/** @type {import('next').NextConfig} */
const nextConfig = {
  // تعطيل SWC minification لتوفير الذاكرة
  swcMinify: false,
  
  // تعطيل optimizations عشان نوفر ذاكرة
  compiler: {
    removeConsole: false,
  },
  
  // تعطيل ESLint أثناء البناء
  eslint: {
    ignoreDuringBuilds: true,
  },
  
  // تعطيل image optimization
  images: { 
    unoptimized: true 
  },
  
  // تقليل webpack optimization
  webpack: (config, { dev, isServer }) => {
    if (dev) {
      // تقليل الـ cache في development
      config.cache = false;
      
      // تقليل الـ optimization
      config.optimization = {
        ...config.optimization,
        minimize: false,
        splitChunks: false,
      };
    }
    
    return config;
  },
  
  experimental: {
    serverComponentsExternalPackages: ['next-auth']
  }
};

module.exports = nextConfig;