import { z } from 'zod'

export const leadSchema = z.object({
  fullName: z.string().min(1, 'Full name is required'),
  email: z.string().email().optional().or(z.literal('')),
  phone: z.string().optional(),
  sourceId: z.string().optional(),
  typeId: z.string().optional(),
  stage: z.enum(['NEW', 'CONTACTED', 'QUALIFIED', 'VIEWING', 'OFFER', 'WON', 'LOST']).default('NEW'),
  assignedTo: z.string().optional(),
  notes: z.string().optional(),
})

export type LeadFormData = z.infer<typeof leadSchema>