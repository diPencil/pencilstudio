type Role = 'SUPER_ADMIN' | 'ADMIN' | 'SALES' | 'AGENT'

export const PERMISSIONS = {
  SUPER_ADMIN: ['*'],
  ADMIN: ['leads', 'properties', 'deals', 'tasks', 'activities', 'owners', 'listings'],
  SALES: ['leads', 'deals', 'tasks', 'activities'],
  AGENT: ['leads', 'tasks', 'activities'],
} as const

export function hasPermission(userRole: Role, resource: string): boolean {
  const permissions = PERMISSIONS[userRole] as readonly string[]
  return permissions.includes('*') || permissions.includes(resource)
}

export function canAccessAdmin(userRole: Role): boolean {
  return ['SUPER_ADMIN', 'ADMIN'].includes(userRole)
}