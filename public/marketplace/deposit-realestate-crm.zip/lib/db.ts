// Enhanced CRM Database with all required features
import bcrypt from 'bcryptjs'

// Settings/Lookups interfaces
interface LeadSource {
  id: string
  name: string
  channel?: string
  isActive: boolean
  createdAt: string
}

interface LeadType {
  id: string
  name: string
  isActive: boolean
  createdAt: string
}

interface PropertyType {
  id: string
  name: string
  isActive: boolean
  createdAt: string
}

interface PropertyStatus {
  id: string
  name: string
  isActive: boolean
  createdAt: string
}

interface DealStage {
  id: string
  name: string
  probability: number
  order: number
  color: string
  isActive: boolean
  createdAt: string
}

interface ActivityType {
  id: string
  name: string
  isActive: boolean
  createdAt: string
}

interface ListingChannel {
  id: string
  name: string
  isActive: boolean
  createdAt: string
}

interface City {
  id: string
  name: string
  isActive: boolean
  createdAt: string
}

// Main entities
interface User {
  id: string
  email: string
  password: string
  fullName: string
  role: string
  isActive: boolean
  createdAt: string
}

interface Lead {
  id: string
  fullName: string
  email?: string
  phone?: string
  sourceId?: string
  typeId?: string
  stage: string
  assignedTo?: string
  notes?: string
  createdAt: string
  updatedAt: string
}

interface Property {
  id: string
  code: string
  typeId: string
  statusId: string
  city: string
  area?: string
  address?: string
  bedrooms?: number
  bathrooms?: number
  sizeSqm?: number
  price?: number
  currency: string
  ownerId?: string
  attachments?: string[]
  createdAt: string
  updatedAt: string
}

interface Listing {
  id: string
  propertyId: string
  channelId: string
  title: string
  description?: string
  priceOverride?: number
  media?: string[]
  status: string
  publishAt?: string
  endAt?: string
  url?: string
  views: number
  inquiries: number
  leadsCreated: number
  createdAt: string
  updatedAt: string
}

interface Deal {
  id: string
  leadId: string
  propertyId?: string
  title: string
  value?: number
  currency: string
  stageId: string
  probability: number
  expectedCloseDate?: string
  assignedTo?: string
  nextStep?: string
  notes?: string
  createdAt: string
  updatedAt: string
}

interface Task {
  id: string
  title: string
  description?: string
  assignedTo: string
  dueDate?: string
  priority: 'Low' | 'Normal' | 'High' | 'Urgent'
  status: 'Open' | 'In Progress' | 'Done'
  leadId?: string
  dealId?: string
  propertyId?: string
  reminder?: 'none' | 'at_time' | '1h' | '24h'
  subtasks?: string[]
  attachments?: string[]
  createdAt: string
  updatedAt: string
}

interface Activity {
  id: string
  type: 'call' | 'email' | 'whatsapp' | 'meeting' | 'viewing' | 'note'
  direction?: string
  leadId?: string
  ownerId?: string
  dealId?: string
  propertyId?: string
  at: string
  duration?: number
  outcome?: 'connected' | 'no_answer' | 'rescheduled' | 'interested' | 'not_interested' | 'completed'
  notes?: string
  attachments?: string[]
  userId: string
  createdAt: string
}

interface Owner {
  id: string
  name: string
  phone?: string
  email?: string
  company?: string
  nationalId?: string
  preferredContact?: string
  payoutDetails?: string
  notes?: string
  createdAt: string
}

// In-memory storage - Start with empty data
const db = {
  // Settings/Lookups
  leadSources: [] as LeadSource[],
  leadTypes: [] as LeadType[],
  propertyTypes: [] as PropertyType[],
  propertyStatuses: [] as PropertyStatus[],
  dealStages: [] as DealStage[],
  activityTypes: [] as ActivityType[],
  listingChannels: [] as ListingChannel[],
  cities: [] as City[],
  
  // Main entities - Start empty
  users: [] as User[],
  leads: [] as Lead[],
  properties: [] as Property[],
  listings: [] as Listing[],
  deals: [] as Deal[],
  tasks: [] as Task[],
  activities: [] as Activity[],
  owners: [] as Owner[],
}

// Initialize with minimal demo data
export async function initializeDatabase() {
  if (db.users.length > 0) return

  console.log('Initializing CRM database with minimal data...')

  const hashedPassword = await bcrypt.hash('Admin@123', 12)

  // Initialize Settings/Lookups only
  
  // Lead Sources
  db.leadSources.push(
    { id: 'src-1', name: 'Facebook Ads', channel: 'Social Media', isActive: true, createdAt: new Date().toISOString() },
    { id: 'src-2', name: 'Website', channel: 'Online', isActive: true, createdAt: new Date().toISOString() },
    { id: 'src-3', name: 'OLX', channel: 'Marketplace', isActive: true, createdAt: new Date().toISOString() },
    { id: 'src-4', name: 'Referral', channel: 'Word of Mouth', isActive: true, createdAt: new Date().toISOString() }
  )

  // Lead Types
  db.leadTypes.push(
    { id: 'type-1', name: 'Buyer', isActive: true, createdAt: new Date().toISOString() },
    { id: 'type-2', name: 'Seller', isActive: true, createdAt: new Date().toISOString() },
    { id: 'type-3', name: 'Renter', isActive: true, createdAt: new Date().toISOString() },
    { id: 'type-4', name: 'Investor', isActive: true, createdAt: new Date().toISOString() }
  )

  // Property Types
  db.propertyTypes.push(
    { id: 'ptype-1', name: 'Apartment', isActive: true, createdAt: new Date().toISOString() },
    { id: 'ptype-2', name: 'Villa', isActive: true, createdAt: new Date().toISOString() },
    { id: 'ptype-3', name: 'Duplex', isActive: true, createdAt: new Date().toISOString() },
    { id: 'ptype-4', name: 'Townhouse', isActive: true, createdAt: new Date().toISOString() }
  )

  // Property Statuses
  db.propertyStatuses.push(
    { id: 'status-1', name: 'Available', isActive: true, createdAt: new Date().toISOString() },
    { id: 'status-2', name: 'Under Offer', isActive: true, createdAt: new Date().toISOString() },
    { id: 'status-3', name: 'Sold', isActive: true, createdAt: new Date().toISOString() },
    { id: 'status-4', name: 'Rented', isActive: true, createdAt: new Date().toISOString() }
  )

  // Deal Stages
  db.dealStages.push(
    { id: 'stage-1', name: 'Pipeline', probability: 10, order: 1, color: '#3b82f6', isActive: true, createdAt: new Date().toISOString() },
    { id: 'stage-2', name: 'Negotiation', probability: 50, order: 2, color: '#eab308', isActive: true, createdAt: new Date().toISOString() },
    { id: 'stage-3', name: 'Agreement', probability: 75, order: 3, color: '#8b5cf6', isActive: true, createdAt: new Date().toISOString() },
    { id: 'stage-4', name: 'Closed Won', probability: 100, order: 4, color: '#10b981', isActive: true, createdAt: new Date().toISOString() },
    { id: 'stage-5', name: 'Closed Lost', probability: 0, order: 5, color: '#ef4444', isActive: true, createdAt: new Date().toISOString() }
  )

  // Activity Types
  db.activityTypes.push(
    { id: 'act-1', name: 'Call', isActive: true, createdAt: new Date().toISOString() },
    { id: 'act-2', name: 'WhatsApp', isActive: true, createdAt: new Date().toISOString() },
    { id: 'act-3', name: 'Email', isActive: true, createdAt: new Date().toISOString() },
    { id: 'act-4', name: 'Meeting', isActive: true, createdAt: new Date().toISOString() },
    { id: 'act-5', name: 'Viewing', isActive: true, createdAt: new Date().toISOString() },
    { id: 'act-6', name: 'Note', isActive: true, createdAt: new Date().toISOString() }
  )

  // Listing Channels
  db.listingChannels.push(
    { id: 'ch-1', name: 'Website', isActive: true, createdAt: new Date().toISOString() },
    { id: 'ch-2', name: 'OLX', isActive: true, createdAt: new Date().toISOString() },
    { id: 'ch-3', name: 'Facebook', isActive: true, createdAt: new Date().toISOString() },
    { id: 'ch-4', name: 'Instagram', isActive: true, createdAt: new Date().toISOString() }
  )

  // Cities
  db.cities.push(
    { id: 'city-1', name: 'القاهرة', isActive: true, createdAt: new Date().toISOString() },
    { id: 'city-2', name: 'الجيزة', isActive: true, createdAt: new Date().toISOString() },
    { id: 'city-3', name: 'الإسكندرية', isActive: true, createdAt: new Date().toISOString() },
    { id: 'city-4', name: 'الشرقية', isActive: true, createdAt: new Date().toISOString() }
  )

  // Add only admin user - no demo data
  db.users.push(
    {
      id: 'admin-1',
      email: 'admin@crm.local',
      password: hashedPassword,
      fullName: 'System Administrator',
      role: 'SUPER_ADMIN',
      isActive: true,
      createdAt: new Date().toISOString()
    }
  )

  console.log('CRM database initialized with minimal data!')
}

// Generate auto codes
function generatePropertyCode(): string {
  const year = new Date().getFullYear()
  const existingCodes = db.properties.map(p => p.code)
  let seq = 1
  let code = `PR-${year}-${seq.toString().padStart(4, '0')}`
  
  while (existingCodes.includes(code)) {
    seq++
    code = `PR-${year}-${seq.toString().padStart(4, '0')}`
  }
  
  return code
}

// Enhanced database operations
export const dbOperations = {
  // Settings/Lookups operations
  getLeadSources: async () => {
    await initializeDatabase()
    return db.leadSources.filter(s => s.isActive)
  },

  createLeadSource: async (data: Omit<LeadSource, 'id' | 'createdAt'>) => {
    await initializeDatabase()
    const newSource: LeadSource = {
      id: `src-${Date.now()}`,
      ...data,
      createdAt: new Date().toISOString()
    }
    db.leadSources.push(newSource)
    return newSource
  },

  getLeadTypes: async () => {
    await initializeDatabase()
    return db.leadTypes.filter(t => t.isActive)
  },

  createLeadType: async (data: Omit<LeadType, 'id' | 'createdAt'>) => {
    await initializeDatabase()
    const newType: LeadType = {
      id: `type-${Date.now()}`,
      ...data,
      createdAt: new Date().toISOString()
    }
    db.leadTypes.push(newType)
    return newType
  },

  getPropertyTypes: async () => {
    await initializeDatabase()
    return db.propertyTypes.filter(t => t.isActive)
  },

  createPropertyType: async (data: Omit<PropertyType, 'id' | 'createdAt'>) => {
    await initializeDatabase()
    const newType: PropertyType = {
      id: `ptype-${Date.now()}`,
      ...data,
      createdAt: new Date().toISOString()
    }
    db.propertyTypes.push(newType)
    return newType
  },

  createDealStage: async (data: Omit<DealStage, 'id' | 'order' | 'createdAt'>) => {
    await initializeDatabase()
    const maxOrder = Math.max(...db.dealStages.map(s => s.order), 0)
    const newStage: DealStage = {
      id: `stage-${Date.now()}`,
      order: maxOrder + 1,
      ...data,
      createdAt: new Date().toISOString()
    }
    db.dealStages.push(newStage)
    return newStage
  },

  createActivityType: async (data: Omit<ActivityType, 'id' | 'createdAt'>) => {
    await initializeDatabase()
    const newType: ActivityType = {
      id: `act-${Date.now()}`,
      ...data,
      createdAt: new Date().toISOString()
    }
    db.activityTypes.push(newType)
    return newType
  },

  createListingChannel: async (data: Omit<ListingChannel, 'id' | 'createdAt'>) => {
    await initializeDatabase()
    const newChannel: ListingChannel = {
      id: `ch-${Date.now()}`,
      ...data,
      createdAt: new Date().toISOString()
    }
    db.listingChannels.push(newChannel)
    return newChannel
  },

  getPropertyStatuses: async () => {
    await initializeDatabase()
    return db.propertyStatuses.filter(s => s.isActive)
  },

  getDealStages: async () => {
    await initializeDatabase()
    return db.dealStages.filter(s => s.isActive).sort((a, b) => a.order - b.order)
  },

  getActivityTypes: async () => {
    await initializeDatabase()
    return db.activityTypes.filter(t => t.isActive)
  },

  getListingChannels: async () => {
    await initializeDatabase()
    return db.listingChannels.filter(c => c.isActive)
  },

  getCities: async () => {
    await initializeDatabase()
    return db.cities.filter(c => c.isActive)
  },

  // Users
  findUserByEmail: async (email: string): Promise<User | null> => {
    await initializeDatabase()
    return db.users.find(user => user.email === email && user.isActive) || null
  },

  getUsers: async () => {
    await initializeDatabase()
    return db.users.filter(u => u.isActive).map(user => ({ ...user, password: undefined }))
  },

  // Leads with enhanced features
  getLeads: async (search?: string, page = 1, limit = 10) => {
    await initializeDatabase()
    let leads = db.leads
    
    if (search) {
      leads = leads.filter(lead => 
        lead.fullName.toLowerCase().includes(search.toLowerCase()) ||
        lead.email?.toLowerCase().includes(search.toLowerCase()) ||
        lead.phone?.includes(search)
      )
    }

    const total = leads.length
    const offset = (page - 1) * limit
    const paginatedLeads = leads.slice(offset, offset + limit)

    return {
      data: paginatedLeads.map(lead => ({
        ...lead,
        source: lead.sourceId ? db.leadSources.find(s => s.id === lead.sourceId) : null,
        type: lead.typeId ? db.leadTypes.find(t => t.id === lead.typeId) : null,
        assignee: lead.assignedTo ? db.users.find(u => u.id === lead.assignedTo) : null
      })),
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
    }
  },

  getLeadById: async (id: string) => {
    await initializeDatabase()
    const lead = db.leads.find(l => l.id === id)
    if (!lead) return null
    
    return {
      ...lead,
      source: lead.sourceId ? db.leadSources.find(s => s.id === lead.sourceId) : null,
      type: lead.typeId ? db.leadTypes.find(t => t.id === lead.typeId) : null,
      assignee: lead.assignedTo ? db.users.find(u => u.id === lead.assignedTo) : null
    }
  },

  createLead: async (data: Omit<Lead, 'id' | 'createdAt' | 'updatedAt'>) => {
    await initializeDatabase()
    const newLead: Lead = {
      id: `lead-${Date.now()}`,
      ...data,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    db.leads.push(newLead)
    
    // Create activity
    db.activities.push({
      id: `activity-${Date.now()}`,
      type: 'note',
      leadId: newLead.id,
      at: new Date().toISOString(),
      notes: 'Lead created',
      userId: data.assignedTo || 'admin-1',
      createdAt: new Date().toISOString()
    })
    
    return dbOperations.getLeadById(newLead.id)
  },

  updateLead: async (id: string, data: Partial<Lead>) => {
    await initializeDatabase()
    const index = db.leads.findIndex(l => l.id === id)
    if (index === -1) return null
    
    const oldLead = db.leads[index]
    db.leads[index] = { ...db.leads[index], ...data, updatedAt: new Date().toISOString() }
    
    // Create activity for stage change
    if (data.stage && data.stage !== oldLead.stage) {
      db.activities.push({
        id: `activity-${Date.now()}`,
        type: 'note',
        leadId: id,
        at: new Date().toISOString(),
        notes: `Stage changed from ${oldLead.stage} to ${data.stage}`,
        userId: data.assignedTo || oldLead.assignedTo || 'admin-1',
        createdAt: new Date().toISOString()
      })
    }
    
    return dbOperations.getLeadById(id)
  },

  deleteLead: async (id: string) => {
    await initializeDatabase()
    const index = db.leads.findIndex(l => l.id === id)
    if (index === -1) return false
    
    db.leads.splice(index, 1)
    return true
  },

  // Properties with enhanced features
  getProperties: async (search?: string, page = 1, limit = 10) => {
    await initializeDatabase()
    let properties = db.properties
    
    if (search) {
      properties = properties.filter(prop => 
        prop.code.toLowerCase().includes(search.toLowerCase()) ||
        prop.city.toLowerCase().includes(search.toLowerCase()) ||
        prop.area?.toLowerCase().includes(search.toLowerCase())
      )
    }

    const total = properties.length
    const offset = (page - 1) * limit
    const paginatedProperties = properties.slice(offset, offset + limit)

    return {
      data: paginatedProperties.map(property => ({
        ...property,
        type: db.propertyTypes.find(t => t.id === property.typeId),
        status: db.propertyStatuses.find(s => s.id === property.statusId),
        owner: property.ownerId ? db.owners.find(o => o.id === property.ownerId) : null
      })),
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
    }
  },

  createProperty: async (data: Omit<Property, 'id' | 'code' | 'createdAt' | 'updatedAt'>) => {
    await initializeDatabase()
    const newProperty: Property = {
      id: `prop-${Date.now()}`,
      code: generatePropertyCode(),
      ...data,
      currency: data.currency || 'EGP',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    db.properties.push(newProperty)
    return newProperty
  },

  updateProperty: async (id: string, data: Partial<Property>) => {
    await initializeDatabase()
    const index = db.properties.findIndex(p => p.id === id)
    if (index === -1) return null
    
    db.properties[index] = { ...db.properties[index], ...data, updatedAt: new Date().toISOString() }
    return db.properties[index]
  },

  deleteProperty: async (id: string) => {
    await initializeDatabase()
    const index = db.properties.findIndex(p => p.id === id)
    if (index === -1) return false
    
    db.properties.splice(index, 1)
    return true
  },

  // Deals with enhanced features
  getDeals: async (page = 1, limit = 10) => {
    await initializeDatabase()
    const total = db.deals.length
    const offset = (page - 1) * limit
    const paginatedDeals = db.deals.slice(offset, offset + limit)

    return {
      data: paginatedDeals.map(deal => ({
        ...deal,
        lead: db.leads.find(l => l.id === deal.leadId),
        property: deal.propertyId ? db.properties.find(p => p.id === deal.propertyId) : null,
        stage: db.dealStages.find(s => s.id === deal.stageId),
        assignee: deal.assignedTo ? db.users.find(u => u.id === deal.assignedTo) : null
      })),
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
    }
  },

  createDeal: async (data: Omit<Deal, 'id' | 'createdAt' | 'updatedAt'>) => {
    await initializeDatabase()
    const newDeal: Deal = {
      id: `deal-${Date.now()}`,
      ...data,
      currency: data.currency || 'EGP',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    db.deals.push(newDeal)
    
    // Create follow-up task
    db.tasks.push({
      id: `task-${Date.now()}`,
      title: 'Follow up on new deal',
      assignedTo: data.assignedTo || 'admin-1',
      dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      priority: 'Normal',
      status: 'Open',
      dealId: newDeal.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    })
    
    return newDeal
  },

  updateDeal: async (id: string, data: Partial<Deal>) => {
    await initializeDatabase()
    const index = db.deals.findIndex(d => d.id === id)
    if (index === -1) return null
    
    const oldDeal = db.deals[index]
    db.deals[index] = { ...db.deals[index], ...data, updatedAt: new Date().toISOString() }
    
    // Handle stage changes
    if (data.stageId && data.stageId !== oldDeal.stageId) {
      const newStage = db.dealStages.find(s => s.id === data.stageId)
      const oldStage = db.dealStages.find(s => s.id === oldDeal.stageId)
      
      // Update probability based on stage
      if (newStage) {
        db.deals[index].probability = newStage.probability
      }
      
      // Create activity
      db.activities.push({
        id: `activity-${Date.now()}`,
        type: 'note',
        dealId: id,
        at: new Date().toISOString(),
        notes: `Deal stage changed from ${oldStage?.name} to ${newStage?.name}`,
        userId: data.assignedTo || oldDeal.assignedTo || 'admin-1',
        createdAt: new Date().toISOString()
      })
      
      // Handle Closed Won
      if (newStage?.name === 'Closed Won') {
        // Close related tasks
        db.tasks.forEach(task => {
          if (task.dealId === id && task.status !== 'Done') {
            task.status = 'Done'
            task.updatedAt = new Date().toISOString()
          }
        })
        
        // End related listings
        if (oldDeal.propertyId) {
          db.listings.forEach(listing => {
            if (listing.propertyId === oldDeal.propertyId && listing.status === 'Published') {
              listing.status = 'Ended'
              listing.endAt = new Date().toISOString()
              listing.updatedAt = new Date().toISOString()
            }
          })
        }
      }
    }
    
    return db.deals[index]
  },

  // Listings with enhanced features
  getListings: async (page = 1, limit = 10, filters?: { channel?: string; status?: string; city?: string }) => {
    await initializeDatabase()
    let listings = db.listings
    
    // Apply filters
    if (filters?.channel) {
      const channel = db.listingChannels.find(c => c.name === filters.channel)
      if (channel) {
        listings = listings.filter(l => l.channelId === channel.id)
      }
    }
    
    if (filters?.status) {
      listings = listings.filter(l => l.status === filters.status)
    }
    
    if (filters?.city) {
      listings = listings.filter(l => {
        const property = db.properties.find(p => p.id === l.propertyId)
        return property?.city === filters.city
      })
    }
    
    const total = listings.length
    const offset = (page - 1) * limit
    const paginatedListings = listings.slice(offset, offset + limit)

    return {
      data: paginatedListings.map(listing => ({
        ...listing,
        property: (() => {
          const property = db.properties.find(p => p.id === listing.propertyId)
          if (!property) return null
          return {
            ...property,
            type: db.propertyTypes.find(t => t.id === property.typeId),
            status: db.propertyStatuses.find(s => s.id === property.statusId)
          }
        })(),
        channel: db.listingChannels.find(c => c.id === listing.channelId),
        isActive: listing.status === 'Published',
        publishedAt: listing.publishAt || listing.createdAt
      })),
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
    }
  },

  getListingById: async (id: string) => {
    await initializeDatabase()
    const listing = db.listings.find(l => l.id === id)
    if (!listing) return null
    
    const property = db.properties.find(p => p.id === listing.propertyId)
    return {
      ...listing,
      property: property ? {
        ...property,
        type: db.propertyTypes.find(t => t.id === property.typeId),
        status: db.propertyStatuses.find(s => s.id === property.statusId)
      } : null,
      channel: db.listingChannels.find(c => c.id === listing.channelId)
    }
  },

  createListing: async (data: Omit<Listing, 'id' | 'views' | 'inquiries' | 'leadsCreated' | 'createdAt' | 'updatedAt'>) => {
    await initializeDatabase()
    const property = db.properties.find(p => p.id === data.propertyId)
    const propertyType = property ? db.propertyTypes.find(t => t.id === property.typeId) : null
    const channel = db.listingChannels.find(c => c.id === data.channelId)
    
    const newListing: Listing = {
      id: `listing-${Date.now()}`,
      ...data,
      title: data.title || `${propertyType?.name || 'عقار'} في ${property?.city || 'غير محدد'} - ${property?.code || 'غير محدد'}`,
      views: 0,
      inquiries: 0,
      leadsCreated: 0,
      publishAt: data.status === 'Published' ? new Date().toISOString() : undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    db.listings.push(newListing)
    
    // Create activity
    db.activities.push({
      id: `activity-${Date.now()}`,
      type: 'note',
      propertyId: data.propertyId,
      at: new Date().toISOString(),
      notes: `Listing created for ${channel?.name || 'Unknown channel'}`,
      userId: 'admin-1',
      createdAt: new Date().toISOString()
    })
    
    return newListing
  },

  updateListing: async (id: string, data: Partial<Listing>) => {
    await initializeDatabase()
    const index = db.listings.findIndex(l => l.id === id)
    if (index === -1) return null
    
    const oldListing = db.listings[index]
    db.listings[index] = { ...db.listings[index], ...data, updatedAt: new Date().toISOString() }
    
    // Handle status changes
    if (data.status && data.status !== oldListing.status) {
      if (data.status === 'Published' && !db.listings[index].publishAt) {
        db.listings[index].publishAt = new Date().toISOString()
      } else if (data.status === 'Ended' && !db.listings[index].endAt) {
        db.listings[index].endAt = new Date().toISOString()
      }
      
      // Create activity
      db.activities.push({
        id: `activity-${Date.now()}`,
        type: 'note',
        propertyId: oldListing.propertyId,
        at: new Date().toISOString(),
        notes: `Listing status changed from ${oldListing.status} to ${data.status}`,
        userId: 'admin-1',
        createdAt: new Date().toISOString()
      })
    }
    
    return db.listings[index]
  },

  deleteListing: async (id: string) => {
    await initializeDatabase()
    const index = db.listings.findIndex(l => l.id === id)
    if (index === -1) return false
    
    db.listings.splice(index, 1)
    return true
  },

  updateListingStatus: async (id: string, status: string) => {
    await initializeDatabase()
    const index = db.listings.findIndex(l => l.id === id)
    if (index === -1) return null
    
    const oldStatus = db.listings[index].status
    db.listings[index].status = status
    db.listings[index].updatedAt = new Date().toISOString()
    
    if (status === 'Published' && !db.listings[index].publishAt) {
      db.listings[index].publishAt = new Date().toISOString()
    } else if (status === 'Ended' && !db.listings[index].endAt) {
      db.listings[index].endAt = new Date().toISOString()
    }
    
    // Create activity
    db.activities.push({
      id: `activity-${Date.now()}`,
      type: 'note',
      propertyId: db.listings[index].propertyId,
      at: new Date().toISOString(),
      notes: `Listing status changed from ${oldStatus} to ${status}`,
      userId: 'admin-1',
      createdAt: new Date().toISOString()
    })
    
    return db.listings[index]
  },

  duplicateListing: async (id: string) => {
    await initializeDatabase()
    const originalListing = db.listings.find(l => l.id === id)
    if (!originalListing) return null
    
    const duplicatedListing: Listing = {
      ...originalListing,
      id: `listing-${Date.now()}`,
      title: `${originalListing.title} (Copy)`,
      status: 'Draft',
      publishAt: undefined,
      endAt: undefined,
      views: 0,
      inquiries: 0,
      leadsCreated: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    
    db.listings.push(duplicatedListing)
    return duplicatedListing
  },

  // Tasks with enhanced features
  getTasks: async (userId?: string, page = 1, limit = 10) => {
    await initializeDatabase()
    let tasks = userId ? db.tasks.filter(task => task.assignedTo === userId) : db.tasks
    
    const total = tasks.length
    const offset = (page - 1) * limit
    const paginatedTasks = tasks.slice(offset, offset + limit)

    return {
      data: paginatedTasks.map(task => ({
        ...task,
        lead: task.leadId ? db.leads.find(l => l.id === task.leadId) : null,
        deal: task.dealId ? db.deals.find(d => d.id === task.dealId) : null,
        property: task.propertyId ? db.properties.find(p => p.id === task.propertyId) : null,
        assignee: db.users.find(u => u.id === task.assignedTo)
      })),
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
    }
  },

  createTask: async (data: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) => {
    await initializeDatabase()
    const newTask: Task = {
      id: `task-${Date.now()}`,
      ...data,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    db.tasks.push(newTask)
    return newTask
  },

  updateTask: async (id: string, data: Partial<Task>) => {
    await initializeDatabase()
    const index = db.tasks.findIndex(t => t.id === id)
    if (index === -1) return null
    
    db.tasks[index] = { ...db.tasks[index], ...data, updatedAt: new Date().toISOString() }
    return db.tasks[index]
  },

  // Activities with enhanced features
  getActivities: async (leadId?: string, dealId?: string, page = 1, limit = 10) => {
    await initializeDatabase()
    let activities = db.activities
    
    if (leadId) activities = activities.filter(a => a.leadId === leadId)
    if (dealId) activities = activities.filter(a => a.dealId === dealId)
    
    // Sort by date descending
    activities = activities.sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime())
    
    const total = activities.length
    const offset = (page - 1) * limit
    const paginatedActivities = activities.slice(offset, offset + limit)

    return {
      data: paginatedActivities.map(activity => ({
        ...activity,
        lead: activity.leadId ? db.leads.find(l => l.id === activity.leadId) : null,
        deal: activity.dealId ? db.deals.find(d => d.id === activity.dealId) : null,
        property: activity.propertyId ? db.properties.find(p => p.id === activity.propertyId) : null,
        owner: activity.ownerId ? db.owners.find(o => o.id === activity.ownerId) : null,
        user: db.users.find(u => u.id === activity.userId)
      })),
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
    }
  },

  createActivity: async (data: Omit<Activity, 'id' | 'createdAt'>) => {
    await initializeDatabase()
    const newActivity: Activity = {
      id: `activity-${Date.now()}`,
      ...data,
      createdAt: new Date().toISOString()
    }
    db.activities.push(newActivity)
    return newActivity
  },

  getDealById: async (id: string) => {
    await initializeDatabase()
    const deal = db.deals.find(d => d.id === id)
    if (!deal) return null
    
    return {
      ...deal,
      lead: db.leads.find(l => l.id === deal.leadId),
      property: deal.propertyId ? db.properties.find(p => p.id === deal.propertyId) : null,
      stage: db.dealStages.find(s => s.id === deal.stageId),
      assignee: deal.assignedTo ? db.users.find(u => u.id === deal.assignedTo) : null
    }
  },

  deleteDeal: async (id: string) => {
    await initializeDatabase()
    const index = db.deals.findIndex(d => d.id === id)
    if (index === -1) return false
    
    db.deals.splice(index, 1)
    return true
  },

  getTaskById: async (id: string) => {
    await initializeDatabase()
    const task = db.tasks.find(t => t.id === id)
    if (!task) return null
    
    return {
      ...task,
      lead: task.leadId ? db.leads.find(l => l.id === task.leadId) : null,
      deal: task.dealId ? db.deals.find(d => d.id === task.dealId) : null,
      property: task.propertyId ? db.properties.find(p => p.id === task.propertyId) : null,
      assignee: db.users.find(u => u.id === task.assignedTo),
      isOverdue: task.dueDate ? new Date(task.dueDate) < new Date() : false
    }
  },

  deleteTask: async (id: string) => {
    await initializeDatabase()
    const index = db.tasks.findIndex(t => t.id === id)
    if (index === -1) return false
    
    db.tasks.splice(index, 1)
    return true
  },

  updateActivity: async (id: string, data: Partial<Activity>) => {
    await initializeDatabase()
    const index = db.activities.findIndex(a => a.id === id)
    if (index === -1) return null
    
    db.activities[index] = { ...db.activities[index], ...data }
    return db.activities[index]
  },

  deleteActivity: async (id: string) => {
    await initializeDatabase()
    const index = db.activities.findIndex(a => a.id === id)
    if (index === -1) return false
    
    db.activities.splice(index, 1)
    return true
  },

  // Owners with enhanced features
  getOwners: async (page = 1, limit = 10) => {
    await initializeDatabase()
    const total = db.owners.length
    const offset = (page - 1) * limit
    const paginatedOwners = db.owners.slice(offset, offset + limit)

    return {
      data: paginatedOwners.map(owner => ({
        ...owner,
        properties: db.properties.filter(p => p.ownerId === owner.id).map(property => ({
          ...property,
          type: db.propertyTypes.find(t => t.id === property.typeId),
          status: db.propertyStatuses.find(s => s.id === property.statusId)
        }))
      })),
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
    }
  },

  getOwnerById: async (id: string) => {
    await initializeDatabase()
    const owner = db.owners.find(o => o.id === id)
    if (!owner) return null
    
    return {
      ...owner,
      properties: db.properties.filter(p => p.ownerId === owner.id).map(property => ({
        ...property,
        type: db.propertyTypes.find(t => t.id === property.typeId),
        status: db.propertyStatuses.find(s => s.id === property.statusId)
      }))
    }
  },

  createOwner: async (data: Omit<Owner, 'id' | 'createdAt'>) => {
    await initializeDatabase()
    const newOwner: Owner = {
      id: `owner-${Date.now()}`,
      ...data,
      createdAt: new Date().toISOString()
    }
    db.owners.push(newOwner)
    return newOwner
  },

  updateOwner: async (id: string, data: Partial<Owner>) => {
    await initializeDatabase()
    const index = db.owners.findIndex(o => o.id === id)
    if (index === -1) return null
    
    db.owners[index] = { ...db.owners[index], ...data }
    return db.owners[index]
  },

  deleteOwner: async (id: string) => {
    await initializeDatabase()
    const index = db.owners.findIndex(o => o.id === id)
    if (index === -1) return false
    
    db.owners.splice(index, 1)
    return true
  },

  // Dashboard with enhanced metrics
  getDashboardData: async () => {
    await initializeDatabase()
    const today = new Date().toISOString().split('T')[0]
    const thisWeek = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
    
    const leadsToday = db.leads.filter(lead => 
      lead.createdAt.startsWith(today)
    ).length

    const openDealsValue = db.deals
      .filter(deal => {
        const stage = db.dealStages.find(s => s.id === deal.stageId)
        return stage && !['Closed Won', 'Closed Lost'].includes(stage.name)
      })
      .reduce((sum, deal) => sum + (deal.value || 0), 0)

    const viewingsThisWeek = db.activities.filter(activity => 
      activity.type === 'viewing' && activity.at >= thisWeek
    ).length

    const totalProperties = db.properties.length
    const openTasks = db.tasks.filter(t => t.status !== 'Done').length
    const totalListings = db.listings.length
    const activeListings = db.listings.filter(l => l.status === 'Published').length
    const totalActivities = db.activities.length
    const activitiesThisWeek = db.activities.filter(a => a.at >= thisWeek).length
    const totalOwners = db.owners.length

    const recentActivities = db.activities
      .slice(-10)
      .reverse()
      .map(activity => ({
        ...activity,
        lead: activity.leadId ? db.leads.find(l => l.id === activity.leadId) : null,
        deal: activity.dealId ? db.deals.find(d => d.id === activity.dealId) : null,
        user: db.users.find(u => u.id === activity.userId)
      }))

    return {
      leadsToday,
      openDealsValue,
      viewingsThisWeek,
      totalProperties,
      openTasks,
      totalListings,
      activeListings,
      totalActivities,
      activitiesThisWeek,
      totalOwners,
      recentActivities
    }
  }
}