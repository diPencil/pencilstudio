export const locales = ['en', 'ar'] as const
export type Locale = typeof locales[number]

export const defaultLocale: Locale = 'en'

export function getDirection(locale: Locale) {
  return locale === 'ar' ? 'rtl' : 'ltr'
}

export async function getMessages(locale: Locale) {
  try {
    return (await import(`@/messages/${locale}.json`)).default
  } catch {
    return (await import(`@/messages/${defaultLocale}.json`)).default
  }
}