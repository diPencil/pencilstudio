'use client'

import { useState } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'

import { useLocale } from '@/components/providers/locale-provider'

const channelSchema = z.object({
  name: z.string().min(1, 'Name is required'),
})

type ChannelFormData = z.infer<typeof channelSchema>

interface AddListingChannelModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onChannelAdded: (channel: { id: string; name: string; isActive: boolean; createdAt: string }) => void
}

export function AddListingChannelModal({ open, onOpenChange, onChannelAdded }: AddListingChannelModalProps) {
  const [isLoading, setIsLoading] = useState(false)
  const { messages } = useLocale()

  const form = useForm<ChannelFormData>({
    resolver: zodResolver(channelSchema),
    defaultValues: {
      name: '',
    },
  })

  const handleSubmit = async (data: ChannelFormData) => {
    setIsLoading(true)
    try {
      const response = await fetch('/api/settings/listing-channels', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...data,
          isActive: true,
        }),
      })

      if (response.ok) {
        const newChannel = await response.json()
        onChannelAdded(newChannel)
        form.reset()
      }
    } catch (error) {
      console.error('Failed to create listing channel:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{messages?.modals?.addListingChannel || 'Add Listing Channel'}</DialogTitle>
          <DialogDescription>
            {messages?.modals?.addListingChannelDescription || 'Create a new channel for publishing listings'}
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{messages?.modals?.typeName || 'Channel Name'} *</FormLabel>
                  <FormControl>
                    <Input {...field} disabled={isLoading} placeholder={messages?.modals?.channelNamePlaceholder || "e.g., TikTok"} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={isLoading}
              >
                {messages?.common?.cancel || 'Cancel'}
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (messages?.common?.creating || 'Creating...') : (messages?.modals?.createChannel || 'Create Channel')}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}