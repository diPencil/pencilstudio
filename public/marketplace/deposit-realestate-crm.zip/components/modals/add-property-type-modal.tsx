'use client'

import { useState } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'

import { useLocale } from '@/components/providers/locale-provider'

const typeSchema = z.object({
  name: z.string().min(1, 'Name is required'),
})

type TypeFormData = z.infer<typeof typeSchema>

interface AddPropertyTypeModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onTypeAdded: (type: { id: string; name: string; isActive: boolean; createdAt: string }) => void
}

export function AddPropertyTypeModal({ open, onOpenChange, onTypeAdded }: AddPropertyTypeModalProps) {
  const [isLoading, setIsLoading] = useState(false)
  const { messages } = useLocale()

  const form = useForm<TypeFormData>({
    resolver: zodResolver(typeSchema),
    defaultValues: {
      name: '',
    },
  })

  const handleSubmit = async (data: TypeFormData) => {
    setIsLoading(true)
    try {
      const response = await fetch('/api/settings/property-types', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...data,
          isActive: true,
        }),
      })

      if (response.ok) {
        const newType = await response.json()
        onTypeAdded(newType)
        form.reset()
      }
    } catch (error) {
      console.error('Failed to create property type:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{messages?.modals?.addPropertyType || 'Add Property Type'}</DialogTitle>
          <DialogDescription>
            {messages?.modals?.addPropertyTypeDescription || 'Create a new property type for categorizing your properties.'}
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{messages?.modals?.typeName || 'Type Name'} *</FormLabel>
                  <FormControl>
                    <Input {...field} disabled={isLoading} placeholder={messages?.modals?.propertyTypePlaceholder || "e.g., Loft"} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={isLoading}
              >
                {messages?.common?.cancel || 'Cancel'}
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (messages?.common?.creating || 'Creating...') : (messages?.modals?.createType || 'Create Type')}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}