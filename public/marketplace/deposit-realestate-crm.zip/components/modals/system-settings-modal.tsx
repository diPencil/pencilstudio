'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Globe, Database, Download, Upload, Trash2, RefreshCw } from 'lucide-react'
import { useLocale } from '@/components/providers/locale-provider'

interface SystemSettingsModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function SystemSettingsModal({ open, onOpenChange }: SystemSettingsModalProps) {
  const { locale, setLocale, messages } = useLocale()
  const [defaultCurrency, setDefaultCurrency] = useState('EGP')
  const [isLoading, setIsLoading] = useState(false)

  const handleSaveLocalization = async () => {
    setIsLoading(true)
    try {
      // Save localization settings
      localStorage.setItem('defaultCurrency', defaultCurrency)
      
      // Here you would typically save to backend
      await new Promise(resolve => setTimeout(resolve, 1000)) // Simulate API call
      
      alert(messages?.systemSettings?.languageCurrencySaved || 'Language and currency settings saved successfully!')
    } catch (error) {
      console.error('Failed to save localization settings:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleExportData = async (type: string) => {
    try {
      const response = await fetch(`/api/export/${type}`)
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `${type}-export-${new Date().toISOString().split('T')[0]}.csv`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      }
    } catch (error) {
      console.error('Export failed:', error)
    }
  }

  const handleImportData = (type: string) => {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = '.csv,.xlsx'
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (!file) return

      const formData = new FormData()
      formData.append('file', file)

      try {
        const response = await fetch(`/api/import/${type}`, {
          method: 'POST',
          body: formData,
        })

        if (response.ok) {
          alert(messages?.systemSettings?.dataImportedSuccessfully || 'Data imported successfully!')
        }
      } catch (error) {
        console.error('Import failed:', error)
      }
    }
    input.click()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{messages?.systemSettings?.title || 'System Settings'}</DialogTitle>
          <DialogDescription>
            {messages?.systemSettings?.description || 'Manage language, currency and data settings'}
          </DialogDescription>
        </DialogHeader>
        
        <Tabs defaultValue="localization" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="localization" className="flex items-center gap-2">
              <Globe className="h-4 w-4" />
              {messages?.systemSettings?.languageCurrency || 'Language & Currency'}
            </TabsTrigger>
            <TabsTrigger value="data" className="flex items-center gap-2">
              <Database className="h-4 w-4" />
              {messages?.systemSettings?.dataManagement || 'Data Management'}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="localization" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{messages?.systemSettings?.languageSettings || 'Language Settings'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">{messages?.systemSettings?.defaultLanguage || 'Default Language'}</label>
                  <Select value={locale} onValueChange={(value: any) => setLocale(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ar">{messages?.systemSettings?.arabicDefault || 'Arabic (Default)'}</SelectItem>
                      <SelectItem value="en">{messages?.systemSettings?.english || 'English'}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">{messages?.systemSettings?.textDirection || 'Text Direction'}</label>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full" />
                    <span className="text-sm">{messages?.systemSettings?.rtlEnabled || 'RTL (Right to Left) - Enabled'}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{messages?.systemSettings?.currencySettings || 'Currency Settings'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">{messages?.systemSettings?.defaultCurrency || 'Default Currency'}</label>
                  <Select value={defaultCurrency} onValueChange={setDefaultCurrency}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="EGP">{messages?.systemSettings?.egyptianPound || 'Egyptian Pound (EGP)'}</SelectItem>
                      <SelectItem value="USD">{messages?.systemSettings?.usDollar || 'US Dollar (USD)'}</SelectItem>
                      <SelectItem value="EUR">{messages?.systemSettings?.euro || 'Euro (EUR)'}</SelectItem>
                      <SelectItem value="AED">{messages?.systemSettings?.emiratiDirham || 'Emirati Dirham (AED)'}</SelectItem>
                      <SelectItem value="SAR">{messages?.systemSettings?.saudiRiyal || 'Saudi Riyal (SAR)'}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">{messages?.systemSettings?.numberFormat || 'Number Format'}</label>
                  <div className="text-sm text-muted-foreground">
                    <p>{messages?.systemSettings?.numberFormatExample || 'Example: 1,250,000 Egyptian Pounds'}</p>
                    <p>{messages?.systemSettings?.numberFormatDescription || 'Comma for thousands, dot for decimals'}</p>
                  </div>
                </div>

                <Button onClick={handleSaveLocalization} disabled={isLoading} className="w-full">
                  {isLoading ? (messages?.systemSettings?.saving || 'Saving...') : (messages?.systemSettings?.saveLanguageCurrency || 'Save Language & Currency Settings')}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="data" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{messages?.systemSettings?.importExportData || 'Import and Export Data'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-medium">{messages?.systemSettings?.exportData || 'Export Data'}</h4>
                    <div className="space-y-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full justify-start"
                        onClick={() => handleExportData('leads')}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        {messages?.systemSettings?.exportLeads || 'Export Leads'}
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full justify-start"
                        onClick={() => handleExportData('properties')}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        {messages?.systemSettings?.exportProperties || 'Export Properties'}
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full justify-start"
                        onClick={() => handleExportData('deals')}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        {messages?.systemSettings?.exportDeals || 'Export Deals'}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">{messages?.systemSettings?.importData || 'Import Data'}</h4>
                    <div className="space-y-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full justify-start"
                        onClick={() => handleImportData('leads')}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        {messages?.systemSettings?.importLeads || 'Import Leads'}
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full justify-start"
                        onClick={() => handleImportData('properties')}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        {messages?.systemSettings?.importProperties || 'Import Properties'}
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full justify-start"
                        onClick={() => handleImportData('owners')}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        {messages?.systemSettings?.importOwners || 'Import Owners'}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{messages?.systemSettings?.backupRestore || 'Backup and Restore'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Button variant="outline" className="h-20 flex flex-col space-y-2">
                    <Database className="h-6 w-6" />
                    <span>{messages?.systemSettings?.createBackup || 'Create Backup'}</span>
                  </Button>
                  <Button variant="outline" className="h-20 flex flex-col space-y-2">
                    <RefreshCw className="h-6 w-6" />
                    <span>{messages?.systemSettings?.restoreBackup || 'Restore from Backup'}</span>
                  </Button>
                </div>
                
                <div className="text-sm text-muted-foreground bg-muted/50 p-3 rounded">
                  <p className="font-medium mb-1">{messages?.systemSettings?.lastBackup || 'Last backup:'}</p>
                  <p>{messages?.systemSettings?.todayAutomatic || 'Today at 2:30 AM (automatic)'}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-destructive">{messages?.systemSettings?.dangerZone || 'Danger Zone'}</CardTitle>
              </CardHeader>
              <CardContent>
                <Button variant="destructive" className="w-full">
                  <Trash2 className="h-4 w-4 mr-2" />
                  {messages?.systemSettings?.deleteAllData || 'Delete All Data (Irreversible)'}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
          >
            {messages?.systemSettings?.close || 'Close'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}