'use client'

import { useState } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'

import { useLocale } from '@/components/providers/locale-provider'

const stageSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  probability: z.number().min(0).max(100),
  color: z.string().min(1, 'Color is required'),
})

type StageFormData = z.infer<typeof stageSchema>

interface AddDealStageModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onStageAdded: (stage: { id: string; name: string; probability: number; color: string; isActive: boolean; createdAt: string }) => void
}

export function AddDealStageModal({ open, onOpenChange, onStageAdded }: AddDealStageModalProps) {
  const [isLoading, setIsLoading] = useState(false)
  const { messages } = useLocale()

  const form = useForm<StageFormData>({
    resolver: zodResolver(stageSchema),
    defaultValues: {
      name: '',
      probability: 50,
      color: '#3b82f6',
    },
  })

  const handleSubmit = async (data: StageFormData) => {
    setIsLoading(true)
    try {
      const response = await fetch('/api/settings/deal-stages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...data,
          isActive: true,
        }),
      })

      if (response.ok) {
        const newStage = await response.json()
        onStageAdded(newStage)
        form.reset()
      }
    } catch (error) {
      console.error('Failed to create deal stage:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{messages?.modals?.addDealStage || 'Add Deal Stage'}</DialogTitle>
          <DialogDescription>
            {messages?.modals?.addDealStageDescription || 'Create a new stage to track deal progress'}
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{messages?.modals?.typeName || 'Stage Name'} *</FormLabel>
                  <FormControl>
                    <Input {...field} disabled={isLoading} placeholder={messages?.modals?.stageNamePlaceholder || "e.g., Negotiation"} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="probability"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{messages?.deals?.probability || 'Success Probability'} (%)</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      type="number" 
                      min="0" 
                      max="100"
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                      disabled={isLoading} 
                      placeholder="50" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="color"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{messages?.modals?.stageColor || 'Stage Color'}</FormLabel>
                  <FormControl>
                    <div className="flex items-center space-x-2">
                      <Input 
                        {...field} 
                        type="color"
                        disabled={isLoading} 
                        className="w-16 h-10"
                      />
                      <Input 
                        {...field} 
                        disabled={isLoading} 
                        placeholder="#3b82f6"
                        className="flex-1"
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={isLoading}
              >
                {messages?.common?.cancel || 'Cancel'}
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (messages?.common?.creating || 'Creating...') : (messages?.modals?.createStage || 'Create Stage')}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}