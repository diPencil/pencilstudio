'use client'

import { useState, useEffect } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Users, Plus, Edit, Trash2, Shield, UserCheck, UserX } from 'lucide-react'
import { useLocale } from '@/components/providers/locale-provider'

const userSchema = z.object({
  fullName: z.string().min(1, 'Full name is required'),
  email: z.string().email('Invalid email address'),
  phone: z.string().optional(),
  role: z.enum(['SUPER_ADMIN', 'ADMIN', 'SALES', 'AGENT']),
  password: z.string().min(6, 'Password must be at least 6 characters'),
})

type UserFormData = z.infer<typeof userSchema>

interface User {
  id: string
  fullName: string
  email: string
  phone?: string
  role: string
  isActive: boolean
  createdAt: string
}

interface UserManagementModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function UserManagementModal({ open, onOpenChange }: UserManagementModalProps) {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [isLoading, setIsLoading] = useState(false)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [activeTab, setActiveTab] = useState('users')
  const { messages } = useLocale()

  const form = useForm<UserFormData>({
    resolver: zodResolver(userSchema),
    defaultValues: {
      fullName: '',
      email: '',
      phone: '',
      role: 'AGENT',
      password: '',
    },
  })

  const fetchUsers = async () => {
    try {
      const response = await fetch('/api/users')
      if (response.ok) {
        const data = await response.json()
        setUsers(data)
      }
    } catch (error) {
      console.error('Failed to fetch users:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (open) {
      fetchUsers()
    }
  }, [open])

  const handleSubmit = async (data: UserFormData) => {
    setIsLoading(true)
    try {
      const url = editingUser ? `/api/users/${editingUser.id}` : '/api/users'
      const method = editingUser ? 'PATCH' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchUsers()
        form.reset()
        setEditingUser(null)
      }
    } catch (error) {
      console.error('Failed to save user:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleEdit = (user: User) => {
    setEditingUser(user)
    form.reset({
      fullName: user.fullName,
      email: user.email,
      phone: user.phone || '',
      role: user.role as any,
      password: '', // Don't pre-fill password
    })
    setActiveTab('add-user')
  }

  const handleToggleStatus = async (userId: string, isActive: boolean) => {
    try {
      const response = await fetch(`/api/users/${userId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isActive }),
      })

      if (response.ok) {
        await fetchUsers()
      }
    } catch (error) {
      console.error('Failed to update user status:', error)
    }
  }

  const getRoleColor = (role: string) => {
    const colors: Record<string, string> = {
      SUPER_ADMIN: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
      ADMIN: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300',
      SALES: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      AGENT: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    }
    return colors[role] || 'bg-gray-100 text-gray-800'
  }

  const getRoleText = (role: string) => {
    const texts: Record<string, string> = {
      SUPER_ADMIN: 'مدير عام',
      ADMIN: 'مدير',
      SALES: 'مبيعات',
      AGENT: 'وكيل',
    }
    return texts[role] || role
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{messages?.userManagement?.title || 'User and Role Management'}</DialogTitle>
          <DialogDescription>
            {messages?.userManagement?.description || 'Add and edit users and manage permissions'}
          </DialogDescription>
        </DialogHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="users">{messages?.userManagement?.users || 'Users'}</TabsTrigger>
            <TabsTrigger value="add-user">{messages?.userManagement?.addUser || 'Add User'}</TabsTrigger>
            <TabsTrigger value="roles">{messages?.userManagement?.rolesPermissions || 'Roles & Permissions'}</TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {users.map((user) => (
                <Card key={user.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{user.fullName}</CardTitle>
                      <div className="flex items-center space-x-2">
                        <Badge className={getRoleColor(user.role)}>
                          {getRoleText(user.role)}
                        </Badge>
                        {user.isActive ? (
                          <UserCheck className="h-4 w-4 text-green-600" />
                        ) : (
                          <UserX className="h-4 w-4 text-red-600" />
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                    {user.phone && (
                      <p className="text-sm text-muted-foreground">{user.phone}</p>
                    )}
                    <div className="flex items-center space-x-2 pt-2">
                      <Button size="sm" variant="outline" onClick={() => handleEdit(user)}>
                        <Edit className="h-3 w-3 mr-1" />
                        {messages?.common?.edit || 'Edit'}
                      </Button>
                      <Button 
                        size="sm" 
                        variant={user.isActive ? "destructive" : "default"}
                        onClick={() => handleToggleStatus(user.id, !user.isActive)}
                      >
                        {user.isActive ? (messages?.userManagement?.deactivate || 'Deactivate') : (messages?.userManagement?.activate || 'Activate')}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="add-user" className="space-y-4">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{messages?.userManagement?.fullName || 'Full Name'} *</FormLabel>
                      <FormControl>
                        <Input {...field} disabled={isLoading} placeholder={messages?.userManagement?.enterFullName || "Enter full name"} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{messages?.userManagement?.email || 'Email'} *</FormLabel>
                        <FormControl>
                          <Input {...field} type="email" disabled={isLoading} placeholder="user@example.com" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{messages?.userManagement?.phone || 'Phone'}</FormLabel>
                        <FormControl>
                          <Input {...field} disabled={isLoading} placeholder="+971 50 123 4567" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{messages?.userManagement?.role || 'Role'} *</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder={messages?.userManagement?.selectRole || "Select role"} />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="SUPER_ADMIN">{messages?.userManagement?.superAdmin || 'Super Admin'}</SelectItem>
                            <SelectItem value="ADMIN">{messages?.userManagement?.admin || 'Admin'}</SelectItem>
                            <SelectItem value="SALES">{messages?.userManagement?.sales || 'Sales'}</SelectItem>
                            <SelectItem value="AGENT">{messages?.userManagement?.agent || 'Agent'}</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{messages?.userManagement?.password || 'Password'} *</FormLabel>
                        <FormControl>
                          <Input {...field} type="password" disabled={isLoading} placeholder="••••••••" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      form.reset()
                      setEditingUser(null)
                    }}
                    disabled={isLoading}
                  >
                    {messages?.userManagement?.cancel || 'Cancel'}
                  </Button>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading 
                      ? (messages?.userManagement?.saving || 'Saving...') 
                      : editingUser ? (messages?.userManagement?.updateUser || 'Update User') : (messages?.userManagement?.createUser || 'Create User')
                    }
                  </Button>
                </div>
              </form>
            </Form>
          </TabsContent>

          <TabsContent value="roles" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Shield className="h-5 w-5 text-red-600" />
                    <span>{messages?.userManagement?.superAdmin || 'Super Admin'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <span>{messages?.userManagement?.allPermissions || 'All permissions'}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <span>{messages?.userManagement?.userManagement || 'User management'}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <span>{messages?.userManagement?.settingsManagement || 'Settings management'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Shield className="h-5 w-5 text-purple-600" />
                    <span>{messages?.userManagement?.admin || 'Admin'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <span>{messages?.userManagement?.leadsProperties || 'Leads and properties'}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <span>{messages?.userManagement?.dealsTasksActivities || 'Deals, tasks and activities'}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <span>{messages?.userManagement?.ownersListings || 'Owners and listings'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Shield className="h-5 w-5 text-blue-600" />
                    <span>{messages?.userManagement?.sales || 'Sales'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <span>{messages?.userManagement?.leadsDeals || 'Leads and deals'}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <span>{messages?.userManagement?.tasksActivities || 'Tasks and activities'}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full" />
                      <span>{messages?.userManagement?.readPropertiesListings || 'Read properties and listings'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Shield className="h-5 w-5 text-green-600" />
                    <span>{messages?.userManagement?.agent || 'Agent'}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <span>{messages?.userManagement?.assignedLeads || 'Assigned leads only'}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <span>{messages?.userManagement?.personalDealsTasksActivities || 'Personal deals, tasks and activities'}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full" />
                      <span>{messages?.userManagement?.limitedRead || 'Limited read access'}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
          >
            {messages?.userManagement?.close || 'Close'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}