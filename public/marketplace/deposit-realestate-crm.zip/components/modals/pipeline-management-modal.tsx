'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { GripVertical, Edit, Trash2, Plus } from 'lucide-react'

import { useLocale } from '@/components/providers/locale-provider'

interface DealStage {
  id: string
  name: string
  probability: number
  order: number
  color: string
  isActive: boolean
}

interface PipelineManagementModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function PipelineManagementModal({ open, onOpenChange }: PipelineManagementModalProps) {
  const [stages, setStages] = useState<DealStage[]>([])
  const [loading, setLoading] = useState(true)
  const [editingStage, setEditingStage] = useState<DealStage | null>(null)
  const { messages } = useLocale()

  const fetchStages = async () => {
    try {
      const response = await fetch('/api/settings/deal-stages')
      if (response.ok) {
        const data = await response.json()
        setStages(data)
      }
    } catch (error) {
      console.error('Failed to fetch deal stages:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (open) {
      fetchStages()
    }
  }, [open])

  const handleUpdateStage = async (stageId: string, updates: Partial<DealStage>) => {
    try {
      const response = await fetch(`/api/settings/deal-stages/${stageId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updates),
      })

      if (response.ok) {
        await fetchStages()
      }
    } catch (error) {
      console.error('Failed to update stage:', error)
    }
  }

  const handleDeleteStage = async (stageId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذه المرحلة؟')) return

    try {
      const response = await fetch(`/api/settings/deal-stages/${stageId}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        await fetchStages()
      }
    } catch (error) {
      console.error('Failed to delete stage:', error)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{messages?.pipelineManagement?.title || 'Deal Stage Management'}</DialogTitle>
          <DialogDescription>
            {messages?.pipelineManagement?.description || 'Customize deal stages, order them and set colors and probabilities'}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">{messages?.pipelineManagement?.dealStages || 'Deal Stages'}</h3>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-2" />
              {messages?.pipelineManagement?.addStage || 'Add Stage'}
            </Button>
          </div>

          <div className="space-y-3">
            {stages.map((stage, index) => (
              <Card key={stage.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-4">
                    <GripVertical className="h-5 w-5 text-muted-foreground cursor-move" />
                    
                    <div 
                      className="w-4 h-4 rounded-full border-2 border-white shadow-sm"
                      style={{ backgroundColor: stage.color }}
                    />
                    
                    <div className="flex-1">
                      {editingStage?.id === stage.id ? (
                        <div className="grid grid-cols-3 gap-2">
                          <Input
                            value={editingStage.name}
                            onChange={(e) => setEditingStage({...editingStage, name: e.target.value})}
                            placeholder={messages?.pipelineManagement?.stageName || "Stage name"}
                          />
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            value={editingStage.probability}
                            onChange={(e) => setEditingStage({...editingStage, probability: parseInt(e.target.value) || 0})}
                            placeholder={messages?.deals?.probability || "Probability %"}
                          />
                          <Input
                            type="color"
                            value={editingStage.color}
                            onChange={(e) => setEditingStage({...editingStage, color: e.target.value})}
                          />
                        </div>
                      ) : (
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-semibold">{stage.name}</h4>
                            <p className="text-sm text-muted-foreground">
                              {messages?.deals?.probability || 'Success probability'}: {stage.probability}%
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline">{messages?.pipelineManagement?.stage || 'Stage'} {index + 1}</Badge>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setEditingStage(stage)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleDeleteStage(stage.id)}
                              className="text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {editingStage?.id === stage.id && (
                    <div className="flex justify-end space-x-2 mt-3 pt-3 border-t">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setEditingStage(null)}
                      >
                        {messages?.pipelineManagement?.cancel || 'Cancel'}
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => {
                          handleUpdateStage(stage.id, editingStage)
                          setEditingStage(null)
                        }}
                      >
                        {messages?.pipelineManagement?.save || 'Save'}
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="bg-muted/50">
            <CardContent className="p-4">
              <h4 className="font-semibold mb-2">{messages?.pipelineManagement?.enabledAutomations || 'Enabled Automations:'}</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full" />
                  <span>{messages?.pipelineManagement?.negotiationAutomation || 'When reaching \'Negotiation\' stage ← Create follow-up task after 24 hours'}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span>{messages?.pipelineManagement?.closedWonAutomation || 'When deal is closed successfully ← Close tasks and end listings'}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full" />
                  <span>{messages?.pipelineManagement?.overdueTaskAutomation || 'When task is overdue ← Notify assignee and manager'}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
          >
            {messages?.pipelineManagement?.close || 'Close'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}