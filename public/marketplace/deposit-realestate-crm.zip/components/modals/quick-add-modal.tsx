'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Building, CheckSquare, Activity, HeartHandshake, UserCheck, User } from 'lucide-react'
import { LeadForm } from '@/components/forms/lead-form'
import { PropertyForm } from '@/components/forms/property-form'
import { TaskForm } from '@/components/forms/task-form'
import { ActivityForm } from '@/components/forms/activity-form'
import { DealForm } from '@/components/forms/deal-form'
import { OwnerForm } from '@/components/forms/owner-form'

import { useLocale } from '@/components/providers/locale-provider'

interface QuickAddModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function QuickAddModal({ open, onOpenChange }: QuickAddModalProps) {
  const [selectedType, setSelectedType] = useState<string | null>(null)
  const { messages } = useLocale()

  const quickAddOptions = [
    {
      id: 'lead',
      title: messages?.quickAdd?.lead || 'Lead',
      description: messages?.quickAdd?.leadDescription || 'Add new lead to system',
      icon: User,
      color: 'bg-blue-500',
    },
    {
      id: 'property',
      title: messages?.quickAdd?.property || 'Property',
      description: messages?.quickAdd?.propertyDescription || 'Add property to inventory',
      icon: Building,
      color: 'bg-green-500',
    },
    {
      id: 'task',
      title: messages?.quickAdd?.task || 'Task',
      description: messages?.quickAdd?.taskDescription || 'Create new task',
      icon: CheckSquare,
      color: 'bg-orange-500',
    },
    {
      id: 'activity',
      title: messages?.quickAdd?.activity || 'Activity',
      description: messages?.quickAdd?.activityDescription || 'Log activity or interaction',
      icon: Activity,
      color: 'bg-purple-500',
    },
    {
      id: 'deal',
      title: messages?.quickAdd?.deal || 'Deal',
      description: messages?.quickAdd?.dealDescription || 'Create new deal',
      icon: HeartHandshake,
      color: 'bg-pink-500',
    },
    {
      id: 'owner',
      title: messages?.quickAdd?.owner || 'Owner',
      description: messages?.quickAdd?.ownerDescription || 'Add new property owner',
      icon: UserCheck,
      color: 'bg-indigo-500',
    },
  ]

  const handleSubmit = async (data: any) => {
    try {
      const response = await fetch(`/api/${selectedType}s`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        setSelectedType(null)
        onOpenChange(false)
        // Refresh the current page data if needed
        window.location.reload()
      }
    } catch (error) {
      console.error(`Failed to create ${selectedType}:`, error)
    }
  }

  const renderForm = () => {
    const commonProps = {
      open: true,
      onOpenChange: (open: boolean) => {
        if (!open) setSelectedType(null)
      },
      onSubmit: handleSubmit,
      mode: 'create' as const,
    }

    switch (selectedType) {
      case 'lead':
        return <LeadForm {...commonProps} />
      case 'property':
        return <PropertyForm {...commonProps} />
      case 'task':
        return <TaskForm {...commonProps} />
      case 'activity':
        return <ActivityForm {...commonProps} />
      case 'deal':
        return <DealForm {...commonProps} />
      case 'owner':
        return <OwnerForm {...commonProps} />
      default:
        return null
    }
  }

  if (selectedType) {
    return renderForm()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{messages?.quickAdd?.title || 'Quick Add'}</DialogTitle>
          <DialogDescription>
            {messages?.quickAdd?.description || 'What would you like to add?'}
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-2 gap-4 py-4">
          {quickAddOptions.map((option) => {
            const Icon = option.icon
            return (
              <Button
                key={option.id}
                variant="outline"
                className="h-24 flex flex-col space-y-2 hover:shadow-md transition-all"
                onClick={() => setSelectedType(option.id)}
              >
                <div className={`w-8 h-8 ${option.color} rounded-lg flex items-center justify-center`}>
                  <Icon className="h-5 w-5 text-white" />
                </div>
                <div className="text-center">
                  <p className="font-medium">{option.title}</p>
                  <p className="text-xs text-muted-foreground">{option.description}</p>
                </div>
              </Button>
            )
          })}
        </div>
      </DialogContent>
    </Dialog>
  )
}