'use client'

import { useState } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { useLocale } from '@/components/providers/locale-provider'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'

const sourceSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  channel: z.string().optional(),
})

type SourceFormData = z.infer<typeof sourceSchema>

interface AddSourceModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSourceAdded: (source: { id: string; name: string; channel?: string; isActive: boolean; createdAt: string }) => void
}

export function AddSourceModal({ open, onOpenChange, onSourceAdded }: AddSourceModalProps) {
  const [isLoading, setIsLoading] = useState(false)
  const { messages } = useLocale()

  const form = useForm<SourceFormData>({
    resolver: zodResolver(sourceSchema),
    defaultValues: {
      name: '',
      channel: '',
    },
  })

  const handleSubmit = async (data: SourceFormData) => {
    setIsLoading(true)
    try {
      const response = await fetch('/api/settings/sources', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...data,
          isActive: true,
        }),
      })

      if (response.ok) {
        const newSource = await response.json()
        onSourceAdded(newSource)
        form.reset()
      }
    } catch (error) {
      console.error('Failed to create source:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{messages?.modals?.addLeadSource || 'Add Lead Source'}</DialogTitle>
          <DialogDescription>
            {messages?.modals?.addLeadSourceDescription || 'Create a new lead source for tracking where your leads come from.'}
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{messages?.modals?.sourceName || 'Source Name'} *</FormLabel>
                  <FormControl>
                    <Input {...field} disabled={isLoading} placeholder={messages?.modals?.sourceNamePlaceholder || "e.g., Google Ads"} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="channel"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{messages?.modals?.channel || 'Channel (Optional)'}</FormLabel>
                  <FormControl>
                    <Input {...field} disabled={isLoading} placeholder={messages?.modals?.channelPlaceholder || "e.g., Online Marketing"} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={isLoading}
              >
                {messages?.common?.cancel || 'Cancel'}
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (messages?.common?.creating || 'Creating...') : (messages?.modals?.createSource || 'Create Source')}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}