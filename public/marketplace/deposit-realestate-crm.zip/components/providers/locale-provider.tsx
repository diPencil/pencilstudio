'use client'

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { Locale, defaultLocale, getDirection } from '@/lib/i18n'

interface LocaleContextType {
  locale: Locale
  setLocale: (locale: Locale) => void
  messages: any
  direction: 'ltr' | 'rtl'
}

const LocaleContext = createContext<LocaleContextType | undefined>(undefined)

interface LocaleProviderProps {
  children: ReactNode
  initialLocale?: Locale
  initialMessages: any
}

export function LocaleProvider({ 
  children, 
  initialLocale = defaultLocale,
  initialMessages 
}: LocaleProviderProps) {
  const [locale, setLocaleState] = useState<Locale>(initialLocale)
  const [messages, setMessages] = useState(initialMessages)
  const direction = getDirection(locale)

  const setLocale = (newLocale: Locale) => {
    setLocaleState(newLocale)
    // Save to localStorage
    localStorage.setItem('locale', newLocale)
    // Update document direction and lang
    document.documentElement.dir = getDirection(newLocale)
    document.documentElement.lang = newLocale
    
    // Load new messages
    import(`@/messages/${newLocale}.json`).then((module) => {
      setMessages(module.default)
    })
  }

  useEffect(() => {
    // Check localStorage for saved locale
    const savedLocale = localStorage.getItem('locale') as Locale
    if (savedLocale && savedLocale !== locale) {
      setLocale(savedLocale)
    }
  }, [])

  return (
    <LocaleContext.Provider value={{ locale, setLocale, messages, direction }}>
      {children}
    </LocaleContext.Provider>
  )
}

export function useLocale() {
  const context = useContext(LocaleContext)
  if (context === undefined) {
    throw new Error('useLocale must be used within a LocaleProvider')
  }
  return context
}