'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { useLocale } from '@/components/providers/locale-provider'
import { LayoutDashboard, Users, Building, List, HeartHandshake as Handshake, CheckSquare, Activity, UserCheck, Settings, Home, MessageSquare } from 'lucide-react'

interface SidebarProps {
  onClose?: () => void
}

const navigationItems = [
  {
    key: 'dashboard',
    href: '/dashboard',
    icon: LayoutDashboard,
  },
  {
    key: 'leads',
    href: '/leads',
    icon: Users,
  },
  {
    key: 'properties',
    href: '/properties',
    icon: Building,
  },
  {
    key: 'listings',
    href: '/listings',
    icon: List,
  },
  {
    key: 'deals',
    href: '/deals',
    icon: Handshake,
  },
  {
    key: 'tasks',
    href: '/tasks',
    icon: CheckSquare,
  },
  {
    key: 'activities',
    href: '/activities',
    icon: Activity,
  },
  {
    key: 'owners',
    href: '/owners',
    icon: UserCheck,
  },
  {
    key: 'support',
    href: '/support',
    icon: MessageSquare,
  },
  {
    key: 'settings',
    href: '/settings',
    icon: Settings,
  },
]

export function Sidebar({ onClose }: SidebarProps) {
  const pathname = usePathname()
  const { messages, direction } = useLocale()

  const handleNavClick = (href: string) => {
    if (onClose) {
      onClose()
    }
  }

  return (
    <div className={`flex flex-col w-64 bg-card h-full ${
      direction === 'rtl' ? 'border-l border-border' : 'border-r border-border'
    }`}>
      <div className="p-6">
        <div className={`flex items-center ${
          direction === 'rtl' ? 'space-x-reverse space-x-2' : 'space-x-2'
        }`}>
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Home className="w-5 h-5 text-primary-foreground" />
          </div>
          <h1 className="text-lg md:text-xl font-bold">Deposit CRM</h1>
        </div>
      </div>
      
      <nav className="flex-1 px-4 space-y-1 pb-6">
        {navigationItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href
          
          return (
            <Link
              key={item.key}
              href={item.href}
              onClick={() => handleNavClick(item.href)}
              className={cn(
                'flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-all duration-200',
                'hover:bg-accent hover:text-accent-foreground hover:shadow-sm',
                isActive 
                  ? 'bg-primary text-primary-foreground shadow-sm' 
                  : 'text-muted-foreground'
              )}
            >
              <Icon className={`h-5 w-5 ${direction === 'rtl' ? 'ml-3' : 'mr-3'}`} />
              <span className="truncate">{messages?.nav?.[item.key] || item.key}</span>
            </Link>
          )
        })}
      </nav>
    </div>
  )
}