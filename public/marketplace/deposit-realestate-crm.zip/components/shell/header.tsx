'use client'

import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { LanguageSwitcher } from './language-switcher'
import { ThemeToggle } from './theme-toggle'
import { useLocale } from '@/components/providers/locale-provider'
import { Bell, User, LogOut, Plus } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { QuickAddModal } from '@/components/modals/quick-add-modal'

interface HeaderProps {
  onMenuClick?: () => void
}

export function Header({ onMenuClick }: HeaderProps) {
  const { user, signOut } = useAuth()
  const { messages, direction } = useLocale()
  const [quickAddOpen, setQuickAddOpen] = useState(false)
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const router = useRouter()
  const [notifications, setNotifications] = useState<any[]>([])
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024)
    }
    
    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  useEffect(() => {
    // Start with empty notifications - system should be clean
    setNotifications([])
  }, [])

  const unreadCount = notifications.filter(n => !n.isRead).length

  const handleNotificationClick = (notification: any) => {
    // Mark as read
    setNotifications(prev => 
      prev.map(n => n.id === notification.id ? { ...n, isRead: true } : n)
    )
    
    // Navigate based on type
    switch (notification.type) {
      case 'assignment':
      case 'new_lead':
        router.push('/leads')
        break
      case 'due_task':
        router.push('/tasks')
        break
      case 'deal_update':
        router.push('/deals')
        break
      default:
        break
    }
    
    setNotificationsOpen(false)
  }
  return (
    <header className="flex items-center justify-between px-4 sm:px-6 py-3 sm:py-4 bg-card border-b border-border">
      <div className="flex items-center min-w-0">
        {/* Mobile menu button */}
        {isMobile && onMenuClick && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onMenuClick}
            className="mr-3"
          >
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </Button>
        )}
        
        <h2 className="text-lg font-semibold text-muted-foreground">
          <span className="hidden sm:inline">Welcome back, </span>
          <span className="truncate">{user?.name}</span>
        </h2>
      </div>

      <div className="flex items-center space-x-2 sm:space-x-4 rtl:space-x-reverse">
        <Button size="sm" className="bg-primary hover:bg-primary/90 hidden sm:flex" onClick={() => setQuickAddOpen(true)}>
          <Plus className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
          <span className="hidden md:inline">{messages?.quickAdd?.title || 'Quick Add'}</span>
        </Button>
        
        {/* Mobile Quick Add */}
        <Button size="sm" className="bg-primary hover:bg-primary/90 sm:hidden" onClick={() => setQuickAddOpen(true)}>
          <Plus className="h-4 w-4" />
        </Button>

        <Dialog open={notificationsOpen} onOpenChange={setNotificationsOpen}>
          <DialogTrigger asChild>
            <Button size="sm" variant="ghost" className="relative">
              <Bell className="h-4 w-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full text-xs flex items-center justify-center text-white">
                  {unreadCount}
                </span>
              )}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{messages?.notifications?.title || 'Notifications'}</DialogTitle>
              <DialogDescription>
                {messages?.notifications?.description || 'Latest updates and reminders'}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {notifications.slice(0, 3).map((notification) => (
                <div 
                  key={notification.id}
                  className={`flex items-start space-x-3 p-3 rounded-lg cursor-pointer hover:bg-muted/50 transition-colors ${
                    notification.type === 'assignment' ? 'bg-blue-50 dark:bg-blue-900/20' :
                    notification.type === 'due_task' ? 'bg-orange-50 dark:bg-orange-900/20' :
                    'bg-green-50 dark:bg-green-900/20'
                  }`}
                  onClick={() => handleNotificationClick(notification)}
                >
                  <div className={`w-2 h-2 rounded-full mt-2 ${
                    notification.type === 'assignment' ? 'bg-blue-500' :
                    notification.type === 'due_task' ? 'bg-orange-500' :
                    'bg-green-500'
                  }`} />
                  <div className="flex-1">
                    <p className={`text-sm font-medium ${!notification.isRead ? 'font-bold' : ''}`}>
                      {notification.title}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {notification.message}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(notification.createdAt).toLocaleString('ar-EG')}
                    </p>
                  </div>
                  {!notification.isRead && (
                    <div className="w-2 h-2 bg-primary rounded-full" />
                  )}
                </div>
              ))}
            </div>
            <div className="flex justify-end">
              <Button variant="outline" size="sm" onClick={() => {
                setNotificationsOpen(false)
                router.push('/notifications')
              }}>
                {messages?.notifications?.viewAllNotifications || 'View All Notifications'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <div className="hidden sm:flex items-center space-x-2">
          <LanguageSwitcher />
          <ThemeToggle />
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="flex items-center space-x-2 rtl:space-x-reverse min-w-0">
              <User className="h-4 w-4" />
              <span className="hidden sm:inline truncate max-w-24">{user?.name}</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align={direction === 'rtl' ? 'start' : 'end'}>
            <div className="sm:hidden">
              <DropdownMenuItem onClick={() => setQuickAddOpen(true)}>
                <Plus className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                {messages?.quickAdd?.title || 'Quick Add'}
              </DropdownMenuItem>
            </div>
            <DropdownMenuItem onClick={() => signOut()}>
              <LogOut className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
              {messages?.auth?.signOut || 'Sign Out'}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      
      <QuickAddModal
        open={quickAddOpen}
        onOpenChange={setQuickAddOpen}
      />
    </header>
  )
}