'use client'

import { useState, useEffect } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { leadSchema, LeadFormData } from '@/lib/validators/lead'
import { useLocale } from '@/components/providers/locale-provider'
import { Plus } from 'lucide-react'
import { AddSourceModal } from '@/components/modals/add-source-modal'
import { AddLeadTypeModal } from '@/components/modals/add-lead-type-modal'

interface LeadFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubmit: (data: LeadFormData) => Promise<void>
  initialData?: Partial<LeadFormData>
  mode?: 'create' | 'edit'
}

interface LeadSource {
  id: string
  name: string
  channel?: string
}

interface LeadType {
  id: string
  name: string
}

export function LeadForm({
  open,
  onOpenChange,
  onSubmit,
  initialData,
  mode = 'create'
}: LeadFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [sources, setSources] = useState<LeadSource[]>([])
  const [types, setTypes] = useState<LeadType[]>([])
  const [sourceModalOpen, setSourceModalOpen] = useState(false)
  const [typeModalOpen, setTypeModalOpen] = useState(false)
  const { messages } = useLocale()

  const form = useForm<LeadFormData>({
    resolver: zodResolver(leadSchema),
    defaultValues: {
      fullName: initialData?.fullName || undefined,
      email: initialData?.email || undefined,
      phone: initialData?.phone || undefined,
      sourceId: initialData?.sourceId || undefined,
      typeId: initialData?.typeId || undefined,
      stage: initialData?.stage || 'NEW',
      assignedTo: initialData?.assignedTo || undefined,
      notes: initialData?.notes || undefined,
    },
  })

  // Fetch sources and types
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [sourcesRes, typesRes] = await Promise.all([
          fetch('/api/settings/sources'),
          fetch('/api/settings/lead-types')
        ])
        
        if (sourcesRes.ok) {
          const sourcesData = await sourcesRes.json()
          setSources(sourcesData)
        }
        
        if (typesRes.ok) {
          const typesData = await typesRes.json()
          setTypes(typesData)
        }
      } catch (error) {
        console.error('Failed to fetch form data:', error)
      }
    }

    if (open) {
      fetchData()
    }
  }, [open])

  const handleSubmit = async (data: LeadFormData) => {
    setIsLoading(true)
    try {
      await onSubmit(data)
      form.reset()
      onOpenChange(false)
    } catch (error) {
      console.error('Form submission error:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSourceAdded = (newSource: LeadSource) => {
    setSources(prev => [...prev, newSource])
    form.setValue('sourceId', newSource.id)
    setSourceModalOpen(false)
  }

  const handleTypeAdded = (newType: LeadType) => {
    setTypes(prev => [...prev, newType])
    form.setValue('typeId', newType.id)
    setTypeModalOpen(false)
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {mode === 'create' 
                ? (messages?.leads?.addLead || 'Add Lead')
                : (messages?.leads?.editLead || 'Edit Lead')
              }
            </DialogTitle>
            <DialogDescription>
              {mode === 'create'
                ? 'Add a new lead to your CRM system.'
                : 'Update the lead information.'
              }
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{messages?.leads?.fullName || 'Full Name'} *</FormLabel>
                    <FormControl>
                      <Input {...field} disabled={isLoading} placeholder="Enter full name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{messages?.common?.email || 'Email'}</FormLabel>
                      <FormControl>
                        <Input {...field} type="email" disabled={isLoading} placeholder="email@example.com" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{messages?.common?.phone || 'Phone'}</FormLabel>
                      <FormControl>
                        <Input {...field} disabled={isLoading} placeholder="+971 50 123 4567" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="sourceId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{messages?.leads?.source || 'Source'}</FormLabel>
                      <div className="flex gap-2">
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger className="flex-1">
                              <SelectValue placeholder="Select source" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {sources.map((source) => (
                              <SelectItem key={source.id} value={source.id}>
                                {source.name}
                                {source.channel && (
                                  <span className="text-muted-foreground ml-2">({source.channel})</span>
                                )}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setSourceModalOpen(true)}
                          disabled={isLoading}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="typeId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Lead Type</FormLabel>
                      <div className="flex gap-2">
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger className="flex-1">
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {types.map((type) => (
                              <SelectItem key={type.id} value={type.id}>
                                {type.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setTypeModalOpen(true)}
                          disabled={isLoading}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="stage"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{messages?.leads?.stage || 'Stage'}</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select stage" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="NEW">
                          {messages?.leads?.stages?.NEW || 'New'}
                        </SelectItem>
                        <SelectItem value="CONTACTED">
                          {messages?.leads?.stages?.CONTACTED || 'Contacted'}
                        </SelectItem>
                        <SelectItem value="QUALIFIED">
                          {messages?.leads?.stages?.QUALIFIED || 'Qualified'}
                        </SelectItem>
                        <SelectItem value="VIEWING">
                          {messages?.leads?.stages?.VIEWING || 'Viewing'}
                        </SelectItem>
                        <SelectItem value="OFFER">
                          {messages?.leads?.stages?.OFFER || 'Offer'}
                        </SelectItem>
                        <SelectItem value="WON">
                          {messages?.leads?.stages?.WON || 'Won'}
                        </SelectItem>
                        <SelectItem value="LOST">
                          {messages?.leads?.stages?.LOST || 'Lost'}
                        </SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        disabled={isLoading} 
                        rows={3} 
                        placeholder="Add any notes about this lead..."
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => onOpenChange(false)}
                  disabled={isLoading}
                >
                  {messages?.common?.cancel || 'Cancel'}
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading 
                    ? (messages?.common?.loading || 'Loading...') 
                    : (messages?.common?.save || 'Save')
                  }
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <AddSourceModal
        open={sourceModalOpen}
        onOpenChange={setSourceModalOpen}
        onSourceAdded={handleSourceAdded}
      />

      <AddLeadTypeModal
        open={typeModalOpen}
        onOpenChange={setTypeModalOpen}
        onTypeAdded={handleTypeAdded}
      />
    </>
  )
}