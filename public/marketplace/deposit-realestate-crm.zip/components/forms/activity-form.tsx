'use client'

import { useState, useEffect } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useLocale } from '@/components/providers/locale-provider'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { CalendarIcon, Clock } from 'lucide-react'
import { format } from 'date-fns'
import { cn } from '@/lib/utils'

const activitySchema = z.object({
  type: z.string().min(1, 'Activity type is required'),
  direction: z.enum(['inbound', 'outbound']).optional(),
  leadId: z.string().optional(),
  ownerId: z.string().optional(),
  dealId: z.string().optional(),
  propertyId: z.string().optional(),
  at: z.string().min(1, 'Date and time is required'),
  duration: z.number().min(0).optional(),
  outcome: z.enum(['connected', 'no_answer', 'rescheduled', 'interested', 'not_interested', 'completed']).optional(),
  notes: z.string().optional(),
})

type ActivityFormData = z.infer<typeof activitySchema>

interface ActivityFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubmit: (data: ActivityFormData) => Promise<void>
  initialData?: Partial<ActivityFormData>
  mode?: 'create' | 'edit'
}

interface ActivityType {
  id: string
  name: string
}

interface Lead {
  id: string
  fullName: string
}

interface Deal {
  id: string
  title: string
}

interface Property {
  id: string
  code: string
  city: string
}

interface Owner {
  id: string
  name: string
}

export function ActivityForm({
  open,
  onOpenChange,
  onSubmit,
  initialData,
  mode = 'create'
}: ActivityFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [activityTypes, setActivityTypes] = useState<ActivityType[]>([])
  const [leads, setLeads] = useState<Lead[]>([])
  const [deals, setDeals] = useState<Deal[]>([])
  const [properties, setProperties] = useState<Property[]>([])
  const [owners, setOwners] = useState<Owner[]>([])
  const { messages } = useLocale()

  const form = useForm<ActivityFormData>({
    resolver: zodResolver(activitySchema),
    defaultValues: {
      type: initialData?.type || undefined,
      direction: initialData?.direction || undefined,
      leadId: initialData?.leadId || undefined,
      ownerId: initialData?.ownerId || undefined,
      dealId: initialData?.dealId || undefined,
      propertyId: initialData?.propertyId || undefined,
      at: initialData?.at || new Date().toISOString(),
      duration: initialData?.duration || 0,
      outcome: initialData?.outcome || undefined,
      notes: initialData?.notes || undefined,
    },
  })

  const selectedType = form.watch('type')

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [typesRes, leadsRes, dealsRes, propertiesRes, ownersRes] = await Promise.all([
          fetch('/api/settings/activity-types'),
          fetch('/api/leads'),
          fetch('/api/deals'),
          fetch('/api/properties'),
          fetch('/api/owners')
        ])
        
        if (typesRes.ok) {
          const typesData = await typesRes.json()
          setActivityTypes(typesData)
        }
        
        if (leadsRes.ok) {
          const leadsData = await leadsRes.json()
          setLeads(leadsData.data || [])
        }
        
        if (dealsRes.ok) {
          const dealsData = await dealsRes.json()
          setDeals(dealsData.data || [])
        }
        
        if (propertiesRes.ok) {
          const propertiesData = await propertiesRes.json()
          setProperties(propertiesData.data || [])
        }
        
        if (ownersRes.ok) {
          const ownersData = await ownersRes.json()
          setOwners(ownersData.data || [])
        }
      } catch (error) {
        console.error('Failed to fetch form data:', error)
      }
    }

    if (open) {
      fetchData()
    }
  }, [open])

  const handleSubmit = async (data: ActivityFormData) => {
    setIsLoading(true)
    try {
      await onSubmit(data)
      form.reset()
      onOpenChange(false)
    } catch (error) {
      console.error('Form submission error:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const requiresDirection = ['call', 'whatsapp', 'email'].includes(selectedType?.toLowerCase() || '')
  const requiresDuration = ['call', 'meeting', 'viewing'].includes(selectedType?.toLowerCase() || '')

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {mode === 'create' ? 'Log Activity' : 'Edit Activity'}
          </DialogTitle>
          <DialogDescription>
            {mode === 'create'
              ? 'Record a new interaction or activity.'
              : 'Update the activity information.'
            }
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Activity Type *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="no-activity-type">Select activity type</SelectItem>
                        {activityTypes.map((type) => (
                          <SelectItem key={type.id} value={type.name.toLowerCase()}>
                            {type.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {requiresDirection && (
                <FormField
                  control={form.control}
                  name="direction"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Direction</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select direction" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="outbound">Outbound</SelectItem>
                          <SelectItem value="inbound">Inbound</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="at"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Date & Time *</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(new Date(field.value), "PPP p")
                            ) : (
                              <span>Pick date & time</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value ? new Date(field.value) : undefined}
                          onSelect={(date) => {
                            if (date) {
                              // Keep the current time if updating date
                              const currentTime = field.value ? new Date(field.value) : new Date()
                              date.setHours(currentTime.getHours())
                              date.setMinutes(currentTime.getMinutes())
                              field.onChange(date.toISOString())
                            }
                          }}
                          initialFocus
                        />
                        <div className="p-3 border-t">
                          <div className="flex items-center space-x-2">
                            <Clock className="h-4 w-4" />
                            <Input
                              type="time"
                              value={field.value ? format(new Date(field.value), "HH:mm") : ""}
                              onChange={(e) => {
                                if (field.value && e.target.value) {
                                  const date = new Date(field.value)
                                  const [hours, minutes] = e.target.value.split(':')
                                  date.setHours(parseInt(hours), parseInt(minutes))
                                  field.onChange(date.toISOString())
                                }
                              }}
                            />
                          </div>
                        </div>
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {requiresDuration && (
                <FormField
                  control={form.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Duration (minutes)</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="number" 
                          min="0"
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                          disabled={isLoading} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
            </div>

            <FormField
              control={form.control}
              name="outcome"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Outcome</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select outcome" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="connected">Connected</SelectItem>
                      <SelectItem value="no_answer">No Answer</SelectItem>
                      <SelectItem value="rescheduled">Rescheduled</SelectItem>
                      <SelectItem value="interested">Interested</SelectItem>
                      <SelectItem value="not_interested">Not Interested</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Related entities */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium">Related To (Optional)</h4>
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="leadId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Lead</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(value === 'no-lead' ? undefined : value)} 
                        value={field.value || 'no-lead'}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select lead" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="no-lead">No lead</SelectItem>
                          {leads.map((lead) => (
                            <SelectItem key={lead.id} value={lead.id}>
                              {lead.fullName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="ownerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Owner</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(value === 'no-owner' ? undefined : value)} 
                        value={field.value || 'no-owner'}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select owner" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="no-owner">No owner</SelectItem>
                          {owners.map((owner) => (
                            <SelectItem key={owner.id} value={owner.id}>
                              {owner.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="dealId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Deal</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(value === 'no-deal' ? undefined : value)} 
                        value={field.value || 'no-deal'}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select deal" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="no-deal">No deal</SelectItem>
                          {deals.map((deal) => (
                            <SelectItem key={deal.id} value={deal.id}>
                              {deal.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="propertyId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Property</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(value === 'no-property' ? undefined : value)} 
                        value={field.value || 'no-property'}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select property" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="no-property">No property</SelectItem>
                          {properties.map((property) => (
                            <SelectItem key={property.id} value={property.id}>
                              {property.code} - {property.city}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      disabled={isLoading} 
                      rows={4} 
                      placeholder="Add details about this activity..."
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={isLoading}
              >
                {messages?.common?.cancel || 'Cancel'}
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading 
                  ? (messages?.common?.loading || 'Loading...') 
                  : (messages?.common?.save || 'Save')
                }
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}