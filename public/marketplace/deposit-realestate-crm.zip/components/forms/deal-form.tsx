'use client'

import { useState, useEffect } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useLocale } from '@/components/providers/locale-provider'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { CalendarIcon, Search } from 'lucide-react'
import { format } from 'date-fns'
import { cn } from '@/lib/utils'

const dealSchema = z.object({
  leadId: z.string().min(1, 'Lead is required'),
  propertyId: z.string().optional(),
  title: z.string().optional(),
  value: z.number().min(0).optional(),
  currency: z.string().default('EGP'),
  stageId: z.string().min(1, 'Stage is required'),
  probability: z.number().min(0).max(100).optional(),
  expectedCloseDate: z.string().optional(),
  assignedTo: z.string().optional(),
  nextStep: z.string().optional(),
  notes: z.string().optional(),
})

type DealFormData = z.infer<typeof dealSchema>

interface DealFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubmit: (data: DealFormData) => Promise<void>
  initialData?: Partial<DealFormData>
  mode?: 'create' | 'edit'
}

interface Lead {
  id: string
  fullName: string
  email?: string
  phone?: string
}

interface Property {
  id: string
  code: string
  city: string
  area?: string
  type: { name: string }
}

interface DealStage {
  id: string
  name: string
  probability: number
  color: string
}

interface User {
  id: string
  fullName: string
}

export function DealForm({
  open,
  onOpenChange,
  onSubmit,
  initialData,
  mode = 'create'
}: DealFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [leads, setLeads] = useState<Lead[]>([])
  const [properties, setProperties] = useState<Property[]>([])
  const [dealStages, setDealStages] = useState<DealStage[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [leadSearch, setLeadSearch] = useState('')
  const { messages } = useLocale()

  const form = useForm<DealFormData>({
    resolver: zodResolver(dealSchema),
    defaultValues: {
      leadId: initialData?.leadId || undefined,
      propertyId: initialData?.propertyId || undefined,
      title: initialData?.title || undefined,
      value: initialData?.value || 0,
      currency: initialData?.currency || 'EGP',
      stageId: initialData?.stageId || undefined,
      probability: initialData?.probability || 0,
      expectedCloseDate: initialData?.expectedCloseDate || undefined,
      assignedTo: initialData?.assignedTo || undefined,
      nextStep: initialData?.nextStep || undefined,
      notes: initialData?.notes || undefined,
    },
  })

  // Watch for changes to auto-generate title
  const selectedLeadId = form.watch('leadId')
  const selectedPropertyId = form.watch('propertyId')
  const selectedStageId = form.watch('stageId')

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [leadsRes, propertiesRes, stagesRes, usersRes] = await Promise.all([
          fetch('/api/leads'),
          fetch('/api/properties'),
          fetch('/api/settings/deal-stages'),
          fetch('/api/users')
        ])
        
        if (leadsRes.ok) {
          const leadsData = await leadsRes.json()
          setLeads(leadsData.data || [])
        }
        
        if (propertiesRes.ok) {
          const propertiesData = await propertiesRes.json()
          setProperties(propertiesData.data || [])
        }
        
        if (stagesRes.ok) {
          const stagesData = await stagesRes.json()
          setDealStages(stagesData)
        }
        
        if (usersRes.ok) {
          const usersData = await usersRes.json()
          setUsers(usersData)
        }
      } catch (error) {
        console.error('Failed to fetch form data:', error)
      }
    }

    if (open) {
      fetchData()
    }
  }, [open])

  // Auto-generate title when lead or property changes
  useEffect(() => {
    if (selectedLeadId && !form.getValues('title')) {
      const lead = leads.find(l => l.id === selectedLeadId)
      const property = selectedPropertyId ? properties.find(p => p.id === selectedPropertyId) : null
      
      if (lead) {
        const title = property 
          ? `${lead.fullName} - ${property.code} (${property.city})`
          : `${lead.fullName} - Deal`
        form.setValue('title', title)
      }
    }
  }, [selectedLeadId, selectedPropertyId, leads, properties, form])

  // Auto-update probability when stage changes
  useEffect(() => {
    if (selectedStageId) {
      const stage = dealStages.find(s => s.id === selectedStageId)
      if (stage) {
        form.setValue('probability', stage.probability)
      }
    }
  }, [selectedStageId, dealStages, form])

  const handleSubmit = async (data: DealFormData) => {
    setIsLoading(true)
    try {
      await onSubmit(data)
      form.reset()
      onOpenChange(false)
    } catch (error) {
      console.error('Form submission error:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const filteredLeads = leads.filter(lead =>
    lead.fullName.toLowerCase().includes(leadSearch.toLowerCase()) ||
    lead.email?.toLowerCase().includes(leadSearch.toLowerCase()) ||
    lead.phone?.includes(leadSearch)
  )

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {mode === 'create' ? 'Add Deal' : 'Edit Deal'}
          </DialogTitle>
          <DialogDescription>
            {mode === 'create'
              ? 'Create a new deal to track your sales pipeline.'
              : 'Update the deal information.'
            }
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="leadId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Lead *</FormLabel>
                    <div className="space-y-2">
                      <div className="relative">
                        <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                          placeholder="Search leads..."
                          value={leadSearch}
                          onChange={(e) => setLeadSearch(e.target.value)}
                        />
                      </div>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select lead" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {filteredLeads.map((lead) => (
                            <SelectItem key={lead.id} value={lead.id}>
                              <div>
                                <div className="font-medium">{lead.fullName}</div>
                                {lead.phone && (
                                  <div className="text-sm text-muted-foreground">{lead.phone}</div>
                                )}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="propertyId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Property (Optional)</FormLabel>
                    <Select onValueChange={(value) => field.onChange(value === 'no-property' ? undefined : value)} value={field.value || 'no-property'}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select property" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="no-property">No property selected</SelectItem>
                        {properties.map((property) => (
                          <SelectItem key={property.id} value={property.id}>
                            {property.code} - {property.city}
                            {property.area && `, ${property.area}`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input {...field} disabled={isLoading} placeholder="Auto-generated from lead + property" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="value"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deal Value</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="number" 
                        min="0"
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        disabled={isLoading} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="currency"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Currency</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Currency" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="EGP">EGP</SelectItem>
                        <SelectItem value="USD">USD</SelectItem>
                        <SelectItem value="EUR">EUR</SelectItem>
                        <SelectItem value="AED">AED</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="probability"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Probability (%)</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="number" 
                        min="0"
                        max="100"
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        disabled={isLoading} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="stageId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Stage *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select stage" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {dealStages.map((stage) => (
                          <SelectItem key={stage.id} value={stage.id}>
                            <div className="flex items-center space-x-2">
                              <div 
                                className="w-3 h-3 rounded-full" 
                                style={{ backgroundColor: stage.color }}
                              />
                              <span>{stage.name}</span>
                              <span className="text-muted-foreground">({stage.probability}%)</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="assignedTo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assigned To</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select user" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {users.map((user) => (
                          <SelectItem key={user.id} value={user.id}>
                            {user.fullName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="expectedCloseDate"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Expected Close Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "w-full pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          {field.value ? (
                            format(new Date(field.value), "PPP")
                          ) : (
                            <span>Pick a date</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value ? new Date(field.value) : undefined}
                        onSelect={(date) => field.onChange(date?.toISOString())}
                        disabled={(date) =>
                          date < new Date()
                        }
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="nextStep"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Next Step</FormLabel>
                  <FormControl>
                    <Input {...field} disabled={isLoading} placeholder="What's the next action to take?" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      disabled={isLoading} 
                      rows={3} 
                      placeholder="Add any notes about this deal..."
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={isLoading}
              >
                {messages?.common?.cancel || 'Cancel'}
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading 
                  ? (messages?.common?.loading || 'Loading...') 
                  : (messages?.common?.save || 'Save')
                }
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}