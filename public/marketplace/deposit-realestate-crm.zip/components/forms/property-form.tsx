'use client'

import { useState, useEffect } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useLocale } from '@/components/providers/locale-provider'
import { Plus, RefreshCw } from 'lucide-react'
import { AddPropertyTypeModal } from '@/components/modals/add-property-type-modal'

const propertySchema = z.object({
  typeId: z.string().min(1, 'Property type is required'),
  statusId: z.string().min(1, 'Status is required'),
  city: z.string().min(1, 'City is required'),
  area: z.string().optional(),
  address: z.string().optional(),
  bedrooms: z.number().min(0).optional(),
  bathrooms: z.number().min(0).optional(),
  sizeSqm: z.number().min(0).optional(),
  price: z.number().min(0).optional(),
  currency: z.string().default('AED'),
  ownerId: z.string().optional(),
})

type PropertyFormData = z.infer<typeof propertySchema>

interface PropertyFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubmit: (data: PropertyFormData & { code?: string }) => Promise<void>
  initialData?: Partial<PropertyFormData & { code?: string }>
  mode?: 'create' | 'edit'
}

interface PropertyType {
  id: string
  name: string
}

interface PropertyStatus {
  id: string
  name: string
}

interface Owner {
  id: string
  name: string
}

export function PropertyForm({
  open,
  onOpenChange,
  onSubmit,
  initialData,
  mode = 'create'
}: PropertyFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [propertyTypes, setPropertyTypes] = useState<PropertyType[]>([])
  const [propertyStatuses, setPropertyStatuses] = useState<PropertyStatus[]>([])
  const [owners, setOwners] = useState<Owner[]>([])
  const [typeModalOpen, setTypeModalOpen] = useState(false)
  const [generatedCode, setGeneratedCode] = useState('')
  const { messages } = useLocale()

  const form = useForm<PropertyFormData>({
    resolver: zodResolver(propertySchema),
    defaultValues: {
      typeId: initialData?.typeId || undefined,
      statusId: initialData?.statusId || undefined,
      city: initialData?.city || undefined,
      area: initialData?.area || undefined,
      address: initialData?.address || undefined,
      bedrooms: initialData?.bedrooms || 0,
      bathrooms: initialData?.bathrooms || 0,
      sizeSqm: initialData?.sizeSqm || 0,
      price: initialData?.price || 0,
      currency: initialData?.currency || 'AED',
      ownerId: initialData?.ownerId || undefined,
    },
  })

  // Fetch form data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [typesRes, statusesRes, ownersRes] = await Promise.all([
          fetch('/api/settings/property-types'),
          fetch('/api/settings/property-statuses'),
          fetch('/api/owners')
        ])
        
        if (typesRes.ok) {
          const typesData = await typesRes.json()
          setPropertyTypes(typesData)
        }
        
        if (statusesRes.ok) {
          const statusesData = await statusesRes.json()
          setPropertyStatuses(statusesData)
        }
        
        if (ownersRes.ok) {
          const ownersData = await ownersRes.json()
          setOwners(ownersData.data || [])
        }
      } catch (error) {
        console.error('Failed to fetch form data:', error)
      }
    }

    if (open) {
      fetchData()
      if (mode === 'create') {
        generateCode()
      } else if (initialData?.code) {
        setGeneratedCode(initialData.code)
      }
    }
  }, [open, mode, initialData])

  const generateCode = () => {
    const year = new Date().getFullYear()
    const seq = Math.floor(Math.random() * 9999) + 1
    const code = `PR-${year}-${seq.toString().padStart(4, '0')}`
    setGeneratedCode(code)
  }

  const handleSubmit = async (data: PropertyFormData) => {
    setIsLoading(true)
    try {
      await onSubmit({ ...data, code: generatedCode })
      form.reset()
      onOpenChange(false)
    } catch (error) {
      console.error('Form submission error:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleTypeAdded = (newType: PropertyType) => {
    setPropertyTypes(prev => [...prev, newType])
    form.setValue('typeId', newType.id)
    setTypeModalOpen(false)
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {mode === 'create' 
                ? (messages?.properties?.addProperty || 'Add Property')
                : (messages?.properties?.editProperty || 'Edit Property')
              }
            </DialogTitle>
            <DialogDescription>
              {mode === 'create'
                ? 'Add a new property to your inventory.'
                : 'Update the property information.'
              }
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              {/* Property Code */}
              <div className="flex items-center gap-2">
                <div className="flex-1">
                  <label className="text-sm font-medium">Property Code</label>
                  <div className="flex items-center gap-2 mt-1">
                    <Input value={generatedCode} disabled className="flex-1" />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={generateCode}
                      disabled={isLoading || mode === 'edit'}
                    >
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="typeId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{messages?.properties?.type || 'Type'} *</FormLabel>
                      <div className="flex gap-2">
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger className="flex-1">
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {propertyTypes.map((type) => (
                              <SelectItem key={type.id} value={type.id}>
                                {type.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setTypeModalOpen(true)}
                          disabled={isLoading}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="statusId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{messages?.common?.status || 'Status'} *</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {propertyStatuses.map((status) => (
                            <SelectItem key={status.id} value={status.id}>
                              {status.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{messages?.properties?.city || 'City'} *</FormLabel>
                      <FormControl>
                        <Input {...field} disabled={isLoading} placeholder="مثال: القاهرة" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="area"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{messages?.properties?.area || 'Area'}</FormLabel>
                      <FormControl>
                        <Input {...field} disabled={isLoading} placeholder="مثال: مدينة نصر" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{messages?.properties?.address || 'Address'}</FormLabel>
                    <FormControl>
                      <Input {...field} disabled={isLoading} placeholder="العنوان كاملاً" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="bedrooms"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{messages?.properties?.bedrooms || 'Bedrooms'}</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="number" 
                          min="0"
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                          disabled={isLoading} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="bathrooms"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{messages?.properties?.bathrooms || 'Bathrooms'}</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="number" 
                          min="0"
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                          disabled={isLoading} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="sizeSqm"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{messages?.properties?.sizeSqm || 'Size (sqm)'}</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="number" 
                          min="0"
                          step="0.1"
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          disabled={isLoading} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{messages?.properties?.price || 'Price'}</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="number" 
                          min="0"
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          disabled={isLoading} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="currency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Currency</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Currency" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="EGP">جنيه مصري</SelectItem>
                          <SelectItem value="USD">USD</SelectItem>
                          <SelectItem value="EUR">EUR</SelectItem>
                          <SelectItem value="AED">AED</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="ownerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Owner</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select owner" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {owners.map((owner) => (
                            <SelectItem key={owner.id} value={owner.id}>
                              {owner.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => onOpenChange(false)}
                  disabled={isLoading}
                >
                  {messages?.common?.cancel || 'Cancel'}
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading 
                    ? (messages?.common?.loading || 'Loading...') 
                    : (messages?.common?.save || 'Save')
                  }
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <AddPropertyTypeModal
        open={typeModalOpen}
        onOpenChange={setTypeModalOpen}
        onTypeAdded={handleTypeAdded}
      />
    </>
  )
}