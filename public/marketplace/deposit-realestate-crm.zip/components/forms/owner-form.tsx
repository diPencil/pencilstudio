'use client'

import { useState } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useLocale } from '@/components/providers/locale-provider'

const ownerSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  phone: z.string().optional(),
  email: z.string().email().optional().or(z.literal('')),
  company: z.string().optional(),
  nationalId: z.string().optional(),
  preferredContact: z.enum(['call', 'whatsapp', 'email']).optional(),
  payoutDetails: z.string().optional(),
  notes: z.string().optional(),
})

type OwnerFormData = z.infer<typeof ownerSchema>

interface OwnerFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubmit: (data: OwnerFormData) => Promise<void>
  initialData?: Partial<OwnerFormData>
  mode?: 'create' | 'edit'
}

export function OwnerForm({
  open,
  onOpenChange,
  onSubmit,
  initialData,
  mode = 'create'
}: OwnerFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const { messages } = useLocale()

  const form = useForm<OwnerFormData>({
    resolver: zodResolver(ownerSchema),
    defaultValues: {
      name: initialData?.name || undefined,
      phone: initialData?.phone || undefined,
      email: initialData?.email || undefined,
      company: initialData?.company || undefined,
      nationalId: initialData?.nationalId || undefined,
      preferredContact: initialData?.preferredContact || undefined,
      payoutDetails: initialData?.payoutDetails || undefined,
      notes: initialData?.notes || undefined,
    },
  })

  const handleSubmit = async (data: OwnerFormData) => {
    setIsLoading(true)
    try {
      await onSubmit(data)
      form.reset()
      onOpenChange(false)
    } catch (error) {
      console.error('Form submission error:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {mode === 'create' ? 'Add Owner' : 'Edit Owner'}
          </DialogTitle>
          <DialogDescription>
            {mode === 'create'
              ? 'Add a new property owner to the system.'
              : 'Update the owner information.'
            }
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name *</FormLabel>
                  <FormControl>
                    <Input {...field} disabled={isLoading} placeholder="Enter owner's full name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone</FormLabel>
                    <FormControl>
                      <Input {...field} disabled={isLoading} placeholder="+971 50 123 4567" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input {...field} type="email" disabled={isLoading} placeholder="owner@example.com" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="company"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Company</FormLabel>
                    <FormControl>
                      <Input {...field} disabled={isLoading} placeholder="Company name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="nationalId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>National ID / Tax ID</FormLabel>
                    <FormControl>
                      <Input {...field} disabled={isLoading} placeholder="ID number" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="preferredContact"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Preferred Contact Method</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select preferred contact method" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="call">Phone Call</SelectItem>
                      <SelectItem value="whatsapp">WhatsApp</SelectItem>
                      <SelectItem value="email">Email</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="payoutDetails"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Payout Details</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      disabled={isLoading} 
                      rows={2} 
                      placeholder="Bank account details, commission structure, etc."
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      disabled={isLoading} 
                      rows={3} 
                      placeholder="Additional notes about this owner..."
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={isLoading}
              >
                {messages?.common?.cancel || 'Cancel'}
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading 
                  ? (messages?.common?.loading || 'Loading...') 
                  : (messages?.common?.save || 'Save')
                }
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}