'use client'

import { useState, useEffect } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useLocale } from '@/components/providers/locale-provider'

const listingSchema = z.object({
  propertyId: z.string().min(1, 'Property is required'),
  channelId: z.string().min(1, 'Channel is required'),
  city: z.string().optional(),
  title: z.string().optional(),
  description: z.string().optional(),
  priceOverride: z.number().min(0).optional().or(z.literal('')),
  media: z.array(z.string()).optional(),
  url: z.string().optional(),
  status: z.enum(['Draft', 'Published', 'Paused', 'Ended']).default('Draft'),
})

type ListingFormData = z.infer<typeof listingSchema>

interface ListingFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubmit: (data: ListingFormData) => Promise<void>
  initialData?: Partial<ListingFormData>
  mode?: 'create' | 'edit'
}

interface Property {
  id: string
  code: string
  type: { name: string }
  city: string
  area?: string
  price?: number
}

interface Channel {
  id: string
  name: string
}

interface City {
  id: string
  name: string
}
export function ListingForm({
  open,
  onOpenChange,
  onSubmit,
  initialData,
  mode = 'create'
}: ListingFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [properties, setProperties] = useState<Property[]>([])
  const [channels, setChannels] = useState<Channel[]>([])
  const [cities, setCities] = useState<City[]>([])
  const { messages } = useLocale()

  const form = useForm<ListingFormData>({
    resolver: zodResolver(listingSchema),
    defaultValues: {
      propertyId: initialData?.propertyId || undefined,
      channelId: initialData?.channelId || undefined,
      city: initialData?.city || undefined,
      title: initialData?.title || undefined,
      description: initialData?.description || undefined,
      priceOverride: initialData?.priceOverride || undefined,
      media: initialData?.media || [],
      url: initialData?.url || undefined,
      status: initialData?.status || 'Draft',
    },
  })

  // Watch property selection to auto-generate title
  const selectedPropertyId = form.watch('propertyId')
  const selectedChannelId = form.watch('channelId')

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [propertiesRes, channelsRes, citiesRes] = await Promise.all([
          fetch('/api/properties'),
          fetch('/api/settings/listing-channels'),
          fetch('/api/settings/cities')
        ])
        
        if (propertiesRes.ok) {
          const propertiesData = await propertiesRes.json()
          setProperties(propertiesData.data || [])
        }
        
        if (channelsRes.ok) {
          const channelsData = await channelsRes.json()
          setChannels(channelsData)
        }
        
        if (citiesRes.ok) {
          const citiesData = await citiesRes.json()
          setCities(citiesData)
        }
      } catch (error) {
        console.error('Failed to fetch form data:', error)
      }
    }

    if (open) {
      fetchData()
    }
  }, [open])

  // Auto-generate title when property or channel changes
  useEffect(() => {
    if (selectedPropertyId && !form.getValues('title')) {
      const property = properties.find(p => p.id === selectedPropertyId)
      if (property) {
        const autoTitle = `${property.type.name} في ${property.city} - ${property.code}`
        form.setValue('title', autoTitle)
      }
    }
  }, [selectedPropertyId, properties, form])

  const handleSubmit = async (data: ListingFormData) => {
    setIsLoading(true)
    try {
      const submitData = {
        ...data,
        priceOverride: data.priceOverride ? Number(data.priceOverride) : undefined
      }
      await onSubmit(submitData)
      form.reset()
      onOpenChange(false)
    } catch (error) {
      console.error('Form submission error:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {mode === 'create' ? 'Create Listing' : 'Edit Listing'}
          </DialogTitle>
          <DialogDescription>
            {mode === 'create'
              ? 'Create a new property listing for marketing channels.'
              : 'Update the listing information.'
            }
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="propertyId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Property *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select property" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {properties.map((property) => (
                          <SelectItem key={property.id} value={property.id}>
                            {property.code} - {property.city}
                            {property.area && `, ${property.area}`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="channelId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Channel *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select channel" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {channels.map((channel) => (
                          <SelectItem key={channel.id} value={channel.id}>
                            {channel.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>City</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select city" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {cities.map((city) => (
                        <SelectItem key={city.id} value={city.name}>
                          {city.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input {...field} disabled={isLoading} placeholder="Auto-generated from property" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      disabled={isLoading} 
                      rows={4} 
                      placeholder="Detailed description of the property..."
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="priceOverride"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Price Override (EGP)</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="number" 
                        min="0"
                        onChange={(e) => field.onChange(e.target.value)}
                        disabled={isLoading} 
                        placeholder="Leave empty to use property price"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Draft">Draft</SelectItem>
                        <SelectItem value="Published">Published</SelectItem>
                        <SelectItem value="Paused">Paused</SelectItem>
                        <SelectItem value="Ended">Ended</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="url"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>External URL (Optional)</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      disabled={isLoading} 
                      placeholder="https://example.com/listing"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={isLoading}
              >
                {messages?.common?.cancel || 'Cancel'}
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading 
                  ? (messages?.common?.loading || 'Loading...') 
                  : (messages?.common?.save || 'Save')
                }
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}