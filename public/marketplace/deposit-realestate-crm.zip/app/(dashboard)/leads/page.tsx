'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { EmptyState } from '@/components/ui/empty-state'
import { LeadForm } from '@/components/forms/lead-form'
import { useLocale } from '@/components/providers/locale-provider'
import { Users, Plus, Edit, Trash2, Phone, Mail, MapPin, User } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { MoreHorizontal } from 'lucide-react'
import { LeadFormData } from '@/lib/validators/lead'

interface Lead {
  id: string
  fullName: string
  email?: string
  phone?: string
  stage: 'NEW' | 'CONTACTED' | 'QUALIFIED' | 'VIEWING' | 'OFFER' | 'WON' | 'LOST'
  source?: string
  assignee?: {
    id: string
    fullName: string
  }
  createdAt: string
}

interface LeadsData {
  data: Lead[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

export default function LeadsPage() {
  const { messages } = useLocale()
  const [leads, setLeads] = useState<LeadsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [formOpen, setFormOpen] = useState(false)
  const [editingLead, setEditingLead] = useState<Lead | null>(null)

  const fetchLeads = async () => {
    try {
      const response = await fetch('/api/leads')
      if (response.ok) {
        const data = await response.json()
        setLeads(data)
      }
    } catch (error) {
      console.error('Failed to fetch leads:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchLeads()
  }, [])

  const handleCreateLead = async (data: LeadFormData) => {
    try {
      const response = await fetch('/api/leads', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchLeads()
      }
    } catch (error) {
      console.error('Failed to create lead:', error)
    }
  }

  const handleEditLead = async (data: LeadFormData) => {
    if (!editingLead) return

    try {
      const response = await fetch(`/api/leads/${editingLead.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchLeads()
        setEditingLead(null)
      }
    } catch (error) {
      console.error('Failed to update lead:', error)
    }
  }

  const handleDeleteLead = async (id: string) => {
    if (!confirm('Are you sure you want to delete this lead?')) return

    try {
      const response = await fetch(`/api/leads/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        await fetchLeads()
      }
    } catch (error) {
      console.error('Failed to delete lead:', error)
    }
  }

  const getStageColor = (stage: string) => {
    const colors: Record<string, string> = {
      NEW: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      CONTACTED: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
      QUALIFIED: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300',
      VIEWING: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
      OFFER: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-300',
      WON: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      LOST: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
    }
    return colors[stage] || 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300'
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">
          {messages?.common?.loading || 'Loading...'}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">
            {messages?.leads?.title || 'Leads'}
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage your potential customers and track their journey
          </p>
        </div>
        <Button onClick={() => setFormOpen(true)} className="shadow-sm">
          <Plus className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
          {messages?.leads?.addLead || 'Add Lead'}
        </Button>
      </div>

      {/* Stats Cards */}
      {leads && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Leads</p>
                  <p className="text-2xl font-bold">{leads.pagination.total}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">New</p>
                  <p className="text-2xl font-bold">
                    {leads.data.filter(l => l.stage === 'NEW').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-purple-500 rounded-full" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Qualified</p>
                  <p className="text-2xl font-bold">
                    {leads.data.filter(l => l.stage === 'QUALIFIED').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Won</p>
                  <p className="text-2xl font-bold">
                    {leads.data.filter(l => l.stage === 'WON').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Leads Grid */}
      {leads?.data.length ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {leads.data.map((lead) => (
            <Card key={lead.id} className="hover:shadow-lg transition-all duration-200 border-l-4 border-l-primary/20">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-semibold">{lead.fullName}</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Badge className={getStageColor(lead.stage)}>
                      {messages?.leads?.stages?.[lead.stage] || lead.stage}
                    </Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setEditingLead(lead)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDeleteLead(lead.id)}
                          className="text-destructive"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {lead.email && (
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Mail className="h-4 w-4" />
                    <span className="truncate">{lead.email}</span>
                  </div>
                )}
                {lead.phone && (
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Phone className="h-4 w-4" />
                    <span>{lead.phone}</span>
                  </div>
                )}
                {lead.source && (
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span>{lead.source}</span>
                  </div>
                )}
                {lead.assignee && (
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <User className="h-4 w-4" />
                    <span>{lead.assignee.fullName}</span>
                  </div>
                )}
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground">
                    Created: {new Date(lead.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={<Users className="h-12 w-12" />}
          title="No leads found"
          description="Start by adding your first lead to the system."
          action={{
            label: messages?.leads?.addLead || 'Add Lead',
            onClick: () => setFormOpen(true),
          }}
        />
      )}

      {/* Forms */}
      <LeadForm
        open={formOpen}
        onOpenChange={setFormOpen}
        onSubmit={handleCreateLead}
        mode="create"
      />

      {editingLead && (
        <LeadForm
          open={!!editingLead}
          onOpenChange={(open) => !open && setEditingLead(null)}
          onSubmit={handleEditLead}
          initialData={editingLead}
          mode="edit"
        />
      )}
    </div>
  )
}