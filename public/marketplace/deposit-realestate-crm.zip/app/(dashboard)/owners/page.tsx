'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { EmptyState } from '@/components/ui/empty-state'
import { OwnerForm } from '@/components/forms/owner-form'
import { useLocale } from '@/components/providers/locale-provider'
import { UserCheck, Plus, Mail, Phone, Building, User, Edit, Trash2, MoreHorizontal } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

interface Owner {
  id: string
  name: string
  email?: string
  phone?: string
  notes?: string
  properties: Array<{
    id: string
    code: string
    type: {
      name: string
    }
    city: string
    status: {
      name: string
    }
  }>
  createdAt: string
}

interface OwnersData {
  data: Owner[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

export default function OwnersPage() {
  const { messages } = useLocale()
  const [owners, setOwners] = useState<OwnersData | null>(null)
  const [loading, setLoading] = useState(true)
  const [formOpen, setFormOpen] = useState(false)
  const [editingOwner, setEditingOwner] = useState<Owner | null>(null)

  const fetchOwners = async () => {
    try {
      const response = await fetch('/api/owners')
      if (response.ok) {
        const data = await response.json()
        setOwners(data)
      }
    } catch (error) {
      console.error('Failed to fetch owners:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchOwners()
  }, [])

  const handleCreateOwner = async (data: any) => {
    try {
      const response = await fetch('/api/owners', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchOwners()
      }
    } catch (error) {
      console.error('Failed to create owner:', error)
    }
  }

  const handleEditOwner = async (data: any) => {
    if (!editingOwner) return

    try {
      const response = await fetch(`/api/owners/${editingOwner.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchOwners()
        setEditingOwner(null)
      }
    } catch (error) {
      console.error('Failed to update owner:', error)
    }
  }

  const handleDeleteOwner = async (id: string) => {
    if (!confirm('Are you sure you want to delete this owner?')) return

    try {
      const response = await fetch(`/api/owners/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        await fetchOwners()
      }
    } catch (error) {
      console.error('Failed to delete owner:', error)
    }
  }

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      Available: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      'Under Offer': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
      Sold: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
      Rented: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      Reserved: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300',
    }
    return colors[status] || 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300'
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">
          {messages?.common?.loading || 'Loading...'}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Owners</h1>
          <p className="text-muted-foreground mt-1">
            Manage property owners and their portfolios
          </p>
        </div>
        <Button onClick={() => setFormOpen(true)} className="shadow-sm">
          <Plus className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
          Add Owner
        </Button>
      </div>

      {/* Stats Cards */}
      {owners && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <UserCheck className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Owners</p>
                  <p className="text-2xl font-bold">{owners.pagination.total}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Building className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Properties</p>
                  <p className="text-2xl font-bold">
                    {owners.data.reduce((sum, owner) => sum + owner.properties.length, 0)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Mail className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">With Email</p>
                  <p className="text-2xl font-bold">
                    {owners.data.filter(o => o.email).length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Phone className="h-5 w-5 text-orange-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">With Phone</p>
                  <p className="text-2xl font-bold">
                    {owners.data.filter(o => o.phone).length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Owners Grid */}
      {owners?.data.length ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {owners.data.map((owner) => (
            <Card key={owner.id} className="hover:shadow-lg transition-all duration-200 border-l-4 border-l-primary/20">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-semibold flex items-center space-x-2">
                    <User className="h-5 w-5" />
                    <span>{owner.name}</span>
                  </CardTitle>
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline">
                      {owner.properties.length} Properties
                    </Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setEditingOwner(owner)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDeleteOwner(owner.id)}
                          className="text-destructive"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {owner.email && (
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Mail className="h-4 w-4" />
                    <span className="truncate">{owner.email}</span>
                  </div>
                )}
                
                {owner.phone && (
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Phone className="h-4 w-4" />
                    <span>{owner.phone}</span>
                  </div>
                )}
                
                {owner.notes && (
                  <div className="text-sm text-muted-foreground bg-muted/50 p-2 rounded">
                    {owner.notes}
                  </div>
                )}
                
                {/* Properties List */}
                {owner.properties.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Properties:</h4>
                    <div className="space-y-1">
                      {owner.properties.slice(0, 3).map((property) => (
                        <div key={property.id} className="flex items-center justify-between text-xs">
                          <span className="flex items-center space-x-1">
                            <Building className="h-3 w-3" />
                            <span>{property.code} - {property.city}</span>
                          </span>
                          <Badge className={getStatusColor(property.status?.name || 'Available')}>
                            {property.status?.name || 'Available'}
                          </Badge>
                        </div>
                      ))}
                      {owner.properties.length > 3 && (
                        <div className="text-xs text-muted-foreground">
                          +{owner.properties.length - 3} more properties
                        </div>
                      )}
                    </div>
                  </div>
                )}
                
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground">
                    Added: {new Date(owner.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={<UserCheck className="h-12 w-12" />}
          title="No owners found"
          description="Start by adding property owners to manage their portfolios."
          action={{
            label: 'Add Owner',
            onClick: () => setFormOpen(true),
          }}
        />
      )}

      {/* Forms */}
      <OwnerForm
        open={formOpen}
        onOpenChange={setFormOpen}
        onSubmit={handleCreateOwner}
        mode="create"
      />

      {editingOwner && (
        <OwnerForm
          open={!!editingOwner}
          onOpenChange={(open) => !open && setEditingOwner(null)}
          onSubmit={handleEditOwner}
          initialData={editingOwner}
          mode="edit"
        />
      )}
    </div>
  )
}