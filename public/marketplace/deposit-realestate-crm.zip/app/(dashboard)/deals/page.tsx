'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { EmptyState } from '@/components/ui/empty-state'
import { DealForm } from '@/components/forms/deal-form'
import { useLocale } from '@/components/providers/locale-provider'
import { HeartHandshake, Plus, DollarSign, TrendingUp, Calendar, User, Edit, Trash2, MoreHorizontal } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

interface Deal {
  id: string
  title: string
  value?: number
  stageId: string
  probability?: number
  expectedCloseDate?: string
  nextStep?: string
  notes?: string
  lead: {
    id: string
    fullName: string
    email?: string
    phone?: string
  }
  property?: {
    id: string
    code: string
    type: { name: string }
    city: string
  }
  stage: {
    id: string
    name: string
    color: string
    probability: number
  }
  assignee?: {
    id: string
    fullName: string
  }
  createdAt: string
}

interface DealsData {
  data: Deal[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

export default function DealsPage() {
  const { messages } = useLocale()
  const [deals, setDeals] = useState<DealsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [formOpen, setFormOpen] = useState(false)
  const [editingDeal, setEditingDeal] = useState<Deal | null>(null)

  const fetchDeals = async () => {
    try {
      const response = await fetch('/api/deals')
      if (response.ok) {
        const data = await response.json()
        setDeals(data)
      }
    } catch (error) {
      console.error('Failed to fetch deals:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchDeals()
  }, [])

  const handleCreateDeal = async (data: any) => {
    try {
      const response = await fetch('/api/deals', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchDeals()
      }
    } catch (error) {
      console.error('Failed to create deal:', error)
    }
  }

  const handleEditDeal = async (data: any) => {
    if (!editingDeal) return

    try {
      const response = await fetch(`/api/deals/${editingDeal.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchDeals()
        setEditingDeal(null)
      }
    } catch (error) {
      console.error('Failed to update deal:', error)
    }
  }

  const handleDeleteDeal = async (id: string) => {
    if (!confirm('Are you sure you want to delete this deal?')) return

    try {
      const response = await fetch(`/api/deals/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        await fetchDeals()
      }
    } catch (error) {
      console.error('Failed to delete deal:', error)
    }
  }

  const getProbabilityColor = (probability?: number) => {
    if (!probability) return 'text-gray-500'
    if (probability >= 75) return 'text-green-600'
    if (probability >= 50) return 'text-yellow-600'
    return 'text-red-600'
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">
          {messages?.common?.loading || 'Loading...'}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Deals</h1>
          <p className="text-muted-foreground mt-1">
            Track your sales pipeline and close more deals
          </p>
        </div>
        <Button onClick={() => setFormOpen(true)} className="shadow-sm">
          <Plus className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
          Add Deal
        </Button>
      </div>

      {/* Stats Cards */}
      {deals && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <HeartHandshake className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Deals</p>
                  <p className="text-2xl font-bold">{deals.pagination.total}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <DollarSign className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Value</p>
                  <p className="text-2xl font-bold">
                    ${deals.data.reduce((sum, deal) => sum + (deal.value || 0), 0).toLocaleString()}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Won Deals</p>
                  <p className="text-2xl font-bold">
                    {deals.data.filter(d => d.stage?.name === 'Closed Won').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-yellow-500 rounded-full" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">In Progress</p>
                  <p className="text-2xl font-bold">
                    {deals.data.filter(d => d.stage && !['Closed Won', 'Closed Lost'].includes(d.stage.name)).length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Deals Grid */}
      {deals?.data.length ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {deals.data.map((deal) => (
            <Card key={deal.id} className="hover:shadow-lg transition-all duration-200 border-l-4 border-l-primary/20">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-semibold">{deal.title}</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Badge 
                      className="text-white"
                      style={{ backgroundColor: deal.stage?.color }}
                    >
                      {deal.stage?.name}
                    </Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setEditingDeal(deal)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDeleteDeal(deal.id)}
                          className="text-destructive"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
                {deal.value && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Deal Value</span>
                    <span className="font-bold text-lg text-primary">
                      ${deal.value.toLocaleString()}
                    </span>
                  </div>
                )}
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <User className="h-4 w-4" />
                  <span>{deal.lead.fullName}</span>
                  {deal.lead.phone && <span>• {deal.lead.phone}</span>}
                </div>
                
                {deal.property && (
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <span>🏠 {deal.property.code} - {deal.property.city}</span>
                  </div>
                )}
                
                {deal.assignee && (
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <span>👤 {deal.assignee.fullName}</span>
                  </div>
                )}
                
                {deal.probability !== undefined && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Success Probability</span>
                    <span className={`font-semibold ${getProbabilityColor(deal.probability)}`}>
                      {deal.probability}%
                    </span>
                  </div>
                )}
                
                {deal.expectedCloseDate && (
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    <span>Expected: {new Date(deal.expectedCloseDate).toLocaleDateString()}</span>
                  </div>
                )}
                
                {deal.nextStep && (
                  <div className="text-sm bg-blue-50 dark:bg-blue-900/20 p-2 rounded">
                    <span className="font-medium">Next: </span>
                    {deal.nextStep}
                  </div>
                )}
                
                {deal.notes && (
                  <div className="text-sm text-muted-foreground bg-muted/50 p-2 rounded">
                    {deal.notes}
                  </div>
                )}
                
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground">
                    Created: {new Date(deal.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={<HeartHandshake className="h-12 w-12" />}
          title="No deals found"
          description="Start by creating your first deal to track your sales pipeline."
          action={{
            label: 'Add Deal',
            onClick: () => setFormOpen(true),
          }}
        />
      )}

      {/* Forms */}
      <DealForm
        open={formOpen}
        onOpenChange={setFormOpen}
        onSubmit={handleCreateDeal}
        mode="create"
      />

      {editingDeal && (
        <DealForm
          open={!!editingDeal}
          onOpenChange={(open) => !open && setEditingDeal(null)}
          onSubmit={handleEditDeal}
          initialData={editingDeal}
          mode="edit"
        />
      )}
    </div>
  )
}