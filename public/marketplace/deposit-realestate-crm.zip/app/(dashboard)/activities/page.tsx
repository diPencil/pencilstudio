'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { EmptyState } from '@/components/ui/empty-state'
import { ActivityForm } from '@/components/forms/activity-form'
import { useLocale } from '@/components/providers/locale-provider'
import { Activity, Plus, Phone, Mail, MessageCircle, Users, Calendar, User, Edit, Trash2, MoreHorizontal, Filter } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface ActivityItem {
  id: string
  type: string
  direction?: 'inbound' | 'outbound'
  duration?: number
  outcome?: 'connected' | 'interested' | 'completed' | 'no_answer' | 'rescheduled' | 'not_interested'
  notes?: string
  at: string
  lead?: {
    id: string
    fullName: string
  }
  deal?: {
    id: string
    title: string
  }
  property?: {
    id: string
    code: string
    city: string
  }
  owner?: {
    id: string
    name: string
  }
  user: {
    id: string
    fullName: string
  }
}

interface ActivitiesData {
  data: ActivityItem[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

export default function ActivitiesPage() {
  const { messages } = useLocale()
  const [activities, setActivities] = useState<ActivitiesData | null>(null)
  const [loading, setLoading] = useState(true)
  const [formOpen, setFormOpen] = useState(false)
  const [editingActivity, setEditingActivity] = useState<ActivityItem | null>(null)
  const [filters, setFilters] = useState({
    type: ''
  })

  const fetchActivities = async () => {
    try {
      const params = new URLSearchParams()
      if (filters.type && filters.type !== 'all') params.append('type', filters.type)
      
      const response = await fetch(`/api/activities?${params.toString()}`)
      if (response.ok) {
        const data = await response.json()
        setActivities(data)
      }
    } catch (error) {
      console.error('Failed to fetch activities:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchActivities()
  }, [filters])

  const handleCreateActivity = async (data: any) => {
    try {
      const response = await fetch('/api/activities', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchActivities()
      }
    } catch (error) {
      console.error('Failed to create activity:', error)
    }
  }

  const handleEditActivity = async (data: any) => {
    if (!editingActivity) return

    try {
      const response = await fetch(`/api/activities/${editingActivity.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchActivities()
        setEditingActivity(null)
      }
    } catch (error) {
      console.error('Failed to update activity:', error)
    }
  }

  const handleDeleteActivity = async (id: string) => {
    if (!confirm('Are you sure you want to delete this activity?')) return

    try {
      const response = await fetch(`/api/activities/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        await fetchActivities()
      }
    } catch (error) {
      console.error('Failed to delete activity:', error)
    }
  }

  const getActivityIcon = (type: string) => {
    const icons: Record<string, React.ReactNode> = {
      call: <Phone className="h-4 w-4" />,
      email: <Mail className="h-4 w-4" />,
      whatsapp: <MessageCircle className="h-4 w-4" />,
      meeting: <Users className="h-4 w-4" />,
      viewing: <Calendar className="h-4 w-4" />,
      note: <Activity className="h-4 w-4" />,
    }
    return icons[type] || <Activity className="h-4 w-4" />
  }

  const getActivityColor = (type: string) => {
    const colors: Record<string, string> = {
      call: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      email: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      whatsapp: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      meeting: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300',
      viewing: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
      note: 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300',
    }
    return colors[type] || 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300'
  }

  const getOutcomeColor = (outcome?: string) => {
    const colors: Record<string, string> = {
      connected: 'text-green-600',
      interested: 'text-green-600',
      completed: 'text-green-600',
      no_answer: 'text-yellow-600',
      rescheduled: 'text-yellow-600',
      not_interested: 'text-red-600',
    }
    return outcome ? colors[outcome] || 'text-gray-600' : 'text-gray-600'
  }
  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">
          {messages?.common?.loading || 'Loading...'}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Activities</h1>
          <p className="text-muted-foreground mt-1">
            Track all interactions with your leads and deals
          </p>
        </div>
        <Button onClick={() => setFormOpen(true)} className="shadow-sm">
          <Plus className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
          Log Activity
        </Button>
      </div>

      {/* Stats Cards */}
      {activities && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Activity className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Activities</p>
                  <p className="text-2xl font-bold">{activities.pagination.total}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Phone className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Calls</p>
                  <p className="text-2xl font-bold">
                    {activities.data.filter(a => a.type === 'call').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Mail className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Emails</p>
                  <p className="text-2xl font-bold">
                    {activities.data.filter(a => a.type === 'email').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-orange-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Meetings</p>
                  <p className="text-2xl font-bold">
                    {activities.data.filter(a => a.type === 'meeting').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filter Activities
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Activity Type</label>
              <Select value={filters.type} onValueChange={(value) => setFilters(prev => ({ ...prev, type: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="call">Call</SelectItem>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="whatsapp">WhatsApp</SelectItem>
                  <SelectItem value="meeting">Meeting</SelectItem>
                  <SelectItem value="viewing">Viewing</SelectItem>
                  <SelectItem value="note">Note</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Activities Timeline */}
      {activities?.data.length ? (
        <Card>
          <CardHeader>
            <CardTitle>Activity Timeline</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activities.data.map((activity, index) => (
                <div key={activity.id} className="flex items-start space-x-4 pb-4 border-b last:border-b-0 hover:bg-muted/50 p-3 rounded-lg transition-colors">
                  <div className={`p-2 rounded-full ${getActivityColor(activity.type).split(' ')[0]} flex items-center justify-center`}>
                    {getActivityIcon(activity.type)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Badge className={getActivityColor(activity.type)}>
                          {activity.type.charAt(0).toUpperCase() + activity.type.slice(1)}
                        </Badge>
                        {activity.direction && (
                          <Badge variant="outline">
                            {activity.direction}
                          </Badge>
                        )}
                        {activity.outcome && (
                          <Badge variant="outline" className={getOutcomeColor(activity.outcome)}>
                            {activity.outcome.replace('_', ' ')}
                          </Badge>
                        )}
                        <span className="text-sm text-muted-foreground">
                          {new Date(activity.at).toLocaleString()}
                        </span>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => setEditingActivity(activity)}>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => handleDeleteActivity(activity.id)}
                            className="text-destructive"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    
                    <div className="mt-1">
                      {activity.duration && (
                        <p className="text-sm text-muted-foreground">Duration: {activity.duration} minutes</p>
                      )}
                      
                      {activity.notes && (
                        <p className="text-sm text-foreground mt-1">{activity.notes}</p>
                      )}
                      
                      <div className="flex items-center space-x-4 mt-2 text-sm text-muted-foreground">
                        {activity.lead && (
                          <div className="flex items-center space-x-1">
                            <User className="h-3 w-3" />
                            <span>{activity.lead.fullName}</span>
                          </div>
                        )}
                        
                        {activity.owner && (
                          <div className="flex items-center space-x-1">
                            <span>👤 {activity.owner.name}</span>
                          </div>
                        )}
                        
                        {activity.deal && (
                          <div className="flex items-center space-x-1">
                            <span>💼 {activity.deal.title}</span>
                          </div>
                        )}
                        
                        {activity.property && (
                          <div className="flex items-center space-x-1">
                            <span>🏠 {activity.property.code} - {activity.property.city}</span>
                          </div>
                        )}
                        
                        <div className="flex items-center space-x-1">
                          <span>👤 {activity.user.fullName}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ) : (
        <EmptyState
          icon={<Activity className="h-12 w-12" />}
          title="No activities found"
          description="Start logging your interactions with leads and deals to track your progress."
          action={{
            label: 'Log Activity',
            onClick: () => setFormOpen(true),
          }}
        />
      )}

      {/* Forms */}
      <ActivityForm
        open={formOpen}
        onOpenChange={setFormOpen}
        onSubmit={handleCreateActivity}
        mode="create"
      />

      {editingActivity && (
        <ActivityForm
          open={!!editingActivity}
          onOpenChange={(open) => !open && setEditingActivity(null)}
          onSubmit={handleEditActivity}
          initialData={editingActivity}
          mode="edit"
        />
      )}
    </div>
  )
}