'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useLocale } from '@/components/providers/locale-provider'
import { Settings, Plus, Edit, Trash2, Users, Database, Palette, Globe } from 'lucide-react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { AddSourceModal } from '@/components/modals/add-source-modal'
import { AddLeadTypeModal } from '@/components/modals/add-lead-type-modal'
import { AddPropertyTypeModal } from '@/components/modals/add-property-type-modal'
import { AddDealStageModal } from '@/components/modals/add-deal-stage-modal'
import { AddActivityTypeModal } from '@/components/modals/add-activity-type-modal'
import { AddListingChannelModal } from '@/components/modals/add-listing-channel-modal'
import { UserManagementModal } from '@/components/modals/user-management-modal'
import { PipelineManagementModal } from '@/components/modals/pipeline-management-modal'
import { SystemSettingsModal } from '@/components/modals/system-settings-modal'

interface SettingsItem {
  id: string
  name: string
  channel?: string
  color?: string
  isActive: boolean
  createdAt: string
}

export default function SettingsPage() {
  const { messages } = useLocale()
  const [leadSources, setLeadSources] = useState<SettingsItem[]>([])
  const [leadTypes, setLeadTypes] = useState<SettingsItem[]>([])
  const [propertyTypes, setPropertyTypes] = useState<SettingsItem[]>([])
  const [dealStages, setDealStages] = useState<SettingsItem[]>([])
  const [activityTypes, setActivityTypes] = useState<SettingsItem[]>([])
  const [listingChannels, setListingChannels] = useState<SettingsItem[]>([])
  const [cities, setCities] = useState<SettingsItem[]>([])
  const [loading, setLoading] = useState(true)
  
  // Modal states
  const [sourceModalOpen, setSourceModalOpen] = useState(false)
  const [leadTypeModalOpen, setLeadTypeModalOpen] = useState(false)
  const [propertyTypeModalOpen, setPropertyTypeModalOpen] = useState(false)
  const [dealStageModalOpen, setDealStageModalOpen] = useState(false)
  const [activityTypeModalOpen, setActivityTypeModalOpen] = useState(false)
  const [listingChannelModalOpen, setListingChannelModalOpen] = useState(false)
  const [userManagementModalOpen, setUserManagementModalOpen] = useState(false)
  const [pipelineModalOpen, setPipelineModalOpen] = useState(false)
  const [systemModalOpen, setSystemModalOpen] = useState(false)

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const [sourcesRes, leadTypesRes, propTypesRes, stagesRes, actTypesRes, channelsRes, citiesRes] = await Promise.all([
          fetch('/api/settings/sources'),
          fetch('/api/settings/lead-types'),
          fetch('/api/settings/property-types'),
          fetch('/api/settings/deal-stages'),
          fetch('/api/settings/activity-types'),
          fetch('/api/settings/listing-channels'),
          fetch('/api/settings/cities')
        ])

        if (sourcesRes.ok) {
          const sources = await sourcesRes.json()
          setLeadSources(sources)
        }

        if (leadTypesRes.ok) {
          const types = await leadTypesRes.json()
          setLeadTypes(types)
        }

        if (propTypesRes.ok) {
          const types = await propTypesRes.json()
          setPropertyTypes(types)
        }
        
        if (stagesRes.ok) {
          const stages = await stagesRes.json()
          setDealStages(stages)
        }
        
        if (actTypesRes.ok) {
          const types = await actTypesRes.json()
          setActivityTypes(types)
        }
        
        if (channelsRes.ok) {
          const channels = await channelsRes.json()
          setListingChannels(channels)
        }
        
        if (citiesRes.ok) {
          const cities = await citiesRes.json()
          setCities(cities)
        }
      } catch (error) {
        console.error('Failed to fetch settings:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchSettings()
  }, [])

  const handleSourceAdded = (newSource: SettingsItem) => {
    setLeadSources(prev => [...prev, newSource])
    setSourceModalOpen(false)
  }

  const handleLeadTypeAdded = (newType: SettingsItem) => {
    setLeadTypes(prev => [...prev, newType])
    setLeadTypeModalOpen(false)
  }

  const handlePropertyTypeAdded = (newType: SettingsItem) => {
    setPropertyTypes(prev => [...prev, newType])
    setPropertyTypeModalOpen(false)
  }

  const handleDealStageAdded = (newStage: SettingsItem) => {
    setDealStages(prev => [...prev, newStage])
    setDealStageModalOpen(false)
  }

  const handleActivityTypeAdded = (newType: SettingsItem) => {
    setActivityTypes(prev => [...prev, newType])
    setActivityTypeModalOpen(false)
  }

  const handleListingChannelAdded = (newChannel: SettingsItem) => {
    setListingChannels(prev => [...prev, newChannel])
    setListingChannelModalOpen(false)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">Loading settings...</div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">
            {messages?.settings?.title || 'Settings'}
          </h1>
          <p className="text-muted-foreground mt-1">
            {messages?.settings?.description || 'Manage your CRM system configuration and preferences'}
          </p>
        </div>
      </div>

      <Tabs defaultValue="lookups" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="lookups" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            {messages?.settings?.lookups || 'Lookups'}
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            {messages?.settings?.users || 'Users & Roles'}
          </TabsTrigger>
          <TabsTrigger value="pipelines" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            {messages?.settings?.pipelines || 'Pipelines'}
          </TabsTrigger>
          <TabsTrigger value="branding" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Branding
          </TabsTrigger>
        </TabsList>

        <TabsList className="grid w-full grid-cols-1 mt-2">
          <TabsTrigger value="system" className="flex items-center gap-2">
            <Globe className="h-4 w-4" />
            {messages?.settings?.system || 'System'}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="lookups" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Lead Sources */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-lg font-semibold">
                  {messages?.settings?.leadSources || 'Lead Sources'}
                </CardTitle>
                <Button size="sm" variant="outline" onClick={() => setSourceModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  {messages?.common?.add || 'Add'}
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {leadSources.slice(0, 5).map((source) => (
                    <div key={source.id} className="flex items-center justify-between p-2 rounded border">
                      <div>
                        <p className="font-medium">{source.name}</p>
                        {source.channel && (
                          <p className="text-sm text-muted-foreground">{source.channel}</p>
                        )}
                      </div>
                      <Badge variant={source.isActive ? 'default' : 'secondary'}>
                        {source.isActive ? (messages?.settings?.active || 'Active') : (messages?.settings?.inactive || 'Inactive')}
                      </Badge>
                    </div>
                  ))}
                  {leadSources.length > 5 && (
                    <p className="text-sm text-muted-foreground text-center pt-2">
                      +{leadSources.length - 5} {messages?.settings?.additionalItems || 'additional items'}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Lead Types */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-lg font-semibold">
                  {messages?.settings?.leadTypes || 'Lead Types'}
                </CardTitle>
                <Button size="sm" variant="outline" onClick={() => setLeadTypeModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  {messages?.common?.add || 'Add'}
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {leadTypes.slice(0, 5).map((type) => (
                    <div key={type.id} className="flex items-center justify-between p-2 rounded border">
                      <p className="font-medium">{type.name}</p>
                      <Badge variant={type.isActive ? 'default' : 'secondary'}>
                        {type.isActive ? (messages?.settings?.active || 'Active') : (messages?.settings?.inactive || 'Inactive')}
                      </Badge>
                    </div>
                  ))}
                  {leadTypes.length > 5 && (
                    <p className="text-sm text-muted-foreground text-center pt-2">
                      +{leadTypes.length - 5} {messages?.settings?.additionalItems || 'additional items'}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Property Types */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-lg font-semibold">
                  {messages?.settings?.propertyTypes || 'Property Types'}
                </CardTitle>
                <Button size="sm" variant="outline" onClick={() => setPropertyTypeModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  {messages?.common?.add || 'Add'}
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {propertyTypes.slice(0, 5).map((type) => (
                    <div key={type.id} className="flex items-center justify-between p-2 rounded border">
                      <p className="font-medium">{type.name}</p>
                      <Badge variant={type.isActive ? 'default' : 'secondary'}>
                        {type.isActive ? (messages?.settings?.active || 'Active') : (messages?.settings?.inactive || 'Inactive')}
                      </Badge>
                    </div>
                  ))}
                  {propertyTypes.length > 5 && (
                    <p className="text-sm text-muted-foreground text-center pt-2">
                      +{propertyTypes.length - 5} {messages?.settings?.additionalItems || 'additional items'}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {/* Deal Stages */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-lg font-semibold">
                  {messages?.settings?.dealStages || 'Deal Stages'}
                </CardTitle>
                <Button size="sm" variant="outline" onClick={() => setDealStageModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  {messages?.common?.add || 'Add'}
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {dealStages.slice(0, 5).map((stage) => (
                    <div key={stage.id} className="flex items-center justify-between p-2 rounded border">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: stage.color || '#3b82f6' }} />
                        <p className="font-medium">{stage.name}</p>
                      </div>
                      <Badge variant={stage.isActive ? 'default' : 'secondary'}>
                        {stage.isActive ? (messages?.settings?.active || 'Active') : (messages?.settings?.inactive || 'Inactive')}
                      </Badge>
                    </div>
                  ))}
                  {dealStages.length > 5 && (
                    <p className="text-sm text-muted-foreground text-center pt-2">
                      +{dealStages.length - 5} {messages?.settings?.additionalItems || 'additional items'}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {/* Activity Types */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-lg font-semibold">
                  {messages?.settings?.activityTypes || 'Activity Types'}
                </CardTitle>
                <Button size="sm" variant="outline" onClick={() => setActivityTypeModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  {messages?.common?.add || 'Add'}
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {activityTypes.slice(0, 5).map((type) => (
                    <div key={type.id} className="flex items-center justify-between p-2 rounded border">
                      <p className="font-medium">{type.name}</p>
                      <Badge variant={type.isActive ? 'default' : 'secondary'}>
                        {type.isActive ? (messages?.settings?.active || 'Active') : (messages?.settings?.inactive || 'Inactive')}
                      </Badge>
                    </div>
                  ))}
                  {activityTypes.length > 5 && (
                    <p className="text-sm text-muted-foreground text-center pt-2">
                      +{activityTypes.length - 5} {messages?.settings?.additionalItems || 'additional items'}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {/* Listing Channels */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-lg font-semibold">
                  {messages?.settings?.listingChannels || 'Listing Channels'}
                </CardTitle>
                <Button size="sm" variant="outline" onClick={() => setListingChannelModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  {messages?.common?.add || 'Add'}
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {listingChannels.slice(0, 5).map((channel) => (
                    <div key={channel.id} className="flex items-center justify-between p-2 rounded border">
                      <p className="font-medium">{channel.name}</p>
                      <Badge variant={channel.isActive ? 'default' : 'secondary'}>
                        {channel.isActive ? (messages?.settings?.active || 'Active') : (messages?.settings?.inactive || 'Inactive')}
                      </Badge>
                    </div>
                  ))}
                  {listingChannels.length > 5 && (
                    <p className="text-sm text-muted-foreground text-center pt-2">
                      +{listingChannels.length - 5} {messages?.settings?.additionalItems || 'additional items'}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Additional Settings Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Settings className="h-4 w-4 text-orange-600" />
                </div>
                <div>
                  <p className="font-medium">{messages?.settings?.cities || 'Cities'}</p>
                  <p className="text-sm text-muted-foreground">{cities.length} cities</p>
                </div>
              </div>
            </Card>
            
            <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <Settings className="h-4 w-4 text-indigo-600" />
                </div>
                <div>
                  <p className="font-medium">{messages?.settings?.automations || 'Automations'}</p>
                  <p className="text-sm text-muted-foreground">5 rules enabled</p>
                </div>
              </div>
            </Card>
            
            <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-pink-100 rounded-lg flex items-center justify-center">
                  <Settings className="h-4 w-4 text-pink-600" />
                </div>
                <div>
                  <p className="font-medium">{messages?.settings?.notifications || 'Notifications'}</p>
                  <p className="text-sm text-muted-foreground">Email & WhatsApp</p>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="users" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{messages?.settings?.userRoleManagement || 'User and Role Management'}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">{messages?.settings?.userManagement || 'User Management'}</h3>
                <p className="text-muted-foreground mb-4">
                  {messages?.settings?.userRoleDescription || 'Manage users, roles and permissions for your CRM system'}
                </p>
                <Button onClick={() => setUserManagementModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  {messages?.settings?.manageUsers || 'Manage Users'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pipelines" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{messages?.settings?.dealStageSettings || 'Deal Stage Settings'}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Palette className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">{messages?.settings?.pipelineManagement || 'Pipeline Management'}</h3>
                <p className="text-muted-foreground mb-4">
                  {messages?.settings?.dealStageDescription || 'Customize deal stages, probabilities and automation rules'}
                </p>
                <Button onClick={() => setPipelineModalOpen(true)}>
                  <Edit className="h-4 w-4 mr-2" />
                  {messages?.settings?.manageStages || 'Manage Stages'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="branding" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Logo & System Name */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Logo & System Name
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Current Logo</label>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
                      <Settings className="w-6 h-6 text-primary-foreground" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Deposit CRM</p>
                      <p className="text-xs text-muted-foreground">Default logo</p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">Upload New Logo</label>
                  <div className="flex items-center space-x-2">
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      id="logo-upload"
                      onChange={(e) => {
                        const file = e.target.files?.[0]
                        if (file) {
                          // Handle logo upload
                          console.log('Logo uploaded:', file.name)
                          alert('Logo uploaded successfully! (Demo)')
                        }
                      }}
                    />
                    <Button 
                      variant="outline" 
                      onClick={() => document.getElementById('logo-upload')?.click()}
                    >
                      Choose File
                    </Button>
                    <span className="text-sm text-muted-foreground">PNG, JPG up to 2MB</span>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">System Name</label>
                  <input
                    type="text"
                    defaultValue="Deposit CRM"
                    className="w-full px-3 py-2 border border-input rounded-md bg-background"
                    onChange={(e) => {
                      // Handle system name change
                      console.log('System name changed to:', e.target.value)
                    }}
                  />
                </div>
                
                <Button className="w-full">
                  Save Logo & Name
                </Button>
              </CardContent>
            </Card>

            {/* Color Theme */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Color Theme
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-3 block">Primary Color</label>
                  <div className="grid grid-cols-4 gap-3">
                    {[
                      { name: 'Blue', color: '#3b82f6', isDefault: true, key: 'Blue' },
                      { name: 'Green', color: '#10b981', key: 'Green' },
                      { name: 'Purple', color: '#8b5cf6', key: 'Purple' },
                      { name: 'Orange', color: '#f59e0b', key: 'Orange' },
                      { name: 'Red', color: '#ef4444', key: 'Red' },
                      { name: 'Pink', color: '#ec4899', key: 'Pink' },
                      { name: 'Indigo', color: '#6366f1', key: 'Indigo' },
                      { name: 'Teal', color: '#14b8a6', key: 'Teal' },
                    ].map((theme) => (
                      <button
                        key={theme.name}
                        className={`w-full h-12 rounded-lg border-2 transition-all hover:scale-105 ${
                          theme.isDefault ? 'border-primary ring-2 ring-primary/20' : 'border-gray-200 hover:border-gray-300'
                        }`}
                        style={{ backgroundColor: theme.color }}
                        onClick={() => {
                          // Apply theme color
                          document.documentElement.style.setProperty('--primary', theme.color)
                          console.log('Theme changed to:', theme.key)
                          alert(`${messages?.branding?.themeChangedTo || 'Theme changed to'} ${messages?.branding?.colors?.[theme.key] || theme.name}! (${messages?.common?.demo || 'Demo'})`)
                        }}
                        title={messages?.branding?.colors?.[theme.key] || theme.name}
                      >
                        <span className="text-white text-xs font-medium">{messages?.branding?.colors?.[theme.key] || theme.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">{messages?.branding?.customColor || 'Custom Color'}</label>
                  <div className="flex items-center space-x-2">
                    <input
                      type="color"
                      defaultValue="#3b82f6"
                      className="w-12 h-10 border border-input rounded cursor-pointer"
                      onChange={(e) => {
                        document.documentElement.style.setProperty('--primary', e.target.value)
                        console.log('Custom color applied:', e.target.value)
                        alert(`${messages?.branding?.customColorApplied || 'Custom color applied:'} ${e.target.value}`)
                      }}
                    />
                    <input
                      type="text"
                      defaultValue="#3b82f6"
                      className="flex-1 px-3 py-2 border border-input rounded-md bg-background"
                      placeholder="#3b82f6"
                      onChange={(e) => {
                        if (e.target.value.match(/^#[0-9A-F]{6}$/i)) {
                          document.documentElement.style.setProperty('--primary', e.target.value)
                        }
                      }}
                    />
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-3 block">{messages?.branding?.themeMode || 'Theme Mode'}</label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button 
                      variant="outline" 
                      className="h-20 flex flex-col space-y-2"
                      onClick={() => {
                        document.documentElement.classList.remove('dark')
                        console.log('Light theme applied')
                        alert(messages?.branding?.lightThemeApplied || 'Light theme applied')
                      }}
                    >
                      <div className="w-8 h-8 bg-white border-2 border-gray-300 rounded" />
                      <span>{messages?.branding?.light || 'Light'}</span>
                    </Button>
                    <Button 
                      variant="outline" 
                      className="h-20 flex flex-col space-y-2"
                      onClick={() => {
                        document.documentElement.classList.add('dark')
                        console.log('Dark theme applied')
                        alert(messages?.branding?.darkThemeApplied || 'Dark theme applied')
                      }}
                    >
                      <div className="w-8 h-8 bg-gray-800 border-2 border-gray-600 rounded" />
                      <span>{messages?.branding?.dark || 'Dark'}</span>
                    </Button>
                  </div>
                </div>
                
                <Button className="w-full" onClick={() => {
                  alert(messages?.branding?.colorThemeSaved || 'Color theme saved successfully!')
                }}>
                  {messages?.branding?.saveColorTheme || 'Save Color Theme'}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Preview Section */}
          <Card>
            <CardHeader>
              <CardTitle>{messages?.branding?.livePreview || 'Live Preview'}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 bg-muted/30">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                    <Settings className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">Deposit CRM</h3>
                    <p className="text-sm text-muted-foreground">{messages?.branding?.yourCustomizedCRM || 'Your customized CRM system'}</p>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <Button size="sm" className="bg-primary hover:bg-primary/90">{messages?.branding?.primaryButton || 'Primary Button'}</Button>
                  <Button size="sm" variant="outline">{messages?.branding?.secondaryButton || 'Secondary Button'}</Button>
                  <Button size="sm" variant="ghost">{messages?.branding?.ghostButton || 'Ghost Button'}</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="system" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setSystemModalOpen(true)}>
              <CardHeader>
                <CardTitle>{messages?.settings?.languageCurrency || 'Language & Currency'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium">{messages?.settings?.defaultLanguage || 'Default Language'}</label>
                  <p className="text-sm text-muted-foreground">{messages?.settings?.arabicDefault || 'Arabic'} / {messages?.settings?.english || 'English'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">{messages?.settings?.defaultCurrency || 'Default Currency'}</label>
                  <p className="text-sm text-muted-foreground">{messages?.settings?.egyptianPound || 'Egyptian Pound (EGP)'}</p>
                </div>
                <Button variant="outline" size="sm">
                  <Edit className="h-4 w-4 mr-2" />
                  {messages?.common?.edit || 'Edit Settings'}
                </Button>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setSystemModalOpen(true)}>
              <CardHeader>
                <CardTitle>{messages?.settings?.dataManagement || 'Data Management'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium">{messages?.settings?.importExportData || 'Import/Export'}</label>
                  <p className="text-sm text-muted-foreground">{messages?.settings?.csvExcelSupport || 'CSV & Excel support'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">{messages?.settings?.backupRestore || 'Backup'}</label>
                  <p className="text-sm text-muted-foreground">{messages?.settings?.automaticBackupEnabled || 'Automatic backup enabled'}</p>
                </div>
                <Button variant="outline" size="sm">
                  <Database className="h-4 w-4 mr-2" />
                  {messages?.settings?.dataManagement || 'Manage Data'}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Modals */}
      <AddSourceModal
        open={sourceModalOpen}
        onOpenChange={setSourceModalOpen}
        onSourceAdded={handleSourceAdded}
      />

      <AddLeadTypeModal
        open={leadTypeModalOpen}
        onOpenChange={setLeadTypeModalOpen}
        onTypeAdded={handleLeadTypeAdded}
      />

      <AddPropertyTypeModal
        open={propertyTypeModalOpen}
        onOpenChange={setPropertyTypeModalOpen}
        onTypeAdded={handlePropertyTypeAdded}
      />

      <AddDealStageModal
        open={dealStageModalOpen}
        onOpenChange={setDealStageModalOpen}
        onStageAdded={handleDealStageAdded}
      />

      <AddActivityTypeModal
        open={activityTypeModalOpen}
        onOpenChange={setActivityTypeModalOpen}
        onTypeAdded={handleActivityTypeAdded}
      />

      <AddListingChannelModal
        open={listingChannelModalOpen}
        onOpenChange={setListingChannelModalOpen}
        onChannelAdded={handleListingChannelAdded}
      />

      <UserManagementModal
        open={userManagementModalOpen}
        onOpenChange={setUserManagementModalOpen}
      />

      <PipelineManagementModal
        open={pipelineModalOpen}
        onOpenChange={setPipelineModalOpen}
      />

      <SystemSettingsModal
        open={systemModalOpen}
        onOpenChange={setSystemModalOpen}
      />
    </div>
  )
}