'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { EmptyState } from '@/components/ui/empty-state'
import { ListingForm } from '@/components/forms/listing-form'
import { useLocale } from '@/components/providers/locale-provider'
import { List, Plus, Globe, Share2, Eye, Calendar, Edit, Trash2, Copy, Play, Pause, Square, Filter } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { MoreHorizontal } from 'lucide-react'

interface Listing {
  id: string
  channel: {
    id: string
    name: string
    isActive: boolean
    createdAt: string
  }
  status: 'Draft' | 'Published' | 'Paused' | 'Ended'
  publishedAt?: string
  views: number
  inquiries: number
  leadsCreated: number
  priceOverride?: number
  url?: string
  property: {
    id: string
    code: string
    type: {
      id: string
      name: string
      isActive: boolean
      createdAt: string
    }
    city: string
    area?: string
    price?: number
    bedrooms?: number
    bathrooms?: number
  }
  createdAt: string
}

interface ListingsData {
  data: Listing[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

export default function ListingsPage() {
  const { messages } = useLocale()
  const [listings, setListings] = useState<ListingsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [formOpen, setFormOpen] = useState(false)
  const [editingListing, setEditingListing] = useState<Listing | null>(null)
  const [filters, setFilters] = useState({
    channel: '',
    status: '',
    city: ''
  })

  const fetchListings = async () => {
    try {
      const params = new URLSearchParams()
      if (filters.channel && filters.channel !== 'all') params.append('channel', filters.channel)
      if (filters.status && filters.status !== 'all') params.append('status', filters.status)
      if (filters.city && filters.city !== 'all') params.append('city', filters.city)
      
      const response = await fetch(`/api/listings?${params.toString()}`)
      if (response.ok) {
        const data = await response.json()
        setListings(data)
      }
    } catch (error) {
      console.error('Failed to fetch listings:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchListings()
  }, [filters])

  const handleCreateListing = async (data: any) => {
    try {
      const response = await fetch('/api/listings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchListings()
      }
    } catch (error) {
      console.error('Failed to create listing:', error)
    }
  }

  const handleEditListing = async (data: any) => {
    if (!editingListing) return

    try {
      const response = await fetch(`/api/listings/${editingListing.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchListings()
        setEditingListing(null)
      }
    } catch (error) {
      console.error('Failed to update listing:', error)
    }
  }

  const handleStatusChange = async (id: string, status: string) => {
    try {
      const response = await fetch(`/api/listings/${id}/${status.toLowerCase()}`, {
        method: 'POST',
      })

      if (response.ok) {
        await fetchListings()
      }
    } catch (error) {
      console.error(`Failed to ${status.toLowerCase()} listing:`, error)
    }
  }

  const handleDuplicate = async (id: string) => {
    try {
      const response = await fetch(`/api/listings/${id}/duplicate`, {
        method: 'POST',
      })

      if (response.ok) {
        await fetchListings()
      }
    } catch (error) {
      console.error('Failed to duplicate listing:', error)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الإعلان؟')) return

    try {
      const response = await fetch(`/api/listings/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        await fetchListings()
      }
    } catch (error) {
      console.error('Failed to delete listing:', error)
    }
  }
  const getChannelIcon = (channel: string) => {
    const icons: Record<string, string> = {
      Website: '🌐',
      OLX: '🛒',
      Facebook: '📘',
      Instagram: '📷',
      'Email Campaign': '📧',
      Offline: '📋',
    }
    return icons[channel] || '📢'
  }

  const getChannelColor = (channel: string) => {
    const colors: Record<string, string> = {
      Website: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      OLX: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      Facebook: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      Instagram: 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300',
      'Email Campaign': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300',
      Offline: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300',
    }
    return colors[channel] || 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300'
  }

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      Draft: 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300',
      Published: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      Paused: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
      Ended: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
    }
    return colors[status] || 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300'
  }

  const getStatusText = (status: string) => {
    const texts: Record<string, string> = {
      Draft: 'Draft',
      Published: 'Published',
      Paused: 'Paused',
      Ended: 'Ended',
    }
    return texts[status] || status
  }
  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">
          {messages?.common?.loading || 'Loading...'}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Listings</h1>
          <p className="text-muted-foreground mt-1">
            Manage your property listings across different channels
          </p>
        </div>
        <Button onClick={() => setFormOpen(true)} className="shadow-sm">
          <Plus className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
          Create Listing
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filter Results
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Channel</label>
              <Select value={filters.channel} onValueChange={(value) => setFilters(prev => ({ ...prev, channel: value === 'all' ? '' : value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="All Channels" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Channels</SelectItem>
                  <SelectItem value="Website">Website</SelectItem>
                  <SelectItem value="OLX">OLX</SelectItem>
                  <SelectItem value="Facebook">Facebook</SelectItem>
                  <SelectItem value="Instagram">Instagram</SelectItem>
                  <SelectItem value="Email Campaign">Email Campaign</SelectItem>
                  <SelectItem value="Offline">Offline</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">Status</label>
              <Select value={filters.status} onValueChange={(value) => setFilters(prev => ({ ...prev, status: value === 'all' ? '' : value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="All Statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="Draft">Draft</SelectItem>
                  <SelectItem value="Published">Published</SelectItem>
                  <SelectItem value="Paused">Paused</SelectItem>
                  <SelectItem value="Ended">Ended</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">City</label>
              <Select value={filters.city} onValueChange={(value) => setFilters(prev => ({ ...prev, city: value === 'all' ? '' : value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="All Cities" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Cities</SelectItem>
                  <SelectItem value="القاهرة">القاهرة</SelectItem>
                  <SelectItem value="الجيزة">الجيزة</SelectItem>
                  <SelectItem value="الإسكندرية">الإسكندرية</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>
      {/* Stats Cards */}
      {listings && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <List className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Listings</p>
                  <p className="text-2xl font-bold">{listings.pagination.total}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Eye className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Published</p>
                  <p className="text-2xl font-bold">
                    {listings.data.filter(l => l.status === 'Published').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Globe className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Channels</p>
                  <p className="text-2xl font-bold">
                    {new Set(listings.data.map(l => l.channel.name || 'Unknown')).size}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-yellow-500 rounded-full" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Paused</p>
                  <p className="text-2xl font-bold">
                    {listings.data.filter(l => l.status === 'Paused').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Listings Grid */}
      {listings?.data.length ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {listings.data.map((listing) => (
            <Card key={listing.id} className="hover:shadow-lg transition-all duration-200 border-l-4 border-l-primary/20">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-semibold">{listing.property.code}</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Badge className={getChannelColor(listing.channel.name)}>
                      {getChannelIcon(listing.channel.name)} {listing.channel.name}
                    </Badge>
                    <Badge className={getStatusColor(listing.status)}>
                      {getStatusText(listing.status)}
                    </Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setEditingListing(listing)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleDuplicate(listing.id)}>
                          <Copy className="h-4 w-4 mr-2" />
                          Duplicate
                        </DropdownMenuItem>
                        {listing.status === 'Draft' && (
                          <DropdownMenuItem onClick={() => handleStatusChange(listing.id, 'publish')}>
                            <Play className="h-4 w-4 mr-2" />
                            Publish
                          </DropdownMenuItem>
                        )}
                        {listing.status === 'Published' && (
                          <DropdownMenuItem onClick={() => handleStatusChange(listing.id, 'pause')}>
                            <Pause className="h-4 w-4 mr-2" />
                            Pause
                          </DropdownMenuItem>
                        )}
                        {(listing.status === 'Published' || listing.status === 'Paused') && (
                          <DropdownMenuItem onClick={() => handleStatusChange(listing.id, 'end')}>
                            <Square className="h-4 w-4 mr-2" />
                            End
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem 
                          onClick={() => handleDelete(listing.id)}
                          className="text-destructive"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">
                    {listing.property.type.name} في {listing.property.city}
                  </span>
                  {(listing.priceOverride || listing.property.price) && (
                    <span className="font-bold text-lg text-primary">
                      {(listing.priceOverride || listing.property.price)?.toLocaleString()} جنيه
                    </span>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {/* Performance Metrics */}
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-muted/50 p-2 rounded">
                    <p className="text-xs text-muted-foreground">Views</p>
                    <p className="font-semibold">{listing.views}</p>
                  </div>
                  <div className="bg-muted/50 p-2 rounded">
                    <p className="text-xs text-muted-foreground">Inquiries</p>
                    <p className="font-semibold">{listing.inquiries}</p>
                  </div>
                  <div className="bg-muted/50 p-2 rounded">
                    <p className="text-xs text-muted-foreground">Leads</p>
                    <p className="font-semibold">{listing.leadsCreated}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  {listing.property.bedrooms && (
                    <span>🛏️ {listing.property.bedrooms} BR</span>
                  )}
                  {listing.property.bathrooms && (
                    <span>🚿 {listing.property.bathrooms} BA</span>
                  )}
                </div>
                
                {listing.property.area && (
                  <div className="text-sm text-muted-foreground">
                    📍 {listing.property.area}
                  </div>
                )}
                
                {listing.publishedAt && (
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    <span>Published: {new Date(listing.publishedAt).toLocaleDateString()}</span>
                  </div>
                )}
                
                {listing.url && (
                  <div className="text-sm">
                    <a 
                      href={listing.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary hover:underline"
                    >
                      🔗 View Listing
                    </a>
                  </div>
                )}
                
                <div className="flex items-center space-x-2 pt-2">
                  <Button size="sm" variant="outline" className="flex-1">
                    <Share2 className="h-4 w-4 mr-1" />
                    Share
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1">
                    <Eye className="h-4 w-4 mr-1" />
                    View
                  </Button>
                </div>
                
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground">
                    Created: {new Date(listing.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={<List className="h-12 w-12" />}
          title="No listings found"
          description="Start by creating your first property listing to reach more customers."
          action={{
            label: 'Create Listing',
            onClick: () => setFormOpen(true),
          }}
        />
      )}

      {/* Forms */}
      <ListingForm
        open={formOpen}
        onOpenChange={setFormOpen}
        onSubmit={handleCreateListing}
        mode="create"
      />

      {editingListing && (
        <ListingForm
          open={!!editingListing}
          onOpenChange={(open) => !open && setEditingListing(null)}
          onSubmit={handleEditListing}
          initialData={editingListing}
          mode="edit"
        />
      )}
    </div>
  )
}