'use client'

import { useEffect, useState, useRef, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  MessageCircle, 
  Send, 
  Ticket, 
  Plus, 
  Clock, 
  User, 
  AlertCircle,
  CheckCircle,
  Pause,
  Search,
  Filter,
  MoreHorizontal,
  Paperclip,
  History,
  Circle
} from 'lucide-react'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useLocale } from '@/components/providers/locale-provider'
import { useAuth } from '@/lib/auth-context'
import { format } from 'date-fns'

interface ChatMessage {
  id: string
  senderId: string
  senderName: string
  senderRole: string
  message: string
  timestamp: string
  type: 'text' | 'system'
  recipientId?: string
  recipientName?: string
}

interface SupportTicket {
  id: string
  title: string
  description: string
  priority: 'Low' | 'Normal' | 'High' | 'Urgent'
  status: 'Open' | 'In Progress' | 'Resolved' | 'Closed'
  category: 'Technical' | 'Feature Request' | 'Bug Report' | 'General'
  createdBy: string
  createdByName: string
  assignedTo?: string
  assignedToName?: string
  createdAt: string
  updatedAt: string
  messages: ChatMessage[]
}

export default function SupportPage() {
  const { messages, locale } = useLocale()
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState('chat')
  
  // Chat state
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([])
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [onlineUsers, setOnlineUsers] = useState<any[]>([])
  const [selectedUser, setSelectedUser] = useState<any>(null)
  const [privateChatMessages, setPrivateChatMessages] = useState<Record<string, ChatMessage[]>>({})
  const chatEndRef = useRef<HTMLDivElement>(null)
  
  // Tickets state
  const [tickets, setTickets] = useState<SupportTicket[]>([])
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null)
  const [ticketFormOpen, setTicketFormOpen] = useState(false)
  const [ticketFilters, setTicketFilters] = useState({
    status: 'all',
    priority: 'all',
    category: 'all'
  })
  
  // New ticket form
  const [newTicket, setNewTicket] = useState({
    title: '',
    description: '',
    priority: 'Normal' as const,
    category: 'General' as const
  })

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate receiving new messages (in real app, this would be WebSocket)
      // For demo, we'll just update timestamps
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  // Auto-scroll chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [chatMessages])

  // Initialize with some demo data for demonstration
  useEffect(() => {
    // Initialize online users
    setOnlineUsers([
      { id: 'admin-1', name: 'System Administrator', role: 'SUPER_ADMIN', status: 'online', lastSeen: new Date().toISOString() },
    ])

    // Initialize with completely empty data for clean system
    setChatMessages([])
    setChatHistory([])
    setTickets([])
    setPrivateChatMessages({})
  }, [])

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !user) return

    const isPrivateChat = selectedUser && selectedUser.id !== 'general'
    const message: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderId: user.id,
      senderName: user.name,
      senderRole: user.role,
      message: newMessage.trim(),
      timestamp: new Date().toISOString(),
      type: 'text',
      recipientId: isPrivateChat ? selectedUser.id : undefined,
      recipientName: isPrivateChat ? selectedUser.name : undefined
    }

    if (isPrivateChat) {
      // Private message
      setPrivateChatMessages(prev => ({
        ...prev,
        [selectedUser.id]: [...(prev[selectedUser.id] || []), message]
      }))
    } else {
      // General chat
      setChatMessages(prev => [...prev, message])
    }
    
    setNewMessage('')

    // In real app, send to WebSocket server
    try {
      const endpoint = isPrivateChat ? '/api/support/private-chat' : '/api/support/chat'
      await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(message)
      })
    } catch (error) {
      console.error('Failed to send message:', error)
    }
  }

  const handleCreateTicket = async () => {
    if (!newTicket.title.trim() || !user) return

    const ticket: SupportTicket = {
      id: `ticket-${Date.now()}`,
      title: newTicket.title,
      description: newTicket.description,
      priority: newTicket.priority,
      status: 'Open',
      category: newTicket.category,
      createdBy: user.id,
      createdByName: user.name,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: []
    }

    setTickets(prev => [ticket, ...prev])
    setNewTicket({ title: '', description: '', priority: 'Normal', category: 'General' })
    setTicketFormOpen(false)

    // In real app, send to backend
    try {
      await fetch('/api/support/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(ticket)
      })
    } catch (error) {
      console.error('Failed to create ticket:', error)
    }
  }

  const handleTicketReply = async (ticketId: string, message: string) => {
    if (!message.trim() || !user) return

    const reply: ChatMessage = {
      id: `reply-${Date.now()}`,
      senderId: user.id,
      senderName: user.name,
      senderRole: user.role,
      message: message.trim(),
      timestamp: new Date().toISOString(),
      type: 'text'
    }

    setTickets(prev => prev.map(ticket => 
      ticket.id === ticketId 
        ? { ...ticket, messages: [...ticket.messages, reply], updatedAt: new Date().toISOString() }
        : ticket
    ))

    if (selectedTicket?.id === ticketId) {
      setSelectedTicket(prev => prev ? { ...prev, messages: [...prev.messages, reply] } : null)
    }
  }

  const getRoleColor = (role: string) => {
    const colors: Record<string, string> = {
      SUPER_ADMIN: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
      ADMIN: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300',
      SALES: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      AGENT: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    }
    return colors[role] || 'bg-gray-100 text-gray-800'
  }

  const getPriorityColor = (priority: string) => {
    const colors: Record<string, string> = {
      Low: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      Normal: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      High: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
      Urgent: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
    }
    return colors[priority] || 'bg-gray-100 text-gray-800'
  }

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      Open: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
      'In Progress': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
      Resolved: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      Closed: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300',
    }
    return colors[status] || 'bg-gray-100 text-gray-800'
  }

  const getStatusIcon = (status: string) => {
    const icons: Record<string, React.ReactNode> = {
      Open: <AlertCircle className="h-4 w-4" />,
      'In Progress': <Clock className="h-4 w-4" />,
      Resolved: <CheckCircle className="h-4 w-4" />,
      Closed: <Pause className="h-4 w-4" />,
    }
    return icons[status] || <AlertCircle className="h-4 w-4" />
  }

  const getCurrentChatMessages = () => {
    if (selectedUser && selectedUser.id !== 'general') {
      return privateChatMessages[selectedUser.id] || []
    }
    return chatMessages
  }

  const handleUserSelect = (selectedUser: any) => {
    setSelectedUser(selectedUser)
  }

  const filteredTickets = tickets.filter(ticket => {
    if (ticketFilters.status !== 'all' && ticket.status !== ticketFilters.status) return false
    if (ticketFilters.priority !== 'all' && ticket.priority !== ticketFilters.priority) return false
    if (ticketFilters.category !== 'all' && ticket.category !== ticketFilters.category) return false
    return true
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">
            {messages?.support?.title || 'Support'}
          </h1>
          <p className="text-muted-foreground mt-1">
            {messages?.support?.description || 'Get help and communicate with your team'}
          </p>
        </div>
        <Button onClick={() => setTicketFormOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          {messages?.support?.createTicket || 'Create Ticket'}
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="chat" className="flex items-center gap-2">
            <MessageCircle className="h-4 w-4" />
            {messages?.support?.chat || 'Chat'}
          </TabsTrigger>
          <TabsTrigger value="tickets" className="flex items-center gap-2">
            <Ticket className="h-4 w-4" />
            {messages?.support?.supportTickets || 'Support Tickets'}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Users & Chat History */}
            <Card className="lg:col-span-1">
              <Tabs defaultValue="online" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="online" className="flex items-center gap-1 text-xs">
                    <Circle className="h-3 w-3" />
                    {messages?.support?.online || 'Online'}
                  </TabsTrigger>
                  <TabsTrigger value="history" className="flex items-center gap-1 text-xs">
                    <History className="h-3 w-3" />
                    {messages?.support?.history || 'History'}
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="online" className="space-y-3 mt-4">
                  {/* General Chat Option */}
                  <div 
                    className={`flex items-center space-x-3 p-2 rounded-lg cursor-pointer transition-colors ${
                      !selectedUser || selectedUser.id === 'general' ? 'bg-primary/10 border border-primary/20' : 'hover:bg-muted/50'
                    }`}
                    onClick={() => handleUserSelect({ id: 'general', name: 'General Chat', role: 'GENERAL', status: 'online' })}
                  >
                    <div className="relative">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="text-xs bg-primary text-primary-foreground">
                          ALL
                        </AvatarFallback>
                      </Avatar>
                      <div className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white bg-green-500" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{messages?.support?.generalChat || 'General Chat'}</p>
                      <p className="text-xs text-muted-foreground">{messages?.support?.everyoneCanSee || 'Everyone can see'}</p>
                    </div>
                  </div>
                  
                  {/* Online Users */}
                  {onlineUsers.filter(u => u.id !== user?.id).map((onlineUser) => (
                    <div 
                      key={onlineUser.id} 
                      className={`flex items-center space-x-3 p-2 rounded-lg cursor-pointer transition-colors ${
                        selectedUser?.id === onlineUser.id ? 'bg-primary/10 border border-primary/20' : 'hover:bg-muted/50'
                      }`}
                      onClick={() => handleUserSelect(onlineUser)}
                    >
                      <div className="relative">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="text-xs">
                            {onlineUser.name.split(' ').map((n: string) => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white ${
                          onlineUser.status === 'online' ? 'bg-green-500' : 'bg-yellow-500'
                        }`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{onlineUser.name}</p>
                        <Badge className={`${getRoleColor(onlineUser.role)} text-xs`}>
                          {onlineUser.role}
                        </Badge>
                      </div>
                      {privateChatMessages[onlineUser.id]?.length > 0 && (
                        <div className="w-2 h-2 bg-primary rounded-full" />
                      )}
                    </div>
                  ))}
                  
                  {onlineUsers.filter(u => u.id !== user?.id).length === 0 && (
                    <div className="text-center text-muted-foreground py-4">
                      <User className="h-6 w-6 mx-auto mb-2 opacity-50" />
                      <p className="text-xs">{messages?.support?.noUsersOnline || 'No other users online'}</p>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="history" className="space-y-3 mt-4">
                  <div className="text-center text-muted-foreground py-8">
                    <History className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">{messages?.support?.noChatHistory || 'No chat history'}</p>
                    <p className="text-xs">{messages?.support?.startChattingToSeeHistory || 'Start chatting to see history here'}</p>
                  </div>
                </TabsContent>
              </Tabs>
            </Card>

            {/* Chat Area */}
            <Card className="lg:col-span-3">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                  <MessageCircle className="h-5 w-5" />
                    {selectedUser ? (
                      selectedUser.id === 'general' ? 
                        (messages?.support?.generalChat || 'General Chat') : 
                        `${messages?.support?.chatWith || 'Chat with'} ${selectedUser.name}`
                    ) : (
                      messages?.support?.selectUserToChat || 'Select a user to chat'
                    )}
                  </div>
                  {selectedUser && selectedUser.id !== 'general' && (
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${
                        selectedUser.status === 'online' ? 'bg-green-500' : 'bg-yellow-500'
                      }`} />
                      <span className="text-sm text-muted-foreground">
                        {selectedUser.status === 'online' ? 
                          (messages?.support?.online || 'Online') : 
                          (messages?.support?.away || 'Away')
                        }
                      </span>
                    </div>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Messages */}
                <div className="h-96 overflow-y-auto space-y-3 p-4 bg-muted/30 rounded-lg">
                  {!selectedUser ? (
                    <div className="text-center text-muted-foreground py-8">
                      <MessageCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p>{messages?.support?.selectUserToStartChat || 'Select a user to start chatting'}</p>
                      <p className="text-xs">{messages?.support?.chooseFromOnlineUsers || 'Choose from online users or general chat'}</p>
                    </div>
                  ) : getCurrentChatMessages().length === 0 ? (
                    <div className="text-center text-muted-foreground py-8">
                      <MessageCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p>{messages?.support?.noMessages || 'No messages yet'}</p>
                      <p className="text-xs">
                        {selectedUser.id === 'general' ? 
                          (messages?.support?.startGeneralConversation || 'Start a conversation with everyone') :
                          (messages?.support?.startPrivateConversation || `Start a private conversation with ${selectedUser.name}`)
                        }
                      </p>
                    </div>
                  ) : (
                    getCurrentChatMessages().map((msg) => (
                      <div key={msg.id} className={`flex ${msg.senderId === user?.id ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                          msg.senderId === user?.id 
                            ? 'bg-primary text-primary-foreground' 
                            : 'bg-card border'
                        }`}>
                          {msg.senderId !== user?.id && (
                            <div className="flex items-center space-x-2 mb-1">
                              <span className="text-xs font-medium">{msg.senderName}</span>
                              <Badge className={`${getRoleColor(msg.senderRole)} text-xs`}>
                                {msg.senderRole}
                              </Badge>
                            </div>
                          )}
                          <p className="text-sm">{msg.message}</p>
                          {msg.recipientName && msg.senderId === user?.id && (
                            <p className="text-xs opacity-70 mt-1">
                              {messages?.support?.to || 'To'}: {msg.recipientName}
                            </p>
                          )}
                          <p className="text-xs opacity-70 mt-1">
                            {format(new Date(msg.timestamp), 'HH:mm')}
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                  <div ref={chatEndRef} />
                </div>

                {/* Message Input */}
                <div className={`flex items-center space-x-2 ${!selectedUser ? 'opacity-50 pointer-events-none' : ''}`}>
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder={
                      !selectedUser ? 
                        (messages?.support?.selectUserFirst || 'Select a user first...') :
                        selectedUser.id === 'general' ?
                          (messages?.support?.typeMessageToEveryone || 'Type message to everyone...') :
                          (messages?.support?.typePrivateMessage || `Type private message to ${selectedUser.name}...`)
                    }
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault()
                        handleSendMessage()
                      }
                    }}
                    className="flex-1"
                    disabled={!selectedUser}
                  />
                  <Button size="sm" variant="outline">
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <Button onClick={handleSendMessage} disabled={!newMessage.trim() || !selectedUser}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tickets" className="space-y-4">
          {/* Ticket Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                {messages?.support?.filterTickets || 'Filter Tickets'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">{messages?.support?.status || 'Status'}</label>
                  <Select value={ticketFilters.status} onValueChange={(value) => setTicketFilters(prev => ({ ...prev, status: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{messages?.support?.allStatuses || 'All Statuses'}</SelectItem>
                      <SelectItem value="Open">{messages?.support?.open || 'Open'}</SelectItem>
                      <SelectItem value="In Progress">{messages?.support?.inProgress || 'In Progress'}</SelectItem>
                      <SelectItem value="Resolved">{messages?.support?.resolved || 'Resolved'}</SelectItem>
                      <SelectItem value="Closed">{messages?.support?.closed || 'Closed'}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">{messages?.support?.priority || 'Priority'}</label>
                  <Select value={ticketFilters.priority} onValueChange={(value) => setTicketFilters(prev => ({ ...prev, priority: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{messages?.support?.allPriorities || 'All Priorities'}</SelectItem>
                      <SelectItem value="Low">{messages?.support?.low || 'Low'}</SelectItem>
                      <SelectItem value="Normal">{messages?.support?.normal || 'Normal'}</SelectItem>
                      <SelectItem value="High">{messages?.support?.high || 'High'}</SelectItem>
                      <SelectItem value="Urgent">{messages?.support?.urgent || 'Urgent'}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">{messages?.support?.category || 'Category'}</label>
                  <Select value={ticketFilters.category} onValueChange={(value) => setTicketFilters(prev => ({ ...prev, category: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{messages?.support?.allCategories || 'All Categories'}</SelectItem>
                      <SelectItem value="Technical">{messages?.support?.technical || 'Technical'}</SelectItem>
                      <SelectItem value="Feature Request">{messages?.support?.featureRequest || 'Feature Request'}</SelectItem>
                      <SelectItem value="Bug Report">{messages?.support?.bugReport || 'Bug Report'}</SelectItem>
                      <SelectItem value="General">{messages?.support?.general || 'General'}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-end">
                  <div className="relative flex-1">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input placeholder={messages?.support?.searchTickets || 'Search tickets...'} className="pl-8" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tickets Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Ticket className="h-5 w-5 text-blue-600" />
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{messages?.support?.totalTickets || 'Total Tickets'}</p>
                    <p className="text-2xl font-bold">{tickets.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <AlertCircle className="h-5 w-5 text-red-600" />
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{messages?.support?.open || 'Open'}</p>
                    <p className="text-2xl font-bold">{tickets.filter(t => t.status === 'Open').length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Clock className="h-5 w-5 text-yellow-600" />
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{messages?.support?.inProgress || 'In Progress'}</p>
                    <p className="text-2xl font-bold">{tickets.filter(t => t.status === 'In Progress').length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{messages?.support?.resolved || 'Resolved'}</p>
                    <p className="text-2xl font-bold">{tickets.filter(t => t.status === 'Resolved').length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tickets List */}
          {filteredTickets.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTickets.map((ticket) => (
                <Card key={ticket.id} className="hover:shadow-lg transition-all duration-200 cursor-pointer border-l-4 border-l-primary/20"
                      onClick={() => setSelectedTicket(ticket)}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg font-semibold truncate">{ticket.title}</CardTitle>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            {messages?.support?.assignToMe || 'Assign to Me'}
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            {messages?.support?.markResolved || 'Mark as Resolved'}
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">
                            {messages?.support?.closeTicket || 'Close Ticket'}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={getStatusColor(ticket.status)}>
                        <div className="flex items-center space-x-1">
                          {getStatusIcon(ticket.status)}
                          <span>{messages?.support?.statuses?.[ticket.status] || ticket.status}</span>
                        </div>
                      </Badge>
                      <Badge className={getPriorityColor(ticket.priority)}>
                        {messages?.support?.priorities?.[ticket.priority] || ticket.priority}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-sm text-muted-foreground line-clamp-2">{ticket.description}</p>
                    
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <User className="h-4 w-4" />
                      <span>{ticket.createdByName}</span>
                    </div>
                    
                    {ticket.assignedToName && (
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <span>👤 {messages?.support?.assignedTo || 'Assigned to'}: {ticket.assignedToName}</span>
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t">
                      <span>{messages?.support?.created || 'Created'}: {format(new Date(ticket.createdAt), 'MMM dd, HH:mm')}</span>
                      {ticket.messages.length > 0 && (
                        <span>{ticket.messages.length} {messages?.support?.replies || 'replies'}</span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <Ticket className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">{messages?.support?.noTickets || 'No support tickets'}</h3>
                <p className="text-muted-foreground mb-4">
                  {messages?.support?.noTicketsDescription || 'Create your first support ticket to get help from the team'}
                </p>
                <Button onClick={() => setTicketFormOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  {messages?.support?.createFirstTicket || 'Create First Ticket'}
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Create Ticket Modal */}
      <Dialog open={ticketFormOpen} onOpenChange={setTicketFormOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{messages?.support?.createTicket || 'Create Support Ticket'}</DialogTitle>
            <DialogDescription>
              {messages?.support?.createTicketDescription || 'Describe your issue or request and we\'ll help you resolve it'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">{messages?.support?.ticketTitle || 'Ticket Title'} *</label>
              <Input
                value={newTicket.title}
                onChange={(e) => setNewTicket(prev => ({ ...prev, title: e.target.value }))}
                placeholder={messages?.support?.ticketTitlePlaceholder || 'Brief description of your issue'}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">{messages?.support?.priority || 'Priority'}</label>
                <Select value={newTicket.priority} onValueChange={(value: any) => setNewTicket(prev => ({ ...prev, priority: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Low">{messages?.support?.low || 'Low'}</SelectItem>
                    <SelectItem value="Normal">{messages?.support?.normal || 'Normal'}</SelectItem>
                    <SelectItem value="High">{messages?.support?.high || 'High'}</SelectItem>
                    <SelectItem value="Urgent">{messages?.support?.urgent || 'Urgent'}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium mb-2 block">{messages?.support?.category || 'Category'}</label>
                <Select value={newTicket.category} onValueChange={(value: any) => setNewTicket(prev => ({ ...prev, category: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Technical">{messages?.support?.technical || 'Technical'}</SelectItem>
                    <SelectItem value="Feature Request">{messages?.support?.featureRequest || 'Feature Request'}</SelectItem>
                    <SelectItem value="Bug Report">{messages?.support?.bugReport || 'Bug Report'}</SelectItem>
                    <SelectItem value="General">{messages?.support?.general || 'General'}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">{messages?.support?.description || 'Description'} *</label>
              <Textarea
                value={newTicket.description}
                onChange={(e) => setNewTicket(prev => ({ ...prev, description: e.target.value }))}
                placeholder={messages?.support?.descriptionPlaceholder || 'Provide detailed information about your issue or request...'}
                rows={4}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setTicketFormOpen(false)}>
              {messages?.common?.cancel || 'Cancel'}
            </Button>
            <Button onClick={handleCreateTicket} disabled={!newTicket.title.trim() || !newTicket.description.trim()}>
              {messages?.support?.createTicket || 'Create Ticket'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Ticket Detail Modal */}
      {selectedTicket && (
        <Dialog open={!!selectedTicket} onOpenChange={() => setSelectedTicket(null)}>
          <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <div className="flex items-center justify-between">
                <DialogTitle className="flex items-center gap-2">
                  <Ticket className="h-5 w-5" />
                  {selectedTicket.title}
                </DialogTitle>
                <div className="flex items-center space-x-2">
                  <Badge className={getStatusColor(selectedTicket.status)}>
                    {messages?.support?.statuses?.[selectedTicket.status] || selectedTicket.status}
                  </Badge>
                  <Badge className={getPriorityColor(selectedTicket.priority)}>
                    {messages?.support?.priorities?.[selectedTicket.priority] || selectedTicket.priority}
                  </Badge>
                </div>
              </div>
              <DialogDescription>
                {messages?.support?.ticketId || 'Ticket ID'}: {selectedTicket.id} • {messages?.support?.createdBy || 'Created by'}: {selectedTicket.createdByName}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="bg-muted/50 p-4 rounded-lg">
                <h4 className="font-medium mb-2">{messages?.support?.originalRequest || 'Original Request'}</h4>
                <p className="text-sm">{selectedTicket.description}</p>
              </div>
              
              {/* Ticket Messages */}
              <div className="space-y-3">
                <h4 className="font-medium">{messages?.support?.conversation || 'Conversation'}</h4>
                <div className="max-h-64 overflow-y-auto space-y-3">
                  {selectedTicket.messages.length === 0 ? (
                    <div className="text-center text-muted-foreground py-4">
                      <MessageCircle className="h-6 w-6 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">{messages?.support?.noReplies || 'No replies yet'}</p>
                    </div>
                  ) : (
                    selectedTicket.messages.map((msg) => (
                      <div key={msg.id} className={`flex ${msg.senderId === user?.id ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-md px-4 py-2 rounded-lg ${
                          msg.senderId === user?.id 
                            ? 'bg-primary text-primary-foreground' 
                            : 'bg-muted'
                        }`}>
                          <div className="flex items-center space-x-2 mb-1">
                            <span className="text-xs font-medium">{msg.senderName}</span>
                            <span className="text-xs opacity-70">
                              {format(new Date(msg.timestamp), 'MMM dd, HH:mm')}
                            </span>
                          </div>
                          <p className="text-sm">{msg.message}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
                
                {/* Reply Input */}
                <div className="flex items-center space-x-2 pt-2 border-t">
                  <Input
                    placeholder={messages?.support?.typeReply || 'Type your reply...'}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        const input = e.target as HTMLInputElement
                        if (input.value.trim()) {
                          handleTicketReply(selectedTicket.id, input.value)
                          input.value = ''
                        }
                      }
                    }}
                    className="flex-1"
                  />
                  <Button size="sm">
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}