'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useLocale } from '@/components/providers/locale-provider'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { 
  Users, 
  DollarSign, 
  Eye, 
  Building, 
  CheckSquare, 
  Activity, 
  List, 
  UserCheck,
  TrendingUp,
  Calendar,
  ArrowUpRight
} from 'lucide-react'

interface DashboardData {
  leadsToday: number
  openDealsValue: number
  viewingsThisWeek: number
  totalProperties: number
  openTasks: number
  totalListings: number
  activeListings: number
  totalActivities: number
  activitiesThisWeek: number
  totalOwners: number
  recentActivities: any[]
}

const chartData = [
  { name: 'Mon', activities: 0 },
  { name: 'Tue', activities: 0 },
  { name: 'Wed', activities: 0 },
  { name: 'Thu', activities: 0 },
  { name: 'Fri', activities: 0 },
  { name: 'Sat', activities: 0 },
  { name: 'Sun', activities: 0 },
]

const leadStageData = [
  { name: 'New', value: 0, color: '#3b82f6' },
  { name: 'Contacted', value: 0, color: '#eab308' },
  { name: 'Qualified', value: 0, color: '#8b5cf6' },
  { name: 'Won', value: 0, color: '#10b981' },
]

export default function DashboardPage() {
  const { messages, locale } = useLocale()
  const router = useRouter()
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchDashboardData() {
      try {
        const response = await fetch('/api/dashboard')
        if (response.ok) {
          const dashboardData = await response.json()
          setData(dashboardData)
        }
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchDashboardData()
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">
          {messages?.common?.loading || 'Loading...'}
        </div>
      </div>
    )
  }

  const kpis = [
    {
      title: messages?.dashboard?.leadsToday || 'Leads Today',
      value: data?.leadsToday || 0,
      icon: Users,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50 dark:bg-blue-900/20',
      iconBg: 'bg-blue-100 dark:bg-blue-800',
      href: '/leads',
      description: messages?.dashboard?.newLeadsAddedToday || 'New leads added today'
    },
    {
      title: messages?.dashboard?.openDealsValue || 'Open Deals Value',
      value: `${(data?.openDealsValue || 0).toLocaleString()} EGP`,
      icon: DollarSign,
      color: 'text-green-600',
      bgColor: 'bg-green-50 dark:bg-green-900/20',
      iconBg: 'bg-green-100 dark:bg-green-800',
      href: '/deals',
      description: messages?.dashboard?.totalValueActiveDeals || 'Total value of active deals'
    },
    {
      title: messages?.dashboard?.viewingsThisWeek || 'Viewings This Week',
      value: data?.viewingsThisWeek || 0,
      icon: Eye,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50 dark:bg-purple-900/20',
      iconBg: 'bg-purple-100 dark:bg-purple-800',
      href: '/activities',
      description: messages?.dashboard?.propertyViewingsScheduled || 'Property viewings scheduled'
    },
    {
      title: messages?.dashboard?.totalProperties || 'Properties',
      value: data?.totalProperties || 0,
      icon: Building,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50 dark:bg-indigo-900/20',
      iconBg: 'bg-indigo-100 dark:bg-indigo-800',
      href: '/properties',
      description: messages?.dashboard?.totalPropertiesInventory || 'Total properties in inventory'
    },
    {
      title: messages?.dashboard?.openTasks || 'Open Tasks',
      value: data?.openTasks || 0,
      icon: CheckSquare,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50 dark:bg-orange-900/20',
      iconBg: 'bg-orange-100 dark:bg-orange-800',
      href: '/tasks',
      description: messages?.dashboard?.pendingTasksComplete || 'Pending tasks to complete'
    },
    {
      title: messages?.dashboard?.activeListings || 'Active Listings',
      value: data?.activeListings || 0,
      icon: List,
      color: 'text-teal-600',
      bgColor: 'bg-teal-50 dark:bg-teal-900/20',
      iconBg: 'bg-teal-100 dark:bg-teal-800',
      href: '/listings',
      description: messages?.dashboard?.currentlyPublishedListings || 'Currently published listings'
    },
    {
      title: messages?.dashboard?.activitiesThisWeek || 'Activities This Week',
      value: data?.activitiesThisWeek || 0,
      icon: Activity,
      color: 'text-pink-600',
      bgColor: 'bg-pink-50 dark:bg-pink-900/20',
      iconBg: 'bg-pink-100 dark:bg-pink-800',
      href: '/activities',
      description: messages?.dashboard?.interactionsLoggedWeek || 'Interactions logged this week'
    },
    {
      title: messages?.dashboard?.propertyOwners || 'Property Owners',
      value: data?.totalOwners || 0,
      icon: UserCheck,
      color: 'text-cyan-600',
      bgColor: 'bg-cyan-50 dark:bg-cyan-900/20',
      iconBg: 'bg-cyan-100 dark:bg-cyan-800',
      href: '/owners',
      description: messages?.dashboard?.registeredPropertyOwners || 'Registered property owners'
    },
  ]

  const handleCardClick = (href: string) => {
    router.push(href)
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">
            {messages?.dashboard?.title || 'Dashboard'}
          </h1>
          <p className="text-muted-foreground mt-1">
            {messages?.dashboard?.welcomeMessage || 'Welcome to your CRM dashboard'}
          </p>
        </div>
        <div className="flex items-center text-sm text-muted-foreground">
          <Calendar className="h-4 w-4 mr-2" />
          {new Date().toLocaleDateString(locale === 'ar' ? 'ar-EG' : 'en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </div>
      </div>

      {/* KPI Cards - Responsive Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        {kpis.map((kpi, index) => {
          const Icon = kpi.icon
          return (
            <Card 
              key={index} 
              className={`cursor-pointer transition-all duration-200 hover:shadow-lg hover:scale-105 border-0 ${kpi.bgColor}`}
              onClick={() => handleCardClick(kpi.href)}
            >
              <CardContent className="p-4 md:p-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-muted-foreground mb-1">
                      {kpi.title}
                    </p>
                    <p className="text-xl md:text-2xl font-bold mb-1">
                      {kpi.value}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {kpi.description}
                    </p>
                  </div>
                  <div className={`p-3 rounded-full ${kpi.iconBg} flex-shrink-0 ml-4`}>
                    <Icon className={`h-5 w-5 md:h-6 md:w-6 ${kpi.color}`} />
                  </div>
                </div>
                <div className="flex items-center justify-end mt-2">
                  <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Charts Section - Responsive Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Weekly Activities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis 
                  dataKey="name" 
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis 
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Bar 
                  dataKey="activities" 
                  fill="#3b82f6" 
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Lead Stages
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={leadStageData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {leadStageData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="text-center text-sm text-muted-foreground mt-2">
              No leads data available
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              {messages?.dashboard?.recentActivities || 'Recent Activities'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-[250px] overflow-y-auto">
              {data?.recentActivities?.length ? (
                data.recentActivities.slice(0, 6).map((activity, index) => (
                  <div key={index} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Activity className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">
                        {activity.type} {activity.lead?.fullName ? `with ${activity.lead.fullName}` : ''}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(activity.at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  <Activity className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No recent activities</p>
                  <p className="text-xs">Start logging activities to see them here</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions Section */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            {[
              { label: 'Add Lead', href: '/leads', icon: Users, color: 'bg-blue-500' },
              { label: 'Add Property', href: '/properties', icon: Building, color: 'bg-green-500' },
              { label: 'Create Deal', href: '/deals', icon: DollarSign, color: 'bg-purple-500' },
              { label: 'Add Task', href: '/tasks', icon: CheckSquare, color: 'bg-orange-500' },
              { label: 'Log Activity', href: '/activities', icon: Activity, color: 'bg-pink-500' },
              { label: 'Create Listing', href: '/listings', icon: List, color: 'bg-teal-500' },
              { label: 'Add Owner', href: '/owners', icon: UserCheck, color: 'bg-cyan-500' },
              { label: 'Settings', href: '/settings', icon: TrendingUp, color: 'bg-indigo-500' },
            ].map((action, index) => {
              const Icon = action.icon
              return (
                <Card 
                  key={index}
                  className="cursor-pointer transition-all duration-200 hover:shadow-md hover:scale-105 border-dashed border-2"
                  onClick={() => router.push(action.href)}
                >
                  <CardContent className="p-3 text-center">
                    <div className={`w-8 h-8 ${action.color} rounded-lg flex items-center justify-center mx-auto mb-2`}>
                      <Icon className="h-4 w-4 text-white" />
                    </div>
                    <p className="text-xs font-medium">{action.label}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Empty State Message */}
      <Card className="border-dashed border-2">
        <CardContent className="p-8 text-center">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <TrendingUp className="h-8 w-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Welcome to Your CRM</h3>
          <p className="text-muted-foreground mb-4 max-w-md mx-auto">
            Your dashboard is ready! Start by adding leads, properties, and deals to see your business metrics come to life.
          </p>
          <div className="flex flex-col sm:flex-row gap-2 justify-center">
            <Card 
              className="cursor-pointer hover:shadow-md transition-all p-4 bg-primary/5 border-primary/20"
              onClick={() => router.push('/leads')}
            >
              <div className="flex items-center gap-3">
                <Users className="h-5 w-5 text-primary" />
                <span className="font-medium">Add Your First Lead</span>
              </div>
            </Card>
            <Card 
              className="cursor-pointer hover:shadow-md transition-all p-4 bg-green-500/5 border-green-500/20"
              onClick={() => router.push('/properties')}
            >
              <div className="flex items-center gap-3">
                <Building className="h-5 w-5 text-green-600" />
                <span className="font-medium">Add Your First Property</span>
              </div>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}