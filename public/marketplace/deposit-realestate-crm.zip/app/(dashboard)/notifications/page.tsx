'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Bell, Check, Trash2, Filter, Calendar, User, AlertTriangle, CheckCircle, Info } from 'lucide-react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useLocale } from '@/components/providers/locale-provider'

interface Notification {
  id: string
  type: 'assignment' | 'due_task' | 'deal_update' | 'new_lead' | 'system'
  title: string
  message: string
  isRead: boolean
  priority: 'low' | 'medium' | 'high' | 'urgent'
  relatedEntity?: {
    type: 'lead' | 'deal' | 'task' | 'property'
    id: string
    name: string
  }
  createdAt: string
  actionUrl?: string
}

export default function NotificationsPage() {
  const { messages } = useLocale()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    // Start with empty notifications - clean system
    setNotifications([])
    setLoading(false)
  }, [])

  const getNotificationIcon = (type: string) => {
    const icons: Record<string, React.ReactNode> = {
      assignment: <User className="h-4 w-4" />,
      due_task: <AlertTriangle className="h-4 w-4" />,
      deal_update: <CheckCircle className="h-4 w-4" />,
      new_lead: <User className="h-4 w-4" />,
      system: <Info className="h-4 w-4" />,
    }
    return icons[type] || <Bell className="h-4 w-4" />
  }

  const getNotificationColor = (type: string, priority: string) => {
    if (priority === 'urgent') return 'bg-red-50 border-red-200 dark:bg-red-900/20'
    if (priority === 'high') return 'bg-orange-50 border-orange-200 dark:bg-orange-900/20'
    if (priority === 'medium') return 'bg-blue-50 border-blue-200 dark:bg-blue-900/20'
    return 'bg-gray-50 border-gray-200 dark:bg-gray-900/20'
  }

  const getPriorityColor = (priority: string) => {
    const colors: Record<string, string> = {
      urgent: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
      high: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
      medium: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      low: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300',
    }
    return colors[priority] || 'bg-gray-100 text-gray-800'
  }

  const handleMarkAsRead = async (id: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === id ? { ...notif, isRead: true } : notif
      )
    )
  }

  const handleMarkAllAsRead = async () => {
    setNotifications(prev => 
      prev.map(notif => ({ ...notif, isRead: true }))
    )
  }

  const handleDelete = async (id: string) => {
    setNotifications(prev => prev.filter(notif => notif.id !== id))
  }

  const filteredNotifications = notifications.filter(notif => {
    if (filter === 'all') return true
    if (filter === 'unread') return !notif.isRead
    if (filter === 'read') return notif.isRead
    return notif.type === filter
  })

  const unreadCount = notifications.filter(n => !n.isRead).length

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">جاري التحميل...</div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">{messages?.notifications?.title || 'Notifications'}</h1>
          <p className="text-muted-foreground mt-1">
            {messages?.notifications?.description || 'Track all important updates and reminders'}
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="secondary">
            {unreadCount} {messages?.notifications?.unread || 'unread'}
          </Badge>
          <Button onClick={handleMarkAllAsRead} disabled={unreadCount === 0}>
            <Check className="h-4 w-4 mr-2" />
            {messages?.notifications?.markAllAsRead || 'Mark All as Read'}
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            {messages?.notifications?.filterNotifications || 'Filter Notifications'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-full md:w-64">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{messages?.notifications?.allNotifications || 'All Notifications'}</SelectItem>
              <SelectItem value="unread">{messages?.notifications?.unread || 'Unread'}</SelectItem>
              <SelectItem value="read">{messages?.notifications?.read || 'Read'}</SelectItem>
              <SelectItem value="assignment">{messages?.notifications?.assignments || 'Assignments'}</SelectItem>
              <SelectItem value="due_task">{messages?.notifications?.dueTasks || 'Due Tasks'}</SelectItem>
              <SelectItem value="deal_update">{messages?.notifications?.dealUpdates || 'Deal Updates'}</SelectItem>
              <SelectItem value="new_lead">{messages?.notifications?.newLeads || 'New Leads'}</SelectItem>
              <SelectItem value="system">{messages?.notifications?.system || 'System'}</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {filteredNotifications.map((notification) => (
          <Card 
            key={notification.id} 
            className={`transition-all duration-200 hover:shadow-md cursor-pointer ${
              !notification.isRead ? 'border-l-4 border-l-primary' : ''
            } ${getNotificationColor(notification.type, notification.priority)}`}
            onClick={() => {
              if (!notification.isRead) {
                handleMarkAsRead(notification.id)
              }
              if (notification.actionUrl) {
                window.location.href = notification.actionUrl
              }
            }}
          >
            <CardContent className="p-4">
              <div className="flex items-start space-x-4">
                <div className={`p-2 rounded-full ${
                  notification.priority === 'urgent' ? 'bg-red-100 text-red-600' :
                  notification.priority === 'high' ? 'bg-orange-100 text-orange-600' :
                  notification.priority === 'medium' ? 'bg-blue-100 text-blue-600' :
                  'bg-gray-100 text-gray-600'
                }`}>
                  {getNotificationIcon(notification.type)}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className={`font-semibold ${!notification.isRead ? 'text-foreground' : 'text-muted-foreground'}`}>
                      {notification.title}
                    </h3>
                    <div className="flex items-center space-x-2">
                      <Badge className={getPriorityColor(notification.priority)}>
                        {notification.priority === 'urgent' ? (messages?.notifications?.urgent || 'Urgent') :
                         notification.priority === 'high' ? (messages?.notifications?.high || 'High') :
                         notification.priority === 'medium' ? (messages?.notifications?.medium || 'Medium') : (messages?.notifications?.low || 'Low')}
                      </Badge>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleDelete(notification.id)
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <p className={`text-sm mt-1 ${!notification.isRead ? 'text-foreground' : 'text-muted-foreground'}`}>
                    {notification.message}
                  </p>
                  
                  {notification.relatedEntity && (
                    <div className="flex items-center space-x-2 mt-2">
                      <Badge variant="outline" className="text-xs">
                        {notification.relatedEntity.type === 'lead' ? (messages?.notifications?.lead || 'Lead') :
                         notification.relatedEntity.type === 'deal' ? (messages?.notifications?.deal || 'Deal') :
                         notification.relatedEntity.type === 'task' ? (messages?.notifications?.task || 'Task') :
                         notification.relatedEntity.type === 'property' ? (messages?.notifications?.property || 'Property') : ''}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {notification.relatedEntity.name}
                      </span>
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>{new Date(notification.createdAt).toLocaleString()}</span>
                    </div>
                    
                    {!notification.isRead && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleMarkAsRead(notification.id)
                        }}
                      >
                        <Check className="h-4 w-4 mr-1" />
                        {messages?.notifications?.markAsRead || 'Mark as Read'}
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredNotifications.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Bell className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">{messages?.notifications?.noNotifications || 'No notifications'}</h3>
            <p className="text-muted-foreground">
              {filter === 'unread' 
                ? (messages?.notifications?.allNotificationsRead || 'All notifications read!') 
                : (messages?.notifications?.noNotificationsAvailable || 'No notifications available at the moment')
              }
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}