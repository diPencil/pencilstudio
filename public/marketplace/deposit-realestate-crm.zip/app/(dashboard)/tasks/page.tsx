'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { EmptyState } from '@/components/ui/empty-state'
import { TaskForm } from '@/components/forms/task-form'
import { useLocale } from '@/components/providers/locale-provider'
import { CheckSquare, Plus, Edit, Trash2, MoreHorizontal, Clock, AlertTriangle, User, Calendar } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface Task {
  id: string
  title: string
  description?: string
  status: 'Open' | 'In Progress' | 'Done'
  priority: 'Low' | 'Normal' | 'High' | 'Urgent'
  dueDate?: string
  assignedTo: string
  lead?: {
    id: string
    fullName: string
  }
  deal?: {
    id: string
    title: string
  }
  property?: {
    id: string
    code: string
    city: string
  }
  assignee: {
    id: string
    fullName: string
  }
  isOverdue: boolean
  createdAt: string
}

interface TasksData {
  data: Task[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

export default function TasksPage() {
  const { messages } = useLocale()
  const [tasks, setTasks] = useState<TasksData | null>(null)
  const [loading, setLoading] = useState(true)
  const [formOpen, setFormOpen] = useState(false)
  const [editingTask, setEditingTask] = useState<Task | null>(null)
  const [filters, setFilters] = useState({
    status: '',
    priority: ''
  })

  const fetchTasks = async () => {
    try {
      const params = new URLSearchParams()
      if (filters.status && filters.status !== 'all') params.append('status', filters.status)
      if (filters.priority && filters.priority !== 'all') params.append('priority', filters.priority)
      
      const response = await fetch(`/api/tasks?${params.toString()}`)
      if (response.ok) {
        const data = await response.json()
        setTasks(data)
      }
    } catch (error) {
      console.error('Failed to fetch tasks:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchTasks()
  }, [filters])

  const handleCreateTask = async (data: any) => {
    try {
      const response = await fetch('/api/tasks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchTasks()
      }
    } catch (error) {
      console.error('Failed to create task:', error)
    }
  }

  const handleEditTask = async (data: any) => {
    if (!editingTask) return

    try {
      const response = await fetch(`/api/tasks/${editingTask.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchTasks()
        setEditingTask(null)
      }
    } catch (error) {
      console.error('Failed to update task:', error)
    }
  }

  const handleDeleteTask = async (id: string) => {
    if (!confirm('Are you sure you want to delete this task?')) return

    try {
      const response = await fetch(`/api/tasks/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        await fetchTasks()
      }
    } catch (error) {
      console.error('Failed to delete task:', error)
    }
  }

  const handleStatusChange = async (taskId: string, newStatus: string) => {
    try {
      const response = await fetch(`/api/tasks/${taskId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: newStatus }),
      })

      if (response.ok) {
        await fetchTasks()
      }
    } catch (error) {
      console.error('Failed to update task status:', error)
    }
  }
  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      Open: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
      'In Progress': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
      Done: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    }
    return colors[status] || 'bg-gray-100 text-gray-800'
  }

  const getPriorityColor = (priority: string) => {
    const colors: Record<string, string> = {
      Low: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      Normal: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      High: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
      Urgent: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
    }
    return colors[priority] || 'bg-gray-100 text-gray-800'
  }

  const getPriorityIcon = (priority: string) => {
    if (priority === 'Urgent' || priority === 'High') {
      return <AlertTriangle className="h-3 w-3" />
    }
    return <Clock className="h-3 w-3" />
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">
          {messages?.common?.loading || 'Loading...'}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Tasks</h1>
          <p className="text-muted-foreground mt-1">
            Manage and track your team's tasks and assignments
          </p>
        </div>
        <Button onClick={() => setFormOpen(true)}>
          <Plus className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
          Add Task
        </Button>
      </div>

      {/* Stats Cards */}
      {tasks && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <CheckSquare className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Tasks</p>
                  <p className="text-2xl font-bold">{tasks.pagination.total}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-orange-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Open</p>
                  <p className="text-2xl font-bold">
                    {tasks.data.filter(t => t.status === 'Open').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5 text-red-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Overdue</p>
                  <p className="text-2xl font-bold">
                    {tasks.data.filter(t => t.isOverdue).length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <CheckSquare className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Completed</p>
                  <p className="text-2xl font-bold">
                    {tasks.data.filter(t => t.status === 'Done').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filter Tasks</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Status</label>
              <Select value={filters.status} onValueChange={(value) => setFilters(prev => ({ ...prev, status: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="All Statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="Open">Open</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="Done">Done</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">Priority</label>
              <Select value={filters.priority} onValueChange={(value) => setFilters(prev => ({ ...prev, priority: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="All Priorities" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Priorities</SelectItem>
                  <SelectItem value="Low">Low</SelectItem>
                  <SelectItem value="Normal">Normal</SelectItem>
                  <SelectItem value="High">High</SelectItem>
                  <SelectItem value="Urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tasks Grid */}
      {tasks?.data.length ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tasks.data.map((task) => (
            <Card key={task.id} className={`hover:shadow-lg transition-all duration-200 border-l-4 ${
              task.isOverdue ? 'border-l-red-500' : 
              task.priority === 'Urgent' ? 'border-l-red-400' :
              task.priority === 'High' ? 'border-l-orange-400' :
              'border-l-primary/20'
            }`}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-semibold">{task.title}</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Badge className={getStatusColor(task.status)}>
                      {task.status}
                    </Badge>
                    <Badge className={getPriorityColor(task.priority)}>
                      <div className="flex items-center space-x-1">
                        {getPriorityIcon(task.priority)}
                        <span>{task.priority}</span>
                      </div>
                    </Badge>
                    {task.isOverdue && (
                      <Badge variant="destructive">Overdue</Badge>
                    )}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setEditingTask(task)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        {task.status !== 'Done' && (
                          <DropdownMenuItem onClick={() => handleStatusChange(task.id, 'Done')}>
                            <CheckSquare className="h-4 w-4 mr-2" />
                            Mark as Done
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem 
                          onClick={() => handleDeleteTask(task.id)}
                          className="text-destructive"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {task.description && (
                  <p className="text-sm text-muted-foreground">{task.description}</p>
                )}
                
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <User className="h-4 w-4" />
                  <span>{task.assignee.fullName}</span>
                </div>
                
                {task.dueDate && (
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    <span>Due: {new Date(task.dueDate).toLocaleDateString()}</span>
                  </div>
                )}
                
                {/* Related entities */}
                <div className="space-y-1">
                  {task.lead && (
                    <div className="text-sm text-muted-foreground">
                      👤 Lead: {task.lead.fullName}
                    </div>
                  )}
                  
                  {task.deal && (
                    <div className="text-sm text-muted-foreground">
                      💼 Deal: {task.deal.title}
                    </div>
                  )}
                  
                  {task.property && (
                    <div className="text-sm text-muted-foreground">
                      🏠 Property: {task.property.code} - {task.property.city}
                    </div>
                  )}
                </div>
                
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground">
                    Created: {new Date(task.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={<CheckSquare className="h-12 w-12" />}
          title="No tasks found"
          description="Create your first task to get started with task management."
          action={{
            label: 'Add Task',
            onClick: () => setFormOpen(true),
          }}
        />
      )}

      {/* Forms */}
      <TaskForm
        open={formOpen}
        onOpenChange={setFormOpen}
        onSubmit={handleCreateTask}
        mode="create"
      />

      {editingTask && (
        <TaskForm
          open={!!editingTask}
          onOpenChange={(open) => !open && setEditingTask(null)}
          onSubmit={handleEditTask}
          initialData={editingTask}
          mode="edit"
        />
      )}
    </div>
  )
}