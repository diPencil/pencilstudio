'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { EmptyState } from '@/components/ui/empty-state'
import { PropertyForm } from '@/components/forms/property-form'
import { useLocale } from '@/components/providers/locale-provider'
import { Building, Plus, Edit, Trash2, MapPin, Bed, Bath, Square } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { MoreHorizontal } from 'lucide-react'

interface Property {
  id: string
  code: string
  type: {
    id: string
    name: string
  }
  status: {
    id: string
    name: string
  }
  city: string
  area?: string
  bedrooms?: number
  bathrooms?: number
  sizeSqm?: number
  price?: number
  owner?: {
    id: string
    name: string
  }
  createdAt: string
}

interface PropertiesData {
  data: Property[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

export default function PropertiesPage() {
  const { messages } = useLocale()
  const [properties, setProperties] = useState<PropertiesData | null>(null)
  const [loading, setLoading] = useState(true)
  const [formOpen, setFormOpen] = useState(false)
  const [editingProperty, setEditingProperty] = useState<Property | null>(null)

  const fetchProperties = async () => {
    try {
      const response = await fetch('/api/properties')
      if (response.ok) {
        const data = await response.json()
        setProperties(data)
      }
    } catch (error) {
      console.error('Failed to fetch properties:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchProperties()
  }, [])

  const handleCreateProperty = async (data: any) => {
    try {
      const response = await fetch('/api/properties', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchProperties()
      }
    } catch (error) {
      console.error('Failed to create property:', error)
    }
  }

  const handleEditProperty = async (data: any) => {
    if (!editingProperty) return

    try {
      const response = await fetch(`/api/properties/${editingProperty.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        await fetchProperties()
        setEditingProperty(null)
      }
    } catch (error) {
      console.error('Failed to update property:', error)
    }
  }

  const handleDeleteProperty = async (id: string) => {
    if (!confirm('Are you sure you want to delete this property?')) return

    try {
      const response = await fetch(`/api/properties/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        await fetchProperties()
      }
    } catch (error) {
      console.error('Failed to delete property:', error)
    }
  }
  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      AVAILABLE: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      UNDER_OFFER: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
      SOLD: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
      RENTED: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
    }
    return colors[status] || 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300'
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">
          {messages?.common?.loading || 'Loading...'}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">
            {messages?.properties?.title || 'Properties'}
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage your property inventory and listings
          </p>
        </div>
        <Button onClick={() => setFormOpen(true)} className="shadow-sm">
          <Plus className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
          {messages?.properties?.addProperty || 'Add Property'}
        </Button>
      </div>

      {/* Stats Cards */}
      {properties && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Building className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Properties</p>
                  <p className="text-2xl font-bold">{properties.pagination.total}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Available</p>
                  <p className="text-2xl font-bold">
                    {properties.data.filter(p => p.status?.name === 'Available').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-red-500 rounded-full" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Sold</p>
                  <p className="text-2xl font-bold">
                    {properties.data.filter(p => p.status?.name === 'Sold').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Rented</p>
                  <p className="text-2xl font-bold">
                    {properties.data.filter(p => p.status?.name === 'Rented').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Properties Grid */}
      {properties?.data.length ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {properties.data.map((property) => (
            <Card key={property.id} className="hover:shadow-lg transition-all duration-200 border-l-4 border-l-primary/20">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-semibold">{property.code}</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Badge className={getStatusColor(property.status?.name || 'AVAILABLE')}>
                      {property.status?.name || 'Available'}
                    </Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setEditingProperty(property)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive">
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">
                    {property.type?.name || 'Unknown Type'}
                  </span>
                  {property.price && (
                    <span className="font-bold text-lg text-primary">
                      {property.price.toLocaleString()} جنيه
                    </span>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => {
                      // Create listing for this property
                      setFormOpen(true)
                      // You can pre-fill the property in the form
                    }}
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Create Listing
                  </Button>
                </div>
                
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <span>{property.city}{property.area && `, ${property.area}`}</span>
                </div>
                
                {(property.bedrooms || property.bathrooms || property.sizeSqm) && (
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    {property.bedrooms && (
                      <div className="flex items-center space-x-1">
                        <Bed className="h-4 w-4" />
                        <span>{property.bedrooms}</span>
                      </div>
                    )}
                    {property.bathrooms && (
                      <div className="flex items-center space-x-1">
                        <Bath className="h-4 w-4" />
                        <span>{property.bathrooms}</span>
                      </div>
                    )}
                    {property.sizeSqm && (
                      <div className="flex items-center space-x-1">
                        <Square className="h-4 w-4" />
                        <span>{property.sizeSqm}m²</span>
                      </div>
                    )}
                  </div>
                )}
                
                {property.owner && (
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <span>Owner: {property.owner.name}</span>
                  </div>
                )}
                
                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground">
                    Created: {new Date(property.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={<Building className="h-12 w-12" />}
          title="No properties found"
          description="Start by adding your first property to the system."
          action={{
            label: messages?.properties?.addProperty || 'Add Property',
            onClick: () => setFormOpen(true),
          }}
        />
      )}

      {/* Forms */}
      <PropertyForm
        open={formOpen}
        onOpenChange={setFormOpen}
        onSubmit={handleCreateProperty}
        mode="create"
      />

      {editingProperty && (
        <PropertyForm
          open={!!editingProperty}
          onOpenChange={(open) => !open && setEditingProperty(null)}
          onSubmit={handleEditProperty}
          initialData={editingProperty}
          mode="edit"
        />
      )}
    </div>
  )
}