'use client'

import './globals.css'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { ThemeProvider } from '@/components/providers/theme-provider'
import { AuthProvider } from '@/lib/auth-context'
import { LocaleProvider } from '@/components/providers/locale-provider'
import { getMessages, defaultLocale } from '@/lib/i18n'
import { useEffect, useState } from 'react'

const inter = Inter({ subsets: ['latin'] })

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [messages, setMessages] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function loadMessages() {
      try {
        const msgs = await getMessages(defaultLocale)
        setMessages(msgs)
      } catch (error) {
        console.error('Failed to load messages:', error)
        setMessages({}) // fallback to empty object
      } finally {
        setIsLoading(false)
      }
    }
    
    loadMessages()
  }, [])

  if (isLoading) {
    return (
      <html lang={defaultLocale} dir="ltr">
        <body className={inter.className}>
          <div className="flex items-center justify-center h-screen">
            <div className="text-muted-foreground">Loading...</div>
          </div>
        </body>
      </html>
    )
  }

  return (
    <html lang={defaultLocale} dir="ltr">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
          <AuthProvider>
            <LocaleProvider initialMessages={messages || {}}>
              {children}
            </LocaleProvider>
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}