import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { jwtVerify } from 'jose'
import { dbOperations } from '@/lib/db'
import { z } from 'zod'

const listingSchema = z.object({
  propertyId: z.string().min(1, 'Property is required'),
  channelId: z.string().min(1, 'Channel is required'),
  title: z.string().optional(),
  description: z.string().optional(),
  priceOverride: z.number().min(0).optional(),
  media: z.array(z.string()).optional(),
  status: z.enum(['Draft', 'Published', 'Paused', 'Ended']).default('Draft'),
  publishAt: z.string().optional(),
  endAt: z.string().optional(),
  url: z.string().optional(),
})

const secret = new TextEncoder().encode(process.env.JWT_SECRET || 'your-secret-key-here-make-it-long-and-secure')

async function getUser() {
  try {
    const cookieStore = cookies()
    const token = cookieStore.get('auth-token')
    if (!token) return null
    
    const { payload } = await jwtVerify(token.value, secret)
    return {
      id: payload.userId as string,
      email: payload.email as string,
      name: payload.name as string,
      role: payload.role as string
    }
  } catch {
    return null
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') ?? '1')
    const limit = parseInt(searchParams.get('limit') ?? '10')
    const channel = searchParams.get('channel')
    const status = searchParams.get('status')
    const city = searchParams.get('city')

    const result = await dbOperations.getListings(page, limit, { 
      channel: channel || undefined, 
      status: status || undefined, 
      city: city || undefined 
    })
    return NextResponse.json(result)
  } catch (error) {
    console.error('Listings API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const validatedData = listingSchema.parse(body)

    const newListing = await dbOperations.createListing(validatedData)

    return NextResponse.json(newListing)
  } catch (error) {
    console.error('Create listing error:', error)
    return NextResponse.json(
      { error: 'Failed to create listing' },
      { status: 500 }
    )
  }
}