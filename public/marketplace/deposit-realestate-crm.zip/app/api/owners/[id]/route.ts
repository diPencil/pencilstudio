import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { jwtVerify } from 'jose'
import { dbOperations } from '@/lib/db'
import { z } from 'zod'

const ownerSchema = z.object({
  name: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email().optional().or(z.literal('')),
  company: z.string().optional(),
  nationalId: z.string().optional(),
  preferredContact: z.enum(['call', 'whatsapp', 'email']).optional(),
  payoutDetails: z.string().optional(),
  notes: z.string().optional(),
})

const secret = new TextEncoder().encode(process.env.JWT_SECRET || 'your-secret-key-here-make-it-long-and-secure')

async function getUser() {
  try {
    const cookieStore = cookies()
    const token = cookieStore.get('auth-token')
    if (!token) return null
    
    const { payload } = await jwtVerify(token.value, secret)
    return {
      id: payload.userId as string,
      email: payload.email as string,
      name: payload.name as string,
      role: payload.role as string
    }
  } catch {
    return null
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const owner = await dbOperations.getOwnerById(params.id)
    if (!owner) {
      return NextResponse.json({ error: 'Owner not found' }, { status: 404 })
    }

    return NextResponse.json(owner)
  } catch (error) {
    console.error('Get owner error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const validatedData = ownerSchema.parse(body)

    const updatedOwner = await dbOperations.updateOwner(params.id, validatedData)
    if (!updatedOwner) {
      return NextResponse.json({ error: 'Owner not found' }, { status: 404 })
    }

    return NextResponse.json(updatedOwner)
  } catch (error) {
    console.error('Update owner error:', error)
    return NextResponse.json(
      { error: 'Failed to update owner' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const success = await dbOperations.deleteOwner(params.id)
    if (!success) {
      return NextResponse.json({ error: 'Owner not found' }, { status: 404 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Delete owner error:', error)
    return NextResponse.json(
      { error: 'Failed to delete owner' },
      { status: 500 }
    )
  }
}