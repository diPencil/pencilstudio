import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { jwtVerify } from 'jose'
import { dbOperations } from '@/lib/db'
import { z } from 'zod'

const leadSourceSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  channel: z.string().optional(),
  isActive: z.boolean().default(true),
})

const secret = new TextEncoder().encode(process.env.JWT_SECRET || 'your-secret-key-here-make-it-long-and-secure')

async function getUser() {
  try {
    const cookieStore = cookies()
    const token = cookieStore.get('auth-token')
    if (!token) return null
    
    const { payload } = await jwtVerify(token.value, secret)
    return {
      id: payload.userId as string,
      email: payload.email as string,
      name: payload.name as string,
      role: payload.role as string
    }
  } catch {
    return null
  }
}

export async function GET() {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const sources = await dbOperations.getLeadSources()
    return NextResponse.json(sources)
  } catch (error) {
    console.error('Lead sources API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const validatedData = leadSourceSchema.parse(body)

    const newSource = await dbOperations.createLeadSource(validatedData)
    return NextResponse.json(newSource)
  } catch (error) {
    console.error('Create lead source error:', error)
    return NextResponse.json(
      { error: 'Failed to create lead source' },
      { status: 500 }
    )
  }
}