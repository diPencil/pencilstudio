import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { jwtVerify } from 'jose'
import { dbOperations } from '@/lib/db'

const secret = new TextEncoder().encode(process.env.JWT_SECRET || 'your-secret-key-here-make-it-long-and-secure')

async function getUser() {
  try {
    const cookieStore = cookies()
    const token = cookieStore.get('auth-token')
    if (!token) return null
    
    const { payload } = await jwtVerify(token.value, secret)
    return {
      id: payload.userId as string,
      email: payload.email as string,
      name: payload.name as string,
      role: payload.role as string
    }
  } catch {
    return null
  }
}

export async function GET() {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const stages = await dbOperations.getDealStages()
    return NextResponse.json(stages)
  } catch (error) {
    console.error('Deal stages API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const newStage = await dbOperations.createDealStage(body)
    return NextResponse.json(newStage)
  } catch (error) {
    console.error('Create deal stage error:', error)
    return NextResponse.json(
      { error: 'Failed to create deal stage' },
      { status: 500 }
    )
  }
}