import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { jwtVerify } from 'jose'
import { dbOperations } from '@/lib/db'
import { z } from 'zod'

const activitySchema = z.object({
  type: z.enum(['call', 'email', 'whatsapp', 'meeting', 'viewing', 'note']),
  at: z.string().min(1),
  direction: z.enum(['inbound', 'outbound']).optional(),
  duration: z.number().min(0).optional(),
  outcome: z.enum(['connected', 'no_answer', 'rescheduled', 'interested', 'not_interested', 'completed']).optional(),
  notes: z.string().optional(),
  leadId: z.string().optional(),
  ownerId: z.string().optional(),
  dealId: z.string().optional(),
  propertyId: z.string().optional(),
})

const secret = new TextEncoder().encode(process.env.JWT_SECRET || 'your-secret-key-here-make-it-long-and-secure')

async function getUser() {
  try {
    const cookieStore = cookies()
    const token = cookieStore.get('auth-token')
    if (!token) return null
    
    const { payload } = await jwtVerify(token.value, secret)
    return {
      id: payload.userId as string,
      email: payload.email as string,
      name: payload.name as string,
      role: payload.role as string
    }
  } catch {
    return null
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') ?? '1')
    const limit = parseInt(searchParams.get('limit') ?? '10')
    const leadId = searchParams.get('leadId')
    const dealId = searchParams.get('dealId')

    const result = await dbOperations.getActivities(leadId || undefined, dealId || undefined, page, limit)
    return NextResponse.json(result)
  } catch (error) {
    console.error('Activities API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const validatedData = activitySchema.parse(body)

    const newActivity = await dbOperations.createActivity({
      ...validatedData,
      userId: user.id
    })

    return NextResponse.json(newActivity)
  } catch (error) {
    console.error('Create activity error:', error)
    return NextResponse.json(
      { error: 'Failed to create activity' },
      { status: 500 }
    )
  }
}