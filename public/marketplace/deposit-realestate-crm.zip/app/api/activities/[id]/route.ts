import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { jwtVerify } from 'jose'
import { dbOperations } from '@/lib/db'
import { z } from 'zod'

const activitySchema = z.object({
  type: z.enum(['call', 'email', 'whatsapp', 'meeting', 'viewing', 'note']).optional(),
  direction: z.enum(['inbound', 'outbound']).optional(),
  leadId: z.string().optional(),
  ownerId: z.string().optional(),
  dealId: z.string().optional(),
  propertyId: z.string().optional(),
  at: z.string().optional(),
  duration: z.number().min(0).optional(),
  outcome: z.enum(['connected', 'no_answer', 'rescheduled', 'interested', 'not_interested', 'completed']).optional(),
  notes: z.string().optional(),
})

const secret = new TextEncoder().encode(process.env.JWT_SECRET || 'your-secret-key-here-make-it-long-and-secure')

async function getUser() {
  try {
    const cookieStore = cookies()
    const token = cookieStore.get('auth-token')
    if (!token) return null
    
    const { payload } = await jwtVerify(token.value, secret)
    return {
      id: payload.userId as string,
      email: payload.email as string,
      name: payload.name as string,
      role: payload.role as string
    }
  } catch {
    return null
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const validatedData = activitySchema.parse(body)

    const updatedActivity = await dbOperations.updateActivity(params.id, validatedData)
    if (!updatedActivity) {
      return NextResponse.json({ error: 'Activity not found' }, { status: 404 })
    }

    return NextResponse.json(updatedActivity)
  } catch (error) {
    console.error('Update activity error:', error)
    return NextResponse.json(
      { error: 'Failed to update activity' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const success = await dbOperations.deleteActivity(params.id)
    if (!success) {
      return NextResponse.json({ error: 'Activity not found' }, { status: 404 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Delete activity error:', error)
    return NextResponse.json(
      { error: 'Failed to delete activity' },
      { status: 500 }
    )
  }
}