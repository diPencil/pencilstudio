import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { jwtVerify } from 'jose'
import { dbOperations } from '@/lib/db'
import { z } from 'zod'

const dealSchema = z.object({
  leadId: z.string().min(1),
  title: z.string().optional(),
  propertyId: z.string().optional(),
  value: z.number().min(0).optional(),
  currency: z.string().default('EGP'),
  stageId: z.string().min(1),
  probability: z.number().min(0).max(100).optional(),
  expectedCloseDate: z.string().optional(),
  assignedTo: z.string().optional(),
  nextStep: z.string().optional(),
  notes: z.string().optional(),
})

const secret = new TextEncoder().encode(process.env.JWT_SECRET || 'your-secret-key-here-make-it-long-and-secure')

async function getUser() {
  try {
    const cookieStore = cookies()
    const token = cookieStore.get('auth-token')
    if (!token) return null
    
    const { payload } = await jwtVerify(token.value, secret)
    return {
      id: payload.userId as string,
      email: payload.email as string,
      name: payload.name as string,
      role: payload.role as string
    }
  } catch {
    return null
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') ?? '1')
    const limit = parseInt(searchParams.get('limit') ?? '10')

    const result = await dbOperations.getDeals(page, limit)
    return NextResponse.json(result)
  } catch (error) {
    console.error('Deals API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const validatedData = dealSchema.parse(body)

    // Auto-generate title if not provided
    const dealData = {
      ...validatedData,
      title: validatedData.title || `Deal - ${Date.now()}`,
      assignedTo: validatedData.assignedTo || user.id
    }

    const newDeal = await dbOperations.createDeal(dealData)

    return NextResponse.json(newDeal)
  } catch (error) {
    console.error('Create deal error:', error)
    return NextResponse.json(
      { error: 'Failed to create deal' },
      { status: 500 }
    )
  }
}