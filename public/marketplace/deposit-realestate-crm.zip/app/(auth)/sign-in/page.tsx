'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form'
import { signInSchema, SignInFormData } from '@/lib/validators/auth'
import { useLocale } from '@/components/providers/locale-provider'
import { LanguageSwitcher } from '@/components/shell/language-switcher'
import { ThemeToggle } from '@/components/shell/theme-toggle'
import { useAuth } from '@/lib/auth-context'

export default function SignInPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const router = useRouter()
  const { messages } = useLocale()
  const { signIn } = useAuth()

  const form = useForm<SignInFormData>({
    resolver: zodResolver(signInSchema),
    defaultValues: {
      email: 'admin@crm.local',
      password: 'Admin@123',
    },
  })

  async function onSubmit(data: SignInFormData) {
    setIsLoading(true)
    setError('')
    
    try {
      console.log('Attempting sign in with:', data.email)
      const success = await signIn(data.email, data.password)

      if (!success) {
        setError(messages?.auth?.invalidCredentials || 'Invalid credentials')
      } else {
        console.log('Sign in successful, redirecting...')
        router.push('/dashboard')
      }
    } catch (error) {
      console.error('Sign in error:', error)
      setError('خطأ في تسجيل الدخول - تأكد من البيانات')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="absolute top-4 right-4 flex space-x-2">
        <LanguageSwitcher />
        <ThemeToggle />
      </div>

      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center">
            Deposit CRM
          </CardTitle>
          <CardDescription className="text-center">
            {messages?.auth?.welcome || 'مرحباً بك في نظام إدارة العقارات'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{messages?.auth?.email || 'Email'}</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="email"
                        placeholder="admin@crm.local"
                        disabled={isLoading}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{messages?.auth?.password || 'Password'}</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="password"
                        placeholder="••••••••"
                        disabled={isLoading}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {error && (
                <div className="text-sm text-destructive text-center">
                  {error}
                </div>
              )}

              <Button
                type="submit"
                className="w-full"
                disabled={isLoading}
              >
                {isLoading 
                  ? (messages?.common?.loading || 'Loading...') 
                  : (messages?.auth?.signIn || 'Sign In')
                }
              </Button>
            </form>
          </Form>

          <div className="mt-6 text-sm text-center text-muted-foreground">
            <p>Demo credentials:</p>
            <p><strong>Email:</strong> admin@crm.local</p>
            <p><strong>Password:</strong> Admin@123</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}