'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function HomePage() {
  const router = useRouter()

  useEffect(() => {
    router.push('/sign-in')
  }, [router])

  return (
    <div className="flex items-center justify-center h-screen">
      <div className="text-muted-foreground">Redirecting...</div>
    </div>
  )
}