import type { TranslationNamespace } from '../localization/translation-registry'

export const authMetadataCopy = {
  login: {
    title: { en: 'Sign In', es: 'Iniciar sesión', it: 'Accedi' , ar: "تسجيل الدخول" },
    description: { en: 'Sign in to your TravNeeds account to manage bookings and trips.', es: 'Inicia sesión en tu cuenta de TravNeeds para gestionar reservas y viajes.', it: 'Accedi al tuo account TravNeeds per gestire prenotazioni e viaggi.' , ar: "سجّل الدخول إلى حسابك في TravNeeds لإدارة حجوزاتك ورحلاتك." },
  },
  register: {
    title: { en: 'Create Account', es: 'Crear cuenta', it: 'Crea un account' , ar: "إنشاء حساب" },
    description: { en: 'Create your TravNeeds account to book Egypt trips and manage your travel.', es: 'Crea tu cuenta de TravNeeds para reservar viajes a Egipto y gestionar tu viaje.', it: 'Crea il tuo account TravNeeds per prenotare viaggi in Egitto e gestire il tuo viaggio.' , ar: "أنشئ حسابك في TravNeeds لحجز رحلات مصر وإدارة سفرك." },
  },
  forgotPassword: {
    title: { en: 'Forgot Password', es: 'Recuperar contraseña', it: 'Recupera password' , ar: "استعادة كلمة المرور" },
    description: { en: 'Reset your TravNeeds account password.', es: 'Restablece la contraseña de tu cuenta de TravNeeds.', it: 'Reimposta la password del tuo account TravNeeds.' , ar: "استعد كلمة مرور حسابك في TravNeeds." },
  },
  resetPassword: {
    title: { en: 'Reset Password', es: 'Restablecer contraseña', it: 'Reimposta password' , ar: "إعادة تعيين كلمة المرور" },
    description: { en: 'Set a new password for your TravNeeds account.', es: 'Establece una nueva contraseña para tu cuenta de TravNeeds.', it: 'Imposta una nuova password per il tuo account TravNeeds.' , ar: "عيّن كلمة مرور جديدة لحسابك في TravNeeds." },
  },
} as const

export const authMetadataNamespace: TranslationNamespace = { namespace: 'customer.auth', messages: Object.fromEntries(
  Object.entries(authMetadataCopy).flatMap(([page, fields]) => Object.entries(fields).map(([field, copy]) => [page + '.' + field, copy])),
) }
