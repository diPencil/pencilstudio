import type { Metadata } from 'next'
import type { Locale } from '../localization/locale-config'
import type { authMetadataCopy } from './auth-metadata-messages'
import { translate } from '../localization/platform-translations'

export function authPageMetadata(page: keyof typeof authMetadataCopy, locale: Locale): Metadata {
  return {
    title: translate(locale, 'customer.auth.' + page + '.title'),
    description: translate(locale, 'customer.auth.' + page + '.description'),
    robots: { index: false, follow: false, nocache: true },
  }
}
