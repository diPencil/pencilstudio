'use client';

import { useEffect, useMemo, useState } from 'react';
import { useCatalogueLanguage } from './use-catalogue-language';
import { validateCatalogueTranslations } from './catalogue-translations';
import { readJsonObject } from '../shared/json-text';
import type { Destination, MultiDayCategory } from '@/data/types';

/** Normalize one `/api/destinations` row to the shared domain shape. */
function toDestination(row: Record<string, unknown>): Destination {
  const detail = readJsonObject(row.detail);
  const strArray = (v: unknown): string[] =>
    Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : [];
  return {
    translations: row.translations ? validateCatalogueTranslations('destination', row.translations) : {},
    title: String(row.title ?? ''),
    slug: String(row.slug ?? ''),
    image: String(row.image ?? ''),
    copy: String(row.copy ?? ''),
    nameAr: typeof row.nameAr === 'string' ? row.nameAr : undefined,
    copyAr: typeof row.copyAr === 'string' ? row.copyAr : undefined,
    showInOneDayTours: row.showInOneDayTours === true ? true : undefined,
    showInDestinations: row.showInDestinations === false ? false : undefined,
    isPublished: row.isPublished === false ? false : undefined,
    displayOrder: typeof row.displayOrder === 'number' ? row.displayOrder : 999,
    detail: {
      heroImage: String(detail.heroImage ?? row.image ?? ''),
      heroAlt: String(detail.heroAlt ?? row.title ?? ''),
      eyebrow: String(detail.eyebrow ?? ''),
      intro: String(detail.intro ?? row.copy ?? ''),
      facts: Array.isArray(detail.facts) ? detail.facts : [],
      bestFor: strArray(detail.bestFor),
      experiences: Array.isArray(detail.experiences) ? detail.experiences : [],
      rhythm: Array.isArray(detail.rhythm) ? detail.rhythm : [],
      practical: Array.isArray(detail.practical) ? detail.practical : [],
      tourSlugs: strArray(detail.tourSlugs),
    },
  };
}

/** Normalize one `/api/multi-day-categories` row to the shared domain shape. */
function toCategory(row: Record<string, unknown>): MultiDayCategory {
  return {
    translations: row.translations ? validateCatalogueTranslations('category', row.translations) : {},
    slug: String(row.slug ?? ''),
    name: String(row.name ?? ''),
    nameAr: String(row.nameAr ?? ''),
    copy: String(row.copy ?? ''),
    copyAr: String(row.copyAr ?? ''),
    image: String(row.image ?? ''),
    order: typeof row.order === 'number' ? row.order : 999,
    active: row.active !== false,
  };
}

type CacheEntry<T> = { list: T[] | null; inflight: Promise<T[] | null> | null; listeners: Set<() => void>; error: string | null };

export type DbListStatus<T> = {
  /** DB list only  -  null until the API resolves. Never bootstrap data. */
  data: T[] | null;
  loading: boolean;
  error: string | null;
  retry(): void;
  /** Drop the cached rows and refetch from the API in place, without a
   * full page reload, so write-back screens can update the open table. */
  refresh(): void;
};

function createCache<T>(url: string, map: (row: Record<string, unknown>) => T | null, label: string): CacheEntry<T> & { load(): void; invalidate(): void; use(base: readonly T[]): T[]; useStatus(): DbListStatus<T> } {
  const entry: CacheEntry<T> = { list: null, inflight: null, listeners: new Set(), error: null };
  let generation = 0;
  let lastFetchedAt = 0;
  const STALE_MS = 30_000;
  const load = (force = false) => {
    if ((entry.list && !force && Date.now() - lastFetchedAt < STALE_MS) || entry.inflight) return;
    const current = ++generation;
    entry.error = null;
    entry.inflight = (async () => {
      try {
        const fetchUrl = url + (url.includes('?') ? '&' : '?') + '_t=' + Date.now();
        const res = await fetch(fetchUrl, { credentials: 'same-origin', cache: 'no-store' });
        if (!res.ok) {
          if (current === generation) entry.error = `Request failed (${res.status}).`;
          return null;
        }
        const data = (await res.json()) as Record<string, unknown>;
        const rows = data.destinations ?? data.categories;
        if (!Array.isArray(rows)) {
          if (current === generation) entry.error = `Unexpected response (${label}).`;
          return null;
        }
        const mapped = (rows as Record<string, unknown>[])
          .map((row) => {
            try {
              return map(row);
            } catch {
              return null;
            }
          })
          .filter((v): v is T => Boolean(v));
        return mapped;
      } catch {
        if (current === generation) entry.error = `Could not reach the database (${label}).`;
        return null;
      } finally {
        if (current === generation) entry.inflight = null;
      }
    })();
    void entry.inflight.then((list) => {
      if (current !== generation) return;
      if (list) {
        entry.list = list;
        lastFetchedAt = Date.now();
      }
      entry.listeners.forEach((notify) => notify());
    });
  };
  return {
    ...entry,
    load,
    invalidate() {
      generation++;
      entry.list = null;
      lastFetchedAt = 0;
      entry.inflight = null;
      entry.error = null;
      entry.listeners.forEach((notify) => notify());
      if (entry.listeners.size) load(true);
    },
    use(base: readonly T[]): T[] {
      // Bumped when the shared DB cache resolves so the memo below recomputes.
      const [version, setVersion] = useState(0);
      useEffect(() => {
        const notify = () => setVersion((n) => n + 1);
        entry.listeners.add(notify);
        if (!entry.list || Date.now() - lastFetchedAt >= STALE_MS) {
          load(!entry.list ? false : true);
        }
        const onVisibilityOrFocus = () => {
          if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
            if (Date.now() - lastFetchedAt >= STALE_MS) {
              load(true);
            }
          }
        };
        if (typeof window !== 'undefined') {
          window.addEventListener('visibilitychange', onVisibilityOrFocus);
          window.addEventListener('focus', onVisibilityOrFocus);
        }
        return () => {
          entry.listeners.delete(notify);
          if (typeof window !== 'undefined') {
            window.removeEventListener('visibilitychange', onVisibilityOrFocus);
            window.removeEventListener('focus', onVisibilityOrFocus);
          }
        };
      }, []);
      // Referentially stable: identical `base` yields an identical result,
      // so consumers can safely depend on it in effects without render
      // loops. Full DB list wins (admin creates new slugs outside the
      // bootstrap set); the bootstrap catalogue renders until it arrives.
      return useMemo(() => entry.list ?? [...base], [base, version]);
    },
    useStatus(): DbListStatus<T> {
      // Bumped when the shared DB cache resolves or fails.
      const [version, setVersion] = useState(0);
      useEffect(() => {
        const notify = () => setVersion((n) => n + 1);
        entry.listeners.add(notify);
        load();
        return () => {
          entry.listeners.delete(notify);
        };
      }, []);
      return useMemo(
        () => ({
          // Admin-only: the DB list or null. Bootstrap data is NEVER
          // substituted here so a broken DB runtime cannot look healthy.
          data: entry.list,
          loading: entry.list === null && entry.error === null,
          error: entry.list === null ? entry.error : null,
          retry: () => {
            generation++;
            entry.error = null;
            entry.inflight = null;
            setVersion((n) => n + 1);
            load();
          },
          refresh: () => {
            generation++;
            entry.list = null;
            entry.error = null;
            entry.inflight = null;
            setVersion((n) => n + 1);
            load();
          },
        }),
        [version],
      );
    },
  };
}

const destinationsCache = createCache<Destination>('/api/destinations', (row) => {
  const item = toDestination(row);
  return item.slug ? item : null;
}, 'destinations');

// Keep private editor rows out of the public catalogue cache across navigation.
const adminDestinationsCache = createCache<Destination>('/api/destinations?admin=1', (row) => {
  const item = toDestination(row);
  return item.slug ? item : null;
}, 'destinations');

const categoriesCache = createCache<MultiDayCategory>('/api/multi-day-categories', (row) => {
  const item = toCategory(row);
  return item.slug ? item : null;
}, 'categories');

/**
 * Drop cached DB lists so the next read refetches. Call after any
 * successful POST/PUT/DELETE so admin + public views stay truthful.
 */
export function invalidateCatalogueCache() {
  destinationsCache.invalidate();
  adminDestinationsCache.invalidate();
  categoriesCache.invalidate();
}

/**
 * Normalize free-form admin input into a DB catalogue slug
 * (lowercase letters, numbers, hyphens, max 80 chars, no prefix).
 */
export function dbSlugify(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9\u0600-\u06FF]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
}

/**
 * DB-backed destination list for client components (public + admin).
 * No browser storage is consulted.
 */
export function useDbDestinations(_base: readonly Destination[]): Destination[] {
  return useCatalogueLanguage(destinationsCache.use([]), 'destination');
}

/**
 * DB-backed multi-day category list for client components (public + admin).
 * No browser storage is consulted.
 */
export function useDbCategories(base: readonly MultiDayCategory[]): MultiDayCategory[] {
  return useCatalogueLanguage(categoriesCache.use(base), 'category');
}

/**
 * Failure-aware destination list for ADMIN screens. `data` is the DB
 * list or null while loading/failed  -  bootstrap data is never
 * substituted, so a broken DB runtime cannot look healthy.
 */
export function useDbDestinationsStatus(): DbListStatus<Destination> {
  return adminDestinationsCache.useStatus();
}

/**
 * Failure-aware multi-day category list for ADMIN screens. Same
 * no-fallback contract as `useDbDestinationsStatus`.
 */
export function useDbCategoriesStatus(): DbListStatus<MultiDayCategory> {
  return categoriesCache.useStatus();
}

/** Public cache stays separate from private rows and never invents bootstrap records. */
export function usePublicDestinationsStatus({ revalidateOnMount = true }: { revalidateOnMount?: boolean } = {}): DbListStatus<Destination> {
  const status = destinationsCache.useStatus();
  const [started, setStarted] = useState(false);
  // A fresh server seed must beat a warm browser cache on navigation.
  // Revalidate every mount, retaining generation protection for old requests.
  useEffect(() => { if (revalidateOnMount) status.refresh(); setStarted(true); }, []);
  const localized = useCatalogueLanguage(status.data ?? [], 'destination');
  return { ...status, data: !started || status.data === null ? null : localized, error: started ? status.error : null };
}
