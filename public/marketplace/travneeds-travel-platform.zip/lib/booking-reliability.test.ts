import { test } from 'vitest';
import assert from 'node:assert/strict';
import {
  cartKey,
  removeAddonFromCartItem,
  sanitizeCartItem,
  isHotelCartItem,
  isTourCartItem,
  type CartItem,
  type HotelCartItem,
  type TourCartItem,
} from './cart';
import { estimateCart, resolveCartLine, validateLineHeadcount } from './booking';
import type { Tour } from '@/data/types';


// 1. cartKey normalization
test('1. cartKey normalization', () => {
  const item1: Omit<CartItem, 'key'> = {
    tourSlug: 'cairo-day-tour',
    title: 'Cairo Day Tour',
    image: '',
    date: '2026-12-01',
    adults: 2,
    children: 1,
    infants: 0,
    addons: ['Lunch', 'Guide'],
    addonTotal: 30,
    adultUnit: 50,
    childUnit: 25,
    infantUnit: 0,
    total: 155,
  };
  const item2: Omit<CartItem, 'key'> = {
    ...item1,
    tourSlug: '  CAIRO-DAY-TOUR  ',
    addons: ['Guide', 'Lunch'], // different order
  };
  assert.equal(cartKey(item1), cartKey(item2), 'cartKey must be deterministic across addon order and slug casing');
  console.log('✅ PASSED: cartKey normalization and deterministic ordering');
});
// 2. Headcount boundaries
test('2. Headcount boundaries', () => {
  assert.equal(validateLineHeadcount({ adults: 0, children: 1, infants: 0 }), 'adults_required');
  assert.equal(validateLineHeadcount({ adults: 51, children: 0, infants: 0 }), 'adults_max');
  assert.equal(validateLineHeadcount({ adults: 2, children: 51, infants: 0 }), 'children_max');
  assert.equal(validateLineHeadcount({ adults: 2, children: 0, infants: 51 }), 'infants_max');
  assert.equal(validateLineHeadcount({ adults: 40, children: 20, infants: 5 }), 'total_max'); // 65 > 60
  assert.equal(validateLineHeadcount({ adults: 2, children: 2, infants: 1 }), null); // 5 is valid
  console.log('✅ PASSED: Headcount validation bounds (min 1 adult, max 50 per type, max 60 total)');
});
// 3. Dynamic published tour resolution
test('3. Dynamic published tour resolution', () => {
  const dynamicTour: Tour = {
    slug: 'new-published-luxor-trip',
    title: 'New Published Luxor Trip',
    category: 'multi-days-tours',
    location: 'Luxor',
    price: 300,
    duration: '3 Days',
    image: '/luxor.jpg',
    summary: 'A wonderful Luxor trip',
    detail: {
      overview: ['Overview'],
      highlights: [],
      itinerary: [],
      locations: [],
      addOns: [
        { title: 'Hot Air Balloon', price: 120 },
        { title: 'Private Photographer' }, // unpriced / on-request
      ],
    },
  };

  const cartItem: CartItem = {
    key: 'item-1',
    tourSlug: 'new-published-luxor-trip',
    title: 'New Published Luxor Trip',
    image: '/luxor.jpg',
    date: '2026-11-15',
    adults: 2,
    children: 0,
    infants: 0,
    addons: ['Hot Air Balloon', 'Private Photographer'],
    addonTotal: 120,
    adultUnit: 300,
    childUnit: 0,
    infantUnit: 0,
    total: 720,
  };

  // Without live catalog, dynamic tour would be stale
  const staleResolution = resolveCartLine(cartItem);
  assert.equal(staleResolution.stale, true, 'Without dynamic tour in catalog, it is marked stale');

  // With live catalog passed, it resolves cleanly!
  const liveResolution = resolveCartLine(cartItem, [dynamicTour]);
  assert.equal(liveResolution.stale, false, 'Dynamic tour from database resolves as valid');
  assert.equal(liveResolution.pricedAddons.length, 1);
  assert.equal(liveResolution.pricedAddons[0], 'Hot Air Balloon');
  assert.equal(liveResolution.onRequestAddons.length, 1);
  assert.equal(liveResolution.onRequestAddons[0], 'Private Photographer');
  assert.equal(liveResolution.addonTotal, 120, 'Unpriced add-on is NOT added to total and NOT free');
  console.log('✅ PASSED: Dynamic DB tours resolve cleanly and unpriced add-ons are kept on-request');
});
// 4. Hotel Cart Item sanitization and key generation
test('4. Hotel Cart Item sanitization and key generation', () => {
  const rawHotel = {
    itemType: 'hotel',
    hotelId: 'hotel-luxor-palace',
    hotelSlug: 'luxor-palace',
    hotelName: 'Luxor Palace Resort',
    roomTypeId: 'deluxe-suite',
    roomTypeName: 'Deluxe Nile Suite',
    ratePlanId: 'bb-standard',
    ratePlanName: 'Bed & Breakfast',
    checkInDate: '2026-12-10',
    checkOutDate: '2026-12-13',
    nights: 3,
    roomsCount: 1,
    adults: 2,
    children: 1,
    boardBasis: 'BB',
    pricePerNight: 150,
    total: 450,
  };

  const sanitized = sanitizeCartItem(rawHotel);
  assert.ok(sanitized, 'Hotel item must sanitize cleanly');
  assert.equal(isHotelCartItem(sanitized), true, 'Must be identified as hotel cart item');
  assert.equal(sanitized.itemType, 'hotel');
  assert.equal(sanitized.total, 450);
  assert.equal(sanitized.adults, 2);
  assert.equal(sanitized.children, 1);
  assert.equal(sanitized.nights, 3);
  assert.equal(sanitized.boardBasis, 'BB');

  const hotelSanitized = sanitized as HotelCartItem;
  const key1 = cartKey(hotelSanitized);
  const key2 = cartKey({ ...hotelSanitized, hotelId: '  HOTEL-LUXOR-PALACE  ' } as Omit<HotelCartItem, 'key'>);
  assert.equal(key1, key2, 'Hotel cart key must be case/whitespace normalized and deterministic');

  // Invalid check-in/out rejected
  assert.equal(sanitizeCartItem({ ...rawHotel, checkInDate: 'invalid-date' }), null, 'Invalid date rejected');
  assert.equal(sanitizeCartItem({ ...rawHotel, hotelName: '' }), null, 'Empty hotel name rejected');

  console.log('✅ PASSED: Hotel Cart Item sanitization, validation and deterministic key generation');
});
// 5. Hotel Cart Line resolution
test('5. Hotel Cart Line resolution', () => {
  const hotelItem: HotelCartItem = {
    key: 'hotel-key-1',
    itemType: 'hotel',
    hotelId: 'hotel-luxor-palace',
    hotelSlug: 'luxor-palace',
    hotelName: 'Luxor Palace Resort',
    title: 'Luxor Palace Resort — Deluxe Nile Suite',
    image: '/hotel-luxor.jpg',
    roomTypeId: 'deluxe-suite',
    roomTypeName: 'Deluxe Nile Suite',
    ratePlanId: 'bb-standard',
    ratePlanName: 'Bed & Breakfast',
    checkInDate: '2026-12-10',
    checkOutDate: '2026-12-13',
    nights: 3,
    roomsCount: 1,
    adults: 2,
    children: 1,
    infants: 0,
    boardBasis: 'BB',
    pricePerNight: 150,
    total: 450,
  };

  const resolved = resolveCartLine(hotelItem);
  assert.equal(resolved.stale, false, 'Hotel cart line is valid (not stale)');
  assert.equal(resolved.canonicalTotal, 450, 'Canonical total equals hotel display estimate');
  assert.equal(resolved.travelerTotal, 450);
  assert.equal(resolved.discountTotal, 0);
  assert.equal(resolved.adultUnit, 150);

  console.log('✅ PASSED: Hotel cart line resolves cleanly as non-stale line item');
});
// 6. Mixed Cart estimation (Tour + Hotel items)
test('6. Mixed Cart estimation (Tour + Hotel items)', () => {
  const tourItem: TourCartItem = {
    key: 'tour-key-1',
    itemType: 'tour',
    tourSlug: 'cairo-day-tour',
    title: 'Cairo Day Tour',
    image: '/cairo.jpg',
    date: '2026-12-05',
    adults: 2,
    children: 0,
    infants: 0,
    addons: [],
    addonTotal: 0,
    adultUnit: 100,
    childUnit: 50,
    infantUnit: 0,
    total: 200,
  };

  const hotelItem: HotelCartItem = {
    key: 'hotel-key-1',
    itemType: 'hotel',
    hotelId: 'hotel-luxor-palace',
    hotelSlug: 'luxor-palace',
    hotelName: 'Luxor Palace Resort',
    title: 'Luxor Palace Resort — Deluxe Nile Suite',
    image: '/hotel-luxor.jpg',
    roomTypeId: 'deluxe-suite',
    roomTypeName: 'Deluxe Nile Suite',
    ratePlanId: 'bb-standard',
    ratePlanName: 'Bed & Breakfast',
    checkInDate: '2026-12-10',
    checkOutDate: '2026-12-13',
    nights: 3,
    roomsCount: 1,
    adults: 2,
    children: 1,
    infants: 0,
    boardBasis: 'BB',
    pricePerNight: 150,
    total: 450,
  };

  // Mock catalog with cairo-day-tour
  const mockCatalog: Tour[] = [
    {
      slug: 'cairo-day-tour',
      title: 'Cairo Day Tour',
      category: 'one-day-tours',
      location: 'Cairo',
      price: 100,
      duration: '1 Day',
      image: '/cairo.jpg',
      summary: 'Cairo tour',
    },
  ];

  const estimate = estimateCart([tourItem, hotelItem], mockCatalog);
  assert.equal(estimate.lines.length, 2, 'Estimate contains both lines');
  assert.equal(estimate.validLines.length, 2, 'Both lines are valid');
  assert.equal(estimate.staleLines.length, 0, 'No stale lines');
  assert.equal(estimate.subtotal, 650, 'Subtotal correctly sums tour ($200) + hotel ($450) = $650');
  console.log('✅ PASSED: Mixed Cart estimate seamlessly calculates combined Tour + Hotel subtotal');
});
