import { expect, test } from 'vitest'
import { customerErrorCopy, customerErrorText } from './customer-error-copy'
import { authPageMetadata } from '../auth/auth-page-metadata'
import { SEARCH_TYPE_LABELS } from '../search/site-search'
import { platformTranslations } from '../localization/platform-translations'
import type { LocaleText } from '../localization/locale-config'
import { searchResultSummary } from '../search/search-copy'
import { searchPublishedContent } from '../search/site-search'
import { tours } from '@/data/tours'

test.each(Object.entries(customerErrorCopy))('Customer error has an Arabic presentation: %s', (message, copy) => {
  expect((copy as LocaleText).ar).toMatch(/[\u0600-\u06ff]/)
  expect(customerErrorText('ar', message)).toBe((copy as LocaleText).ar)
  for (const locale of ['en', 'es', 'it'] as const) expect(customerErrorText(locale, message)).toBe(copy[locale])
})

test('All 85 API lookup strings stay intact and unknown Arabic errors use safe localized fallback', () => {
  expect(Object.keys(customerErrorCopy)).toHaveLength(85)
  expect(customerErrorText('ar', 'Unmapped backend diagnostic')).toBe('حدث خطأ. حاول مجددًا.')
  expect(customerErrorText('ar', 'constructor')).toBe('حدث خطأ. حاول مجددًا.')
  expect(customerErrorText('ar', 'Database diagnostic for أحمد')).toBe('حدث خطأ. حاول مجددًا.')
  expect(customerErrorText('en', 'Unmapped backend diagnostic')).toBe('Unmapped backend diagnostic')
  expect(customerErrorText('ar', undefined, 'تعذر إتمام الحجز')).toBe('تعذر إتمام الحجز')
  expect(customerErrorText('ar', 'رسالة عربية موجودة')).toBe('رسالة عربية موجودة')
})

test.each([
  [0, 'لا توجد نتائج'], [1, 'نتيجة واحدة'], [2, 'نتيجتان'], [3, '٣ نتائج'], [11, '١١ نتيجة'], [100, '١٠٠ نتيجة'],
] as const)('Arabic result count %s uses Arabic plural forms without modifying query text', (count, expected) => {
  expect(searchResultSummary('ar', count, ' مصر ')).toBe(expected + ' عن "مصر"')
})

test.each(['en', 'es', 'it'] as const)('Search counts retain existing %s singular/plural copy', locale => {
  const expected = { en: ['1 result for "Egypt"', '2 results for "Egypt"'], es: ['1 resultado para "Egypt"', '2 resultados para "Egypt"'], it: ['1 risultato per "Egypt"', '2 risultati per "Egypt"'] }
  expect(searchResultSummary(locale, 1, 'Egypt')).toBe(expected[locale][0])
  expect(searchResultSummary(locale, 2, 'Egypt')).toBe(expected[locale][1])
})

test('Search selects existing Arabic entity content, retains canonical matching and never changes records or routes', () => {
  const tour = structuredClone(tours.find(item => item.detail)!)
  tour.status = 'published'
  tour.title = 'English canonical title'
  tour.detail!.translations = { ar: { title: 'رحلة الأهرامات', summary: 'وصف الرحلة العربية' } }
  const sources = { tours: [tour], destinations: [], events: [], offers: [], blogs: [] }
  const before = structuredClone(sources)
  expect(searchPublishedContent(sources, 'الأهرامات', 0, 'ar')[0]).toMatchObject({ title: 'رحلة الأهرامات', copy: 'وصف الرحلة العربية', href: `/all-tours/${tour.slug}` })
  expect(searchPublishedContent(sources, 'English canonical', 0, 'ar')[0].title).toBe('رحلة الأهرامات')
  expect(searchPublishedContent(sources, 'English canonical', 0)[0].title).toBe('English canonical title')
  expect(sources).toEqual(before)
})

test('Unpublished duplicate source content cannot replace a published search presentation', () => {
  const published = structuredClone(tours.find(item => item.detail)!)
  published.status = 'published'
  published.detail!.translations = { ar: { title: 'عنوان منشور' } }
  const draft = structuredClone(published)
  draft.status = 'draft'
  draft.detail!.translations = { ar: { title: 'عنوان مسودة مخفية' } }
  expect(searchPublishedContent({ tours: [published, draft], destinations: [], events: [], offers: [], blogs: [] }, '', 0, 'ar')[0].title).toBe('عنوان منشور')
})

test.each(['login', 'register', 'forgotPassword', 'resetPassword'] as const)('Auth metadata for %s has Arabic and retains private-page robots', page => {
  const metadata = authPageMetadata(page, 'ar')
  expect(metadata.title).toMatch(/[\u0600-\u06ff]/)
  expect(metadata.description).toMatch(/[\u0600-\u06ff]/)
  expect(metadata.robots).toEqual({ index: false, follow: false, nocache: true })
  expect(authPageMetadata(page, 'en').title).not.toEqual(metadata.title)
})

test('Search entity labels and customer namespaces are discoverable in the shared registry', () => {
  for (const copy of Object.values(SEARCH_TYPE_LABELS)) expect((copy as LocaleText).ar).toMatch(/[\u0600-\u06ff]/)
  const keys = platformTranslations.describe().map(item => item.key)
  expect(keys.filter(key => key.startsWith('customer.errors.'))).toHaveLength(86)
  expect(keys.filter(key => key.startsWith('customer.auth.'))).toHaveLength(8)
  expect(keys.some(key => key.startsWith('public.search.'))).toBe(true)
})
