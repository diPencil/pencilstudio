import type { Locale } from '../localization/locale-config'
import { translate } from '../localization/platform-translations'
import { customerErrorKeys } from './customer-error-messages'
export { customerErrorCopy } from './customer-error-messages'

// Translate at presentation time; never change API responses or their lookup strings.
export function customerErrorText(locale: Locale, message: unknown, fallback = translate(locale, 'customer.errors.fallback')): string {
  if (typeof message !== 'string' || !message) return fallback
  const key = customerErrorKeys.get(message)
  if (key) return translate(locale, 'customer.errors.' + key)
  // Keep existing Arabic UI notices; unknown English diagnostics use the safe fallback.
  if (locale === 'ar' && /^[\s\u200e\u200f]*[\u0621-\u064a\u066e-\u06d3\u06fa-\u06ff]/.test(message)) return message
  return locale === 'en' ? message : fallback
}
