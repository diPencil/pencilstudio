import { useSyncExternalStore } from 'react'

/**
 * Authoritative frontend cart contract.
 *
 * Supports Tour bookings and Hotel stays in a unified cart:
 * - Tour items: canonical tour slug, date, traveler counts, add-ons, display pricing.
 * - Hotel items: hotel/room/rate-plan IDs, check-in/out dates, occupancy, board basis, display pricing.
 *
 * Persisted cart data is UNTRUSTED browser input: every stored line is
 * sanitized on read (never crashes, never corrupts state).
 * The server remains authoritative for final availability and pricing.
 */
export type CartItemType = 'tour' | 'hotel'

export interface BaseCartItem {
  key: string
  itemType?: CartItemType
  title: string
  image: string
  adults: number
  children: number
  infants: number
  /**
   * Frontend estimate in USD base units, formatted at display time with the
   * active currency. The backend remains authoritative for final pricing.
   */
  total: number
}

export interface TourCartItem extends BaseCartItem {
  itemType?: 'tour'
  tourSlug: string
  /** Preferred/requested date (YYYY-MM-DD) or '' for an open date. No availability is implied. */
  date: string
  addons: readonly string[]
  addonTotal: number
  adultUnit: number
  childUnit: number
  infantUnit: number
}

export interface HotelCartItem extends BaseCartItem {
  itemType: 'hotel'
  hotelId: string
  hotelSlug: string
  hotelName: string
  roomTypeId: string
  roomTypeName: string
  ratePlanId: string
  ratePlanName: string
  checkInDate: string // YYYY-MM-DD
  checkOutDate: string // YYYY-MM-DD
  nights: number
  roomsCount: number
  childAges?: readonly number[]
  boardBasis: string
  pricePerNight: number
  lockToken?: string
  // Defensively typed properties for union compatibility
  tourSlug?: undefined
  date?: string
  addons?: readonly string[]
  addonTotal?: number
  adultUnit?: number
  childUnit?: number
  infantUnit?: number
}

export type CartItem = TourCartItem | HotelCartItem

export function isHotelCartItem(item: CartItem | Omit<CartItem, 'key'>): item is HotelCartItem {
  return (
    item.itemType === 'hotel' ||
    ('hotelId' in item && typeof (item as any).hotelId === 'string' && (item as any).hotelId.trim() !== '')
  )
}

export function isTourCartItem(item: CartItem | Omit<CartItem, 'key'>): item is TourCartItem {
  return !isHotelCartItem(item)
}

// Backend integration point: the cart persists in this browser only.
// Checkout builds a BookingRequestDraft (@/lib/booking) from these lines;
// the future backend service will receive that draft, revalidate it, and
// return the authoritative booking. No API calls exist yet.
const KEY = 'sp-cart'
const MAX_LINES = 20
const listeners = new Set<() => void>()
const EMPTY_CART: CartItem[] = []

const DATE_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/

function sanitizeDate(value: unknown): string {
  if (typeof value !== 'string' || value === '') return ''
  const match = DATE_PATTERN.exec(value)
  if (!match) return ''
  const year = Number(match[1])
  const month = Number(match[2])
  const day = Number(match[3])
  const date = new Date(Date.UTC(year, month - 1, day))
  const valid =
    year >= 2000 && year <= 2100 &&
    date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day
  return valid ? value : ''
}

function sanitizeCount(value: unknown, min: number, max: number, fallback: number): number {
  const n = typeof value === 'number' ? value : Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.min(max, Math.max(min, Math.floor(n)))
}

function sanitizeMoney(value: unknown): number {
  const n = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(n) && n >= 0 ? n : 0
}

function sanitizeAddons(value: unknown): string[] {
  if (!Array.isArray(value)) return []
  return value
    .filter((entry): entry is string => typeof entry === 'string')
    .map((entry) => entry.trim())
    .filter((entry) => entry.length > 0)
    .slice(0, 20)
}

/**
 * Defensive normalization for one stored line. Returns null when the
 * line cannot be tied to a valid tour or hotel request.
 * Traveler counts and money are coerced into safe ranges; the line is never
 * reinterpreted as a different booking. Stale slugs (removed tours/hotels) are kept
 * so the UI can flag them instead of substituting another item.
 */
export function sanitizeCartItem(value: unknown): CartItem | null {
  if (typeof value !== 'object' || value === null) return null
  const raw = value as any

  // 1. Hotel Stay Item
  if (raw.itemType === 'hotel' || (typeof raw.hotelId === 'string' && raw.hotelId.trim() !== '')) {
    const hotelId = typeof raw.hotelId === 'string' ? raw.hotelId.trim() : ''
    const hotelSlug = typeof raw.hotelSlug === 'string' ? raw.hotelSlug.trim() : ''
    const hotelName = typeof raw.hotelName === 'string' ? raw.hotelName.trim() : typeof raw.title === 'string' ? raw.title.trim() : ''
    const roomTypeId = typeof raw.roomTypeId === 'string' ? raw.roomTypeId.trim() : ''
    const roomTypeName = typeof raw.roomTypeName === 'string' ? raw.roomTypeName.trim() : ''
    const ratePlanId = typeof raw.ratePlanId === 'string' ? raw.ratePlanId.trim() : ''
    const ratePlanName = typeof raw.ratePlanName === 'string' ? raw.ratePlanName.trim() : ''
    const checkInDate = sanitizeDate(raw.checkInDate)
    const checkOutDate = sanitizeDate(raw.checkOutDate)
    if (!hotelName || !checkInDate || !checkOutDate) return null
    const adults = sanitizeCount(raw.adults, 1, 30, 2)
    const children = sanitizeCount(raw.children, 0, 10, 0)
    const infants = sanitizeCount(raw.infants, 0, 5, 0)
    const roomsCount = sanitizeCount(raw.roomsCount, 1, 10, 1)
    const nights = Math.max(1, sanitizeCount(raw.nights, 1, 90, 1))
    const pricePerNight = sanitizeMoney(raw.pricePerNight)
    const total = sanitizeMoney(raw.total)
    const title = typeof raw.title === 'string' && raw.title.trim() ? raw.title.trim() : `${hotelName} — ${roomTypeName || 'Room'}`

    const candidate: Omit<HotelCartItem, 'key'> = {
      itemType: 'hotel',
      hotelId,
      hotelSlug,
      hotelName,
      title,
      image: typeof raw.image === 'string' ? raw.image : '',
      roomTypeId,
      roomTypeName,
      ratePlanId,
      ratePlanName,
      checkInDate,
      checkOutDate,
      date: `${checkInDate} → ${checkOutDate}`,
      nights,
      roomsCount,
      adults,
      children,
      infants,
      childAges: Array.isArray(raw.childAges) ? raw.childAges.filter((a: any) => typeof a === 'number') : [],
      boardBasis: typeof raw.boardBasis === 'string' ? raw.boardBasis : 'RO',
      pricePerNight,
      total,
      lockToken: typeof raw.lockToken === 'string' ? raw.lockToken : undefined,
      addons: [],
      addonTotal: 0,
      adultUnit: pricePerNight,
      childUnit: 0,
      infantUnit: 0,
    }
    return { ...candidate, key: cartKey(candidate) }
  }

  // 2. Tour Line Item
  const tourSlug = typeof raw.tourSlug === 'string' ? raw.tourSlug.trim() : ''
  const title = typeof raw.title === 'string' ? raw.title.trim() : ''
  if (!tourSlug || !title) return null
  const adults = sanitizeCount(raw.adults, 1, 50, 1)
  let children = sanitizeCount(raw.children, 0, 50, 0)
  let infants = sanitizeCount(raw.infants, 0, 50, 0)
  if (adults + children + infants > 60) {
    const available = Math.max(0, 60 - adults)
    children = Math.min(children, available)
    infants = Math.min(infants, Math.max(0, available - children))
  }
  const candidate: Omit<TourCartItem, 'key'> = {
    itemType: 'tour',
    tourSlug,
    title,
    image: typeof raw.image === 'string' ? raw.image : '',
    date: sanitizeDate(raw.date),
    adults,
    children,
    infants,
    addons: sanitizeAddons(raw.addons),
    addonTotal: sanitizeMoney(raw.addonTotal),
    adultUnit: sanitizeMoney(raw.adultUnit),
    childUnit: sanitizeMoney(raw.childUnit),
    infantUnit: sanitizeMoney(raw.infantUnit),
    total: sanitizeMoney(raw.total),
  }
  return { ...candidate, key: cartKey(candidate) }
}

let inMemoryFallback: CartItem[] = []

function readCart(): CartItem[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return inMemoryFallback
    const parsed: unknown = JSON.parse(raw)
    if (!Array.isArray(parsed)) return inMemoryFallback
    const items: CartItem[] = []
    for (const entry of parsed) {
      const item = sanitizeCartItem(entry)
      if (item && !items.some((kept) => kept.key === item.key)) items.push(item)
      if (items.length >= MAX_LINES) break
    }
    inMemoryFallback = items
    return items
  } catch {
    return inMemoryFallback
  }
}

let cache: CartItem[] | null = null

function getSnapshot(): CartItem[] {
  if (cache === null) cache = readCart()
  return cache
}

function getServerSnapshot(): CartItem[] {
  return EMPTY_CART
}

function update(next: CartItem[]) {
  cache = next
  inMemoryFallback = next
  try { localStorage.setItem(KEY, JSON.stringify(next)) } catch { /* private mode or quota exceeded: in-memory fallback active */ }
  listeners.forEach((notify) => notify())
}

function subscribe(notify: () => void) {
  listeners.add(notify)
  const onStorage = (event: StorageEvent) => {
    if (event.key === KEY || event.key === null) {
      cache = null
      notify()
    }
  }
  window.addEventListener('storage', onStorage)
  return () => {
    listeners.delete(notify)
    window.removeEventListener('storage', onStorage)
  }
}

export function cartKey(item: Omit<CartItem, 'key'>): string {
  if (isHotelCartItem(item)) {
    const h = item as Omit<HotelCartItem, 'key'>
    return [
      'hotel',
      (h.hotelId || h.hotelSlug || '').trim().toLowerCase(),
      (h.roomTypeId || '').trim().toLowerCase(),
      (h.ratePlanId || '').trim().toLowerCase(),
      h.checkInDate || '',
      h.checkOutDate || '',
      h.adults,
      h.children,
    ].join('|')
  }
  const t = item as Omit<TourCartItem, 'key'>
  const sortedAddons = [...(t.addons || [])].map((a) => a.trim()).filter(Boolean).sort()
  return [
    (t.tourSlug || '').trim().toLowerCase(),
    t.date || 'open',
    t.adults,
    t.children,
    t.infants,
    sortedAddons.join('+'),
  ].join('|')
}

/**
 * Deterministic duplicate behavior: adding the identical configuration
 * merges into one line, so rapid or double clicks can never create accidental
 * duplicates. A meaningfully different configuration stays a separate line.
 */
export function addToCart(item: Omit<CartItem, 'key'>): string {
  const sanitized = sanitizeCartItem(item)
  if (!sanitized) throw new Error('addToCart requires a valid tour or hotel reservation configuration')
  const key = sanitized.key
  update([...getSnapshot().filter((entry) => entry.key !== key), { ...sanitized, key }])
  return key
}

/**
 * Dedicated helper to add a validated hotel stay to the cart.
 */
export function addHotelToCart(
  item: Omit<HotelCartItem, 'key' | 'itemType' | 'infants'> & { infants?: number; itemType?: 'hotel' }
): string {
  const fullItem: Omit<HotelCartItem, 'key'> = {
    ...item,
    infants: item.infants ?? 0,
    itemType: 'hotel',
  }
  const sanitized = sanitizeCartItem(fullItem)
  if (!sanitized) throw new Error('addHotelToCart requires valid hotel details, dates, and occupancy')
  const key = sanitized.key
  update([...getSnapshot().filter((entry) => entry.key !== key), { ...sanitized, key }])
  return key
}

export function removeFromCart(key: string) {
  update(getSnapshot().filter((entry) => entry.key !== key))
}

/**
 * Remove a single add-on title from an existing cart line without
 * deleting the entire trip configuration.
 */
export function removeAddonFromCartItem(key: string, addonToRemove: string) {
  const items = getSnapshot()
  const found = items.find((entry) => entry.key === key)
  if (!found || isHotelCartItem(found)) return
  const nextAddons = found.addons.filter((a) => a !== addonToRemove)
  const candidate: Omit<TourCartItem, 'key'> = {
    itemType: 'tour',
    tourSlug: found.tourSlug,
    title: found.title,
    image: found.image,
    date: found.date,
    adults: found.adults,
    children: found.children,
    infants: found.infants,
    addons: nextAddons,
    addonTotal: found.addonTotal,
    adultUnit: found.adultUnit,
    childUnit: found.childUnit,
    infantUnit: found.infantUnit,
    total: found.total,
  }
  const nextKey = cartKey(candidate)
  const nextItem: TourCartItem = { ...candidate, key: nextKey }
  update(items.map((entry) => (entry.key === key ? nextItem : entry)))
}

export function clearCart() {
  update([])
}

export function useCart() {
  const items = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot)
  return {
    items,
    lines: items.length,
    travelers: items.reduce((n, i) => n + i.adults + i.children + i.infants, 0),
    subtotal: items.reduce((n, i) => n + i.total, 0),
  }
}
