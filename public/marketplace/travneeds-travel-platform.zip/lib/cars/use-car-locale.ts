'use client'
import { useLocale } from '@/components/locale'

export function useCarLocale() {
  return useLocale().locale
}
