import type { Metadata } from 'next'
import { pageContentMetadata } from '@/lib/server/seo/page-content-metadata'
import { FAQPage } from '@/components/extended-pages'
import { getSiteUrl, getHreflangEntries } from '@/lib/seo'
import { readFaqHeroState } from '@/lib/server/cms/faq-hero'
import { publicFaqHero, type PublicFaqHero } from '@/lib/cms/faq-hero'
import { FaqHeroProvider } from '@/components/cms/faq-hero-context'
import { originalEditorialHero } from '@/lib/cms/editorial-hero-definitions'
import { readPublishedPage } from '@/lib/server/cms/page-sections'

export async function generateMetadata(): Promise<Metadata> {
  const siteUrl = await getSiteUrl()
  const hreflang = await getHreflangEntries('/faq')

  return {
    title: 'Frequently Asked Questions',
    description: 'Find answers to common questions about TravNeeds Egypt tours, bookings, Nile cruises, and travel planning.',
    alternates: { canonical: `${siteUrl}/faq`, languages: hreflang },
    ...(await pageContentMetadata('faq')),
  }
}

export default async function Page() {
  let hero: PublicFaqHero
  try {
    const state = await readFaqHeroState()
    hero = state.mode === 'original' ? { hidden: false, content: originalEditorialHero('faq') } : publicFaqHero(state)
  }
  catch { hero = { hidden: false, content: null, unavailable: true } }
  return <FaqHeroProvider state={hero}><FAQPage pageContent={await readPublishedPage('faq')} /></FaqHeroProvider>
}
