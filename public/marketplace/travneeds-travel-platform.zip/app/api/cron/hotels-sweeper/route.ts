import { NextResponse, type NextRequest } from 'next/server';
import { runHotelExpirySweeper } from '@/lib/server/hotels';
import { getCurrentUser, hasPermission } from '@/lib/server/auth';
import { isSameOriginRequest } from '@/lib/server/csrf';

/**
 * Deployment-compatible scheduled cron endpoint for hotel expiry safety.
 *
 * Invocation channels:
 * 1. Scheduled Cron (POST):
 *    Requires header `Authorization: Bearer <CRON_SECRET>` or `x-cron-secret: <CRON_SECRET>`
 *    when CRON_SECRET is configured in environment.
 * 2. Authenticated Staff Admin (same-origin POST):
 *    Requires `bookings.edit` or `hotels.manage` permission.
 * GET never executes the sweeper. Authentication is required in all environments.
 */
export async function GET(_request: NextRequest) {
  return NextResponse.json(
    { error: 'Method not allowed. Use POST.' },
    { status: 405, headers: { Allow: 'POST' } },
  );
}

export async function POST(request: NextRequest) {
  return handleSweeper(request);
}

async function handleSweeper(request: NextRequest) {
  const cronSecret = process.env.CRON_SECRET;
  const authHeader = request.headers.get('authorization');
  const customHeader = request.headers.get('x-cron-secret');
  const bearerToken = authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;
  const providedSecret = bearerToken || customHeader;

  let authorized = false;

  if (cronSecret && providedSecret === cronSecret) {
    authorized = true;
  } else {
    // Check staff permissions
    try {
      const user = await getCurrentUser();
      if (
        user &&
        (hasPermission(user, 'bookings.edit') ||
          hasPermission(user, 'hotels.manage'))
      ) {
        if (!isSameOriginRequest(request)) {
          return NextResponse.json({ error: 'Forbidden.' }, { status: 403 });
        }
        authorized = true;
      } else if (user) {
        return NextResponse.json({ error: 'Forbidden.' }, { status: 403 });
      }
    } catch {
      // ignore
    }
  }

  if (!authorized) {
    return NextResponse.json(
      { error: 'Unauthorized: valid cron secret or staff permission required.' },
      { status: 401 },
    );
  }

  const { searchParams } = new URL(request.url);
  const rawMinutes = searchParams.get('olderThanMinutes');
  const parsedMinutes = rawMinutes ? parseInt(rawMinutes, 10) : 30;
  const olderThanMinutes =
    Number.isFinite(parsedMinutes) && parsedMinutes >= 5 && parsedMinutes <= 1440
      ? parsedMinutes
      : 30;

  try {
    const result = await runHotelExpirySweeper({ olderThanMinutes });
    return NextResponse.json({
      success: true,
      timestamp: new Date().toISOString(),
      olderThanMinutes,
      swept: result,
    });
  } catch (error) {
    console.error('Hotel expiry sweeper failed:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Sweeper execution failed.' },
      { status: 500 },
    );
  }
}

