import { catalogueTranslationResponse, saveWithCatalogueTranslations, deleteWithCatalogueTranslations } from '@/lib/server/catalogue/catalogue-translations';
import { validateCatalogueTranslations } from '@/lib/catalogue/catalogue-translations';
import { NextResponse } from 'next/server';
import { isSameOriginRequest } from '@/lib/server/csrf';
import { db } from '@/lib/server/db';
import { getCurrentUser, hasPermission } from '@/lib/server/auth';

const SLUG_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

export async function GET(
  request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  // Public: view a single multi-day category by slug
  const { slug } = await params;
  const category = await db.multiDayCategory.findUnique({ where: { slug } });

  if (!category) {
    return NextResponse.json({ notFound: true }, { status: 404 });
  }

  return NextResponse.json(await catalogueTranslationResponse('category', { category }));
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  // Staff-only edit with same-origin mutation protection
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized.' }, { status: 401 });
  }
  if (!hasPermission(user, 'categories.edit')) {
    return NextResponse.json({ error: 'Forbidden.' }, { status: 403 });
  }

  const originOk = isSameOriginRequest(request);
  if (!originOk) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }

  const data = await request.json();
  if (data?.translations !== undefined) {
    try { validateCatalogueTranslations('category', data.translations); }
    catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : 'Invalid translations.' }, { status: 400 }); }
  }
  const { slug: paramSlug } = await params;

  const existing = await db.multiDayCategory.findUnique({ where: { slug: paramSlug } });
  if (!existing) {
    return NextResponse.json({ error: 'Category not found.' }, { status: 404 });
  }

  if (data.slug && data.slug !== existing.slug) {
    const slug = String(data.slug).trim().toLowerCase();
    if (!SLUG_PATTERN.test(slug) || slug.length > 80) {
      return NextResponse.json({ error: 'Enter a valid slug.' }, { status: 400 });
    }
    const slugExists = await db.multiDayCategory.findUnique({ where: { slug } });
    if (slugExists) {
      return NextResponse.json({ error: 'Slug must be unique.' }, { status: 409 });
    }
  }

  const category = await saveWithCatalogueTranslations('category', data.translations, existing.slug, (tx) => tx.multiDayCategory.update({
    where: { slug: paramSlug },
    data: {
      slug: data.slug ? String(data.slug).trim().toLowerCase() || existing.slug : existing.slug,
      name: typeof data.name === 'string' && data.name.trim() ? data.name.trim().slice(0, 120) : existing.name,
      nameAr: typeof data.nameAr === 'string' && data.nameAr.trim() ? data.nameAr.trim().slice(0, 120) : existing.nameAr,
      copy: typeof data.copy === 'string' && data.copy.trim() ? data.copy.trim().slice(0, 2000) : existing.copy,
      copyAr: typeof data.copyAr === 'string' && data.copyAr.trim() ? data.copyAr.trim().slice(0, 2000) : existing.copyAr,
      image: typeof data.image === 'string' ? data.image.trim().slice(0, 2000) : existing.image,
      order: data.order === undefined || data.order === '' ? existing.order : (Number.isFinite(Number(data.order)) ? Number(data.order) : existing.order),
      active: data.active === undefined ? existing.active : data.active !== false,
    },
  }));

  return NextResponse.json(await catalogueTranslationResponse('category', { category }));
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  // Staff-only delete with same-origin mutation protection.
  // Tours keep their categorySlugs entries; the join ignores unknown
  // slugs, so no tour row is modified or lost.
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized.' }, { status: 401 });
  }
  if (!hasPermission(user, 'categories.delete')) {
    return NextResponse.json({ error: 'Forbidden.' }, { status: 403 });
  }

  const originOk = isSameOriginRequest(request);
  if (!originOk) {
    return NextResponse.json({ error: 'Invalid request origin.' }, { status: 403 });
  }

  const { slug: paramSlug } = await params;

  const existing = await db.multiDayCategory.findUnique({ where: { slug: paramSlug } });
  if (!existing) {
    return NextResponse.json({ error: 'Category not found.' }, { status: 404 });
  }

  await deleteWithCatalogueTranslations('category', paramSlug, (tx) => tx.multiDayCategory.delete({ where: { slug: paramSlug } }));

  return NextResponse.json({ deleted: true });
}
