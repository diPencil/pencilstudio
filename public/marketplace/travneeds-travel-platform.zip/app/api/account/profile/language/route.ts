import { getAccountWriteUser } from '@/lib/server/staff-preview'
import { profileLanguageHandlers } from '@/lib/server/localization/profile-language'

export const { GET, PATCH } = profileLanguageHandlers(getAccountWriteUser)
