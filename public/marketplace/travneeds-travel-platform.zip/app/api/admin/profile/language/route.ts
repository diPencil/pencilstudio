import { getCurrentUser, hasStaffRole } from '@/lib/server/auth'
import { profileLanguageHandlers } from '@/lib/server/localization/profile-language'

export const { GET, PATCH } = profileLanguageHandlers(async () => {
  const user = await getCurrentUser()
  return user && hasStaffRole(user) ? user : null
})
