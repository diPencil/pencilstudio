import type { Metadata } from 'next'
import { translate } from '@/lib/localization/platform-translations'
import { getServerLocale } from '@/lib/server/localization/locale'
import { CartPage } from '@/components/booking/cart-page'

export async function generateMetadata(): Promise<Metadata> {
  const locale = await getServerLocale()
  return {
    title: translate(locale, 'core.pageMetadata.cart.title'),
    description: translate(locale, 'core.pageMetadata.cart.description'),
    robots: { index: false, follow: false, nocache: true },
  }
}

export default function Page() {
  return <CartPage />
}
