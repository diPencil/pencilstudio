'use client'
import { useAdminTranslations } from '@/components/admin/providers/admin-translations'


import Link from 'next/link'
import { useMemo, useState } from 'react'
import { ExternalLink, Eye, EyeOff, Link2, Pencil, Plus, Tags, Trash2 } from 'lucide-react'
import { PageHead } from '@/components/admin/admin-shell'
import { AdminEmpty, AdminIconAction, AdminStats, AdminStatSplitValue, AdminTableActions, AdminTableTools, AdminTableWrap, AdminText, Card, StatusPill } from '@/components/admin/admin-ui'
import { SortableTh, useAdminTableSort } from '@/components/admin/ui/admin-table-sort'
import { useAdminLocale } from '@/components/admin/providers/admin-locale'
import { AdminPagination, usePagination } from '@/components/admin/ui/admin-pagination'
import { getMultiDayToursForCategory, getToursByCategory } from '@/data/tours'
import { invalidateCatalogueCache, useDbCategoriesStatus } from '@/lib/catalogue/catalogue-client'
import { useDbToursStatus } from '@/lib/tours/tours-client'
import { AdminConfirmDialog } from '@/components/admin/ui/admin-confirm-dialog'
import { toast } from '@/components/admin/ui/admin-toaster'

export default function MultiDayCategoriesPage() {
  const i18n = useAdminTranslations("admin.catalogue")

  const ar = useAdminLocale() === 'ar'
  const [query, setQuery] = useState('')
  const [removeTarget, setRemoveTarget] = useState<{ slug: string; name: string } | null>(null)
  const [removeBusy, setRemoveBusy] = useState(false)
  const [removeError, setRemoveError] = useState('')
  // DB-authoritative catalogue with no static fallback: while the API is
  // loading or failing, the screen shows loading/error  -  never bootstrap
  // rows masquerading as database records.
  const { data: categoryData, loading: categoriesLoading, error: categoriesError, retry: retryCategories, refresh: refreshCategories } = useDbCategoriesStatus()
  const liveCategories = categoryData ?? []
  const removeCategory = async () => {
    if (!removeTarget || removeBusy) return
    setRemoveBusy(true)
    setRemoveError('')
    try {
      const res = await fetch(`/api/multi-day-categories/${encodeURIComponent(removeTarget.slug)}`, {
        method: 'DELETE',
        credentials: 'same-origin',
      })
      if (!res.ok) {
        const data = await res.json().catch(() => ({} as { error?: string }))
        throw new Error(data.error || 'Failed to delete category.')
      }
      toast.success(ar ? `تم حذف "${removeTarget.name}".` : `"${removeTarget.name}" deleted.`, { dedupeKey: `category-delete-${removeTarget.slug}` })
      setRemoveTarget(null)
      // Refresh from the DB source of truth without a full page reload.
      invalidateCatalogueCache()
      refreshCategories()
    } catch (err) {
      setRemoveError(err instanceof Error ? err.message : 'Failed to delete category.')
      toast.error(err instanceof Error ? err.message : 'Failed to delete category.', { dedupeKey: 'category-delete-error' })
    } finally {
      setRemoveBusy(false)
    }
  }
  const { data: tourData, loading: toursLoading, error: toursError, retry: retryTours } = useDbToursStatus(getToursByCategory('multi-days-tours'))
  const liveTours = tourData ?? []
  const loading = categoriesLoading || (toursLoading && tourData === null)
  const loadError = categoriesError ?? toursError
  const retryAll = () => { retryCategories(); retryTours(); }
  const rows = useMemo(() => {
    const q = query.trim().toLowerCase()
    return liveCategories
      .map((category) => ({ category, linked: getMultiDayToursForCategory(liveTours, category.slug).length }))
      .filter(({ category }) => !q || `${category.name} ${category.nameAr} ${category.slug}`.toLowerCase().includes(q))
  }, [liveCategories, liveTours, query])
  const published = liveCategories.filter((c) => c.active).length
  const assignments = rows.reduce((sum, row) => sum + row.linked, 0)
  const categorySort = useAdminTableSort(rows, {
    category: (row) => row.category.name,
    tours: (row) => row.linked,
    status: (row) => (!row.category.active ? 'hidden' : 'published'),
    order: (row) => row.category.order,
  }, 'order', 'asc')
  const paging = usePagination(categorySort.sortedRows)

  return <>
    <PageHead eyebrow={i18n("admin.shared.catalogue")} title={i18n("admin.catalogue.multiDayCategories")} titleAr="فئات الرحلات متعددة الأيام" sub={i18n("admin.catalogue.manageThemedCollectionsAndTheirLinkedMulti_051efdb")} subAr="إدارة المجموعات الموضوعية ورحلاتها المرتبطة" actions={<Link className="sp-btn primary" href="/admin/multi-day-categories/new"><Plus size={17} /> <AdminText en="New category" ar="فئة جديدة" /></Link>} />
    <AdminStats items={[
      { label: <AdminText en="Categories" ar="الفئات" />, value: <AdminStatSplitValue total={liveCategories.length} published={published} ar={ar} />, note: <AdminText en="Themed collections" ar="مجموعات موضوعية" />, icon: Tags, tone: 'orange' },
      { label: <AdminText en="Linked tours" ar="الرحلات المرتبطة" />, value: assignments, note: <AdminText en="Category assignments" ar="ارتباطات الفئات" />, icon: Link2, tone: 'green' },
      { label: <AdminText en="Published" ar="المنشورة" />, value: published, note: <AdminText en="Visible on the website" ar="ظاهرة على الموقع" />, icon: Eye, tone: 'blue' },
      { label: <AdminText en="Hidden" ar="المخفية" />, value: liveCategories.length - published, note: <AdminText en="Hidden from the website" ar="مخفية عن الموقع" />, icon: EyeOff, tone: 'violet' },
    ]} />
    <Card title={<AdminText en="All categories" ar="كل الفئات" />} sub={<AdminText en={`${rows.length} of ${liveCategories.length} shown`} ar={`عرض ${rows.length} من ${liveCategories.length}`} />}>
      <AdminTableTools query={query} onQueryChange={setQuery} placeholder={ar ? 'ابحث في الفئات...' : i18n("admin.catalogue.searchCategories")} />
      {loading ? <AdminEmpty title={<AdminText en="Loading categories…" ar="جارٍ تحميل الفئات…" />} copy={<AdminText en="Reading the authoritative catalogue." ar="تتم قراءة السجل المعتمد." />} />
      : loadError ? <><AdminEmpty title={<AdminText en="Could not load categories" ar="تعذر تحميل الفئات" />} copy={<AdminText en={loadError} ar={loadError} />} /><div style={{ display: 'flex', justifyContent: 'center', marginTop: 12 }}><button type="button" className="sp-btn" onClick={retryAll}><AdminText en="Retry" ar="إعادة المحاولة" /></button></div></>
      : rows.length ? <AdminTableWrap><table className="sp-table">
        <thead><tr><th className="sp-row-number">#</th><SortableTh label={<AdminText en="Category" ar="الفئة" />} column="category" {...categorySort} onSort={categorySort.sortBy} /><SortableTh label={<AdminText en="Linked tours" ar="الرحلات المرتبطة" />} column="tours" {...categorySort} onSort={categorySort.sortBy} /><SortableTh label={<AdminText en="Status" ar="الحالة" />} column="status" {...categorySort} onSort={categorySort.sortBy} /><SortableTh label={<AdminText en="Order" ar="الترتيب" />} column="order" {...categorySort} onSort={categorySort.sortBy} /><th></th></tr></thead>
        <tbody>{paging.pageRows.map(({ category, linked }, index) => <tr key={category.slug}>
          <td className="sp-row-number">{paging.from + index}</td>
          <td><span style={{ display: 'flex', alignItems: 'center', gap: 10 }}>{category.image ? <img src={category.image} alt="" style={{ width: 44, height: 44, borderRadius: 10, objectFit: 'cover', flex: 'none' }} /> : null}<span><strong>{ar ? category.nameAr : category.name}</strong><br /><small style={{ color: 'var(--sp-muted)' }}>{(ar ? category.copyAr : category.copy).slice(0, 76)}...</small></span></span></td>
          <td>{linked}</td>
          <td><StatusPill status={!category.active ? 'hidden' : 'published'} /></td>
          <td>{category.order}</td>
          <td><AdminTableActions>
            <AdminIconAction icon={Pencil} label={ar ? `تعديل ${category.name}` : `Edit ${category.name}`} href={`/admin/multi-day-categories/new?slug=${category.slug}`} />
            <AdminIconAction icon={ExternalLink} label={ar ? `عرض ${category.name}` : `View ${category.name}`} href={`/all-tours/multi-days-tours/${category.slug}`} />
            <AdminIconAction icon={Trash2} label={ar ? `حذف ${category.name}` : `Delete ${category.name}`} tone="danger" onClick={() => { setRemoveError(''); setRemoveTarget({ slug: category.slug, name: ar ? category.nameAr : category.name }) }} />
          </AdminTableActions></td>
        </tr>)}</tbody>
      </table></AdminTableWrap> : <AdminEmpty title={<AdminText en="No categories found" ar="لا توجد فئات" />} copy={<AdminText en="Try changing the search or filters." ar="جرب تغيير البحث أو الفلاتر." />} />}
        {rows.length > 0 && <AdminPagination page={paging.page} pageCount={paging.pageCount} onPage={paging.setPage} pageSize={paging.pageSize} onPageSize={paging.setPageSize} from={paging.from} to={paging.to} total={paging.total} />}
    </Card>
    <AdminConfirmDialog
      open={removeTarget !== null}
      onClose={() => { if (!removeBusy) setRemoveTarget(null) }}
      onConfirm={() => { void removeCategory() }}
      title={<AdminText en="Delete this category?" ar="حذف هذه الفئة؟" />}
      description={<AdminText en="This permanently removes the themed collection; linked tours keep their category assignments and can be reassigned." ar="يزيل هذه المجموعة الموضوعية نهائيًا؛ تحتفظ الرحلات المرتبطة بتعييناتها ويمكن إعادة تعيينها." />}
      confirmLabel={<AdminText en={removeBusy ? 'Deleting…' : 'Delete category'} ar={removeBusy ? 'جارٍ الحذف…' : 'حذف الفئة'} />}
      cancelLabel={<AdminText en="Keep" ar="إبقاء" />}
      tone="danger"
      canConfirm={!removeBusy}
    >
      <div style={{ display: 'grid', gap: 8 }}>
        <p style={{ margin: 0, fontWeight: 700 }}>{removeTarget ? (ar ? removeTarget.name || removeTarget.slug : removeTarget.name || removeTarget.slug) : null}</p>
        {removeError ? <p role="alert" style={{ color: '#b91c1c', margin: 0 }}>{removeError}</p> : null}
      </div>
    </AdminConfirmDialog>
  </>
}
