'use client'
import { AdminText as RegistryAdminText } from '@/components/admin/ui/admin-text'

import { useAdminTranslations } from '@/components/admin/providers/admin-translations'


import { CreationTimeline } from '@/components/admin/ui/creation-timeline'

import { Suspense, useEffect, useState } from 'react'
import { ContentLanguageTabs, TranslatedInput, TranslatedTextarea } from '@/components/admin/ui/content-language-tabs'
import { type CatalogueTranslations } from '@/lib/catalogue/catalogue-translations'
import { useRouter, useSearchParams } from 'next/navigation'
import { PageHead } from '@/components/admin/admin-shell'
import { AdminText, Card } from '@/components/admin/admin-ui'
import { useAdminLocale } from '@/components/admin/providers/admin-locale'
import { toast } from '@/components/admin/ui/admin-toaster'
import { slugify } from '@/lib/admin/admin-store'
import { invalidateOffersBlogsCache, useDbBlogs } from '@/lib/catalogue/offers-blogs-client'
import { ImageField } from '@/components/admin/ui/image-field'
import { BlogEditorialForm } from '@/components/admin/blogs/blog-editorial-form'
import type { Blog } from '@/data/types'
import { BlogEditorialInputError, emptyBlogEditorial, validateBlogEditorial } from '@/lib/blogs/blog-editorial'

const cleanSlugInput = (value: string) =>
  value.toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '').replace(/-+/g, '-').slice(0, 80)

function BlogForm({ initial, editSlug }: { initial: Blog | null; editSlug: string }) {
  const i18n = useAdminTranslations("admin.catalogue")

  const ar = useAdminLocale() === 'ar'
  const router = useRouter()
  const dbBlogs = useDbBlogs([])

  const editing = Boolean(editSlug)
  const missing = editing && initial === null

  const [translations, setTranslations] = useState<CatalogueTranslations>(initial?.translations ?? {})
  const [title, setTitle] = useState(initial?.title ?? '')
  const [slug, setSlug] = useState(initial?.slug ?? '')
  const [slugTouched, setSlugTouched] = useState(Boolean(initial))
  const [category, setCategory] = useState(initial?.category ?? '')
  const [date, setDate] = useState(initial?.date ?? '')
  const [image, setImage] = useState(initial?.image ?? '')
  const [excerpt, setExcerpt] = useState(initial?.excerpt ?? '')
  const [editorial, setEditorial] = useState(initial?.editorial ?? emptyBlogEditorial())
  const [published, setPublished] = useState(initial ? initial.isPublished !== false : false)
  const [displayOrder, setDisplayOrder] = useState(initial?.displayOrder != null ? String(initial.displayOrder) : '')
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  const save = async () => {
    setError('')
    if (saving) return
    if (!title.trim()) { setError(ar ? 'اكتب عنوان المقال.' : 'Enter the story title.'); return }
    if (!category.trim()) { setError(ar ? 'اكتب تصنيف المقال.' : 'Enter the story category.'); return }
    if (!date.trim()) { setError(ar ? 'اكتب تاريخ المقال.' : 'Enter the story date.'); return }
    if (!excerpt.trim()) { setError(ar ? 'اكتب مقتطف المقال.' : 'Enter the story excerpt.'); return }
    let cleanEditorial
    try {
      cleanEditorial = validateBlogEditorial(editorial, { publishable: published })
    } catch (validationError) {
      setError(validationError instanceof BlogEditorialInputError ? validationError.message : (ar ? 'راجع محتوى المقال.' : 'Check the article content.'))
      return
    }
    const finalSlug = editing ? editSlug : cleanSlugInput(slugTouched ? slug : slugify(title)) || slugify(title || 'story')
    if (!/^[a-z0-9-]{1,80}$/.test(finalSlug)) {
      setError(ar ? 'المعرف (slug) يجب أن يكون أحرفًا إنجليزية صغيرة وأرقامًا وشرطات.' : 'Slug must be lowercase letters, numbers and dashes.')
      return
    }
    if (!editing && dbBlogs.some((b) => b.slug === finalSlug)) {
      setError(ar ? 'هذا المعرف مستخدم بالفعل. اختر معرفًا مختلفًا.' : 'This slug is already taken. Choose a different one.')
      return
    }
    // Story record is DB-authoritative (POST for new, PUT for edit).
    // Rich editorial content is preserved untouched on edit.
    setSaving(true)
    try {
      const url = editing
        ? `/api/blogs/${encodeURIComponent(editSlug)}`
        : '/api/blogs'
      const res = await fetch(url, {
        method: editing ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...(editing ? {} : { slug: finalSlug }),
          translations,
          title: title.trim(),
          image: image.trim(),
          category: category.trim(),
          date: date.trim(),
          excerpt: excerpt.trim(),
          editorial: cleanEditorial,
          isPublished: published,
          ...(displayOrder.trim() ? { displayOrder: Number(displayOrder) } : {}),
        }),
        credentials: 'same-origin',
      })
      if (!res.ok) {
        const data = await res.json().catch(() => ({} as { error?: string }))
        throw new Error(data.error || 'Failed to save story.')
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : (ar ? 'تعذر حفظ المقال.' : 'Failed to save story.'), { dedupeKey: 'blog-editor-save' })
      setSaving(false)
      return
    }
    setSaving(false)
    invalidateOffersBlogsCache()
    toast.success(published ? (ar ? 'تم حفظ ونشر المقال.' : 'Story saved and published.') : (ar ? 'تم حفظ المقال كمسودة.' : 'Story saved as a draft.'), { dedupeKey: 'blog-editor-save' })
    router.push('/admin/blogs')
  }

  if (missing) {
    return <>
      <PageHead eyebrow={i18n("admin.catalogue.blogs")} title={i18n("admin.catalogue.storyNotFound")} titleAr="المقال غير موجود" sub={i18n("admin.catalogue.unknownSlug")} subAr="معرف غير معروف" backHref="/admin/blogs" />
      <Card title={<AdminText en="Unknown story" ar="مقال غير معروف" />}>
        <p><AdminText en={`No story matches slug "${editSlug}".`} ar={`لا يوجد مقال بالمعرف "${editSlug}".`} /></p>
      </Card>
    </>
  }

  return <>
    <PageHead
      eyebrow={i18n("admin.catalogue.blogs")}
      title={editing ? i18n("admin.catalogue.editStory") : i18n("admin.catalogue.newStory")}
      titleAr={editing ? 'تعديل مقال' : 'مقال جديد'}
      sub={editing ? i18n("admin.actions.editingRecord", { name: editSlug }) : i18n("admin.catalogue.publishedToTheJournalAndHomepage")}
      subAr={editing ? `تعديل ${editSlug}` : 'ينشر في المجلة والرئيسية'}
      backHref="/admin/blogs"
      actions={<button type="button" className="sp-btn dark" onClick={save} disabled={saving}><AdminText en={editing ? 'Save changes' : (published ? 'Publish story' : 'Save draft')} ar={editing ? 'حفظ التعديلات' : (published ? 'نشر المقال' : 'حفظ مسودة')} /></button>}
    />
    <ContentLanguageTabs translations={translations} setTranslations={setTranslations}>
    <CreationTimeline busy={saving} steps={[
      { id: 'details', label: i18n("admin.catalogue.storyDetails"), content: <><Card title={<AdminText en="Story details" ar="بيانات المقال" />} sub={<AdminText en="Card information, publishing and ordering. The full article builder follows below." ar="بيانات الكارت والنشر والترتيب، ثم منشئ المقال الكامل بالأسفل." />}>
      <div className="sp-form">
        <div className="sp-form-2">
          <label><AdminText en="Title" ar="العنوان" /><TranslatedInput field="title" value={title} onChange={(e) => { setTitle(e.target.value); if (!slugTouched && !editing) setSlug(slugify(e.target.value)) }} /></label>
          <label><AdminText en="Category" ar="التصنيف" /><TranslatedInput field="category" value={category} onChange={(e) => setCategory(e.target.value)} placeholder={ar ? 'مثال: دليل السفر' : i18n("admin.catalogue.eGTravelGuide")} /></label>
        </div>
        <div className="sp-form-2">
          <label><AdminText en="Slug" ar="المعرف" /><input value={editing ? editSlug : (slugTouched ? slug : slugify(title))} disabled={editing} dir="ltr" onChange={(e) => { setSlugTouched(true); setSlug(cleanSlugInput(e.target.value)) }} placeholder="custom-..." />{!editing && <small><AdminText en="Lowercase letters, numbers, dashes. Must be unique." ar="أحرف صغيرة وأرقام وشرطات. يجب أن يكون فريدًا." /></small>}{editing && <small><AdminText en="Slug identity stays stable when editing." ar="يبقى المعرف ثابتًا عند التعديل." /></small>}</label>
          <label><AdminText en="Date" ar="التاريخ" /><input value={date} onChange={(e) => setDate(e.target.value)} placeholder={ar ? 'مثال: مارس 2026' : i18n("admin.catalogue.eGMarch2026")} /></label>
        </div>
        <ImageField value={image} onChange={setImage} />
        <label><AdminText en="Excerpt" ar="المقتطف" /><TranslatedTextarea field="excerpt" rows={3} value={excerpt} onChange={(e) => setExcerpt(e.target.value)} /></label>

      </div>
      </Card></> },
      { id: 'article-hero', label: i18n("admin.catalogue.articleHero"), content: <BlogEditorialForm section="hero" value={editorial} onChange={setEditorial} /> },
      { id: 'article-facts', label: i18n("admin.catalogue.atAGlanceFacts"), content: <BlogEditorialForm section="facts" value={editorial} onChange={setEditorial} /> },
      { id: 'article-sections', label: i18n("admin.catalogue.articleSections"), content: <BlogEditorialForm section="sections" value={editorial} onChange={setEditorial} /> },
      { id: 'article-navigation', label: i18n("admin.catalogue.guideNavigationSidebar"), content: <BlogEditorialForm section="navigation" value={editorial} onChange={setEditorial} /> },
      { id: 'article-practical', label: i18n("admin.catalogue.tipsQuoteChecklist"), content: <BlogEditorialForm section="practical" value={editorial} onChange={setEditorial} /> },
      { id: 'article-cta', label: i18n("admin.catalogue.finalCallToAction"), content: <BlogEditorialForm section="cta" value={editorial} onChange={setEditorial} /> },
      { id: 'publishing', label: i18n("admin.catalogue.reviewPublish"), content: <><Card title={i18n("admin.catalogue.publishing")}><div className="sp-form-2">
          <label className="sp-check"><input type="checkbox" checked={published} onChange={(e) => setPublished(e.target.checked)} /> <AdminText en="Published (visible on website)" ar="منشور (ظاهر على الموقع)" /></label>
          <label><AdminText en="Display order" ar="ترتيب العرض" /><input type="number" step="1" value={displayOrder} onChange={(e) => setDisplayOrder(e.target.value)} placeholder="1" /></label>
        </div></Card></> }
      ]} footer={<>{error && <p role="alert" style={{ color: '#b91c1c' }}>{<RegistryAdminText text={error} />}</p>}
      <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
        <button type="button" className="sp-btn primary" onClick={save} disabled={saving}><AdminText en={editing ? 'Save changes' : (published ? 'Publish story' : 'Save draft')} ar={editing ? 'حفظ التعديلات' : (published ? 'نشر المقال' : 'حفظ مسودة')} /></button>
      </div>
</>} />
    </ContentLanguageTabs>
  </>
}

function normalizeBlogRow(row: Record<string, unknown>): Blog {
  const content = (row.content ?? {}) as Record<string, unknown>
  return {
    translations: row.translations as CatalogueTranslations | undefined,
    title: String(row.title ?? ''),
    slug: String(row.slug ?? ''),
    image: String(row.image ?? ''),
    category: String(row.category ?? ''),
    date: String(row.date ?? ''),
    excerpt: String(row.excerpt ?? ''),
    editorial: (content.editorial as Blog['editorial']) ?? undefined,
    isPublished: row.isPublished === false ? false : undefined,
    displayOrder: typeof row.displayOrder === 'number' ? row.displayOrder : undefined,
  } as Blog
}

function BlogFormLoader() {
  const i18n = useAdminTranslations("admin.catalogue")

  const params = useSearchParams()
  const editSlug = params.get('slug') ?? ''
  const [remote, setRemote] = useState<Record<string, unknown> | null | undefined>(editSlug ? undefined : null)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [attempt, setAttempt] = useState(0)

  useEffect(() => {
    if (!editSlug) {
      setRemote(null)
      return
    }
    let cancelled = false
    setRemote(undefined)
    setLoadError(null)
    // Single source of truth: the DB record. Base-first snapshots would
    // leave admin-created slugs unresolvable and risk stale form state.
    fetch(`/api/blogs/${encodeURIComponent(editSlug)}?admin=1`, { credentials: 'same-origin' })
      .then(async (res) => {
        if (cancelled) return
        if (!res.ok) {
          // Unknown slugs are "not found"; any other failure is a DB/API
          // error and must never render as a missing record.
          if (res.status === 404) setRemote(null)
          else setLoadError(`Request failed (${res.status}).`)
          return
        }
        const data = (await res.json()) as { blog?: Record<string, unknown> }
        if (!cancelled) setRemote(data.blog ?? null)
      })
      .catch(() => {
        if (!cancelled) setLoadError('Could not reach the database.')
      })
    return () => { cancelled = true }
  }, [editSlug, attempt])

  if (remote === undefined && loadError) {
    return <>
      <PageHead eyebrow={i18n("admin.catalogue.blogs")} title={i18n("admin.catalogue.editStory")} titleAr="تعديل مقال" backHref="/admin/blogs" />
      <Card title={<AdminText en="Could not load story" ar="تعذر تحميل المقال" />}>
        <p>{<RegistryAdminText text={loadError} />}</p>
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <button type="button" className="sp-btn primary" onClick={() => { setLoadError(null); setRemote(undefined); setAttempt((n) => n + 1) }}><AdminText en="Retry" ar="إعادة المحاولة" /></button>
        </div>
      </Card>
    </>
  }
  if (remote === undefined) {
    return <>
      <PageHead eyebrow={i18n("admin.catalogue.blogs")} title={i18n("admin.catalogue.editStory")} titleAr="تعديل مقال" backHref="/admin/blogs" />
      <Card title={<AdminText en="Loading…" ar="جارٍ التحميل…" />}><p><AdminText en="Loading story…" ar="جارٍ تحميل المقال…" /></p></Card>
    </>
  }
  const initial = remote ? normalizeBlogRow(remote) : null
  return <BlogForm key={editSlug || 'new'} initial={initial} editSlug={editSlug} />
}

export default function NewBlogPage() {
  return <Suspense><BlogFormLoader /></Suspense>
}
