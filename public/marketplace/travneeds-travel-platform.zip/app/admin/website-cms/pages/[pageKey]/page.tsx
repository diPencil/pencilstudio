
import { AdminText as RegistryAdminText } from '@/components/admin/ui/admin-text'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { findCmsPage } from '@/lib/cms/cms-coverage'
import { PageVisualEditor } from '@/components/admin/cms/page-visual-editor'
import { PageHead } from '@/components/admin/admin-shell'
import { Card } from '@/components/admin/admin-ui'
import { isPageDocumentId } from '@/lib/cms/additional-page-content'
export default async function Page({ params }: { params: Promise<{ pageKey: string }> }) {
  const { pageKey } = await params
  if (pageKey === 'shared') return <><p className="cms-coverage-note"><RegistryAdminText translationKey="admin.cms.publicMenuStructureAndPublishedMenuLabels_886dd76" />{" "}<Link href="/admin/website-cms/navigation"><RegistryAdminText translationKey="admin.cms.navigationManager" /></Link><RegistryAdminText translationKey="admin.cms.theseLegacyLabelsContinueToSupplyThe_d37df58" /></p><PageVisualEditor key={pageKey} pageId={pageKey} /></>
  const page = findCmsPage(pageKey)
  if (!page) notFound()
  if (isPageDocumentId(pageKey)) return <PageVisualEditor key={pageKey} pageId={pageKey} />
  return <><PageHead eyebrow="PAGES & SECTIONS" title={page.name} sub={page.route} backHref="/admin/website-cms/pages" /><Card title="Page structure" sub={page.inventory === 'partial' ? 'Partial inventory: remaining presentation content is explicitly marked below.' : 'Original visual section order'}>
    <ol className="cms-structure-list">{page.sections.map((section) => <li key={section.id}><div><h3>{<RegistryAdminText text={section.name} />}</h3><p>{section.owner === 'cms' ? 'Managed by the existing CMS editor' : section.owner === 'business' ? 'Managed by the original content module' : section.owner === 'functional' ? 'Fixed application behavior; not a presentation editor' : 'Presentation integration still pending'}</p>{section.note && <p>{<RegistryAdminText text={section.note} />}</p>}</div>{section.editor && <Link href={section.editor} className="sp-btn"><RegistryAdminText translationKey="admin.cms.openExistingEditor" /></Link>}</li>)}</ol>
    {!page.route.includes('[') && <Link href={page.route} className="sp-btn"><RegistryAdminText translationKey="admin.shared.viewPublicPage" /></Link>}
  </Card></>
}
