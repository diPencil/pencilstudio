'use client'
import { AdminText as RegistryAdminText } from '@/components/admin/ui/admin-text'

import { useAdminTranslations } from '@/components/admin/providers/admin-translations'

import { useEffect, useState } from 'react'
import { Eye, Pencil } from 'lucide-react'
import { PageHead } from '@/components/admin/admin-shell'
import { Card, AdminTableTools, AdminTableWrap, AdminTableActions, AdminIconAction } from '@/components/admin/admin-ui'
import { AdminPagination, usePagination } from '@/components/admin/ui/admin-pagination'
import { SharedSelect } from '@/components/shared/shared-select'
import { heroCatalogue } from '@/lib/cms/hero-catalogue'
import type { HeroState } from '@/lib/cms/website-heroes'
import type { FaqHeroState } from '@/lib/cms/faq-hero'
import { EDITORIAL_HERO_IDS, isEditorialHeroId, originalEditorialHero } from '@/lib/cms/editorial-hero-definitions'
import { SHOWCASE_HERO_IDS, isShowcaseHeroId, type ShowcaseHeroState } from '@/lib/cms/showcase-heroes'
export default function HeroSectionsPage() {
  const i18n = useAdminTranslations("admin.cms")

  const [query, setQuery] = useState('')
  const [group, setGroup] = useState('all')
  const [state, setState] = useState<HeroState | null>(null)
  const [editorialStates, setEditorialStates] = useState<Record<string, FaqHeroState>>({})
  const [showcaseStates, setShowcaseStates] = useState<Record<string, ShowcaseHeroState>>({})
  const [error, setError] = useState('')
  useEffect(() => { fetch('/api/admin/website-cms/hero-sections', { cache: 'no-store' }).then(async (res) => { const data = await res.json(); if (!res.ok) throw new Error(data.error); setState(data.state) }).catch(() => setError('Could not load publication status.')) }, [])
  useEffect(() => {
    for (const id of EDITORIAL_HERO_IDS) fetch('/api/admin/website-cms/editorial-heroes/' + id, { cache: 'no-store' }).then(async (res) => { const data = await res.json(); if (!res.ok) throw new Error(); setEditorialStates((previous) => ({ ...previous, [id]: data.state })) }).catch(() => setError('Could not load publication status.'))
    for (const id of SHOWCASE_HERO_IDS) fetch('/api/admin/website-cms/showcase-heroes/' + id, { cache: 'no-store' }).then(async (res) => { const data = await res.json(); if (!res.ok) throw new Error(); setShowcaseStates((previous) => ({ ...previous, [id]: data.state })) }).catch(() => setError('Could not load publication status.'))
  }, [])
  const rows = heroCatalogue.filter((hero) => (group === 'all' || hero.group === group) && (hero.name + ' ' + hero.route).toLowerCase().includes(query.toLowerCase()))
  const paging = usePagination(rows)
  return <>
    <PageHead eyebrow={i18n("admin.shared.websiteCms")} title={i18n("admin.cms.heroSections_fa7249d")} sub={i18n("admin.cms.pageHeroesAndTheirAuthoritativeContentEditors")} />
    <Card title={i18n("admin.cms.heroSections_54a0ea6")}>
      {error && <p className="form-error" role="alert">{<RegistryAdminText text={error} />}</p>}
      <AdminTableTools query={query} onQueryChange={setQuery} placeholder={i18n("admin.cms.searchPageNameOrRoute")}>
        <SharedSelect value={group} onChange={setGroup} label={i18n("admin.cms.pageGroup")} options={[{ value: 'all', label: i18n("admin.cms.allGroups") }, ...[...new Set(heroCatalogue.map((hero) => hero.group))].map((value) => ({ value, label: value }))]} />
      </AdminTableTools>
      <AdminTableWrap><table className="sp-table"><thead><tr><th>{i18n("admin.cms.preview")}</th><th>{i18n("admin.cms.page")}</th><th>{i18n("admin.shared.route")}</th><th>{i18n("admin.cms.heroType")}</th><th>{i18n("admin.cms.management")}</th><th>{i18n("admin.shared.publication")}</th><th>{i18n("admin.shared.updated")}</th><th>{i18n("admin.shared.actions")}</th></tr></thead><tbody>
        {paging.pageRows.map((hero) => {
          const publication = hero.id === 'homepage' ? state : isShowcaseHeroId(hero.id) ? showcaseStates[hero.id] : editorialStates[hero.id]
          const thumbnail = hero.id === 'homepage' ? state?.published?.mediaType === 'image' ? state.published.mediaUrl : state?.published?.poster || '/egypt-hero.png' : isEditorialHeroId(hero.id) ? editorialStates[hero.id]?.published?.image || originalEditorialHero(hero.id).image : isShowcaseHeroId(hero.id) ? showcaseStates[hero.id]?.published?.image : null
          return <tr key={hero.id}>
          <td>{thumbnail ? <img src={thumbnail} alt="" width={64} height={42} style={{ objectFit: 'cover', borderRadius: 6 }} /> : ' - '}</td>
          <td>{hero.name}</td><td>{hero.route}</td><td>{hero.type}</td><td>{'cms' in hero ? i18n("admin.cms.websiteCms") : 'editor' in hero ? i18n("admin.cms.existingContentEditor") : i18n("admin.cms.sourceManagedPending")}</td>
          <td>{'cms' in hero ? publication ? publication.mode === 'original' ? i18n("admin.shared.originalDefaults") : publication.mode : i18n("admin.shared.loading") : 'Source-managed'}</td>
          <td>{publication?.updatedAt ? new Date(publication.updatedAt).toLocaleString() : ' - '}</td>
          <td><AdminTableActions>{'editor' in hero && <AdminIconAction icon={Pencil} label={'cms' in hero ? i18n("admin.cms.editHero") : i18n("admin.cms.openSourceEditor")} href={hero.editor} />}{!hero.route.includes('[') && <AdminIconAction icon={Eye} label={i18n("admin.shared.viewPublicPage")} href={hero.route} />}</AdminTableActions></td>
        </tr>})}
      </tbody></table></AdminTableWrap>
      <AdminPagination {...paging} onPage={paging.setPage} onPageSize={paging.setPageSize} />
    </Card>
  </>
}
