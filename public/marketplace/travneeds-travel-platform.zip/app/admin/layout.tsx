import type { Metadata } from 'next';
import { translate } from '@/lib/localization/platform-translations';
import { getServerLocale } from '@/lib/server/localization/locale';
import { AdminShell } from '@/components/admin/admin-shell';
import { AdminLocaleProvider } from '@/components/admin/providers/admin-locale';
import { requireStaff } from '@/lib/server/guards';
import './admin.css';
import './mobile.css';

export async function generateMetadata(): Promise<Metadata> {
  const locale = await getServerLocale();
  return {
    title: translate(locale, 'core.pageMetadata.admin.title'),
    description: translate(locale, 'core.pageMetadata.admin.description'),
    robots: { index: false, follow: false, nocache: true },
  };
}

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireStaff();
  return <AdminLocaleProvider><AdminShell>{children}</AdminShell></AdminLocaleProvider>;
}
