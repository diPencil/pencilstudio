import type { Metadata } from 'next';
import { translate } from '@/lib/localization/platform-translations';
import { getServerLocale } from '@/lib/server/localization/locale';

import { GuestBookingPage } from '@/components/account/account-portal';

// Personal booking data lives in this URL, so it must never be indexed,
// cached, or prerendered.
export async function generateMetadata(): Promise<Metadata> {
  const locale = await getServerLocale();
  return {
    title: translate(locale, 'core.pageMetadata.booking.title'),
    robots: { index: false, follow: false, nocache: true },
  };
}
export const dynamic = 'force-dynamic';

function first(value: string | string[] | undefined): string {
  return Array.isArray(value) ? (value[0] ?? '') : (value ?? '');
}

/**
 * Thin route wrapper. The token is deliberately NOT read here and NOT passed
 * down as a prop: the client view reads it from the router, so the credential
 * is never serialized into the server-rendered HTML.
 */
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ print?: string | string[] }>
}) {
  const { print } = await searchParams
  return <GuestBookingPage autoPrint={first(print) === '1'} />
}