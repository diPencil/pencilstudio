import type { Metadata } from 'next'
import { pageContentMetadata } from '@/lib/server/seo/page-content-metadata'
import { ServerShowcaseHero } from '@/components/cms/server-showcase-hero'
import { AboutPage } from '@/components/extended-pages'
import { getSiteUrl, getHreflangEntries } from '@/lib/seo'

export async function generateMetadata(): Promise<Metadata> {
  const siteUrl = await getSiteUrl()
  const hreflang = await getHreflangEntries('/about')

  return {
    title: 'About Us',
    description: 'Learn about TravNeeds  -  your trusted Egypt travel partner for unforgettable journeys, expert guides, and personalized service.',
    alternates: { canonical: `${siteUrl}/about`, languages: hreflang },
    ...(await pageContentMetadata('about')),
  }
}

export default function Page() { return <ServerShowcaseHero id="about"><AboutPage /></ServerShowcaseHero> }
