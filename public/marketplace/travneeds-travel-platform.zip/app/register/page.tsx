import { authPageMetadata } from '@/lib/auth/auth-page-metadata'
import { getServerLocale } from '@/lib/server/localization/locale'
import { RegisterPage } from '@/components/auth/auth-pages'

export async function generateMetadata() {
  return authPageMetadata('register', await getServerLocale())
}

export default function Page() {
  return <RegisterPage />
}
