import type { Metadata } from 'next'
import { RebuiltHomePage } from '@/components/homepage'
import { generateOrganizationJsonLd, renderJsonLd } from '@/lib/seo/structured-data'
import { getSiteUrl, getHreflangEntries } from '@/lib/seo'
import { readHeroState } from '@/lib/server/cms/website-heroes'
import { publicHeroState } from '@/lib/cms/website-heroes'
import type { PublicHomeHero } from '@/components/cms/homepage-hero'
import { readPublishedPage } from '@/lib/server/cms/page-sections'
import { getServerLocale } from '@/lib/server/localization/locale'
import { pageContentMetadata } from '@/lib/server/seo/page-content-metadata'

export async function generateMetadata(): Promise<Metadata> {
  const siteUrl = await getSiteUrl()
  const hreflang = await getHreflangEntries('/')
  const [pageContent, locale] = await Promise.all([readPublishedPage(), getServerLocale()])
  const seo = pageContent.content?.seo
  const seoText = locale === 'ar' ? seo?.text['en'] : seo?.text[locale]
  const title = seoText?.title || 'TravNeeds | Discover Egypt'
  const description = seoText?.description || 'Discover ancient wonders, warm hospitality, and unforgettable journeys across Egypt. Book Nile cruises, Cairo day tours, multi-day trips, and shore excursions with TravNeeds.'

  return {
    title: { absolute: title },
    description,
    alternates: { canonical: siteUrl, languages: hreflang },
    openGraph: {
      title,
      description: seoText?.description || 'Discover ancient wonders, warm hospitality, and unforgettable journeys across Egypt.',
      ...(seo?.image ? { images: [seo.image] } : {}),
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description: seoText?.description || 'Discover ancient wonders, warm hospitality, and unforgettable journeys across Egypt.',
      ...(seo?.image ? { images: [seo.image] } : {}),
    },
    ...(await pageContentMetadata('homepage')),
  }
}

export default async function Page() {
  const orgJsonLd = generateOrganizationJsonLd()
  let hero: PublicHomeHero
  try { hero = publicHeroState(await readHeroState()) }
  catch { hero = { hidden: false, content: null, unavailable: true } }
  return (
    <>
      {renderJsonLd(orgJsonLd)}
      <RebuiltHomePage hero={hero} pageContent={await readPublishedPage()} />
    </>
  )
}
