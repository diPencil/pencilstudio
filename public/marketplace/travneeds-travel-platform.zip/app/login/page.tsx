import { authPageMetadata } from '@/lib/auth/auth-page-metadata'
import { getServerLocale } from '@/lib/server/localization/locale'
import { LoginPage } from '@/components/auth/auth-pages'

export async function generateMetadata() {
  return authPageMetadata('login', await getServerLocale())
}

export default function Page() {
  return <LoginPage />
}
