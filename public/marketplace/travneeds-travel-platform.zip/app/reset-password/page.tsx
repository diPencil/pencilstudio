import { authPageMetadata } from '@/lib/auth/auth-page-metadata'
import { getServerLocale } from '@/lib/server/localization/locale'
import { ResetPasswordPage } from '@/components/extended-pages'

export async function generateMetadata() {
  return authPageMetadata('resetPassword', await getServerLocale())
}

export default function Page() {
  return <ResetPasswordPage />
}
