import type { Metadata } from 'next'
import { CustomerAccountPage } from '@/components/account/account-portal'

export const metadata: Metadata = {
  title: 'My Messages',
  description: 'View your TravNeeds support conversations.',
  robots: { index: false, follow: false, nocache: true },
}

export default function Page() { return <CustomerAccountPage section="messages" /> }
