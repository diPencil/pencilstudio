import type { Metadata } from 'next'
import { pageContentMetadata } from '@/lib/server/seo/page-content-metadata'
import { ServerShowcaseHero } from '@/components/cms/server-showcase-hero'
import { TourListing } from '@/components/site'
import { getSiteUrl, getHreflangEntries } from '@/lib/seo'

export async function generateMetadata(): Promise<Metadata> {
  const siteUrl = await getSiteUrl()
  const hreflang = await getHreflangEntries('/all-tours/shore-excursions')

  return {
    title: 'Shore Excursions in Egypt',
    description: 'Book shore excursions with TravNeeds. Port visits from Alexandria, Port Said, and Sokhna. Half-day and full-day tours to Cairo, Luxor, and Aswan for cruise ship passengers.',
    alternates: { canonical: `${siteUrl}/all-tours/shore-excursions`, languages: hreflang },
    ...(await pageContentMetadata('shore')),
  }
}

export default function Page() {
  return <ServerShowcaseHero id="shore"><TourListing slug="shore-excursions" /></ServerShowcaseHero>
}
