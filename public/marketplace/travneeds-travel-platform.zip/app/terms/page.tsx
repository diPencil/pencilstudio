import type { Metadata } from 'next'
import { pageContentMetadata } from '@/lib/server/seo/page-content-metadata'
import { getSiteUrl, getHreflangEntries } from '@/lib/seo'
import { readPublishedPage } from '@/lib/server/cms/page-sections'
import { CmsPolicyPage } from '@/components/cms/cms-additional-pages'

export async function generateMetadata(): Promise<Metadata> {
  const siteUrl = await getSiteUrl()
  const hreflang = await getHreflangEntries('/terms')

  return {
    title: 'Terms of Use',
    description: 'TravNeeds terms of use. Conditions for booking Egypt tours, Nile cruises, and travel services with TravNeeds.',
    alternates: { canonical: `${siteUrl}/terms`, languages: hreflang },
    ...(await pageContentMetadata('terms')),
  }
}

export default async function Page() {
  return <CmsPolicyPage pageId="terms" state={await readPublishedPage('terms')} />
}
