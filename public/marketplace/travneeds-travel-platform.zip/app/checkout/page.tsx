import type { Metadata } from 'next'
import { translate } from '@/lib/localization/platform-translations'
import { getServerLocale } from '@/lib/server/localization/locale'
import { CheckoutPage } from '@/components/booking/checkout-page'

export async function generateMetadata(): Promise<Metadata> {
  const locale = await getServerLocale()
  return {
    title: translate(locale, 'core.pageMetadata.checkout.title'),
    description: translate(locale, 'core.pageMetadata.checkout.description'),
    robots: { index: false, follow: false, nocache: true },
  }
}

export default function Page() {
  return <CheckoutPage />
}
