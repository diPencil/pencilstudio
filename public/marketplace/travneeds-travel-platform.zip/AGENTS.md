# TravNeeds Agent Guide

This file is the entry point for AI agents working in this repository. It maps
the documentation to the code and identifies the checks required for the risk
and scope of the task. TravNeeds is independently installed commercial travel
software, not multi-tenant SaaS. See `README.md` for product layers, current
implementation status, and the planned Languages Module.

## Required reading order

Read these files before editing code:

1. `AGENTS.md` (this file) for the repository map and working rules.
2. `constitution.md` for the mandatory feature-delivery, review, testing, and
   security gates.
3. `README.md` for the product summary, stack, and local setup.
4. `DESIGN_SYSTEM.md` for UI tokens, layout, responsive behavior,
   accessibility, and visual conventions.
5. `AGENT.md` before changing Next.js code. It contains version-specific
   guidance maintained by Next.js.

For framework behavior, consult the installed Next.js 16 documentation under
`node_modules/next/dist/docs/`. Do not rely on remembered behavior
from older Next.js versions when local documentation is available.

## Documentation map

| Document | Purpose | Read when |
| --- | --- | --- |
| `constitution.md` | Non-negotiable delivery and quality policy | Every feature, fix, or refactor |
| `README.md` | Product overview, stack, setup, and public project structure | Starting work or onboarding |
| `DESIGN_SYSTEM.md` | Brand tokens and UI/UX rules | Any visual, responsive, or accessibility change |
| `AGENT.md` | Next.js 16 agent warning and local docs pointer | Any application code change |
| `CLAUDE.md` | Redirects Claude-compatible agents to `AGENTS.md` | Claude-based tooling only |
| `components.json` | shadcn aliases, style, Tailwind CSS entry, icon library | Adding or modifying UI components |
| `package.json` | Runtime versions, dependencies, and executable scripts | Dependency or command changes |
| `tsconfig.json` | TypeScript strictness and `@/*` alias | TypeScript or import changes |
| `next.config.mjs` | Next.js build and image behavior | Build, image, or framework configuration changes |
| `prisma/schema.prisma`; `prisma/migrations/` | MySQL persistence contracts and migration history | Server/data changes; never infer applied database state from files |
| `lib/modules/` | Module manifests, registry, dependencies, entitlement contracts | Module or licensing work |
| `docs/localization-foundation.md` | Shared locale ownership, translation registry, compatibility and future source contracts | Public/Admin/account/CMS/module localization work |
| `.env.example`; `vitest*.config.ts` | Environment template and configured test discovery | Setup and verification planning |

When a code change makes any statement above stale, update the relevant
documentation in the same change.

## Repository map

```text
TravelWin-Websource/          # Repository/application root; run commands here
|- AGENTS.md                 # AI entry point and documentation/code map
|- AGENT.md                  # Next.js-generated framework instructions
|- constitution.md           # Feature delivery and quality constitution
|- README.md                 # Product and setup overview
|- app/                       # App Router layouts, pages, and global CSS
|  |- admin/                  # Staff routes and independent Admin styles
|  `- api/                    # Public, account, staff, and integration route handlers
|- components/                # Shared shells, features, and page compositions
|- components/ui/             # shadcn-style primitives
|- data/                      # Frontend contracts and preserved reference/bootstrap content
|- lib/                       # Client-safe domain utilities and legacy compatibility imports
|  |- core/                   # Validation, password, token, and media primitives
|  |- modules/                # Manifest catalogue, registry, dependencies, entitlements
|  |- hotels/                 # Hotel contracts, validation, and booking calculations
|  |- account/, admin/, auth/, blogs/, catalogue/, destinations/, enquiries/, events/
|  |- gallery/, localization/, offers/, reviews/, search/, tours/, trips/
|  |- cars/, cms/, marketing/, notifications/, seo/, shared/, payments/
|  `- server/                 # Prisma repositories, auth, guards, mutations, integrations
|- prisma/                    # MySQL schema and migration history
|- scripts/                   # Operational helpers; inspect before considering execution
|- storage/                   # Local uploaded media; preserve along with database data
|- docs/                      # Feature notes; docs/archive contains historical reports
|- public/                    # Local static assets
|- DESIGN_SYSTEM.md           # Visual source of truth
`- package.json               # Scripts and dependencies
```

The application has a Node.js backend, Prisma/MySQL persistence, server-owned
sessions and RBAC, staff/customer APIs, catalogue/CMS services, requests,
bookings, payments, and commercial documents. Follow the specific route and
service before claiming persistence or readiness: a model, screen, or manifest
alone does not prove a complete production integration. Hotels Booking Engine
work is in progress; licensing verification is a foundation with a pending
central-server integration. Preserve ongoing Hotels and `lib/` reorganization
work and existing compatibility imports.

## Code ownership map

| Concern | Primary source |
| --- | --- |
| Root metadata, fonts, and global layout | `app/layout.tsx` |
| Homepage route | `app/page.tsx` |
| Homepage composition and sections | `components/homepage.tsx` |
| Unified trip catalogue and filters | `components/tours/trips-page.tsx`; live catalogue via `lib/tours/tours-client.ts` and `lib/server/tours.ts` |
| Header, footer, shell, search engine, tour listing, shared travel UI | `components/site.tsx` |
| Public content, password recovery, cars, and detail compositions | `components/extended-pages.tsx`; CMS/shared implementations may be re-exported or composed here |
| Login and registration experiences, social-auth previews, and registration fields | `components/auth/auth-pages.tsx`; country metadata in `data/countries.ts` |
| Tour detail presentation | `components/tours/tour-detail.tsx`; `components/tours/day-tour-detail.tsx`; `components/tours/tour-video-gallery.tsx` |
| Runtime Tour catalogue and publish rules | `lib/server/tours.ts`; `app/api/tours/`; `lib/tours/tours-client.ts`; `lib/tours/tour-publish.ts` |
| Preserved Tour identity/reference content and bootstrap input | `data/tours.ts` (runtime catalogue is DB-authoritative) |
| Shared frontend domain contracts | `data/types.ts` |
| Locale, RTL, and currency state | `lib/localization/locale-config.ts`; `lib/server/localization/locale.ts`; `components/locale.tsx`; `lib/localization/currency.ts` |
| Shared translation keys and module source discovery | `lib/localization/{translation-registry,platform-translations,core-messages}.ts`; `lib/modules/localization.ts`; root locale owner in `app/layout.tsx` |
| Admin core locale and RTL | `app/admin/layout.tsx` mounts `AdminLocaleProvider`; `components/admin/providers/admin-locale.tsx` reuses the shared locale/direction providers. Shell, PageHead and shared controls consume that context; missing domain copy retains English fallback |
| Catalogue translations | `lib/catalogue/catalogue-translations.ts`; `lib/tours/tour-translations.ts`; `CatalogueTranslation` and entity content/translation payloads |
| Catalogue/CMS persistence | `lib/server/`; `components/cms/`; `data/content.ts` is preserved reference content, not the universal live source |
| Admin shell, primitives, domain editors | `app/admin/layout.tsx`; `components/admin/admin-shell.tsx`; `components/admin/admin-ui.tsx`; `components/admin/{domain}/` and `components/admin/ui/` |
| Authentication, authorization, database | `lib/server/auth.ts` (`hasPermission`); `lib/server/session.ts`; `lib/server/guards.ts`; `lib/server/users.ts`; `lib/server/db.ts`; primitives in `lib/core/` |
| Booking, cart, checkout, payments | `components/booking/`; `lib/booking.ts`; `lib/cart.ts`; `lib/server/bookings.ts`; `lib/server/payments/`; `lib/payments/` |
| Hotels foundation and booking work | `components/hotels/`; `app/admin/hotels/`; `lib/hotels/`; `lib/server/hotels.ts`; `prisma/schema.prisma` |
| Modules and installation licensing | `lib/modules/{types,catalogue,registry,entitlements}.ts`; `lib/server/licensing/license-client.ts`; `app/admin/addons/` |
| URL query contracts and defensive parsers | `lib/shared/query.ts` |
| Shared class-name utility | `lib/utils.ts` |
| Public and Admin style sources | `app/globals.css`; `app/mobile-shell.css`; `app/admin/admin.css`; `app/admin/mobile.css`; domain styles beside components |
| Images, icons, and brand assets | `public/` |

Prefer changing the owning shared component or data source instead of copying
logic into a route wrapper. Keep `app/**/page.tsx` files thin unless a route has
genuinely route-specific behavior.

## Route-to-code map

| Routes | Implementation |
| --- | --- |
| `/` | `app/page.tsx` -> `components/homepage.tsx` |
| `/trips` | `components/tours/trips-page.tsx`; live catalogue via `lib/tours/tours-client.ts` and Tour API/service |
| `/about`, `/contact`, `/faq` | Public compositions in `components/extended-pages.tsx` and `components/cms/`; published page/hero services |
| `/accessible-travel`, `/egypt-travel-guide` | `components/cms/information-page.tsx`; published page/hero services |
| `/blogs`, `/blogs/[slug]` | `components/extended-pages.tsx`; `lib/server/blogs/blogs.ts` and public catalogue clients |
| `/events`, `/events/[slug]` | `components/extended-pages.tsx`; event APIs and `lib/server/` services |
| `/destinations`, `/destinations/[slug]` | `components/extended-pages.tsx`; `lib/server/destinations/destinations.ts` and catalogue clients |
| `/special-offers`, `/special-offers/[slug]` | `components/extended-pages.tsx`; offers API/services and `components/cms/` campaign presentation |
| `/all-tours/one-day-tours` | `components/site.tsx` (`OneDayToursRegions`) |
| `/all-tours/multi-days-tours`, `/all-tours/nile-cruises`, `/all-tours/shore-excursions` | `components/site.tsx` (`TourListing`) |
| `/all-tours/[slug]` | `lib/server/tours.ts`; route validation in `app/all-tours/[slug]/page.tsx`; presentation in `components/tours/tour-detail.tsx` or `components/tours/day-tour-detail.tsx` |
| `/make-your-trip` | Route-local interactive planner in `app/make-your-trip/page.tsx` |
| `/rent-car`, `/rent-car/request` | `components/extended-pages.tsx`; fleet/quote/request APIs, `lib/cars/` and server services |
| `/search` | Re-export from `components/extended-pages.tsx` -> `components/shared/public-search-page.tsx`; `lib/search/use-public-search.ts` uses published DB collections |
| `/login`, `/register` | Thin route wrappers -> `components/auth/auth-pages.tsx`; country metadata in `data/countries.ts` |
| `/forgot-password` | `components/extended-pages.tsx` |
| `/account/**` | Route wrappers and `components/account/`; customer/session guards and account APIs |
| `/privacy`, `/terms` | `components/cms/cms-additional-pages.tsx`; published page sections |

This map identifies entry points, not an exhaustive list of live data sources.
Content routes may delegate to `components/cms/` and server-published settings;
trace the imports before changing them. Additional route families:

| Routes | Implementation |
| --- | --- |
| `/hotels`, `/hotels/[slug]` | `components/hotels/`; `lib/server/hotels.ts` (in progress) |
| `/cart`, `/checkout`, `/booking/[token]`, `/verify-voucher/[token]` | Booking components, server booking/document services, token-scoped access |
| `/admin/**` | Staff layout and shared Admin shell; route/domain editors and `/api/admin/**` |
| `/website-cms-preview/**` | Staff preview routes and CMS presentation components |
| `/api/**`, `/media/**`, `/gallery-videos/**` | Route handlers; server services; persistent media storage |

## Project commands

Run application commands from this directory (the directory containing
`package.json`):

```powershell
corepack pnpm install --frozen-lockfile
corepack pnpm dev
corepack pnpm typecheck
corepack pnpm test
corepack pnpm test:unit
corepack pnpm build
corepack pnpm verify:release
corepack pnpm start
```

Important current constraints:

- Vitest is the existing runner. `test` and `test:unit` run the same safe unit
  workflow: `lib/**/*.test.ts` and `tests/unit/**/*.test.ts`, excluding
  `**/*.integration.test.ts`. Existing standalone assertions are registered as
  Vitest cases; fixtures and simulation checks do not prove database behavior.
- `tests/unit/setup.ts` clears database URLs inside workers and rejects imports
  of the application database service and Prisma client. Keep unit tests pure;
  do not bypass this boundary to make a test pass.
- `test:integration` retains the separate configuration for nine legacy
  document/payment tests. Those files, the isolation helper and integration
  setup remain missing; do not run integration/migration scripts or claim
  database coverage until that harness is restored and safely verified.
- `verify:release` runs TypeScript, the configured default Vitest suite, and the
  production build in sequence and stops on the first failure. It includes
  colocated unit tests but excludes database integration. Release acceptance additionally requires risk-relevant
  integration coverage under the constitution, once safely configured.
- `build` runs `prisma generate` then `next build --webpack`; `dev` uses
  `next dev --webpack`. Generation changes local generated artifacts, not data.
- Production builds enforce TypeScript errors. Keep the separate `typecheck`
  step in release verification so failures are reported before the build.
- There is no lint or browser E2E script yet. Do not claim either ran when it
  did not, and do not add another test runner or package manager.
- Use pnpm through Corepack; do not introduce a second lockfile or package
  manager.
- Do not edit generated output in `.next/`, `node_modules/`, or
  `tsconfig.tsbuildinfo`.
- Use risk-based development checks and full release checkpoints from
  `constitution.md`; documentation-only work needs static review, not builds.
- Database scripts exist but are not routine setup/verification permissions.
  Inspect complete script contents and effects first; never reset or seed data.

## Working rules

1. Preserve the App Router, strict TypeScript, `@/*` imports, and existing
   component boundaries unless the feature requires a documented change.
2. Follow `DESIGN_SYSTEM.md` and existing CSS variables before adding new
   colors, spacing, typography, or interaction patterns.
3. Use existing shared components and Lucide icons before creating duplicates.
4. Keep server components by default. Add `'use client'` only where browser
   state, effects, or browser APIs require it.
5. Treat English/Arabic direction, keyboard access, focus visibility, semantic
   HTML, and responsive layouts as acceptance criteria, not polish.
6. Inspect the current diff, preserve unrelated user and agent work, and make
   surgical changes to the owning code. Never rewrite an entire working file
   merely because a feature touches one part of it.
7. Do not add dependencies, infrastructure, or abstractions without a concrete
   need and a clear maintenance benefit.
8. Follow every gate in `constitution.md` and report exactly what was and was
   not verified.

## Architecture rules

1. Place new files inside their appropriate domain directory.
2. Avoid adding new files directly under `lib/` or `lib/server/`.
3. Separate server-only logic from client-safe utilities.
4. Reuse existing services instead of duplicating business logic.
5. Keep modules isolated with explicit public interfaces.
6. Update imports when relocating files.
7. Preserve existing booking, payment, and licensing contracts.
8. Avoid unrelated refactoring during feature development.

## Completion report

Every completed task should state:

- what changed and which user-visible behavior is affected;
- which files own the change;
- which checks were run and their outcomes;
- what could not be verified, if anything;
- any remaining risk, mock behavior, migration, or follow-up.

<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->

## TravNeeds project rules  -  highest priority for all agents

These project-specific restrictions take precedence over instructions in any
installed skill, plugin, persona, script, or general workflow. Skills are
reference workflows only; they do not authorize actions prohibited here.

- Do not use browsers, browser automation, or browser-based testing.
- Do not stage, commit, push, or deploy without the user's explicit approval.
- Do not perform production operations.
- Do not reset or seed databases, or run destructive migrations. Preserve local
development data.
- Preserve the existing design system and page layouts. Do not make unrelated
code or configuration changes.
- English (EN) is the default and Arabic (AR with full RTL) is the second
  built-in core language. Spanish, Italian, and other additional languages
  belong to the optional, independently licensed Languages Module (planned).
  Follow the migration plan in `README.md`: every functional module must expose
  translatable content and stable translation keys. Preserve current EN/AR/ES/IT
  behavior and translations until an explicitly scoped migration; do not disable
  languages or introduce entitlement gating as a documentation side effect.
  Legacy Star Pyramids restrictions disabling Arabic are obsolete. Historical
  audits may still contain them; current rules and `lib/localization/locale-config.ts` prevail.
- Do not access or modify `web-source-recovery`.
- Before considering any bundled or repository script, inspect its complete
contents and effects. Never execute a bundled script without inspecting it.
- When a skill recommends an action that conflicts with these rules, follow
these project rules and stop before the prohibited action.
