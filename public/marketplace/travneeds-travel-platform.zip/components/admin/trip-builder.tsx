'use client'
import { AdminText as RegistryAdminText } from '@/components/admin/ui/admin-text'

import { useAdminTranslations } from '@/components/admin/providers/admin-translations'


import { useEffect, useMemo, useRef, useState } from 'react'
import { ArrowLeft, ArrowRight, CalendarDays, CheckCircle2, ExternalLink, Eye, EyeOff, ImagePlus, MapPin, Plus, Save, Trash2, Upload } from 'lucide-react'
import { PageHead } from './admin-shell'
import { AdminText, Card, StatusPill } from './admin-ui'
import { useAdminLocale } from '@/components/admin/providers/admin-locale'
import { toast } from '@/components/admin/ui/admin-toaster'
import { invalidateToursCache } from '@/lib/tours/tours-client'
import { multiDayCategories, normalizeTourPricePeriods, tours } from '@/data/tours'
import { useDbCategories, useDbDestinationsStatus } from '@/lib/catalogue/catalogue-client'
import { tripDestinationOptions } from '@/lib/tours/trip-builder-destinations'
import type { CruiseTypeSlug, Tour, TourCategory, TourLocation, TourVideoPlatform } from '@/data/types'
import { uploadImageFile } from '@/lib/admin/admin-store'
import { TripBuilderPreview } from '@/components/admin/tours/trip-builder-preview'
import type { AppearanceTokens } from '@/lib/cms/website-appearance'
import { cleanTravelerPriceRows, previewTextKey, type BasicForm, type AddOnRow, type HighlightRow, type ItineraryRow, type PassengerRateRow, type TravelerPriceRows, type PriceTierRow, type PriceMatrixRow, type LocationRow, type GalleryRow, type VideoRow } from '@/lib/tours/trip-builder-preview'
import { isTourImage, tourWritePayload } from '@/lib/tours/tour-write'
import { ImageField } from './ui/image-field'
import { SharedSelect } from '@/components/shared/shared-select'
import { DateInput } from '@/components/shared/date-input'
import { Tabs } from '@base-ui/react/tabs'
import { ADMIN_CONTENT_LOCALES, LOCALE_LABELS, type AdminContentLocale } from '@/lib/localization/locale-config'
import { readTourText, writeTourText, type Translatable, type TourTranslations } from '@/lib/tours/tour-translations'
import { RichTextEditor } from './ui/rich-text-editor'
import { sanitizeRichText, isHtmlContent } from '@/lib/cms/rich-text'

const steps = [
  { en: 'Basic', ar: 'الأساسية' },
  { en: 'Booking Pricing', ar: 'تسعير الحجز' },
  { en: 'Add-ons', ar: 'الإضافات' },
  { en: 'Overview', ar: 'نظرة عامة' },
  { en: 'Highlights', ar: 'أبرز المعالم' },
  { en: 'Itinerary', ar: 'البرنامج' },
  { en: 'Inclusions', ar: 'المشمول' },
  { en: 'Date Pricing', ar: 'أسعار المواعيد' },
  { en: 'Media', ar: 'الوسائط' },
  { en: 'Map', ar: 'الخريطة' },
  { en: 'Review & Publish', ar: 'المراجعة والنشر' },
] as const


const id = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
const splitLines = (value: string) => value.split('\n').map((line) => line.trim()).filter(Boolean)
const isValidPassengerRate = (row: PassengerRateRow) => Number.isInteger(Number(row.travelers)) && Number(row.travelers) > 0 && row.price.trim() !== '' && Number.isFinite(Number(row.price)) && Number(row.price) >= 0
const isSafeExternalUrl = (value: string) => {
  try { return new URL(value).protocol === 'https:' } catch { return false }
}

function locationRows(locations: readonly TourLocation[] | undefined, fallback: string, translations?: readonly (TourTranslations | null)[]): LocationRow[] {
  const values = locations?.length ? locations : [fallback]
  return values.map((location, index) => typeof location === 'string'
    ? { id: id('location'), name: location, translations: translations?.[index] ?? undefined, nameAr: '', latitude: '', longitude: '' }
    : { id: id('location'), translations: translations?.[index] ?? undefined, name: location.name, nameAr: location.nameAr ?? '', latitude: String(location.latitude ?? ''), longitude: String(location.longitude ?? '') })
}

export function editorData(tour: Tour) {
  const detail = tour.category === 'one-day-tours' ? undefined : tour.detail
  const dayDetail = tour.category === 'one-day-tours' ? tour.dayDetail : undefined
  // A tour that has no price yet (a brand-new record) must not render "0" in
  // price inputs; fall back to an empty string so those fields stay empty.
  const fallbackPrice = tour.slug ? tour.price : ''
  const itinerarySource = detail?.itinerary ?? dayDetail?.stops?.map((stop, index) => ({ ...stop, day: stop.day ?? `Stop ${index + 1}` })) ?? []
  const travelerSource = detail?.travelerPrices ?? dayDetail?.travelerPrices ?? [
    { travelers: 1, adultPrice: tour.slug ? tour.price : undefined, childPrice: tour.slug ? tour.price : undefined, infantPrice: 0 },
    { travelers: 2, adultPrice: tour.slug ? tour.price : undefined, childPrice: tour.slug ? tour.price : undefined, infantPrice: 0 },
    { travelers: 3, adultPrice: tour.slug ? tour.price : undefined, childPrice: tour.slug ? tour.price : undefined, infantPrice: 0 },
  ]
  const addonsSource = detail?.addOns ?? dayDetail?.addOns ?? []
  const highlightsSource = detail?.highlights ?? dayDetail?.highlightGroups ?? (dayDetail?.highlights?.length ? [{ title: 'Highlights', items: dayDetail.highlights }] : [])
  const gallerySource = tour.gallery?.length ? tour.gallery : dayDetail?.gallery?.map((item) => item.src) ?? [tour.image]
  const overview = detail?.overview ?? dayDetail?.overview ?? [tour.summary]
  const priceSource = normalizeTourPricePeriods(detail?.priceRows ?? dayDetail?.priceRows, 'Available travel dates')
  return {
    form: {
      ...((tour.category === 'one-day-tours' ? dayDetail : detail)?.translations ? { translations: (tour.category === 'one-day-tours' ? dayDetail : detail)?.translations } : {}),
      title: tour.title,
      titleAr: tour.titleAr ?? '',
      category: tour.category,
      destinationSlug: tour.destinationSlug ?? '',
      cruiseType: tour.cruiseType ?? '',
      departurePort: tour.departurePort ?? '',
      location: tour.location,
      duration: tour.duration,
      price: tour.slug ? String(tour.price) : '',
      deal: String(('manualDeal' in tour ? tour.manualDeal : tour.deal)?.percent ?? ''),
      dealEndsAt: ('manualDeal' in tour ? tour.manualDeal : tour.deal)?.endsAt?.slice(0, 10) ?? '',
      groupSize: tour.groupSize ?? '',
      travelStyle: tour.travelStyle ?? '',
      summary: tour.summary,
      overview: overview.join('\n'),
      itineraryNote: detail?.itineraryNote ?? dayDetail?.itineraryNote ?? '',
      included: (detail?.included ?? dayDetail?.included ?? []).join('\n'),
      excluded: (detail?.excluded ?? dayDetail?.excluded ?? []).join('\n'),
    } satisfies BasicForm,
    addOns: addonsSource.map((item) => ({ id: id('addon'), translations: item.translations, title: item.title, price: item.price === undefined ? '' : String(item.price) })),
    categorySlugs: [...(tour.categorySlugs ?? [])],
    highlightImage: detail?.highlightImage ?? dayDetail?.highlightImage ?? gallerySource[0] ?? tour.image,
    highlights: highlightsSource.map((group) => ({ id: id('highlight'), translations: group.translations, title: group.title, items: group.items.join('\n') })),
    itinerary: itinerarySource.map((item, index) => ({ id: id('day'), translations: item.translations, day: item.day, title: item.title, description: item.description, meals: item.meals ?? '', image: item.image ?? detail?.itineraryImages?.[index] ?? '' })),
    travelerPrices: {
      adult: travelerSource.map((item) => ({ id: id('adult-price'), travelers: String(item.travelers), price: String(item.adultPrice ?? item.price ?? fallbackPrice) })),
      child: travelerSource.map((item) => ({ id: id('child-price'), travelers: String(item.travelers), price: String(item.childPrice ?? item.adultPrice ?? item.price ?? fallbackPrice) })),
      infant: travelerSource.map((item) => ({ id: id('infant-price'), travelers: String(item.travelers), price: String(item.infantPrice ?? 0) })),
    } satisfies TravelerPriceRows,
    priceRows: priceSource.map((row) => ({ id: id('price-row'), translations: row.translations, category: row.category, startDate: row.startDate ?? '', endDate: row.endDate ?? '', price: String(row.price), note: row.note, prefix: row.prefix ?? '', tiers: (row.tiers ?? []).map((tier) => ({ id: id('price-tier'), translations: tier.translations, label: tier.label, price: String(tier.price), suffix: tier.suffix ?? '' })) })),
    locations: locationRows(detail?.locations ?? dayDetail?.locations, tour.location, detail?.locationTranslations ?? dayDetail?.locationTranslations),
    gallery: gallerySource.map((src, index) => ({ id: id('gallery'), src, translations: tour.galleryCaptions?.[index]?.translations, altAr: tour.galleryCaptions?.[index]?.ar, alt: tour.galleryCaptions?.[index]?.en ?? `${tour.title} ${index + 1}`, creditLabel: tour.photoCredits?.[index]?.label ?? '', creditUrl: tour.photoCredits?.[index]?.url ?? '', source: 'link' as const })).filter(row => row.src.trim()),
    videos: (tour.journeyVideos ?? []).map((video) => ({ id: video.id || id('video'), translations: video.translations, url: video.url, platform: video.platform ?? 'youtube', title: video.title, titleAr: video.titleAr ?? '', publishedAt: video.publishedAt.slice(0, 10), thumbnail: video.thumbnail ?? '' })),
  }
}

/**
 * A brand-new tour starts blank. It carries only the structural defaults the
 * builder and the API require (empty identity, empty collections), so no
 * existing tour's title, price, location, duration or travel style is ever
 * prefilled into a new record. Editing an existing tour still loads the real
 * saved record through load() (driven by ?slug=).
 */
export function blankTour(): Tour {
  return {
    slug: '',
    title: '',
    category: 'one-day-tours',
    location: '',
    duration: '',
    price: 0,
    summary: '',
    image: '',
    groupSize: '',
    travelStyle: '',
    categorySlugs: [],
    gallery: [],
  }
}

export function TripBuilder({ initialSlug, previewAppearance }: { initialSlug?: string | null; previewAppearance?: AppearanceTokens } = {}) {
  const i18n = useAdminTranslations("admin.tours")

  const ar = useAdminLocale() === 'ar'
  const clearedPreviewTranslations = useRef(new Set<string>())
  const initialTour = blankTour()
  const initial = editorData(initialTour)
  const [sourceTour, setSourceTour] = useState(initialTour)
  const [loadingTour, setLoadingTour] = useState(Boolean(initialSlug))
  const [loadAttempt, setLoadAttempt] = useState(0)
  // Canonical slug being edited (null = creating a new tour). Set from
  // ?slug= on load and after a successful POST so later saves update it.
  const [editingSlug, setEditingSlug] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const mediaUploadCount = useRef(0)
  const [mediaUploads, setMediaUploads] = useState(0)
  const uploadActivity = (active: boolean) => {
    mediaUploadCount.current = Math.max(0, mediaUploadCount.current + (active ? 1 : -1))
    setMediaUploads(mediaUploadCount.current)
  }
  const [visBusy, setVisBusy] = useState(false)
  // Publish state of the loaded record (new tours publish on first save).
  const tourVisible = (sourceTour?.status ?? 'published') === 'published'
  // Publish / Unpublish without touching other fields: PUT accepts a
  // status-only patch (every other field falls back to the stored row).
  const setVisibility = async (published: boolean) => {
    if (!editingSlug || visBusy) return
    setVisBusy(true)
    setError('')
    try {
      const res = await fetch(`/api/tours/${encodeURIComponent(editingSlug)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: published ? 'published' : 'draft', expectedUpdatedAt: (sourceTour as Tour & { updatedAt?: string }).updatedAt }),
        credentials: 'same-origin',
      })
      if (!res.ok) {
        const data = await res.json().catch(() => ({} as { error?: string }))
        throw new Error(data.error || 'Failed to update visibility.')
      }
      const response = await res.json()
      setSourceTour(response.tour)
      invalidateToursCache()
      toast.success(
        published
          ? (ar ? 'تم نشر الرحلة. ستظهر في الموقع العام.' : 'Tour published. It now appears on the public website.')
          : (ar ? 'تم إخفاء الرحلة. لن تظهر في الموقع العام.' : 'Tour unpublished. It is now hidden from the public website.'),
        { dedupeKey: 'tour-visibility' },
      )
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update visibility.', { dedupeKey: 'tour-visibility-error' })
    } finally {
      setVisBusy(false)
    }
  }
  const [activeStep, setActiveStep] = useState(0)
  // Step 11 (index steps.length - 1) is the maximum valid builder step.
  // All navigation paths clamp here; nothing may advance beyond it.
  const isLastStep = activeStep >= steps.length - 1
  const step = activeStep === 4 ? -1 : activeStep > 4 ? activeStep - 1 : activeStep
  const [stepLanguages, setStepLanguages] = useState<Partial<Record<number, AdminContentLocale>>>({})
  const contentLocale = stepLanguages[activeStep] ?? 'en'
  const localText = <T extends Translatable,>(row: T, key: keyof T & string) => readTourText(row, key, contentLocale)
  const editText = <T extends Translatable,>(row: T, key: keyof T & string, value: string) => {
    const marker = previewTextKey(row, key, contentLocale)
    if (contentLocale !== 'en' && value === '') clearedPreviewTranslations.current.add(marker)
    else clearedPreviewTranslations.current.delete(marker)
    return writeTourText(row, key, value, contentLocale)
  }
  const [done, setDone] = useState<number[]>([])
  const [form, setForm] = useState<BasicForm>(initial.form)
  const [catSlugs, setCatSlugs] = useState<string[]>(initial.categorySlugs)
  const [addOns, setAddOns] = useState<AddOnRow[]>(initial.addOns)
  const [highlightImage, setHighlightImage] = useState(initial.highlightImage)
  const [highlights, setHighlights] = useState<HighlightRow[]>(initial.highlights)
  const [itinerary, setItinerary] = useState<ItineraryRow[]>(initial.itinerary)
  const [travelerPrices, setTravelerPrices] = useState<TravelerPriceRows>(initial.travelerPrices)
  const [priceRows, setPriceRows] = useState<PriceMatrixRow[]>(initial.priceRows)
  const [locations, setLocations] = useState<LocationRow[]>(initial.locations)
  const [gallery, setGallery] = useState<GalleryRow[]>(initial.gallery)
  const [videos, setVideos] = useState<VideoRow[]>(initial.videos)
  const [mediaLink, setMediaLink] = useState('')
  const [mediaAlt, setMediaAlt] = useState('')
  const [mediaCreditLabel, setMediaCreditLabel] = useState('')
  const [mediaCreditUrl, setMediaCreditUrl] = useState('')
  const [previewAdults, setPreviewAdults] = useState(2)
  const [previewChildren, setPreviewChildren] = useState(0)
  const [previewInfants, setPreviewInfants] = useState(0)
  // Route slug for a new tour (the slug field is read-only when editing).
  const [newSlug, setNewSlug] = useState('')
  const [error, setError] = useState('')
  // Serialized snapshot of the last persisted editor state. Compared
  // against the live editor state to decide whether Save & Publish shows.
  // Step navigation and preview controls never touch these fields.
  const [baseline, setBaseline] = useState<string | null>(() =>
    JSON.stringify({
      form: initial.form, catSlugs: initial.categorySlugs, addOns: initial.addOns,
      highlightImage: initial.highlightImage, highlights: initial.highlights,
      itinerary: initial.itinerary, travelerPrices: initial.travelerPrices,
      priceRows: initial.priceRows, locations: initial.locations,
      gallery: initial.gallery, videos: initial.videos,
    }),
  )

  const load = (tour: Tour) => {
    clearedPreviewTranslations.current.clear()
    const data = editorData(tour)
    setSourceTour(tour)
    setForm(data.form)
    setCatSlugs(data.categorySlugs)
    setAddOns(data.addOns)
    setHighlightImage(data.highlightImage)
    setHighlights(data.highlights)
    setItinerary(data.itinerary)
    setTravelerPrices(data.travelerPrices)
    setPriceRows(data.priceRows)
    setLocations(data.locations)
    setGallery(data.gallery)
    setVideos(data.videos)
    // Loaded DB state is clean by definition.
    setBaseline(JSON.stringify({
      form: data.form, catSlugs: data.categorySlugs, addOns: data.addOns,
      highlightImage: data.highlightImage, highlights: data.highlights,
      itinerary: data.itinerary, travelerPrices: data.travelerPrices,
      priceRows: data.priceRows, locations: data.locations,
      gallery: data.gallery, videos: data.videos,
    }))
  }

  // DB-authoritative pickers: new destinations/categories appear without reload.
  const destinationStatus = useDbDestinationsStatus()
  const destinationOptions = tripDestinationOptions(destinationStatus.data ?? [], contentLocale, form.destinationSlug)
  const dbCategories = useDbCategories(multiDayCategories)

  useEffect(() => {
    const slug = initialSlug === undefined ? new URLSearchParams(window.location.search).get('slug') : initialSlug
    if (!slug) return
    setLoadingTour(true)
    setError('')
    // DB-authoritative load (no static/localStorage fallback).
    let cancelled = false
    const loadFromDb = async () => {
      try {
        const res = await fetch(`/api/tours/${encodeURIComponent(slug)}`, { credentials: 'same-origin' })
        const data = await res.json()
        if (cancelled) return
        if (!res.ok || !data.tour) {
          setError(data.error || 'Tour not found in the database.')
          return
        }
        if (!cancelled) {
          load(data.tour as Tour)
          // Resolve to the canonical slug (supports opening via an alias).
          setEditingSlug((data.tour as Tour).slug)
        }
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : 'Failed to load tour.')
      } finally {
        if (!cancelled) setLoadingTour(false)
      }
    }
    void loadFromDb()
    return () => { cancelled = true }
  }, [initialSlug, loadAttempt])

  const set = (key: keyof BasicForm) => (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm((current) => ['title', 'location', 'duration', 'groupSize', 'travelStyle', 'summary', 'overview', 'itineraryNote', 'included', 'excluded', 'departurePort'].includes(key)
      ? editText(current, key, event.target.value)
      : { ...current, [key]: event.target.value })

  /** String-value adapter so shared dropdowns reuse the same form update. */
  const setField = (key: keyof BasicForm) => (next: string) =>
    setForm((current) => ({ ...current, [key]: next }))

  const toggleCatSlug = (slug: string) =>
    setCatSlugs((current) => current.includes(slug) ? current.filter((entry) => entry !== slug) : [...current, slug])

  const next = () => {
    setDone((current) => current.includes(activeStep) ? current : [...current, activeStep])
    setActiveStep((current) => Math.min(current + 1, steps.length - 1))
  }

  const addMediaLink = () => {
    const src = mediaLink.trim()
    if (!isTourImage(src)) {
      setError(ar ? 'أدخل رابط صورة صحيحا.' : 'Upload an image or use a local, Unsplash or Wikimedia image URL.')
      return
    }
    setGallery((current) => [...current, { id: id('gallery'), src, alt: mediaAlt.trim() || form.title, creditLabel: mediaCreditLabel.trim(), creditUrl: mediaCreditUrl.trim(), source: 'link' as const }].slice(0, 12))
    setMediaLink('')
    setMediaAlt('')
    setMediaCreditLabel('')
    setMediaCreditUrl('')
    setError('')
  }

  const uploadGallery = async (files: FileList | null) => {
    if (!files || saving) return
    uploadActivity(true)
    try {
      const batch = Array.from(files).slice(0, 12)
      const loaded = await Promise.all(batch.map(async (file) => ({ file, url: await uploadImageFile(file) })))
      const valid = loaded.filter((item): item is { file: File; url: string } => Boolean(item.url)).map(({ file, url }) => ({ id: id('gallery'), src: url, alt: file.name, creditLabel: '', creditUrl: '', source: 'upload' as const }))
      setGallery((current) => [...current, ...valid].slice(0, 12))
      if (valid.length !== loaded.length) setError(ar ? 'بعض الصور لم تُقبل. الحد 1.5MB للصورة.' : 'Some images were rejected. The limit is 1.5MB per image.')
    } finally { uploadActivity(false) }
  }

  const cleanTravelerPrices = useMemo(() => cleanTravelerPriceRows(travelerPrices), [travelerPrices])

  // Unsaved-changes detection: every persisted editor field serialized.
  // New (never-saved) tours always show Save & Publish until the first
  // successful save; step navigation never alters these fields.
  const currentSnapshot = useMemo(
    () =>
      JSON.stringify({
        form, catSlugs, addOns, highlightImage, highlights, itinerary,
        travelerPrices, priceRows, locations, gallery, videos,
      }),
    [form, catSlugs, addOns, highlightImage, highlights, itinerary, travelerPrices, priceRows, locations, gallery, videos],
  )
  const showSave = editingSlug === null || baseline === null || baseline !== currentSnapshot

  const publish = async (targetStatus: 'draft' | 'published' = 'published') => {
    setError('')
    if (mediaUploadCount.current > 0) { setError('Wait for image uploads to finish before saving.'); return }
    if (saving || visBusy) return
    const missingEnglish = addOns.some((row) => row.translations && !row.title.trim())
      || itinerary.some((row) => row.translations && !row.title.trim() && !row.description.trim())
      || highlights.some((row) => row.translations && !row.title.trim() && !row.items.trim())
      || locations.some((row) => row.translations && !row.name.trim())
      || videos.some((row) => row.translations && !row.title.trim())
      || priceRows.some((row) => row.translations && !row.category.trim() || row.tiers.some((tier) => tier.translations && (!tier.label.trim() || tier.price === '')))
    if (missingEnglish) {
      setError(ar ? 'أكمل المحتوى الإنجليزي للعناصر المترجمة قبل الحفظ.' : 'Complete the English content for translated items before saving.')
      return
    }
    const basePrice = Number(form.price)
    if (targetStatus === 'published' && !gallery[0]?.src.trim()) {
      setError(ar ? 'أضف صورة غلاف قبل النشر.' : 'Add a cover image before publishing. The preview can remain image-free while editing.')
      return
    }
    if (!form.title.trim() || !form.duration.trim() || form.price.trim() === '' || !Number.isFinite(basePrice) || basePrice < 0) {
      setError(ar ? 'راجع العنوان والمدة والسعر الأساسي قبل النشر.' : 'Check the title, duration, and base price before publishing.')
      return
    }
    if (form.category === 'one-day-tours' && !form.destinationSlug) {
      setError(ar ? 'اختر الوجهة قبل نشر رحلة اليوم الواحد.' : 'Select the destination before publishing the one-day tour.')
      return
    }
    if (form.category === 'multi-days-tours' && !catSlugs.length) {
      setError(ar ? 'اختر فئة واحدة على الأقل قبل نشر رحلة متعددة الأيام.' : 'Select at least one category before publishing the multi-day tour.')
      return
    }
    if (form.category === 'nile-cruises' && !form.cruiseType) {
      setError(ar ? 'اختر نوع الرحلة النيلية قبل النشر.' : 'Select the Nile cruise type before publishing.')
      return
    }
    if (form.category === 'shore-excursions' && !form.departurePort.trim()) {
      setError(ar ? 'أدخل ميناء الانطلاق قبل نشر الرحلة الساحلية.' : 'Enter the departure port before publishing the shore excursion.')
      return
    }
    const invalidTravelerPricing = (Object.keys(travelerPrices) as Array<keyof TravelerPriceRows>).some((type) => {
      const rows = travelerPrices[type]
      return !rows.length || rows.some((row) => !isValidPassengerRate(row)) || new Set(rows.map((row) => Number(row.travelers))).size !== rows.length
    })
    if (invalidTravelerPricing) {
      setError(ar ? 'راجع عدد المسافرين وأسعار البالغ والطفل والرضيع. يجب أن تكون القيم صحيحة وغير مكررة.' : 'Check traveler counts and every adult, child, and infant rate. Counts must be valid and unique.')
      return
    }
    const invalidDetailedPrice = priceRows.some((row) => row.price !== '' && (!Number.isFinite(Number(row.price)) || Number(row.price) < 0)
      || !row.category.trim()
      || Boolean(row.startDate) !== Boolean(row.endDate)
      || Boolean(row.startDate && row.endDate && row.endDate < row.startDate)
      || !row.tiers.length
      || row.tiers.some((tier) => !tier.label.trim() || tier.price === '' || !Number.isFinite(Number(tier.price)) || Number(tier.price) < 0))
    if (invalidDetailedPrice) {
      setError(ar ? 'راجع فترات السفر وأسعارها. يلزم عنوان للفترة، وتاريخا البداية والنهاية معا عند استخدامهما، وشريحة سعر واحدة على الأقل.' : 'Check date pricing. Each period needs a title, both dates when dates are used, and at least one valid price tier.')
      return
    }
    const invalidVideo = videos.find((row) => {
      const hasData = row.url.trim() || row.title.trim() || row.titleAr.trim() || row.publishedAt || row.thumbnail.trim()
      return hasData && (!row.url.trim() || !row.title.trim() || !isSafeExternalUrl(row.url.trim()) || Boolean(row.thumbnail.trim()) && !isSafeExternalUrl(row.thumbnail.trim()))
    })
    if (invalidVideo) {
      setError(ar ? 'كل فيديو يحتاج عنوانا ورابط HTTPS صحيحا.' : 'Every video needs a title and a valid HTTPS URL.')
      return
    }
    const invalidCredit = gallery.find((item) => Boolean(item.creditLabel.trim()) !== Boolean(item.creditUrl.trim()) || item.creditUrl.trim() && !isSafeExternalUrl(item.creditUrl.trim()))
    if (invalidCredit) {
      setError(ar ? 'بيانات مصدر الصورة تحتاج اسما ورابط HTTPS صحيحا معا.' : 'Photo credits need both a label and a valid HTTPS URL.')
      return
    }
    const savedLocations: TourLocation[] = locations.filter((row) => row.name.trim()).map((row) => {
      const latitude = Number(row.latitude)
      const longitude = Number(row.longitude)
      return Number.isFinite(latitude) && Number.isFinite(longitude) && row.latitude !== '' && row.longitude !== ''
        ? { id: row.id, name: row.name.trim(), nameAr: row.nameAr.trim() || undefined, latitude, longitude }
        : row.name.trim()
    })
    const savedItinerary = itinerary.filter((row) => row.title.trim() || row.description.trim()).map((row, index) => ({
      translations: row.translations,
      day: row.day.trim() || (form.category === 'one-day-tours' ? `Stop ${index + 1}` : `Day ${index + 1}`),
      title: row.title.trim(),
      description: row.description.trim(),
      meals: row.meals.trim() || undefined,
      image: row.image.trim() || undefined,
    }))
    const savedAddOns = addOns.filter((row) => row.title.trim()).map((row) => ({ translations: row.translations, title: row.title.trim(), price: row.price === '' ? undefined : Number(row.price) }))
    const savedHighlights = highlights.filter((row) => row.title.trim() || splitLines(row.items).length).map((row) => ({ translations: row.translations, title: row.title.trim() || 'Highlights', items: splitLines(row.items) }))
    const savedPriceRows = priceRows.filter((row) => row.category.trim()).map((row) => ({
      translations: row.translations,
      category: row.category.trim(),
      price: Number(row.price) || 0,
      note: row.note.trim(),
      startDate: row.startDate || undefined,
      endDate: row.endDate || undefined,
      prefix: row.prefix.trim() || undefined,
      tiers: row.tiers.filter((tier) => tier.label.trim() && tier.price !== '').map((tier) => ({ translations: tier.translations, label: tier.label.trim(), price: Number(tier.price), suffix: tier.suffix.trim() || undefined })),
    }))
    const savedVideos = videos.filter((row) => row.url.trim() && row.title.trim()).map((row) => ({
      id: row.id,
      translations: row.translations,
      url: row.url.trim(),
      platform: row.platform,
      title: row.title.trim(),
      titleAr: row.titleAr.trim() || undefined,
      publishedAt: row.publishedAt || '',
      thumbnail: row.thumbnail.trim() || undefined,
    }))
    const overview = isHtmlContent(form.overview) ? [sanitizeRichText(form.overview)] : splitLines(form.overview)
    const galleryImages = gallery.map((item) => item.src)
    const common: Tour = {
      ...sourceTour,
      status: targetStatus,
      title: form.title.trim(),
      titleAr: form.titleAr.trim() || undefined,
      category: form.category,
      cruiseType: form.category === 'nile-cruises' ? form.cruiseType || undefined : undefined,
      departurePort: form.category === 'shore-excursions' ? form.departurePort.trim() || undefined : undefined,
      destinationSlug: form.category === 'one-day-tours' ? form.destinationSlug || null : null,
      categorySlugs: form.category === 'multi-days-tours' ? [...catSlugs] : [],
      location: form.location.trim(),
      duration: form.duration.trim(),
      price: basePrice,
      image: galleryImages[0] ?? '',
      gallery: galleryImages,
      galleryCaptions: gallery.map((item) => ({ en: item.alt, ar: item.altAr ?? item.alt, translations: item.translations })),
      photoCredits: gallery.filter((item) => item.creditLabel.trim() && item.creditUrl.trim()).map((item) => ({ label: item.creditLabel.trim(), url: item.creditUrl.trim() })),
      journeyVideos: savedVideos,
      summary: form.summary.trim(),
      groupSize: form.groupSize.trim() || undefined,
      travelStyle: form.travelStyle.trim() || undefined,
      deal: Number(form.deal) > 0 && form.dealEndsAt ? { percent: Number(form.deal), endsAt: form.dealEndsAt } : undefined,
    }
    const saved: Tour = form.category === 'one-day-tours' ? {
      ...common,
      dayDetail: {
        ...(sourceTour.dayDetail ?? { overview: [] }),
        translations: form.translations,
        overview,
        highlightImage: highlightImage.trim() || undefined,
        itineraryNote: form.itineraryNote.trim() || undefined,
        highlightGroups: savedHighlights,
        highlights: savedHighlights.flatMap((group) => group.items),
        stops: savedItinerary.map(({ day, title, description, meals, image, translations }) => ({ day, title, description, meals, image, translations })),
        gallery: gallery.map((item) => ({ src: item.src, alt: item.alt })),
        included: splitLines(form.included),
        excluded: splitLines(form.excluded),
        addOns: savedAddOns,
        locationTranslations: locations.filter((row) => row.name.trim()).map((row) => row.translations ?? null),
        locations: savedLocations,
        priceRows: savedPriceRows,
        travelerPrices: cleanTravelerPrices,
      },
    } : {
      ...common,
      detail: {
        ...(sourceTour.detail ?? { highlights: [], itinerary: [], locations: [] }),
        translations: form.translations,
        overview,
        highlightImage: highlightImage.trim() || undefined,
        itineraryNote: form.itineraryNote.trim() || undefined,
        highlights: savedHighlights,
        itinerary: savedItinerary,
        itineraryImages: [],
        included: splitLines(form.included),
        excluded: splitLines(form.excluded),
        addOns: savedAddOns,
        locationTranslations: locations.filter((row) => row.name.trim()).map((row) => row.translations ?? null),
        locations: savedLocations,
        priceRows: savedPriceRows,
        travelerPrices: cleanTravelerPrices,
      },
    }
    // Save & Publish: the ONLY persistence path, straight to the database.
    // - Editing (?slug= loaded): PUT updates exactly that DB row.
    // - Creating (no ?slug=): POST inserts exactly one row; a taken slug is
    //   reported as an error and never silently overwritten (no duplicates).
    if (saving) return
    setSaving(true)
    try {
      let method: 'POST' | 'PUT' = 'PUT'
      let url = ''
      let finalSlug = ''
      if (editingSlug) {
        method = 'PUT'
        finalSlug = editingSlug
        url = `/api/tours/${encodeURIComponent(editingSlug)}`
      } else {
        const slug = newSlug.trim().toLowerCase()
        if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug) || slug.length > 80) {
          setError(ar ? 'أدخل رابطا جديدا صحيحا: حروف إنجليزية صغيرة وأرقام وشرطات.' : 'Enter a valid new route slug: lowercase letters, numbers, and hyphens.')
          setSaving(false)
          return
        }
        method = 'POST'
        finalSlug = slug
        url = '/api/tours'
      }
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(tourWritePayload({ ...saved, slug: finalSlug }, targetStatus)),
        credentials: 'same-origin',
      })
      const data = await res.json().catch(() => ({} as { error?: string; tour?: Tour }))
      if (res.status === 409) throw new Error(data.error || 'This tour changed or its slug is already in use. Reload before saving again.')
      if (!res.ok) throw new Error(data.error || 'Failed to save tour')
      const persisted = (data.tour as Tour | undefined) ?? saved
      setSourceTour(persisted)
      setEditingSlug(persisted.slug)
      invalidateToursCache()
      try {
        const nextUrl = new URL(window.location.href)
        nextUrl.searchParams.set('slug', persisted.slug)
        window.history.replaceState(null, '', nextUrl.toString())
      } catch { /* non-fatal */ }
      setDone(steps.map((_, index) => index))
      toast.success(ar ? 'تم حفظ الرحلة في قاعدة البيانات.' : 'Tour saved to the database.', { dedupeKey: 'tour-save' })
      // Successful save marks the editor clean, hiding Save & Publish until
      // the next edit. Failures leave the baseline untouched (button stays).
      setBaseline(currentSnapshot)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : (ar ? 'فشل حفظ الرحلة في قاعدة البيانات.' : 'Failed to save tour to database.'), { dedupeKey: 'tour-save-error' })
    } finally {
      setSaving(false)
    }
  }

  const repeatHeader = (title: React.ReactNode, index: number, remove: () => void) => <header><span>{index + 1}</span><strong>{title}</strong><button type="button" onClick={remove} aria-label={ar ? 'حذف العنصر' : i18n("admin.shared.removeItem")} title={ar ? 'حذف' : i18n("admin.shared.remove")}><Trash2 size={16} /></button></header>

  const pricingGroups = [
    { type: 'adult' as const, en: 'Adults', ar: 'البالغون', defaultPrice: form.price },
    { type: 'child' as const, en: 'Children', ar: 'الأطفال', defaultPrice: form.price },
    { type: 'infant' as const, en: 'Infants', ar: 'الرضع', defaultPrice: '0' },
  ]
  const addPassengerRate = (type: keyof TravelerPriceRows, defaultPrice: string) => setTravelerPrices((current) => {
    const rows = current[type]
    const nextCount = Math.max(0, ...rows.map((item) => Number(item.travelers) || 0)) + 1
    return { ...current, [type]: [...rows, { id: id(`${type}-price`), travelers: String(nextCount), price: defaultPrice }] }
  })
  const updatePassengerRate = (type: keyof TravelerPriceRows, rowId: string, key: 'travelers' | 'price', value: string) => setTravelerPrices((current) => ({
    ...current,
    [type]: current[type].map((row) => row.id === rowId ? { ...row, [key]: value } : row),
  }))
  const removePassengerRate = (type: keyof TravelerPriceRows, rowId: string) => setTravelerPrices((current) => ({
    ...current,
    [type]: current[type].filter((row) => row.id !== rowId),
  }))

  if (loadingTour) return <Card title={i18n("admin.tours.tripBuilder")}><p role="status">{i18n("admin.tours.loadingTrip")}</p></Card>
  if (initialSlug && !sourceTour.slug) return <Card title={i18n("admin.tours.tripBuilder")}><p role="alert">{error || i18n("admin.tours.couldNotLoadTrip")}</p><button type="button" className="sp-btn" onClick={() => setLoadAttempt(value => value + 1)}>{i18n("admin.shared.retry")}</button></Card>

  return <>
    <PageHead eyebrow={i18n("admin.tours.tripBuilder")} title={i18n("admin.tours.tripBuilder")} titleAr="منشئ الرحلات" sub={i18n("admin.tours.editTheCompleteTourExperienceFromOne_5115615")} subAr="عدّل تجربة الرحلة كاملة من مسار عمل منظم" backHref="/admin/trips" actions={isLastStep ? (
      // Final step: navigation only  -  never advances the builder, never saves.
      editingSlug ? <a className="sp-btn dark" href={`/all-tours/${encodeURIComponent(editingSlug)}`} target="_blank" rel="noopener noreferrer"><ExternalLink size={16} /> <AdminText en="View Tour" ar="عرض الرحلة" /></a> : null
    ) : (
      <button type="button" className="sp-btn dark" onClick={next} disabled={saving || visBusy || mediaUploads > 0}><ArrowRight size={16} /> <AdminText en="Continue" ar="متابعة" /></button>
    )} />
    <nav className="sp-builder-timeline" aria-label={i18n("admin.tours.tripBuilderSteps")}>
      <ol className="sp-steps">{steps.map((item, index) => {
        const current = index === activeStep
        const completed = done.includes(index)
        return <li key={item.en} className={current ? 'active' : completed ? 'done' : ''}>
          <button type="button" aria-current={current ? 'step' : undefined} aria-label={`${index + 1}. ${ar ? item.ar : item.en}${completed ? i18n("admin.shared.completed") : ''}`} onClick={() => setActiveStep(index)}>
            <span className="sp-step-node" aria-hidden="true">{completed && !current ? <CheckCircle2 size={16} /> : index + 1}</span>
            <span className="sp-step-label">{ar ? item.ar : item.en}</span>
          </button>
        </li>
      })}</ol>
    </nav>

    <div className="sp-builder">
      <Card title={ar ? steps[activeStep].ar : steps[activeStep].en} sub={<AdminText en="Every field feeds the public tour detail experience" ar="كل حقل يغذي تجربة صفحة الرحلة العامة" />}>
        <Tabs.Root value={contentLocale} onValueChange={(value) => {
          if (ADMIN_CONTENT_LOCALES.some((locale) => locale === value)) setStepLanguages((current) => ({ ...current, [activeStep]: value as AdminContentLocale }))
        }} className="sp-builder-languages">
          {activeStep !== 1 && activeStep !== 10 && <Tabs.List className="sp-builder-language-tabs" aria-label={ar ? 'لغة محتوى الرحلة' : i18n("admin.tours.tourContentLanguage")}>
            {ADMIN_CONTENT_LOCALES.map((locale) => <Tabs.Tab key={locale} value={locale}>{LOCALE_LABELS[locale]}</Tabs.Tab>)}
          </Tabs.List>}
          <Tabs.Panel value={contentLocale} className="sp-form" render={<div lang={contentLocale} />}>
          {step === 4 && <div className="sp-field"><span className="sp-label"><AdminText en="Itinerary note" ar="ملاحظة البرنامج" /></span><RichTextEditor value={localText(form, 'itineraryNote')} onChange={(html) => setForm((curr) => writeTourText(curr, 'itineraryNote', html, contentLocale))} minHeight={100} dir={(contentLocale as string) === 'ar' ? 'rtl' : 'ltr'} placeholder={ar ? 'ملاحظة تظهر أعلى أيام أو محطات البرنامج' : i18n("admin.tours.shownAboveTheItineraryDaysOrStops")} /></div>}
          {step === 7 && gallery.length>0&&<div className="sp-media-alt-list"><strong><AdminText en="Gallery image descriptions" ar="أوصاف صور المعرض" /></strong>{gallery.map((image, index) => <label key={image.id}><AdminText en={`Image ${index + 1} description`} ar={`وصف الصورة ${index + 1}`} /><input value={localText(image, 'alt')} onChange={(event) => setGallery((current) => current.map((item) => item.id === image.id ? editText(item, 'alt', event.target.value) : item))} /></label>)}</div>}
          {step === 9 && <div className="sp-builder-note"><CheckCircle2 size={17}/><AdminText en="Related Tours are selected automatically from the tour category and destination. Customer reviews are submitted and moderated separately, so neither should be authored as tour content here." ar="يتم اختيار الرحلات ذات الصلة تلقائيا حسب تصنيف الرحلة والوجهة. أما تقييمات العملاء فتُرسل وتُراجع بشكل منفصل، لذلك لا يتم تأليف أي منهما كمحتوى للرحلة هنا." /></div>}
          {step === 9 && <div className="sp-builder-coverage"><span><b>{videos.length}</b><AdminText en="journey videos" ar="فيديوهات رحلة" /></span><span><b>{priceRows.length}</b><AdminText en="detailed price rows" ar="صفوف أسعار تفصيلية" /></span><span><b>{gallery.filter((item) => item.creditLabel && item.creditUrl).length}</b><AdminText en="photo credits" ar="مصادر صور" /></span><span><b>{form.itineraryNote ? 1 : 0}</b><AdminText en="itinerary note" ar="ملاحظة برنامج" /></span></div>}
          {step === 6 && <><div className="sp-builder-subhead"><div><strong><AdminText en="Tour date price calendar" ar="تقويم أسعار مواعيد الرحلة" /></strong><small><AdminText en="Create one card for each travel period, then add Solo, 2 PAX, group, cabin, or other prices inside it." ar="أنشئ كارتا لكل فترة سفر، ثم أضف داخله أسعار الفردي أو شخصين أو المجموعة أو الكابينة." /></small></div><button type="button" className="sp-btn" onClick={() => setPriceRows((current) => [...current, { id: id('price-row'), category: '', startDate: '', endDate: '', price: '', note: '', prefix: '', tiers: [{ id: id('price-tier'), label: 'Solo', price: form.price, suffix: 'per person' }] }])}><Plus size={16}/><AdminText en="Add travel period" ar="إضافة فترة سفر" /></button></div><div className="sp-repeat-list">{priceRows.map((row, index) => <article className="sp-repeat-card sp-date-price-card" key={row.id}>{repeatHeader(<AdminText en="Travel period" ar="فترة سفر" />, index, () => setPriceRows((current) => current.filter((item) => item.id !== row.id)))}<label><AdminText en="Period title" ar="عنوان الفترة" /><input value={localText(row, 'category')} placeholder={ar ? 'مثال: 1 - 10 يناير 2027' : i18n("admin.tours.example110January2027")} onChange={(event) => setPriceRows((current) => current.map((item) => item.id === row.id ? editText(item, 'category', event.target.value) : item))} /></label><div className="sp-form-2"><label><AdminText en="Start date" ar="تاريخ البداية" /><DateInput value={row.startDate} onChange={(event) => setPriceRows((current) => current.map((item) => item.id === row.id ? { ...item, startDate: event.target.value } : item))} /></label><label><AdminText en="End date" ar="تاريخ النهاية" /><DateInput value={row.endDate} min={row.startDate || undefined} onChange={(event) => setPriceRows((current) => current.map((item) => item.id === row.id ? { ...item, endDate: event.target.value } : item))} /></label></div><label><AdminText en="Period note (optional)" ar="ملاحظة الفترة (اختياري)" /><input value={localText(row, 'note')} placeholder={ar ? 'مثال: موسم الذروة' : i18n("admin.tours.examplePeakSeason")} onChange={(event) => setPriceRows((current) => current.map((item) => item.id === row.id ? editText(item, 'note', event.target.value) : item))} /></label><div className="sp-tier-editor"><div className="sp-tier-editor-head"><strong><AdminText en="Prices in this period" ar="أسعار هذه الفترة" /></strong><button type="button" className="sp-btn" onClick={() => setPriceRows((current) => current.map((item) => item.id === row.id ? { ...item, tiers: [...item.tiers, { id: id('price-tier'), label: '', price: '', suffix: 'per person' }] } : item))}><Plus size={15}/><AdminText en="Add period price" ar="إضافة سعر للفترة" /></button></div>{row.tiers.map((tier) => <div className="sp-tier-row" key={tier.id}><input value={localText(tier, 'label')} aria-label={ar ? 'اسم شريحة السعر' : i18n("admin.tours.priceTierLabel")} placeholder={ar ? 'فردي أو 2 PAX أو 3-10 PAX' : i18n("admin.tours.solo2PaxOr310Pax")} onChange={(event) => setPriceRows((current) => current.map((item) => item.id === row.id ? { ...item, tiers: item.tiers.map((entry) => entry.id === tier.id ? editText(entry, 'label', event.target.value) : entry) } : item))} /><input type="number" min="0" step="0.01" value={tier.price} aria-label={ar ? 'السعر' : i18n("admin.tours.price")} placeholder="0" onChange={(event) => setPriceRows((current) => current.map((item) => item.id === row.id ? { ...item, tiers: item.tiers.map((entry) => entry.id === tier.id ? { ...entry, price: event.target.value } : entry) } : item))} /><input value={localText(tier, 'suffix')} aria-label={ar ? 'وحدة السعر' : i18n("admin.tours.priceUnit")} placeholder={ar ? 'للفرد' : i18n("admin.tours.perPerson")} onChange={(event) => setPriceRows((current) => current.map((item) => item.id === row.id ? { ...item, tiers: item.tiers.map((entry) => entry.id === tier.id ? editText(entry, 'suffix', event.target.value) : entry) } : item))} /><button type="button" className="sp-icon-btn danger" onClick={() => setPriceRows((current) => current.map((item) => item.id === row.id ? { ...item, tiers: item.tiers.filter((entry) => entry.id !== tier.id) } : item))} aria-label={ar ? 'حذف سعر الفترة' : i18n("admin.tours.removePeriodPrice")}><Trash2 size={15}/></button></div>)}</div></article>)}</div></>}
          {step === 7 && <>
            <div className="sp-builder-subhead"><div><strong><AdminText en="Journey video reels" ar="فيديوهات الرحلة" /></strong><small><AdminText en="Newest dated videos appear first on the public page." ar="تظهر الفيديوهات الأحدث تاريخا أولا في صفحة الرحلة." /></small></div><button type="button" className="sp-btn" onClick={() => setVideos((current) => [...current, { id: id('video'), url: '', platform: 'youtube', title: '', titleAr: '', publishedAt: '', thumbnail: '' }])}><Plus size={16}/><AdminText en="Add video" ar="إضافة فيديو" /></button></div>
            <div className="sp-repeat-list">{videos.map((row, index) => <article className="sp-repeat-card" key={row.id}>
              {repeatHeader(<AdminText en="Journey video" ar="فيديو الرحلة" />, index, () => setVideos((current) => current.filter((item) => item.id !== row.id)))}
              <div className="sp-form-2"><label><AdminText en="Video URL" ar="رابط الفيديو" /><input value={row.url} dir="ltr" placeholder="https://..." onChange={(event) => setVideos((current) => current.map((item) => item.id === row.id ? { ...item, url: event.target.value } : item))} /></label><label><AdminText en="Platform" ar="المنصة" /><SharedSelect value={row.platform} onChange={(next) => setVideos((current) => current.map((item) => item.id === row.id ? { ...item, platform: next as TourVideoPlatform } : item))} locale={ar ? 'ar' : 'en'} options={[{ value: 'youtube', label: 'YouTube' }, { value: 'instagram', label: 'Instagram' }, { value: 'tiktok', label: 'TikTok' }, { value: 'facebook', label: 'Facebook' }, { value: 'vimeo', label: 'Vimeo' }, { value: 'direct', label: i18n("admin.tours.directVideo") }]} /></label></div>
              <label><AdminText en="Title" ar="العنوان" /><input value={localText(row, 'title')} onChange={(event) => setVideos((current) => current.map((item) => item.id === row.id ? editText(item, 'title', event.target.value) : item))} /></label>
              <label><AdminText en="Published date" ar="تاريخ النشر" /><DateInput value={row.publishedAt} onChange={(event) => setVideos((current) => current.map((item) => item.id === row.id ? { ...item, publishedAt: event.target.value } : item))} /></label>
              <ImageField disabled={saving || visBusy} onUploadingChange={uploadActivity} value={row.thumbnail} onChange={(thumbnail) => setVideos((current) => current.map((item) => item.id === row.id ? { ...item, thumbnail } : item))} preview="compact" linkLabel={{ en: 'Thumbnail URL (optional)', ar: 'رابط صورة الفيديو (اختياري)' }} uploadLabel={{ en: 'Upload thumbnail', ar: 'رفع صورة الفيديو' }} previewAlt={row.title || 'Video thumbnail'} />
            </article>)}</div>
            <div className="sp-builder-divider" />
            <div className="sp-builder-subhead"><div><strong><AdminText en="Tour gallery" ar="معرض صور الرحلة" /></strong><small><AdminText en="The first image is the cover. Credits are optional." ar="الصورة الأولى هي الغلاف. بيانات المصدر اختيارية." /></small></div></div>
            <div className="sp-form-2"><label><AdminText en="Pending photo credit" ar="مصدر الصورة الجديدة" /><input value={mediaCreditLabel} onChange={(event) => setMediaCreditLabel(event.target.value)} placeholder={ar ? 'اسم المصور أو المصدر' : i18n("admin.tours.photographerOrSourceName")} /></label><label><AdminText en="Pending credit URL" ar="رابط مصدر الصورة الجديدة" /><input value={mediaCreditUrl} onChange={(event) => setMediaCreditUrl(event.target.value)} dir="ltr" placeholder="https://..." /></label></div>
            {gallery.length>0&&<div className="sp-media-credit-list">{gallery.map((image, index) => <div key={image.id}><strong>{index + 1}. {image.alt}</strong><div className="sp-form-2"><label><AdminText en="Credit label" ar="اسم المصدر" /><input value={image.creditLabel} onChange={(event) => setGallery((current) => current.map((item) => item.id === image.id ? { ...item, creditLabel: event.target.value } : item))} /></label><label><AdminText en="Credit URL" ar="رابط المصدر" /><input value={image.creditUrl} dir="ltr" placeholder="https://..." onChange={(event) => setGallery((current) => current.map((item) => item.id === image.id ? { ...item, creditUrl: event.target.value } : item))} /></label></div></div>)}</div>}
          </>}
          {step === 0 && <><label><AdminText en={editingSlug ? 'Route slug (read only)' : 'New route slug'} ar={editingSlug ? 'رابط الرحلة (للقراءة فقط)' : 'رابط الرحلة الجديدة'} />{editingSlug ? <input value={sourceTour.slug} readOnly dir="ltr" /> : <input value={newSlug} onChange={(event) => setNewSlug(event.target.value)} dir="ltr" placeholder="my-new-tour" />}</label><label><AdminText en="Title" ar="العنوان" /><input value={localText(form, 'title')} onChange={set('title')} placeholder={ar ? 'مثال: جولة ويوم في القاهرة' : i18n("admin.tours.eGCairoGizaDayTour")} /></label><div className="sp-form-2"><label><AdminText en="Category" ar="التصنيف" /><SharedSelect value={form.category} onChange={setField('category')} locale={ar ? 'ar' : 'en'} options={[{ value: 'one-day-tours', label: 'one-day-tours' }, { value: 'multi-days-tours', label: 'multi-days-tours' }, { value: 'nile-cruises', label: 'nile-cruises' }, { value: 'shore-excursions', label: 'shore-excursions' }]} /></label><label><AdminText en="Primary location" ar="الموقع الأساسي" /><input value={localText(form, 'location')} onChange={set('location')} placeholder={ar ? 'مثال: القاهرة' : i18n("admin.tours.eGCairo")} /></label></div>{form.category === 'one-day-tours' && <label><AdminText en="Destination" ar="الوجهة" /><SharedSelect value={form.destinationSlug} disabled={destinationStatus.data === null} onChange={setField('destinationSlug')} locale={ar ? 'ar' : 'en'} popupWidth="trigger" options={[{ value: '', label: ar ? 'اختر الوجهة' : 'Select destination' }, ...destinationOptions]} />{destinationStatus.loading && <small role="status">{i18n("admin.tours.loadingDestinations")}</small>}{destinationStatus.error && <small role="alert">{destinationStatus.error} <button type="button" className="link-btn" onClick={destinationStatus.retry}>{i18n("admin.shared.retry")}</button></small>}</label>}{form.category === 'multi-days-tours' && <div><strong style={{ display: 'block', marginBottom: 8 }}><AdminText en="Multi Day Categories" ar="فئات الرحلات متعددة الأيام" /></strong><div className="sp-check-grid">{dbCategories.map((c) => <label key={c.slug} className="sp-check-row"><input type="checkbox" checked={catSlugs.includes(c.slug)} onChange={() => toggleCatSlug(c.slug)} /><span>{c.name}<small dir="ltr">{c.slug}</small></span></label>)}</div></div>}{form.category === 'nile-cruises'&&<label><AdminText en="Cruise type" ar="نوع الرحلة النيلية" /><SharedSelect value={form.cruiseType} onChange={setField('cruiseType')} locale={ar ? 'ar' : 'en'} popupWidth="trigger" options={[{ value: '', label: ar ? 'اختر نوع الرحلة' : 'Select cruise type' }, { value: 'standard-nile-cruises', label: 'standard-nile-cruises' }, { value: 'deluxe-nile-cruise', label: 'deluxe-nile-cruise' }, { value: 'superior-nile-cruise', label: 'superior-nile-cruise' }, { value: 'luxury-nile-cruise', label: 'luxury-nile-cruise' }]} /></label>}{form.category === 'shore-excursions'&&<label><AdminText en="Departure port" ar="ميناء الانطلاق" /><input value={localText(form, 'departurePort')} onChange={set('departurePort')} placeholder={ar ? 'ميناء الإسكندرية' : i18n("admin.tours.alexandria")} /></label>}<div className="sp-form-2"><label><AdminText en="Duration" ar="المدة" /><input value={localText(form, 'duration')} onChange={set('duration')} placeholder={ar ? 'مثال: 4 ساعات' : i18n("admin.tours.eG4Hours")} /></label><label><AdminText en="Group size" ar="حجم المجموعة" /><input value={localText(form, 'groupSize')} onChange={set('groupSize')} placeholder={ar ? 'مثال: particular' : i18n("admin.tours.eGPrivate")} /></label></div><label><AdminText en="Travel style" ar="نمط الرحلة" /><input value={localText(form, 'travelStyle')} onChange={set('travelStyle')} placeholder={ar ? 'مثال: particular' : i18n("admin.tours.eGPrivate")} /></label><label><AdminText en="Short summary" ar="الملخص القصير" /><textarea value={localText(form, 'summary')} onChange={set('summary')} rows={3} placeholder={ar ? 'وصف قصير يظهر في بطاقة الرحلة' : i18n("admin.tours.shortSummaryShownOnTheTourCard")} /></label></>}

          {step === 1 && <><div className="sp-form-2"><label><AdminText en="Base price (USD)" ar="السعر الأساسي (USD)" /><input type="number" min="0" value={form.price} onChange={set('price')} placeholder={ar ? 'مثال: 120' : 'e.g. 120'} /></label><label><AdminText en="Deal discount %" ar="نسبة الخصم %" /><input type="number" min="0" max="99" value={form.deal} onChange={set('deal')} /></label></div><label><AdminText en="Deal ends at" ar="ينتهي الخصم في" /><DateInput value={form.dealEndsAt} onChange={set('dealEndsAt')} /></label><p className="sp-builder-note"><AdminText en="The base price is the fallback when no traveler-count tier matches." ar="السعر الأساسي هو السعر الاحتياطي عندما لا توجد شريحة مطابقة لعدد المسافرين." /></p></>}

          {step === 2 && <><div className="sp-repeat-list">{addOns.map((row, index) => <article className="sp-repeat-card" key={row.id}>{repeatHeader(<AdminText en="Optional add-on" ar="إضافة اختيارية" />, index, () => setAddOns((current) => current.filter((item) => item.id !== row.id)))}<div className="sp-form-2"><label><AdminText en="Title" ar="العنوان" /><input value={localText(row, 'title')} onChange={(event) => setAddOns((current) => current.map((item) => item.id === row.id ? editText(item, 'title', event.target.value) : item))} /></label><label><AdminText en="Price (blank = on request)" ar="السعر (فارغ = حسب الطلب)" /><input type="number" min="0" value={row.price} onChange={(event) => setAddOns((current) => current.map((item) => item.id === row.id ? { ...item, price: event.target.value } : item))} /></label></div></article>)}</div><button type="button" className="sp-btn" onClick={() => setAddOns((current) => [...current, { id: id('addon'), title: '', price: '' }])}><Plus size={16} /><AdminText en="Add add-on" ar="إضافة اختيار" /></button></>}

          {step === 3 && <div className="sp-field"><span className="sp-label"><AdminText en="Overview" ar="النظرة العامة" /></span><RichTextEditor value={localText(form, 'overview')} onChange={(html) => setForm((curr) => writeTourText(curr, 'overview', html, contentLocale))} placeholder={ar ? 'اكتب تفاصيل النظرة العامة على الرحلة...' : i18n("admin.tours.writeComprehensiveTourOverviewWithHeadingsLists_e372814")} minHeight={240} dir={(contentLocale as string) === 'ar' ? 'rtl' : 'ltr'} /></div>}

          {activeStep === 4 && <><p className="sp-builder-note"><AdminText en="Choose the main Highlights image, then create one or more groups with one highlight per line." ar="اختر الصورة الرئيسية لقسم أبرز المعالم، ثم أنشئ مجموعة أو أكثر واكتب بندا واحدا في كل سطر." /></p><article className="sp-repeat-card sp-highlight-image-editor"><header><span><ImagePlus size={16}/></span><strong><AdminText en="Highlights image" ar="صورة أبرز المعالم" /></strong></header><ImageField disabled={saving || visBusy} onUploadingChange={uploadActivity} value={highlightImage} onChange={setHighlightImage} preview="wide" linkLabel={{ en: 'Highlights image URL', ar: 'رابط صورة أبرز المعالم' }} uploadLabel={{ en: 'Upload Highlights image', ar: 'رفع صورة أبرز المعالم' }} previewAlt={ar ? 'معاينة صورة أبرز المعالم' : 'Highlights image preview'} /></article><div className="sp-repeat-list">{highlights.map((row, index) => <article className="sp-repeat-card" key={row.id}>{repeatHeader(<AdminText en="Highlight group" ar="مجموعة أبرز المعالم" />, index, () => setHighlights((current) => current.filter((item) => item.id !== row.id)))}<label><AdminText en="Group title" ar="عنوان المجموعة" /><input value={localText(row, 'title')} placeholder={ar ? 'أبرز معالم القاهرة' : i18n("admin.tours.cairoHighlights")} onChange={(event) => setHighlights((current) => current.map((item) => item.id === row.id ? editText(item, 'title', event.target.value) : item))} /></label><label><AdminText en="Highlights (one per line)" ar="المعالم البارزة (بند في كل سطر)" /><textarea value={localText(row, 'items')} rows={5} placeholder={ar ? 'أهرامات الجيزة\nأبو الهول' : i18n("admin.tours.gizaPyramidsGreatSphinx")} onChange={(event) => setHighlights((current) => current.map((item) => item.id === row.id ? editText(item, 'items', event.target.value) : item))} /></label></article>)}</div><button type="button" className="sp-btn" onClick={() => setHighlights((current) => [...current, { id: id('highlight'), title: '', items: '' }])}><Plus size={16}/><AdminText en="Add highlight group" ar="إضافة مجموعة" /></button></>}

          {step === 4 && <><div className="sp-repeat-list">{itinerary.map((row, index) => <article className="sp-repeat-card" key={row.id}>{repeatHeader(<AdminText en={form.category === 'one-day-tours' ? 'Itinerary stop' : 'Itinerary day'} ar={form.category === 'one-day-tours' ? 'محطة البرنامج' : 'يوم البرنامج'} />, index, () => setItinerary((current) => current.filter((item) => item.id !== row.id)))}<div className="sp-form-2"><label><AdminText en="Day label" ar="العنوان التعريفي لليوم" /><input value={localText(row, 'day')} placeholder={form.category === 'one-day-tours' ? i18n("admin.tours.stop1") : i18n("admin.shared.day1")} onChange={(event) => setItinerary((current) => current.map((item) => item.id === row.id ? editText(item, 'day', event.target.value) : item))} /></label><label><AdminText en="Day title" ar="عنوان اليوم" /><input value={localText(row, 'title')} onChange={(event) => setItinerary((current) => current.map((item) => item.id === row.id ? editText(item, 'title', event.target.value) : item))} /></label></div><div className="sp-field"><span className="sp-label"><AdminText en="Description" ar="الوصف" /></span><RichTextEditor value={localText(row, 'description')} minHeight={130} dir={(contentLocale as string) === 'ar' ? 'rtl' : 'ltr'} placeholder={ar ? 'تفاصيل محطة / يوم البرنامج...' : i18n("admin.tours.itineraryDayDescriptionHighlightsActivities")} onChange={(html) => setItinerary((current) => current.map((item) => item.id === row.id ? editText(item, 'description', html) : item))} /></div><label><AdminText en="Meals" ar="وجبات اليوم" /><input value={localText(row, 'meals')} placeholder={ar ? 'إفطار، غداء، عشاء' : i18n("admin.tours.breakfastLunchDinner")} onChange={(event) => setItinerary((current) => current.map((item) => item.id === row.id ? editText(item, 'meals', event.target.value) : item))} /></label><ImageField disabled={saving || visBusy} onUploadingChange={uploadActivity} value={row.image} onChange={(image) => setItinerary((current) => current.map((item) => item.id === row.id ? { ...item, image } : item))} preview="compact" linkLabel={{ en: 'Itinerary image URL', ar: 'رابط صورة البرنامج' }} uploadLabel={{ en: 'Upload itinerary image', ar: 'رفع صورة البرنامج' }} previewAlt={row.title || row.day} /></article>)}</div><button type="button" className="sp-btn" onClick={() => setItinerary((current) => [...current, { id: id('day'), day: form.category === 'one-day-tours' ? `Stop ${current.length + 1}` : `Day ${current.length + 1}`, title: '', description: '', meals: '', image: '' }])}><Plus size={16}/><AdminText en="Add itinerary item" ar="إضافة عنصر للبرنامج" /></button></>}

          {step === 5 && <><label><AdminText en="What's included? (one per line)" ar="ما المشمول؟ (بند في كل سطر)" /><textarea value={localText(form, 'included')} onChange={set('included')} rows={6} /></label><label><AdminText en="What's excluded? (one per line)" ar="ما غير المشمول؟ (بند في كل سطر)" /><textarea value={localText(form, 'excluded')} onChange={set('excluded')} rows={6} /></label></>}

          {step === 1 && <><div className="sp-builder-divider" /><div className="sp-builder-subhead"><div><strong><AdminText en="Booking rates by passenger type" ar="أسعار الحجز حسب نوع المسافر" /></strong><small><AdminText en="These rates drive the live booking total. They do not appear in the public date-price calendar." ar="هذه الأسعار تحسب إجمالي الحجز مباشرة، ولا تظهر داخل تقويم أسعار المواعيد العام." /></small></div></div><div className="sp-passenger-pricing-grid">{pricingGroups.map((group) => <section className={`sp-passenger-pricing ${group.type}`} key={group.type}><header><div><strong>{ar ? group.ar : group.en}</strong><small><AdminText en="Per-person rate by total group size" ar="سعر الفرد حسب إجمالي حجم المجموعة" /></small></div><button type="button" className="sp-btn" onClick={() => addPassengerRate(group.type, group.defaultPrice)}><Plus size={15}/><AdminText en="Add rate" ar="إضافة سعر" /></button></header><div className="sp-passenger-rate-head"><span><AdminText en="Total travelers" ar="إجمالي المسافرين" /></span><span><AdminText en="Price (USD)" ar="السعر (USD)" /></span><span /></div>{travelerPrices[group.type].map((row) => <div className="sp-passenger-rate-row" key={row.id}><input type="number" min="1" step="1" aria-label={ar ? `عدد المسافرين لفئة ${group.ar}` : `${group.en} traveler count`} value={row.travelers} onChange={(event) => updatePassengerRate(group.type, row.id, 'travelers', event.target.value)} /><input type="number" min="0" step="0.01" aria-label={ar ? `سعر فئة ${group.ar}` : `${group.en} price`} value={row.price} onChange={(event) => updatePassengerRate(group.type, row.id, 'price', event.target.value)} /><button type="button" className="sp-icon-btn danger" onClick={() => removePassengerRate(group.type, row.id)} aria-label={ar ? 'حذف السعر' : i18n("admin.tours.removeRate")} title={ar ? 'حذف السعر' : i18n("admin.tours.removeRate")}><Trash2 size={18}/></button></div>)}</section>)}</div></>}

          {step === 7 && <>
            <ImageField disabled={saving || visBusy} onUploadingChange={uploadActivity} value={mediaLink} onChange={setMediaLink} preview="compact" linkLabel={{ en: 'Gallery image URL', ar: 'رابط صورة المعرض' }} uploadLabel={{ en: 'Upload one image', ar: 'رفع صورة واحدة' }} previewAlt={mediaAlt || form.title} />
            <label><AdminText en="Image description" ar="وصف الصورة" /><input value={mediaAlt} onChange={(event) => setMediaAlt(event.target.value)} /></label>
            <button type="button" className="sp-btn" onClick={addMediaLink}><ImagePlus size={16}/><AdminText en="Add image to gallery" ar="إضافة الصورة إلى المعرض" /></button>
            <label className="sp-file-label"><AdminText en="Or upload several gallery images" ar="أو ارفع عدة صور للمعرض" /><span className="sp-file-trigger"><Upload size={16}/><AdminText en="Choose images" ar="اختيار الصور" /></span><input type="file" accept="image/png,image/jpeg,image/webp,image/gif" multiple onChange={(event) => uploadGallery(event.target.files)} /></label>
            <div className="sp-gallery">{gallery.map((image, index) => <figure className="sp-g-item" key={image.id}><img src={image.src} alt={image.alt}/>{index===0&&<em className="sp-g-cover"><AdminText en="Cover" ar="الغلاف" /></em>}<figcaption><span>{image.alt}</span><span className="sp-g-ops"><button type="button" disabled={index===0} onClick={() => setGallery((current) => { const next=[...current]; [next[index-1],next[index]]=[next[index],next[index-1]]; return next })} aria-label={ar?'تحريك للخلف':i18n("admin.tours.moveBackward")}><ArrowLeft size={14}/></button><button type="button" disabled={index===gallery.length-1} onClick={() => setGallery((current) => { const next=[...current]; [next[index+1],next[index]]=[next[index],next[index+1]]; return next })} aria-label={ar?'تحريك للأمام':i18n("admin.tours.moveForward")}><ArrowRight size={14}/></button><button type="button" onClick={() => setGallery((current) => current.filter((item) => item.id !== image.id))} aria-label={ar?'حذف الصورة':i18n("admin.shared.removeImage")}><Trash2 size={14}/></button></span></figcaption></figure>)}</div>
          </>}

          {step === 8 && <><p className="sp-builder-note"><MapPin size={16}/><AdminText en="Add every stop. Coordinates produce the interactive map; a name alone uses the standard map search." ar="أضف كل محطة. الإحداثيات تُظهر الخريطة التفاعلية، والاسم وحده يستخدم بحث الخريطة الطبيعي." /></p><div className="sp-repeat-list">{locations.map((row, index) => <article className="sp-repeat-card" key={row.id}>{repeatHeader(<AdminText en="Map location" ar="موقع على الخريطة" />, index, () => setLocations((current) => current.filter((item) => item.id !== row.id)))}<label><AdminText en="Location name" ar="اسم الموقع" /><input value={localText(row, 'name')} onChange={(event) => setLocations((current) => current.map((item) => item.id===row.id?editText(item, 'name', event.target.value):item))} /></label><div className="sp-form-2"><label><AdminText en="Latitude" ar="خط العرض" /><input inputMode="decimal" dir="ltr" value={row.latitude} placeholder="25.6872" onChange={(event) => setLocations((current) => current.map((item) => item.id===row.id?{...item,latitude:event.target.value}:item))} /></label><label><AdminText en="Longitude" ar="خط الطول" /><input inputMode="decimal" dir="ltr" value={row.longitude} placeholder="32.6396" onChange={(event) => setLocations((current) => current.map((item) => item.id===row.id?{...item,longitude:event.target.value}:item))} /></label></div></article>)}</div><button type="button" className="sp-btn" onClick={() => setLocations((current) => [...current, { id:id('location'), name:'', nameAr:'', latitude:'', longitude:'' }])}><Plus size={16}/><AdminText en="Add location" ar="إضافة موقع" /></button></>}

          {step === 9 && <div className="sp-review-grid"><div><small><AdminText en="Tour" ar="الرحلة" /></small><strong>{form.title}</strong><span>{form.category} · {form.duration}</span></div><div><small><AdminText en="Content" ar="المحتوى" /></small><strong>{itinerary.length} <AdminText en="itinerary items" ar="عناصر برنامج" /></strong><span>{highlights.length} <AdminText en="highlight groups" ar="مجموعات أبرز المعالم" /> · {addOns.length} <AdminText en="add-ons" ar="إضافات" /> · {locations.length} <AdminText en="locations" ar="مواقع" /></span></div><div><small><AdminText en="Pricing" ar="التسعير" /></small><strong>{cleanTravelerPrices.length} <AdminText en="combined traveler tiers" ar="شرائح مسافرين مجمعة" /></strong><span><AdminText en={`${travelerPrices.adult.length} adult · ${travelerPrices.child.length} child · ${travelerPrices.infant.length} infant rates`} ar={`${travelerPrices.adult.length} بالغ · ${travelerPrices.child.length} طفل · ${travelerPrices.infant.length} رضيع`} /></span></div><div><small><AdminText en="Media" ar="الوسائط" /></small><strong>{gallery.length} <AdminText en="images" ar="صور" /></strong><span><AdminText en="First image is the cover" ar="الصورة الأولى هي الغلاف" /></span></div>{editingSlug && <div><small><AdminText en="Visibility" ar="الظهور" /></small><strong><StatusPill status={tourVisible ? 'published' : 'hidden'} /></strong><span><button type="button" className="sp-btn" onClick={() => void setVisibility(!tourVisible)} disabled={visBusy || saving}>{tourVisible ? <EyeOff size={16} /> : <Eye size={16} />}<AdminText en={tourVisible ? 'Unpublish' : 'Publish'} ar={tourVisible ? 'إخفاء' : 'نشر'} /></button><AdminText en={tourVisible ? 'Visible on the public website.' : 'Hidden from the public website.'} ar={tourVisible ? 'ظاهرة في الموقع العام.' : 'مخفية عن الموقع العام.'} /></span></div>}<p className="sp-builder-note full"><AdminText en="Save & Publish writes this tour to the database. The public tour page reads the same saved record." ar="الحفظ والنشر يكتبان هذه الرحلة في قاعدة البيانات. صفحة الرحلة العامة تقرأ نفس السجل المحفوظ." /></p></div>}

          {error&&<p className="sp-builder-feedback error" role="alert">{<RegistryAdminText text={error} />}</p>}
          <div className="sp-builder-actions">{activeStep>0&&<button type="button" className="sp-btn" onClick={() => setActiveStep((current) => current-1)} disabled={saving || visBusy || mediaUploads > 0}><AdminText en="Back" ar="رجوع" /></button>}{!isLastStep?<button type="button" className="sp-btn primary" onClick={next} disabled={saving || visBusy || mediaUploads > 0}><AdminText en="Continue" ar="متابعة" /></button>:showSave?<>{(!editingSlug || !tourVisible) && <button type="button" className="sp-btn" onClick={() => void publish('draft')} disabled={saving || visBusy || mediaUploads > 0}><Save size={16}/><AdminText en="Save Draft" ar="حفظ المسودة" /></button>}<button type="button" className="sp-btn primary" onClick={() => void publish('published')} disabled={saving || visBusy || mediaUploads > 0}><Save size={16}/><AdminText en="Save & Publish" ar="حفظ ونشر" /></button></>:null}</div>
          </Tabs.Panel>
        </Tabs.Root>
      </Card>

      <TripBuilderPreview appearance={previewAppearance} showDatePricing={activeStep === 7} source={sourceTour} draft={{ routeSlug: editingSlug ?? newSlug, form, catSlugs, addOns, highlightImage, highlights, itinerary, travelerPrices, priceRows, locations, gallery, videos }} clearedTranslations={clearedPreviewTranslations.current} counts={{ adult: previewAdults, child: previewChildren, infant: previewInfants }} onCount={(type, count) => { if (type === 'adult') setPreviewAdults(count); else if (type === 'child') setPreviewChildren(count); else setPreviewInfants(count) }}/>
    </div>
  </>
}
