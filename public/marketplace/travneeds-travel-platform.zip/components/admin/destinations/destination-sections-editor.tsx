'use client'
import { useAdminTranslations } from '@/components/admin/providers/admin-translations'


import Link from 'next/link'
import { ArrowDown, ArrowUp, Plus, Trash2 } from 'lucide-react'
import type { Destination } from '@/data/types'
import { changeDestinationRow, type DestinationRepeater } from '@/lib/destinations/destination-builder'
import type { CatalogueTranslations } from '@/lib/catalogue/catalogue-translations'
import { Card } from '@/components/admin/admin-ui'
import { ContentLanguageTabs, TranslatedInput, TranslatedTextarea, useContentLanguage } from '@/components/admin/ui/content-language-tabs'
import { ImageField } from '@/components/admin/ui/image-field'

type Props = {
  item: Destination
  onChange: (item: Destination) => void
  setTranslations: React.Dispatch<React.SetStateAction<CatalogueTranslations>>
  onUpload: (key: string, active: boolean) => void
  disabled?: boolean
}
const sections = {
  facts: { title: '2. Facts at a glance', fields: { label: 'Label', value: 'Value' } },
  bestFor: { title: 'Best suited for', fields: {} },
  experiences: { title: '4. Signature experiences', fields: { title: 'Title', copy: 'Description', alt: 'Image description' } },
  rhythm: { title: '5. Journey rhythm', fields: { label: 'Time / stage', title: 'Title', copy: 'Description' } },
  practical: { title: '6. Practical information', fields: { title: 'Title', copy: 'Description' } },
}

function Rows({ section, item, onChange, onUpload, disabled }: Props & { section: DestinationRepeater }) {
  const i18n = useAdminTranslations("admin.catalogue")

  const language = useContentLanguage()
  const english = !language || language.locale === 'en'
  const rows = item.detail[section]
  const change = (index: number, key: string, text: string) => onChange({ ...item, detail: { ...item.detail,
    [section]: rows.map((row, position) => position !== index ? row : section === 'bestFor' ? text : { ...row as object, [key]: text }),
  } })
  return <div className="sp-repeat-list">
    {!english && <p className="sp-builder-note">{i18n("admin.catalogue.translateTheExistingItemsHereAddRemove_091dbc3")}</p>}
    {!rows.length && <p className="sp-builder-note">{i18n("admin.catalogue.noItemsThePreviewWillKeepThis_eaa0eb4")}</p>}
    {rows.map((row, index) => <article className="sp-repeat-card" key={`${section}-${index}`}>
      <header><strong>{i18n("admin.shared.item")}{" "}{index + 1}</strong><div className="sp-destination-row-actions">
        <button type="button" className="sp-icon-btn" disabled={!english || disabled || index === 0} aria-label={i18n("admin.actions.moveSectionItemUp", { section: section, position: index + 1 })} onClick={() => onChange(changeDestinationRow(item, section, 'move', index, index - 1))}><ArrowUp size={16}/></button>
        <button type="button" className="sp-icon-btn" disabled={!english || disabled || index === rows.length - 1} aria-label={i18n("admin.actions.moveSectionItemDown", { section: section, position: index + 1 })} onClick={() => onChange(changeDestinationRow(item, section, 'move', index, index + 1))}><ArrowDown size={16}/></button>
        <button type="button" className="sp-icon-btn danger" disabled={!english || disabled} aria-label={i18n("admin.actions.removeSectionItem", { section: section, position: index + 1 })} onClick={() => onChange(changeDestinationRow(item, section, 'remove', index))}><Trash2 size={16}/></button>
      </div></header>
      {section === 'bestFor' ? <label>{i18n("admin.catalogue.audienceInterest")}<TranslatedInput field={`detail.bestFor.${index}`} value={String(row)} onChange={event => change(index, '', event.target.value)} /></label> : Object.entries(sections[section].fields).map(([field, label]) => <label key={field}>{label}<TranslatedTextarea field={`detail.${section}.${index}.${field}`} value={String((row as unknown as Record<string, string>)[field] ?? '')} onChange={event => change(index, field, event.target.value)} rows={field === 'copy' ? 3 : 1}/></label>)}
      {section === 'experiences' && <ImageField value={(row as Destination['detail']['experiences'][number]).image} onChange={value => change(index, 'image', value)} preview="wide" previewAlt={(row as Destination['detail']['experiences'][number]).alt} disabled={disabled || !english} onUploadingChange={active => onUpload(`experiences.${index}`, active)} />}
    </article>)}
    <button type="button" className="sp-btn" disabled={!english || disabled || rows.length >= 100} onClick={() => onChange(changeDestinationRow(item, section, 'add'))}><Plus size={16}/>{i18n("admin.shared.addItem")}</button>
  </div>
}

export function DestinationSectionsEditor(props: Props & { section?: 'hero' | 'facts' | 'story' | 'experiences' | 'rhythm' | 'practical' }) {
  const i18n = useAdminTranslations("admin.catalogue")

  const { item, onChange, setTranslations, onUpload, disabled } = props
  const detail = (key: 'heroImage' | 'heroAlt' | 'eyebrow' | 'intro', value: string) => onChange({ ...item, detail: { ...item.detail, [key]: value } })
  const languages = (children: React.ReactNode) => <ContentLanguageTabs translations={item.translations ?? {}} setTranslations={setTranslations}>{children}</ContentLanguageTabs>
  return <>
    {(!props.section || props.section === 'hero') && <Card title={i18n("admin.catalogue.message1Hero")} sub={i18n("admin.catalogue.destinationNameIntroductoryCopyAndBackgroundShown_b6ba838")}>
      {languages(<div className="sp-form">
        <label>{i18n("admin.catalogue.destinationName")}<TranslatedInput field="title" value={item.title} onChange={event => onChange({ ...item, title: event.target.value })}/></label>
        <label>{i18n("admin.catalogue.heroDescriptionCardSummary")}<TranslatedTextarea field="copy" value={item.copy} onChange={event => onChange({ ...item, copy: event.target.value })} rows={3}/></label>
        <label>{i18n("admin.catalogue.eyebrow")}<TranslatedInput field="detail.eyebrow" value={item.detail.eyebrow} onChange={event => detail('eyebrow', event.target.value)}/></label>
        <label>{i18n("admin.catalogue.heroImageDescription")}<TranslatedInput field="detail.heroAlt" value={item.detail.heroAlt} onChange={event => detail('heroAlt', event.target.value)}/></label>
      </div>)}
      <ImageField value={item.detail.heroImage} onChange={value => detail('heroImage', value)} preview="wide" previewAlt={item.detail.heroAlt} disabled={disabled} onUploadingChange={active => onUpload('hero', active)}/>
      <p className="sp-builder-note">{i18n("admin.catalogue.theSameHeroImageIsReusedBeside_e0847f2")}</p>
    </Card>}
    {(!props.section || props.section === 'facts') && <Card title={sections.facts.title} sub={i18n("admin.catalogue.displayOrderFollowsTheItemOrderBelow_9393108")}>{languages(<Rows {...props} section="facts"/>)}</Card>}
    {(!props.section || props.section === 'story') && <Card title={i18n("admin.catalogue.message3DestinationStory")} sub={i18n("admin.catalogue.theIntroductionAndAudienceTagsShownBelow_099275c")}>
      {languages(<><label>{i18n("admin.catalogue.introduction")}<TranslatedTextarea field="detail.intro" value={item.detail.intro} onChange={event => detail('intro', event.target.value)} rows={5}/></label><h4>{i18n("admin.catalogue.bestSuitedFor")}</h4><Rows {...props} section="bestFor"/></>)}
    </Card>}
    {(['experiences', 'rhythm', 'practical'] as const).filter(section => !props.section || props.section === section).map(section => <Card key={section} title={sections[section].title} sub={i18n("admin.catalogue.addTranslateAndArrangeTheItemsExactly_3d06d44")}>{languages(<Rows {...props} section={section}/>)}</Card>)}

  </>
}

export function DestinationCoverEditor({ item, onChange, onUpload, disabled }: Pick<Props, 'item' | 'onChange' | 'onUpload' | 'disabled'>) {
  const i18n = useAdminTranslations("admin.catalogue")

  return (
    <Card title={i18n("admin.catalogue.message8PlanningCtaDestinationCard")} sub={i18n("admin.catalogue.theCoverImageIsReusedAsThe_1fe6358")}>
      <ImageField value={item.image} onChange={image => onChange({ ...item, image })} preview="wide" previewAlt={item.title} disabled={disabled} onUploadingChange={active => onUpload('cover', active)}/>
      <p className="sp-builder-note">{i18n("admin.catalogue.theDestinationNameIsInsertedIntoThe_2f089d2")}{" "}<Link href="/admin/website-cms/pages/destination-detail">{i18n("admin.catalogue.websiteCmsDestinationTemplate")}</Link>.</p>
    </Card>
  )
}
