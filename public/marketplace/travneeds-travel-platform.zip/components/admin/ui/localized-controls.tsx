'use client'

import Link from 'next/link'
import type { ComponentProps } from 'react'
import { useAdminTranslations } from '../providers/admin-translations'

/** Native attributes must receive strings; keep the shared Admin UI module server-safe. */
export function AdminSearchInput(props: ComponentProps<'input'>) {
  const t = useAdminTranslations('admin.shared')
  return <input {...props} placeholder={props.placeholder ? t.text(props.placeholder) : props.placeholder} aria-label={props['aria-label'] ? t.text(props['aria-label']) : props['aria-label']} />
}

export function AdminActionButton(props: ComponentProps<'button'>) {
  const t = useAdminTranslations('admin.shared')
  return <button {...props} title={props.title ? t.text(props.title) : props.title} aria-label={props['aria-label'] ? t.text(props['aria-label']) : props['aria-label']} />
}

export function AdminActionLink(props: ComponentProps<typeof Link>) {
  const t = useAdminTranslations('admin.shared')
  return <Link {...props} title={props.title ? t.text(props.title) : props.title} aria-label={props['aria-label'] ? t.text(props['aria-label']) : props['aria-label']} />
}
