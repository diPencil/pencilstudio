'use client'

import type { ReactNode } from 'react'
import { useAdminLocale } from '@/components/admin/providers/admin-locale'
import { adminText, formatAdminTranslation, type AdminTranslationValues } from '@/lib/localization/admin-translations'

// React context follows dialogs/menus through portals; ancestor CSS does not.
export function AdminText(props: { en: ReactNode; ar: ReactNode } | { translationKey: string; values?: AdminTranslationValues } | { text: ReactNode }) {
  const locale = useAdminLocale()
  if ('translationKey' in props) return <>{formatAdminTranslation(locale, props.translationKey, props.values)}</>
  if ('text' in props) return <>{typeof props.text === 'string' ? adminText(locale, props.text) : props.text}</>
  const value = locale === 'ar' ? props.ar : props.en
  return <>{typeof value === 'string' ? adminText(locale, value) : value}</>
}
