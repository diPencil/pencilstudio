'use client'
import { useAdminTranslations } from '@/components/admin/providers/admin-translations'

import { BrandMark } from '@/components/layout/brand-mark'
import { currencyChoices, type Currency } from '@/lib/localization/currency'
import { useLocale } from '@/components/locale'
import { useAdminLocale } from '@/components/admin/providers/admin-locale'
import { adminText } from '@/lib/localization/admin-translations'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useEffect, useRef, useState } from 'react'
import {
  Bell,
  Boxes,
  Building2,
  CalendarCheck,
  CarFront,
  ChevronDown,
  ClipboardList,
  Compass,
  CreditCard,
  ExternalLink,
  LayoutDashboard,
  Images,
  LogOut,
  Mail,
  Map,
  MapPinned,
  Menu,
  MessageCircle,
  Newspaper,
  PanelLeftClose,
  Route,
  Search,
  Settings,
  ShoppingCart,
  Sparkles,
  Tags,
  Ticket,
  User,
  Users,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useCurrentUser } from '@/lib/auth/use-current-user'
import { useAdminNotifications, type AdminNotification } from '@/lib/notifications/admin-notifications'
import { NotificationPanel as SharedNotificationPanel } from '@/components/layout/notification-panel'
import { Avatar } from './admin-ui'
import { AdminBackButton } from '@/components/admin/ui/admin-back'
import { LanguageToggle, getLanguageDialogText, getLanguageRegions } from '@/components/layout/language-selector'
import { LOCALE_SHORT_LABELS, type Locale } from '@/lib/localization/locale-config'
import { readAdminProfile } from '@/lib/admin/admin-store'
import { useMobileDrawer } from '@/lib/shared/use-mobile-drawer'
import { Toaster } from '@/components/admin/ui/admin-toaster'

function timeAgo(iso: string, ar: boolean): string {
  const then = new Date(iso).getTime()
  if (!Number.isFinite(then)) return ''
  const seconds = Math.max(0, Math.floor((Date.now() - then) / 1000))
  if (seconds < 60) return ar ? 'الآن' : 'Just now'
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return ar ? `منذ ${minutes} د` : `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return ar ? `منذ ${hours} س` : `${hours}h ago`
  const days = Math.floor(hours / 24)
  if (days < 30) return ar ? `منذ ${days} يوم` : `${days}d ago`
  return new Date(iso).toLocaleDateString(ar ? 'ar-EG' : 'en-US', { day: 'numeric', month: 'short' })
}

function iconForAdminNotification(type: string) {
  switch (type) {
    case 'admin_booking_created':
      return ShoppingCart
    case 'admin_trip_request_submitted':
      return Compass
    case 'admin_car_request_submitted':
      return CarFront
    case 'admin_event_request_submitted':
      return ClipboardList
    case 'admin_payment_initiated':
      return CreditCard
    default:
      return Bell
  }
}

/**
 * Minimum view permission (any-of) required to show each admin section.
 * Dashboard stays visible to every staff identity as the shell landing
 * page; every other section mirrors the `*.view` key its API enforces,
 * so a bookings-only user never sees Payments, Users or Settings links.
 * APIs remain the source of truth  -  this only keeps navigation honest.
 */
const NAV_VIEW_PERMISSIONS: Record<string, string[]> = {
  '/admin/bookings': ['bookings.view'],
  '/admin/payments': ['payments.view'],
  '/admin/trips': ['tours.view'],
  '/admin/hotels': ['hotels.view', 'hotels.manage'],
  '/admin/destinations': ['destinations.view'],
  '/admin/multi-day-categories': ['categories.view'],
  '/admin/events': ['events.view'],
  '/admin/event-requests': ['requests.view'],
  '/admin/offers': ['offers.view'],
  '/admin/blogs': ['blogs.view'],
  '/admin/gallery': ['gallery.view'],
  '/admin/cars': ['cars.view'],
  '/admin/rent-cars': ['cars.view'],
  '/admin/car-requests': ['requests.view'],
  '/admin/trip-requests': ['requests.view'],
  '/admin/customers': ['customers.view'],
  '/admin/inbox': ['support.view'],
  '/admin/notifications': ['support.view'],
  '/admin/emails': ['emails.view'],
  '/admin/reviews': ['reviews.view'],
  '/admin/users': ['users.view', 'roles.view'],
  '/admin/addons': ['settings.view'],
  '/admin/settings': ['settings.view'],
  '/admin/website-cms/hero-sections': ['settings.view'],
  '/admin/website-cms': ['settings.view'],
  '/admin/website-cms/pages': ['settings.view'],
  '/admin/website-cms/seo': ['settings.view'],
  '/admin/website-cms/navigation': ['settings.view'],
}

function canSeeNavItem(
  user: { roles?: string[]; permissions?: string[] },
  href: string,
): boolean {
  if (user.roles?.includes('SUPER_ADMIN')) return true
  const keys = NAV_VIEW_PERMISSIONS[href]
  if (!keys) return true
  const permissions = user.permissions ?? []
  return keys.some((key) => permissions.includes(key))
}

const groups = [
  {
    label: 'نظرة عامة',
    labelEn: 'DASHBOARD',
    items: [
      { href: '/admin/dashboard', icon: LayoutDashboard, en: 'Dashboard', ar: 'لوحة المؤشرات' },
    ],
  },
  {
    label: 'خدمات السفر والمنتجات',
    labelEn: 'TRAVEL SERVICES',
    items: [
      { href: '/admin/trips', icon: Map, en: 'Tours & Packages', ar: 'الرحلات والبرامج' },
      { href: '/admin/hotels', icon: Building2, en: 'Hotels & Lodging', ar: 'الفنادق والإقامة' },
      { href: '/admin/cars', icon: CarFront, en: 'Rent Cars Fleet', ar: 'أسطول السيارات' },
      { href: '/admin/destinations', icon: MapPinned, en: 'Destinations', ar: 'الوجهات' },
      { href: '/admin/multi-day-categories', icon: Tags, en: 'Multi Day Categories', ar: 'فئات الرحلات' },
      { href: '/admin/events', icon: CalendarCheck, en: 'Events', ar: 'الفعاليات' },
    ],
  },
  {
    label: 'العمليات والطلبات',
    labelEn: 'OPERATIONS',
    items: [
      { href: '/admin/bookings', icon: ShoppingCart, en: 'Bookings', ar: 'الحجوزات' },
      { href: '/admin/trip-requests', icon: Compass, en: 'Trip Requests', ar: 'طلبات الرحلات' },
      { href: '/admin/car-requests', icon: ClipboardList, en: 'Car Requests', ar: 'طلبات السيارات' },
      { href: '/admin/event-requests', icon: ClipboardList, en: 'Event Requests', ar: 'طلبات الفعاليات' },
      { href: '/admin/rent-cars', icon: Route, en: 'Routes & Prices', ar: 'الأسعار والخطوط' },
    ],
  },
  {
    label: 'إدارة الأعمال والعملاء',
    labelEn: 'BUSINESS MANAGEMENT',
    items: [
      { href: '/admin/customers', icon: Users, en: 'Customers (CRM)', ar: 'العملاء (CRM)' },
      { href: '/admin/payments', icon: CreditCard, en: 'Finance & Payments', ar: 'المالية والمدفوعات' },
      { href: '/admin/inbox', icon: MessageCircle, en: 'Support Inbox', ar: 'صندوق الدعم' },
      { href: '/admin/emails', icon: Mail, en: 'Emails Log', ar: 'سجل البريد' },
      { href: '/admin/reviews', icon: Sparkles, en: 'Customer Reviews', ar: 'تقييمات العملاء' },
      { href: '/admin/notifications', icon: Bell, en: 'Notifications', ar: 'الإشعارات' },
    ],
  },
  {
    label: 'الموقع وإدارة المحتوى',
    labelEn: 'WEBSITE & CMS',
    items: [
      { href: '/admin/website-cms', icon: LayoutDashboard, en: 'CMS Overview', ar: 'نظرة عامة' },
      { href: '/admin/website-cms/hero-sections', icon: Images, en: 'Hero Sections', ar: 'الأقسام الرئيسية' },
      { href: '/admin/website-cms/pages', icon: Newspaper, en: 'Pages & Sections', ar: 'الصفحات والأقسام' },
      { href: '/admin/website-cms/navigation', icon: Route, en: 'Navigation Manager', ar: 'إدارة القوائم' },
      { href: '/admin/website-cms/seo', icon: Search, en: 'SEO Manager', ar: 'إدارة الـ SEO' },
      { href: '/admin/offers', icon: Ticket, en: 'Special Offers', ar: 'العروض الخاصة' },
      { href: '/admin/blogs', icon: Newspaper, en: 'Travel Blogs', ar: 'المدونة' },
      { href: '/admin/gallery', icon: Images, en: 'Journey Gallery', ar: 'معرض الرحلات' },
    ],
  },
  {
    label: 'الإضافات والتراخيص',
    labelEn: 'ADD-ONS',
    items: [
      { href: '/admin/addons', icon: Boxes, en: 'Add-ons & Modules', ar: 'الإضافات والوحدات' },
    ],
  },
  {
    label: 'الإدارة والنظام',
    labelEn: 'SETTINGS',
    items: [
      { href: '/admin/users', icon: Users, en: 'Users & Roles', ar: 'المستخدمون والصلاحيات' },
      { href: '/admin/settings', icon: Settings, en: 'System Settings', ar: 'إعدادات النظام' },
    ],
  },
];

export function AdminShell({ children }: { children: React.ReactNode }) {
  const i18n = useAdminTranslations("admin.core")

  const pathname = usePathname()
  const router = useRouter()
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const sidebarRef = useRef<HTMLElement>(null)
  const menuTriggerRef = useRef<HTMLButtonElement>(null)
  const mobileDrawer = useMobileDrawer({ open: mobileOpen, onClose: () => setMobileOpen(false), panel: sidebarRef, trigger: menuTriggerRef, query: '(max-width: 860px)' })
  const locale = useAdminLocale()
  const { locale: siteLocale, setLocale: changeLocale, currency, setCurrency: changeCurrency } = useLocale()
  const [languageOpen, setLanguageOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const [userMenu, setUserMenu] = useState(false)
  const { user, loading: sessionLoading } = useCurrentUser()
  const adminNotifications = useAdminNotifications()
  const [adminAvatar, setAdminAvatar] = useState('')
  useEffect(() => {
    const profile = readAdminProfile()
    setAdminAvatar(profile.avatar)
    window.addEventListener('sp-profile', () => setAdminAvatar(readAdminProfile().avatar))
    return () => window.removeEventListener('sp-profile', () => setAdminAvatar(readAdminProfile().avatar))
  }, [])
  const unreadCount = adminNotifications.unreadCount
  useEffect(() => {
    document.documentElement.classList.add('sp-admin-root')
    try {
      if (window.localStorage.getItem('sp-admin-collapsed') === '1') setCollapsed(true)
    } catch { /* Locale/cookie switching still works when storage is unavailable. */ }
    return () => {
      document.documentElement.classList.remove('sp-admin-root')
    }
  }, [])

  useEffect(() => {
    try { window.localStorage.setItem('sp-admin-collapsed', collapsed ? '1' : '0') } catch { /* Keep in-memory layout state. */ }
  }, [collapsed])

  useEffect(() => {
    setNotificationsOpen(false)
    setUserMenu(false)
    setMobileOpen(false)
  }, [pathname])

  const logout = async () => {
    setUserMenu(false)
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'same-origin',
      })
    } catch {
      // Logout request failed; still redirect to login
    }
    router.push('/login')
  }

  const ar = locale === 'ar'
  // Identity display: real staff name inline with the username, never the
  // raw email prefix. Avatar prefers the server account photo and falls
  // back to the local admin profile mirror only until it is saved.
  const emailPrefix = user?.email?.split('@')[0] ?? 'Admin'
  const fullName = `${user?.firstName ?? ''} ${user?.lastName ?? ''}`.trim()
  const userName = user?.username?.trim() || ''
  const displayName = fullName || userName || emailPrefix
  const chipSub = userName ? `@${userName}` : ''
  const sideSub = userName ? `@${userName}` : (user?.email ?? '')
  const shellAvatar = user?.avatar || adminAvatar || undefined
  // Until the session (roles + permissions) resolves, no real navigation
  // item is rendered  -  only neutral placeholders. This guarantees an
  // unauthorized link is never visible, even for a frame.
  const navReady = !sessionLoading && user !== null
  const visibleGroups = navReady
    ? groups
      .map((group) => ({
        ...group,
        items: group.items.filter((item) => canSeeNavItem(user, item.href)),
      }))
      .filter((group) => group.items.length > 0)
    : []
  const searchResults = query.trim()
    ? visibleGroups.flatMap((group) => group.items).filter((item) => `${item.en} ${item.ar}`.toLowerCase().includes(query.trim().toLowerCase()))
    : []

  return (
    <div className={cn('sp-admin', collapsed && 'is-collapsed', ar && 'is-rtl')} dir={ar ? 'rtl' : 'ltr'} lang={locale}>
      <div
        className={cn('sp-scrim', mobileOpen && 'show')}
        onClick={() => setMobileOpen(false)}
      />
      <aside ref={sidebarRef} id="admin-mobile-menu" className={cn('sp-side', mobileOpen && 'open')} inert={mobileDrawer && !mobileOpen ? true : undefined} role={mobileDrawer && mobileOpen ? 'dialog' : undefined} aria-modal={mobileDrawer && mobileOpen ? true : undefined} aria-label={ar ? 'قائمة الإدارة' : i18n("admin.core.adminNavigation")}>
        <div className="sp-brand">
          <Link href="/admin/dashboard" className="sp-brand-link">
            <span className="sp-brand-mark"><BrandMark alt="" /></span>
            {!collapsed && (
              <span className="sp-brand-copy">
                <strong>TravNeeds</strong>
                <small>{ar ? 'لوحة الإدارة' : i18n("admin.core.internalDashboard")}</small>
              </span>
            )}
          </Link>
          <button type="button" className="sp-icon-btn only-mobile" onClick={() => setMobileOpen(false)} aria-label={ar ? 'إغلاق القائمة' : i18n("admin.core.closeMenu")}><X size={20}/></button>
        </div>

        <nav className="sp-nav" aria-busy={!navReady}>
          {!navReady && (
            <p role="status" style={{ margin: '6px 8px 4px', color: '#9db4e8', fontSize: 12 }}>
              {ar ? 'جارٍ تحميل القائمة…' : i18n("admin.core.loadingMenu")}
            </p>
          )}
          {(navReady ? visibleGroups : []).map((g) => (
            <div key={g.label} className="sp-nav-group">
              {!collapsed && <p>{ar ? g.label : g.labelEn}</p>}
              {g.items.map((item) => {
                const active = pathname === item.href || (item.href !== '/admin/website-cms' && pathname?.startsWith(item.href + '/'))
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    title={ar ? item.ar : item.en}
                    className={cn('sp-nav-link', active && 'active')}
                    onClick={() => setMobileOpen(false)}
                  >
                    <item.icon size={18} />
                    {!collapsed && <span>{ar ? item.ar : item.en}</span>}
                  </Link>
                )
              })}
            </div>
          ))}
          {!navReady && groups.map((g) => (
            <div key={g.label} className="sp-nav-group" aria-hidden="true">
              {!collapsed && <p>{ar ? g.label : g.labelEn}</p>}
              {g.items.map((item) => (
                <span key={item.href} className="sp-nav-link" style={{ pointerEvents: 'none' }}>
                  <span style={{ width: 18, height: 18, borderRadius: 6, background: 'rgba(255,255,255,.14)' }} />
                  {!collapsed && <span style={{ height: 12, borderRadius: 6, background: 'rgba(255,255,255,.14)', flex: 1 }} />}
                </span>
              ))}
            </div>
          ))}
        </nav>

        <div className="sp-side-user" title={user?.email ?? undefined}>
          <Avatar name={displayName} size={38} online src={shellAvatar} />
          {!collapsed && user && (
            <div>
              <strong>{displayName}</strong>
              <small>{sideSub}</small>
            </div>
          )}
        </div>
      </aside>

      <div className="sp-main" inert={mobileDrawer && mobileOpen ? true : undefined}>
        <header className="sp-top">
          <button
            ref={menuTriggerRef}
            type="button"
            className="sp-icon-btn only-mobile"
            onClick={() => { setCollapsed(false); setMobileOpen(true) }}
            aria-expanded={mobileOpen}
            aria-controls="admin-mobile-menu"
            aria-label={ar ? 'فتح القائمة' : i18n("admin.core.openMenu")}
          >
            <Menu size={20} />
          </button>
          <button
            type="button"
            className={cn('sp-icon-btn', 'sp-collapse-btn', collapsed && 'is-collapsed')}
            onClick={() => setCollapsed((v) => !v)}
            aria-label={ar ? 'طي القائمة الجانبية' : i18n("admin.core.collapseSidebar")}
            aria-expanded={!collapsed}
            title={ar ? 'طي القائمة الجانبية' : i18n("admin.core.collapseSidebar")}
          >
            <PanelLeftClose size={18} />
          </button>
          <div className="sp-search">
            <Search size={17} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={ar ? 'بحث عن حجز أو رحلة أو عميل...' : i18n("admin.core.searchBookingsTripsCustomers")}
              aria-label={ar ? 'البحث في أقسام الإدارة' : i18n("admin.core.searchAdminModules")}
            />
            {query && (
              <button type="button" onClick={() => setQuery('')} aria-label={i18n("admin.core.clear")}>
                <X size={15} />
              </button>
            )}
            {query && <div className="sp-search-results" role="navigation" aria-label={ar ? 'نتائج البحث' : i18n("admin.core.searchResults")}>
              {searchResults.length ? searchResults.map((item) => <Link key={item.href} href={item.href} onClick={() => setQuery('')}><item.icon size={16} /><span>{ar ? item.ar : item.en}</span></Link>) : <span>{ar ? 'لا توجد أقسام مطابقة' : i18n("admin.core.noMatchingModules")}</span>}
            </div>}
          </div>
          <div className="sp-top-actions">
            <LanguageToggle label={LOCALE_SHORT_LABELS[siteLocale] + ' - ' + currency} onOpen={() => setLanguageOpen(true)} />
            <Link
              className="sp-icon-btn"
              href="/"
              aria-label={ar ? 'فتح الموقع' : i18n("admin.core.viewWebsite")}
              title={ar ? 'فتح الموقع' : i18n("admin.core.viewWebsite")}
            >
              <ExternalLink size={18} />
            </Link>
            <button type="button" className="sp-icon-btn" aria-label={ar ? 'الإشعارات' : i18n("admin.shared.notifications")} aria-expanded={notificationsOpen} onClick={() => { setNotificationsOpen((open) => !open); setUserMenu(false) }}>
              <Bell size={18} />
              {unreadCount > 0 && <i className="dot" aria-hidden="true" />}
            </button>
            {notificationsOpen && (
              <AdminNotificationPanel
                ar={ar}
                state={adminNotifications}
                onOpen={(href) => {
                  setNotificationsOpen(false)
                  if (href) router.push(href)
                }}
              />
            )}
            <div className="sp-user-wrap">
              <button
                type="button"
                className="sp-user-chip"
                aria-haspopup="menu"
                aria-expanded={userMenu}
                aria-label={ar ? 'قائمة الحساب' : i18n("admin.core.accountMenu")}
                onClick={() => { setUserMenu((open) => !open); setNotificationsOpen(false) }}
              >
                <Avatar name={displayName} size={34} src={shellAvatar} />
                <span>
                  <strong>{displayName}</strong>
                  <small>{chipSub}</small>
                </span>
                <ChevronDown size={15} />
              </button>
              {userMenu && <div className="sp-user-menu" role="menu">
                <Link href="/admin/profile" role="menuitem" onClick={() => setUserMenu(false)}><User size={16} /><span><b>{ar ? 'البروفايل' : i18n("admin.core.profile")}</b><small>{user?.email}</small></span></Link>
                <button type="button" role="menuitem" onClick={logout}><LogOut size={16} /><span><b>{ar ? 'تسجيل الخروج' : i18n("admin.core.logout")}</b></span></button>
              </div>}
            </div>
          </div>
        </header>
        <main className="sp-content">
          {children}
        </main>
      </div>
      {languageOpen && (
        <AdminLanguageModal
          activeLocale={siteLocale}
          ar={ar}
          currency={currency}
          onClose={() => setLanguageOpen(false)}
          onSelect={changeLocale}
          onCurrency={changeCurrency}
        />
      )}
      <Toaster />
    </div>
  )
}

function AdminLanguageModal({
  activeLocale,
  ar,
  currency,
  onClose,
  onSelect,
  onCurrency,
}: {
  activeLocale: Locale
  ar: boolean
  currency: Currency
  onClose: () => void
  onSelect: (locale: Locale) => void
  onCurrency: (currency: Currency) => void
}) {
  const copy = getLanguageDialogText(ar ? 'ar' : 'en')
  const currencies = currencyChoices(activeLocale)
  // Same region list as the storefront modal: driven by the shared locale
  // config, so both modals stay identical by construction.
  const regions = getLanguageRegions(ar ? 'ar' : 'en')
  return (
    <div className="language-backdrop" role="presentation" onMouseDown={onClose}>
      <div className="language-modal" role="dialog" aria-modal="true" aria-labelledby="language-title" onMouseDown={(event) => event.stopPropagation()}>
        <div className="language-modal-head">
          <h2 id="language-title">{copy.modalTitle}</h2>
          <button className="language-close" onClick={onClose} aria-label={copy.closeLabel}><X size={20} /></button>
        </div>
        <h3>{copy.curTitle}</h3>
        <div className="language-options currency-options">
          {currencies.map(([name, code, value]) => (
            <button key={code} className={currency === value ? 'selected' : ''} onClick={() => { onCurrency(value); onClose() }} aria-pressed={currency === value}>
              <span>{name}</span><strong>{code}</strong>
            </button>
          ))}
        </div>
        <h3>{copy.regTitle}</h3>
        <div className="language-options region-options">
          {regions.map(([region, language, value]) => (
            <button key={region} type="button" className={value === activeLocale ? 'selected' : ''} onClick={() => { onSelect(value); onClose() }} aria-pressed={value === activeLocale}>
              <span>{region}</span><strong>{language}</strong>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

function AdminNotificationPanel({
  ar,
  state,
  onOpen,
}: {
  ar: boolean
  state: {
    recent: AdminNotification[]
    unreadCount: number
    loading: boolean
    loadError: string
    refresh: () => void
    markRead: (id: string) => Promise<boolean>
    markAllRead: () => Promise<boolean>
  }
  onOpen: (href: string | null) => void
}) {
  const i18n = useAdminTranslations("admin.core")

  const { recent, unreadCount, loading, loadError, refresh, markRead, markAllRead } = state

  const openNotification = async (item: AdminNotification) => {
    await markRead(item.id)
    onOpen(item.href)
  }

  return (
    <SharedNotificationPanel
      items={recent}
      unreadCount={unreadCount}
      loading={loading}
      loadError={loadError}
      title={ar ? 'الإشعارات' : i18n("admin.shared.notifications")}
      dialogLabel={ar ? 'الإشعارات' : 'Notifications'}
      unreadLabel={unreadCount > 0 ? (ar ? `${unreadCount} غير مقروء` : `${unreadCount} unread`) : null}
      markAllLabel={ar ? 'تعليم الكل كمقروء' : 'Mark all read'}
      markingAllLabel={ar ? 'جارٍ التعليم…' : 'Marking…'}
      loadingLabel={ar ? 'جارٍ تحميل الإشعارات' : 'Loading notifications'}
      retryLabel={ar ? 'إعادة المحاولة' : 'Retry'}
      emptyTitle={ar ? 'لا توجد إشعارات' : "You're all caught up"}
      emptyHint={ar ? 'ستظهر هنا طلبات العملاء والمدفوعات الجديدة.' : 'New customer requests and payments will appear here.'}
      iconForType={iconForAdminNotification}
      formatTime={(iso) => timeAgo(iso, ar)}
      linkItems={false}
      onOpenItem={openNotification}
      onMarkAll={() => markAllRead()}
      onRetry={refresh}
    />
  )
}

export function PageHead({
  eyebrow,
  title,
  titleAr,
  sub,
  subAr,
  actions,
  backHref,
  backLabelEn,
  backLabelAr,
}: {
  eyebrow: string
  title: string
  titleAr?: string
  sub?: string
  subAr?: string
  actions?: React.ReactNode
  backHref?: string
  backLabelEn?: string
  backLabelAr?: string
}) {
  const locale = useAdminLocale()
  return (
    <div className="sp-pagehead">
      <div className="sp-pagehead-title-row">
        {backHref && <AdminBackButton href={backHref} labelEn={backLabelEn ?? 'Back'} labelAr={backLabelAr ?? 'رجوع'} />}
        <div>
          <p>{adminText(locale, eyebrow)}</p>
          <h1>{locale === 'ar' && titleAr ? titleAr : adminText(locale, title)}</h1>
          {sub && <span>{locale === 'ar' && subAr ? subAr : adminText(locale, sub)}</span>}
        </div>
      </div>
      {actions && <div className="sp-pagehead-actions">{actions}</div>}
    </div>
  )
}
