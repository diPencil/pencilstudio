'use client'
import { AdminText as RegistryAdminText } from '@/components/admin/ui/admin-text'

import { useAdminTranslations } from '@/components/admin/providers/admin-translations'


import { useCallback, useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { FileText, Search, Languages, Link2, Pencil, Eye, Save, Send, RotateCcw, Monitor, Smartphone } from 'lucide-react'
import { PageHead } from '@/components/admin/admin-shell'
import { Card, AdminStats, AdminTableTools, AdminTableWrap, AdminTableActions, AdminIconAction } from '@/components/admin/admin-ui'
import { AdminPagination, usePagination } from '@/components/admin/ui/admin-pagination'
import { AdminConfirmDialog } from '@/components/admin/ui/admin-confirm-dialog'
import { toast } from '@/components/admin/ui/admin-toaster'
import { SharedSelect } from '@/components/shared/shared-select'
import { SEO_PAGES, currentSeo, type SeoAction } from '@/lib/seo/seo-manager'
import { validateSeoContent, type SeoContent } from '@/lib/seo/seo-content'
import type { PageContentState } from '@/lib/cms/page-sections'
import type { SeoPageId as PageDocumentId } from '@/lib/seo/seo-manager'
import { ENABLED_LOCALES, LOCALE_LABELS, type EnabledLocale } from '@/lib/localization/locale-config'
import { protectEnquiryNavigation } from '@/lib/enquiries/enquiry-navigation'
import './seo-manager.css'
import { SeoGlobalSettings } from './seo-global-settings'
import { DynamicSeoRecords, SeoDiagnostics, fetchSavedRecordSeoPreview, type RecordSeoPreviewResponse, type SeoRecordResponse } from './seo-record-editor'
import { validateRecordSeoContent } from '@/lib/seo/record-seo'

type SeoInventoryRow = { id: string; name: string; route: string; kind: 'cms' | 'business' | 'private' | 'template'; editor: string | null; title: string; description: string; image: string; index: boolean | null; canonicalIssue: boolean; translationIssue: boolean; updatedAt: string | null }
type Inventory = { pages: SeoInventoryRow[]; languageUrls: 'cookie-only'; googleConnected: false; canEdit: boolean }
const missing = (row: SeoInventoryRow) => row.kind === 'cms' && (!row.title.trim() || !row.description.trim() || !row.image.trim())
const safeEditor = (href: string | null) => href?.startsWith('/admin/') && !href.includes('\\') ? href : null
function SeoNotice() {
  const i18n = useAdminTranslations("admin.seo")

  return <p className="cms-coverage-note">{i18n("admin.seo.languagesUseCookiesOnTheSameUrl_a128454")}</p>
}
export function SeoDashboard() {
  const i18n = useAdminTranslations("admin.seo")

  const [tab, setTab] = useState('Overview')
  const [data, setData] = useState<Inventory | null>(null)
  const [error, setError] = useState('')
  const [retry, setRetry] = useState(0)
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState('all')
  const [kind, setKind] = useState('all')
  useEffect(() => {
    const controller = new AbortController()
    setData(null); setError('')
    void fetch('/api/admin/website-cms/seo', { cache: 'no-store', signal: controller.signal }).then(async response => {
      if (!response.ok) throw new Error(response.status === 403 || response.status === 401 ? 'You do not have access to SEO inventory.' : 'Could not load SEO inventory.')
      const next: Inventory = await response.json()
      if (!controller.signal.aborted) setData(next)
    }).catch(error => { if (!controller.signal.aborted) setError(error instanceof Error ? error.message : 'Could not load SEO inventory.') })
    return () => controller.abort()
  }, [retry])
  const rows = (data?.pages ?? []).filter(row => (tab !== 'Static Pages' || row.kind === 'cms') && `${row.name} ${i18n.text(row.name)} ${row.route} ${row.title}`.toLowerCase().includes(query.toLowerCase()) && (kind === 'all' || row.kind === kind) && (status === 'all' || status === 'missing' && missing(row) || status === 'canonical' && row.canonicalIssue || status === 'translation' && row.translationIssue || status === 'noindex' && row.index === false || status === 'unavailable' && row.index === null))
  const paging = usePagination(rows)
  const filter = (update: (value: string) => void) => (value: string) => { update(value); paging.setPage(1) }
  return <div className="seo-manager">
    <PageHead eyebrow={i18n("admin.shared.websiteCms")} title={i18n("admin.seo.seoManager")} sub={i18n("admin.seo.pageMetadataInventoryAndIndependentSeoPublishing")} />
    <SeoNotice />
    <nav className="seo-tabs" aria-label={i18n("admin.seo.seoSections")}>{['Overview', 'Static Pages', 'Dynamic Content', 'Global Settings', 'Technical SEO'].map(item => <button type="button" className="sp-btn" key={item} aria-pressed={tab === item} onClick={() => { setTab(item); setKind('all'); setStatus('all'); setQuery(''); paging.setPage(1) }}>{i18n.text(item)}</button>)}</nav>
    {tab === 'Dynamic Content' && <DynamicSeoRecords />}
    {tab === 'Technical SEO' && <SeoDiagnostics />}
    {tab === 'Global Settings' && data && <SeoGlobalSettings canEdit={data.canEdit} />}
    {error && <p className="form-error" role="alert">{<RegistryAdminText text={error} />} <button type="button" className="sp-btn" onClick={() => setRetry(n => n + 1)}>{i18n("admin.shared.retry")}</button></p>}
    {!data && !error && <p role="status">{i18n("admin.seo.loadingSeoInventory")}</p>}
    {data && (tab === 'Overview' || tab === 'Static Pages') && <>{tab === 'Overview' && <><AdminStats items={[
      { label: i18n("admin.seo.registeredPagesTemplates"), value: data.pages.length, icon: FileText },
      { label: i18n("admin.seo.missingCmsOverrides"), value: data.pages.filter(missing).length, note: i18n("admin.seo.titleDescriptionOrImageOverrideIsEmpty_2fbe009"), icon: Search, tone: 'orange' },
      { label: i18n("admin.seo.nonSelfCanonicalOverrides"), value: data.pages.filter(row => row.canonicalIssue).length, note: i18n("admin.seo.differentTargetReviewIntentNotNecessarilyA_c8bf40d"), icon: Link2 },
      { label: i18n("admin.seo.missingCmsTranslations"), value: data.pages.filter(row => row.kind === 'cms' && row.translationIssue).length, icon: Languages, tone: 'orange' },
    ]} /><p className="cms-coverage-note">{data.pages.filter(row => row.index === null).length} {" "}{i18n("admin.seo.rowsHaveAnUnavailableIndexingBaselineCounts_ccf1b47")}</p>
      <AdminStats items={[
        { label: i18n("admin.seo.indexAllowedInVerifiedSources"), value: data.pages.filter(row => row.index === true).length, note: i18n("admin.seo.excludesUnknownTemplatesNotGoogleIndexedPage_f6b7378"), icon: FileText },
        { label: i18n("admin.seo.completeCmsOverrides"), value: data.pages.filter(row => row.kind === 'cms' && !missing(row)).length, note: i18n("admin.seo.titleDescriptionAndSocialImageConfigured"), icon: Search },
        { label: i18n("admin.seo.missingSourceSocialImages"), value: data.pages.filter(row => (row.kind === 'cms' || row.kind === 'business') && !row.image).length, icon: Eye },
        { label: i18n("admin.seo.noindexPrivateRoutes"), value: data.pages.filter(row => row.index === false).length, icon: FileText },
      ]} />
      <Card title={i18n("admin.seo.recentlyUpdatedSeoSources")}><ul className="cms-recent-list">{data.pages.filter(row => row.updatedAt).sort((a, b) => b.updatedAt!.localeCompare(a.updatedAt!)).slice(0, 5).map(row => <li key={row.id}><span>{i18n.text(row.name)}</span><time dateTime={row.updatedAt!}>{new Date(row.updatedAt!).toLocaleString()}</time></li>)}{!data.pages.some(row => row.updatedAt) && <li>{i18n("admin.seo.noSavedCmsSeoOrPageUpdates_e07eef9")}</li>}</ul></Card>
      </>}
      <Card title={i18n("admin.seo.seoInventory")}>
        <AdminTableTools query={query} onQueryChange={filter(setQuery)} placeholder={i18n("admin.seo.searchPageRouteOrTitle")}>
          <SharedSelect label={i18n("admin.seo.pageType")} value={kind} onChange={filter(setKind)} options={['all', 'cms', 'business', 'private', 'template'].map(value => ({ value, label: value === 'all' ? 'All types' : value }))} />
          <SharedSelect label={i18n("admin.seo.seoStatus")} value={status} onChange={filter(setStatus)} options={[{ value: 'all', label: i18n("admin.shared.allStatuses") }, { value: 'missing', label: i18n("admin.seo.missingCmsOverride") }, { value: 'canonical', label: i18n("admin.seo.canonicalIssue") }, { value: 'translation', label: i18n("admin.seo.translationIssue") }, { value: 'noindex', label: i18n("admin.seo.noindex") }, { value: 'unavailable', label: i18n("admin.seo.baselineUnavailable") }]} />
        </AdminTableTools>
        <AdminTableWrap><table className="sp-table"><thead><tr><th>{i18n("admin.seo.pageRoute")}</th><th>{i18n("admin.shared.type")}</th><th>{i18n("admin.seo.titleDescription")}</th><th>{i18n("admin.shared.image")}</th><th>{i18n("admin.seo.indexingChecks")}</th><th>{i18n("admin.shared.updated")}</th><th>{i18n("admin.shared.actions")}</th></tr></thead><tbody>{paging.pageRows.map(row => {
          const editor = row.kind === 'cms' && Object.hasOwn(SEO_PAGES, row.id) ? '/admin/website-cms/seo/' + encodeURIComponent(row.id) : safeEditor(row.editor)
          return <tr key={row.id}><td><strong>{i18n.text(row.name)}</strong><small className="cms-row-note">{row.route}</small></td><td>{row.kind}</td><td className="seo-copy"><strong>{row.title || (row.kind === 'cms' ? i18n("admin.seo.noTitleOverride") : i18n("admin.seo.titleBaselineUnavailable"))}</strong><small className="cms-row-note">{row.description || (row.kind === 'cms' ? i18n("admin.seo.noDescriptionOverride") : i18n("admin.seo.descriptionBaselineUnavailable"))}</small></td><td>{row.image ? i18n("admin.seo.set") : row.kind === 'cms' ? i18n("admin.seo.noOverride") : i18n("admin.seo.unavailable")}</td><td>{row.index === null ? i18n("admin.seo.baselineUnavailable") : row.index ? i18n("admin.seo.indexAllowed_ace1103") : i18n("admin.seo.noindex")}{row.canonicalIssue && <small className="cms-row-note">{i18n("admin.seo.canonicalIssue")}</small>}{row.translationIssue && <small className="cms-row-note">{i18n("admin.seo.translationIssue")}</small>}</td><td>{row.updatedAt ? new Date(row.updatedAt).toLocaleString() : i18n("admin.seo.notRecorded")}</td><td><AdminTableActions>{editor && <AdminIconAction icon={Pencil} href={editor} label={row.kind === 'cms' ? i18n("admin.seo.editSeo") : i18n("admin.shared.openOriginalEditor")} />}{!row.route.includes('[') && row.route.startsWith('/') && !row.route.startsWith('//') && !row.route.includes('\\') && <AdminIconAction icon={Eye} href={row.route} label={i18n("admin.seo.viewPage")} />}</AdminTableActions>{!editor && <small>{i18n("admin.seo.sourceManaged")}</small>}</td></tr>
        })}{rows.length === 0 && <tr><td colSpan={7}>{i18n("admin.shared.noPagesMatchTheseFilters")}</td></tr>}</tbody></table></AdminTableWrap>
        <AdminPagination {...paging} onPage={paging.setPage} onPageSize={paging.setPageSize} />
      </Card></>}
  </div>
}

export function SeoEditor({ pageKey, recordKey }: { pageKey: PageDocumentId; recordKey?: { kind: string; slug: string } }) {
  const i18n = useAdminTranslations("admin.seo")

  const router = useRouter()
  const [state, setState] = useState<PageContentState | null>(null)
  const [content, setContent] = useState<(SeoContent & { structuredData?: boolean }) | null>(null)
  const [recordData, setRecordData] = useState<SeoRecordResponse | null>(null)
  const [previewOpen, setPreviewOpen] = useState(true)
  const [savedPreview, setSavedPreview] = useState<RecordSeoPreviewResponse | null>(null)
  const [previewError, setPreviewError] = useState('')
  const [canEdit, setCanEdit] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
    const [conflict, setConflict] = useState(false)
  const [locale, setLocale] = useState<EnabledLocale>('en')
  const [device, setDevice] = useState('desktop')
  const [confirm, setConfirm] = useState<SeoAction | 'reload' | null>(null)
  const [pending, setPending] = useState<(() => void) | null>(null)
  const lock = useRef(false)
  const dirtyRef = useRef(false)
  const pendingRef = useRef(false)
  const saved = recordData ? recordData.state.draft ?? recordData.state.published ?? emptyRecordSeo() : state ? state.seoDraft ?? currentSeo(state, pageKey) : null
  const dirty = !!content && JSON.stringify(content) !== JSON.stringify(saved)
  dirtyRef.current = dirty
  const endpoint = recordKey ? '/api/admin/website-cms/seo/records/' + encodeURIComponent(recordKey.kind) + '/' + encodeURIComponent(recordKey.slug) : '/api/admin/website-cms/seo/' + encodeURIComponent(pageKey)
  const load = useCallback(async () => {
    if (lock.current) return
    lock.current = true; setBusy(true); setError('')
    setSavedPreview(null); setPreviewError('')
    try {
      const response = await fetch(endpoint, { cache: 'no-store' })
      if (response.status === 401 || response.status === 403) { setCanEdit(false); throw new Error('You do not have access to this SEO editor.') }
      if (!response.ok) throw new Error('Could not load SEO. Retry using Reload.')
      const data = await response.json()
      if (recordKey) { const next = data as SeoRecordResponse; setRecordData(next); setContent(next.state.draft ?? next.state.published ?? emptyRecordSeo()) }
      else { setState(data.state); setContent(data.state.seoDraft ?? currentSeo(data.state, pageKey)) }
      setCanEdit(data.canEdit); setConflict(false); dirtyRef.current = false
    } catch (error) { setError(error instanceof Error ? error.message : 'Could not load SEO.') }
    finally { lock.current = false; setBusy(false) }
  }, [endpoint, pageKey, recordKey?.kind, recordKey?.slug])
  useEffect(() => { void load() }, [load])
  useEffect(() => {
    const navigate = (next: () => void) => { if (lock.current || pendingRef.current) return; pendingRef.current = true; setPending(() => next) }
    const cleanup = protectEnquiryNavigation(window, () => dirtyRef.current || lock.current, navigate)
    const click = (event: MouseEvent) => {
      if ((!dirtyRef.current && !lock.current) || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return
      const anchor = event.target instanceof Element ? event.target.closest('a[href]') : null
      if (!(anchor instanceof HTMLAnchorElement) || anchor.target === '_blank' || anchor.hasAttribute('download')) return
      const url = new URL(anchor.href)
      if (url.href === location.href) return
      event.preventDefault(); event.stopPropagation()
      navigate(() => url.origin === location.origin ? router.push(url.pathname + url.search + url.hash) : location.assign(url.href))
    }
    document.addEventListener('click', click, true)
    return () => { cleanup(); document.removeEventListener('click', click, true) }
  }, [router])
  const disabled = busy || !canEdit || conflict || !(state || recordData)
  const change = (next: SeoContent & { structuredData?: boolean }) => { if (disabled) return; setContent(next); setSavedPreview(null); setPreviewError('') }
  const validateSavedPreview = async () => {
    if (!recordKey || !recordData || dirty || busy || conflict || lock.current) return
    lock.current = true; setBusy(true); setSavedPreview(null); setPreviewError('')
    try { setSavedPreview(await fetchSavedRecordSeoPreview(endpoint, locale)) }
    catch (error) { setPreviewError(error instanceof Error ? error.message : 'Could not validate the saved preview.') }
    finally { lock.current = false; setBusy(false) }
  }
  const action = async (command: SeoAction) => {
    if (!(state || recordData) || !content || disabled || lock.current) return
    let validated: SeoContent | undefined
    try { if (command === 'save-draft') validated = recordKey ? validateRecordSeoContent(content) : validateSeoContent(content) }
    catch (error) { setError(error instanceof Error ? error.message : 'Check the SEO fields.'); return }
    lock.current = true; setBusy(true); setError('')
    setSavedPreview(null); setPreviewError('')
    try {
      const response = await fetch(endpoint, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: command, revision: recordData?.state.revision ?? state!.revision, ...(validated ? { content: validated } : {}) }) })
      if (response.status === 409) { setConflict(true); throw new Error('Another editor changed this page. Reload the latest revision before saving; your local edits remain visible.') }
      if (response.status === 401 || response.status === 403) { setCanEdit(false); throw new Error('Editing access is unavailable. Your local edits remain visible.') }
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'Could not save SEO. Retry when ready.')
      if (recordKey) { const next = data as SeoRecordResponse; setRecordData(next); setContent(next.state.draft ?? next.state.published ?? emptyRecordSeo()); setCanEdit(next.canEdit) }
      else { const next: PageContentState = data.state; setState(next); setContent(next.seoDraft ?? currentSeo(next, pageKey)) }
      dirtyRef.current = false
      toast.success(command === 'save-draft' ? 'SEO draft saved. Public metadata is unchanged.' : command === 'publish' ? 'Saved SEO published. Page section drafts are unchanged.' : 'Original SEO restored. Saved SEO draft cleared; page section drafts are unchanged.', { dedupeKey: 'seo-editor-command' })
    } catch (error) { setError(error instanceof Error ? error.message : 'Could not save SEO.') }
    finally { lock.current = false; setBusy(false); setConfirm(null) }
  }
  const page = recordKey ? { name: recordData?.record.name ?? recordKey.slug, route: recordData?.record.publicUrl ?? 'Hidden record: no public URL' } : SEO_PAGES[pageKey]!
  const published = recordData ? recordData.state.published : state ? currentSeo(state, pageKey) : null
  const draft = recordData ? recordData.state.draft : state?.seoDraft
  const previewImage = content?.image || recordData?.record.image
  return <div className="seo-manager">
    <PageHead eyebrow={i18n("admin.shared.websiteCms")} title={page.name + ' SEO'} sub={state || recordData ? i18n("admin.actions.routeRevisionSummary", { route: page.route, revision: recordData?.state.revision ?? state!.revision, suffix: dirty ? i18n("admin.seo.unsavedChanges") : '' }) : i18n("admin.seo.loadingSeo")} backHref="/admin/website-cms/seo" />
    <SeoNotice />
    <div className="cms-editor-toolbar"><nav className="sp-builder-language-tabs" aria-label={i18n("admin.seo.seoLanguage")}>{ENABLED_LOCALES.map(language => <button type="button" key={language} disabled={busy} data-active={locale === language ? '' : undefined} aria-pressed={locale === language} onClick={() => { setLocale(language); setSavedPreview(null); setPreviewError('') }}>{LOCALE_LABELS[language] ?? language}</button>)}</nav><div>
      <button className="sp-btn" type="button" disabled={busy} onClick={() => dirty ? setConfirm('reload') : void load()}><RotateCcw size={16} /> {" "}{i18n("admin.shared.reload")}</button>
      <button className="sp-btn" type="button" disabled={disabled || !dirty} onClick={() => void action('save-draft')}><Save size={16} /> {" "}{i18n("admin.shared.saveDraft")}</button>
      <button className="sp-btn" type="button" disabled={!content || busy} onClick={() => setPreviewOpen(value => !value)}><Eye size={16} /> {previewOpen ? i18n("admin.shared.closePreview") : i18n("admin.seo.previewDraft")}</button>
      {recordKey && <button className="sp-btn" type="button" disabled={dirty || busy || conflict || !recordData} onClick={() => void validateSavedPreview()}><Eye size={16} /> {" "}{i18n("admin.seo.validateSavedPreview")}</button>}
      <button className="sp-btn primary" type="button" disabled={disabled || dirty || !draft || JSON.stringify(draft) === JSON.stringify(published)} onClick={() => setConfirm('publish')}><Send size={16} /> {" "}{i18n("admin.seo.publishSeo")}</button>
      <button className="sp-btn" type="button" disabled={disabled} onClick={() => setConfirm('restore')}><RotateCcw size={16} /> {" "}{i18n("admin.seo.restoreOriginalSeo")}</button>
    </div></div>
    {error && <p className="form-error" role="alert">{<RegistryAdminText text={error} />}</p>}
    {busy && <p role="status">{i18n("admin.seo.loadingOrSavingSeo")}</p>}
    {(state || recordData) && !canEdit && <p role="status">{i18n("admin.seo.readOnlyEditingPermissionIsRequiredTo_6661f60")}</p>}
    {recordData && <p className="cms-coverage-note">{i18n("admin.seo.content")}{" "}{recordData.record.published ? i18n("admin.shared.published") : i18n("admin.shared.hidden")}{i18n("admin.seo.seo")}{" "}{recordData.state.published ? i18n("admin.seo.publishedOverride") : i18n("admin.shared.originalDefaults")}{recordData.state.draft ? i18n("admin.seo.savedDraft_7bda2db") : ''}{i18n("admin.seo.publishingSeoDoesNotPublishHiddenContent")}{" "}{safeEditor(recordData.record.sourceEditor) && <a href={recordData.record.sourceEditor}>{i18n("admin.seo.openOriginalContentEditor")}</a>}</p>}
    {previewOpen && <p role="status">{i18n("admin.seo.privateLocalDraftIllustrationBelowIncludingUnsaved_774568c")}</p>}
    {recordKey && <section className="seo-saved-preview" aria-label={i18n("admin.seo.savedSeoPreviewValidation")}>
      {previewError && <p className="form-error" role="alert">{previewError}</p>}
      {savedPreview && <>
        <p role="status">{i18n("admin.seo.savedPreviewValidated")}{savedPreview.locale.toUpperCase()}). {savedPreview.structuredData === null ? i18n("admin.seo.structuredDataIsDisabledOrUnavailableFor_a29a8f4") : i18n("admin.seo.automaticStructuredDataReturnedSuccessfully")} {" "}{i18n("admin.seo.thisIsAPrivateServerSnapshotNot_a11af31")}</p>
        <p>{savedPreview.publicUrl ?? i18n("admin.seo.noPublicUrl")}</p>
        <details><summary>{i18n("admin.seo.savedMetadata")}</summary><pre>{JSON.stringify(savedPreview.metadata, null, 2)}</pre></details>
        <details><summary>{i18n("admin.seo.savedStructuredData")}{savedPreview.structuredData === null ? i18n("admin.seo.disabledOrUnavailable") : ''}</summary><pre>{JSON.stringify(savedPreview.structuredData, null, 2)}</pre></details>
      </>}
    </section>}
    {content && <><p className="cms-coverage-note">{draft ? i18n("admin.seo.showingSavedSeoDraftWithAnyLocal_a10da48") : i18n("admin.seo.showingCurrentSeoDefaultsOrPublication")} {" "}{i18n("admin.seo.publishingAffectsSeoIndependentlyOfPageContent_f5e64bd")}</p>
      <div className={'seo-layout' + (!previewOpen ? ' seo-fields-only' : '')}><section className="cms-field-panel" aria-label={i18n("admin.seo.seoFields")}><fieldset disabled={disabled} lang={locale}>
        {(['title', 'description', 'ogTitle', 'ogDescription'] as const).map(field => <label key={field}>{({ title: 'Title', description: 'Description', ogTitle: 'Open Graph title', ogDescription: 'Open Graph description' })[field]} ({locale.toUpperCase()})
          <textarea rows={field.toLowerCase().includes('description') ? 4 : 2} maxLength={field.toLowerCase().includes('description') ? 320 : 160} value={content.text[locale][field] ?? ''} onChange={event => change({ ...content, text: { ...content.text, [locale]: { ...content.text[locale], [field]: event.target.value } } })} />
          <small>{(content.text[locale][field] ?? '').length} {" "}{i18n("admin.seo.characters")}{field === 'title' ? i18n("admin.seo.around5060IsACommonGuide") : field === 'description' ? i18n("admin.seo.around140160IsACommonGuide") : i18n("admin.seo.emptyUsesTheTitleOrDescription")}</small>
        </label>)}
        <label>{i18n("admin.shared.socialImageUrl")}<input maxLength={2000} value={content.image} onChange={event => change({ ...content, image: event.target.value })} /></label>
        <label>{i18n("admin.seo.canonicalSameSitePath")}<input list={recordData ? 'record-canonical-paths' : undefined} placeholder={page.route} maxLength={2000} value={content.canonical ?? ''} onChange={event => change({ ...content, canonical: event.target.value })} /><small>{i18n("admin.seo.publicPathOnlySuchAsAboutNo_50526ed")}</small></label>
        {recordData && <datalist id="record-canonical-paths">{recordData.record.canonicalPaths.map(path => <option key={path} value={path} />)}</datalist>}
        {(['index', 'follow'] as const).map(field => <label className="cms-checkbox" key={field}><input type="checkbox" checked={content[field] ?? true} onChange={event => change({ ...content, [field]: event.target.checked })} />{field === 'index' ? i18n("admin.seo.allowIndexing") : i18n("admin.seo.allowFollowingLinks")}{content[field] === undefined && ' (default)'}</label>)}
        {recordKey && <label className="cms-checkbox"><input type="checkbox" checked={content.structuredData ?? true} onChange={event => change({ ...content, structuredData: event.target.checked })} />{i18n("admin.seo.enableAutomaticStructuredData")}</label>}
        <label>{i18n("admin.seo.twitterCard")}<SharedSelect label={i18n("admin.seo.twitterCard")} disabled={disabled} value={content.card ?? 'summary_large_image'} onChange={card => change({ ...content, card: card as SeoContent['card'] })} options={[{ value: 'summary', label: i18n("admin.seo.summary") }, { value: 'summary_large_image', label: i18n("admin.seo.summaryWithLargeImage") }]} /></label>
      </fieldset></section>
      <aside className="seo-preview" hidden={!previewOpen}><Card title={i18n("admin.seo.googlePreview")} action={<div className="seo-devices">{[{ value: 'desktop', icon: Monitor }, { value: 'mobile', icon: Smartphone }].map(({ value, icon: Icon }) => <button key={value} type="button" className="sp-btn" title={value} aria-label={value + ' preview'} aria-pressed={device === value} onClick={() => setDevice(value)}><Icon size={18} /></button>)}</div>}>
        <div className={'seo-google ' + device} lang={locale} dir="ltr"><small>TravNeeds</small><div>{content.canonical || page.route}</div><h3>{content.text[locale].title || recordData?.record.name || i18n("admin.seo.titleOverrideEmptyBaselinePreviewUnavailable")}</h3><p>{content.text[locale].description || recordData?.record.description || i18n("admin.seo.descriptionOverrideEmptyBaselinePreviewUnavailable")}</p></div>
        <p className="cms-coverage-note">{i18n("admin.seo.illustrativePreviewOfTheseOverridesGoogleMay_9378ce9")}</p>
      </Card><Card title={i18n("admin.seo.socialPreview")}><div className="seo-social" lang={locale}>{previewImage && <img src={previewImage} alt="Social preview" referrerPolicy="no-referrer" />}<strong>{content.text[locale].ogTitle || content.text[locale].title || recordData?.record.name || i18n("admin.seo.originalTitleFallback")}</strong><p>{content.text[locale].ogDescription || content.text[locale].description || recordData?.record.description || i18n("admin.seo.originalDescriptionFallback")}</p><small>{content.canonical || page.route}</small><p>{i18n("admin.seo.robots")}{" "}{content.index === false ? 'noindex' : 'index'}, {content.follow === false ? 'nofollow' : 'follow'}{recordData && !recordData.record.published ? i18n("admin.seo.hiddenContentStaysUnavailablePublicly") : ''}</p></div></Card><Card title={i18n("admin.seo.currentPublicSeo")}><dl className="seo-public"><dt>{i18n("admin.seo.title")}{locale.toUpperCase()})</dt><dd>{published?.text[locale].title || i18n("admin.seo.noOverride")}</dd><dt>{i18n("admin.seo.description")}</dt><dd>{published?.text[locale].description || i18n("admin.seo.noOverride")}</dd><dt>{i18n("admin.seo.canonicalOverride")}</dt><dd>{published?.canonical || i18n("admin.seo.existingCanonical")}</dd></dl></Card></aside></div>
    </>}
    <AdminConfirmDialog open={confirm !== null} onClose={() => setConfirm(null)} canConfirm={!busy} title={confirm === 'reload' ? i18n("admin.seo.discardUnsavedEditsAndReload") : confirm === 'restore' ? i18n("admin.seo.restoreOriginalSeo_dadcc2a") : i18n("admin.seo.publishSavedSeoDraft")} description={confirm === 'reload' ? i18n("admin.seo.localEditsWillBeDiscardedAndThe_6738133") : confirm === 'restore' ? i18n("admin.seo.thisClearsTheSavedSeoDraftAnd_6a0e1d2") : i18n("admin.seo.theSavedSeoDraftBecomesPublicPage_5c78bae")} confirmLabel={confirm === 'reload' ? i18n("admin.seo.discardAndReload") : confirm === 'restore' ? i18n("admin.seo.restoreSeo") : i18n("admin.seo.publishSeo")} cancelLabel={i18n("admin.shared.keepEditing")} onConfirm={() => { if (confirm === 'reload') { setConfirm(null); void load() } else if (confirm) void action(confirm) }} />
    <AdminConfirmDialog open={pending !== null} onClose={() => { pendingRef.current = false; setPending(null) }} title={i18n("admin.seo.discardUnsavedSeoEdits")} description={i18n("admin.seo.yourSavedDraftRemainsAvailableLocalEdits_4c51506")} confirmLabel={i18n("admin.shared.discardAndLeave")} cancelLabel={i18n("admin.shared.keepEditing")} canConfirm={!busy} onConfirm={() => { const next = pending; dirtyRef.current = false; pendingRef.current = false; setPending(null); next?.() }} />
  </div>
}

function emptyRecordSeo(): SeoContent { return { text: Object.fromEntries(ENABLED_LOCALES.map((l) => [l, { title: '', description: '' }])) as SeoContent['text'], image: '' } }
