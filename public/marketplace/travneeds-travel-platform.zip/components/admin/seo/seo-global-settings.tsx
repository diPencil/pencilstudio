'use client';
import { AdminText as RegistryAdminText } from '@/components/admin/ui/admin-text'

import { useAdminTranslations } from '@/components/admin/providers/admin-translations'


import { useCallback, useEffect, useRef, useState } from 'react';
import { RotateCw, Save } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { protectEnquiryNavigation } from '@/lib/enquiries/enquiry-navigation';
import { DEFAULT_GTM_CONTAINER_ID } from '@/lib/marketing/tracking';
import { Card } from '@/components/admin/admin-ui';
import { AdminConfirmDialog } from '@/components/admin/ui/admin-confirm-dialog';
import { toast } from '@/components/admin/ui/admin-toaster';

const fields = [
  ['site.seoTitle', 'Default SEO title', 160],
  ['site.seoDescriptionEn', 'Default description (EN)', 320],
  ['site.seoDescriptionAr', 'Default description (AR)', 320],
  ['site.seoDescriptionEs', 'Default description (ES)', 320],
  ['site.seoDescriptionIt', 'Default description (IT)', 320],
  ['site.seoImage', 'Default social image URL', 2000],
  ['site.googleSiteVerification', 'Google Search Console verification token', 256],
] as const;

const trackingFields = [
  ['tracking.gtmEnabled', 'Enable Google Tag Manager', 5],
  ['tracking.gtmContainerId', 'Google Tag Manager Container ID', 32],
] as const;

const allFields = [...fields, ...trackingFields] as const;

function readValues(snapshot: unknown): Record<string, string> {
  if (!snapshot || typeof snapshot !== 'object' || !('values' in snapshot)
    || !snapshot.values || typeof snapshot.values !== 'object') throw new Error('Invalid settings response.');
  const publicValues = snapshot.values as Record<string, unknown>;
  return Object.fromEntries(allFields.map(([key]) => {
    const stored = publicValues[key];
    if (typeof stored !== 'string') throw new Error('Invalid settings response.');
    if (key === 'tracking.gtmEnabled' && stored === '') return [key, 'true'];
    if (key === 'tracking.gtmContainerId' && stored === '') return [key, DEFAULT_GTM_CONTAINER_ID];
    return [key, stored];
  }));
}

export function SeoGlobalSettings({ canEdit = false }: { canEdit?: boolean }) {
  const i18n = useAdminTranslations("admin.seo")

  const router = useRouter();
  const [values, setValues] = useState<Record<string, string>>({});
  const [baseline, setBaseline] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [confirmReload, setConfirmReload] = useState(false);
  const [pendingNavigation, setPendingNavigation] = useState<(() => void) | null>(null);
  const busy = useRef(false);
  const dirtyRef = useRef(false);
  const pendingRef = useRef(false);
  const dirty = allFields.some(([key]) => values[key] !== baseline[key]);
  dirtyRef.current = dirty;
  const load = useCallback(async () => {
    if (busy.current) return;
    busy.current = true;
    setLoading(true); setError('');
    try {
      const response = await fetch('/api/admin/settings', { cache: 'no-store' });
      if (!response.ok) throw new Error('Unable to load settings.');
      const next = readValues(await response.json());
      setValues(next); setBaseline(next); dirtyRef.current = false;
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Unable to load settings.');
    } finally { busy.current = false; setLoading(false); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  useEffect(() => {
    const navigate = (action: () => void) => {
      if (busy.current || pendingRef.current) return;
      pendingRef.current = true;
      setPendingNavigation(() => action);
    };
    const cleanup = protectEnquiryNavigation(window, () => dirtyRef.current || busy.current, navigate);
    const click = (event: MouseEvent) => {
      if ((!dirtyRef.current && !busy.current) || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return;
      const anchor = event.target instanceof Element ? event.target.closest('a[href]') : null;
      if (!(anchor instanceof HTMLAnchorElement) || (anchor.target && anchor.target !== '_self') || anchor.hasAttribute('download')) return;
      const url = new URL(anchor.href);
      if (url.href === window.location.href) return;
      event.preventDefault(); event.stopPropagation();
      navigate(() => url.origin === window.location.origin ? router.push(url.pathname + url.search + url.hash) : window.location.assign(url.href));
    };
    document.addEventListener('click', click, true);
    return () => { cleanup(); document.removeEventListener('click', click, true); };
  }, [router]);

  function requestReload() {
    if (busy.current || pendingRef.current) return;
    if (dirtyRef.current) {
      pendingRef.current = true;
      setConfirmReload(true);
    } else void load();
  }

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canEdit || loading || busy.current || pendingRef.current) return;
    const patch = Object.fromEntries(allFields.filter(([key]) => values[key] !== baseline[key]).map(([key]) => [key, values[key]]));
    if (!Object.keys(patch).length) return;
    busy.current = true; setSaving(true); setError('');
    try {
      const response = await fetch('/api/admin/settings', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ values: patch }),
      });
      if (!response.ok) throw new Error(response.status === 403 ? 'You do not have permission to edit settings.' : 'Unable to save settings. Check the entered values and retry.');
      const next = readValues(await response.json());
      setValues(next); setBaseline(next); dirtyRef.current = false;
      toast.success('Settings saved.', { dedupeKey: 'seo-global-save' });
    } catch (cause) {
      toast.error(cause instanceof Error ? cause.message : 'Unable to save settings.', { dedupeKey: 'seo-global-save' });
    } finally { busy.current = false; setSaving(false); }
  }

  return <Card title={i18n("admin.seo.globalSeoSettings")}>
    {loading && <p role="status">{i18n("admin.seo.loadingSettings")}</p>}
    {error && <p role="alert">{<RegistryAdminText text={error} />}</p>}
        {!canEdit && <p>{i18n("admin.seo.readOnlyEditingRequiresSettingsPermission")}</p>}
    <form onSubmit={save} className="cms-field-panel">
      <fieldset disabled={!canEdit || loading || saving || confirmReload || pendingNavigation !== null || !Object.keys(baseline).length}>
        <legend>{i18n("admin.seo.globalSeoDefaults")}</legend>
        {fields.map(([key, label, maxLength]) => <label key={key}>
          <span>{i18n.text(label)}</span>
          {key.startsWith('site.seoDescription')
            ? <textarea dir={key === 'site.seoDescriptionAr' ? 'rtl' : 'ltr'} maxLength={maxLength} value={values[key] ?? ''} onChange={event => { setValues(old => ({ ...old, [key]: event.target.value })); }} />
            : <input maxLength={maxLength} required={key === 'site.seoTitle'} dir={key === 'site.googleSiteVerification' || key === 'site.seoImage' ? 'ltr' : undefined} pattern={key === 'site.googleSiteVerification' ? '[A-Za-z0-9_-]*' : undefined} value={values[key] ?? ''} onChange={event => { setValues(old => ({ ...old, [key]: event.target.value })); }} />}
        </label>)}
      </fieldset>
      <fieldset disabled={!canEdit || loading || saving || confirmReload || pendingNavigation !== null || !Object.keys(baseline).length}>
        <legend>{i18n("admin.seo.trackingAnalytics")}</legend>
        <label className="cms-checkbox">
          <input
            type="checkbox"
            checked={values['tracking.gtmEnabled'] !== 'false'}
            onChange={event => { setValues(old => ({ ...old, 'tracking.gtmEnabled': event.target.checked ? 'true' : 'false' })); }}
          />
          {i18n("admin.seo.enableGoogleTagManager")}</label>
        <label>
          <span>{i18n("admin.seo.googleTagManagerContainerId")}</span>
          <input
            maxLength={32}
            required
            dir="ltr"
            pattern="GTM-[A-Z0-9]{4,12}"
            placeholder={DEFAULT_GTM_CONTAINER_ID}
            value={values['tracking.gtmContainerId'] ?? ''}
            onChange={event => { setValues(old => ({ ...old, 'tracking.gtmContainerId': event.target.value.toUpperCase() })); }}
          />
        </label>
        <p>{i18n("admin.seo.oneContainerLoadsOnPublicPagesOnly_39e8ee3")}</p>
      </fieldset>
      <p>{i18n("admin.seo.aConfiguredVerificationTokenDoesNotMean_ea1d086")}</p>
      <button className="sp-btn" type="submit" disabled={!canEdit || loading || saving || confirmReload || pendingNavigation !== null || !Object.keys(baseline).length || !dirty}><Save size={16} aria-hidden="true" />{saving ? 'Saving...' : i18n("admin.seo.saveSettings")}</button>
      <button className="sp-btn" type="button" disabled={loading || saving || confirmReload || pendingNavigation !== null} onClick={requestReload}><RotateCw size={16} aria-hidden="true" />{error && !Object.keys(baseline).length ? i18n("admin.shared.retry") : i18n("admin.shared.reload")}</button>
    </form>
    <AdminConfirmDialog open={confirmReload} title={i18n("admin.seo.discardUnsavedSeoEditsAndReload")} description={i18n("admin.seo.localEditsWillBeDiscardedAndThe_fe6d3ad")} confirmLabel={i18n("admin.seo.discardAndReload")} cancelLabel={i18n("admin.shared.keepEditing")} canConfirm={!loading && !saving} onClose={() => { pendingRef.current = false; setConfirmReload(false); }} onConfirm={() => {
      if (busy.current || !pendingRef.current) return;
      pendingRef.current = false; setConfirmReload(false); void load();
    }} />
    <AdminConfirmDialog open={pendingNavigation !== null} title={i18n("admin.seo.discardUnsavedSeoEdits")} description={i18n("admin.seo.yourLocalEditsWillBeDiscardedWhen_08199d6")} confirmLabel={i18n("admin.shared.discardAndLeave")} cancelLabel={i18n("admin.shared.keepEditing")} canConfirm={!loading && !saving} onClose={() => { pendingRef.current = false; setPendingNavigation(null); }} onConfirm={() => {
      if (busy.current || !pendingRef.current) return;
      const action = pendingNavigation;
      dirtyRef.current = false; pendingRef.current = false;
      setValues(baseline); setPendingNavigation(null); action?.();
    }} />
  </Card>;
}
