'use client'

import type { ReactNode } from 'react'
import { LocaleProvider, useLocale } from '@/components/locale'

export type AdminLocale = 'en' | 'ar'

export function AdminLocaleProvider({ children }: { children: ReactNode }) {
  return <LocaleProvider>{children}</LocaleProvider>
}

// Admin chrome has EN/AR copy. Keep ES/IT preferences and content locales
// intact, using the existing English fallback for untranslated chrome.
export function useAdminLocale(): AdminLocale {
  const { locale } = useLocale()
  return locale === 'ar' ? 'ar' : 'en'
}
