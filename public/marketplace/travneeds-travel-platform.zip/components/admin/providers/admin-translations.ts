'use client'

import { useMemo } from 'react'
import { useAdminLocale } from './admin-locale'
import { adminText, formatAdminTranslation, type AdminTranslationValues } from '@/lib/localization/admin-translations'
import type { Locale } from '@/lib/localization/locale-config'

export interface AdminTranslator {
  (key: string, values?: AdminTranslationValues): string
  text(source: string): string
}

export function useAdminTranslations(namespace: string, previewLocale?: Locale): AdminTranslator {
  const adminLocale = useAdminLocale()
  const locale = previewLocale ?? adminLocale
  return useMemo(() => Object.assign(
    (key: string, values?: AdminTranslationValues) => formatAdminTranslation(locale, key.startsWith('admin.') ? key : `${namespace}.${key}`, values),
    { text: (source: string) => adminText(locale, source) },
  ), [locale, namespace])
}
