'use client'
import { isCurrency, formatCurrency } from '@/lib/localization/currency'

import { useCallback } from 'react'
import { formatPrice, getCurrencyRates, useLocale, type Currency } from '@/components/locale'
import { readLocalePreferenceCookie, resolveLocale, type Locale } from '@/lib/localization/locale-config'

/**
 * Shared admin currency conversion (display-only).
 *
 * Tour booking accounting stores USD; other modules may own native currencies. This hook mirrors the storefront behavior:
 * it reads the selected `star-currency`, converts with the same DB-backed
 * configured rates (`getCurrencyRates`, missing foreign rates retain USD) and formats
 * with the same `Intl` rules. Nothing here changes stored values.
 */
export function readStoredAdminCurrency(): Currency {
  if (typeof window === 'undefined') return 'USD'
  try {
    const saved = window.localStorage.getItem('star-currency')
    return isCurrency(saved) ? saved : 'USD'
  } catch { return 'USD' }
}

export function readStoredAdminCurrencyLocale(): Locale {
  if (typeof window === 'undefined') return 'en'
  let stored: string | null = null
  let cookie: Locale | null = null
  try { stored = window.localStorage.getItem('star-locale') } catch { /* Cookie fallback remains available. */ }
  try { cookie = readLocalePreferenceCookie(document.cookie) } catch { /* Keep the built-in default if cookies are unavailable. */ }
  return resolveLocale(stored, cookie)
}

export function useAdminCurrency() {
  const { locale: intlLocale, currency } = useLocale()
  const formatUsd = useCallback(
    (usd: number) => formatPrice(usd, currency, intlLocale),
    [currency, intlLocale],
  )
  // Compact form for chart axes/legends (same converted value, short label).
  const formatUsdCompact = useCallback(
    (usd: number) => {
      const rate = getCurrencyRates()[currency]
      const available = Number.isFinite(rate) && rate > 0
      return formatCurrency(available ? usd * rate : usd, available ? currency : 'USD', intlLocale, { notation: 'compact', minimumFractionDigits: 0, maximumFractionDigits: 1 })
    },
    [currency, intlLocale],
  )
  return { currency, formatUsd, formatUsdCompact }
}

/** Drop-in converted display for a USD amount stored on the server. */
export function AdminMoney({ usd }: { usd: number }) {
  const { formatUsd } = useAdminCurrency()
  return <>{formatUsd(usd)}</>
}
