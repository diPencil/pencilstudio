'use client'

import { useEffect, useRef, useState } from 'react'
import { useLocale } from '@/components/locale'
import { ALL_LOCALES, LOCALE_LABELS } from '@/lib/localization/locale-config'
import { savedLocale } from '@/lib/localization/recipient-locale'
import { translate } from '@/lib/localization/platform-translations'
import { useProfileLanguage } from '@/lib/localization/use-profile-language'
import { invalidateNotifications } from '@/lib/notifications/admin-notifications'

export function ProfileLanguageSetting() {
  const { locale, setLocale } = useLocale()
  const { preference, loading, loadFailed, save } = useProfileLanguage('admin')
  const [selection, setSelection] = useState(locale)
  const [result, setResult] = useState<'saved' | 'saveFailed' | null>(null)
  const [saving, setSaving] = useState(false)
  const pending = useRef(false)
  const t = (key: string) => translate(locale, `profile.language.${key}`)

  useEffect(() => { setSelection(preference ?? locale) }, [preference, locale])

  async function submit() {
    if (pending.current || loading || loadFailed) return
    pending.current = true
    setSaving(true)
    setResult(null)
    try {
      await save(selection)
      setLocale(selection)
      invalidateNotifications()
      setResult('saved')
    } catch {
      setResult('saveFailed')
    } finally {
      pending.current = false
      setSaving(false)
    }
  }

  return <section className="sp-form" aria-busy={loading || saving}>
    <label>{t('label')}
      <select value={selection} disabled={loading || loadFailed || saving} onChange={event => {
        const value = savedLocale(event.target.value)
        if (value) setSelection(value)
        setResult(null)
      }}>
        {ALL_LOCALES.map(value => <option key={value} value={value} lang={value}>{LOCALE_LABELS[value]}</option>)}
      </select>
    </label>
    <small>{t('help')}</small>
    {loadFailed && <p role="alert">{t('loadFailed')}</p>}
    {result && <p role={result === 'saved' ? 'status' : 'alert'}>{t(result)}</p>}
    <div><button type="button" className="sp-btn" disabled={loading || loadFailed || saving} onClick={() => void submit()}>{t('save')}</button></div>
  </section>
}
