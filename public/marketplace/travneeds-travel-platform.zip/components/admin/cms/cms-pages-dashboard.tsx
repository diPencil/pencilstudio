'use client'
import { ENABLED_LOCALES } from '@/lib/localization/locale-config'
import { AdminText as RegistryAdminText } from '@/components/admin/ui/admin-text'

import { useAdminTranslations } from '@/components/admin/providers/admin-translations'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { Eye, FileText, Layers, Pencil, Send } from 'lucide-react'
import { PageHead } from '@/components/admin/admin-shell'
import { Card, AdminStats, AdminTableTools, AdminTableWrap, AdminTableActions, AdminIconAction } from '@/components/admin/admin-ui'
import { AdminPagination, usePagination } from '@/components/admin/ui/admin-pagination'
import { SharedSelect } from '@/components/shared/shared-select'
import type { CmsPageDefinition } from '@/lib/cms/cms-coverage'
import { cmsSharedRegistry } from '@/lib/cms/cms-coverage'
type CmsPageRow = CmsPageDefinition & { statuses: { scope: string; mode: string; draft: boolean }[]; updatedAt: string | null; hasDraft: boolean; hasPublication: boolean }
type Snapshot = { pages: CmsPageRow[]; counts: { pages: number; manageable: number; routePatterns: number; sections: number; cms: number; business: number; functional: number; uncovered: number; partialInventories: number }; published: number; drafts: number }
export function CmsPagesDashboard({ overview = false }: { overview?: boolean }) {
  const i18n = useAdminTranslations("admin.cms")

  const [data, setData] = useState<Snapshot | null>(null)
  const [error, setError] = useState('')
  const [retry, setRetry] = useState(0)
  const [query, setQuery] = useState('')
  const [group, setGroup] = useState('all')
  const [status, setStatus] = useState('all')
  useEffect(() => { const controller = new AbortController(); setError(''); void fetch('/api/admin/website-cms/pages', { signal: controller.signal, cache: 'no-store' }).then(async (response) => { const next = await response.json(); if (!response.ok) throw new Error(); if (!controller.signal.aborted) setData(next) }).catch(() => { if (!controller.signal.aborted) setError('Could not load CMS publication data.') }); return () => controller.abort() }, [retry])
  const rows = (data?.pages ?? []).filter((page) => (group === 'all' || group === page.group) && (status === 'all' || status === 'draft' && page.hasDraft || status === 'published' && page.hasPublication || status === 'uncovered' && page.sections.some((s) => s.owner === 'uncovered')) && `${page.name} ${i18n.text(page.name)} ${page.route}`.toLowerCase().includes(query.toLowerCase()))
  const paging = usePagination(rows)
  return <>
    <PageHead eyebrow={i18n("admin.shared.websiteCms")} title={overview ? i18n("admin.cms.websiteCms") : i18n("admin.cms.pagesSections_2f25b07")} sub={i18n("admin.cms.pageStructurePresentationEditorsAndOriginalContent_ca2a854")} />
    {error && <p className="form-error" role="alert">{<RegistryAdminText text={error} />} <button className="sp-btn" type="button" onClick={() => setRetry((value) => value + 1)}>{i18n("admin.shared.retry")}</button></p>}
    {!data && !error && <p role="status">{i18n("admin.cms.loadingRealPublicationData")}</p>}
    {data && <>
      <AdminStats items={[{ label: i18n("admin.cms.manageablePagesTemplates"), value: data.counts.manageable, note: `${data.counts.pages} registered · ${data.counts.routePatterns} route patterns`, icon: FileText }, { label: i18n("admin.cms.pagesWithCmsPublications"), value: data.published, note: i18n("admin.cms.atLeastOnePublishedCmsDocument"), icon: Send, tone: 'green' }, { label: i18n("admin.cms.pagesWithDraftChanges"), value: data.drafts, note: i18n("admin.cms.savedDraftDiffersFromPublicContent"), icon: Pencil, tone: 'orange' }, { label: i18n("admin.cms.registeredPageSections"), value: data.counts.sections, note: `${data.counts.cms} CMS · ${data.counts.business} business · ${data.counts.functional} functional`, icon: Layers }]} />
      <p className="cms-coverage-note">{data.counts.uncovered} {" "}{i18n("admin.cms.registeredPresentationSectionsStillNeedIntegration")}{" "}{data.counts.partialInventories} {" "}{i18n("admin.cms.pageTemplateInventoriesArePartialThisIs_b79b0d5")}</p>
      {overview && <Card title={i18n("admin.cms.recentlyUpdatedCmsContent")} action={<Link href="/admin/website-cms/pages" className="sp-btn">{i18n("admin.cms.allPagesSections")}</Link>}>
        {data.pages.some((page) => page.updatedAt) ? <ul className="cms-recent-list">{data.pages.filter((page) => page.updatedAt).sort((a, b) => b.updatedAt!.localeCompare(a.updatedAt!)).slice(0, 6).map((page) => <li key={page.key}><Link href={'/admin/website-cms/pages/' + page.key}>{i18n.text(page.name)}</Link><span>{new Date(page.updatedAt!).toLocaleString()}</span></li>)}</ul> : <p>{i18n("admin.cms.noSavedCmsChangesYet")}</p>}
      </Card>}
      {overview && <Card title={i18n("admin.cms.sharedContentSources")}><ul className="cms-recent-list">{cmsSharedRegistry.map((section) => <li key={section.id}><span>{<RegistryAdminText text={section.name} />}</span>{section.editor ? <Link className="sp-btn" href={section.editor}>{i18n("admin.shared.openOriginalEditor")}</Link> : <span>{section.owner === 'functional' ? i18n("admin.cms.fixedBehavior") : i18n("admin.cms.integrationPending")}</span>}</li>)}</ul></Card>}
    </>}
    <Card title={overview ? i18n("admin.cms.quickAccessToPages") : i18n("admin.cms.actualPagesSections")}>
      <AdminTableTools query={query} onQueryChange={setQuery} placeholder={i18n("admin.cms.searchPageNameOrRoute")}><SharedSelect value={group} label={i18n("admin.cms.pageGroup")} onChange={setGroup} options={[{ value: 'all', label: i18n("admin.cms.allGroups") }, ...[...new Set((data?.pages ?? []).map((page) => page.group))].map((value) => ({ value, label: i18n.text(value) }))]} /><SharedSelect value={status} label={i18n("admin.cms.publicationCoverage")} onChange={setStatus} options={[{ value: 'all', label: i18n("admin.shared.allStatuses") }, { value: 'draft', label: i18n("admin.cms.draftChanges") }, { value: 'published', label: i18n("admin.cms.hasCmsPublication") }, { value: 'uncovered', label: i18n("admin.cms.needsIntegration") }]} /></AdminTableTools>
      <AdminTableWrap><table className="sp-table"><thead><tr><th>{i18n("admin.cms.page")}</th><th>{i18n("admin.shared.route")}</th><th>{i18n("admin.shared.type")}</th><th>{i18n("admin.cms.languages")}</th><th>{i18n("admin.shared.publication")}</th><th>{i18n("admin.cms.sections")}</th><th>{i18n("admin.shared.updated")}</th><th>{i18n("admin.shared.actions")}</th></tr></thead><tbody>{paging.pageRows.map((page) => <tr key={page.key}><td><strong>{i18n.text(page.name)}</strong>{page.inventory === 'partial' && <small className="cms-row-note">{i18n("admin.cms.partialInventory")}</small>}</td><td>{page.route}</td><td>{i18n.text(page.type)}</td><td>{page.sections.some((s) => s.owner === 'cms') ? ENABLED_LOCALES.map(locale => locale.toUpperCase()).join(' / ') : i18n("admin.cms.ownedBySource")}</td><td>{page.statuses.length ? page.statuses.map((status) => <div key={status.scope}>{status.scope}: {i18n.text(status.mode)}{status.draft && <> · {i18n("admin.cms.draftChanges")}</>}</div>) : i18n("admin.cms.originalSource")}</td><td>{page.sections.length}</td><td>{page.updatedAt ? new Date(page.updatedAt).toLocaleString() : ' - '}</td><td><AdminTableActions><AdminIconAction icon={Pencil} href={'/admin/website-cms/pages/' + page.key} label={i18n("admin.cms.openPageStructure")} />{!page.route.includes('[') && <AdminIconAction icon={Eye} href={page.route} label={i18n("admin.shared.viewPublicPage")} />}</AdminTableActions></td></tr>)}{data && rows.length === 0 && <tr><td colSpan={8}>{i18n("admin.shared.noPagesMatchTheseFilters")}</td></tr>}</tbody></table></AdminTableWrap>
      <AdminPagination {...paging} onPage={paging.setPage} onPageSize={paging.setPageSize} />
    </Card>
  </>
}
