'use client'
import { AdminText as RegistryAdminText } from '@/components/admin/ui/admin-text'

import { useAdminTranslations } from '@/components/admin/providers/admin-translations'

import { useEffect, useRef, useState } from 'react'
import { Save, Send, RotateCcw, EyeOff } from 'lucide-react'
import { PageHead } from '@/components/admin/admin-shell'
import { Card } from '@/components/admin/admin-ui'
import { toast } from '@/components/admin/ui/admin-toaster'
import { AdminConfirmDialog } from '@/components/admin/ui/admin-confirm-dialog'
import { SharedSelect } from '@/components/shared/shared-select'
import { ENABLED_LOCALES, LOCALE_LABELS, type EnabledLocale } from '@/lib/localization/locale-config'
import { FAQ_HERO_DESTINATIONS } from '@/lib/cms/faq-hero'
import { originalShowcaseHero, SHOWCASE_PAGES, type ShowcaseHero, type ShowcaseHeroId, type ShowcaseHeroState } from '@/lib/cms/showcase-heroes'
import type { HeroAction } from '@/lib/cms/website-heroes'
import { isCompactHeroId } from '@/lib/cms/compact-hero-defaults'
import '@/app/admin/website-cms/hero-sections/homepage/hero-editor.css'

export function ShowcaseHeroEditor({ id }: { id: ShowcaseHeroId }) {
  const i18n = useAdminTranslations("admin.cms")

  const original = () => originalShowcaseHero(id)
  const [state, setState] = useState<ShowcaseHeroState | null>(null)
  const [draft, setDraft] = useState<ShowcaseHero>(original)
  const [canEdit, setCanEdit] = useState(false)
  const [locale, setLocale] = useState<EnabledLocale>('en')
  const [width, setWidth] = useState('desktop')
  const [busy, setBusy] = useState(false)
  const [dirty, setDirty] = useState(false)
  const [error, setError] = useState('')
    const [confirm, setConfirm] = useState<HeroAction | null>(null)
  const lock = useRef(false)
  const frame = useRef<HTMLIFrameElement>(null)
  const sync = () => frame.current?.contentWindow?.postMessage({ type: 'star-showcase-preview', id, content: draft, locale }, window.location.origin)
  useEffect(() => {
    sync()
    const ready = (event: MessageEvent) => { if (event.origin === window.location.origin && event.source === frame.current?.contentWindow && event.data?.type === 'star-showcase-preview-ready') sync() }
    window.addEventListener('message', ready)
    return () => window.removeEventListener('message', ready)
  }, [draft, locale])
  const load = async () => {
    setError('')
    try {
      const response = await fetch('/api/admin/website-cms/showcase-heroes/' + id, { cache: 'no-store' })
      const data = await response.json()
      if (!response.ok) throw new Error()
      setState(data.state); setDraft(data.state.draft ?? data.state.published ?? original()); setCanEdit(data.canEdit); setDirty(false)
    } catch { setError('Could not load hero. Reload to retry.') }
  }
  useEffect(() => { void load() }, [])
  const change = (next: Partial<ShowcaseHero>) => { setDraft((previous) => ({ ...previous, ...next })); setDirty(true) }
  const action = async (command: HeroAction) => {
    if (!state || !canEdit || lock.current) return
    lock.current = true; setBusy(true); setError('')
    try {
      const response = await fetch('/api/admin/website-cms/showcase-heroes/' + id, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action: command, revision: state.revision, ...(command === 'save-draft' ? { content: draft } : {}) }) })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'Could not save hero.')
      setState(data.state); setDraft(data.state.draft ?? data.state.published ?? original()); setDirty(false)
      if (command === 'save-draft') toast.success('Draft saved. Public content is unchanged.', { dedupeKey: 'showcase-hero-draft' })
      else if (command === 'restore') toast.success('Original hero restored.', { dedupeKey: 'showcase-hero-restore' })
      else if (command === 'unpublish') toast.success('Hero unpublished.', { dedupeKey: 'showcase-hero-unpublish' })
      else toast.success('Hero published.', { dedupeKey: 'showcase-hero-publish' })
    } catch (error) { setError(error instanceof Error ? error.message : 'Could not save hero.') }
    finally { lock.current = false; setBusy(false); setConfirm(null) }
  }
  const upload = async (file: File | undefined, field: 'image' | 'mobileImage') => {
    if (!file || !state || !canEdit || lock.current) return
    lock.current = true; setBusy(true); setError('')
    try {
      const body = new FormData(); body.set('type', 'image'); body.set('file', file)
      const response = await fetch('/api/admin/website-cms/hero-media', { method: 'POST', body })
      const data = await response.json()
      if (!response.ok || typeof data.media?.url !== 'string') throw new Error(data.error || 'Upload failed.')
      change({ [field]: data.media.url }); toast.info('Image ready. Save draft to retain its reference.', { dedupeKey: 'showcase-hero-upload' })
    } catch (error) { setError(error instanceof Error ? error.message : 'Upload failed.') }
    finally { lock.current = false; setBusy(false) }
  }
  const disabled = !state || !canEdit || busy
  const labels: Record<string, string> = { title: 'Heading', eyebrow: 'Small heading', intro: 'Description', primaryLabel: 'Primary button', secondaryLabel: 'Secondary button', railLabel: 'Featured panel label', railTitle: 'Featured panel heading', statsLabel: 'Summary accessibility label', stat0: 'First statistic label', stat1: 'Second statistic label', meta0: 'First detail label', meta1: 'Second detail label' }
  return <>
    <PageHead eyebrow={i18n("admin.cms.heroSections")} title={SHOWCASE_PAGES[id].name} backHref="/admin/website-cms/hero-sections" />
    <Card title={i18n("admin.cms.heroContent")} sub={state ? i18n("admin.actions.revisionSummary", { revision: state.revision, mode: i18n.text(state.mode), suffix: '' }) : i18n("admin.shared.loading")}>
      {error && <p className="form-error" role="alert">{<RegistryAdminText text={error} />}</p>}
      {!state && <button className="sp-btn" type="button" onClick={() => void load()}>{i18n("admin.shared.reload")}</button>}
      <form className="cms-hero-form" onSubmit={(event) => { event.preventDefault(); void action('save-draft') }}>
        <fieldset disabled={disabled}>
          <nav className="sp-builder-language-tabs" aria-label={i18n("admin.shared.contentLanguage")}>
            {ENABLED_LOCALES.map((value) => (
              <button
                className="sp-btn"
                type="button"
                key={value}
                data-active={locale === value ? '' : undefined}
                aria-pressed={locale === value}
                onClick={() => setLocale(value)}
              >
                {LOCALE_LABELS[value] ?? value}
              </button>
            ))}
          </nav>
          <div className="cms-hero-fields">{Object.keys(draft.text[locale]).map((field) => <label key={field}>{labels[field] ?? field}<input required maxLength={field === 'intro' ? 600 : field === 'title' || field === 'railTitle' ? 160 : 100} value={draft.text[locale][field]} onChange={(event) => change({ text: { ...draft.text, [locale]: { ...draft.text[locale], [field]: event.target.value } } })} /></label>)}</div>
          {Object.keys(draft.links).map((field) => <label className="cms-hero-media-field" key={field}>{field === 'primaryHref' ? i18n("admin.cms.primaryButtonDestination") : field === 'secondaryHref' ? i18n("admin.cms.secondaryButtonDestination") : i18n("admin.cms.featuredPanelDestination")}<SharedSelect disabled={disabled} value={draft.links[field]} onChange={(value) => change({ links: { ...draft.links, [field]: value } })} label={field} options={[...new Set([...Object.values(original().links), ...FAQ_HERO_DESTINATIONS])].map((value) => ({ value, label: value }))} /></label>)}
          {!isCompactHeroId(id) && <>
          {(['image', 'mobileImage'] as const).map((field) => <label className="cms-hero-media-field" key={field}>{field === 'image' ? i18n("admin.cms.desktopImageOverride") : i18n("admin.cms.mobileImageOverride")}<input value={draft[field]} maxLength={2000} onChange={(event) => change({ [field]: event.target.value })} /><input type="file" accept="image/jpeg,image/png,image/webp,image/gif" onChange={(event) => { void upload(event.target.files?.[0], field); event.target.value = '' }} />{draft[field] && <button className="sp-btn" type="button" onClick={() => change({ [field]: '' })}>{i18n("admin.cms.useOriginalMedia")}</button>}</label>)}
          <label className="cms-hero-media-field">{i18n("admin.cms.imageAlt")}<input value={draft.alt[locale]} maxLength={250} onChange={(event) => change({ alt: { ...draft.alt, [locale]: event.target.value } })} /></label>
          <label>{i18n("admin.cms.position")}<SharedSelect disabled={disabled} label={i18n("admin.cms.position")} value={draft.position} onChange={(value) => change({ position: value as ShowcaseHero['position'] })} options={['source', 'center', 'top', 'bottom', 'left', 'right'].map((value) => ({ value, label: value === 'source' ? 'Original position' : value }))} /></label>
          <label className="cms-hero-media-field"><input type="checkbox" checked={draft.overlay !== null} onChange={(event) => change({ overlay: event.target.checked ? 0.4 : null })} /> {" "}{i18n("admin.cms.customOverlay")}</label>
          {draft.overlay !== null && <label>{i18n("admin.cms.overlay")}{" "}{Math.round(draft.overlay * 100)}%<input type="range" min="0" max="85" value={Math.round(draft.overlay * 100)} onChange={(event) => change({ overlay: Number(event.target.value) / 100 })} /></label>}
          </>}
        </fieldset>
        <div className="cms-hero-actions"><button className="sp-btn" type="submit" disabled={disabled}><Save size={16} /> {" "}{i18n("admin.shared.saveDraft")}</button><button className="sp-btn" type="button" disabled={disabled || dirty || !state?.draft} onClick={() => setConfirm('publish')}><Send size={16} /> {" "}{i18n("admin.cms.publishSavedDraft")}</button><button className="sp-btn" type="button" disabled={disabled || dirty || state?.mode !== 'published'} onClick={() => setConfirm('unpublish')}><EyeOff size={16} /> {" "}{i18n("admin.shared.unpublish")}</button><button className="sp-btn" type="button" disabled={disabled} onClick={() => setConfirm('restore')}><RotateCcw size={16} /> {" "}{i18n("admin.cms.restoreOriginal")}</button></div>
      </form>
    </Card>
    <Card title={i18n("admin.shared.livePreview")} action={<SharedSelect label={i18n("admin.cms.previewSize")} value={width} onChange={setWidth} options={[{ value: 'desktop', label: i18n("admin.cms.desktop") }, { value: 'mobile', label: i18n("admin.cms.mobile") }]} />}>
      {state && <iframe ref={frame} onLoad={sync} src={'/website-cms-preview/showcase/' + id} title={SHOWCASE_PAGES[id].name + ' inactive preview'} className={'cms-hero-frame ' + width} />}
    </Card>
    <AdminConfirmDialog open={confirm !== null} onClose={() => setConfirm(null)} onConfirm={() => { if (confirm) void action(confirm) }} canConfirm={!busy} title={confirm === 'restore' ? i18n("admin.cms.restoreOriginalHero") : confirm === 'unpublish' ? i18n("admin.cms.unpublishHero") : i18n("admin.cms.publishSavedDraft_41401dd")} description={confirm === 'restore' ? i18n("admin.cms.thisReplacesTheDraftAndUnsavedEdits_a796c4c") : i18n("admin.cms.thisChangesThePublicHeroOnlyOther_ddfc9a7")} confirmLabel={i18n("admin.cms.confirm")} />
  </>
}
