'use client'
import { useAdminTranslations } from '@/components/admin/providers/admin-translations'


import { useState } from 'react'
import { ArrowDown, ArrowUp, Plus, Trash2 } from 'lucide-react'
import { AdminConfirmDialog } from '@/components/admin/ui/admin-confirm-dialog'
import { SharedSelect } from '@/components/shared/shared-select'
import { FAQ_HERO_DESTINATIONS, type EditorialSection } from '@/lib/cms/faq-hero'
import { ENABLED_LOCALES, type EnabledLocale } from '@/lib/localization/locale-config'

export function EditorialSectionsEditor({ sections, locale, disabled, onChange }: {
  sections: EditorialSection[]; locale: EnabledLocale; disabled: boolean; onChange: (sections: EditorialSection[]) => void
}) {
  const i18n = useAdminTranslations("admin.cms")

  const [removeId, setRemoveId] = useState<string | null>(null)
  const change = (index: number, field: 'heading' | 'description' | 'action', value: string) => {
    onChange(sections.map((section, position) => position === index ? { ...section, text: { ...section.text, [locale]: { ...section.text[locale], [field]: value } } } : section))
  }
  const move = (index: number, step: number) => {
    const next = [...sections]
    const target = index + step
    if (target < 0 || target >= next.length) return
    ;[next[index], next[target]] = [next[target], next[index]]
    onChange(next)
  }
  const add = () => {
    if (disabled || sections.length >= 8) return
    const fields = () => ({ heading: '', description: '', action: '' })
    onChange([...sections, { id: 'section-' + crypto.randomUUID(), text: Object.fromEntries(ENABLED_LOCALES.map((locale) => [locale, fields()])) as Record<EnabledLocale, { heading: string; description: string; action: string }>, href: '/contact' }])
  }
  return <section className="cms-page-sections" aria-labelledby="cms-page-sections-title">
    <h2 id="cms-page-sections-title">{i18n("admin.cms.pageSections")}</h2>
    {sections.map((section, index) => <fieldset key={section.id} className="cms-page-section" disabled={disabled}>
      <legend>{index + 1}. {section.text[locale].heading || i18n("admin.cms.newSection")}</legend>
      <div className="cms-hero-actions">
        <button type="button" className="sp-btn" title={i18n("admin.cms.moveSectionUp")} aria-label={i18n("admin.actions.moveSectionUp", { position: index + 1 })} disabled={disabled || index === 0} onClick={() => move(index, -1)}><ArrowUp size={16} /></button>
        <button type="button" className="sp-btn" title={i18n("admin.cms.moveSectionDown")} aria-label={i18n("admin.actions.moveSectionDown", { position: index + 1 })} disabled={disabled || index === sections.length - 1} onClick={() => move(index, 1)}><ArrowDown size={16} /></button>
        <button type="button" className="sp-btn" title={i18n("admin.cms.removeSection")} aria-label={i18n("admin.actions.removeSection", { position: index + 1 })} disabled={disabled} onClick={() => setRemoveId(section.id)}><Trash2 size={16} /></button>
      </div>
      <label>{i18n("admin.cms.sectionHeading")}{locale.toUpperCase()})<input required maxLength={120} value={section.text[locale].heading} onChange={(event) => change(index, 'heading', event.target.value)} /></label>
      <label>{i18n("admin.cms.sectionContent")}{locale.toUpperCase()})<textarea required maxLength={1200} rows={5} value={section.text[locale].description} onChange={(event) => change(index, 'description', event.target.value)} /></label>
      <div className="cms-hero-fields">
        <label>{i18n("admin.cms.linkLabel")}{locale.toUpperCase()})<input required maxLength={100} value={section.text[locale].action} onChange={(event) => change(index, 'action', event.target.value)} /></label>
        <label>{i18n("admin.cms.linkDestination")}<SharedSelect value={section.href} label={i18n("admin.actions.sectionDestination", { position: index + 1 })} disabled={disabled} options={FAQ_HERO_DESTINATIONS.map((href) => ({ value: href, label: href }))} onChange={(href) => onChange(sections.map((item, position) => position === index ? { ...item, href } : item))} /></label>
      </div>
    </fieldset>)}
    <button type="button" className="sp-btn" disabled={disabled || sections.length >= 8} onClick={add}><Plus size={16} /> {" "}{i18n("admin.cms.addSection")}</button>
    <AdminConfirmDialog open={removeId !== null} onClose={() => setRemoveId(null)} title={i18n("admin.cms.removeThisSectionFromTheDraft")} description={i18n("admin.cms.thePublicPageChangesOnlyAfterSaving_5895acc")} confirmLabel={i18n("admin.cms.removeSection")} canConfirm={!disabled} onConfirm={() => { onChange(sections.filter((section) => section.id !== removeId)); setRemoveId(null) }} />
  </section>
}
