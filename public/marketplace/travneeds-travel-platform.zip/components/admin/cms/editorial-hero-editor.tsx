'use client'
import { AdminText as RegistryAdminText } from '@/components/admin/ui/admin-text'

import { useAdminTranslations } from '@/components/admin/providers/admin-translations'

import { useEffect, useRef, useState } from 'react'
import { Eye, EyeOff, RotateCcw, Save, Send, Upload } from 'lucide-react'
import { PageHead } from '@/components/admin/admin-shell'
import { Card } from '@/components/admin/admin-ui'
import { toast } from '@/components/admin/ui/admin-toaster'
import { AdminConfirmDialog } from '@/components/admin/ui/admin-confirm-dialog'
import { SharedSelect } from '@/components/shared/shared-select'
import { ENABLED_LOCALES, LOCALE_LABELS, type EnabledLocale } from '@/lib/localization/locale-config'
import { FAQ_HERO_DESTINATIONS, type FaqHero, type FaqHeroState } from '@/lib/cms/faq-hero'
import { originalEditorialHero, EDITORIAL_HERO_PAGES, type EditorialHeroId } from '@/lib/cms/editorial-hero-definitions'
import type { HeroAction } from '@/lib/cms/website-heroes'
import { isInformationPageId } from '@/lib/cms/information-pages'
import { EditorialSectionsEditor } from '@/components/admin/cms/editorial-sections-editor'
import '@/app/admin/website-cms/hero-sections/homepage/hero-editor.css'

export function EditorialHeroEditor({ id }: { id: EditorialHeroId }) {
  const i18n = useAdminTranslations("admin.cms")

  const original = () => originalEditorialHero(id)
  const endpoint = '/api/admin/website-cms/editorial-heroes/' + id
  const page = EDITORIAL_HERO_PAGES[id]
  const hasPageSections = isInformationPageId(id)
  const [state, setState] = useState<FaqHeroState | null>(null)
  const [draft, setDraft] = useState<FaqHero>(original)
  const [canEdit, setCanEdit] = useState(false)
  const [locale, setLocale] = useState<EnabledLocale>('en')
  const [busy, setBusy] = useState(false)
  const [dirty, setDirty] = useState(false)
  const [error, setError] = useState('')
    const [confirm, setConfirm] = useState<HeroAction | null>(null)
  const [preview, setPreview] = useState(false)
  const [width, setWidth] = useState('desktop')
  const lock = useRef(false)
  const load = async () => {
    setError('')
    try {
      const response = await fetch(endpoint, { cache: 'no-store' })
      const data = await response.json()
      if (!response.ok) throw new Error()
      setState(data.state); setDraft(data.state.draft ?? data.state.published ?? original()); setCanEdit(data.canEdit); setDirty(false)
    } catch { setError('Could not load hero. Reload to retry.') }
  }
  useEffect(() => { void load() }, [])
  const change = (next: Partial<FaqHero>) => { setDraft((previous) => ({ ...previous, ...next })); setDirty(true); setPreview(false) }
  const action = async (command: HeroAction) => {
    if (!state || !canEdit || lock.current) return
    lock.current = true; setBusy(true); setError('')
    try {
      const response = await fetch(endpoint, { method: 'PATCH', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action: command, revision: state.revision, ...(command === 'save-draft' ? { content: draft } : {}) }) })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'Could not save hero.')
      setState(data.state); setDraft(data.state.draft ?? data.state.published ?? original()); setDirty(false)
      if (command === 'save-draft') toast.success('Draft saved. Public content is unchanged.', { dedupeKey: 'editorial-hero-draft' })
      else if (command === 'publish') toast.success(hasPageSections ? 'Page content published.' : 'Hero published.', { dedupeKey: 'editorial-hero-publish' })
      else if (command === 'restore') toast.success(hasPageSections ? 'Original hero and page sections restored and published.' : 'Original hero restored and published.', { dedupeKey: 'editorial-hero-restore' })
      else toast.success('Hero unpublished. Page content is unchanged.', { dedupeKey: 'editorial-hero-unpublish' })
    } catch (error) { setError(error instanceof Error ? error.message : 'Could not save hero.') }
    finally { lock.current = false; setBusy(false); setConfirm(null) }
  }
  const upload = async (file?: File) => {
    if (!file || !canEdit || !state || lock.current) return
    lock.current = true; setBusy(true); setError('')
    try {
      const body = new FormData(); body.set('file', file); body.set('type', 'image')
      const response = await fetch('/api/admin/website-cms/hero-media', { method: 'POST', body })
      const data = await response.json()
      if (!response.ok || typeof data.media?.url !== 'string') throw new Error(data.error || 'Upload failed.')
      change({ image: data.media.url }); toast.info('Image uploaded. Reference is not published yet.', { dedupeKey: 'editorial-hero-upload' })
    } catch (error) { setError(error instanceof Error ? error.message : 'Upload failed.') }
    finally { lock.current = false; setBusy(false) }
  }
  const disabled = !state || !canEdit || busy
  const fields = draft.text[locale]
  const labels = { heading: 'Heading', eyebrow: 'Small heading', description: 'Description', action: 'Button label', alt: 'Image alt text' }
  return <>
    <PageHead eyebrow={i18n("admin.cms.heroSections")} title={page.name} backHref="/admin/website-cms/hero-sections" />
    <Card title={i18n("admin.cms.heroContent")} sub={state ? i18n("admin.actions.revisionSummary", { revision: state.revision, mode: i18n.text(state.mode), suffix: '' }) : i18n("admin.shared.loading")}>
      {error && <p className="form-error" role="alert">{<RegistryAdminText text={error} />}</p>}
      {!state && <button type="button" className="sp-btn" onClick={() => void load()}>{i18n("admin.shared.reload")}</button>}
      <form className="cms-hero-form" onSubmit={(event) => { event.preventDefault(); void action('save-draft') }}>
        <fieldset disabled={disabled}>
          <nav className="sp-builder-language-tabs" aria-label={i18n("admin.shared.contentLanguage")}>
            {ENABLED_LOCALES.map((value) => (
              <button
                key={value}
                type="button"
                data-active={locale === value ? '' : undefined}
                aria-pressed={locale === value}
                onClick={() => setLocale(value)}
              >
                {LOCALE_LABELS[value] ?? value}
              </button>
            ))}
          </nav>
          <div className="cms-hero-fields">{(Object.keys(labels) as (keyof typeof labels)[]).map((field) => <label key={field}>{labels[field]}<input value={fields[field]} maxLength={field === 'description' ? 600 : field === 'heading' ? 160 : field === 'alt' ? 250 : 100} required={field !== 'eyebrow' && field !== 'alt'} onChange={(event) => change({ text: { ...draft.text, [locale]: { ...fields, [field]: event.target.value } } })} /></label>)}</div>
          <label className="cms-hero-media-field">{i18n("admin.cms.imageUrl")}<input value={draft.image} maxLength={2000} required onChange={(event) => change({ image: event.target.value })} /></label>
          <label className="cms-hero-media-field"><span><Upload size={16} /> {" "}{i18n("admin.cms.uploadImage")}</span><input type="file" accept="image/jpeg,image/png,image/webp,image/gif" onChange={(event) => { void upload(event.target.files?.[0]); event.target.value = '' }} /></label>
          <label>{i18n("admin.cms.buttonDestination")}<SharedSelect value={draft.href} onChange={(href) => change({ href })} label={i18n("admin.cms.buttonDestination")} disabled={disabled} options={FAQ_HERO_DESTINATIONS.map((value) => ({ value, label: value }))} /></label>
          {hasPageSections && <EditorialSectionsEditor sections={draft.sections ?? []} locale={locale} disabled={disabled} onChange={(sections) => change({ sections })} />}
        </fieldset>
        <div className="cms-hero-actions">
          <button type="submit" className="sp-btn" disabled={disabled}><Save size={16} /> {" "}{i18n("admin.shared.saveDraft")}</button>
          <button type="button" className="sp-btn" disabled={!state?.draft || dirty || busy} onClick={() => setPreview((value) => !value)}><Eye size={16} /> {" "}{i18n("admin.cms.previewSavedDraft")}</button>
          <button type="button" className="sp-btn" disabled={disabled || dirty || !state?.draft} onClick={() => setConfirm('publish')}><Send size={16} /> {" "}{i18n("admin.cms.publishSavedDraft")}</button>
          <button type="button" className="sp-btn" disabled={disabled || dirty || state?.mode !== 'published'} onClick={() => setConfirm('unpublish')}><EyeOff size={16} /> {" "}{i18n("admin.shared.unpublish")}</button>
          <button type="button" className="sp-btn" disabled={disabled} onClick={() => setConfirm('restore')}><RotateCcw size={16} /> {" "}{i18n("admin.cms.restoreOriginal")}</button>
        </div>
      </form>
    </Card>
    {preview && <Card title={i18n("admin.cms.savedDraftPreview")} action={<SharedSelect value={width} onChange={setWidth} label={i18n("admin.cms.previewSize")} options={[{ value: 'desktop', label: i18n("admin.cms.desktop") }, { value: 'mobile', label: i18n("admin.cms.mobile") }]} />}><iframe key={`${state?.revision}-${locale}`} title={page.name + ' saved draft preview'} src={'/website-cms-preview/editorial/' + id + '?locale=' + locale} className={'cms-hero-frame ' + width} /></Card>}
    <AdminConfirmDialog open={confirm !== null} onClose={() => setConfirm(null)} onConfirm={() => { if (confirm) void action(confirm) }} canConfirm={!busy} title={confirm === 'restore' ? hasPageSections ? i18n("admin.cms.restoreOriginalPageContent") : i18n("admin.cms.restoreOriginalHero") : confirm === 'unpublish' ? i18n("admin.cms.unpublishHero") : i18n("admin.cms.publishSavedDraft_41401dd")} description={hasPageSections ? confirm === 'restore' ? i18n("admin.cms.thisReplacesTheDraftAndPublishedHero_976f3e8") : confirm === 'unpublish' ? i18n("admin.cms.thisHidesTheHeroPublishedPageSections_70e730a") : i18n("admin.cms.thisPublishesTheSavedHeroAndAll_1f5b608") : confirm === 'restore' ? i18n("admin.cms.thisReplacesTheSavedDraftUnsavedEdits_914296a") : i18n("admin.cms.thisChangesThePublicHeroOnlyOther_ddfc9a7")} confirmLabel={i18n("admin.cms.confirm")} />
  </>
}
