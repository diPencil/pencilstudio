'use client'
import { EmptyFleetHero, EmptyOffersHero } from '@/components/cms/empty-fleet-hero'
import { carTripTypeForKey } from '@/lib/cars/car-request'
import { CmsPublicLink } from '@/components/cms/cms-public-link'

import { usePresentation, PresentationSection, PresentationOrder, useSharedFaqs } from '@/components/cms/presentation-content-context'


import { CmsFaqBody } from '@/components/cms/cms-additional-pages'
import type { PublicPageContent } from '@/lib/cms/page-sections'

import Link from 'next/link'
import { OfferCards, CampaignDetail, CampaignPlacementSlot } from '@/components/cms/offer-campaigns'
import { Suspense, useEffect, useMemo, useRef, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import { ArrowRight, CalendarCheck, CalendarDays, Camera, Check, CircleAlert, Clock3, Compass, CarFront, Eye, EyeOff, Gift, Headphones, Mail, MapPin, MessageCircle, Minus, Phone, Plus, Search, Send, Share2, ShieldCheck, Sparkles, Star, Sun, Ticket, Users, type LucideIcon } from 'lucide-react'
import { blogs, cars, destinations, events, faqs, offers, policies, siteImages } from '@/data/content'
import { placedOffers } from '@/lib/marketing/marketing-campaigns'
import { isOfferActive, offerHref } from '@/lib/offers/special-offers'
import { getActiveDealPercent } from '@/data/tours'
import { useBrandSettings } from '@/lib/admin/admin-store'
import { localizeCatalogue, vehicleTransmissionLabel } from '@/lib/catalogue/catalogue-translations'
import { useDbCars, useDbCarsStatus, useDbEvents } from '@/lib/cars/events-cars-client'
import { useCarQuote } from '@/lib/cars/car-quote-client'
import { CarQuoteSummary } from './cars/car-quote-summary'
import { parseVehicleCapacity } from '@/lib/cars/car-request'
import { useDbBlogs, useDbOffers, useDbOffersStatus } from '@/lib/catalogue/offers-blogs-client'
import { usePublicDestinationsStatus } from '@/lib/catalogue/catalogue-client'
import { destinationTours } from '@/lib/destinations/destination-public'
import { invalidateToursCache, useDbTours, useDbToursStatus } from '@/lib/tours/tours-client'
import { eventCity, eventMapQuery, eventPriceLabel, eventStatusLabel, getEventStatus, getPublishedEvents, getRelatedEvents, isEventPublished, parseLegacyEventRange, resolveEventRange } from '@/lib/events/events'
import { formatCurrency } from '@/lib/localization/currency'
import { EventRequestForm } from '@/components/shared/event-request-form'
import { phoneHref, whatsappHref } from '@/data/company'
import { catalogTours, getDealPrice, getToursBySlugs } from '@/data/tours'
import type { Blog, Car, Destination, Event, Offer, Tour } from '@/data/types'
import { parseCarRequestQuery } from '@/lib/shared/query'
import { CAR_LOCATION_MAX, CAR_NOTE_MAX, hasCarErrors, isCarReference, sanitizeCarDraft, validateCarRequest, type CarFieldErrors, type CarRequest, type CarRequestDraft } from '@/lib/cars/car-request'
import { ImpersonationBanner } from '@/components/account/impersonation-banner'
import { useLocale, formatPrice, tx, type Locale } from './locale'
import { Breadcrumb, Heading, HelpCTA, Logo, PageShowcaseHero, SiteShell, TourCard, TourCardPresentation, extra, images } from '@/components/site'
import { LanguageSelector } from '@/components/layout/language-selector'
import { InternationalPhoneInput } from '@/components/shared/international-phone-input'
import { useCurrentUser } from '@/lib/auth/use-current-user'
import { SharedSelect } from '@/components/shared/shared-select'
import { telLink, whatsappLink } from '@/lib/shared/phone'
import { DateInput } from '@/components/shared/date-input'
import { customerErrorText } from '@/lib/account/customer-error-copy'
import { useFaqHero } from '@/components/cms/faq-hero-context'
import { useShowcaseHero } from '@/components/cms/showcase-hero-context'

export function EditorialHero({ eyebrow, title, copy, image = siteImages.pyramids, action = 'Explore with us', href = '/all-tours/one-day-tours' }: { eyebrow?: string; title: string; copy: string; image?: string; action?: string; href?: string }) {
  const state = useFaqHero()
  const { locale } = useLocale()
  if (state?.hidden || state?.unavailable) return null
  const content = state?.content
  const heroImage = content?.image?.trim() || image
  const text = content && locale !== 'ar' ? content.text[locale] : null
  return <section className="editorial-hero">{heroImage && <img src={heroImage} alt={text?.alt ?? ''}/>}<div className="editorial-overlay"/><div className="container editorial-content">{(text?.eyebrow ?? eyebrow) && <span>{text?.eyebrow ?? eyebrow}</span>}<h1>{text?.heading ?? title}</h1><p>{text?.description ?? copy}</p><Link className="primary-btn" href={content?.href ?? href}>{text?.action ?? action}<ArrowRight size={17}/></Link></div></section>
}

export function DetailNotFound({ title, copy, backHref, backLabel }: { title: string; copy: string; backHref: string; backLabel: string }) {
  return <SiteShell><main className="not-found"><div className="not-found-mark">404</div><h1>{title}</h1><p>{copy}</p><Link href={backHref} className="primary-btn">{backLabel}</Link></main></SiteShell>
}

export function ContentCard({ item, type = 'blog' }: { item: Blog | Event | Offer; type?: 'blog' | 'event' | 'offer' }) {
  const { locale } = useLocale()
  const href = type === 'blog' ? `/blogs/${item.slug}` : type === 'event' ? `/events/${item.slug}` : type === 'offer' ? `/special-offers/${item.slug}` : `/destinations/${item.slug}`
  const badge = 'badge' in item ? item.badge : undefined
  const meta = 'category' in item ? `${item.category}, ${item.date}` : 'date' in item ? item.date : undefined
  const description = 'excerpt' in item ? item.excerpt : item.copy
  return <article className="content-card"><Link href={href} className="content-image"><img src={item.image} alt={item.title}/>{badge && <b>{badge}</b>}</Link><div className="content-card-body">{meta && <small>{meta}</small>}<h3><Link href={href}>{item.title}</Link></h3><p>{description}</p><Link className="text-link" href={href}>{tx(locale, { en: 'Read more', es: 'Leer más', it: 'Leggi di più', ar: 'اقرأ المزيد' })} <ArrowRight size={15}/></Link></div></article>
}

export { AboutPage } from './cms/about-page'

export function ContactPage() {
  return <SiteShell><ContactPageContent /></SiteShell>
}

function ContactPageContent() {
  const cms = usePresentation("contact")
  const contactFaqs = useSharedFaqs(3)

  const { locale: cl } = useLocale()
  const brand = useBrandSettings()
  const ar = cl === 'ar'
  const ex = extra[cl]
  const contactMethods = [
    { Icon: Mail, title: cms.text("contact-enquiry","descriptionMethod0",tx(cl, { en: 'Email our travel team', es: 'Escribe a nuestro equipo de viajes', it: 'Scrivi al nostro team di viaggio', ar: 'راسل فريق الرحلات' })), value: brand.email, note: cms.text("contact-enquiry","descriptionMethod1",tx(cl, { en: 'For itineraries and general questions', es: 'Para itinerarios y consultas generales', it: 'Per itinerari e domande generali', ar: 'لبرامج الرحلات والأسئلة العامة' })), href: `mailto:${brand.email}` },
    { Icon: Phone, title: cms.text("contact-enquiry","descriptionMethod2",tx(cl, { en: 'Call our travel team', es: 'Llama a nuestro equipo de viajes', it: 'Chiama il nostro team di viaggio', ar: 'اتصل بفريقنا' })), value: brand.phone, note: cms.text("contact-enquiry","descriptionMethod3",tx(cl, { en: 'For direct enquiries and travel help', es: 'Para consultas directas y ayuda con tu viaje', it: 'Per richieste dirette e assistenza di viaggio', ar: 'للتواصل المباشر والاستفسارات' })), href: phoneHref(brand.phone) },
    { Icon: MessageCircle, title: cms.text("contact-enquiry","descriptionMethod4",tx(cl, { en: 'Chat with us on WhatsApp', es: 'Escríbenos por WhatsApp', it: 'Scrivici su WhatsApp', ar: 'راسلنا على واتساب' })), value: brand.whatsapp, note: cms.text("contact-enquiry","descriptionMethod5",tx(cl, { en: 'Start a direct WhatsApp conversation', es: 'Inicia una conversación directa por WhatsApp', it: 'Avvia una conversazione WhatsApp diretta', ar: 'ابدأ محادثة واتساب مباشرة' })), href: whatsappHref(brand.whatsapp) },
  ]
  const steps = cms.items("contact-v2-process", [['01', tx(cl, { en: 'Tell us about your trip', es: 'Cuéntanos tu viaje', it: 'Raccontaci il tuo viaggio', ar: 'احكيلنا عن رحلتك' }), tx(cl, { en: 'Share your dates, group size, and the places you want to experience.', es: 'Comparte tus fechas, el tamaño del grupo y los lugares que quieres conocer.', it: 'Condividi date, numero di partecipanti e luoghi che vuoi scoprire.', ar: 'شاركنا مواعيدك، عدد المسافرين، والأماكن اللي نفسك تشوفها.' })], ['02', tx(cl, { en: 'We shape the details', es: 'Damos forma a los detalles', it: 'Diamo forma ai dettagli', ar: 'نرتب التفاصيل' }), tx(cl, { en: 'Our local team reviews your idea and connects the right route and experiences.', es: 'Nuestro equipo local revisa tu idea y une la ruta y las experiencias adecuadas.', it: 'Il nostro team locale esamina la tua idea e collega itinerario ed esperienze giusti.', ar: 'فريقنا المحلي يراجع فكرتك ويجمع أنسب مسار وتجارب ليك.' })], ['03', tx(cl, { en: 'Receive a clear proposal', es: 'Recibe una propuesta clara', it: 'Ricevi una proposta chiara', ar: 'تستلم تصور واضح' }), tx(cl, { en: 'We return with an easy-to-review plan before you make any commitment.', es: 'Te devolvemos un plan fácil de revisar antes de ningún compromiso.', it: 'Ti presentiamo un piano facile da rivedere prima di qualsiasi impegno.', ar: 'نرجعلك بخطة مفهومة وتفاصيل جاهزة للمراجعة قبل أي التزام.' })]])

  return <main className="contact-v2"><PresentationOrder pageId="contact">
      <PageShowcaseHero image={siteImages.nile} eyebrow={tx(cl, { en: 'Local team, personal planning', es: 'Equipo local, planificación personal', it: 'Team locale, pianificazione personale', ar: 'فريق محلي, تخطيط شخصي' })} title={tx(cl, { en: 'Your Egypt journey starts with a conversation.', es: 'Tu viaje a Egipto empieza con una conversación.', it: 'Il tuo viaggio in Egitto inizia con una conversazione.', ar: 'رحلتك لمصر تبدأ بمحادثة.' })} intro={tx(cl, { en: 'Tell us how you want to experience Egypt, and we will help turn the idea into a thoughtful route shaped around your time and interests.', es: 'Cuéntanos cómo quieres vivir Egipto y te ayudaremos a convertir la idea en una ruta a medida según tu tiempo e intereses.', it: 'Raccontaci come vuoi vivere l\'Egitto: ti aiuteremo a trasformare l\'idea in un itinerario pensato su tempi e interessi.', ar: 'قولنا نفسك تشوف مصر إزاي، وإحنا نساعدك تحول الفكرة لمسار متوازن يناسب وقتك واهتماماتك.' })} primaryLabel={tx(cl, { en: 'Start the conversation', es: 'Inicia la conversación', it: 'Avvia la conversazione', ar: 'ابدأ المحادثة' })} primaryHref="#contact-enquiry" secondaryLabel={tx(cl, { en: 'Build a detailed trip', es: 'Crea un viaje detallado', it: 'Crea un viaggio dettagliato', ar: 'خطط رحلتك بالتفصيل' })} secondaryHref="/make-your-trip" railLabel={tx(cl, { en: 'Start here', es: 'Empieza aquí', it: 'Inizia qui', ar: 'ابدأ من هنا' })} railTitle={tx(cl, { en: 'Tell us the journey you have in mind.', es: 'Cuéntanos el viaje que tienes en mente.', it: 'Raccontaci il viaggio che hai in mente.', ar: 'احكيلنا عن الرحلة اللي في بالك.' })} railHref="#contact-enquiry" railMeta={[{ Icon: MessageCircle, label: tx(cl, { en: 'Trip enquiry', es: 'Consulta de viaje', it: 'Richiesta di viaggio', ar: 'استفسار عن رحلة' }) }, { Icon: ShieldCheck, label: tx(cl, { en: 'Sent to our team', es: 'Enviada a nuestro equipo', it: 'Inviata al nostro team', ar: 'تُرسل إلى فريقنا' }) }]} statsLabel={tx(cl, { en: 'Contact summary', es: 'Resumen de contacto', it: 'Riepilogo contatti', ar: 'ملخص التواصل' })} stats={[{ value: contactMethods.length, label: tx(cl, { en: 'Ways to connect', es: 'Formas de contactar', it: 'Modi per contattarci', ar: 'طرق للتواصل' }) }, { value: steps.length, label: tx(cl, { en: 'Planning steps', es: 'Pasos de planificación', it: 'Fasi di pianificazione', ar: 'خطوات للتخطيط' }) }]}/>
      <Breadcrumb items={[cms.text("presentation","description0",tx(cl, { en: 'Contact Us', es: 'Contáctanos', it: 'Contattaci', ar: 'تواصل معنا' }))]}/>

      <PresentationSection pageId="contact" id="contact-v2-trust"><section className="contact-v2-trust" aria-label={tx(cl, { en: 'Reasons to contact us', es: 'Por qué contactarnos', it: 'Perché contattarci', ar: 'مميزات التواصل معنا' })}>
        <div className="container">{cms.cards("contact-v2-trust").map(({id,title,Icon})=><span key={id}><Icon size={20}/><b>{title}</b></span>)}</div>
      </section></PresentationSection>

      <PresentationSection pageId="contact" id="contact-enquiry"><section id="contact-enquiry" className="container contact-v2-main">
        <div className="contact-v2-intro">
          <span className="eyebrow">{cms.text("contact-enquiry","description0",tx(cl, { en: 'Let us plan it together', es: 'Planifiquémoslo juntos', it: 'Pianifichiamolo insieme', ar: 'خلينا نخططها سوا' }))}</span>
          <h2>{cms.text("contact-enquiry","description1",tx(cl, { en: 'What kind of journey do you have in mind?', es: '¿Qué tipo de viaje tienes en mente?', it: 'Che tipo di viaggio hai in mente?', ar: 'إيه شكل الرحلة اللي في بالك؟' }))}</h2>
          <p>{cms.text("contact-enquiry","description2",tx(cl, { en: 'Whether it is one day in Cairo, a complete package, a Nile cruise, or an airport transfer, send us the starting point and let our team connect the details.', es: 'Ya sea un día en El Cairo, un paquete completo, un crucero por el Nilo o un traslado al aeropuerto: envíanos la idea inicial y nuestro equipo unirá los detalles.', it: 'Che si tratti di un giorno al Cairo, di un pacchetto completo, di una crociera sul Nilo o di un trasferimento aeroportuale: inviaci l\'idea di partenza e il nostro team collegherà i dettagli.', ar: 'سواء يوم واحد في القاهرة، باكدج كاملة، نايل كروز، أو استقبال من المطار، ابعتلنا الفكرة الأساسية وسيب التفاصيل علينا.' }))}</p>
          <div className="contact-v2-methods">
            {contactMethods.map(({ Icon, ...method }) => <a href={method.href} key={method.title} className="contact-v2-method" target={method.href.startsWith('https://wa.me/') ? '_blank' : undefined} rel={method.href.startsWith('https://wa.me/') ? 'noreferrer' : undefined}>
              <Icon size={22} />
              <span><small>{method.title}</small><strong>{method.value}</strong><em>{method.note}</em></span>
              <ArrowRight size={18} />
            </a>)}
          </div>
          <a className="contact-v2-address" href={brand.mapUrl || undefined} target={brand.mapUrl ? '_blank' : undefined} rel={brand.mapUrl ? 'noreferrer' : undefined}><MapPin size={22} /><span><small>{ex.addrT}</small><strong>{brand.address}</strong></span></a>
        </div>
        <div className="contact-v2-form-wrap">
          <header><span>{cms.text("contact-enquiry","description3",tx(cl, { en: 'Trip enquiry', es: 'Solicitud de viaje', it: 'Richiesta di viaggio', ar: 'طلب رحلة' }))}</span><h2>{cms.text("contact-enquiry","description4",tx(cl, { en: 'Start here.', es: 'Empieza aquí.', it: 'Inizia qui.', ar: 'ابدأ من هنا.' }))}</h2><p>{cms.text("contact-enquiry","description5",tx(cl, { en: 'The more you share, the more useful our first response can be.', es: 'Cuanto más nos cuentes, más útil será nuestra primera respuesta.', it: 'Più ci racconti, più utile sarà la nostra prima risposta.', ar: 'كل ما تحكيلنا أكتر، نقدر نساعدك بصورة أدق.' }))}</p></header>
          <ContactForm />
        </div>
      </section></PresentationSection>

      <PresentationSection pageId="contact" id="contact-v2-process"><section className="contact-v2-process">
        <div className="container">
          <header><span className="eyebrow">{cms.text("contact-v2-process","description0",tx(cl, { en: 'What happens next', es: 'Qué pasa después', it: 'Cosa succede dopo', ar: 'بعد ما تبعتلنا' }))}</span><h2>{cms.text("contact-v2-process","description1",tx(cl, { en: 'From first message to a clear travel plan.', es: 'Del primer mensaje a un plan de viaje claro.', it: 'Dal primo messaggio a un piano di viaggio chiaro.', ar: 'من أول رسالة لخطة رحلة واضحة.' }))}</h2></header>
          <div>{steps.map(([number, title, copy]) => <article key={number}><b>{number}</b><h3>{title}</h3><p>{copy}</p></article>)}</div>
        </div>
      </section></PresentationSection>

      <PresentationSection pageId="contact" id="contact-v2-faq"><section className="container contact-v2-faq">
        <div><span className="eyebrow">{cms.text("contact-v2-faq", "faqEyebrow", ex.faqTeaser)}</span><h2>{cms.text("contact-v2-faq","description0",tx(cl, { en: 'Before you get in touch.', es: 'Antes de contactarnos.', it: 'Prima di contattarci.', ar: 'قبل ما تراسلنا.' }))}</h2><p>{cms.text("contact-v2-faq","description1",tx(cl, { en: 'Quick answers to the questions that usually begin a journey.', es: 'Respuestas rápidas a las preguntas con las que suele empezar un viaje.', it: 'Risposte rapide alle domande con cui di solito inizia un viaggio.', ar: 'إجابات سريعة على الأسئلة اللي غالبًا بتبدأ بيها الرحلة.' }))}</p></div>
        <div>{contactFaqs.map(([question, answer]) => <details key={question}><summary>{question}<span>+</span></summary><p>{answer}</p></details>)}<CmsPublicLink className="text-link" href={cms.link("contact-v2-faq","links0","/faq")}>{cms.text("contact-v2-faq", "faqCta", ex.seeMore)} <ArrowRight size={15} /></CmsPublicLink></div>
      </section></PresentationSection>
    </PresentationOrder></main>
}

export function ContactForm() {
  const { locale } = useLocale()
  const ar = locale === 'ar'
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle')
  const [error, setError] = useState('')
  const submitting = useRef(false)
  const pendingRequest = useRef<{ payload: string; id: string } | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  })

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (status === 'error') setStatus('idle')
  }

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()
    if (submitting.current) return
    if (!formData.subject) {
      setStatus('error')
      setError(tx(locale, { en: 'Choose a trip type.', es: 'Elige un tipo de viaje.', it: 'Scegli un tipo di viaggio.', ar: 'اختر نوع الرحلة.' }))
      document.getElementById('contact-trip-type')?.focus()
      return
    }
    submitting.current = true
    setStatus('submitting')
    setError('')

    try {
      const payload = JSON.stringify({ ...formData, sourcePage: '/contact' })
      if (pendingRequest.current?.payload !== payload) {
        const bytes = crypto.getRandomValues(new Uint8Array(16))
        bytes[6] = (bytes[6] & 15) | 64
        bytes[8] = (bytes[8] & 63) | 128
        const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('')
        const id = `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`
        pendingRequest.current = { payload, id }
      }
      const res = await fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ ...formData, sourcePage: '/contact', requestId: pendingRequest.current.id }),
      })
      const data = await res.json().catch(() => null)
      const fallback = tx(locale, { en: 'Could not confirm your enquiry. Please retry without changing your details.', es: 'No se pudo confirmar tu consulta. Vuelve a intentarlo sin cambiar tus datos.', it: 'Impossibile confermare la tua richiesta. Riprova senza modificare i tuoi dati.', ar: 'تعذر تأكيد استفسارك. حاول مجددًا دون تغيير بياناتك.' })
      if (!res.ok) {
        throw new Error(customerErrorText(locale, data?.error, fallback))
      }
      if (typeof data?.enquiry?.publicId !== 'string' || !data.enquiry.publicId || typeof data.enquiry.createdAt !== 'string') throw new Error(fallback)
      pendingRequest.current = null
      setStatus('success')
      setFormData({ name: '', email: '', phone: '', subject: '', message: '' })
    } catch (err) {
      setStatus('error')
      setError(err instanceof Error ? err.message : tx(locale, { en: 'Could not submit enquiry. Please try again.', es: 'No se pudo enviar la consulta. Inténtalo de nuevo.', it: 'Impossibile inviare la richiesta. Riprova.', ar: 'تعذر إرسال الاستفسار. حاول مجددًا.' }))
    } finally {
      submitting.current = false
    }
  }

  if (status === 'success') {
    return (
      <div className="form-success contact-v2-success">
        <Check size={38} />
        <span>{tx(locale, { en: 'Enquiry sent', es: 'Consulta enviada', it: 'Richiesta inviata', ar: 'تم إرسال الاستفسار' })}</span>
        <h2>{tx(locale, { en: 'We have received your enquiry.', es: 'Hemos recibido tu consulta.', it: 'Abbiamo ricevuto la tua richiesta.', ar: 'لقد تلقينا استفسارك.' })}</h2>
        <p>{tx(locale, { en: 'Our team will review your details and get back to you shortly.', es: 'Nuestro equipo revisará tus datos y se pondrá en contacto contigo en breve.', it: 'Il nostro team esaminerà i tuoi dati e ti contatterà a breve.', ar: 'سيراجع فريقنا تفاصيلك وسيعاود الاتصال بك قريباً.' })}</p>
        <button type="button" className="outline-btn" onClick={() => setStatus('idle')}>
          {tx(locale, { en: 'Send another enquiry', es: 'Enviar otra consulta', it: 'Invia un\'altra richiesta', ar: 'إرسال استفسار آخر' })}
        </button>
      </div>
    )
  }

  const tripTypes = [
    { key: 'one-day', en: 'One-day tour', es: 'Excursión de un día', it: 'Tour di un giorno', ar: 'رحلة يوم واحد' },
    { key: 'multi-day', en: 'Multi-day package', es: 'Paquete de varios días', it: 'Pacchetto di più giorni', ar: 'باكدج متعددة الأيام' },
    { key: 'nile-cruise', en: 'Nile cruise', es: 'Crucero por el Nilo', it: 'Crociera sul Nilo', ar: 'نايل كروز' },
    { key: 'shore', en: 'Shore excursion', es: 'Excursión en tierra', it: 'Escursione a terra', ar: 'رحلة شاطئية' },
    { key: 'car', en: 'Car hire or transfer', es: 'Alquiler de coche o traslado', it: 'Noleggio auto o trasferimento', ar: 'تأجير عربية أو استقبال' },
    { key: 'custom', en: 'Custom journey', es: 'Viaje a medida', it: 'Viaggio su misura', ar: 'رحلة مصممة مخصوص' },
  ] as const

  return (
    <form className="contact-form contact-v2-form" onSubmit={handleSubmit}>
      <div className="form-grid">
        <label>
          {tx(locale, { en: 'Full name', es: 'Nombre completo', it: 'Nome completo', ar: 'الاسم بالكامل' })}
          <input
            required
            autoComplete="name"
            placeholder={tx(locale, { en: 'Your name', es: 'Tu nombre', it: 'Il tuo nome', ar: 'اسمك' })}
            value={formData.name}
            onChange={(e) => handleChange('name', e.target.value)}
            disabled={status === 'submitting'}
          />
        </label>
        <label>
          {tx(locale, { en: 'Email address', es: 'Correo electrónico', it: 'Indirizzo email', ar: 'البريد الإلكتروني' })}
          <input
            required
            type="email"
            autoComplete="email"
            placeholder="you@example.com"
            value={formData.email}
            onChange={(e) => handleChange('email', e.target.value)}
            disabled={status === 'submitting'}
          />
        </label>
        <label>
          {tx(locale, { en: 'Phone (optional)', es: 'Teléfono (opcional)', it: 'Telefono (opzionale)', ar: 'الهاتف (اختياري)' })}
          <input
            type="tel"
            autoComplete="tel"
            placeholder={tx(locale, { en: 'Your phone number', es: 'Tu número de teléfono', it: 'Il tuo numero di telefono', ar: 'رقم هاتفك' })}
            value={formData.phone}
            onChange={(e) => handleChange('phone', e.target.value)}
            disabled={status === 'submitting'}
          />
        </label>
        <label className="full">
          {tx(locale, { en: 'What can we help with?', es: '¿En qué podemos ayudarte?', it: 'Come possiamo aiutarti?', ar: 'نوع الرحلة' })}
          <SharedSelect
            id="contact-trip-type"
            value={formData.subject}
            onChange={(value) => handleChange('subject', value)}
            locale={locale}
            label={tx(locale, { en: 'What can we help with?', es: '¿En qué podemos ayudarte?', it: 'Come possiamo aiutarti?', ar: 'نوع الرحلة' })}
            placeholder={tx(locale, { en: 'Choose a trip type', es: 'Elige un tipo de viaje', it: 'Scegli un tipo di viaggio', ar: 'اختار نوع الرحلة' })}
            options={tripTypes.map((t) => ({ value: t.key, label: tx(locale, { en: t.en, es: t.es, it: t.it, ar: t.ar }) }))}
            disabled={status === 'submitting'}
            popupWidth="trigger"
          />
        </label>
        <label className="full">
          {tx(locale, { en: 'Tell us about your trip', es: 'Cuéntanos tu viaje', it: 'Raccontaci il tuo viaggio', ar: 'احكيلنا عن الرحلة' })}
          <textarea
            required
            placeholder={tx(locale, { en: 'Dates, group size, and the places or experiences you are interested in...', es: 'Fechas, tamaño del grupo y lugares o experiencias que te interesen...', it: 'Date, numero di partecipanti e luoghi o esperienze di interesse...', ar: 'المواعيد، عدد المسافرين، والأماكن أو التجارب اللي مهتم بيها...' })}
            value={formData.message}
            onChange={(e) => handleChange('message', e.target.value)}
            disabled={status === 'submitting'}
          />
        </label>
      </div>
      {status === 'error' && (
        <p className="contact-v2-form-error" role="alert">
          <CircleAlert size={14} /> {error}
        </p>
      )}
      <button className="primary-btn" type="submit" disabled={status === 'submitting'}>
        {status === 'submitting' ? (
          <>
            <span className="spinner" style={{ display: 'inline-block', animation: 'spin 1s linear infinite', marginRight: 8 }}><Send size={17} /></span>
            {tx(locale, { en: 'Sending...', es: 'Enviando...', it: 'Invio...', ar: 'جاري الإرسال...' })}
          </>
        ) : (
          <>
            {tx(locale, { en: 'Send enquiry', es: 'Enviar consulta', it: 'Invia richiesta', ar: 'إرسال الاستفسار' })} <Send size={17} />
          </>
        )}
      </button>
      <small className="contact-v2-form-note"><ShieldCheck size={14} />{tx(locale, { en: 'Your details are sent securely to our team.', es: 'Tus datos se envían de forma segura a nuestro equipo.', it: 'I tuoi dati vengono inviati in modo sicuro al nostro team.', ar: 'ترسل بياناتك بأمان إلى فريقنا.' })}</small>
    </form>
  )
}

export function CarsPage() {
  return <SiteShell><CarsPageContent /></SiteShell>
}

function CarsPageContent() {
  const cms = usePresentation("cars")

  const { locale } = useLocale()
  const ar = locale === 'ar'
  const liveCars = useDbCars(cars).filter((car) => car.isPublished !== false)
  const featured = liveCars[2] ?? liveCars[0]
  const maxSeats = liveCars.length ? Math.max(...liveCars.map((car) => Number.parseInt(car.seats, 10) || 0)) : 0
  if (!featured) return <main><EmptyFleetHero /><div className="container"><PresentationSection pageId="cars" id="content"><section id="fleet" className="section"><div className="section-heading"><span className="eyebrow">{cms.text("content","description0",tx(locale, { en: 'Our fleet', es: 'Nuestra flota', it: 'La nostra flotta', ar: 'الأسطول' }))}</span><h2>{cms.text("content","description1",tx(locale, { en: 'No vehicles listed right now', es: 'Sin vehículos disponibles ahora mismo', it: 'Nessun veicolo disponibile al momento', ar: 'لا توجد سيارات متاحة حاليًا' }))}</h2><p>{cms.text("content","description2",tx(locale, { en: 'Check back later or contact us and we will help arrange your transfer.', es: 'Vuelve más tarde o contáctanos y te ayudaremos a organizar tu traslado.', it: 'Torna più tardi o contattaci: ti aiuteremo a organizzare il trasferimento.', ar: 'عُد لاحقًا أو تواصل معنا وسنساعدك في ترتيب انتقالك.' }))}</p><CmsPublicLink href={cms.link("content","links0","/contact")} className="primary-btn">{cms.text("content","description3",tx(locale, { en: 'Contact us', es: 'Contáctanos', it: 'Contattaci', ar: 'تواصل معنا' }))} <ArrowRight size={16} /></CmsPublicLink></div></section></PresentationSection></div></main>
  return <main>
    <PageShowcaseHero image={featured.image} eyebrow={tx(locale, { en: 'Private drivers & modern fleet', es: 'Conductores privados y flota moderna', it: 'Autisti privati e flotta moderna', ar: 'سائقون خصوصيون وأسطول حديث' })} title={tx(locale, { en: 'Move through Egypt with ease', es: 'Muévete por Egipto con total comodidad', it: 'Muoviti in Egitto in totale comfort', ar: 'تنقّل في مصر براحة تامة' })} intro={tx(locale, { en: 'Airport pickups, day trips, and multi-city routes with a private driver and modern air-conditioned cars.', es: 'Recogidas en el aeropuerto, excursiones de un día y rutas entre ciudades con conductor privado y coches modernos con aire acondicionado.', it: 'Trasferimenti aeroportuali, gite giornaliere e itinerari tra più città con autista privato e auto moderne climatizzate.', ar: 'استقبال من المطار ورحلات يومية وخطوط بين المدن مع سائق خاص وسيارات حديثة مكيفة.' })} primaryLabel={tx(locale, { en: 'Explore the fleet', es: 'Descubre la flota', it: 'Scopri la flotta', ar: 'استكشف الأسطول' })} primaryHref="#fleet" secondaryLabel={tx(locale, { en: 'Request this vehicle', es: 'Solicita este vehículo', it: 'Richiedi questo veicolo', ar: 'اطلب هذه السيارة' })} secondaryHref={`/rent-car/request?vehicle=${featured.slug}`} railLabel={tx(locale, { en: 'Featured vehicle', es: 'Vehículo destacado', it: 'Veicolo in evidenza', ar: 'سيارة مميزة' })} railTitle={featured.title} railHref={`/rent-car/request?vehicle=${featured.slug}`} railMeta={[{ Icon: Users, label: featured.seats }, { Icon: CarFront, label: featured.transmission }]} statsLabel={tx(locale, { en: 'Fleet summary', es: 'Resumen de la flota', it: 'Riepilogo flotta', ar: 'ملخص الأسطول' })} stats={[{ value: liveCars.length, label: tx(locale, { en: 'Fleet choices', es: 'Opciones de vehículos', it: 'Scelte di veicoli', ar: 'خيارات سيارات' }) }, { value: maxSeats, label: tx(locale, { en: 'Seats maximum', es: 'Asientos máximos', it: 'Posti massimi', ar: 'مقعدًا كحد أقصى' }) }]}/>
    <div className="container">
    <PresentationSection pageId="cars" id="fleet"><section id="fleet" className="section">
      <div className="section-heading inline-heading"><div><span className="eyebrow">{cms.text("fleet","description0",tx(locale, { en: 'Our fleet', es: 'Nuestra flota', it: 'La nostra flotta', ar: 'الأسطول' }))}</span><h2>{cms.text("fleet","description1",tx(locale, { en: 'Comfort for every kind of journey', es: 'Comodidad para cada tipo de viaje', it: 'Comfort per ogni tipo di viaggio', ar: 'راحة لكل نوع رحلة' }))}</h2></div><CmsPublicLink className="text-link" href={cms.link("fleet","links0","/rent-car/request")}>{cms.text("fleet","description2",tx(locale, { en: 'Need a custom vehicle?', es: '¿Necesitas un vehículo a medida?', it: 'Serve un veicolo su misura?', ar: 'هل تحتاج إلى سيارة مخصصة؟' }))} <ArrowRight size={15} /></CmsPublicLink></div>
      <div className="fleet-grid">{liveCars.map((car) => <CarCard key={car.slug} car={car} />)}</div>
    </section></PresentationSection>
    </div>
  </main>
}

export function CarCard({ car }: { car: Car }) {
  const { currency, locale } = useLocale()
  const ar = locale === 'ar'
  return <article className="fleet-card">
    <div className="fleet-card-img">
      <img
        src={car.image}
        alt={car.title}
        loading="lazy"
        onError={(event) => {
          event.currentTarget.onerror = null
          event.currentTarget.src = '/fleet-vehicle-fallback.svg'
        }}
      />
      <span className="fleet-price-badge">{tx(locale, { en: 'Price on request', es: 'Precio a consultar', it: 'Prezzo su richiesta', ar: 'السعر عند الطلب' })}</span>
    </div>
    <div className="fleet-card-body">
      <div className="fleet-specs"><span><Users size={14} />{car.seats}</span><span><CarFront size={14} />{vehicleTransmissionLabel(car.transmission, locale)}</span></div>
      <h3>{car.title}</h3>
      <p>{car.copy}</p>
      {car.credit && <small className="fleet-credit"><a href={car.credit.url} target="_blank" rel="noreferrer">{car.credit.label}</a></small>}
      <Link href={`/rent-car/request?vehicle=${car.slug}`} className="primary-btn fleet-cta">{tx(locale, { en: 'Request this car', es: 'Solicita este coche', it: 'Richiedi quest\'auto', ar: 'اطلب هذه السيارة' })} <ArrowRight size={16} /></Link>
    </div>
  </article>
}

type CarRequestValues = { vehicleSlug: string; tripType: '' | 'One Way' | 'Round Trip'; pickup: string; dropoff: string; pickupLocationSlug: string; dropoffLocationSlug: string; pickupTime: string; returnTime: string; pickupDate: string; returnDate: string; passengers: string; fullName: string; email: string; phone: string; notes: string }

/** Select sentinel: "no structured location  -  free-text address". */
const CAR_OTHER_LOCATION = '__other__'

type CarLocationOption = { id: string; slug: string; nameEn: string; nameEs: string; nameIt: string; nameAr: string; kind: string }

function carLocationKindLabel(kind: string, locale: Locale): string {
  const label: Record<string, { en: string; es: string; it: string; ar: string }> = {
    AIRPORT: { en: 'Airport', es: 'Aeropuerto', it: 'Aeroporto', ar: 'مطار' },
    HOTEL: { en: 'Hotel', es: 'Hotel', it: 'Hotel', ar: 'فندق' },
    CITY: { en: 'City', es: 'Ciudad', it: 'Città', ar: 'مدينة' },
    CUSTOM: { en: 'Custom', es: 'Personalizado', it: 'Personalizzato', ar: 'مخصص' },
  }
  const entry = label[kind] ?? label.CUSTOM
  return tx(locale, entry)
}

function carLocationName(item: CarLocationOption, locale: Locale): string {
  const name = tx(locale, { en: item.nameEn, es: item.nameEs, it: item.nameIt, ar: item.nameAr })
  return name || item.nameEn
}

/** Display name for the summary card: resolved location name, custom text, or the Not set/placeholder fallback. */
function carLocationDisplayName(slug: string, customText: string, list: CarLocationOption[], locale: Locale, fallback: string): string {
  if (slug === '' || slug === CAR_OTHER_LOCATION) {
    const text = customText.trim()
    return text !== '' ? text : fallback
  }
  const item = list.find((entry) => entry.slug === slug)
  return item ? carLocationName(item, locale) : fallback
}

/** Joined chauffeur locations  -  public API; on failure use the legacy free-text flow. */
function useCarLocations() {
  const [locations, setLocations] = useState<CarLocationOption[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [version, setVersion] = useState(0)
  useEffect(() => {
    let cancelled = false
    setLoading(true); setError(false)
    fetch('/api/rent-car/locations', { credentials: 'same-origin' })
      .then(async (res) => {
        if (!res.ok) throw new Error('Locations unavailable')
        const data = (await res.json()) as { locations?: CarLocationOption[] }
        if (!cancelled) setLocations(Array.isArray(data.locations) ? data.locations : [])
      })
      .catch(() => { if (!cancelled) setError(true) })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [version])
  return { locations, loading, error, retry: () => setVersion(value => value + 1) }
}


function carTodayLocal(): string {
  const now = new Date()
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`
}

function focusCarField(id: string) {
  const el = document.getElementById(id)
  if (el) {
    if (!el.hasAttribute('tabindex') && !/^(INPUT|SELECT|TEXTAREA|BUTTON|A)$/.test(el.tagName)) el.setAttribute('tabindex', '-1')
    el.focus({ preventScroll: false })
    el.scrollIntoView({ block: 'center', behavior: 'smooth' })
  }
}

export function CarRequestForm({ values, errors, summary, submitting, editing, locations, onChange, onSubmit }: { values: CarRequestValues; errors: CarFieldErrors; summary: string; submitting: boolean; editing: boolean; locations: CarLocationOption[]; onChange: (patch: Partial<CarRequestValues>) => void; onSubmit: (e: React.FormEvent) => void }) {
  const { locale } = useLocale()
  const ar = locale === 'ar'
  const fleet = useDbCarsStatus()
  const liveCars = fleet.data ?? []
  const today = carTodayLocal()
  const errText = (field: keyof CarFieldErrors): string => {
    const code = errors[field]
    if (!code) return ''
    if (field === 'passengers' && values.passengers.trim() === '') return tx(locale, { en: 'Enter the number of passengers.', es: 'Indica el número de pasajeros.', it: 'Indica il numero di passeggeri.', ar: 'أدخل عدد الركاب.' })
    const en: Record<string, string> = {
      vehicle: code === 'required' ? 'Select a vehicle.' : 'Select a vehicle from the fleet list.',
      tripType: 'Choose One Way or Round Trip.',
      pickup: code === 'required' ? 'Enter the pick-up location.' : `Pick-up location must be ${CAR_LOCATION_MAX} characters or fewer.`,
      dropoff: code === 'required' ? 'Enter the drop-off location.' : `Drop-off location must be ${CAR_LOCATION_MAX} characters or fewer.`,
      pickupDate: code === 'required' ? 'Enter your preferred pick-up date.' : 'Enter a valid preferred pick-up date (today or later).',
      returnDate: code === 'required' ? 'Enter your preferred return date.' : 'Enter a valid preferred return date on or after the pick-up date.',
      passengers: 'Passengers must be a whole number from 1 to 50.',
      pickupTime: 'Enter a valid pick-up time (HH:MM).',
      returnTime: 'Enter a valid return time (HH:MM).',
      name: code === 'required' ? 'Enter your full name.' : 'Enter a name with at least 2 letters.',
      email: code === 'required' ? 'Enter your email address.' : 'Enter a valid email address (name@example.com).',
      phone: code === 'required' ? 'Enter your phone number.' : 'Enter a valid phone number (at least 7 digits).',
      notes: `Notes must be ${CAR_NOTE_MAX} characters or fewer.`,
    }
    const arText: Record<string, string> = {
      vehicle: code === 'required' ? 'اختر السيارة.' : 'اختر سيارة من قائمة الأسطول.',
      tripType: 'اختر ذهاب فقط أو ذهاب وعودة.',
      pickup: code === 'required' ? 'أدخل مكان الاستلام.' : `يجب ألا يتجاوز مكان الاستلام ${CAR_LOCATION_MAX} حرفًا.`,
      dropoff: code === 'required' ? 'أدخل مكان الوصول.' : `يجب ألا يتجاوز مكان الوصول ${CAR_LOCATION_MAX} حرفًا.`,
      pickupDate: code === 'required' ? 'أدخل تاريخ الاستلام المفضل.' : 'أدخل تاريخ استلام مفضلًا صالحًا (اليوم أو بعده).',
      returnDate: code === 'required' ? 'أدخل تاريخ العودة المفضل.' : 'أدخل تاريخ عودة مفضلًا صالحًا في تاريخ الاستلام أو بعده.',
      passengers: 'يجب أن يكون عدد الركاب رقمًا صحيحًا من 1 إلى 50.',
      pickupTime: 'أدخل وقت استلام صالحًا (HH:MM).',
      returnTime: 'أدخل وقت عودة صالحًا (HH:MM).',
      name: code === 'required' ? 'أدخل اسمك الكامل.' : 'أدخل اسمًا من حرفين على الأقل.',
      email: code === 'required' ? 'أدخل بريدك الإلكتروني.' : 'أدخل بريدًا إلكترونيًا صالحًا (name@example.com).',
      phone: code === 'required' ? 'أدخل رقم هاتفك.' : 'أدخل رقم هاتف صالحًا (7 أرقام على الأقل).',
      notes: `يجب ألا تتجاوز الملاحظات ${CAR_NOTE_MAX} حرف.`,
    }
    const esText: Record<string, string> = {
      vehicle: code === 'required' ? 'Selecciona un vehículo.' : 'Selecciona un vehículo de la lista de la flota.',
      tripType: 'Elige Solo ida o Ida y vuelta.',
      pickup: code === 'required' ? 'Indica el lugar de recogida.' : `El lugar de recogida debe tener ${CAR_LOCATION_MAX} caracteres como máximo.`,
      dropoff: code === 'required' ? 'Indica el lugar de entrega.' : `El lugar de entrega debe tener ${CAR_LOCATION_MAX} caracteres como máximo.`,
      pickupDate: code === 'required' ? 'Indica la fecha de recogida preferida.' : 'Indica una fecha de recogida válida (hoy o posterior).',
      returnDate: code === 'required' ? 'Indica la fecha de regreso preferida.' : 'Indica una fecha de regreso válida igual o posterior a la de recogida.',
      passengers: 'El número de pasajeros debe ser un número entero entre 1 y 50.',
      pickupTime: 'Indica una hora de recogida válida (HH:MM).',
      returnTime: 'Indica una hora de regreso válida (HH:MM).',
      name: code === 'required' ? 'Indica tu nombre completo.' : 'Indica un nombre con al menos 2 letras.',
      email: code === 'required' ? 'Indica tu correo electrónico.' : 'Indica un correo válido (nombre@ejemplo.com).',
      phone: code === 'required' ? 'Indica tu número de teléfono.' : 'Indica un teléfono válido (al menos 7 dígitos).',
      notes: `Las notas deben tener ${CAR_NOTE_MAX} caracteres como máximo.`,
    }
    const itText: Record<string, string> = {
      vehicle: code === 'required' ? 'Seleziona un veicolo.' : 'Seleziona un veicolo dalla lista della flotta.',
      tripType: 'Scegli Solo andata o Andata e ritorno.',
      pickup: code === 'required' ? 'Indica il luogo di ritiro.' : `Il luogo di ritiro deve avere al massimo ${CAR_LOCATION_MAX} caratteri.`,
      dropoff: code === 'required' ? 'Indica il luogo di riconsegna.' : `Il luogo di riconsegna deve avere al massimo ${CAR_LOCATION_MAX} caratteri.`,
      pickupDate: code === 'required' ? 'Indica la data di ritiro preferita.' : 'Indica una data di ritiro valida (oggi o successiva).',
      returnDate: code === 'required' ? 'Indica la data di ritorno preferita.' : 'Indica una data di ritorno valida pari o successiva a quella di ritiro.',
      passengers: 'Il numero di passeggeri deve essere un intero da 1 a 50.',
      pickupTime: 'Indica un orario di ritiro valido (HH:MM).',
      returnTime: 'Indica un orario di ritorno valido (HH:MM).',
      name: code === 'required' ? 'Indica il tuo nome completo.' : 'Indica un nome di almeno 2 lettere.',
      email: code === 'required' ? 'Indica il tuo indirizzo email.' : 'Indica un indirizzo email valido (nome@esempio.com).',
      phone: code === 'required' ? 'Indica il tuo numero di telefono.' : 'Indica un numero valido (almeno 7 cifre).',
      notes: `Le note devono avere al massimo ${CAR_NOTE_MAX} caratteri.`,
    }
    return tx(locale, { en: en[field], es: esText[field], it: itText[field], ar: arText[field] })
  }
  return <form className="contact-form car-request-form" onSubmit={onSubmit} noValidate>
    <fieldset aria-label={tx(locale, { en: 'Transfer request details', es: 'Datos de la solicitud de traslado', it: 'Dettagli della richiesta di trasferimento' })} disabled={submitting} style={{ border: 0, margin: 0, padding: 0, minWidth: 0 }}>
    {summary !== '' && <p className="co-error" role="alert" style={{ display: 'flex', alignItems: 'center', gap: 8, margin: '0 0 6px' }}><CircleAlert size={15} />{summary}</p>}
    <div className="form-grid">
      <label className="full" htmlFor="car-vehicle"><span className="car-field-label">{tx(locale, { en: 'Vehicle', es: 'Vehículo', it: 'Veicolo', ar: 'السيارة' })} <em className="req" aria-hidden="true">*</em></span><SharedSelect id="car-vehicle" value={values.vehicleSlug} onChange={(next) => onChange({ vehicleSlug: next })} locale={locale} invalid={Boolean(errors.vehicle)} describedBy={errors.vehicle ? 'car-vehicle-error' : undefined} options={[{ value: '', label: tx(locale, { en: 'Select a vehicle', es: 'Selecciona un vehículo', it: 'Seleziona un veicolo', ar: 'اختر السيارة' }) }, ...liveCars.filter((c) => c.isPublished !== false).map((c) => ({ value: c.slug, label: `${c.title} · ${c.seats}` }))]} />{errors.vehicle && <span className="field-error" id="car-vehicle-error" role="alert">{errText('vehicle')}</span>}</label>
      <div className="full req-trip-type"><span id="req-trip-label">{tx(locale, { en: 'Trip type', es: 'Tipo de viaje', it: 'Tipo di viaggio', ar: 'نوع الرحلة' })} <em className="req" aria-hidden="true">*</em></span><div role="radiogroup" aria-labelledby="req-trip-label" aria-describedby={errors.tripType ? 'car-triptype-error' : undefined}>{(['One Way', 'Round Trip'] as const).map((opt) => <button key={opt} type="button" role="radio" aria-checked={values.tripType === opt} tabIndex={values.tripType === opt || (!values.tripType && opt === 'One Way') ? 0 : -1} onKeyDown={event => { const next = carTripTypeForKey(values.tripType, event.key); if (next) { event.preventDefault(); onChange({ tripType: next }); event.currentTarget.parentElement?.querySelectorAll<HTMLButtonElement>('button')[next === 'One Way' ? 0 : 1]?.focus() } }} className={values.tripType === opt ? 'active' : ''} onClick={() => onChange({ tripType: opt })}>{opt === 'One Way' ? (tx(locale, { en: 'One Way', es: 'Solo ida', it: 'Solo andata', ar: 'ذهاب فقط' })) : (tx(locale, { en: 'Round Trip', es: 'Ida y vuelta', it: 'Andata e ritorno', ar: 'ذهاب وعودة' }))}</button>)}</div>{errors.tripType && <span className="field-error" id="car-triptype-error" role="alert">{errText('tripType')}</span>}</div>
      {locations.length > 0 ? <>
        <div className="car-location-field"><label htmlFor="car-pickup"><span className="car-field-label">{tx(locale, { en: 'Pick-up location', es: 'Lugar de recogida', it: 'Luogo di ritiro', ar: 'مكان الاستلام' })} <em className="req" aria-hidden="true">*</em></span><SharedSelect id="car-pickup" value={values.pickupLocationSlug} onChange={(next) => onChange({ pickupLocationSlug: next })} locale={locale} invalid={Boolean(errors.pickup)} describedBy={errors.pickup ? 'car-pickup-error' : undefined} options={[{ value: '', label: tx(locale, { en: 'Select a pick-up location', es: 'Selecciona un lugar de recogida', it: 'Seleziona il luogo di ritiro', ar: 'اختر مكان الاستلام' }) }, ...locations.map((item) => ({ value: item.slug, label: `${carLocationName(item, locale)}${item.kind !== 'CUSTOM' ? ` · ${carLocationKindLabel(item.kind, locale)}` : ''}` })), { value: CAR_OTHER_LOCATION, label: tx(locale, { en: 'Other  -  enter address manually', es: 'Otro  -  introducir dirección manualmente', it: 'Altro  -  inserisci l\'indirizzo manualmente', ar: 'أخرى  -  أدخل العنوان يدويًا' }) }]} />{errors.pickup && <span className="field-error" id="car-pickup-error" role="alert">{errText('pickup')}</span>}</label>
        {values.pickupLocationSlug === '' ? <label className="full" htmlFor="car-pickup-custom"><span className="car-field-label">{tx(locale, { en: 'Pick-up address (custom)', es: 'Dirección de recogida (personalizada)', it: 'Indirizzo di ritiro (personalizzato)', ar: 'عنوان الاستلام (مخصص)' })}</span><input id="car-pickup-custom" placeholder={tx(locale, { en: 'Airport, hotel, or city', es: 'Aeropuerto, hotel o ciudad', it: 'Aeroporto, hotel o città', ar: 'المطار أو الفندق أو المدينة' })} maxLength={CAR_LOCATION_MAX} value={values.pickup} onChange={(e) => onChange({ pickup: e.target.value })} /></label> : null}
        </div><div className="car-location-field"><label htmlFor="car-dropoff"><span className="car-field-label">{tx(locale, { en: 'Drop-off location', es: 'Lugar de entrega', it: 'Luogo di riconsegna', ar: 'مكان الوصول' })} <em className="req" aria-hidden="true">*</em></span><SharedSelect id="car-dropoff" value={values.dropoffLocationSlug} onChange={(next) => onChange({ dropoffLocationSlug: next })} locale={locale} invalid={Boolean(errors.dropoff)} describedBy={errors.dropoff ? 'car-dropoff-error' : undefined} options={[{ value: '', label: tx(locale, { en: 'Select a drop-off location', es: 'Selecciona un lugar de entrega', it: 'Seleziona il luogo di riconsegna', ar: 'اختر مكان الوصول' }) }, ...locations.map((item) => ({ value: item.slug, label: `${carLocationName(item, locale)}${item.kind !== 'CUSTOM' ? ` · ${carLocationKindLabel(item.kind, locale)}` : ''}` })), { value: CAR_OTHER_LOCATION, label: tx(locale, { en: 'Other  -  enter address manually', es: 'Otro  -  introducir dirección manualmente', it: 'Altro  -  inserisci l\'indirizzo manualmente', ar: 'أخرى  -  أدخل العنوان يدويًا' }) }]} />{errors.dropoff && <span className="field-error" id="car-dropoff-error" role="alert">{errText('dropoff')}</span>}</label>
        {values.dropoffLocationSlug === '' ? <label className="full" htmlFor="car-dropoff-custom"><span className="car-field-label">{tx(locale, { en: 'Drop-off address (custom)', es: 'Dirección de entrega (personalizada)', it: 'Indirizzo di riconsegna (personalizzato)', ar: 'عنوان الوصول (مخصص)' })}</span><input id="car-dropoff-custom" placeholder={tx(locale, { en: 'Where are you going?', es: '¿A dónde vas?', it: 'Dove sei diretto?', ar: 'إلى أين تريد الذهاب؟' })} maxLength={CAR_LOCATION_MAX} value={values.dropoff} onChange={(e) => onChange({ dropoff: e.target.value })} /></label> : null}
        </div>
      </>
      : <>
        <label htmlFor="car-pickup"><span className="car-field-label">{tx(locale, { en: 'Pick-up location', es: 'Lugar de recogida', it: 'Luogo di ritiro', ar: 'مكان الاستلام' })} <em className="req" aria-hidden="true">*</em></span><input id="car-pickup" required placeholder={tx(locale, { en: 'Airport, hotel, or city', es: 'Aeropuerto, hotel o ciudad', it: 'Aeroporto, hotel o città', ar: 'المطار أو الفندق أو المدينة' })} maxLength={CAR_LOCATION_MAX} value={values.pickup} onChange={(e) => onChange({ pickup: e.target.value })} aria-invalid={Boolean(errors.pickup)} aria-describedby={errors.pickup ? 'car-pickup-error' : undefined} />{errors.pickup && <span className="field-error" id="car-pickup-error" role="alert">{errText('pickup')}</span>}</label>
        <label htmlFor="car-dropoff"><span className="car-field-label">{tx(locale, { en: 'Drop-off location', es: 'Lugar de entrega', it: 'Luogo di riconsegna', ar: 'مكان الوصول' })} <em className="req" aria-hidden="true">*</em></span><input id="car-dropoff" required placeholder={tx(locale, { en: 'Where are you going?', es: '¿A dónde vas?', it: 'Dove sei diretto?', ar: 'إلى أين تريد الذهاب؟' })} maxLength={CAR_LOCATION_MAX} value={values.dropoff} onChange={(e) => onChange({ dropoff: e.target.value })} aria-invalid={Boolean(errors.dropoff)} aria-describedby={errors.dropoff ? 'car-dropoff-error' : undefined} />{errors.dropoff && <span className="field-error" id="car-dropoff-error" role="alert">{errText('dropoff')}</span>}</label>
      </>}
      <label htmlFor="car-pickup-time"><span className="car-field-label">{tx(locale, { en: 'Pick-up time (optional)', es: 'Hora de recogida (opcional)', it: 'Orario di ritiro (facoltativo)', ar: 'وقت الاستلام (اختياري)' })}</span><input id="car-pickup-time" type="time" dir="ltr" value={values.pickupTime} onChange={(e) => onChange({ pickupTime: e.target.value.slice(0, 5) })} aria-invalid={Boolean(errors.pickupTime)} aria-describedby={errors.pickupTime ? 'car-pickup-time-error' : undefined} />{errors.pickupTime && <span className="field-error" id="car-pickup-time-error" role="alert">{errText('pickupTime')}</span>}</label>
      {values.tripType === 'Round Trip' && <label htmlFor="car-return-time"><span className="car-field-label">{tx(locale, { en: 'Return time (optional)', es: 'Hora de regreso (opcional)', it: 'Orario di ritorno (facoltativo)', ar: 'وقت العودة (اختياري)' })}</span><input id="car-return-time" type="time" dir="ltr" value={values.returnTime} onChange={(e) => onChange({ returnTime: e.target.value.slice(0, 5) })} aria-invalid={Boolean(errors.returnTime)} aria-describedby={errors.returnTime ? 'car-return-time-error' : undefined} />{errors.returnTime && <span className="field-error" id="car-return-time-error" role="alert">{errText('returnTime')}</span>}</label>}
      <label htmlFor="car-pickup-date"><span className="car-field-label">{tx(locale, { en: 'Preferred pick-up date', es: 'Fecha de recogida preferida', it: 'Data di ritiro preferita', ar: 'تاريخ الاستلام المفضل' })} <em className="req" aria-hidden="true">*</em></span><DateInput id="car-pickup-date" required min={today} dir="ltr" value={values.pickupDate} onChange={(e) => onChange({ pickupDate: e.target.value })} aria-invalid={Boolean(errors.pickupDate)} aria-describedby={errors.pickupDate ? 'car-pickup-date-error' : undefined} />{errors.pickupDate && <span className="field-error" id="car-pickup-date-error" role="alert">{errText('pickupDate')}</span>}</label>
      {values.tripType === 'Round Trip'
        ? <label htmlFor="car-return-date"><span className="car-field-label">{tx(locale, { en: 'Preferred return date', es: 'Fecha de regreso preferida', it: 'Data di ritorno preferita', ar: 'تاريخ العودة المفضل' })} <em className="req" aria-hidden="true">*</em></span><DateInput id="car-return-date" required min={values.pickupDate || today} dir="ltr" value={values.returnDate} onChange={(e) => onChange({ returnDate: e.target.value })} aria-invalid={Boolean(errors.returnDate)} aria-describedby={errors.returnDate ? 'car-return-date-error' : undefined} />{errors.returnDate && <span className="field-error" id="car-return-date-error" role="alert">{errText('returnDate')}</span>}</label>
        : <label htmlFor="car-passengers"><span className="car-field-label">{tx(locale, { en: 'Passengers', es: 'Pasajeros', it: 'Passeggeri', ar: 'عدد الركاب' })} <em className="req" aria-hidden="true">*</em></span><input id="car-passengers" required type="number" min="1" max="50" placeholder="2" dir="ltr" value={values.passengers} onChange={(e) => onChange({ passengers: e.target.value })} aria-invalid={Boolean(errors.passengers)} aria-describedby={errors.passengers ? 'car-passengers-error' : undefined} />{errors.passengers && <span className="field-error" id="car-passengers-error" role="alert">{errText('passengers')}</span>}</label>}
      {values.tripType === 'Round Trip' && <label className="full" htmlFor="car-passengers-rt"><span className="car-field-label">{tx(locale, { en: 'Passengers', es: 'Pasajeros', it: 'Passeggeri', ar: 'عدد الركاب' })} <em className="req" aria-hidden="true">*</em></span><input id="car-passengers-rt" required type="number" min="1" max="50" placeholder="2" dir="ltr" value={values.passengers} onChange={(e) => onChange({ passengers: e.target.value })} aria-invalid={Boolean(errors.passengers)} aria-describedby={errors.passengers ? 'car-passengers-error' : undefined} />{errors.passengers && <span className="field-error" id="car-passengers-error" role="alert">{errText('passengers')}</span>}</label>}
      <label className="full" htmlFor="car-name"><span className="car-field-label">{tx(locale, { en: 'Full name', es: 'Nombre completo', it: 'Nome completo', ar: 'الاسم الكامل' })} <em className="req" aria-hidden="true">*</em></span><input id="car-name" required placeholder={tx(locale, { en: 'Your full name', es: 'Tu nombre completo', it: 'Il tuo nome completo', ar: 'اكتب اسمك الكامل' })} maxLength={80} autoComplete="name" value={values.fullName} onChange={(e) => onChange({ fullName: e.target.value })} aria-invalid={Boolean(errors.name)} aria-describedby={errors.name ? 'car-name-error' : undefined} />{errors.name && <span className="field-error" id="car-name-error" role="alert">{errText('name')}</span>}</label>
      <label htmlFor="car-email"><span className="car-field-label">{tx(locale, { en: 'Email', es: 'Correo electrónico', it: 'Email', ar: 'البريد الإلكتروني' })} <em className="req" aria-hidden="true">*</em></span><input id="car-email" required type="email" placeholder="you@example.com" maxLength={120} autoComplete="email" dir="ltr" value={values.email} onChange={(e) => onChange({ email: e.target.value })} aria-invalid={Boolean(errors.email)} aria-describedby={errors.email ? 'car-email-error' : undefined} />{errors.email && <span className="field-error" id="car-email-error" role="alert">{errText('email')}</span>}</label>
      <label htmlFor="car-phone"><span className="car-field-label">{tx(locale, { en: 'Phone', es: 'Teléfono', it: 'Telefono', ar: 'رقم الهاتف' })} <em className="req" aria-hidden="true">*</em></span><InternationalPhoneInput id="car-phone" required value={values.phone} onChange={(phone) => onChange({ phone })} locale={locale} invalid={Boolean(errors.phone)} describedBy={errors.phone ? 'car-phone-error' : undefined} />{errors.phone && <span className="field-error" id="car-phone-error" role="alert">{errText('phone')}</span>}</label>
      <label className="full" htmlFor="car-notes"><span className="car-field-label">{tx(locale, { en: 'Notes (optional)', es: 'Notas (opcional)', it: 'Note (facoltativo)', ar: 'ملاحظات (اختياري)' })}</span><textarea id="car-notes" placeholder={tx(locale, { en: 'Tell us about your route', es: 'Cuéntanos tu ruta', it: 'Raccontaci il tuo itinerario', ar: 'حدثنا عن خط سيرك' })} maxLength={CAR_NOTE_MAX + 1} value={values.notes} onChange={(e) => onChange({ notes: e.target.value })} aria-invalid={Boolean(errors.notes)} aria-describedby={errors.notes ? 'car-notes-error' : 'car-notes-hint'} />{errors.notes && <span className="field-error" id="car-notes-error" role="alert">{errText('notes')}</span>}<small id="car-notes-hint" style={{ color: 'var(--muted)', fontWeight: 500 }}>{values.notes.length}/{CAR_NOTE_MAX}</small></label>
    </div>
    <button className="primary-btn" type="submit" disabled={submitting || fleet.loading || !!fleet.error || !liveCars.some(car => car.isPublished !== false)}>{submitting ? (tx(locale, { en: 'Submitting…', es: 'Enviando…', it: 'Invio…', ar: 'جارٍ الإرسال…' })) : editing ? (tx(locale, { en: 'Save changes', es: 'Guardar cambios', it: 'Salva modifiche', ar: 'حفظ التعديلات' })) : (tx(locale, { en: 'Submit request', es: 'Enviar solicitud', it: 'Invia richiesta', ar: 'إرسال الطلب' }))} <ArrowRight size={17} /></button>
    </fieldset>
  </form>
}

export function CarRequestPage() {
  return <SiteShell><Suspense><CarRequestContent /></Suspense></SiteShell>
}

function CarRequestContent() {
  const brand = useBrandSettings()
  const params = useSearchParams()
  const initial = parseCarRequestQuery(params)
  const rawVehicleSlug = (() => {
    const raw = (params.get('vehicle') ?? '').trim().slice(0, 80)
    return /^[a-z0-9-]{1,80}$/.test(raw) ? raw : ''
  })()
  const { currency, locale } = useLocale()
  const ar = locale === 'ar'
  const { user: sessionUser } = useCurrentUser()
  const fleet = useDbCarsStatus()
  const liveCars = fleet.data ?? []
  const [values, setValues] = useState<CarRequestValues>({ vehicleSlug: initial.vehicleSlug || rawVehicleSlug, tripType: initial.tripType ?? '', pickup: initial.pickup, dropoff: initial.dropoff, pickupLocationSlug: '', dropoffLocationSlug: '', pickupTime: '', returnTime: '', pickupDate: initial.date, returnDate: '', passengers: '', fullName: '', email: '', phone: '', notes: '' })
  const [placed, setPlaced] = useState<CarRequest | null>(null)
  const [editingRef, setEditingRef] = useState<string | null>(null)
  const [errors, setErrors] = useState<CarFieldErrors>({})
  const [summary, setSummary] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const locationState = useCarLocations()
  const locations = locationState.locations
  const submittingRef = useRef(false)
  const patch = (p: Partial<CarRequestValues>) => setValues((v) => ({ ...v, ...p }))
  const vehicle = liveCars.find((car) => car.slug === values.vehicleSlug && car.isPublished !== false)
  const capacity = vehicle ? parseVehicleCapacity(vehicle.seats) : null
  const capacityInvalid = !!vehicle && (capacity === null || Number(values.passengers) > capacity)
  const quoteReady = Boolean(vehicle && values.pickupLocationSlug && values.pickupLocationSlug !== CAR_OTHER_LOCATION && values.dropoffLocationSlug && values.dropoffLocationSlug !== CAR_OTHER_LOCATION && values.tripType && /^\d+$/.test(values.passengers.trim()) && Number(values.passengers) >= 1 && Number(values.passengers) <= 50)
  const { state: quoteState, retry: retryQuote } = useCarQuote(quoteReady ? { vehicle: values.vehicleSlug, from: values.pickupLocationSlug, to: values.dropoffLocationSlug, trip: values.tripType === 'Round Trip' ? 'round-trip' : 'one-way', passengers: Number(values.passengers) } : null)
  const step = placed ? 3 : vehicle ? 2 : 1
  const notSet = tx(locale, { en: 'Not set', es: 'Sin definir', it: 'Non definito', ar: 'لم يحدد' })
  const tripLabel = values.tripType === '' ? notSet : values.tripType === 'One Way' ? (tx(locale, { en: 'One Way', es: 'Solo ida', it: 'Solo andata', ar: 'ذهاب فقط' })) : (tx(locale, { en: 'Round Trip', es: 'Ida y vuelta', it: 'Andata e ritorno', ar: 'ذهاب وعودة' }))
  const steps = [tx(locale, { en: 'Choose vehicle', es: 'Elige el vehículo', it: 'Scegli il veicolo', ar: 'اختيار السيارة' }), tx(locale, { en: 'Trip details', es: 'Detalles del viaje', it: 'Dettagli del viaggio', ar: 'تفاصيل الرحلة' }), tx(locale, { en: 'Submitted', es: 'Enviada', it: 'Inviata', ar: 'تم الإرسال' })]
  const hasQuerySignal = Boolean(initial.vehicleSlug || rawVehicleSlug || initial.pickup || initial.dropoff || initial.date || initial.tripType)
  const editParam = (() => {
    const raw = (params.get('edit') ?? '').trim()
    return isCarReference(raw) ? raw : null
  })()

  // Prefill contact details from the signed-in account as editable copies.
  useEffect(() => {
    if (!sessionUser) return
    setValues((v) => {
      const name = `${sessionUser.firstName ?? ''} ${sessionUser.lastName ?? ''}`.trim()
      return {
        ...v,
        fullName: v.fullName || name,
        email: v.email || sessionUser.email || '',
        phone: v.phone || sessionUser.phone || '',
      }
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionUser])

  // Edit mode: `?edit=SP-CR-…` loads the customer's own record for editing.
  // The query is read once; a foreign or missing record fails honestly.
  useEffect(() => {
    if (!editParam || hasQuerySignal) return
    let cancelled = false
    fetch(`/api/account/car-requests/${encodeURIComponent(editParam)}`, { credentials: 'same-origin' })
      .then(async (res) => {
        if (cancelled) return
        const data = (await res.json()) as CarRequest & { error?: string }
        if (!res.ok) throw new Error(data.error || 'Car request not found.')
        if (data.status !== 'new' && data.status !== 'reviewing') {
          throw new Error(tx(locale, { en: 'This request can no longer be edited.', es: 'Esta solicitud ya no se puede editar.', it: 'Questa richiesta non può più essere modificata.', ar: 'هذا الطلب لم يعد قابلًا للتعديل.' }))
        }
        const shaped = sanitizeCarDraft({
          vehicleSlug: data.vehicleSlug,
          tripType: data.tripType,
          pickup: data.pickup,
          dropoff: data.dropoff,
          preferredPickupDate: data.preferredPickupDate,
          preferredReturnDate: data.preferredReturnDate,
          passengers: data.passengers,
          notes: data.notes,
          contact: { fullName: data.contact.name, email: data.contact.email, phone: data.contact.phone },
          currency,
        })
        if (!shaped || cancelled) return
        setValues({
          vehicleSlug: shaped.vehicleSlug,
          tripType: shaped.tripType,
          pickup: shaped.pickup,
          dropoff: shaped.dropoff,
          pickupLocationSlug: shaped.pickupLocationSlug ?? CAR_OTHER_LOCATION,
          dropoffLocationSlug: shaped.dropoffLocationSlug ?? CAR_OTHER_LOCATION,
          pickupTime: shaped.pickupTime ?? '',
          returnTime: shaped.returnTime ?? '',
          pickupDate: shaped.preferredPickupDate,
          returnDate: shaped.preferredReturnDate,
          passengers: String(shaped.passengers),
          fullName: shaped.contact.fullName,
          email: shaped.contact.email,
          phone: shaped.contact.phone,
          notes: shaped.notes,
        })
        setEditingRef(data.reference)
      })
      .catch((error: unknown) => {
        if (!cancelled) setSummary(error instanceof Error ? error.message : 'Car request not found.')
      })
    return () => { cancelled = true }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const buildDraft = (): CarRequestDraft => {
    const pax = values.passengers.trim()
    const structured = values.pickupLocationSlug !== CAR_OTHER_LOCATION && values.dropoffLocationSlug !== CAR_OTHER_LOCATION && values.pickupLocationSlug !== '' && values.dropoffLocationSlug !== ''
    const pickupSlug = structured ? values.pickupLocationSlug : ''
    const dropSlug = structured ? values.dropoffLocationSlug : ''
    const pickupName = carLocationDisplayName(values.pickupLocationSlug, values.pickup, locations, locale, '')
    const dropName = carLocationDisplayName(values.dropoffLocationSlug, values.dropoff, locations, locale, '')
    return {
      vehicleSlug: values.vehicleSlug,
      tripType: values.tripType,
      pickup: pickupName,
      dropoff: dropName,
      pickupLocationSlug: pickupSlug,
      dropoffLocationSlug: dropSlug,
      pickupTime: values.pickupTime,
      returnTime: values.tripType === 'Round Trip' ? values.returnTime : '',
      preferredPickupDate: values.pickupDate,
      preferredReturnDate: values.tripType === 'Round Trip' ? values.returnDate : '',
      passengers: pax === '' ? Number.NaN : Number(pax),
      notes: values.notes.trim().slice(0, CAR_NOTE_MAX + 1),
      contact: { fullName: values.fullName.trim(), email: values.email.trim(), phone: values.phone.trim() },
      currency,
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (submittingRef.current) return
    const raw = buildDraft()
    const errs = validateCarRequest(raw)
    if (!vehicle) errs.vehicle = 'invalid'
    setErrors(errs)
    if (hasCarErrors(errs)) {
      setSummary(tx(locale, { en: 'Could not submit the request. Review the highlighted fields below.', es: 'No se pudo enviar la solicitud. Revisa los campos marcados abajo.', it: 'Impossibile inviare la richiesta. Controlla i campi evidenziati qui sotto.', ar: 'تعذر إرسال الطلب. راجع الحقول الموضحة أدناه.' }))
      const ids: Record<keyof CarFieldErrors, string> = { vehicle: 'car-vehicle', tripType: 'req-trip-label', pickup: 'car-pickup', dropoff: 'car-dropoff', pickupDate: 'car-pickup-date', returnDate: 'car-return-date', passengers: values.tripType === 'Round Trip' ? 'car-passengers-rt' : 'car-passengers', pickupTime: 'car-pickup-time', returnTime: 'car-return-time', name: 'car-name', email: 'car-email', phone: 'car-phone', notes: 'car-notes' }
      const order: Array<keyof CarFieldErrors> = ['vehicle', 'tripType', 'pickup', 'dropoff', 'pickupDate', 'returnDate', 'passengers', 'pickupTime', 'returnTime', 'name', 'email', 'phone', 'notes']
      for (const field of order) {
        if (errs[field]) {
          focusCarField(ids[field])
          break
        }
      }
      return
    }
    const preview = { ...raw, notes: raw.notes.slice(0, CAR_NOTE_MAX) }
    submittingRef.current = true
    setSubmitting(true)
    const url = editingRef
      ? `/api/account/car-requests/${encodeURIComponent(editingRef)}`
      : '/api/car-requests'
    fetch(url, {
      method: editingRef ? 'PATCH' : 'POST',
      headers: { 'content-type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(editingRef ? { action: 'update', draft: preview } : preview),
    })
      .then(async (res) => {
        const data = (await res.json()) as CarRequest & { error?: string }
        if (!res.ok) throw new Error(data.error || 'Could not submit the request.')
        setErrors({})
        setSummary('')
        setEditingRef(null)
        setPlaced(data)
        window.setTimeout(() => focusCarField('car-preview-title'), 50)
      })
      .catch((error: unknown) => {
        setSummary(error instanceof Error ? error.message : (tx(locale, { en: 'Could not submit the request. Please try again.', es: 'No se pudo enviar la solicitud. Inténtalo de nuevo.', it: 'Impossibile inviare la richiesta. Riprova.', ar: 'تعذر إرسال الطلب. حاول مجددًا.' })))
      })
      .finally(() => { submittingRef.current = false; setSubmitting(false) })
  }

  const handleEdit = () => {
    setPlaced(null)
    window.setTimeout(() => focusCarField('car-vehicle'), 50)
  }

  const renderPreview = (record: CarRequest) => {
    const d = {
      vehicleSlug: record.vehicleSlug,
      tripType: record.tripType,
      pickup: record.pickup,
      dropoff: record.dropoff,
      preferredPickupDate: record.preferredPickupDate,
      preferredReturnDate: record.preferredReturnDate,
      passengers: record.passengers,
      notes: record.notes,
      contact: { fullName: record.contact.name, email: record.contact.email, phone: record.contact.phone },
    }
    const previewCar = liveCars.find((car) => car.slug === d.vehicleSlug)
    const dateRows = d.tripType === 'Round Trip' && d.preferredReturnDate !== ''
      ? [{ label: tx(locale, { en: 'Preferred return date', es: 'Fecha de regreso preferida', it: 'Data di ritorno preferita', ar: 'تاريخ العودة المفضل' }), value: d.preferredReturnDate, ltr: true }]
      : []
    const timeRows: { label: string; value: string }[] = [
      ...(record.pickupTime ? [{ label: tx(locale, { en: 'Pick-up time', es: 'Hora de recogida', it: 'Orario di ritiro', ar: 'وقت الاستلام' }), value: record.pickupTime }] : []),
      ...(record.returnTime ? [{ label: tx(locale, { en: 'Return time', es: 'Hora de regreso', it: 'Orario di ritorno', ar: 'وقت العودة' }), value: record.returnTime }] : []),
    ]
    return <div className="form-success large">
      <Check size={42} />
      <h1 id="car-preview-title" tabIndex={-1}>{tx(locale, { en: 'Car request submitted', es: 'Solicitud de coche enviada', it: 'Richiesta auto inviata', ar: 'تم إرسال طلب السيارة' })}</h1>
      <span className="req-ref" dir="ltr">{tx(locale, { en: 'Reference: ', es: 'Referencia: ', it: 'Riferimento: ', ar: 'المرجع: ' })}{record.reference}</span>
      <div className="req-summary-rows" style={{ maxWidth: 520, margin: '18px auto', textAlign: 'start' }}>
        <div><span>{tx(locale, { en: 'Requested vehicle', es: 'Vehículo solicitado', it: 'Veicolo richiesto', ar: 'السيارة المطلوبة' })}</span><strong>{previewCar?.title ?? d.vehicleSlug}</strong></div>
        <div><span>{tx(locale, { en: 'Trip type', es: 'Tipo', it: 'Tipo', ar: 'النوع' })}</span><strong>{d.tripType === 'One Way' ? (tx(locale, { en: 'One Way', es: 'Solo ida', it: 'Solo andata', ar: 'ذهاب فقط' })) : d.tripType === 'Round Trip' ? (tx(locale, { en: 'Round Trip', es: 'Ida y vuelta', it: 'Andata e ritorno', ar: 'ذهاب وعودة' })) : notSet}</strong></div>
        <div><span>{tx(locale, { en: 'From', es: 'Desde', it: 'Da', ar: 'من' })}</span><strong>{d.pickup}</strong></div>
        <div><span>{tx(locale, { en: 'To', es: 'Hasta', it: 'A', ar: 'إلى' })}</span><strong>{d.dropoff}</strong></div>
        <div><span>{tx(locale, { en: 'Preferred pick-up date', es: 'Fecha de recogida preferida', it: 'Data di ritiro preferita', ar: 'تاريخ الاستلام المفضل' })}</span><strong dir="ltr">{d.preferredPickupDate}</strong></div>
        {dateRows.map((row) => <div key={row.label}><span>{row.label}</span><strong dir="ltr">{row.value}</strong></div>)}
        {timeRows.map((row) => <div key={row.label}><span>{row.label}</span><strong dir="ltr">{row.value}</strong></div>)}
        {(record.quote || record.pickupLocationSlug) && <CarQuoteSummary quote={record.quote} locale={locale} tripType={record.tripType} saved/>}
        <div><span>{tx(locale, { en: 'Passengers', es: 'Pasajeros', it: 'Passeggeri', ar: 'الركاب' })}</span><strong>{d.passengers}</strong></div>
        <div><span>{tx(locale, { en: 'Full name', es: 'Nombre completo', it: 'Nome completo', ar: 'الاسم الكامل' })}</span><strong>{d.contact.fullName}</strong></div>
        <div><span>{tx(locale, { en: 'Email', es: 'Correo electrónico', it: 'Email', ar: 'البريد الإلكتروني' })}</span><strong dir="ltr">{d.contact.email}</strong></div>
        <div><span>{tx(locale, { en: 'Phone', es: 'Teléfono', it: 'Telefono', ar: 'رقم الهاتف' })}</span><strong dir="ltr">{d.contact.phone}</strong></div>
        {d.notes !== '' && <div><span>{tx(locale, { en: 'Notes', es: 'Notas', it: 'Note', ar: 'ملاحظات' })}</span><strong style={{ whiteSpace: 'pre-wrap' }}>{d.notes}</strong></div>}
      </div>
      <p><CircleAlert size={15} style={{ verticalAlign: '-2px', marginInlineEnd: 6 }} />{tx(locale, { en: 'We have received your request and our team will review it. Keep the reference above.', es: 'Hemos recibido tu solicitud y nuestro equipo la revisará. Guarda la referencia de arriba.', it: 'Abbiamo ricevuto la tua richiesta e il nostro team la esaminerà. Conserva il riferimento qui sopra.', ar: 'استلمنا طلبك وسيراجعه فريقنا. احتفظ بالمرجع أعلاه.' })}</p>
      <p>{tx(locale, { en: 'No vehicle has been reserved, no availability was checked, and no rate was confirmed.', es: 'No se ha reservado ningún vehículo, no se ha comprobado disponibilidad ni se ha confirmado ninguna tarifa.', it: 'Nessun veicolo è stato prenotato, nessuna disponibilità è stata verificata e nessuna tariffa è stata confermata.', ar: 'لم يتم حجز أي سيارة ولم يتم التحقق من التوافر أو تأكيد أي سعر.' })}</p>
      <div className="car-success-actions">
        {sessionUser
          ? <><button type="button" className="outline-btn" onClick={handleEdit}>{tx(locale, { en: 'Edit request', es: 'Editar solicitud', it: 'Modifica richiesta', ar: 'تعديل الطلب' })}</button>
            <Link className="primary-btn" href={`/account/car-requests/detail?ref=${encodeURIComponent(record.reference)}`}>{tx(locale, { en: 'View request details', es: 'Ver detalles de la solicitud', it: 'Vedi dettagli richiesta', ar: 'عرض تفاصيل الطلب' })}</Link></>
          : <><Link className="primary-btn" href="/register">{tx(locale, { en: 'Create an account to track my requests', es: 'Crea una cuenta para seguir tus solicitudes', it: 'Crea un account per seguire le tue richieste', ar: 'إنشاء حساب لمتابعة طلباتي' })}</Link>
            <Link className="outline-btn" href={`/login?next=${encodeURIComponent('/account/car-requests')}`}>{tx(locale, { en: 'Sign in', es: 'Iniciar sesión', it: 'Accedi', ar: 'تسجيل الدخول' })}</Link></>}
        <Link className="outline-btn" href="/contact">{tx(locale, { en: 'Contact our team', es: 'Contacta con nuestro equipo', it: 'Contatta il nostro team', ar: 'تواصل مع فريقنا' })}</Link>
      </div>
    </div>
  }

  return <>
    <Breadcrumb items={[tx(locale, { en: 'Rent Car', es: 'Alquiler de coches', it: 'Noleggio auto', ar: 'تأجير السيارات' }), tx(locale, { en: 'Request a vehicle', es: 'Solicitar un vehículo', it: 'Richiedi un veicolo', ar: 'طلب سيارة' })]} />
    <main className="container car-request-page">
      <header className="car-request-head">
        <span className="eyebrow">{tx(locale, { en: 'Private transport', es: 'Transporte privado', it: 'Trasporto privato', ar: 'نقل خاص' })}</span>
        <h1>{tx(locale, { en: 'Tell us how you want to move.', es: 'Cuéntanos cómo quieres moverte.', it: 'Dicci come vuoi muoverti.', ar: 'أخبرنا كيف تريد التنقل.' })}</h1>
        <p>{tx(locale, { en: 'Fill in your request details and our team will review your request and contact you.', es: 'Completa los detalles de tu solicitud y nuestro equipo la revisará y te contactará.', it: 'Compila i dettagli della richiesta: il nostro team la esaminerà e ti contatterà.', ar: 'املأ تفاصيل طلبك وسيراجع فريقنا طلبك وسيتواصل معك.' })}</p>
      </header>
      <ol className="stepper req-stepper" aria-label={tx(locale, { en: 'Vehicle request progress', es: 'Progreso de la solicitud', it: 'Avanzamento richiesta', ar: 'مراحل طلب السيارة' })}>
        {steps.map((label, i) => {
          const state = step > i + 1 ? 'done' : step === i + 1 ? 'active' : 'todo'
          const isDone = step > i + 1
          return <li key={label}>
            {i > 0 && <span className={`step-line${step > i ? ' done' : ''}`} aria-hidden="true" />}
            <span className={`step-pill ${state}`} aria-current={step === i + 1 ? 'step' : undefined}>
              <b className="step-num">{isDone ? <Check size={18} /> : i + 1}</b>
              {label}
            </span>
          </li>
        })}
      </ol>
      {placed
        ? renderPreview(placed)
        : <div className="car-request-layout">
          <aside className="car-summary-card" aria-label={tx(locale, { en: 'Request summary', es: 'Resumen de la solicitud', it: 'Riepilogo richiesta', ar: 'ملخص الطلب' })}>
            <div>
              <span className="eyebrow">{tx(locale, { en: 'Your summary', es: 'Tu resumen', it: 'Il tuo riepilogo', ar: 'ملخص طلبك' })}</span>
              {vehicle
                ? <div className="req-vehicle-mini"><img src={vehicle.image} alt={vehicle.title} /><div><strong>{vehicle.title}</strong><span><Users size={13} style={{ verticalAlign: '-2px' }} /> {vehicle.seats}</span></div></div>
                : <p className="req-novehicle">{tx(locale, { en: 'Select a vehicle in the form to see your summary here.', es: 'Selecciona un vehículo en el formulario para ver tu resumen aquí.', it: 'Seleziona un veicolo nel modulo per vedere qui il riepilogo.', ar: 'اختر السيارة من النموذج ليظهر ملخصك هنا.' })}</p>}
              <div className="req-summary-rows">
                <div><span>{tx(locale, { en: 'Trip type', es: 'Tipo', it: 'Tipo', ar: 'النوع' })}</span><strong>{tripLabel}</strong></div>
                <div><span>{tx(locale, { en: 'From', es: 'Desde', it: 'Da', ar: 'من' })}</span><strong>{carLocationDisplayName(values.pickupLocationSlug, values.pickup, locations, locale, notSet)}</strong></div>
                <div><span>{tx(locale, { en: 'To', es: 'Hasta', it: 'A', ar: 'إلى' })}</span><strong>{carLocationDisplayName(values.dropoffLocationSlug, values.dropoff, locations, locale, notSet)}</strong></div>
                <div><span>{tx(locale, { en: 'Preferred pick-up date', es: 'Fecha de recogida preferida', it: 'Data di ritiro preferita', ar: 'تاريخ الاستلام المفضل' })}</span><strong dir="ltr">{values.pickupDate || notSet}</strong></div>
                {values.tripType === 'Round Trip' && <div><span>{tx(locale, { en: 'Preferred return date', es: 'Fecha de regreso preferida', it: 'Data di ritorno preferita', ar: 'تاريخ العودة المفضل' })}</span><strong dir="ltr">{values.returnDate || notSet}</strong></div>}
                <div><span>{tx(locale, { en: 'Passengers', es: 'Pasajeros', it: 'Passeggeri', ar: 'الركاب' })}</span><strong>{values.passengers || notSet}</strong></div>
                <section aria-live="polite" aria-busy={quoteState.kind === 'loading'} className="car-quote-message">
                  {quoteState.kind === 'loading' ? tx(locale, { en: 'Updating transfer price…', es: 'Actualizando el precio del traslado…', it: 'Aggiornamento del prezzo del trasferimento…' })
                    : quoteState.kind === 'error' ? <>{tx(locale, { en: 'We could not retrieve a price. You can retry or send an inquiry without a quote.', es: 'No pudimos obtener el precio. Puedes reintentar o enviar una consulta sin presupuesto.', it: 'Impossibile recuperare il prezzo. Puoi riprovare o inviare una richiesta senza preventivo.' })}<button type="button" className="text-link" onClick={retryQuote}>{tx(locale, { en: 'Retry price', es: 'Reintentar precio', it: 'Riprova prezzo' })}</button></>
                    : quoteState.kind === 'unavailable' || capacityInvalid ? tx(locale, { en: 'This vehicle cannot be priced for these passengers. Send an inquiry and our team will arrange a suitable vehicle.', es: 'No hay tarifa para este vehículo y pasajeros. Envía una consulta para que busquemos un vehículo adecuado.', it: 'Nessuna tariffa per questo veicolo e passeggeri. Invia una richiesta per trovare un veicolo adatto.' })
                    : <CarQuoteSummary quote={quoteState.kind === 'quote' ? quoteState.quote : null} tripType={values.tripType} locale={locale}/>}
                </section>
              </div>
              <p><ShieldCheck size={15} />{tx(locale, { en: 'Private driver and A/C included', es: 'Conductor privado y aire acondicionado incluidos', it: 'Autista privato e aria condizionata inclusi', ar: 'شامل سائق خاص وتكييف' })}</p>
              <a className="req-wa" href={whatsappHref(brand.whatsapp)} target="_blank" rel="noreferrer">{tx(locale, { en: 'Chat on WhatsApp', es: 'Hablar por WhatsApp', it: 'Chat su WhatsApp', ar: 'تواصل عبر واتساب' })}</a>
            </div>
          </aside>
          <div className="car-form-card">
            {fleet.loading && <p role="status">{tx(locale, { en: 'Loading available vehicles…', es: 'Cargando vehículos disponibles…', it: 'Caricamento dei veicoli disponibili…' })}</p>}
            {fleet.error && <p role="alert">{tx(locale, { en: 'Vehicles could not be loaded.', es: 'No se pudieron cargar los vehículos.', it: 'Impossibile caricare i veicoli.' })}<button type="button" onClick={fleet.retry}>{tx(locale, { en: 'Retry', es: 'Reintentar', it: 'Riprova' })}</button></p>}
            {!fleet.loading && !fleet.error && !liveCars.length && <p role="status">{tx(locale, { en: 'No vehicles are currently available. Please contact our team.', es: 'No hay vehículos disponibles. Contacta con nuestro equipo.', it: 'Nessun veicolo disponibile. Contatta il nostro team.' })}</p>}
            {locationState.loading && <p role="status" className="car-location-notice">{tx(locale, { en: 'Loading pickup and drop-off locations…', es: 'Cargando lugares de recogida y entrega…', it: 'Caricamento dei luoghi di ritiro e riconsegna…' })}</p>}
            {locationState.error && <p role="alert" className="car-location-notice">{tx(locale, { en: 'Locations could not be loaded. Enter your addresses to request a manual quote.', es: 'No se pudieron cargar los lugares. Introduce tus direcciones para solicitar un presupuesto.', it: 'Impossibile caricare i luoghi. Inserisci gli indirizzi per richiedere un preventivo.' })}<button type="button" onClick={locationState.retry}>{tx(locale, { en: 'Retry locations', es: 'Reintentar lugares', it: 'Riprova luoghi' })}</button></p>}
            {editingRef && <p className="car-location-notice">{tx(locale, { en: 'Saving changes recalculates your quote using current prices. Your earlier quote may change.', es: 'Guardar cambios recalcula el presupuesto con los precios actuales. El precio anterior puede cambiar.', it: 'Il salvataggio ricalcola il preventivo con i prezzi attuali. Il prezzo precedente può cambiare.' })}</p>}
            <CarRequestForm values={values} errors={errors} summary={summary} submitting={submitting} editing={editingRef !== null} locations={locations} onChange={patch} onSubmit={handleSubmit} />
          </div>
        </div>}
    </main>
  </>
}

type DestinationListProps = { initialDestinations?: Destination[]; loadError?: boolean }
export function DestinationsPage(props: DestinationListProps = {}) {
  return <SiteShell><DestinationsPageContent {...props} /></SiteShell>
}
function DestinationCatalogueStatus({ error, retry, empty = false }: { error?: boolean; retry: () => void; empty?: boolean }) {
  const { locale } = useLocale()
  return <div role={error ? 'alert' : 'status'} className="container section">
    <p>{error ? tx(locale, { en: 'Destinations could not be loaded. Please try again.', es: 'No se pudieron cargar los destinos. Inténtalo de nuevo.', it: 'Impossibile caricare le destinazioni. Riprova.' }) : empty ? tx(locale, { en: 'No destinations are available yet.', es: 'Aún no hay destinos disponibles.', it: 'Nessuna destinazione disponibile al momento.' }) : tx(locale, { en: 'Loading destinations…', es: 'Cargando destinos…', it: 'Caricamento destinazioni…' })}</p>
    {error && <button className="primary-btn" type="button" onClick={retry}>{tx(locale, { en: 'Try again', es: 'Reintentar', it: 'Riprova' })}</button>}
  </div>
}
function DestinationCatalogueHero({ count, eyebrow, title, copy, image, href, action }: { count: number; eyebrow: string; title: string; copy: string; image: string; href: string; action: string }) {
  const state = useFaqHero()
  const { locale } = useLocale()
  if (state?.hidden || state?.unavailable) return null
  const content = state?.content
  const text = content && locale !== 'ar' ? content.text[locale] : null
  return <PageShowcaseHero
    image={content?.image?.trim() || image}
    eyebrow={text?.eyebrow ?? eyebrow} title={text?.heading ?? title} intro={text?.description ?? copy}
    primaryLabel={text?.action ?? action} primaryHref={content?.href ?? href}
    secondaryLabel={tx(locale, { en: 'Explore destinations', es: 'Descubre los destinos', it: 'Scopri le destinazioni' })} secondaryHref="#destinations-catalogue"
    railLabel={tx(locale, { en: 'Discover Egypt', es: 'Descubre Egipto', it: 'Scopri l’Egitto' })}
    railTitle={tx(locale, { en: 'Find your next destination', es: 'Encuentra tu próximo destino', it: 'Trova la tua prossima destinazione' })}
    railHref="#destinations-catalogue" railMeta={[]}
    statsLabel={tx(locale, { en: 'Available destinations', es: 'Destinos disponibles', it: 'Destinazioni disponibili' })}
    stats={[{ value: count, label: tx(locale, { en: 'Destinations to explore', es: 'Destinos por descubrir', it: 'Destinazioni da esplorare' }) }]}
  />
}
function DestinationsPageContent({ initialDestinations, loadError }: DestinationListProps) {
  const cms = usePresentation("destinations")
 const { locale } = useLocale(); const status = usePublicDestinationsStatus(); const error = Boolean(status.error || (loadError && status.data === null)); const rows = status.data ?? (error ? undefined : initialDestinations?.map(row => localizeCatalogue(row, 'destination', locale))); const liveDestinations = (rows ?? []).filter(row => row.isPublished !== false); return <><DestinationCatalogueHero count={liveDestinations.length} eyebrow={tx(locale, { en: 'See the full picture', es: 'Mira el panorama completo', it: 'Guarda il quadro completo', ar: 'الصورة الكاملة' })} title={tx(locale, { en: 'Egypt Destinations', es: 'Destinos Egipto', it: 'Destinazioni Egitto', ar: 'وجهات مصر' })} copy={tx(locale, { en: 'Build a trip around the places that make you curious, from ancient capitals to salt-white deserts and coral-blue seas.', es: 'Crea un viaje en torno a los lugares que despierten tu curiosidad, desde capitales antiguas hasta desiertos blancos y mares de coral.', it: 'Costruisci un viaggio intorno ai luoghi che accendono la tua curiosità, dalle antiche capitali ai deserti bianchi e ai mari corallini.', ar: 'ابنِ رحلتك حول الأماكن التي تثير فضولك، من العواصم القديمة للصحارى البيضاء والشواطئ المرجانية.' })} image={siteImages.desert} href="/make-your-trip" action={tx(locale, { en: 'Build my route', es: 'Crea mi ruta', it: 'Crea il mio itinerario', ar: 'ابنِ خط سيرك' })}/><main id="destinations-catalogue" className="section container destinations-catalogue">{(error || !rows || !liveDestinations.length) && <DestinationCatalogueStatus error={error} empty={Boolean(rows && !liveDestinations.length)} retry={status.retry} />}<PresentationSection pageId="destinations" id="presentation"><div className="destination-large-grid">{liveDestinations.map(item=><article className="destination-large" key={item.slug}>{item.image && <img src={item.image} alt={item.title} loading="lazy"/>}<div><span className="eyebrow">{cms.text("presentation","description0",tx(locale, { en: 'Discover Egypt', es: 'Descubre Egipto', it: 'Scopri l\'Egitto', ar: 'اكتشف مصر' }))}</span><h2><Link href={`/destinations/${item.slug}`}>{item.title}</Link></h2><p>{item.copy}</p><Link href={`/destinations/${item.slug}`} className="text-link">{cms.text("presentation","description1",tx(locale, { en: 'Explore destination', es: 'Descubre el destino', it: 'Scopri la destinazione', ar: 'استكشف الوجهة' }))} <ArrowRight size={15}/></Link></div></article>)}</div></PresentationSection></main></> }

const destinationFactIcons = [Clock3, Sun, Compass, MapPin]

type DestinationDetailProps = { slug: string; initialDestination?: Destination; initialTours?: Tour[] }
export function DestinationDetailPage(props: DestinationDetailProps) {
  return <SiteShell><DestinationDetailContent {...props} /></SiteShell>
}
function DestinationDetailContent({ slug, initialDestination, initialTours = [] }: DestinationDetailProps) {

  const { locale } = useLocale()
  const status = usePublicDestinationsStatus()
  const tours = useDbToursStatus([], { includeNew: true })
  const [toursStarted, setToursStarted] = useState(false)
  useEffect(() => { invalidateToursCache(); setToursStarted(true) }, [])
  const liveItem = status.data === null ? (status.error ? undefined : initialDestination && localizeCatalogue(initialDestination, 'destination', locale)) : status.data.find(entry => entry.slug === slug)
  const item = liveItem && liveItem.isPublished !== false ? liveItem : undefined
  if (status.error || (!item && status.data === null)) return <DestinationCatalogueStatus error={Boolean(status.error)} retry={status.retry} />
  if (!item) return <main className="not-found"><h1>{tx(locale, { en: 'Destination not found', es: 'Destino no encontrado', it: 'Destinazione non trovata' })}</h1><Link href="/destinations" className="primary-btn">{tx(locale, { en: 'Explore destinations', es: 'Descubre los destinos', it: 'Scopri le destinazioni' })}</Link></main>
  return <DestinationDetailView item={item} relatedTours={destinationTours(item, tours.data?.length && !toursStarted ? initialTours : tours.data ?? (tours.error ? [] : initialTours))} />
}

/** Shared read-only page body. Preview passes unsaved data and never mounts catalogue/network hooks. */
export function DestinationDetailView({ item, relatedTours, preview = false }: { item: Destination; relatedTours: Tour[]; preview?: boolean }) {
  const cms = usePresentation('destination-detail')
  const { locale } = useLocale()
  const detail = item.detail

  return <>
    <main className="destination-detail-page"><PresentationOrder pageId="destination-detail">
      <section className="destination-detail-hero">
        {detail.heroImage && <img src={detail.heroImage} alt={detail.heroAlt}/>}
        <div className="destination-detail-shade"/>
        <div className="container destination-detail-hero-content">
          <nav aria-label={tx(locale, { en: 'Breadcrumb', es: 'Ruta de navegación', it: 'Percorso di navigazione', ar: 'مسار التنقل' })}><Link href="/destinations">{tx(locale, { en: 'Destinations', es: 'Destinos', it: 'Destinazioni', ar: 'الوجهات' })}</Link><span>›</span><span aria-current="page">{item.title}</span></nav>
          <span className="eyebrow">{detail.eyebrow}</span>
          <h1>{item.title}</h1>
          <p>{item.copy}</p>
          <div className="destination-hero-actions">
            <Link href="/make-your-trip" className="primary-btn">{cms.text("destination-story","planDestination",tx(locale, { en: 'Plan this destination', es: 'Planifica este destino', it: 'Pianifica questa destinazione', ar: 'خطط لهذه الوجهة' }))} <ArrowRight size={17}/></Link>
            <a href="#destination-experiences" className="destination-ghost-btn">{cms.text("destination-story","seeDestination",tx(locale, { en: 'See what awaits', es: 'Descubre lo que te espera', it: 'Scopri cosa ti aspetta', ar: 'اكتشف ما ينتظرك' }))}</a>
          </div>
        </div>
      </section>

      <section className="destination-facts" aria-label={tx(locale, { en: `${item.title} at a glance`, es: `${item.title} en resumen`, it: `${item.title} in breve`, ar: `${item.title} باختصار` })}>
        <div className="container">
          {detail.facts.map((fact, index) => {
            const Icon = destinationFactIcons[index] || Compass
            return <div key={fact.label}><Icon size={21}/><span><small>{fact.label}</small><strong>{fact.value}</strong></span></div>
          })}
        </div>
      </section>

      <PresentationSection pageId="destination-detail" id="destination-story"><section className="destination-story container">
        <div>
          <span className="eyebrow">{cms.text("destination-story","description0",tx(locale, { en: 'The destination story', es: 'La historia del destino', it: 'La storia della destinazione', ar: 'حكاية الوجهة' }))}</span>
          <h2>{cms.text("destination-story","description1",tx(locale, { en: 'Come for the icons. Stay for the rhythm.', es: 'Ven por los iconos. Quédate por el ritmo.', it: 'Vieni per le icone. Resta per il ritmo.', ar: 'تعالَ للأيقونات. وابقَ للإيقاع.' }))}</h2>
          <p>{detail.intro}</p>
          <p>{cms.text("destination-story","description2",tx(locale, { en: 'We shape each day around proximity, light, energy, and the moments that deserve more than a quick stop.', es: 'Diseñamos cada día en torno a la cercanía, la luz, la energía y los momentos que merecen más que una parada rápida.', it: 'Modelliamo ogni giornata su vicinanza, luce, energia e momenti che meritano più di una sosta veloce.', ar: 'نصمم كل يوم حول القرب والإضاءة والطاقة واللحظات التي تستحق أكثر من وقفة سريعة.' }))}</p>
        </div>
        <aside>
          <span className="eyebrow">{cms.text("destination-story","description3",tx(locale, { en: 'Especially good for', es: 'Ideal para', it: 'Ideale per', ar: 'مناسبة بشكل خاص لـ' }))}</span>
          <div>{detail.bestFor.map((item) => <span key={item}><Check size={15}/>{item}</span>)}</div>
        </aside>
      </section></PresentationSection>

      <PresentationSection pageId="destination-detail" id="destination-experiences"><section id="destination-experiences" className="destination-experiences">
        <div className="container">
          <header className="destination-section-head"><div><span className="eyebrow">{cms.text("destination-experiences","description0",tx(locale, { en: 'Signature experiences', es: 'Experiencias emblemáticas', it: 'Esperienze imperdibili', ar: 'تجارب مميزة' }))}</span><h2>{cms.text("destination-experiences","description1",tx(locale, { en: 'The moments that define', es: 'Los momentos que definen', it: 'I momenti che definiscono', ar: 'اللحظات التي تميز' }))} {item.title}.</h2></div><p>{cms.text("destination-experiences","description2",tx(locale, { en: 'Not a checklist. A considered mix of landmarks, local texture, and enough space to actually feel the place.', es: 'No es una lista de tareas: es una mezcla cuidada de monumentos, ambiente local y espacio suficiente para sentir de verdad el lugar.', it: 'Non una lista di cose da spuntare, ma un mix studiato di monumenti, atmosfera locale e spazio per vivere davvero il luogo.', ar: 'ليست قائمة مهام، بل مزيج مدروس من المعالم والروح المحلية ومساحة كافية لتشعر بالمكان فعلًا.' }))}</p></header>
          <div className="destination-experience-grid">
            {detail.experiences.map((experience, index) => <article key={experience.title} className={index === 0 ? 'featured' : ''}>
              {experience.image && <img src={experience.image} alt={experience.alt} loading="lazy"/>}
              <div><span>0{index + 1}</span><h3>{experience.title}</h3><p>{experience.copy}</p></div>
            </article>)}
          </div>
        </div>
      </section></PresentationSection>

      <PresentationSection pageId="destination-detail" id="destination-rhythm"><section className="destination-rhythm container">
<div className="destination-rhythm-image">{detail.heroImage && <img src={detail.heroImage} alt={tx(locale, { en: `A memorable view of ${item.title}`, es: `Una vista inolvidable de ${item.title}`, it: `Una vista memorabile di ${item.title}`, ar: `منظر لا يُنسى من ${item.title}` })} loading="lazy"/>}<span>{cms.text("destination-rhythm","description0",tx(locale, { en: 'Suggested rhythm', es: 'Ritmo sugerido', it: 'Ritmo suggerito', ar: 'إيقاع مقترح' }))}</span></div>
        <div className="destination-rhythm-copy">
          <span className="eyebrow">{cms.text("destination-rhythm","description1",tx(locale, { en: 'A route that breathes', es: 'Una ruta que respira', it: 'Un itinerario che respira', ar: 'خط سير يتنفس' }))}</span>
          <h2>{cms.text("destination-rhythm","description2",tx(locale, { en: 'How to experience', es: 'Cómo vivir', it: 'Come vivere', ar: 'كيف تعيش' }))} {item.title} {cms.text("destination-rhythm","description3",tx(locale, { en: 'without rushing it.', es: 'sin prisas.', it: 'senza fretta.', ar: 'دون استعجال.' }))}</h2>
          <div className="destination-timeline">{detail.rhythm.map((step, index) => <article key={step.title}><b>0{index + 1}</b><div><small>{step.label}</small><h3>{step.title}</h3><p>{step.copy}</p></div></article>)}</div>
        </div>
      </section></PresentationSection>

      <PresentationSection pageId="destination-detail" id="destination-practical"><section className="destination-practical">
        <div className="container">
          <header><span className="eyebrow">{cms.text("destination-practical","description0",tx(locale, { en: 'Travel well', es: 'Viaja bien', it: 'Viaggia bene', ar: 'سافر بذكاء' }))}</span><h2>{cms.text("destination-practical","description1",tx(locale, { en: 'Small choices. Better days.', es: 'Pequeñas decisiones. Días mejores.', it: 'Piccole scelte. Giorni migliori.', ar: 'خيارات صغيرة وأيام أجمل.' }))}</h2></header>
          <div>{detail.practical.map((tip, index) => <article key={tip.title}><span>0{index + 1}</span><h3>{tip.title}</h3><p>{tip.copy}</p></article>)}</div>
        </div>
      </section></PresentationSection>

      {relatedTours.length > 0 && <PresentationSection pageId="destination-detail" id="destination-related"><section className="destination-related container">
        <header className="destination-section-head"><div><span className="eyebrow">{cms.text("destination-related","description0",tx(locale, { en: 'Travel with us', es: 'Viaja con nosotros', it: 'Viaggia con noi', ar: 'سافر معنا' }))}</span><h2>{cms.text("destination-related","description1",tx(locale, { en: 'Ways to experience', es: 'Formas de vivir', it: 'Modi per vivere', ar: 'طرق لتعيش بها' }))} {item.title}.</h2></div><CmsPublicLink href={cms.link("destination-related","links0","/all-tours/one-day-tours")} className="text-link">{cms.text("destination-related","description2",tx(locale, { en: 'View all tours', es: 'Ver todas las excursiones', it: 'Vedi tutti i tour', ar: 'شاهد كل الرحلات' }))} <ArrowRight size={15}/></CmsPublicLink></header>
        <div className={`destination-tour-grid${relatedTours.length === 1 ? ' single' : ''}`}>{relatedTours.map((tour) => preview ? <TourCardPresentation key={tour.slug} tour={tour} passive/> : <TourCard key={tour.slug} tour={tour}/>)}</div>
      </section></PresentationSection>}

      <PresentationSection pageId="destination-detail" id="destination-plan-cta"><section className="destination-plan-cta">
        {item.image && <img src={item.image} alt="" loading="lazy"/>}
        <div/>
        <div className="container"><span className="eyebrow">{cms.text("destination-plan-cta","description0",tx(locale, { en: 'Your Egypt, thoughtfully arranged', es: 'Tu Egipto, organizado con esmero', it: 'Il tuo Egitto, organizzato con cura', ar: 'مصر بتنظيم مدروس' }))}</span><h2>{cms.text("destination-plan-cta","description1",tx(locale, { en: 'Make', es: 'Haz de', it: 'Fai di', ar: 'اجعل' }))} {item.title} {cms.text("destination-plan-cta","description2",tx(locale, { en: 'part of a journey built around you.', es: 'parte de un viaje creado a tu medida.', it: 'parte di un viaggio costruito intorno a te.', ar: 'جزءًا من رحلة مبنية حولك.' }))}</h2><p>{cms.text("destination-plan-cta","description3",tx(locale, { en: 'Share your dates, pace, and interests. Our local team will connect the details into one smooth itinerary.', es: 'Comparte tus fechas, tu ritmo y tus intereses. Nuestro equipo local unirá los detalles en un itinerario fluido.', it: 'Condividi date, ritmo e interessi: il nostro team locale collegherà i dettagli in un itinerario fluido.', ar: 'شاركنا مواعيدك وإيقاعك واهتماماتك، وسيربط فريقنا المحلي التفاصيل في برنامج واحد سلس.' }))}</p><CmsPublicLink href={cms.link("destination-plan-cta","links0","/make-your-trip")} className="primary-btn">{cms.text("destination-plan-cta","description4",tx(locale, { en: 'Build my trip', es: 'Crea mi viaje', it: 'Crea il mio viaggio', ar: 'ابنِ رحلتي' }))} <ArrowRight size={17}/></CmsPublicLink></div>
      </section></PresentationSection>
    </PresentationOrder></main>
  </>
}

export function BlogsPage({ initialBlogs }: { initialBlogs: Blog[] }) { return <SiteShell><BlogsPageContent initialBlogs={initialBlogs} /></SiteShell> }

function BlogMagazineCard({ item }: { item: Blog }) {
  const { locale } = useLocale()
  const ar = locale === 'ar'
  const href = `/blogs/${item.slug}`
  const image = item.editorial?.heroImage ?? item.image
  const imageAlt = item.editorial?.heroAlt ?? item.title

  return <article className="blog-mag-card">
    <Link href={href} className="blog-mag-media" aria-label={item.title}>
      <img src={image} alt={imageAlt} loading="lazy"/>
      <span>{item.category}</span>
    </Link>
    <div className="blog-mag-copy">
      <div className="blog-mag-meta">
        <span><CalendarDays size={14}/>{item.date}</span>
        {item.editorial?.readTime && <span><Clock3 size={14}/>{item.editorial.readTime}</span>}
      </div>
      <h3><Link href={href}>{item.title}</Link></h3>
      <p>{item.excerpt}</p>
      <Link href={href} className="blog-mag-link">
        {tx(locale, { en: 'Read the story', es: 'Lee la historia', it: 'Leggi la storia', ar: 'اقرأ الدليل' })} <ArrowRight size={16}/>
      </Link>
    </div>
  </article>
}

function BlogsPageContent({ initialBlogs }: { initialBlogs: Blog[] }) {
  const cms = usePresentation("blogs")

  const { locale } = useLocale()
  const ar = locale === 'ar'
  const liveBlogs = useDbBlogs(initialBlogs).filter((blog) => blog.isPublished !== false)
  const featured = liveBlogs[0]
  const categories = new Set(liveBlogs.map((blog) => blog.category)).size
  if (!featured) return null
  return <main>
    <PageShowcaseHero image={featured.image} eyebrow={tx(locale, { en: 'Stories & inspiration', es: 'Historias e inspiración', it: 'Storie e ispirazione', ar: 'حكايات وإلهام' })} title={tx(locale, { en: 'Travel notes for curious Egypt explorers', es: 'Notas de viaje para exploradores curiosos de Egipto', it: 'Note di viaggio per curiosi esploratori dell\'Egitto', ar: 'ملاحظات سفر لعشاق مصر الفضوليين' })} intro={tx(locale, { en: 'Practical guides, local perspective, and the small details that help you travel with more confidence.', es: 'Guías prácticas, mirada local y los pequeños detalles que te ayudan a viajar con más confianza.', it: 'Guide pratiche, prospettiva locale e piccoli dettagli per viaggiare con più sicurezza.', ar: 'أدلة عملية ووجهة نظر محلية وتفاصيل صغيرة تساعدك تسافر بثقة أكبر.' })} primaryLabel={tx(locale, { en: 'Explore the stories', es: 'Descubre las historias', it: 'Scopri le storie', ar: 'استكشف القصص' })} primaryHref="#blog-stories" secondaryLabel={tx(locale, { en: 'Read the featured story', es: 'Lee la historia destacada', it: 'Leggi la storia in evidenza', ar: 'اقرأ القصة المميزة' })} secondaryHref={`/blogs/${featured.slug}`} railLabel={tx(locale, { en: 'Featured story', es: 'Historia destacada', it: 'Storia in evidenza', ar: 'قصة مميزة' })} railTitle={featured.title} railHref={`/blogs/${featured.slug}`} railMeta={[{ Icon: CalendarDays, label: featured.date }, { Icon: Compass, label: featured.category }]} statsLabel={tx(locale, { en: 'Journal summary', es: 'Resumen del blog', it: 'Riepilogo del diario', ar: 'ملخص المدونة' })} stats={[{ value: liveBlogs.length, label: tx(locale, { en: 'Stories & guides', es: 'Historias y guías', it: 'Storie e guide', ar: 'قصص وأدلة' }) }, { value: categories, label: tx(locale, { en: 'Story categories', es: 'Categorías', it: 'Categorie di storie', ar: 'تصنيفات' }) }]}/>
    <PresentationSection pageId="blogs" id="blog-stories"><section id="blog-stories" className="blogs-editorial section container">
      <article className="blog-feature-story">
        <Link href={`/blogs/${featured.slug}`} className="blog-feature-media" aria-label={featured.title}>
          <img src={featured.editorial?.heroImage ?? featured.image} alt={featured.editorial?.heroAlt ?? featured.title}/>
          <span>{cms.text("blog-stories","description0",tx(locale, { en: 'Editor\'s pick', es: 'Selección del editor', it: 'Scelta del redattore', ar: 'اختيار المجلة' }))}</span>
        </Link>
        <div className="blog-feature-copy">
          <span className="eyebrow">{cms.text("blog-stories","description1",tx(locale, { en: 'Featured story', es: 'Historia destacada', it: 'Storia in evidenza', ar: 'قصة مميزة' }))}</span>
          <div className="blog-mag-meta">
            <span><Compass size={14}/>{featured.category}</span>
            <span><CalendarDays size={14}/>{featured.date}</span>
            {featured.editorial?.readTime && <span><Clock3 size={14}/>{featured.editorial.readTime}</span>}
          </div>
          <h2>{featured.title}</h2>
          <p>{featured.excerpt}</p>
          <Link href={`/blogs/${featured.slug}`} className="blog-feature-link">
            {cms.text("blog-stories","description2",tx(locale, { en: 'Read the full story', es: 'Lee la historia completa', it: 'Leggi la storia completa', ar: 'اقرأ القصة كاملة' }))} <ArrowRight size={17}/>
          </Link>
        </div>
      </article>

      <header className="blog-index-head">
        <div>
          <span className="eyebrow">{cms.text("blog-stories","description3",tx(locale, { en: 'From the travel journal', es: 'De nuestro diario de viajes', it: 'Dal diario di viaggio', ar: 'من مجلة السفر' }))}</span>
          <h2>{cms.text("blog-stories","description4",tx(locale, { en: 'Fresh perspectives for your next Egypt journey.', es: 'Nuevas perspectivas para tu próximo viaje a Egipto.', it: 'Nuove prospettive per il tuo prossimo viaggio in Egitto.', ar: 'أفكار جديدة لرحلتك القادمة في مصر.' }))}</h2>
        </div>
        <p>{tx(locale, { en: `${Math.max(liveBlogs.length - 1, 0)} recent guides and stories`, es: `${Math.max(liveBlogs.length - 1, 0)} guías e historias recientes`, it: `${Math.max(liveBlogs.length - 1, 0)} guide e storie recenti`, ar: `${Math.max(liveBlogs.length - 1, 0)} أدلة وقصص حديثة` })}</p>
      </header>

      <div className="blog-magazine-grid">
        {liveBlogs.slice(1).map((item) => <BlogMagazineCard item={item} key={item.slug}/>) }
      </div>
    </section></PresentationSection>
  </main>
}

const guideIconMap: Record<string, LucideIcon> = { Sun, Clock3, Compass, ShieldCheck, Ticket, Camera }

function GuideTipCard({ icon, title, copy }: { icon: string; title: string; copy: string }) {
  const Icon = guideIconMap[icon] || Compass
  return <article><Icon size={24}/><h3>{title}</h3><p>{copy}</p></article>
}

function GuideSection({ section, tips }: { section: { id: string; number: string; eyebrow: string; heading: string; lede?: string; copy?: readonly string[]; list?: readonly string[]; image?: { src: string; alt: string; caption?: string }; reverse?: boolean }; tips?: readonly { icon: string; title: string; copy: string }[] }) {
  const hasImage = !!section.image
  const hasCopy = !!(section.copy && section.copy.length) || !!section.lede || !!(section.list && section.list.length)
  if (section.id === 'essentials' && tips && tips.length) {
    return <section id={section.id} className="guide-essentials">
      <div className="guide-heading"><span className="guide-section-number">{section.number}</span><div><span className="eyebrow">{section.eyebrow}</span><h2>{section.heading}</h2></div></div>
      <div id="tips" className="guide-tip-grid">{tips.map((tip) => <GuideTipCard key={tip.title} {...tip} />)}</div>
    </section>
  }
  if (hasImage && hasCopy) {
    return <section id={section.id} className={`guide-split${section.reverse ? ' guide-split-reverse' : ''}`}>
      {section.reverse ? <>
        <div className="guide-copy"><span className="guide-section-number">{section.number}</span><span className="eyebrow">{section.eyebrow}</span><h2>{section.heading}</h2>{section.lede && <p className="guide-lede">{section.lede}</p>}{section.copy?.map((p, i) => <p key={i}>{p}</p>)}{section.list && <ul>{section.list.map((item, i) => <li key={i}><Check size={16}/>{item}</li>)}</ul>}</div>
        <div className="guide-image"><img src={section.image!.src} alt={section.image!.alt} loading="lazy"/>{section.image!.caption && <span>{section.image!.caption}</span>}</div>
      </> : <>
        <div className="guide-image"><img src={section.image!.src} alt={section.image!.alt} loading="lazy"/>{section.image!.caption && <span>{section.image!.caption}</span>}</div>
        <div className="guide-copy"><span className="guide-section-number">{section.number}</span><span className="eyebrow">{section.eyebrow}</span><h2>{section.heading}</h2>{section.lede && <p className="guide-lede">{section.lede}</p>}{section.copy?.map((p, i) => <p key={i}>{p}</p>)}{section.list && <ul>{section.list.map((item, i) => <li key={i}><Check size={16}/>{item}</li>)}</ul>}</div>
      </>}
    </section>
  }
  if (hasImage && !hasCopy) {
    return <figure className="guide-wide-image"><img src={section.image!.src} alt={section.image!.alt} loading="lazy"/>{section.image!.caption && <figcaption>{section.image!.caption}</figcaption>}</figure>
  }
  return <section id={section.id} className="guide-intro">
    <span className="guide-section-number">{section.number}</span>
    <div><span className="eyebrow">{section.eyebrow}</span><h2>{section.heading}</h2>{section.lede && <p className="guide-lede">{section.lede}</p>}{section.copy?.map((p, i) => <p key={i}>{p}</p>)}</div>
  </section>
}

export function BlogEditorialPage({ item, allBlogs }: { item: Blog; allBlogs: Blog[] }) {
  const cms = usePresentation("blog-detail")

  const editorial = item.editorial!
  const { currency, locale } = useLocale()
  const adAr = locale === 'ar'
  const related = allBlogs.filter((blog) => blog.isPublished !== false && blog.slug !== item.slug).slice(0, 3)
  // VIP card context comes from the story's own editorial configuration.
  // The lookup base is built from the configured slug itself (it may point
  // at a featured-only tour outside the curated catalogue subsets), so the
  // link and price resolve to the live DB record: static catalogue data
  // renders first, then upgrades to the database price when it arrives.
  const vipTourSlug = editorial.sidebarAction?.tourSlug
  const vipTourBase = useMemo(() => (vipTourSlug ? getToursBySlugs([vipTourSlug]) : []), [vipTourSlug])
  const vipTour = vipTourSlug ? useDbTours(vipTourBase, { includeNew: true }).find((tour) => tour.slug === vipTourSlug) : undefined
  const heroImage = editorial.heroImage || item.image
  const heroAlt = editorial.heroAlt || item.title
  const checklistAnchor = !editorial.tips?.length && editorial.sidebarLinks?.some((link) => link.href === '#tips') ? 'tips' : 'checklist'
  const [activeSection, setActiveSection] = useState<string>('')

  useEffect(() => {
    if (!editorial.sidebarLinks || !editorial.sidebarLinks.length) return
    const ids = editorial.sidebarLinks.map((l) => l.href.replace('#', ''))
    const targets = ids.map((id) => document.getElementById(id)).filter(Boolean) as HTMLElement[]
    if (!targets.length) return
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id)
            break
          }
        }
      },
      { rootMargin: '-20% 0px -60% 0px', threshold: 0 }
    )
    targets.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [editorial.sidebarLinks])

  return <SiteShell>
    <div className="guide-breadcrumb"><div className="container"><Link href="/">{cms.text("presentation","description0",tx(locale, { en: 'Home', es: 'Inicio', it: 'Home', ar: 'الرئيسية' }))}</Link><span>›</span><Link href="/blogs">{cms.text("presentation","description1",tx(locale, { en: 'Blogs', es: 'Blog', it: 'Blog', ar: 'المدونة' }))}</Link><span>›</span><strong>{item.title}</strong></div></div>
    <main className="guide-page">
      <header className="guide-hero">
        <img src={heroImage} alt={heroAlt} />
        <div className="guide-hero-shade" />
        <div className="container guide-hero-content">
          <div className="guide-meta"><span>{item.category}</span><span>{item.date}</span>{editorial.readTime && <span>{editorial.readTime}</span>}</div>
          <h1>{item.title}</h1>
          <p>{item.excerpt} {editorial.heroDescription}</p>
        </div>
      </header>

      {editorial.facts && editorial.facts.length > 0 && <section className="guide-facts" aria-label="At a glance">
        <div className="container guide-facts-inner">{editorial.facts.map(({ icon, label, value }) => {
          const Icon = guideIconMap[icon] || Compass
          return <div key={label}><Icon size={22} aria-hidden="true"/><span><small>{label}</small><strong>{value}</strong></span></div>
        })}</div>
      </section>}

      <div className="container guide-layout">
        <aside className="guide-sidebar">
          {editorial.sidebarLinks && editorial.sidebarLinks.length > 0 && <nav aria-label="In this guide"><strong>{cms.text("presentation","description2",tx(locale, { en: 'In this guide', es: 'En esta guía', it: 'In questa guida', ar: 'في هذا الدليل' }))}</strong>{editorial.sidebarLinks.map((link) => <a key={link.href} href={link.href} className={activeSection === link.href.replace('#', '') ? 'active' : ''}>{link.label}</a>)}</nav>}
          {editorial.sidebarAction && <div className="guide-side-action"><span>{editorial.sidebarAction.label}</span><strong>{editorial.sidebarAction.heading}</strong><Link href={`/all-tours/${editorial.sidebarAction.tourSlug}`}>{cms.text("presentation","description3",tx(locale, { en: 'View the tour', es: 'Ver la excursión', it: 'Vedi il tour', ar: 'استعرض الرحلة' }))} <ArrowRight size={15}/></Link></div>}
          <CampaignPlacementSlot placement="blog-sidebar"/>
        </aside>

        <article className="guide-story">
          {editorial.sections?.map((section) => <GuideSection key={section.id} section={section} tips={editorial.tips} />)}

          {editorial.quote && <blockquote className="guide-quote"><span aria-hidden="true">{'\u201C'}</span><p>{editorial.quote}</p></blockquote>}

          {editorial.wideImage && <figure className="guide-wide-image"><img src={editorial.wideImage.src} alt={editorial.wideImage.alt} loading="lazy"/>{editorial.wideImage.caption && <figcaption>{editorial.wideImage.caption}</figcaption>}</figure>}

          {editorial.checklist && editorial.checklist.length > 0 && <PresentationSection pageId="blog-detail" id="guide-checklist"><section id={checklistAnchor} className="guide-checklist">
            <div><span className="guide-section-number">{String((editorial.sections?.length || 0) + 1).padStart(2, '0')}</span><span className="eyebrow">{editorial.checklistEyebrow || cms.text("guide-checklist","description0",tx(locale, { en: 'Before you go', es: 'Antes de viajar', it: 'Prima di partire', ar: 'قبل السفر' }))}</span><h2>{editorial.checklistHeading || cms.text("guide-checklist","description1",tx(locale, { en: 'Your trip, simplified', es: 'Tu viaje, simplificado', it: 'Il tuo viaggio, semplificato', ar: 'رحلتك ببساطة' }))}</h2></div>
            <ul>{editorial.checklist.map((item, i) => <li key={i}><Check size={17}/><span><strong>{item.title}</strong>{item.detail}</span></li>)}</ul>
          </section></PresentationSection>}
        </article>
      </div>

      {editorial.cta && <PresentationSection pageId="blog-detail" id="guide-cta"><section className="guide-cta">
        <img src={heroImage} alt={heroAlt} loading="lazy"/>
        <div className="guide-cta-shade"/>
        <div className="container guide-cta-content">
          <span>{editorial.cta.eyebrow}</span>
          <h2>{editorial.cta.heading}</h2>
          <p>{editorial.cta.copy}</p>
          <div>
            {editorial.cta.tourSlug && <Link href={`/all-tours/${editorial.cta.tourSlug}`} className="primary-btn">{editorial.cta.tourLabel || 'View the tour'} <ArrowRight size={17}/></Link>}
            <CmsPublicLink href={cms.link("guide-cta","links0","/make-your-trip")} className="guide-cta-link">{editorial.cta.customLabel || 'Build my own trip'}</CmsPublicLink>
          </div>
        </div>
      </section></PresentationSection>}

      <PresentationSection pageId="blog-detail" id="guide-related"><section className="container guide-related"><div className="guide-related-head"><div><span className="eyebrow">{cms.text("guide-related","description0",tx(locale, { en: 'Keep exploring', es: 'Sigue explorando', it: 'Continua a esplorare', ar: 'واصل الاستكشاف' }))}</span><h2>{cms.text("guide-related","description1",tx(locale, { en: 'More stories from Egypt', es: 'Más historias de Egipto', it: 'Altre storie dall\'Egitto', ar: 'قصص أخرى من مصر' }))}</h2></div><CmsPublicLink href={cms.link("guide-related","links0","/blogs")}>{cms.text("guide-related","description2",tx(locale, { en: 'All travel stories', es: 'Todas las historias de viaje', it: 'Tutte le storie di viaggio', ar: 'كل قصص السفر' }))} <ArrowRight size={16}/></CmsPublicLink></div><div className="guide-related-grid">{related.map((blog) => <article key={blog.slug}><Link href={`/blogs/${blog.slug}`}><img src={blog.image} alt={blog.title} loading="lazy"/></Link><small>{blog.category}</small><h3><Link href={`/blogs/${blog.slug}`}>{blog.title}</Link></h3><p>{blog.excerpt}</p></article>)}</div></section></PresentationSection>
    </main>
  </SiteShell>
}

export function BlogDetailPage({ slug, initialBlogs }: { slug: string; initialBlogs: Blog[] }) {
  const liveBlogs = useDbBlogs(initialBlogs)
  const item = liveBlogs.find((blog) => blog.slug === slug)
  const { locale } = useLocale()
  const ar = locale === 'ar'
  if (!item) return <DetailNotFound title={tx(locale, { en: 'Story not found', es: 'Historia no encontrada', it: 'Storia non trovata', ar: 'القصة غير موجودة' })} copy={tx(locale, { en: 'The story you were looking for has taken a different route.', es: 'La historia que buscabas ha tomado otro camino.', it: 'La storia che cercavi ha preso un\'altra strada.', ar: 'القصة التي تبحث عنها سلكت طريقًا آخر.' })} backHref="/blogs" backLabel={tx(locale, { en: 'Read all stories', es: 'Lee todas las historias', it: 'Leggi tutte le storie', ar: 'اقرأ كل القصص' })}/>
  if (item.isPublished === false) return <SiteShell><main className="container section"><div className="account-empty blog-hidden-card" role="status"><span className="blog-hidden-ic" aria-hidden="true"><EyeOff size={22} /></span><h1>{tx(locale, { en: 'This story is currently unavailable', es: 'Esta historia no está disponible ahora mismo', it: 'Questa storia non è al momento disponibile', ar: 'هذا المقال غير متاح حاليًا' })}</h1><p>{tx(locale, { en: 'Browse our other published stories and travel guides.', es: 'Descubre nuestras otras historias publicadas y guías de viaje.', it: 'Scopri le nostre altre storie pubblicate e guide di viaggio.', ar: 'تصفح مقالاتنا المنشورة وأدلة السفر الأخرى.' })}</p><Link href="/blogs" className="primary-btn">{tx(locale, { en: 'Read all stories', es: 'Lee todas las historias', it: 'Leggi tutte le storie', ar: 'اقرأ كل القصص' })}</Link></div></main></SiteShell>
  if (item.editorial) return <BlogEditorialPage item={item} allBlogs={liveBlogs}/>
  return <SiteShell><Breadcrumb items={[tx(locale, { en: 'Blogs', es: 'Blog', it: 'Blog', ar: 'المدونة' }),item.title]}/><main className="article-page container"><div className="article-header"><span className="eyebrow">{item.category}, {item.date}</span><h1>{item.title}</h1><p>{item.excerpt}</p></div>{item.image && <img className="article-cover" src={item.image} alt={item.title}/>}<div className="article-body"><p>{item.excerpt}</p><Link href="/blogs" className="primary-btn">{tx(locale, { en: 'Read all stories', es: 'Lee todas las historias', it: 'Leggi tutte le storie', ar: 'اقرأ كل القصص' })} <ArrowRight size={16}/></Link></div></main></SiteShell>
}

/** Legacy aliases now backed by the structured helpers in `@/lib/events`. */
function parseEventRange(date: string): { start: Date | null; end: Date | null } {
  return parseLegacyEventRange(date)
}

function eventStatus(end: Date | null, locale: Locale, timestamp = Date.now()): string | null {
  if (!end) return null
  const today = new Date(timestamp)
  today.setHours(0, 0, 0, 0)
  return end >= today ? tx(locale, { en: 'Upcoming', es: 'Próximo', it: 'In arrivo', ar: 'قادم' }) : tx(locale, { en: 'Past', es: 'Finalizado', it: 'Concluso', ar: 'انتهى' })
}

const EVENT_IMAGE_FALLBACK = '/placeholder.jpg'

function eventImageSrc(image: string | undefined): string {
  return image && image.trim() ? image : EVENT_IMAGE_FALLBACK
}

function onEventImageError(e: React.SyntheticEvent<HTMLImageElement>) {
  const el = e.currentTarget
  if (!el.src.endsWith('/placeholder.jpg')) el.src = '/placeholder.jpg'
}

export function EventCard({ item }: { item: Event }) {
  const { locale } = useLocale()
  const ar = locale === 'ar'
  const range = resolveEventRange(item)
  const badge = range.start ? { day: String(range.start.getDate()).padStart(2, '0'), mon: range.start.toLocaleString(locale === 'ar' ? 'ar-EG' : locale === 'es' ? 'es-ES' : locale === 'it' ? 'it-IT' : 'en-US', { month: 'short' }) } : null
  const status = getEventStatus(item)
  const statusLabel = eventStatusLabel(status, locale)
  const title = (locale === 'ar' ? item.titleAr : undefined) || item.title
  const copy = (locale === 'ar' ? item.copyAr : undefined) || item.copy
  const venue = (locale === 'ar' ? item.locationAr : undefined) || eventCity(item)
  const category = (locale === 'ar' ? item.categoryAr : undefined) || item.category
  return <article className="event-card">
    <Link href={`/events/${item.slug}`} className="event-card-img" aria-label={title}>
      <img src={eventImageSrc(item.image)} alt={title} loading="lazy" onError={onEventImageError} />
      {badge && <span className="event-date-badge"><b>{badge.day}</b><small>{badge.mon}</small></span>}
      {statusLabel && <span className={`event-card-status is-${status}`}>{statusLabel}</span>}
    </Link>
    <div className="event-card-body">
      <p className="event-card-date"><CalendarDays size={14} />{item.date}</p>
      {category && <p className="event-card-category">{category}</p>}
      <h3><Link href={`/events/${item.slug}`}>{title}</Link></h3>
      <p className="event-card-venue"><MapPin size={14} />{venue}</p>
      <p>{copy}</p>
      <p className="event-card-price">{eventPriceLabel(item, locale)}</p>
      <Link href={`/events/${item.slug}`} className="event-card-cta">{tx(locale, { en: 'Details & request', es: 'Detalles y solicitud', it: 'Dettagli e richiesta', ar: 'التفاصيل وطلب الحضور' })} <ArrowRight size={15} /></Link>
    </div>
  </article>
}

export function EventsPage() {
  return <SiteShell><EventsPageContent /></SiteShell>
}

const EVENTS_PAGE_SIZE = 6

function EventsPageContent() {
  const { locale } = useLocale()
  const heroState = useShowcaseHero()
  const heroContent = heroState?.content
  const heroText = heroContent && locale !== 'ar' ? heroContent.text[locale] : {}
  const ar = locale === 'ar'
  const liveEvents = useDbEvents(events)
  const published = useMemo(() => getPublishedEvents(liveEvents), [liveEvents])
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('all')
  const [city, setCity] = useState('all')
  const [state, setState] = useState<'all' | 'upcoming' | 'past'>('all')
  const [sort, setSort] = useState<'soonest' | 'latest' | 'name'>('soonest')
  const [page, setPage] = useState(1)

  const categories = useMemo(() => [...new Set(published.map((e) => ((locale === 'ar' ? e.categoryAr : undefined) || e.category)).filter(Boolean))] as string[], [published, ar])
  const cities = useMemo(() => [...new Set(published.map((e) => eventCity({ city: (locale === 'ar' ? e.cityAr : undefined) ?? e.city, location: (locale === 'ar' ? e.locationAr : undefined) ?? e.location })))].filter(Boolean), [published, ar])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    const now = Date.now()
    const rows = published.filter((item) => {
      const title = (locale === 'ar' ? item.titleAr : undefined) || item.title
      const copy = (locale === 'ar' ? item.copyAr : undefined) || item.copy
      if (q && !`${title} ${copy} ${item.location} ${item.city ?? ''} ${item.category ?? ''}`.toLowerCase().includes(q)) return false
      const itemCategory = (locale === 'ar' ? item.categoryAr : undefined) || item.category
      if (category !== 'all' && itemCategory !== category) return false
      const itemCity = eventCity({ city: (locale === 'ar' ? item.cityAr : undefined) ?? item.city, location: (locale === 'ar' ? item.locationAr : undefined) ?? item.location })
      if (city !== 'all' && itemCity !== city) return false
      const st = getEventStatus(item, now)
      if (state === 'upcoming' && !(st === 'upcoming' || st === 'ongoing')) return false
      if (state === 'past' && st !== 'past') return false
      return true
    })
    const withTime = rows.map((item) => ({ item, t: resolveEventRange(item).start?.getTime() ?? Number.MAX_SAFE_INTEGER }))
    if (sort === 'name') withTime.sort((a, b) => ((locale === 'ar' ? a.item.titleAr : undefined) || a.item.title).localeCompare(((locale === 'ar' ? b.item.titleAr : undefined) || b.item.title), locale === 'ar' ? 'ar' : locale === 'es' ? 'es' : locale === 'it' ? 'it' : 'en'))
    else if (sort === 'latest') withTime.sort((a, b) => b.t - a.t)
    else withTime.sort((a, b) => a.t - b.t)
    return withTime.map((r) => r.item)
  }, [published, query, category, city, state, sort, ar])

  const now = Date.now()
  const upcomingCount = published.filter((e) => { const s = getEventStatus(e, now); return s === 'upcoming' || s === 'ongoing' }).length
  const cityCount = new Set(published.map((e) => eventCity(e))).size
  const sortedAll = useMemo(() => [...published].map((item) => ({ item, t: resolveEventRange(item).start?.getTime() ?? Number.MAX_SAFE_INTEGER })).sort((a, b) => a.t - b.t), [published])
  const featured = sortedAll.find(({ item }) => { const s = getEventStatus(item, now); return s === 'upcoming' || s === 'ongoing' })?.item ?? sortedAll[0]?.item

  useEffect(() => { setPage(1) }, [query, category, city, state, sort])
  const pageCount = Math.max(1, Math.ceil(filtered.length / EVENTS_PAGE_SIZE))
  const safePage = Math.min(page, pageCount)
  const pageRows = filtered.slice((safePage - 1) * EVENTS_PAGE_SIZE, safePage * EVENTS_PAGE_SIZE)

  return <main>
    {!heroState?.hidden && !heroState?.unavailable && <section className="events-page-hero">
      {heroContent?.image || heroContent?.mobileImage ? <picture>{heroContent.mobileImage && <source media="(max-width: 760px)" srcSet={heroContent.mobileImage} />}<img className="hero-bg-img" src={heroContent.image || (featured ? eventImageSrc(featured.image) : EVENT_IMAGE_FALLBACK)} alt={locale !== 'ar' ? heroContent.alt[locale] : ''} onError={onEventImageError} style={heroContent.position !== 'source' ? { objectPosition: heroContent.position } : undefined} /></picture> : <img src={featured ? eventImageSrc(featured.image) : EVENT_IMAGE_FALLBACK} alt={heroContent && locale !== 'ar' ? heroContent.alt[locale] : ''} onError={onEventImageError} style={heroContent && heroContent.position !== 'source' ? { objectPosition: heroContent.position } : undefined} />}
      <div className="events-page-hero-shade" style={heroContent?.overlay != null ? { background: `rgba(10,32,76,${heroContent.overlay})` } : undefined} />
      <div className="container events-page-hero-content">
        <div className="events-page-hero-copy">
          <span className="eyebrow">{heroText.eyebrow ?? tx(locale, { en: 'Egypt events calendar', es: 'Calendario de eventos de Egipto', it: 'Calendario eventi dell\'Egitto', ar: 'أجندة فعاليات مصر' })}</span>
          <h1>{heroText.title ?? tx(locale, { en: 'Egypt events & seasonal journeys', es: 'Eventos y viajes de temporada en Egipto', it: 'Eventi e viaggi stagionali in Egitto', ar: 'فعاليات ورحلات موسمية تستحق السفر' })}</h1>
          <p>{heroText.intro ?? tx(locale, { en: 'Celebrations, cultural escapes, and limited-time experiences shaped around Egypt at its most alive.', es: 'Celebraciones, escapadas culturales y experiencias por tiempo limitado en torno al Egipto más vibrante.', it: 'Celebrazioni, fughe culturali ed esperienze a tempo limitato intorno all\'Egitto più vivo.', ar: 'احتفالات وعطلات ثقافية وتجارب محدودة التوقيت، مرتبة لتعيش مصر في أكثر لحظاتها حيوية.' })}</p>
          <div className="events-page-hero-actions">
            <a href={heroContent?.links.primaryHref ?? "#events-list"} className="primary-btn">{heroText.primaryLabel ?? tx(locale, { en: 'Explore upcoming events', es: 'Descubre los próximos eventos', it: 'Scopri i prossimi eventi', ar: 'استكشف الفعاليات' })} <ArrowRight size={17} /></a>
            {featured && <Link href={`/events/${featured.slug}`} className="events-hero-link">{heroText.secondaryLabel ?? tx(locale, { en: 'View the next event', es: 'Ver el próximo evento', it: 'Vedi il prossimo evento', ar: 'تفاصيل الفعالية القادمة' })} <ArrowRight size={16} /></Link>}
          </div>
        </div>
        <div className="events-hero-rail">
          {featured ? <Link href={`/events/${featured.slug}`} className="events-next-event">
            <span>{heroText.railLabel ?? tx(locale, { en: 'Next event', es: 'Próximo evento', it: 'Prossimo evento', ar: 'الفعالية القادمة' })}</span>
            <strong>{(locale === 'ar' ? featured.titleAr : undefined) || featured.title}</strong>
            <small><CalendarDays size={14} />{featured.date}<i aria-hidden="true"/><MapPin size={14} />{(locale === 'ar' ? featured.locationAr : undefined) || featured.location}</small>
          </Link> : <p className="events-next-empty">{tx(locale, { en: 'No published events right now.', es: 'No hay eventos publicados ahora mismo.', it: 'Nessun evento pubblicato al momento.', ar: 'لا توجد فعاليات منشورة حاليًا.' })}</p>}
          <div className="events-hero-stats" aria-label={heroText.statsLabel ?? tx(locale, { en: 'Events summary', es: 'Resumen de eventos', it: 'Riepilogo eventi', ar: 'ملخص الفعاليات' })}>
            <span><b>{upcomingCount}</b>{heroText.stat0 ?? tx(locale, { en: 'Upcoming events', es: 'Próximos eventos', it: 'Prossimi eventi', ar: 'فعاليات قادمة' })}</span>
            <span><b>{cityCount}</b>{heroText.stat1 ?? tx(locale, { en: 'Egyptian cities', es: 'Ciudades egipcias', it: 'Città egiziane', ar: 'مدن مصرية' })}</span>
          </div>
        </div>
      </div>
    </section>}
    <div id="events-list" className="section container">
      {published.length === 0 ? (
        <div className="account-empty events-empty" role="status">
          <h3>{tx(locale, { en: 'No published events right now', es: 'Sin eventos publicados ahora mismo', it: 'Nessun evento pubblicato al momento', ar: 'لا توجد فعاليات منشورة حاليًا' })}</h3>
          <p>{tx(locale, { en: 'Check back soon for upcoming events across Egypt.', es: 'Vuelve pronto para ver los próximos eventos en Egipto.', it: 'Torna presto per i prossimi eventi in Egitto.', ar: 'تابعنا قريبًا لاكتشاف أجندة الفعاليات القادمة في مصر.' })}</p>
          <Link href="/make-your-trip" className="primary-btn">{tx(locale, { en: 'Make your trip', es: 'Crea tu viaje', it: 'Crea il tuo viaggio', ar: 'خطط رحلتك' })} <ArrowRight size={17} /></Link>
        </div>
      ) : (
        <>
          <div className="events-discovery" role="search" aria-label={tx(locale, { en: 'Search events', es: 'Buscar eventos', it: 'Cerca eventi', ar: 'البحث في الفعاليات' })}>
            <label className="events-discovery-search"><Search size={17} /><input value={query} onChange={(e) => setQuery(e.target.value.slice(0, 120))} placeholder={tx(locale, { en: 'Search events or cities...', es: 'Busca eventos o ciudades...', it: 'Cerca eventi o città...', ar: 'ابحث عن فعالية أو مدينة...' })} aria-label={tx(locale, { en: 'Search', es: 'Buscar', it: 'Cerca', ar: 'بحث' })} /></label>
            <div className="events-discovery-filters">
              <label>{tx(locale, { en: 'Category', es: 'Categoría', it: 'Categoria', ar: 'التصنيف' })}<SharedSelect value={category} onChange={setCategory} locale={locale} options={[{ value: 'all', label: tx(locale, { en: 'All categories', es: 'Todas las categorías', it: 'Tutte le categorie', ar: 'كل التصنيفات' }) }, ...categories.map((c) => ({ value: c, label: c }))]} /></label>
              <label>{tx(locale, { en: 'City', es: 'Ciudad', it: 'Città', ar: 'المدينة' })}<SharedSelect value={city} onChange={setCity} locale={locale} options={[{ value: 'all', label: tx(locale, { en: 'All cities', es: 'Todas las ciudades', it: 'Tutte le città', ar: 'كل المدن' }) }, ...cities.map((c) => ({ value: c, label: c }))]} /></label>
              <label>{tx(locale, { en: 'Status', es: 'Estado', it: 'Stato', ar: 'الحالة' })}<SharedSelect value={state} onChange={(next) => setState(next as typeof state)} locale={locale} options={[{ value: 'all', label: tx(locale, { en: 'All', es: 'Todos', it: 'Tutti', ar: 'الكل' }) }, { value: 'upcoming', label: tx(locale, { en: 'Upcoming', es: 'Próximos', it: 'Prossimi', ar: 'القادمة' }) }, { value: 'past', label: tx(locale, { en: 'Past', es: 'Pasados', it: 'Passati', ar: 'السابقة' }) }]} /></label>
              <label>{tx(locale, { en: 'Sort', es: 'Ordenar', it: 'Ordina', ar: 'الترتيب' })}<SharedSelect value={sort} onChange={(next) => setSort(next as typeof sort)} locale={locale} options={[{ value: 'soonest', label: tx(locale, { en: 'Soonest', es: 'Más próximos', it: 'I più vicini', ar: 'الأقرب' }) }, { value: 'latest', label: tx(locale, { en: 'Latest', es: 'Más lejanos', it: 'I più lontani', ar: 'الأبعد' }) }, { value: 'name', label: tx(locale, { en: 'Name', es: 'Nombre', it: 'Nome', ar: 'الاسم' }) }]} /></label>
            </div>
          </div>
          <p className="events-results-count" role="status">{tx(locale, { en: `${filtered.length} event${filtered.length === 1 ? '' : 's'}`, es: `${filtered.length} evento${filtered.length === 1 ? '' : 's'}`, it: `${filtered.length} evento${filtered.length === 1 ? '' : 'i'}`, ar: `${filtered.length} فعالية` })}</p>
          {pageRows.length ? <div className="event-grid">{pageRows.map((item) => <EventCard item={item} key={item.slug} />)}</div> : (
            <div className="account-empty events-empty" role="status">
              <h3>{tx(locale, { en: 'No matching events', es: 'Sin eventos coincidentes', it: 'Nessun evento corrispondente', ar: 'لا توجد نتائج مطابقة' })}</h3>
              <p>{tx(locale, { en: 'Try changing the search or filters.', es: 'Prueba a cambiar la búsqueda o los filtros.', it: 'Prova a modificare la ricerca o i filtri.', ar: 'جرب تغيير البحث أو الفلاتر.' })}</p>
              <button type="button" className="primary-btn" onClick={() => { setQuery(''); setCategory('all'); setCity('all'); setState('all') }}>{tx(locale, { en: 'Reset filters', es: 'Restablecer filtros', it: 'Reimposta filtri', ar: 'إعادة التعيين' })}</button>
            </div>
          )}
          {pageCount > 1 && <nav className="pagination" aria-label={tx(locale, { en: 'Events pages', es: 'Páginas de eventos', it: 'Pagine eventi', ar: 'صفحات الفعاليات' })}>{Array.from({ length: pageCount }, (_, i) => i + 1).map((n) => <button key={n} type="button" disabled={n === safePage} onClick={() => setPage(n)} aria-current={n === safePage ? 'page' : undefined}>{n}</button>)}</nav>}
        </>
      )}
    </div>
  </main>
}

export function EventDetailPage({ slug }: { slug: string }) {
  const cms = usePresentation("event-detail")

  const { locale } = useLocale()
  const ar = locale === 'ar'
  const liveEvents = useDbEvents(events)
  const item = liveEvents.find((e) => e.slug === slug)
  const [now, setNow] = useState<number | null>(null)
  const [shared, setShared] = useState(false)
  const range = resolveEventRange({ startDate: item?.startDate, endDate: item?.endDate, date: item?.date ?? '' })
  const rangeKey = range.start?.getTime() ?? 0
  useEffect(() => {
    if (!rangeKey) return
    setNow(Date.now())
    const id = window.setInterval(() => setNow(Date.now()), 1000)
    return () => window.clearInterval(id)
  }, [rangeKey])
  if (!item) return <DetailNotFound title={tx(locale, { en: 'Event not found', es: 'Evento no encontrado', it: 'Evento non trovato', ar: 'الفعالية غير موجودة' })} copy={tx(locale, { en: 'The event you were looking for has taken a different route.', es: 'El evento que buscabas ha tomado otro camino.', it: 'L\'evento che cercavi ha preso un\'altra strada.', ar: 'الفعالية التي تبحث عنها سلكت طريقًا آخر.' })} backHref="/events" backLabel={tx(locale, { en: 'See all events', es: 'Ver todos los eventos', it: 'Vedi tutti gli eventi', ar: 'شاهد كل الفعاليات' })}/>
  if (item.isPublished === false) return <SiteShell><main className="container section"><div className="account-empty" role="status"><h1>{cms.text("presentation","description0",tx(locale, { en: 'This event is currently hidden', es: 'Este evento está oculto ahora mismo', it: 'Questo evento è attualmente nascosto', ar: 'هذه الفعالية مخفية حاليًا' }))}</h1><p>{cms.text("presentation","description1",tx(locale, { en: 'Browse the other published events.', es: 'Descubre los otros eventos publicados.', it: 'Scopri gli altri eventi pubblicati.', ar: 'تصفح الفعاليات المنشورة الأخرى.' }))}</p><Link href="/events" className="primary-btn">{cms.text("presentation","description2",tx(locale, { en: 'See all events', es: 'Ver todos los eventos', it: 'Vedi tutti gli eventi', ar: 'شاهد كل الفعاليات' }))}</Link></div></main></SiteShell>
  const title = (locale === 'ar' ? item.titleAr : undefined) || item.title
  const copy = (locale === 'ar' ? item.copyAr : undefined) || item.copy
  const intro = (locale === 'ar' ? item.introAr : undefined) || (item.intro ?? copy)
  const venue = (locale === 'ar' ? item.locationAr : undefined) || item.location
  const category = (locale === 'ar' ? item.categoryAr : undefined) || item.category
  const included = ar && item.includedAr?.length ? item.includedAr : item.included
  const excluded = ar && item.excludedAr?.length ? item.excludedAr : item.excluded
  const status = getEventStatus(item, now ?? Date.now())
  const statusLabel = now === null ? null : eventStatusLabel(status, locale)
  const msLeft = range.start && now !== null ? Math.max(0, range.start.getTime() - now) : 0
  const cd = [Math.floor(msLeft / 86400000), Math.floor(msLeft / 3600000) % 24, Math.floor(msLeft / 60000) % 60, Math.floor(msLeft / 1000) % 60]
  const cdLabels = locale === 'ar' ? ['أيام', 'ساعات', 'دقائق', 'ثوانٍ'] : locale === 'es' ? ['Días', 'Horas', 'Min', 'Seg'] : locale === 'it' ? ['Giorni', 'Ore', 'Min', 'Sec'] : ['Days', 'Hours', 'Mins', 'Secs']
  const related = getRelatedEvents(item, getPublishedEvents(liveEvents), 2)
  const hasProgram = Boolean(item.program?.length)
  const mapQ = eventMapQuery(item)
  const timeLine = [item.startTime, item.endTime].filter(Boolean).join(' - ')
  const share = async () => {
    const url = typeof window !== 'undefined' ? window.location.href : `/events/${item.slug}`
    try {
      if (navigator.share) { await navigator.share({ title, url }) ; return }
      await navigator.clipboard.writeText(url)
    } catch { try { await navigator.clipboard.writeText(url) } catch { /* clipboard unavailable */ } }
    setShared(true)
    window.setTimeout(() => setShared(false), 2000)
  }
  return <SiteShell><main className="event-detail-page">
    <Breadcrumb items={[cms.text("presentation","description3",tx(locale, { en: 'Events', es: 'Eventos', it: 'Eventi', ar: 'الفعاليات' })), title]} />
    <section className="event-detail-hero container">
      <img src={eventImageSrc(item.image)} alt={title} onError={onEventImageError} />
      <div className="event-detail-shade" />
      <div className="event-detail-content">
        <div className="event-detail-main">
          <span className="event-detail-kicker"><Ticket size={15}/>{category ?? (tx(locale, { en: 'Seasonal event', es: 'Evento de temporada', it: 'Evento stagionale', ar: 'فعالية موسمية' }))}</span>
          <h1>{title}</h1>
          <p>{intro}</p>
          <div className="event-detail-pills"><span><CalendarDays size={15} />{item.date}</span><span><MapPin size={15} />{venue}</span>{timeLine && <span><Clock3 size={15} />{timeLine}</span>}<span className="event-price-pill">{eventPriceLabel(item, locale)}</span>{statusLabel && <span className="event-status">{statusLabel}</span>}</div>
          <div className="event-detail-actions"><a href="#event-book" className="primary-btn">{tx(locale, { en: 'Request your place', es: 'Reserva tu plaza', it: 'Richiedi il tuo posto', ar: 'اطلب مكانك' })} <ArrowRight size={17} /></a>{hasProgram && <a href="#event-program" className="event-detail-text-link">{tx(locale, { en: 'Explore the program', es: 'Descubre el programa', it: 'Scopri il programma', ar: 'شاهد البرنامج' })} <ArrowRight size={16}/></a>}<button type="button" className="event-detail-text-link event-share-btn" onClick={share} aria-live="polite"><Share2 size={16} />{shared ? (tx(locale, { en: 'Link copied', es: 'Enlace copiado', it: 'Link copiato', ar: 'تم نسخ الرابط' })) : (tx(locale, { en: 'Share', es: 'Compartir', it: 'Condividi', ar: 'مشاركة' }))}</button></div>
        </div>
        <aside className="event-hero-summary" aria-label={tx(locale, { en: 'Event at a glance', es: 'El evento en resumen', it: 'L\'evento in breve', ar: 'ملخص الفعالية' })}>
          <span>{tx(locale, { en: 'Event at a glance', es: 'El evento en resumen', it: 'L\'evento in breve', ar: 'ملخص الفعالية' })}</span>
          <dl>
            <div><dt><CalendarDays size={17}/>{tx(locale, { en: 'When', es: 'Cuándo', it: 'Quando', ar: 'الموعد' })}</dt><dd>{item.date}{timeLine ? ` · ${timeLine}` : ''}</dd></div>
            <div><dt><MapPin size={17}/>{tx(locale, { en: 'Where', es: 'Dónde', it: 'Dove', ar: 'الوجهة' })}</dt><dd>{item.venueName ?? venue}{item.city ? ` · ${(locale === 'ar' ? item.cityAr : undefined) || item.city}` : ''}</dd></div>
            <div><dt><Compass size={17}/>{tx(locale, { en: 'Format', es: 'Formato', it: 'Formato', ar: 'شكل الرحلة' })}</dt><dd>{item.program?.length ?? 0} {tx(locale, { en: 'program chapters', es: 'capítulos del programa', it: 'capitoli del programma', ar: 'محطات في البرنامج' })}</dd></div>
          </dl>
          <Link href="/events">{tx(locale, { en: 'View all events', es: 'Ver todos los eventos', it: 'Vedi tutti gli eventi', ar: 'عرض كل الفعاليات' })} <ArrowRight size={15}/></Link>
        </aside>
      </div>
    </section>
    <div className="container event-layout">
      <div className="event-main">
        <PresentationSection pageId="event-detail" id="event-about"><section className="event-about">
          <span className="eyebrow">{cms.text("event-about","description0",tx(locale, { en: 'About this event', es: 'Sobre este evento', it: 'Su questo evento', ar: 'عن الفعالية' }))}</span>
          <h2>{copy}</h2>
          {intro !== copy && <p className="event-lede">{intro}</p>}
          {item.gallery && item.gallery.length > 0 && <div className="event-gallery" role="list" aria-label={tx(locale, { en: 'Event photos', es: 'Fotos del evento', it: 'Foto dell\'evento', ar: 'صور الفعالية' })}>{item.gallery.map((src) => <img key={src} role="listitem" src={eventImageSrc(src)} alt={title} loading="lazy" onError={onEventImageError} />)}</div>}
        </section></PresentationSection>
        {item.highlights && item.highlights.length > 0 && <PresentationSection pageId="event-detail" id="event-experience"><section className="event-experience">
          <span className="eyebrow">{cms.text("event-experience","description0",tx(locale, { en: 'Why this journey works', es: 'Por qué funciona este viaje', it: 'Perché questo viaggio funziona', ar: 'ليه الرحلة دي مميزة' }))}</span>
          <div className="event-experience-grid">{item.highlights.map((highlight, index) => <article key={highlight.title}><span>{String(index + 1).padStart(2, '0')}</span><Sparkles size={20}/><h3>{(locale === 'ar' ? highlight.titleAr : undefined) || highlight.title}</h3><p>{(locale === 'ar' ? highlight.descriptionAr : undefined) || highlight.description}</p></article>)}</div>
        </section></PresentationSection>}
        {range.start && now !== null && msLeft > 0 && (status === 'upcoming') && <section className="event-countdown-wrap" aria-label={tx(locale, { en: 'Countdown', es: 'Cuenta atrás', it: 'Conto alla rovescia', ar: 'العد التنازلي' })}>
          <span className="eyebrow">{tx(locale, { en: 'Countdown to the event', es: 'Cuenta atrás para el evento', it: 'Conto alla rovescia per l\'evento', ar: 'العد التنازلي لبداية الفعالية' })}</span>
          <div className="event-countdown" role="timer">{cd.map((v, i) => <span key={cdLabels[i]}><b>{String(v).padStart(2, '0')}</b><small>{cdLabels[i]}</small></span>)}</div>
        </section>}
        {hasProgram && <PresentationSection pageId="event-detail" id="event-program"><section id="event-program" className="event-program">
          <span className="eyebrow">{cms.text("event-program","description0",tx(locale, { en: 'Event program', es: 'Programa del evento', it: 'Programma dell\'evento', ar: 'برنامج الفعالية' }))}</span>
          <h2>{cms.text("event-program","description1",tx(locale, { en: 'Day by day', es: 'Día a día', it: 'Giorno per giorno', ar: 'يوم بيوم' }))}</h2>
          <div className="event-program-list">{item.program!.map((d) => <article key={`${d.day}-${d.title}`}><span className="event-program-day">{d.day}</span><div><h3>{d.title}</h3><p>{d.description}</p></div></article>)}</div>
        </section></PresentationSection>}
        {(included?.length || excluded?.length) && <section className="event-inclusions">
          <span className="eyebrow">{tx(locale, { en: 'Included & excluded', es: 'Incluido y no incluido', it: 'Incluso ed escluso', ar: 'المشمول والمستبعد' })}</span>
          <h2>{tx(locale, { en: 'Know exactly what the arrangement covers.', es: 'Descubre exactamente qué cubre la organización.', it: 'Scopri esattamente cosa copre l\'organizzazione.', ar: 'اعرف بالضبط إيه الموجود في الترتيب.' })}</h2>
          <div className="event-inclusion-grid">
            {included && included.length > 0 && <article><h3>{tx(locale, { en: "What's included", es: "Incluido", it: "Incluso", ar: 'مشمول' })}</h3><ul className="check-list">{included.map((x) => <li key={x}><Check size={16} />{x}</li>)}</ul></article>}
            {excluded && excluded.length > 0 && <article><h3>{tx(locale, { en: 'Not included', es: 'No incluido', it: 'Escluso', ar: 'غير مشمول' })}</h3><ul className="excluded-list">{excluded.map((x) => <li key={x}><Minus size={16} />{x}</li>)}</ul></article>}
          </div>
        </section>}
        {item.addOns && item.addOns.length > 0 && <PresentationSection pageId="event-detail" id="event-addons-wrap"><section className="event-addons-wrap">
          <span className="eyebrow">{cms.text("event-addons-wrap","description0",tx(locale, { en: 'Optional add-ons', es: 'Extras opcionales', it: 'Extra facoltativi', ar: 'إضافات اختيارية' }))}</span>
          <h2>{cms.text("event-addons-wrap","description1",tx(locale, { en: 'Enhance your experience', es: 'Mejora tu experiencia', it: 'Arricchisci la tua esperienza', ar: 'زوّد تجربتك' }))}</h2>
          <ul className="event-addons">{item.addOns.map((a) => <li key={a.title}><Plus size={15} />{a.title}{typeof a.price === 'number' ? ` · ${formatCurrency(a.price, item.currency, locale)}` : ''}</li>)}</ul>
        </section></PresentationSection>}
        <section className="event-venue">
          <span className="eyebrow">{tx(locale, { en: 'Venue & area', es: 'Lugar y zona', it: 'Sede e zona', ar: 'مكان الانعقاد' })}</span>
          <h2>{item.venueName ?? venue}</h2>
          {item.address && <p>{(locale === 'ar' ? item.addressAr : undefined) || item.address}</p>}
          <iframe title={tx(locale, { en: `${venue} map`, es: `Mapa de ${venue}`, it: `Mappa di ${venue}`, ar: `خريطة ${venue}` })} src={`https://maps.google.com/maps?q=${encodeURIComponent(mapQ)}&t=&z=11&ie=UTF8&iwloc=&output=embed`} loading="lazy" className="location-map" />
          <p>{tx(locale, { en: 'Attendance requests are preliminary and pending review. No payment or confirmed ticket here.', es: 'Las solicitudes de asistencia son preliminares y están pendientes de revisión. Sin pago ni entrada confirmada aquí.', it: 'Le richieste di partecipazione sono preliminari e in attesa di revisione. Nessun pagamento né biglietto confermato qui.', ar: 'طلب الحضور مبدئي وقيد المراجعة. لا يوجد دفع أو تذكرة مؤكدة هنا.' })}</p>
        </section>
        {(item.organizerName || item.organizerPhone || item.organizerWhatsapp || item.organizerEmail) && <section className="event-organizer">
          <span className="eyebrow">{tx(locale, { en: 'Organizer & contact', es: 'Organizador y contacto', it: 'Organizzatore e contatti', ar: 'المنظم والتواصل' })}</span>
          <h2>{(((locale === 'ar' ? item.organizerNameAr : undefined) || item.organizerName) ?? (tx(locale, { en: 'Contact', es: 'Contacto', it: 'Contatto', ar: 'تواصل' })))}</h2>
          <ul className="event-organizer-list">
            {item.organizerPhone && telLink(undefined, item.organizerPhone) !== '' && <li><Phone size={15} /><a href={telLink(undefined, item.organizerPhone)}>{item.organizerPhone}</a></li>}
            {item.organizerWhatsapp && whatsappLink(undefined, item.organizerWhatsapp) !== '' && <li><MessageCircle size={15} /><a href={whatsappLink(undefined, item.organizerWhatsapp)} target="_blank" rel="noreferrer">WhatsApp</a></li>}
            {item.organizerEmail && <li><Mail size={15} /><a href={`mailto:${item.organizerEmail}`}>{item.organizerEmail}</a></li>}
          </ul>
        </section>}
        {related.length > 0 && <PresentationSection pageId="event-detail" id="event-related"><section className="event-related">
          <div className="section-title-row"><h2>{cms.text("event-related","description0",tx(locale, { en: 'More events', es: 'Más eventos', it: 'Altri eventi', ar: 'فعاليات أخرى' }))}</h2><CmsPublicLink href={cms.link("event-related","links0","/events")} className="text-link">{cms.text("event-related","description1",tx(locale, { en: 'View all', es: 'Ver todo', it: 'Vedi tutto', ar: 'شاهد الكل' }))} <ArrowRight size={15} /></CmsPublicLink></div>
          <div className="event-grid two">{related.map((e) => <EventCard item={e} key={e.slug} />)}</div>
        </section></PresentationSection>}
      </div>
      <aside id="event-book" className="event-book" aria-label={tx(locale, { en: 'Event request', es: 'Solicitud del evento', it: 'Richiesta evento', ar: 'طلب حضور الفعالية' })}>
        <EventRequestForm event={item} />
      </aside>
    </div>
  </main></SiteShell>
}

export function OffersPage() {
  return <SiteShell><OffersPageContent /></SiteShell>
}

function OffersPageContent() {
  const cms = usePresentation("offers")

  const { locale } = useLocale()
  const ar = locale === 'ar'
  const liveTours = useDbTours([], { includeNew: true })
  const dbOffers = placedOffers(useDbOffers([]), 'offers')
  const featured = liveTours.find(tour => dbOffers.some(offer => offer.tourSlug === tour.slug)) ?? liveTours[0]
  const tourOfferCount = dbOffers.filter(offer => offer.tourSlug).length
  const campaignCount = dbOffers.length - tourOfferCount
  return <main className="offers-page"><PresentationOrder pageId="offers">
      {!featured && <EmptyOffersHero />}
      {featured && <PageShowcaseHero image={featured.image} eyebrow={tx(locale, { en: 'Curated Egypt savings', es: 'Ahorros seleccionados en Egipto', it: 'Risparmi selezionati in Egitto', ar: 'توفير مختار بعناية في مصر' })} title={tx(locale, { en: 'Egypt travel offers worth packing for.', es: 'Ofertas de viaje a Egipto por las que merece la pena hacer la maleta.', it: 'Offerte di viaggio in Egitto per cui vale la pena fare le valigie.', ar: 'عروض سفر في مصر تستاهل تجهزلها شنطة.' })} intro={tx(locale, { en: 'More nights, thoughtful extras, and memorable combinations designed to give your Egypt journey more value.', es: 'Más noches, extras con encanto y combinaciones memorables para dar más valor a tu viaje a Egipto.', it: 'Più notti, extra pensati e combinazioni memorabili per dare più valore al tuo viaggio in Egitto.', ar: 'ليالٍ أكثر وإضافات مدروسة وتركيبات لا تُنسى تمنح رحلتك لمصر قيمة أكبر.' })} primaryLabel={tx(locale, { en: 'Explore current offers', es: 'Descubre las ofertas actuales', it: 'Scopri le offerte attuali', ar: 'استكشف العروض الحالية' })} primaryHref="#current-offers" secondaryLabel={tx(locale, { en: 'View the featured package', es: 'Ver el paquete destacado', it: 'Vedi il pacchetto in evidenza', ar: 'شاهد الباقة المميزة' })} secondaryHref={`/all-tours/${featured.slug}`} railLabel={tx(locale, { en: 'Featured package', es: 'Paquete destacado', it: 'Pacchetto in evidenza', ar: 'باقة مميزة' })} railTitle={(locale === 'ar' ? featured.titleAr : undefined) || featured.title} railHref={`/all-tours/${featured.slug}`} railMeta={[{ Icon: Clock3, label: featured.duration }, { Icon: MapPin, label: featured.location }]} statsLabel={tx(locale, { en: 'Offers summary', es: 'Resumen de ofertas', it: 'Riepilogo offerte', ar: 'ملخص العروض' })} stats={[{ value: tourOfferCount, label: tx(locale, { en: 'Tour offers', es: 'Ofertas de viaje', it: 'Offerte tour', ar: 'عروض رحلات' }) }, { value: campaignCount, label: tx(locale, { en: 'Travel campaigns', es: 'Campañas de viaje', it: 'Campagne di viaggio', ar: 'حملات سفر' }) }]}/>}

      <PresentationSection pageId="offers" id="offers-trust"><section className="offers-trust" aria-label={tx(locale, { en: 'Booking benefits', es: 'Ventajas de reservar', it: 'Vantaggi della prenotazione', ar: 'مميزات الحجز' })}>
        <div className="container">{cms.cards("offers-trust").map(({id,title,copy,Icon})=><div key={id}><Icon size={22}/><span><strong>{title}</strong><small>{copy}</small></span></div>)}</div>
      </section></PresentationSection>

      <PresentationSection pageId="offers" id="current-offers"><section id="current-offers" className="offers-current container">
        <header className="offers-section-head">
          <div><span className="eyebrow">{cms.text("current-offers","description0",tx(locale, { en: 'Current opportunities', es: 'Oportunidades actuales', it: 'Opportunità attuali', ar: 'فرص حالية' }))}</span><h2>{cms.text("current-offers","description1",tx(locale, { en: 'Choose the value that fits your journey.', es: 'Elige el valor que encaje con tu viaje.', it: 'Scegli il valore adatto al tuo viaggio.', ar: 'اختر القيمة المناسبة لرحلتك.' }))}</h2></div>
          <p>{cms.text("current-offers","description2",tx(locale, { en: 'Every offer can be shaped around your dates, group, and preferred pace. Ask our team for the exact inclusions before you commit.', es: 'Cada oferta puede adaptarse a tus fechas, tu grupo y tu ritmo. Pregunta a nuestro equipo por las inclusiones exactas antes de decidirte.', it: 'Ogni offerta può essere modellata su date, gruppo e ritmo. Chiedi al nostro team le inclusioni esatte prima di impegnarti.', ar: 'كل عرض يمكن تشكيله حول مواعيدك ومجموعتك وإيقاعك المفضل. اسأل فريقنا عن المشمول الدقيق قبل الحجز.' }))}</p>
        </header>

        <OfferCards placement="offers"/>
      </section></PresentationSection>

      <PresentationSection pageId="offers" id="offers-process"><section className="offers-process">
        <div className="container">
          <header><span className="eyebrow">{cms.text("offers-process","description0",tx(locale, { en: 'Simple and personal', es: 'Sencillo y personal', it: 'Semplice e personale', ar: 'بسيط وشخصي' }))}</span><h2>{cms.text("offers-process","description1",tx(locale, { en: 'From offer to confirmed journey.', es: 'De la oferta al viaje confirmado.', it: 'Dall\'offerta al viaggio confermato.', ar: 'من العرض لرحلة مؤكدة.' }))}</h2></header>
        <div className="offers-process-grid">{cms.cards("offers-process").map(({id,title,copy,number})=><div key={id}><strong>{number}</strong><h3>{title}</h3><p>{copy}</p></div>)}</div>
        </div>
      </section></PresentationSection>

      <PresentationSection pageId="offers" id="offers-final"><section className="offers-final">
        <img src={cms.media("offers-final","media0",siteImages.nile)} alt={cms.text("offers-final","description0",tx(locale, { en: 'A Nile journey through Egypt', es: 'Un viaje por el Nilo en Egipto', it: 'Un viaggio sul Nilo in Egitto', ar: 'رحلة نيلية في مصر' }))} loading="lazy"/>
        <div className="offers-final-shade"/>
        <div className="container offers-final-content">
          <span className="eyebrow">{cms.text("offers-final","description1",tx(locale, { en: 'Need a different kind of value?', es: '¿Buscas otro tipo de valor?', it: 'Cerchi un altro tipo di valore?', ar: 'هل تحتاج إلى نوع مختلف من القيمة؟' }))}</span>
          <h2>{cms.text("offers-final","description2",tx(locale, { en: 'Let us shape an offer around your Egypt plans.', es: 'Diseñemos una oferta en torno a tus planes en Egipto.', it: 'Creiamo un\'offerta intorno ai tuoi piani in Egitto.', ar: 'دعنا نصمم عرضًا حول خططك لمصر.' }))}</h2>
          <p>{cms.text("offers-final","description3",tx(locale, { en: 'Tell us your dates, group size, and wish list. Our travel designers will recommend the best available route and inclusions.', es: 'Cuéntanos tus fechas, el tamaño del grupo y tu lista de deseos. Nuestros diseñadores de viajes te recomendarán la mejor ruta y las mejores inclusiones disponibles.', it: 'Dicci date, numero di partecipanti e desideri: i nostri travel designer consiglieranno il miglior itinerario e le migliori inclusioni disponibili.', ar: 'أخبرنا بمواعيدك وحجم مجموعتك وقائمة أمنياتك. سيرشح لك مصممو رحلاتنا أفضل خط سير ومشمول متاح.' }))}</p>
          <CmsPublicLink href={cms.link("offers-final","links0","/make-your-trip")} className="primary-btn">{cms.text("offers-final","description4",tx(locale, { en: 'Make your trip', es: 'Crea tu viaje', it: 'Crea il tuo viaggio', ar: 'خطط رحلتك' }))} <ArrowRight size={17}/></CmsPublicLink>
        </div>
      </section></PresentationSection>
    </PresentationOrder></main>
}



export function OfferDetailPage({ slug }: { slug: string }) { return <CampaignDetail slug={slug}/> }

export function GuidePage() { const { locale } = useLocale(); const ar = locale === 'ar'; const groups: [string, string, string[]][] = [['Ancient civilization', 'Temples, tombs, and five thousand years of stories.', ['Pharaohs', 'Mythology', 'Pyramids', 'Temples', 'Tombs']], ['Tourist attractions', 'Where to go, city by city.', ['Cairo', 'Luxor', 'Aswan', 'Alexandria', 'Sinai', 'Museums', 'Oases']], ['Travel tips', 'Practical know-how before you fly.', ['Before you travel', 'While you are in Egypt', 'Visas', 'Packing', 'Tipping']], ['Destinations', 'Coasts, deserts, cities, and the Nile.', ['Red Sea', 'White Desert', 'Siwa Oasis', 'Nile Valley']], ['Tour packages', 'How to choose the right format.', ['Classic tours', 'Small groups', 'Honeymoon', 'Adventure', 'Spiritual']], ['Sustainability', 'Travel kindly and leave a positive footprint.', ['Local communities', 'Accessible travel', 'Responsible choices']]]; return <SiteShell><EditorialHero eyebrow={tx(locale, { en: 'Learn before you go', es: 'Aprende antes de viajar', it: 'Impara prima di partire', ar: 'تعلّم قبل أن تسافر' })} title={tx(locale, { en: 'Egypt travel guide', es: 'Guía de viaje de Egipto', it: 'Guida di viaggio dell\'Egitto', ar: 'دليل السفر إلى مصر' })} copy={tx(locale, { en: 'Attractions, tips, destinations, and honest advice for planning a smoother journey.', es: 'Atracciones, consejos, destinos y recomendaciones honestas para planificar un viaje sin contratiempos.', it: 'Attrazioni, consigli, destinazioni e suggerimenti onesti per pianificare un viaggio senza intoppi.', ar: 'معالم ونصائح ووجهات ونصيحة صادقة لرحلة أسهل.' })} image={siteImages.desert} href="/make-your-trip" action={tx(locale, { en: 'Plan my trip', es: 'Planifica mi viaje', it: 'Pianifica il mio viaggio', ar: 'خطط رحلتي' })} /><main className="section container"><div className="faq-list">{groups.map(([title, copy, topics]) => <details className="faq-item" key={title}><summary>{title}</summary><p>{copy}</p><div className="location-stops">{topics.map(t => <span key={t}>{t}</span>)}</div></details>)}</div></main><HelpCTA /></SiteShell> }

export function AccessiblePage() { const { locale } = useLocale(); const ar = locale === 'ar'; return <SiteShell><EditorialHero eyebrow={tx(locale, { en: 'Travel for everyone', es: 'Viajar es para todos', it: 'Viaggiare è per tutti', ar: 'سفر للجميع' })} title={tx(locale, { en: 'Accessible travel in Egypt', es: 'Viajes accesibles en Egipto', it: 'Viaggi accessibili in Egitto', ar: 'سفر ميسّر في مصر' })} copy={tx(locale, { en: 'Extra assistance, adapted pacing, and honest advice so every guest can enjoy Egypt comfortably.', es: 'Asistencia extra, ritmo adaptado y consejos honestos para que cada viajero disfrute Egipto con comodidad.', it: 'Assistenza extra, ritmo adattato e consigli onesti perché ogni ospite possa godersi l\'Egitto comodamente.', ar: 'مساعدة إضافية وإيقاع مكيّف ونصيحة صادقة ليستمتع كل ضيف بمصر براحة.' })} image={siteImages.pyramids} href="/contact" action={tx(locale, { en: 'Ask about assistance', es: 'Pregunta por asistencia', it: 'Chiedi assistenza', ar: 'اسأل عن المساعدة' })} /><main><section className="section container split-editorial"><div><span className="eyebrow">{tx(locale, { en: '5% discount', es: '5 % de descuento', it: 'Sconto del 5%', ar: 'خصم 5%' })}</span><h2>{tx(locale, { en: 'Extra care, on us.', es: 'Cuidado extra, por nuestra cuenta.', it: 'Attenzione extra, da parte nostra.', ar: 'عناية إضافية، علينا.' })}</h2><p>{tx(locale, { en: 'Guests requiring accessibility assistance receive 5% off all our tour packages. Tell us what you need and we will adapt vehicles, pacing, hotel rooms, and sightseeing to match.', es: 'Los viajeros que necesiten asistencia de accesibilidad reciben un 5 % de descuento en todos nuestros paquetes. Cuéntanos lo que necesitas y adaptaremos vehículos, ritmo, habitaciones y visitas.', it: 'Gli ospiti che necessitano assistenza per l\'accessibilità ricevono il 5% di sconto su tutti i pacchetti. Dicci di cosa hai bisogno: adatteremo veicoli, ritmo, camere e visite.', ar: 'ضيوفنا من ذوي الاحتياجات الخاصة يحصلون على خصم 5% على كل البرامج. أخبرنا باحتياجاتك وسنكيّف السيارات والإيقاع والغرف والمزارات.' })}</p><div className="detail-highlights">{(locale === 'ar' ? ['سيارات مجهزة', 'خيارات بدون سلالم', 'مرشدون صبورون ومدربون'] : locale === 'es' ? ['Vehículos adaptados', 'Opciones sin escalones', 'Guías pacientes y formados'] : locale === 'it' ? ['Veicoli adattati', 'Opzioni senza gradini', 'Guide pazienti e formate'] : ['Adapted vehicles', 'Step-free options', 'Patient, trained guides']).map(x => <span key={x}><Check size={16} />{x}</span>)}</div></div><img src={siteImages.temple} alt={tx(locale, { en: 'Accessible travel in Egypt', es: 'Viajes accesibles en Egipto', it: 'Viaggi accessibili in Egitto', ar: 'سفر ميسّر في مصر' })} /></section><HelpCTA /></main></SiteShell> } export function FAQPage({ pageContent }: { pageContent?: PublicPageContent } = {}) { const [open,setOpen] = useState(0); const { locale } = useLocale(); const ar = locale === 'ar'; return <SiteShell><EditorialHero eyebrow={tx(locale, { en: 'Questions, answered', es: 'Preguntas con respuesta', it: 'Domande e risposte', ar: 'أسئلة وإجابات' })} title={tx(locale, { en: 'A smoother way to plan Egypt', es: 'Una forma más fácil de planificar Egipto', it: 'Un modo più semplice per pianificare.', ar: 'خطط لمصر براحة أكبر' })} copy={tx(locale, { en: 'Find clear answers to common questions, then talk to our team when you are ready for the details.', es: 'Encuentra respuestas claras a las preguntas frecuentes y habla con nuestro equipo cuando quieras los detalles.', it: 'Trova risposte chiare alle domande frequenti, poi parla con il nostro team quando vuoi i dettagli.', ar: 'اعثر على إجابات واضحة للأسئلة الشائعة، ثم كلمنا عندما تكون جاهزًا للتفاصيل.' })} image={siteImages.temple} href="/contact" action={tx(locale, { en: 'Ask a question', es: 'Haz una pregunta', it: 'Fai una domanda', ar: 'اسأل سؤالًا' })}/><CmsFaqBody state={pageContent} /></SiteShell> }

export { SearchPage } from '@/components/shared/public-search-page'

export function PolicyPage({ type }: { type: 'privacy' | 'terms' }) { const { locale } = useLocale(); const ar = locale === 'ar'; const title=type==='privacy'?(tx(locale, { en: 'Privacy Policy', es: 'Política de privacidad', it: 'Informativa sulla privacy', ar: 'سياسة الخصوصية' })):(tx(locale, { en: 'Terms and Conditions', es: 'Términos y condiciones', it: 'Termini e condizioni', ar: 'الشروط والأحكام' })); return <SiteShell><Breadcrumb items={[title]}/><main className="policy-page container"><span className="eyebrow">TravNeeds Tours</span><h1>{title}</h1><p className="policy-lede">{tx(locale, { en: 'Clear, respectful, and easy to understand. These notes explain how we work with you.', es: 'Claras, respetuosas y fáciles de entender. Estas notas explican cómo trabajamos contigo.', it: 'Chiare, rispettose e facili da capire. Queste note spiegano come lavoriamo con te.', ar: 'واضحة ومحترمة وسهلة الفهم. هذه الملاحظات تشرح طريقة تعاملنا معك.' })}</p>{policies[type].map(item=><section key={item.h}><h2>{item.h}</h2><p>{item.p}</p></section>)}</main></SiteShell> }
export function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const { locale } = useLocale();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ email: email.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Could not send reset email. Please try again.');
        return;
      }
      setSent(true);
    } catch {
      setError('Could not send reset link. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="auth-v2">
      <section className="auth-v2-visual">
        <img
          src={siteImages.pyramids}
          alt={tx(locale, { en: 'The Pyramids of Giza in Egypt', es: 'Las pirámides de Guiza en Egipto', it: 'Le piramidi di Giza in Egitto', ar: 'أهرامات الجيزة في مصر' })}
        />
        <div className="auth-v2-shade" />
        <div className="auth-v2-visual-content">
          <Logo />
          <div>
            <span>{tx(locale, { en: 'Your TravNeeds account', es: 'Tu cuenta de TravNeeds', it: 'Il tuo account TravNeeds', ar: 'حساب TravNeeds' })}</span>
            <h2>{tx(locale, { en: 'Your next Egypt story, kept in one place.', es: 'Tu próxima historia en Egipto, en un solo lugar.', it: 'La tua prossima storia in Egitto, in un unico posto.', ar: 'كل تفاصيل رحلتك لمصر في مكان واحد.' })}</h2>
            <p>{tx(locale, { en: 'Return to saved trips, continue planning, and keep the details of your journey close.', es: 'Vuelve a tus viajes guardados, sigue planificando y ten los detalles de tu viaje a mano.', it: 'Torna ai viaggi salvati, continua a pianificare e tieni i dettagli del viaggio con te.', ar: 'ارجع لرحلاتك المحفوظة، كمّل التخطيط، وخلي تفاصيل رحلتك قريبة منك.' })}</p>
            <ul>
              <li><Check size={16} />{tx(locale, { en: 'Save tours for later', es: 'Guarda tours para después', it: 'Salva i tour per dopo', ar: 'احفظ الرحلات لوقت لاحق' })}</li>
              <li><Check size={16} />{tx(locale, { en: 'Keep trip enquiries together', es: 'Mantén tus consultas juntas', it: 'Tieni insieme le richieste di viaggio', ar: 'اجمع طلبات الرحلة في مكان واحد' })}</li>
              <li><Check size={16} />{tx(locale, { en: 'Continue planning across devices', es: 'Sigue planificando en todos tus dispositivos', it: 'Continua a pianificare su ogni dispositivo', ar: 'كمّل التخطيط من أي جهاز' })}</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="auth-v2-panel">
        <header className="auth-v2-top">
          <Link
            href="/"
            aria-label={tx(locale, { en: 'Back to home', es: 'Volver al inicio', it: 'Torna alla home', ar: 'العودة للرئيسية' })}
          >
            <ArrowRight size={18} />{tx(locale, { en: 'Home', es: 'Inicio', it: 'Home', ar: 'الرئيسية' })}</Link>
          <LanguageSelector />
        </header>
        <div className="auth-v2-card">
          <div className="auth-v2-heading">
            <span>{tx(locale, { en: 'Account recovery', es: 'Recuperación de la cuenta', it: 'Recupero account', ar: 'استعادة الحساب' })}</span>
            <h1>{tx(locale, { en: 'Reset your password', es: 'Restablece tu contraseña', it: 'Reimposta la tua password', ar: 'استعادة كلمة المرور' })}</h1>
            <p>{tx(locale, { en: 'Enter the email address linked to your account and we\'ll send you a secure reset link.', es: 'Introduce el correo electrónico vinculado a tu cuenta y te enviaremos un enlace seguro para restablecer la contraseña.', it: 'Inserisci l\'indirizzo email collegato al tuo account e ti invieremo un link sicuro per reimpostare la password.', ar: 'أدخل عنوان البريد الإلكتروني المرتبط بحسابك وسنرسل لك رابط إعادة تعيين آمن.' })}</p>
          </div>
          {error && <p className="auth-v2-notice" role="alert"><CircleAlert size={15} />{customerErrorText(locale, error, tx(locale, { en: 'Could not send reset link. Please try again.', es: 'No se pudo enviar el enlace de restablecimiento. Inténtalo de nuevo.', it: 'Impossibile inviare il link di reimpostazione. Riprova.', ar: 'تعذر إرسال رابط إعادة التعيين. حاول مجددًا.' }))}</p>}
          <form className="auth-v2-form" onSubmit={handleSubmit}>
            <label className="auth-v2-field">
              <span>{tx(locale, { en: 'Email address', es: 'Correo electrónico', it: 'Indirizzo email', ar: 'البريد الإلكتروني' })}</span>
              <div>
                <Mail size={18} />
                <input
                  required
                  type="email"
                  autoComplete="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={submitting}
                />
              </div>
            </label>
            <button className="auth-v2-primary" type="submit" disabled={submitting}>
              {submitting
                ? tx(locale, { en: 'Sending...', es: 'Enviando...', it: 'Invio...', ar: 'جارٍ الإرسال...' })
                : tx(locale, { en: 'Send reset link', es: 'Enviar enlace de restablecimiento', it: 'Invia link di recupero', ar: 'إرسال رابط الاستعادة' })}
              <ArrowRight size={17} />
            </button>
          </form>
          <p className="auth-v2-switch">
            {tx(locale, { en: 'Remember your password?', es: '¿Recuerdas tu contraseña?', it: 'Ti ricordi la password?', ar: 'تذكرت كلمة المرور?' })}
            <Link href="/login">{tx(locale, { en: 'Back to sign in', es: 'Volver a iniciar sesión', it: 'Torna all\'accesso', ar: 'العودة إلى تسجيل الدخول' })}</Link>
          </p>
        </div>
      </section>
    </main>
  );
}


export function ResetPasswordPage() {
  return (
    <Suspense fallback={null}>
      <ResetPasswordContent />
    </Suspense>
  );
}

function ResetPasswordContent() {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');
  const { locale } = useLocale();
  const params = useSearchParams();
  const token = params.get('token') || '';

  const passwordError = password.length > 0
    ? (password.length < 6 ? 'Password must be at least 6 characters.' : password.length > 8 ? 'Password must be at most 8 characters.' : null)
    : null;
  const matches = password.length > 0 && password === confirmPassword;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (passwordError || !matches) return;
    setSubmitting(true);
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ token, password, confirmPassword }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Could not reset password. Please try again.');
        return;
      }
      setSubmitted(true);
    } catch {
      setError('Could not reset password. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (!token) {
    return (
      <SiteShell>
        <main className="auth-page-centered">
          <div className="auth-card">
            <div className="auth-mobile-logo">
              <Link href="/">
                <span className="brand-copy"><strong>TravNeeds</strong><small>SINCE 1970</small></span>
              </Link>
            </div>
            <div className="form-success">
              <CircleAlert size={34} style={{ color: 'var(--error)' }} />
              <h2>{tx(locale, { en: 'Invalid link', es: 'Enlace no válido', it: 'Link non valido', ar: 'رابط غير صالح' })}</h2>
              <p>{tx(locale, { en: 'This password reset link is missing or invalid. Please request a new one.', es: 'Este enlace de restablecimiento de contraseña falta o no es válido. Por favor solicita uno nuevo.', it: 'Questo link per il ripristino della password manca o non è valido. Richiedine uno nuovo.', ar: 'رابط إعادة تعيين كلمة المرور هذا مفقود أو غير صالح. يرجى طلب واحد جديد.' })}</p>
              <p className="auth-switch"><Link href="/forgot-password">{tx(locale, { en: 'Request new link', es: 'Solicitar nuevo enlace', it: 'Richiedi nuovo link', ar: 'طلب رابط جديد' })}</Link></p>
            </div>
          </div>
        </main>
      </SiteShell>
    );
  }

  if (submitted) {
    return (
      <SiteShell>
        <main className="auth-page-centered">
          <div className="auth-card">
            <div className="auth-mobile-logo">
              <Link href="/">
                <span className="brand-copy"><strong>TravNeeds</strong><small>SINCE 1970</small></span>
              </Link>
            </div>
            <div className="form-success">
              <Check size={34} />
              <h2>{tx(locale, { en: 'Password updated', es: 'Contraseña actualizada', it: 'Password aggiornata', ar: 'تم تحديث كلمة المرور' })}</h2>
              <p>{tx(locale, { en: 'Your password has been reset successfully.', es: 'Tu contraseña se ha restablecido correctamente.', it: 'La tua password è stata reimpostata con successo.', ar: 'تمت إعادة تعيين كلمة المرور بنجاح.' })}</p>
              <p className="auth-switch"><Link href="/login">{tx(locale, { en: 'Sign in with new password', es: 'Iniciar sesión con nueva contraseña', it: 'Accedi con la nuova password', ar: 'تسجيل الدخول بكلمة المرور الجديدة' })}</Link></p>
            </div>
          </div>
        </main>
      </SiteShell>
    );
  }

  return (
    <SiteShell>
      <main className="auth-page-centered">
        <div className="auth-card">
          <div className="auth-mobile-logo">
            <Link href="/">
              <span className="brand-copy"><strong>TravNeeds</strong><small>SINCE 1970</small></span>
            </Link>
          </div>
          <span className="eyebrow">{tx(locale, { en: 'Account recovery', es: 'Recuperación de la cuenta', it: 'Recupero account', ar: 'استعادة الحساب' })}</span>
          <h1>{tx(locale, { en: 'Create new password', es: 'Crear nueva contraseña', it: 'Crea nuova password', ar: 'إنشاء كلمة مرور جديدة' })}</h1>
          <p>{tx(locale, { en: 'Enter your new password below. It must be 6-64 characters.', es: 'Introduce tu nueva contraseña a continuación. Debe tener 6-64 caracteres.', it: 'Inserisci la tua nuova password qui sotto. Deve essere di 6-64 caratteri.', ar: 'أدخل كلمة المرور الجديدة أدناه. يجب أن تكون 6-64 حرفًا.' })}</p>
          <form className="contact-form" onSubmit={handleSubmit}>
            {error && <p className="co-error" role="alert"><CircleAlert size={15} />{customerErrorText(locale, error, tx(locale, { en: 'Could not reset password. Please try again.', es: 'No se pudo restablecer la contraseña. Inténtalo de nuevo.', it: 'Impossibile reimpostare la password. Riprova.', ar: 'تعذر إعادة تعيين كلمة المرور. حاول مجددًا.' }))}</p>}
            <label>
              {tx(locale, { en: 'New password', es: 'Contraseña nueva', it: 'Nuova password', ar: 'كلمة المرور الجديدة' })}
              <span>
                <input
                  required
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  placeholder="Enter new password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={submitting}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword
                    ? tx(locale, { en: 'Hide password', es: 'Ocultar contraseña', it: 'Nascondi password', ar: 'إخفاء كلمة المرور' })
                    : tx(locale, { en: 'Show password', es: 'Mostrar contraseña', it: 'Mostra password', ar: 'إظهار كلمة المرور' })}
                >
                  {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </span>
              {passwordError && <span className="field-error" role="alert">{passwordError}</span>}
            </label>
            <label>
              {tx(locale, { en: 'Confirm new password', es: 'Confirmar contraseña nueva', it: 'Conferma nuova password', ar: 'تأكيد كلمة المرور الجديدة' })}
              <span>
                <input
                  required
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  placeholder="Confirm new password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  disabled={submitting}
                />
              </span>
              {confirmPassword && !matches && <span className="field-error" role="alert">{tx(locale, { en: 'Passwords do not match.', es: 'Las contraseñas no coinciden.', it: 'Le password non coincidono.', ar: 'كلمتا المرور غير متطابقتين.' })}</span>}
            </label>
            <div className="customer-password-rules" aria-live="polite">
              <span className={password.length >= 6 && password.length <= 64 ? 'valid' : ''}><Check size={14} />{tx(locale, { en: '6-64 characters', es: '6-64 caracteres', it: '6-64 caratteri', ar: '6-64 حرفًا' })}</span>
              <span className={matches ? 'valid' : ''}><Check size={14} />{tx(locale, { en: 'Passwords match', es: 'Las contraseñas coinciden', it: 'Le password coincidono', ar: 'كلمتا المرور متطابقتان' })}</span>
            </div>
            <button className="primary-btn" type="submit" disabled={submitting || Boolean(passwordError) || !matches}>
              {submitting
                ? tx(locale, { en: 'Updating…', es: 'Actualizando…', it: 'Aggiornando…', ar: 'جارٍ التحديث…' })
                : tx(locale, { en: 'Update password', es: 'Actualizar contraseña', it: 'Aggiorna password', ar: 'تحديث كلمة المرور' })}
              <ArrowRight size={17} />
            </button>
          </form>
          <p className="auth-switch">
            {tx(locale, { en: 'Remember your password?', es: '¿Recuerdas tu contraseña?', it: 'Ti ricordi la password?', ar: 'تذكرت كلمة المرور؟' })}
            <Link href="/login">{tx(locale, { en: 'Back to sign in', es: 'Volver a iniciar sesión', it: 'Torna all\'accesso', ar: 'العودة إلى تسجيل الدخول' })}</Link>
          </p>
        </div>
      </main>
    </SiteShell>
  );
}


export function AccountPage({ section = 'overview' }: { section?: string }) { const { locale } = useLocale(); const ar = locale === 'ar'; const nav=[[tx(locale, { en: 'Overview', es: 'Resumen', it: 'Panoramica', ar: 'نظرة عامة' }),'/account'],[tx(locale, { en: 'My bookings', es: 'Mis reservas', it: 'Le mie prenotazioni', ar: 'حجوزاتي' }),'/account/bookings'],[tx(locale, { en: 'Favorites', es: 'Favoritos', it: 'Preferiti', ar: 'المفضلة' }),'/account/favorites'],[tx(locale, { en: 'Profile settings', es: 'Ajustes del perfil', it: 'Impostazioni profilo', ar: 'إعدادات الحساب' }),'/account/profile']]; const activeKey=section==='overview'?(tx(locale, { en: 'Overview', es: 'Resumen', it: 'Panoramica', ar: 'نظرة عامة' })):section==='bookings'?(tx(locale, { en: 'My bookings', es: 'Mis reservas', it: 'Le mie prenotazioni', ar: 'حجوزاتي' })):section==='favorites'?(tx(locale, { en: 'Favorites', es: 'Favoritos', it: 'Preferiti', ar: 'المفضلة' })):(tx(locale, { en: 'Profile settings', es: 'Ajustes del perfil', it: 'Impostazioni profilo', ar: 'إعدادات الحساب' })); const heading=section === 'overview' ? (tx(locale, { en: 'Make space for your next adventure.', es: 'Haz hueco para tu próxima aventura.', it: 'Fai spazio alla tua prossima avventura.', ar: 'افسح مكانًا لمغامرتك القادمة.' })) : section === 'bookings' ? (tx(locale, { en: 'Your bookings', es: 'Tus reservas', it: 'Le tue prenotazioni', ar: 'حجوزاتك' })) : section === 'favorites' ? (tx(locale, { en: 'Saved journeys', es: 'Viajes guardados', it: 'Viaggi salvati', ar: 'الرحلات المحفوظة' })) : (tx(locale, { en: 'Profile settings', es: 'Ajustes del perfil', it: 'Impostazioni profilo', ar: 'إعدادات الحساب' })); return <SiteShell><main className="account-page container"><ImpersonationBanner /><aside className="account-nav"><span className="eyebrow">{tx(locale, { en: 'Your account', es: 'Tu cuenta', it: 'Il tuo account', ar: 'حسابك' })}</span><h1>{tx(locale, { en: 'Welcome back', es: 'Bienvenido de nuevo', it: 'Bentornato', ar: 'مرحبًا بعودتك' })}</h1>{nav.map(([label,href])=><Link className={activeKey===label?'active':''} key={href} href={href}>{label}<ArrowRight size={15}/></Link>)}<Link href="/">{tx(locale, { en: 'Sign out', es: 'Cerrar sesión', it: 'Esci', ar: 'تسجيل الخروج' })}</Link></aside><section className="account-content"><span className="eyebrow">{section === 'overview' ? (tx(locale, { en: 'Your travel desk', es: 'Tu mesa de viajes', it: 'Il tuo banco viaggi', ar: 'مكتب سفرك' })) : activeKey}</span><h2>{heading}</h2>{section==='overview'?<><div className="account-stats"><div><strong>0</strong><span>{tx(locale, { en: 'Upcoming trips', es: 'Próximos viajes', it: 'Prossimi viaggi', ar: 'رحلات قادمة' })}</span></div><div><strong>0</strong><span>{tx(locale, { en: 'Saved tours', es: 'Excursiones guardadas', it: 'Tour salvati', ar: 'رحلات محفوظة' })}</span></div><div><strong>1</strong><span>{tx(locale, { en: 'Open enquiry', es: 'Solicitud abierta', it: 'Richiesta aperta', ar: 'طلب مفتوح' })}</span></div></div><div className="account-empty"><h3>{tx(locale, { en: 'Your next chapter starts here.', es: 'Tu próximo capítulo empieza aquí.', it: 'Il tuo prossimo capitolo inizia qui.', ar: 'فصلك القادم يبدأ من هنا.' })}</h3><p>{tx(locale, { en: 'Explore our journeys and save the ones that make you curious.', es: 'Descubre nuestros viajes y guarda los que despierten tu curiosidad.', it: 'Esplora i nostri viaggi e salva quelli che accendono la tua curiosità.', ar: 'استكشف رحلاتنا واحفظ ما يثير فضولك.' })}</p><Link href="/all-tours/one-day-tours" className="primary-btn">{tx(locale, { en: 'Browse tours', es: 'Ver excursiones', it: 'Sfoglia i tour', ar: 'تصفح الرحلات' })}</Link></div></>:<div className="account-empty"><h3>{tx(locale, { en: 'Nothing here yet.', es: 'Nada por aquí todavía.', it: 'Niente qui per ora.', ar: 'لا يوجد شيء هنا بعد.' })}</h3><p>{tx(locale, { en: 'When you are ready, your TravNeeds travel details will appear in this space.', es: 'Cuando estés listo, los detalles de tu viaje TravNeeds aparecerán en este espacio.', it: 'Quando sarai pronto, i dettagli del tuo viaggio TravNeeds appariranno in questo spazio.', ar: 'عندما تكون جاهزًا، ستظهر تفاصيل سفرك هنا.' })}</p><Link href="/make-your-trip" className="primary-btn">{tx(locale, { en: 'Start planning', es: 'Empieza a planificar', it: 'Inizia a pianificare', ar: 'ابدأ التخطيط' })}</Link></div>}</section></main></SiteShell> }
