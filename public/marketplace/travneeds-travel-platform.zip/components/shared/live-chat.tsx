'use client'
import { BrandMark } from '@/components/layout/brand-mark'

import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import Link from 'next/link'
import { ArrowLeft, ArrowRight, Headset, Send, X } from 'lucide-react'
import { getToursByCategory } from '@/data/tours'
import { useDbTours } from '@/lib/tours/tours-client'
import { whatsappHref } from '@/data/company'
import { useBrandSettings } from '@/lib/admin/admin-store'
import { formatPrice, useLocale, tx, type Locale } from '@/components/locale'

type ChatMsg = { id: number; from: 'agent' | 'user'; text: string; time: string }
type ChipId = 'prices' | 'agent' | 'booking' | 'browse' | 'trips' | 'plan' | 'contact' | 'wa'

const chipsHome: ChipId[] = ['prices', 'agent', 'booking']
const chipsBrowse: ChipId[] = ['browse', 'trips']
const chipsPlan: ChipId[] = ['plan', 'browse']
const chipsContact: ChipId[] = ['wa', 'contact']

const minNilePrice = Math.min(...getToursByCategory('nile-cruises').map((tour) => tour.price))
const nileBase = getToursByCategory('nile-cruises')
const baseChipHrefs: Record<ChipId, string | undefined> = {
  prices: undefined, agent: undefined, booking: undefined,
  browse: '/all-tours/nile-cruises', trips: '/trips', plan: '/make-your-trip', contact: '/contact', wa: undefined,
}
const STORE_KEY = 'sp-livechat-msgs-v2'
const OPENED_KEY = 'sp-livechat-opened'

const baseCopy = {
  en: {
    openLabel: 'Open live chat', closeLabel: 'Close live chat', sendLabel: 'Send message',
    name: 'TravNeeds', online: 'Online, replies instantly', inputPh: 'Write a message...',
    teaser: 'Need help planning your Egypt trip? Chat with us!',
    greeting: "Hi there! I'm Nour from TravNeeds. Ask me about Nile cruises, prices, or booking. Or pick a topic:",
    price: 'Our Nile cruises start from {price} per person, depending on the season and group size. Every cruise page has a season price table (solo, pair and group). Open any cruise and check "Cruise Prices".',
    cruise: 'We have 4 cruise levels: Standard, Deluxe, Superior, and Luxury, from 3 to 7 nights between Luxor and Aswan, with full board and guided temple visits.',
    booking: 'Booking is easy: open any trip and press "Book now", or tell us your dates on the Make Your Trip page and we will arrange everything.',
    human: 'Of course! Our team is on WhatsApp and on the Contact page. Someone will get back to you shortly.',
    thanks: 'You are welcome! I am here if you need anything else.',
    fallback: 'Got it! Someone from our team will follow up shortly. Meanwhile, pick a topic so I can help faster:',
    chipLabels: { prices: 'Nile cruise prices', agent: 'Talk to an agent', booking: 'How do I book?', browse: 'View Nile cruises', trips: 'See all trips', plan: 'Plan my trip', contact: 'Contact page', wa: 'WhatsApp us' },
  },
  ar: {
    openLabel: 'فتح المحادثة', closeLabel: 'إغلاق المحادثة', sendLabel: 'إرسال الرسالة',
    name: 'TravNeeds', online: 'متصل الآن، يرد فورًا', inputPh: 'اكتب رسالة...',
    teaser: 'هل تحتاج إلى مساعدة في رحلتك إلى مصر؟ تحدث معنا!',
    greeting: 'أهلاً بك! أنا نور من TravNeeds. اسألني عن الكروز النيلية أو الأسعار أو الحجز. أو اختر موضوعًا:',
    price: 'تبدأ أسعار الكروز النيلية من {price} للفرد حسب الموسم وعدد المسافرين. تتضمن كل رحلة جدول أسعار المواسم (الفردي والزوجي والمجموعات). افتح أي رحلة واطلع على قسم Cruise Prices.',
    cruise: 'لدينا ٤ فئات: عادية وديلوكس وسوبريور وفاخرة، من ٣ إلى ٧ ليالٍ بين الأقصر وأسوان بإقامة شاملة وزيارات معابد مع مرشد.',
    booking: 'الحجز سهل: افتح أي رحلة وانقر Book now، أو أرسل لنا مواعيدك في صفحة Make Your Trip وسنجهز لك كل شيء.',
    human: 'بالطبع! فريقنا متاح عبر واتساب وفي صفحة اتصل بنا. سيرد عليك أحد أفراد الفريق في أقرب وقت.',
    thanks: 'على الرحب والسعة! أنا هنا إن احتجت إلى أي شيء آخر.',
    fallback: 'حسنًا! سيتابع أحد أفراد فريقنا معك قريبًا. ويمكنك اختيار موضوع لأساعدك بشكل أسرع:',
    chipLabels: { prices: 'أسعار الكروز النيلية', agent: 'التحدث إلى موظف', booking: 'كيف أحجز؟', browse: 'استعرض الكروز النيلية', trips: 'كل الرحلات', plan: 'خطط رحلتك', contact: 'صفحة اتصل بنا', wa: 'واتساب' },
  },
} as const

const copy = {
  ...baseCopy,
  es: {
    openLabel: 'Abrir chat', closeLabel: 'Cerrar chat', sendLabel: 'Enviar mensaje',
    name: 'TravNeeds', online: 'En línea, respuestas al instante', inputPh: 'Escribe un mensaje...',
    teaser: '¿Necesitas ayuda para planificar tu viaje a Egipto? ¡Chatea con nosotros!',
    greeting: '¡Hola! Soy Nour de TravNeeds. Pregúntame sobre cruceros por el Nilo, precios o reservas. También puedes elegir un tema:',
    price: 'Nuestros cruceros por el Nilo cuestan desde {price} por persona, según la temporada y el tamaño del grupo. Cada página de crucero tiene una tabla de precios por temporada (individual, pareja y grupo). Abre un crucero y consulta «Precios del crucero».',
    cruise: 'Tenemos 4 categorías de cruceros: Standard, Deluxe, Superior y Luxury, de 3 a 7 noches entre Lúxor y Asuán, con pensión completa y visitas guiadas a los templos.',
    booking: 'Reservar es fácil: abre un viaje y pulsa «Reserva ahora», o indícanos tus fechas en la página «Crea tu viaje» y organizaremos los detalles.',
    human: '¡Por supuesto! Nuestro equipo está disponible en WhatsApp y en la página de contacto. Alguien te responderá en breve.',
    thanks: '¡De nada! Estoy aquí si necesitas algo más.',
    fallback: '¡Entendido! Nuestro equipo te responderá en breve. Mientras tanto, elige un tema para que pueda ayudarte más rápido:',
    chipLabels: { prices: 'Precios de cruceros por el Nilo', agent: 'Hablar con un agente', booking: '¿Cómo reservo?', browse: 'Ver cruceros por el Nilo', trips: 'Ver todos los viajes', plan: 'Planificar mi viaje', contact: 'Página de contacto', wa: 'Escríbenos por WhatsApp' },
  },
  it: {
    openLabel: 'Apri la chat', closeLabel: 'Chiudi la chat', sendLabel: 'Invia messaggio',
    name: 'TravNeeds', online: 'Online, risposte immediate', inputPh: 'Scrivi un messaggio...',
    teaser: 'Hai bisogno di aiuto per organizzare il tuo viaggio in Egitto? Chatta con noi!',
    greeting: 'Ciao! Sono Nour di TravNeeds. Chiedimi informazioni su crociere sul Nilo, prezzi o prenotazioni. Oppure scegli un argomento:',
    price: 'Le nostre crociere sul Nilo partono da {price} a persona, in base alla stagione e alle dimensioni del gruppo. Ogni pagina della crociera ha una tabella dei prezzi stagionali (singolo, coppia e gruppo). Apri una crociera e consulta «Prezzi della crociera».',
    cruise: 'Abbiamo 4 categorie di crociere: Standard, Deluxe, Superior e Luxury, da 3 a 7 notti tra Luxor e Assuan, con pensione completa e visite guidate ai templi.',
    booking: 'Prenotare è semplice: apri un viaggio e premi «Prenota ora», oppure indica le tue date nella pagina «Crea il tuo viaggio» e organizzeremo i dettagli.',
    human: 'Certamente! Il nostro team è disponibile su WhatsApp e nella pagina dei contatti. Qualcuno ti risponderà a breve.',
    thanks: 'Prego! Sono qui se hai bisogno di altro.',
    fallback: 'Ricevuto! Il nostro team ti risponderà a breve. Nel frattempo, scegli un argomento per aiutarti più rapidamente:',
    chipLabels: { prices: 'Prezzi delle crociere sul Nilo', agent: 'Parla con un operatore', booking: 'Come posso prenotare?', browse: 'Vedi le crociere sul Nilo', trips: 'Vedi tutti i viaggi', plan: 'Pianifica il mio viaggio', contact: 'Pagina dei contatti', wa: 'Scrivici su WhatsApp' },
  },
} as const

export function getBotReply(text: string, lang: Locale, priceStr: string): { text: string; chips: ChipId[] } {
  const t = copy[lang]
  const s = text.toLocaleLowerCase()
  const has = (...words: string[]) => words.some((w) => s.includes(w))
  if (/^(hi|hello|hey|good morning|good evening|hii+|hola|buenos días|buenas tardes|ciao|buongiorno|buonasera)\b/.test(s) || has('سلام', 'مرحبا', 'أهلا', 'اهلا', 'ازيك', 'هاي', 'صباح', 'مساء'))
    return { text: t.greeting, chips: [...chipsHome] }
  if (has('price', 'cost', 'much', 'cheap', 'discount', 'precio', 'cuánto', 'descuento', 'prezzo', 'prezzi', 'quanto', 'sconto', 'سعر', 'أسعار', 'اسعار', 'بكام', 'تكلفة', 'تكلفه', 'خصم'))
    return { text: t.price.replace('{price}', priceStr), chips: [...chipsBrowse] }
  if (has('book', 'reserve', 'reserv', 'prenot', 'حجز', 'احجز', 'الحجز'))
    return { text: t.booking, chips: [...chipsPlan] }
  if (has('cruise', 'nile', 'ship', 'luxor', 'aswan', 'crucero', 'nilo', 'crociera', 'crociere', 'كروز', 'نيل', 'النيل', 'مركب', 'الأقصر', 'الاقصر', 'أسوان', 'اسوان'))
    return { text: t.cruise, chips: [...chipsBrowse] }
  if (has('human', 'agent', 'person', 'someone', 'call', 'phone', 'contact', 'whatsapp', 'agente', 'operatore', 'contatt', 'teléfono', 'telefono', 'موظف', 'إنسان', 'انسان', 'بشر', 'مندوب', 'حد يكلمني', 'اتصل', 'تليفون', 'رقم', 'واتس', 'تواصل'))
    return { text: t.human, chips: [...chipsContact] }
  if (has('thank', 'thanks', 'gracias', 'grazie', 'شكرا', 'متشكر', 'ميرسي'))
    return { text: t.thanks, chips: [...chipsHome] }
  return { text: t.fallback, chips: [...chipsHome] }
}

function cleanText(s: string): string {
  return s.replace(/[ - –…“”‘’·]/g, (ch) => (ch === '·' ? ',' : ch === '…' ? '...' : ch === '“' || ch === '”' ? '"' : ch === '‘' || ch === '’' ? "'" : ch === '–' ? '-' : ' '))
}

function loadStored(): ChatMsg[] {
  try {
    const raw = localStorage.getItem(STORE_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw) as ChatMsg[]
    if (!Array.isArray(parsed)) return []
    return parsed
      .filter((m): m is ChatMsg => Boolean(m) && (m.from === 'agent' || m.from === 'user') && typeof m.text === 'string')
      .map((m, i) => ({ ...m, id: i + 1, text: cleanText(m.text) }))
      .slice(-50)
  } catch { return [] }
}

export function LiveChatWidget({ open, onOpen, onClose }: { open: boolean; onOpen: () => void; onClose: () => void }) {
  const { locale, currency } = useLocale()
  const brand = useBrandSettings()
  const t = copy[locale]
  const [mounted, setMounted] = useState(false)
  useEffect(() => { setMounted(true) }, [])
  const liveTours = useDbTours(nileBase)
  const priceStr = formatPrice(minNilePrice, currency, locale)
  const [mobileTarget, setMobileTarget] = useState<HTMLElement | null>(null)
  useEffect(() => { setMobileTarget(document.getElementById('mobile-livechat-trigger')) }, [])
  const [messages, setMessages] = useState<ChatMsg[]>([])
  const [draft, setDraft] = useState('')
  const [chips, setChips] = useState<ChipId[]>([])
  const [typing, setTyping] = useState(false)
  const [unread, setUnread] = useState(0)
  const [teaser, setTeaser] = useState(false)
  const idRef = useRef(1)
  const panelRef = useRef<HTMLElement>(null)
  const bodyRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const timerRef = useRef<number | null>(null)
  const openRef = useRef(open)
  openRef.current = open

  const timeNow = () => new Date().toLocaleTimeString(locale === 'ar' ? 'ar-EG' : locale === 'es' ? 'es-ES' : locale === 'it' ? 'it-IT' : 'en-US', { hour: '2-digit', minute: '2-digit' })

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw) as ChatMsg[]
        if (Array.isArray(parsed) && parsed.length) {
          setMessages(parsed)
          idRef.current = Math.max(...parsed.map((m) => m.id), 0) + 1
        }
      }
    } catch { /* private mode */ }
  }, [])

  useEffect(() => {
    if (!messages.length) return
    try { localStorage.setItem(STORE_KEY, JSON.stringify(messages.slice(-30))) } catch { /* ignore */ }
  }, [messages])

  useEffect(() => {
    bodyRef.current?.scrollTo({ top: bodyRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, typing, chips, open])

  useEffect(() => {
    if (!open) return
    const isMobile = typeof window !== 'undefined' && window.innerWidth <= 768
    if (isMobile) {
      document.body.classList.add('mobile-chat-open')
    }

    const updateViewport = () => {
      if (typeof window !== 'undefined' && window.innerWidth <= 768 && panelRef.current) {
        if (window.visualViewport) {
          panelRef.current.style.height = `${window.visualViewport.height}px`
          panelRef.current.style.top = `${window.visualViewport.offsetTop}px`
        } else {
          panelRef.current.style.height = '100dvh'
          panelRef.current.style.top = '0px'
        }
        bodyRef.current?.scrollTo({ top: bodyRef.current.scrollHeight, behavior: 'smooth' })
      } else if (panelRef.current) {
        panelRef.current.style.height = ''
        panelRef.current.style.top = ''
      }
    }

    const vv = typeof window !== 'undefined' ? window.visualViewport : null
    if (vv) {
      vv.addEventListener('resize', updateViewport)
      vv.addEventListener('scroll', updateViewport)
    }
    window.addEventListener('resize', updateViewport)
    updateViewport()

    inputRef.current?.focus()
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.classList.remove('mobile-chat-open')
      if (vv) {
        vv.removeEventListener('resize', updateViewport)
        vv.removeEventListener('scroll', updateViewport)
      }
      window.removeEventListener('resize', updateViewport)
      window.removeEventListener('keydown', onKey)
    }
  }, [open, onClose])

  useEffect(() => {
    try {
      if (!localStorage.getItem(OPENED_KEY)) {
        const timer = setTimeout(() => {
          if (!openRef.current) setTeaser(true)
        }, 8000)
        return () => clearTimeout(timer)
      }
    } catch { /* ignore */ }
  }, [])

  useEffect(() => () => { if (timerRef.current) window.clearTimeout(timerRef.current) }, [])

  const openPanel = () => {
    onOpen()
    setTeaser(false)
    setUnread(0)
    try { localStorage.setItem(OPENED_KEY, '1') } catch { /* ignore */ }
    if (!messages.length) {
      setTyping(true)
      timerRef.current = window.setTimeout(() => {
        setTyping(false)
        setMessages([{ id: idRef.current++, from: 'agent', text: t.greeting, time: timeNow() }])
        setChips([...chipsHome])
      }, 700)
    }
  }

  const send = (raw: string) => {
    const clean = raw.trim().slice(0, 500)
    if (!clean || typing) return
    const userMsg: ChatMsg = { id: idRef.current++, from: 'user', text: clean, time: timeNow() }
    setMessages((prev) => [...prev, userMsg])
    setDraft('')
    setTyping(true)
    const reply = getBotReply(clean, locale, priceStr)
    timerRef.current = window.setTimeout(() => {
      setTyping(false)
      setMessages((prev) => [...prev, { id: idRef.current++, from: 'agent', text: reply.text, time: timeNow() }])
      setChips(reply.chips)
      if (!openRef.current) setUnread((u) => u + 1)
    }, 900)
  }

  const panel = (
    <section ref={panelRef} className="livechat-panel" role="dialog" aria-label={t.name} aria-modal={mounted ? 'true' : 'false'}>
      <header className="livechat-head">
        <button
          type="button"
          className="livechat-back-btn"
          onClick={onClose}
          aria-label={tx(locale, { en: 'Back', es: 'Volver', it: 'Indietro', ar: 'رجوع' })}
        >
          {locale === 'ar' ? <ArrowRight size={22} /> : <ArrowLeft size={22} />}
        </button>
        <span className="livechat-avatar" aria-hidden="true"><BrandMark alt="" /></span>
        <div className="livechat-head-meta">
          <strong>{t.name}</strong>
          <span className="livechat-online"><i aria-hidden="true" />{t.online}</span>
        </div>
        <button type="button" className="livechat-close" onClick={onClose} aria-label={t.closeLabel}><X size={17} /></button>
      </header>
      <div className="livechat-body" ref={bodyRef} aria-live="polite">
        {messages.map((m) => <div key={m.id} className={`livechat-row ${m.from}`}>
          <div className="livechat-bubble">{m.text}</div>
          <span className="livechat-time">{m.time}</span>
        </div>)}
        {typing && <div className="livechat-row agent"><span className="livechat-typing" aria-label={t.online}><i /><i /><i /></span></div>}
      </div>
      {chips.length > 0 && <div className="livechat-chips">
        {chips.map((id) => {
          const label = t.chipLabels[id]
          const href = id === 'wa' ? whatsappHref(brand.whatsapp) : baseChipHrefs[id]
          return href
            ? (href.startsWith('http')
              ? <a key={id} href={href} target="_blank" rel="noreferrer">{label}</a>
              : <Link key={id} href={href}>{label}</Link>)
            : <button key={id} type="button" onClick={() => send(label)}>{label}</button>
        })}
      </div>}
      <form className="livechat-form" onSubmit={(e) => { e.preventDefault(); send(draft) }}>
        <input ref={inputRef} value={draft} onChange={(e) => setDraft(e.target.value)} placeholder={t.inputPh} aria-label={t.inputPh} maxLength={500} autoComplete="off" />
        <button type="submit" className="livechat-send" aria-label={t.sendLabel}><Send size={17} /></button>
      </form>
    </section>
  )

  return <div className="livechat-wrap">
    {mobileTarget && createPortal(<button type="button" className="mobile-support-trigger" onClick={() => (open ? onClose() : openPanel())} aria-expanded={open} aria-label={open ? t.closeLabel : t.openLabel}><Headset size={21} aria-hidden="true"/><span>{({ en: 'Live Chat', es: 'Chat en vivo', it: 'Chat dal vivo', ar: 'دردشة مباشرة' })[locale]}</span>{!open && unread > 0 && <b>{unread}</b>}</button>, mobileTarget)}
    {teaser && !open && <button type="button" className="livechat-teaser" onClick={openPanel}>{t.teaser}</button>}
    {open && (mounted ? createPortal(panel, document.body) : panel)}
    <button type="button" className="livechat-fab" onClick={() => (open ? onClose() : openPanel())} aria-expanded={open} aria-label={open ? t.closeLabel : t.openLabel}>
      {open ? <X size={24} /> : <Headset size={26} />}
      {!open && unread > 0 && <b>{unread}</b>}
    </button>
  </div>
}
