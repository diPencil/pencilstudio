'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { ArrowRight, Search } from 'lucide-react'
import { usePublicSearch } from '@/lib/search/use-public-search'
import { parseSearchQuery } from '@/lib/shared/query'
import { SEARCH_TYPE_LABELS } from '@/lib/search/site-search'
import { SiteShell } from '@/components/site'
import { tx, useLocale, useTranslations } from '@/components/locale'
import { localeDirection } from '@/lib/localization/locale-config'
import { searchResultSummary } from '@/lib/search/search-copy'

export function SearchPage() {
  const initial = parseSearchQuery(useSearchParams()).q
  const [query, setQuery] = useState(initial)
  useEffect(() => setQuery(initial), [initial])
  const { locale } = useLocale()
  const t = useTranslations('public.search')
  const { results, loading, failed, retry } = usePublicSearch(query)
  return <SiteShell><main className="search-page container" dir={localeDirection(locale)}>
    <div className="search-page-header">
      <span className="eyebrow">{t('eyebrow')}</span>
      <h1>{t('heading')}</h1>
      <label><Search size={20}/><input autoFocus value={query} maxLength={120} onChange={event => setQuery(event.target.value)} placeholder={t('placeholder')} aria-label={t('search')}/></label>
    </div>
    <div className="search-results" aria-busy={loading}>
      {loading && <p role="status">{t('loading')}</p>}
      {failed.length > 0 && <div role="alert"><p>{t('failure')}</p><button type="button" className="outline-btn" onClick={retry}>{t('retry')}</button></div>}
      {!loading && failed.length === 0 && <p role="status">{searchResultSummary(locale, results.length, query)}</p>}
      {!loading && failed.length === 0 && results.length === 0 && <p>{t('empty')}</p>}
      <div className="public-search-results-list">{results.map(item => <article className="public-search-result" key={`${item.type}-${item.slug}`}>
        {item.image && <Link href={item.href} className="public-search-result-image" tabIndex={-1} aria-hidden="true"><img src={item.image} alt="" loading="lazy" onError={event => { event.currentTarget.style.visibility = 'hidden' }}/></Link>}
        <div className="public-search-result-copy"><small>{tx(locale, SEARCH_TYPE_LABELS[item.type])}</small><h2><Link href={item.href}>{item.title}</Link></h2><p>{item.copy}</p><Link href={item.href} className="text-link">{t('openPage')} <ArrowRight size={15}/></Link></div>
      </article>)}</div>
    </div>
  </main></SiteShell>
}
