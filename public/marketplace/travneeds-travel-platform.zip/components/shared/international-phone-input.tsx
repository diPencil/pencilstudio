'use client'

import { useEffect, useState } from 'react'
import { Phone } from 'lucide-react'
import { countryByCode, countryFromPhone, internationalPhone, nationalPhone } from '@/data/countries'
import { stripTrunkZero } from '@/lib/shared/phone'
import { countryLabel } from '@/lib/shared/country-label'
import { CountrySelect } from '@/components/shared/country-select'
import { tx, useLocale } from '@/components/locale'
import { translate } from '@/lib/localization/platform-translations'
import type { Locale } from '@/lib/localization/locale-config'

type InternationalPhoneInputProps = {
  value: string
  onChange: (value: string) => void
  locale?: Locale
  id?: string
  required?: boolean
  disabled?: boolean
  placeholder?: string
  maxLength?: number
  countryCode?: string
  onCountryChange?: (countryCode: string) => void
  invalid?: boolean
  describedBy?: string
  className?: string
}

export function InternationalPhoneInput({ value, onChange, locale: localeOverride, id, required, disabled, placeholder, maxLength = 24, countryCode: controlledCountryCode, onCountryChange, invalid, describedBy, className = '' }: InternationalPhoneInputProps) {
  const { locale: contextLocale } = useLocale()
  const locale = localeOverride ?? contextLocale
  const [internalCountryCode, setInternalCountryCode] = useState(() => countryFromPhone(value).code)
  const countryCode = controlledCountryCode ?? internalCountryCode
  const selectedCountry = countryByCode(countryCode)

  useEffect(() => {
    if (controlledCountryCode || !value.trim().startsWith('+')) return
    setInternalCountryCode(countryFromPhone(value).code)
  }, [controlledCountryCode, value])

  const selectCountry = (nextCode: string) => {
    const nextCountry = countryByCode(nextCode)
    const local = nationalPhone(value, selectedCountry.dialCode)
    if (controlledCountryCode === undefined) setInternalCountryCode(nextCountry.code)
    onCountryChange?.(nextCountry.code)
    onChange(internationalPhone(nextCountry.dialCode, local))
  }

  return <span className={`international-phone-field ${className}`.trim()}>
    <span className="ipf-icon" aria-hidden="true"><Phone size={18} /></span>
    <CountrySelect
      variant="phone"
      value={selectedCountry.code}
      onChange={selectCountry}
      locale={locale}
      disabled={disabled}
      label={`${translate(locale, 'core.controls.countryCallingCode')}: ${countryLabel(selectedCountry, locale)} (${selectedCountry.dialCode})`}
    />
    <span className="ipf-divider" aria-hidden="true" />
    <input id={id} type="tel" inputMode="tel" autoComplete="tel-national" dir="ltr" required={required} disabled={disabled} value={nationalPhone(value, selectedCountry.dialCode)} onChange={(event) => onChange(internationalPhone(selectedCountry.dialCode, stripTrunkZero(selectedCountry.code, event.target.value)))} placeholder={placeholder ?? tx(locale, { en: 'Phone number', es: 'Número de teléfono', it: 'Numero di telefono', ar: 'رقم الهاتف' })} maxLength={maxLength} aria-invalid={invalid} aria-describedby={describedBy} />
  </span>
}
