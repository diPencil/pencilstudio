'use client'
import { currencyChoices } from '@/lib/localization/currency'

import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { PublicAppearancePortal } from '@/components/cms/public-appearance'
import { Globe2, X } from 'lucide-react'
import { useLocale, type Currency, type Locale } from '@/components/locale'
import { translate } from '@/lib/localization/platform-translations'
import { ALL_LOCALES, LOCALE_LABELS, LOCALE_SHORT_LABELS } from '@/lib/localization/locale-config'

export function getLanguageDialogText(locale: Locale) {
  return {
    modalTitle: translate(locale, 'core.language.modalTitle'),
    curTitle: translate(locale, 'core.language.curTitle'),
    regTitle: translate(locale, 'core.language.regTitle'),
    soon: translate(locale, 'core.language.soon'),
    comingSoon: translate(locale, 'core.language.comingSoon'),
    closeLabel: translate(locale, 'core.language.closeLabel'),
  }
}

export function getLanguageRegions(locale: Locale) {
  return ALL_LOCALES.map((value) => [translate(locale, `core.regions.${value}`), LOCALE_LABELS[value], value] as const)
}

export function LanguageModal({ locale, currency, onClose, onSelect, onCurrency }: { locale: Locale; currency: Currency; onClose: () => void; onSelect: (locale: Locale) => void; onCurrency: (currency: Currency) => void }) {
  const text = getLanguageDialogText(locale)
  const currencies = currencyChoices(locale)
  const regions = getLanguageRegions(locale)
  const [mounted, setMounted] = useState(false)
  useEffect(() => { setMounted(true) }, [])
  if (!mounted) return null
  const node = <div className="language-backdrop" role="presentation" onMouseDown={onClose}><div className="language-modal" role="dialog" aria-modal="true" aria-labelledby="language-title" onMouseDown={event => event.stopPropagation()}><div className="language-modal-head"><h2 id="language-title">{text.modalTitle}</h2><button className="language-close" onClick={onClose} aria-label={text.closeLabel}><X size={20} /></button></div><h3>{text.curTitle}</h3><div className="language-options currency-options">{currencies.map(([name, code, value]) => <button key={code} className={currency === value ? 'selected' : ''} onClick={() => { onCurrency(value); onClose() }} aria-pressed={currency === value}><span>{name}</span><strong>{code}</strong></button>)}</div><h3>{text.regTitle}</h3><div className="language-options region-options">{regions.map(([region, language, value]) => <button key={region} type="button" className={value === locale ? 'selected' : ''} onClick={() => { onSelect(value); onClose() }} aria-pressed={value === locale}><span>{region}</span><strong>{language}</strong></button>)}</div></div></div>
  return createPortal(<PublicAppearancePortal>{node}</PublicAppearancePortal>, document.body)
}

export function LanguageToggle({ label, onOpen }: { label: string; onOpen: () => void }) {
  const { locale } = useLocale()
  return <button className="language" onClick={onOpen} aria-label={translate(locale, 'core.language.openLabel')}><Globe2 size={18} /><span className="language-label-full">{label}</span><span className="language-label-compact">{label.split(' - ')[0]}</span></button>
}

export function LanguageSelector() {
  const { locale, setLocale, currency, setCurrency } = useLocale()
  const [open, setOpen] = useState(false)
  return <>
    <LanguageToggle label={LOCALE_SHORT_LABELS[locale] + ' - ' + currency} onOpen={() => setOpen(true)} />
    {open && <LanguageModal locale={locale} currency={currency} onClose={() => setOpen(false)} onSelect={setLocale} onCurrency={setCurrency} />}
  </>
}
