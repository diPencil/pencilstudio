'use client'

import { createContext, startTransition, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { DirectionProvider } from '@base-ui/react/direction-provider'
import {
  DEFAULT_LOCALE,
  sanitizeLocale,
  isLocaleRTL,
  pickLocaleText,
  localePreferenceCookie,
  readLocalePreferenceCookie,
  isLocaleEnabled,
  resolveLocale,
  intlLocale,
  type EnabledLocale,
  type Locale,
} from '@/lib/localization/locale-config'
import { platformTranslations } from '@/lib/localization/platform-translations'
import { ensureStorefrontSettings, getDbCurrency, getDbLocalization } from '@/lib/shared/storefront-settings'

export type { Locale }
export type { Currency } from '@/lib/localization/currency'
import { isCurrency, formatCurrency, type Currency } from '@/lib/localization/currency'

/**
 * Canonical localized-text picker (EN/ES/IT public + preserved AR).
 *
 * Replaces binary `ar ? arabic : english` logic: every user-facing
 * string becomes `{ en, es, it, ar }` with a safe English fallback for
 * any missing translation. Catalogue/editorial content without a real
 * ES/IT source intentionally omits `es`/`it` and falls back to English.
 */
export type LText = { en: string; es?: string; it?: string; ar?: string }

export function tx(locale: Locale, v: LText): string {
  return pickLocaleText(locale, v)
}

// Zero means no configured rate; never invent a conversion.
const defaultRates: Record<Currency, number> = { USD: 1, EUR: 0, EGP: 0 }

export type CurrencySettings = {
  eur: number
  egp: number
  defaultCurrency: Currency
  updatedAt: string
}

export const defaultCurrencySettings: CurrencySettings = {
  eur: defaultRates.EUR,
  egp: defaultRates.EGP,
  defaultCurrency: 'USD',
  updatedAt: '',
}

export function readCurrencySettings(): CurrencySettings {
  // Database is the source of truth (fetched once per page load);
  // built-in defaults render until it arrives. No localStorage mirror.
  const db = getDbCurrency()
  return {
    eur: db?.eur && Number.isFinite(db.eur) && db.eur > 0 ? db.eur : defaultRates.EUR,
    egp: db?.egp && Number.isFinite(db.egp) && db.egp > 0 ? db.egp : defaultRates.EGP,
    defaultCurrency: db?.defaultCurrency ?? 'USD',
    updatedAt: '',
  }
}

export function getCurrencyRates(): Record<Currency, number> {
  const settings = readCurrencySettings()
  return { USD: 1, EUR: settings.eur, EGP: settings.egp }
}

export type LocalizationSettings = {
  defaultLanguage: Locale
  timezone: string
}

export const defaultLocalizationSettings: LocalizationSettings = {
  defaultLanguage: DEFAULT_LOCALE,
  timezone: 'Africa/Cairo',
}

function isValidTimezone(tz: string): boolean {
  if (!tz) return false
  try {
    const supported = (Intl as unknown as { supportedValuesOf?: (key: string) => string[] }).supportedValuesOf?.('timeZone')
    if (supported) return supported.includes(tz)
    Intl.DateTimeFormat(undefined, { timeZone: tz })
    return true
  } catch {
    return false
  }
}

export function readLocalizationSettings(): LocalizationSettings {
  // Database is the source of truth; built-in defaults render until it
  // arrives. Visitor-chosen values stay in star-locale (untouched here).
  const db = getDbLocalization()
  return {
    defaultLanguage: db?.defaultLanguage
      ? sanitizeLocale(db.defaultLanguage)
      : defaultLocalizationSettings.defaultLanguage,
    timezone: db?.timezone ?? defaultLocalizationSettings.timezone,
  }
}

export function getSiteTimezone(): string {
  return readLocalizationSettings().timezone
}

export function formatSiteTime(iso: string, locale: Locale): string {
  return new Date(iso).toLocaleTimeString(intlLocale(locale), {
    hour: '2-digit',
    minute: '2-digit',
    timeZone: getSiteTimezone(),
  })
}

type LocaleState = {
  locale: Locale
  setLocale: (l: Locale) => void
  currency: Currency
  setCurrency: (c: Currency) => void
}

const defaultLocaleState: LocaleState = { locale: DEFAULT_LOCALE, setLocale: () => {}, currency: 'USD', setCurrency: () => {} }
type LocaleScope = { locale: Locale; preview: boolean }
const LocaleCtx = createContext<LocaleState | undefined>(undefined)
const InitialLocaleCtx = createContext<LocaleScope>({ locale: DEFAULT_LOCALE, preview: false })
const ActiveLocaleScope = createContext<LocaleScope | undefined>(undefined)

function readBrowserPreference(key: string): string | null {
  try {
    return window.localStorage.getItem(key)
  } catch { return null }
}

function readStoredLocale(): Locale | null {
  const stored = readBrowserPreference('star-locale')
  return stored && isLocaleEnabled(stored) ? stored : readLocalePreferenceCookie(document.cookie)
}

/** Server-provided hydration seed, not a second mutable locale store. */
export function InitialLocaleProvider({ children, locale, preview = false }: { children: ReactNode; locale: Locale; preview?: boolean }) {
  const scope = useMemo(() => ({ locale: resolveLocale(locale), preview }), [locale, preview])
  return <InitialLocaleCtx.Provider value={scope}>{children}</InitialLocaleCtx.Provider>
}

export function LocaleProvider({ children, initialLocale }: { children: ReactNode; initialLocale?: Locale }) {
  const inherited = useContext(LocaleCtx)
  const activeScope = useContext(ActiveLocaleScope)
  const scope = useContext(InitialLocaleCtx)
  // Existing shell wrappers remain compatible, but cannot fork application state.
  // An explicit InitialLocaleProvider boundary (CMS preview) creates a new scope.
  if (inherited && activeScope === scope) return <>{children}</>
  return <LocaleStateProvider key={scope.preview ? scope.locale : 'application'} initialLocale={initialLocale} scope={scope}>{children}</LocaleStateProvider>
}

function LocaleStateProvider({ children, initialLocale, scope }: { children: ReactNode; initialLocale?: Locale; scope: LocaleScope }) {
  const { locale: serverLocale, preview } = scope
  const [locale, setLocaleState] = useState<Locale>(resolveLocale(initialLocale, serverLocale))
  const [currency, setCurrencyState] = useState<Currency>('USD')
  const [, setRatesVersion] = useState(0)
  useEffect(() => {
    if (preview) return
    ensureStorefrontSettings()
    const applyPersistedPreferences = () => {
      const savedLocale = readStoredLocale()
      const initialLocale = savedLocale
        ? sanitizeLocale(savedLocale)
        : sanitizeLocale(readLocalizationSettings().defaultLanguage)
      if (savedLocale) document.cookie = localePreferenceCookie(initialLocale, window.location.protocol === 'https:')
      const savedCurrency = readBrowserPreference('star-currency')
      const initialCurrency = isCurrency(savedCurrency)
        ? savedCurrency
        : readCurrencySettings().defaultCurrency
      startTransition(() => {
        setLocaleState(initialLocale)
        setCurrencyState(initialCurrency)
      })
    }
    // Streamed Suspense boundaries may hydrate after the provider commits.
    // An idle task runs only after those urgent hydration tasks have yielded,
    // so persisted text never races the server's initial English snapshot.
    // Safari may omit idle callbacks; keep initialization deferred without
    // throwing during mount or cleanup on those browsers.
    const supportsIdle = typeof window.requestIdleCallback === 'function' && typeof window.cancelIdleCallback === 'function'
    const idleId = supportsIdle
      ? window.requestIdleCallback(applyPersistedPreferences)
      : window.setTimeout(applyPersistedPreferences, 0)
    // The DB snapshot often lands AFTER first paint. New visitors (no saved
    // preference) must adopt the late-arriving admin defaults; visitors with
    // an explicit choice keep it.
    const onRates = () => {
      setRatesVersion((v) => v + 1)
      if (!readStoredLocale()) {
        const next = sanitizeLocale(readLocalizationSettings().defaultLanguage)
        setLocaleState((prev) => (prev === next ? prev : next))
      }
      if (!readBrowserPreference('star-currency')) {
        const next = readCurrencySettings().defaultCurrency
        setCurrencyState((prev) => (prev === next ? prev : next))
      }
    }
    window.addEventListener('sp-currency', onRates)
    window.addEventListener('sp-l10n', onRates)
    const onStorage = (event: StorageEvent) => {
      if (event.key === 'star-locale' || event.key === 'star-currency' || event.key === null) applyPersistedPreferences()
    }
    window.addEventListener('storage', onStorage)
    return () => {
      if (supportsIdle) window.cancelIdleCallback(idleId)
      else window.clearTimeout(idleId)
      window.removeEventListener('sp-currency', onRates)
      window.removeEventListener('sp-l10n', onRates)
      window.removeEventListener('storage', onStorage)
    }
  }, [preview])
  useEffect(() => {
    if (preview) return
    document.documentElement.lang = locale
    document.documentElement.dir = isLocaleRTL(locale) ? 'rtl' : 'ltr'
    window.dispatchEvent(new Event('sp-admin-locale')) // Existing Admin display listeners.
  }, [locale, preview])
  useEffect(() => {
    if (!preview) window.dispatchEvent(new Event('sp-currency'))
  }, [currency, preview])
  const setLocale = useCallback((next: Locale) => {
    const resolved = resolveLocale(next)
    if (!preview) {
      try { window.localStorage.setItem('star-locale', resolved) } catch { /* Cookie still retains the chosen language. */ }
      document.cookie = localePreferenceCookie(resolved, window.location.protocol === 'https:')
    }
    setLocaleState(resolved)
  }, [preview])
  const setCurrency = useCallback((next: Currency) => {
    if (!isCurrency(next)) return
    if (!preview) {
      try { window.localStorage.setItem('star-currency', next) } catch { /* Keep the choice for this page when storage is unavailable. */ }
    }
    setCurrencyState(next)
  }, [preview])
  return <ActiveLocaleScope.Provider value={scope}><LocaleCtx.Provider value={{ locale, setLocale, currency, setCurrency }}><DirectionProvider direction={isLocaleRTL(locale) ? 'rtl' : 'ltr'}>{children}</DirectionProvider></LocaleCtx.Provider></ActiveLocaleScope.Provider>
}

export const useLocale = () => useContext(LocaleCtx) ?? defaultLocaleState

/** Static namespaced lookup; legacy tx/getCopy and persisted catalogue payloads remain valid. */
export function useTranslations(namespace: string) {
  const { locale } = useLocale()
  return useCallback((key: string, englishFallback?: string) =>
    platformTranslations.translate(locale, `${namespace}.${key}`, englishFallback), [locale, namespace])
}

export function formatPrice(usd: number, currency: Currency, locale: Locale) {
  const rate = getCurrencyRates()[currency]
  if (!Number.isFinite(rate) || rate <= 0) return formatCurrency(usd, 'USD', locale)
  const value = usd * rate
  return formatCurrency(value, currency, locale, { minimumFractionDigits: currency === 'EGP' ? 0 : 2, maximumFractionDigits: currency === 'EGP' ? 0 : 2 })
}
