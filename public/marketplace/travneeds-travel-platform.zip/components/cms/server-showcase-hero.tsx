import type { ReactNode } from 'react'
import { ShowcaseHeroProvider } from './showcase-hero-context'
import { readPublicShowcase } from '@/lib/server/cms/showcase-heroes'
import type { ShowcaseHeroId } from '@/lib/cms/showcase-heroes'
export async function ServerShowcaseHero({ id, children }: { id: ShowcaseHeroId; children: ReactNode }) { return <ShowcaseHeroProvider state={await readPublicShowcase(id)}>{children}</ShowcaseHeroProvider> }
