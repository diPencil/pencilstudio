'use client'

import { useEffect, useState } from 'react'
import { RebuiltHomePage } from '@/components/homepage'
import { InitialLocaleProvider } from '@/components/locale'
import type { Locale } from '@/lib/localization/locale-config'
import { readHeroPreviewMessage, type HomeHero } from '@/lib/cms/website-heroes'
import type { PublicPageContent } from '@/lib/cms/page-sections'

export function HomepageHeroPreview({ initialContent, initialLocale, pageContent }: { initialContent: HomeHero | null; initialLocale: Locale; pageContent?: PublicPageContent }) {
  const [content, setContent] = useState(initialContent)
  const [locale, setLocale] = useState(initialLocale)
  useEffect(() => {
    const receive = (event: MessageEvent) => {
      const next = readHeroPreviewMessage(event, window.location.origin, window.parent, window.parent !== window)
      if (!next) return
      setContent(next.content)
      setLocale(next.locale)
    }
    window.addEventListener('message', receive)
    if (window.parent !== window) window.parent.postMessage({ type: 'star-hero-preview-ready' }, window.location.origin)
    return () => window.removeEventListener('message', receive)
  }, [])
  return <InitialLocaleProvider locale={locale} preview><div inert><RebuiltHomePage key={locale} initialLocale={locale} hero={{ hidden: false, content }} pageContent={pageContent} /></div></InitialLocaleProvider>
}
