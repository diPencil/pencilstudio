# Global localization foundation

## Implemented boundary

TravNeeds uses English by default and Arabic with RTL as built-in Core languages.
EN/AR/ES/IT remain the only enabled runtime locales. The static registry and
read-only source contracts below are implemented. Dynamic locale registration,
translation management, generation APIs, review/publishing workflows and Languages
Module licensing remain planned. Translation discovery never enables or licenses
a functional module.

## Locale ownership and compatibility

`app/layout.tsx` mounts the shared `LocaleProvider` inside the server-seeded
`InitialLocaleProvider`. Public, auth, account, booking/checkout and Admin shells
keep their existing wrappers, but nested wrappers in the same scope reuse the
parent state and setters. Route changes therefore do not create competing locale
stores. `useLocale`, `tx`, `getCopy`, `AdminLocaleProvider` and `useAdminLocale`
retain their public APIs.

An explicit `InitialLocaleProvider` boundary establishes a separate scope. CMS
preview scopes keep their selected locale and Base UI direction, without writing
locale/currency preferences or changing the parent document direction. Existing
preview remount keys remain valid.

Valid local-storage preferences take precedence over the existing locale cookie;
invalid stored values cannot mask a valid cookie. Without a saved preference,
existing configured defaults are used; the built-in default remains English.
The server reads the existing `star-locale` cookie and defaults to English.
`star-locale`, `star-currency`, cookie attributes, route paths and session cookies
are unchanged. Cross-tab preference synchronization and legacy `sp-admin-locale`
and `sp-currency` notifications are owned by the shared provider.

Document `lang`/`dir` and Base UI direction follow the active application locale.
An English fallback does not change an Arabic request to LTR. Explicit field
locales still override inherited control locales. Intentional LTR isolation for
phone numbers, email addresses, identifiers, URLs and maps is preserved.

## Translation sources and migration coverage

| Surface | Current source / integration | Remaining work |
| --- | --- | --- |
| Shared controls and language chooser | `core.language`, `core.regions`, `core.controls`; existing copy moved verbatim to `lib/localization/core-messages.ts` | Adopt keys for other repeated shared strings incrementally |
| Public navigation and shared copy | Adapters over `lib/localization/site-copy.ts`: `public.navigation`, `public.shared` | Existing direct dictionary callers remain supported |
| Authentication, customer account, booking/checkout | Shared root context, controls, `tx`, `customer.errors` (85 API mappings plus safe fallback), `customer.auth` metadata and existing domain dictionaries | Assign stable keys to remaining inline/domain copy; keep pricing, ownership and payment logic separate |
| Admin | Existing EN/AR chrome and shared UI use the same context; ES/IT preferences/content remain supported | English fallback remains for untranslated domain strings and some headings |
| CMS | String adapter over `lib/cms/homepage-copy.ts`: `cms.home`; published readers use requested-language fields with English fallback | Structured arrays, editor-specific copy and content descriptors need incremental mapping |
| Catalogue/Tours | Existing entity translation payloads, validation and mappers are unchanged | Expose stable entity/content descriptors without renaming stored fields or losing translations |
| Functional modules | `moduleLocalization(manifest)` exposes metadata under `modules.<id>` for all 26 initial manifests | Populate optional module-owned content/UI contributions as each domain migrates |

Published CMS readers no longer coerce Arabic to English or skip its published
overrides. Missing fields fall back individually to English. Explicit empty
strings remain intentional empty values, matching existing content contracts.
Existing inline Arabic defaults are retained when no CMS snapshot was supplied
and for the existing unavailable-snapshot text fallback.
Visibility/unavailable handling and persisted CMS validators are unchanged.

The existing `getCopy` helper still selects whole locale rows, including arrays;
it is not silently changed into a deep merge. Inline `tx`/`pickLocaleText` retain
their existing fallback semantics. Arrays and structured domain content are not
flattened into positional translation keys by the new registry.

`public.search` owns search states, accessible labels, entity labels and result
counts, including Arabic plurals. Search uses existing published entity overlays
for display and matching while retaining canonical query text and route identities.
Customer API responses and English error lookup strings remain unchanged;
`customerErrorText` selects presentation keys and uses a safe Arabic fallback for
unknown English diagnostics. Existing Arabic UI notices remain supported. Auth,
account actions, checkout and proof notices retain source identifiers/messages in
UI state and select their displayed language at render time. Booking snapshots,
financial values and payment/proof semantics are unchanged.

## Registry and interfaces

`lib/localization/translation-registry.ts` defines immutable static snapshots,
namespaces, source descriptors and optional module contributions.
`platform-translations.ts` composes the existing core/public/CMS dictionaries and
module metadata. It contains no translation network calls, database operations,
locale registration or entitlement checks.

```ts
import { translate } from '@/lib/localization/platform-translations'
import { useTranslations } from '@/components/locale'

translate('ar', 'public.navigation.signIn')
const controls = useTranslations('core.controls') // Inside a React component/hook.
controls('chooseCountry')
```

Keys are namespaced identifiers, not English sentences. Registration rejects
duplicate namespaces/qualified keys and messages without an English source.
Missing locale values use English; defined empty values are preserved. Unknown
keys throw unless the caller explicitly supplies an English fallback. `resolve`
reports requested/resolved locale and fallback status; `describe` provides frozen
source descriptors. Render strings through normal escaping; descriptors do not
authorize rendering untrusted HTML.

`ModuleManifest.localization` optionally supplies module-owned namespaces and
`TranslatableContentDescriptor` entries (key, source, format, optional description
and placeholders). `moduleLocalization` enforces the owning `modules.<id>` prefix.
The default metadata namespace exposes names, descriptions, permissions, features
and navigation labels without changing module lifecycle or licensing contracts.
Entity/domain descriptors are an extension point, not complete content coverage.

`LocaleDefinition` is an extensible metadata interface. `LOCALE_DEFINITIONS` is
still a fixed four-locale snapshot; `Locale` and runtime resolution remain closed
to EN/AR/ES/IT. A future Languages Module may consume descriptors and reviewed
snapshots only after a separately scoped migration. This foundation implements
neither provider credentials nor draft generation/publication APIs.

## Formatting and verification limits

Shared Intl locale mapping now honors Arabic; existing EN/ES/IT mappings and
currency codes are retained. Currency labels/formatting are display-only. No
exchange-rate assumptions, financial amounts, booking contracts or transactions
were changed.

Regression coverage includes scope reuse, preview isolation, preference-cookie
compatibility, registry fallback/collisions, preserved dictionary strings, module
metadata, shared RTL controls and published CMS Arabic selection. Unit tests use
the existing database guard. TypeScript and Node/server-render tests do not prove
rendered layout, keyboard behavior, browser hydration or all RTL presentation.
Browser testing remains prohibited by repository rules; human review is required
for those release checks.

## Admin UI translation coverage

Admin UI copy is registered in `lib/localization/admin/*-messages.ts` under
`admin.*` namespaces. `useAdminTranslations` resolves keys through the shared
registry; its optional preview locale keeps content previews independent from
Admin chrome. Existing inline EN/AR pairs remain compatible. Explicit display
adapters cover legacy feedback and code-owned CMS descriptors without changing
stored values, API errors, toast state, record identifiers or publication payloads.
Native accessibility attributes use string translations, and navigation-tree
spacing uses logical CSS properties for RTL. ES/IT pricing and preview copy retain
their existing dictionaries and fallback behavior.

Coverage still excludes arbitrary external diagnostics and user-authored records.
The existing global SEO settings contract has description fields for EN/ES/IT;
adding an Arabic setting and its metadata consumer requires a separate contract
change. Node/server-render regression tests cover labels, validation presentation,
direction, content-preview isolation and feedback language switching. They do not
replace the human browser review required by the project release policy.

## Transactional emails, issued PDFs and operational notifications

`emails.transactional` registers all 29 existing email events (subjects, HTML and
plain text); `emails.shared` owns footer, guest-link and status labels. Canonical
English definitions now live in `lib/email/templates.ts`; the pure renderer is
`lib/email/render-template.ts`. `lib/server/email.ts` retains SMTP delivery,
recipient routing, failure handling, history and idempotency. No live translation
provider is called and translation code does not log recipient data or tokens.

Customers save a preferred language in Account Settings. Staff save it in their
Admin profile. Both use a session-owned language endpoint with same-origin write
checks and share the nullable `User.preferredLocale` field. EN, AR, ES and IT remain
available independently of the planned Languages Module. Saving a language also
updates the current browser through the existing locale provider. The browser
language selector continues to control the current device, while the profile
language follows the recipient across devices.

Transactional email uses a trusted explicit override, then the saved language of
the active account matching the recipient's normalized address. If no preference
is available, the request cookie is used only when an active, unexpired session
owns the recipient email address. All other cases use English. The lookup does
not renew sessions or copy another sender's language.

`documents.booking` supplies document headings, labels, statuses and notices.
Authorized downloads use a trusted explicit locale or the active linked booking
owner's saved language. When unset, the verified owner can still use their
request cookie. Staff and guest downloads fall back to English. All six issued
document types have an
Arabic rendition. `lib/server/pdf/render-localized.ts` also renders Arabic names
and notes in English documents; Latin-only EN/ES/IT documents keep the original
renderer and existing English fallback. Numbers, money, snapshots, references,
verification URLs and issuance rules remain unchanged; no historical rows or
stored documents are rewritten.

The localized PDF path bundles renamed static Cairo derivatives with their SIL
OFL license and provenance in `lib/server/pdf/fonts/ARABIC-FONTS.md`. PDFKit/fontkit
performs OpenType Arabic shaping. `bidi-js` 1.0.3 supplies Unicode 13 bidirectional
run ordering and punctuation mirroring; logical Arabic text is shaped as whole
runs rather than reversed characters. Mixed fonts share an alphabetic baseline,
long text wraps, label/value columns mirror in RTL, and original QR data stays
intact. Bundled fonts cover Arabic/Latin, not all scripts or emoji; extraction
order and accessibility can vary between PDF readers. No PDF/UA certification is
claimed. Synthetic fixtures are rendered and inspected locally without a browser.

`notifications.operational` maps the 29 variants currently emitted by booking,
payment, request, enquiry and support services. Display overlays apply in the shared
notification panel, Account and Admin history. Existing rows, types, identifiers,
read states, routing and API response bodies remain canonical. The authenticated
GET endpoints send the saved preference in a private, non-cacheable
`X-Operational-Locale` header. The client applies it to operational text only and
keeps the existing display locale fallback when no preference is set.
Unknown/custom historical
messages retain English fallback; marketing EN/AR/ES/IT content and identity rules
retain precedence. Unmapped diagnostics (including SMTP/provider, validation and
API error strings outside these templates) remain a separate translation task.

## Remaining Core coverage

| Domain | Remaining work |
| --- | --- |
| Public | Stock and operator-authored catalogue copy can fall back to English. Check public Hotels detail accessibility labels in `components/hotels/hotel-detail-page.tsx`. |
| Admin | The Appearance editor's isolated sample in `components/admin/cms/website-appearance.tsx` is English/LTR. New server validation and legacy inline strings still need a domain-level review. |
| CMS | Published FAQ, policy and SEO Arabic is selected where present. Stock FAQ and legal copy in `lib/cms/additional-page-content.ts` needs approved Arabic content. Missing legacy Arabic rows use English on read without rewriting stored values. |
| Account and Booking | Auth and common errors use the registry. Customer-entered data, snapshots, payment instructions and provider messages retain their source text. Review default planner metadata in `app/make-your-trip/page.tsx`. |
| Functional modules | Car Pricing selects follow Arabic direction. Route/place names still come from English source fields in `components/admin/cars/car-pricing-manager.tsx`. Functional module manifests expose UI keys but still need entity field descriptors in `lib/modules/localization.ts`. |
| Emails and PDFs | Code-owned email templates and the six PDF types support EN/AR. Provider diagnostics, user content and financial snapshots keep their source values. PDF font and extraction limits are documented above. |
| Notifications | Known operational templates localize at display time. Unknown/custom historical messages retain stored copy. Marketing keeps its existing ES/IT overlays. |

Prioritize actionable English-only labels and provider-facing error presentation,
then add stable field descriptors for authored content. Review versioning and
publication before implementing the optional Languages Module.

## Profile language migration

The proposed migration adds one nullable `VARCHAR(16)` column,
`users.preferredLocale`. Existing users need no backfill and keep their current
browser settings. After approval, review the pending Prisma migration list in
the target environment and apply the additive migration before serving code with
the regenerated Prisma Client. Generate the client during the release build or
on the target machine, then restart the application. Verify separate customer
and staff preferences, recipient routing, and fallback in an isolated
environment. The draft SQL is available in the migrations directory for review.
