# TravNeeds Design System

This document records existing public and Admin visual conventions; it does not
authorize a redesign. Tokens and component-specific styles in the repository
are the implementation sources. Accessibility and localization statements below
are acceptance requirements, not claims that every screen was runtime-tested.
Product layers and the planned Languages Module are defined in `README.md`;
engineering and verification rules live in `constitution.md`.

## 1. Design philosophy
The public interface uses bright white surfaces, blue navigation/panels, warm orange actions, compact travel cards, generous section whitespace, and image-led storytelling. Preserve its flat editorial identity, subtle borders, restrained shadows, and large travel-planning controls. The Admin uses a denser operations layout with its own scoped tokens; it belongs to the same independently installed product.

## 2. Reference hierarchy
`components/homepage.tsx` owns the composition: header/promotion, hero/search, statistics, featured tours, popular catalogue, planner, offers, How it works, highlights, editorial and supporting sections, help and footer. CMS section visibility, selections and published copy affect what appears. Preserve the current composition and configured content rather than imposing an older static screenshot order or hardcoded seasonal title.

## 3. Color tokens
- `--primary`: `#F7951D`, action orange.
- `--primary-hover`: `#E88410`, hover orange.
- `--blue`: `#1D4ED8`, current public blue token. Admin retains `--sp-blue: #163A96` and `--sp-blue-deep: #0D2250`; do not normalize these into one color.
- `--text`: `#1D1F1F`, primary copy.
- `--muted`: `#737983`, labels and secondary copy.
- `--surface`: `#FFFFFF`.
- `--soft`: `#F7F7F7`.
- `--border`: `#DEDEDE`.

These are base values from `app/globals.css`. Published appearance settings
render through `components/cms/public-appearance.tsx` and may override selected
public tokens. Preserve that contract and existing scoped colors. Do not change
tokens to match outdated documentation.

## 4. Typography
`app/layout.tsx` loads Montserrat for Latin content (weights 400–800) and Alexandria for Arabic (400–700). `app/globals.css` applies Alexandria under `html[dir='rtl']`; system/Arial fonts are fallbacks. Public display headings commonly use 42–68px with tight line-height; section headings approximately 29–42px, card titles around 17px, body copy 13–16px, and buttons/labels 13–18px at 600–700 weight. Scoped page/mobile rules override these ranges, including smaller phone hero headings. Preserve Arabic shaping, readable line-height and text expansion rather than forcing Latin dimensions.

## 5. Spacing and containers
The spacing foundation favors 4px increments, with established exceptions in existing layouts. Root tokens are `--page:1530px`, `--content:1450px`, and `--page-gutter:48px`; media rules reduce gutters to 40px/32px and phone containers commonly retain 16px per side. Section rules vary: `.section` uses 76px desktop/54px phone, while `.home-section` starts at 70px. Reuse the owning layout's rule rather than applying one spacing value globally.

## 6. Layout and breakpoints
Public grids commonly start with four tour/destination columns or three editorial columns; existing page rules reduce them at 1400px, 1100px/1024px and 760px as appropriate. `app/mobile-shell.css`, imported after globals, controls the public mobile shell at up to 1024px: sticky header, drawer navigation, mobile search/bottom navigation and booking shortcuts. At up to 760px the homepage hero uses bounded media above the search engine. Admin/account layouts have separate responsive rules; do not copy storefront breakpoints into them.

## 7. Radius and borders
Root radius tokens are `--radius-xs:4px`, `--radius-sm:8px`, `--radius-md:16px`, `--radius-card:22px`, and `--radius-large:32px`. Existing scoped controls also use pills, 18px inputs, approximately 18–22px cards, 22–32px banners, 30px dialogs and circular icon actions. Borders are generally 1px using the relevant public/Admin border token; avoid heavy new shadows.

## 8. Buttons
Primary buttons are orange pills with white 600–700 weight text, 52–58px height, and 15px horizontal padding minimum. Outline buttons are blue bordered pills. Icon buttons are 42–54px circles. Hover is a darker orange and a 1px lift; focus-visible should use a visible blue/orange ring.

## 9. Inputs, radios, selects
Search fields are large rounded containers with muted placeholder text, visible labels and calendar/chevron affordances; desktop fields commonly use 58–70px minimum heights, with scoped mobile overrides. Radio options use circular selection indicators or the existing button variants. The hero search uses a rounded segmented tab control with an active indicator; preserve its current shape and state behavior rather than restoring older top-pill styling.

## 10. Search module
The desktop search engine overlays the hero via `.search-wrap`; desktop homepage rules position it below the headline. It has Make Your Trip, Find your trip and Rent Car tabs with distinct controls and CTA behavior. Mobile-shell rules place it in normal flow below the hero media, with responsive field grids and full-width actions. Preserve the current tabs, date controls, selection state and query contracts; do not restore the obsolete mobile overlap layout.

## 11. Cards
Tour cards share one reusable component: 175px image, heart action, optional red Special Offer badge, teal/orange metadata, 17px title, price, and duration pill. Destination cards are 250px image-led overlays. Blog cards use 190px images, small metadata, title, and blue text link. Hover elevation is limited to a subtle 8px/24px shadow.

## 12. Navigation and promo bar
The header is white with an 88px base desktop top row, logo, navigation, language/currency, cart and account actions. Scoped mobile/sticky rules change its height and arrangement. The homepage promotional bar has an 80px base minimum height, blue background, white copy and orange CTA; CMS and responsive rules govern its current content and spacing.

## 13. Hero and floating actions
The desktop homepage hero uses full-bleed cover media, a readable shade, centered white copy and an overlay search engine; current `.home-hero` desktop minimum height is 560px. Phone media uses an 8:5 aspect ratio with centered copy and the search below. Other page heroes have scoped dimensions and CMS content. Floating support/chat controls must respect existing responsive offsets, bottom navigation and booking actions rather than covering fields or CTAs.

## 14. Accordions, modal and gallery
The homepage FAQ uses native `details`/`summary` rows, with the first visible item initially open; do not assume exclusive accordion behavior. The shared language/currency dialog in `components/layout/language-selector.tsx` uses a scrim, close action and selected options, with a current 480px width cap overriding older 635px styling. The homepage journey gallery uses media marquees and `components/shared/gallery-lightbox.tsx` for selected images/videos, including keyboard activation and loading/error states; the old three-image gallery is not its current architecture.

## 15. Footer and forms
The help panel is blue with inline fields on desktop and stacked fields on mobile. The footer is charcoal with logo/description, links, contact information, and copyright/legal row. Inputs retain white backgrounds and rounded 10px corners.

## 16. Motion and z-index
Use the existing short hover/control transitions (commonly 150–220ms); marquees and galleries have scoped animation rules. Honor reduced-motion preferences for nonessential motion. Z-index is scoped, not one universal stack: the public mobile sticky header is 45, while dialogs, search and support controls follow their owning styles. In Admin the shared toaster (`.sp-toaster`, `components/admin/ui/admin-toaster.tsx`) sits at 60, below the full-screen confirm backdrop at 80 and above the sticky user menu/search at 50. The toast stack uses `pointer-events:none` and individual toasts use `auto`.

Admin modules surface backend action results through the shared `toast` API instead of inline success paragraphs: `toast.success/info` (auto-dismiss 4000ms), `toast.warning` (5000ms), `toast.error` (8000ms), and `toast.loading` (sticky until resolved, then updated in place). Pass a stable `dedupeKey` per logical action so retries replace the visible toast instead of stacking. Page-load failures keep inline error states with retry buttons; persistent notification history stays in the Notification Center, never in toasts. Toast copy must follow the module's English/Arabic (AdminText) conventions and toasts survive one page reload via a session-scoped snapshot but never persist to the notification store.

## 17. Accessibility
All meaningful images have alt text, icon-only controls have accessible labels, modal close and buttons are keyboard targets, form fields have labels, status feedback uses `role=status`, and semantic header/nav/main/section/footer elements are used. Color is not the sole indicator of interaction state.

## 18. Responsive rules
Mobile preserves content order and hierarchy. Follow `app/mobile-shell.css` for drawer/search/bottom navigation, hero media and engine flow; many shell controls are 44px and general form controls have a 48px base minimum. Tabs, wrapping, stacking and grids follow their owning component rather than a universal scroll rule. Keep support actions clear of forms, safe-area insets and booking controls; retain spacious constrained desktop sections. These are source conventions, not a rendered-device verification claim.

## 19. Image ratios
Tour images use roughly 1.8:1, destinations use tall 1:1.1 cards, highlight thumbnails use landscape crops, blogs use 1.8:1, and the hero uses full-bleed cover positioning.

## 20. Component consistency
Reuse `Heading`, `Field`, `TourCard`, shared button classes, Base UI/shadcn primitives and Lucide icons before introducing alternatives. Public tokens live in `app/globals.css`, public shell overrides in `app/mobile-shell.css`, and homepage composition in `components/homepage.tsx`. Tour presentation lives under `components/tours/`; live Tour content comes through `lib/server/tours.ts` and catalogue APIs, with `data/tours.ts` retained as reference/bootstrap content.

## 21. Admin visual architecture

`app/admin/layout.tsx` composes the guarded staff layout and shared
`components/admin/admin-shell.tsx`. Reuse `components/admin/admin-ui.tsx`,
`components/admin/ui/` and domain editors under `components/admin/{domain}/`.
Admin CSS is scoped to `.sp-admin` in `app/admin/admin.css`, with responsive
overrides in `app/admin/mobile.css` and domain styles beside components.

Base Admin tokens include blue `#163A96`, deep blue `#0D2250`, orange `#F7951D`,
background `#F4F6FB`, white cards, text `#1D1F1F`, muted `#737983` and border
`#E5E9F2`. The sidebar is 264px expanded/84px collapsed, with grouped navigation
and a sticky operational shell. Preserve current cards, tables, forms, filters,
drawers, dialogs, empty/error states and responsive behavior. Admin is not a
storefront landing page; reuse its existing density and components. `sp-*`
selectors are compatibility identifiers, not a reason to rebrand or rewrite CSS.

## 22. Language and RTL acceptance

English is default and Arabic is the second built-in core language with full
RTL. The optional, independently licensed Languages Module is **planned** for
Spanish, Italian and other additional languages; current EN/AR/ES/IT selectors
and translations stay operational until a separately scoped migration.

Admin uses `AdminLocaleProvider` and the shared locale context for its shell,
PageHead and shared controls. Arabic sets RTL on the Admin root, document and
Base UI direction context; use existing logical-property styles and directional
icons. Missing domain translations retain English fallback. Source/unit checks
do not prove rendered accessibility or RTL parity across every Admin screen.

The root locale provider now supplies the same state/direction across Public,
Customer Account, auth and booking/checkout. Existing nested shells reuse it;
explicit CMS preview scopes retain their own locale and Base UI direction.
Shared controls inherit locale unless an editor explicitly supplies a field
locale. Preserve LTR isolation for phones, emails, identifiers and URLs.
Use the namespaced registry for new shared copy and retain existing dictionaries
during incremental migration; see `docs/localization-foundation.md`.

- Apply locale direction consistently to public and Admin shells, dialogs,
  menus, tables, forms, toasts and document/email presentation. Use logical
  properties and directional icons where appropriate; do not mirror imagery,
  logos, numbers or media indiscriminately.
- Keep email addresses, URLs, reference codes and mixed-direction values
  readable with appropriate bidirectional isolation. Preserve keyboard order,
  visible focus, accessible names and field-error relationships in each locale.
- Allow translated text to wrap and expand without clipped controls or changed
  hierarchy. Keep currency/date formatting distinct from translating copy.
- Every functional module must expose translatable UI/content and stable keys;
  do not bake new language-specific layouts into module components. Preserve
  existing Spanish/Italian content through migration and English fallback.
- Future translation management must visibly distinguish drafts, generated
  text, review status and published revisions. Generated translations require
  review before publication; unavailable published text falls back to English
  while maintaining the selected locale's direction and formatting.

See `README.md` for the planned workflow and migration contract. This document
does not claim dynamic locale registration or translation publishing exists.
Verify with source review and permitted non-browser checks under
`constitution.md`; agents must not use browser testing. Report unverified
rendered layout, accessibility and RTL behavior honestly.
