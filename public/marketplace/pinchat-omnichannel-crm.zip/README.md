# 🌟 بنتشات CRM (PinChat CRM) - منصة إدارة WhatsApp الموحدة والذكية

![PinChat Logo](./public/meras-logo.png)

## 📋 نظرة عامة

**بنتشات CRM (PinChat CRM)** هو نظام CRM (إدارة علاقات العملاء) متكامل ومتطور مصمم خصيصاً لإدارة محادثات WhatsApp للأعمال. يوفر واجهة موحدة لإدارة جميع تفاعلات العملاء من مكان واحد مع دعم كامل للأتمتة والتحليلات.

---

## 🚀 التقنيات المستخدمة

### اللغات والأطر
- **TypeScript 5** - لغة البرمجة الرئيسية
- **Next.js 16.0.10** - إطار عمل React للتطبيقات الحديثة
- **React 19.2.0** - مكتبة بناء واجهات المستخدم
- **Node.js** - بيئة التشغيل

### التصميم والواجهة
- **Tailwind CSS 4.1.9** - إطار عمل CSS الحديث
- **Radix UI** - مكتبة مكونات UI عالية الجودة
- **Lucide React** - مكتبة أيقونات حديثة
- **next-themes** - دعم الوضع الليلي/النهاري

### المكتبات المساعدة
- **React Hook Form** - إدارة النماذج
- **Zod** - التحقق من صحة البيانات
- **date-fns** - معالجة التواريخ
- **Recharts** - الرسوم البيانية
- **Vercel Analytics** - تحليلات الأداء

---

## 📁 بنية المشروع

```
MerasNode/
│
├── 📂 app/                          # صفحات التطبيق (Next.js App Router)
│   ├── 📄 page.tsx                 # صفحة تسجيل الدخول الرئيسية
│   ├── 📄 layout.tsx               # Layout الرئيسي للتطبيق
│   ├── 📄 globals.css              # أنماط CSS العامة
│   │
│   ├── 📂 dashboard/               # لوحة التحكم
│   │   ├── page.tsx               # صفحة Dashboard الرئيسية
│   │   └── loading.tsx            # حالة التحميل
│   │
│   ├── 📂 inbox/                   # صندوق الوارد (المحادثات)
│   │   ├── page.tsx               # قائمة المحادثات
│   │   └── loading.tsx
│   │
│   ├── 📂 contacts/                # إدارة جهات الاتصال
│   │   ├── page.tsx               # قائمة جهات الاتصال
│   │   └── loading.tsx
│   │
│   ├── 📂 templates/               # قوالب الرسائل
│   │   ├── page.tsx               # إدارة القوالب
│   │   └── loading.tsx
│   │
│   ├── 📂 bot-flows/               # سير العمل الآلي
│   │   ├── page.tsx               # إدارة Bot Flows
│   │   └── loading.tsx
│   │
│   ├── 📂 accounts/                # حسابات WhatsApp
│   │   ├── page.tsx               # إدارة الحسابات
│   │   └── loading.tsx
│   │
│   ├── 📂 users/                   # إدارة المستخدمين
│   │   ├── page.tsx               # قائمة المستخدمين
│   │   └── loading.tsx
│   │
│   ├── 📂 logs/                    # السجلات
│   │   ├── page.tsx               # عرض السجلات
│   │   └── loading.tsx
│   │
│   └── 📂 settings/                # الإعدادات
│       ├── page.tsx               # صفحة الإعدادات
│       └── loading.tsx
│
├── 📂 components/                   # مكونات React القابلة لإعادة الاستخدام
│   ├── 📄 app-layout.tsx           # Layout التطبيق الداخلي
│   ├── 📄 navigation-rail.tsx      # القائمة الجانبية
│   ├── 📄 top-bar.tsx              # الشريط العلوي
│   ├── 📄 language-switcher.tsx    # مبدل اللغة (عربي/إنجليزي)
│   ├── 📄 theme-provider.tsx       # مزود الثيم (ليلي/نهاري)
│   │
│   ├── 📂 ui/                      # مكونات UI الأساسية (57 مكون)
│   │   ├── button.tsx             # أزرار
│   │   ├── input.tsx              # حقول الإدخال
│   │   ├── card.tsx               # بطاقات
│   │   ├── dialog.tsx             # نوافذ منبثقة
│   │   ├── dropdown-menu.tsx      # قوائم منسدلة
│   │   ├── select.tsx             # قوائم اختيار
│   │   ├── checkbox.tsx           # مربعات اختيار
│   │   ├── switch.tsx             # مفاتيح تبديل
│   │   ├── tabs.tsx               # تبويبات
│   │   ├── toast.tsx              # إشعارات
│   │   ├── avatar.tsx             # صور المستخدمين
│   │   ├── badge.tsx              # شارات
│   │   ├── calendar.tsx           # تقويم
│   │   ├── chart.tsx              # رسوم بيانية
│   │   ├── table.tsx              # جداول
│   │   └── ... (42 مكون إضافي)
│   │
│   └── 📂 inbox/                   # مكونات خاصة بصندوق الوارد
│       ├── chat-area.tsx          # منطقة المحادثة
│       ├── conversation-list.tsx  # قائمة المحادثات
│       └── message-input.tsx      # حقل إدخال الرسائل
│
├── 📂 lib/                          # مكتبات ووظائف مساعدة
│   ├── 📄 i18n.tsx                 # نظام الترجمة (عربي/إنجليزي)
│   ├── 📄 utils.ts                 # وظائف مساعدة عامة
│   └── 📄 ...                      # مكتبات إضافية
│
├── 📂 hooks/                        # React Hooks مخصصة
│   └── 📄 ...                      # Hooks مخصصة
│
├── 📂 public/                       # ملفات ثابتة
│   ├── favicon.png                # أيقونة الموقع
│   ├── meras-logo.png             # شعار PinChat
│   └── ...                        # صور وملفات أخرى
│
├── 📂 styles/                       # ملفات CSS إضافية
│
├── 📄 package.json                  # تبعيات المشروع
├── 📄 tsconfig.json                 # إعدادات TypeScript
├── 📄 next.config.mjs               # إعدادات Next.js
├── 📄 tailwind.config.ts            # إعدادات Tailwind CSS
├── 📄 postcss.config.mjs            # إعدادات PostCSS
├── 📄 components.json               # إعدادات shadcn/ui
└── 📄 proxy.ts                      # إعدادات Proxy

```

---

## 🎯 الميزات الرئيسية

### 1. 🔐 نظام المصادقة
- صفحة تسجيل دخول حديثة وجذابة
- بيانات تجريبية جاهزة:
  - **البريد:** `admin@pinchatcrm.com`
  - **كلمة المرور:** `admin123`
- تصميم Hero Section يعرض إحصائيات المنصة

### 2. 📊 لوحة التحكم (Dashboard)
- **إحصائيات في الوقت الفعلي:**
  - إجمالي المحادثات
  - جهات الاتصال النشطة
  - المشاكل المحلولة اليوم
  - متوسط وقت الاستجابة
- **رسوم بيانية تفاعلية:**
  - المحادثات عبر الزمن
  - اتجاهات وقت الاستجابة
- **سجل النشاطات الأخيرة**

### 3. 💬 صندوق الوارد (Inbox)
- واجهة شبيهة بـ WhatsApp Web
- **فلترة المحادثات:**
  - الكل
  - غير مقروء
  - مؤرشف
  - محظور
- إرسال واستقبال الرسائل
- دعم الوسائط المتعددة

### 4. 👥 إدارة جهات الاتصال
- إضافة وتعديل جهات الاتصال
- **معلومات تفصيلية:**
  - الاسم والهاتف
  - البريد الإلكتروني
  - الوسوم (Tags)
  - الملاحظات
  - تاريخ المتابعة
- بحث متقدم وفلترة

### 5. 📝 قوالب الرسائل
- إنشاء قوالب رسائل جاهزة
- **تصنيف حسب:**
  - الفئة
  - اللغة
  - الحالة (معتمد، قيد الانتظار، مرفوض)
- استخدام سريع في المحادثات

### 6. 🤖 سير العمل الآلي (Bot Flows)
- **أتمتة الردود:**
  - ردود تلقائية
  - رسائل ترحيبية
  - رسائل خارج أوقات العمل
- **تصميم سير عمل مخصص:**
  - محفزات (Triggers)
  - خطوات متسلسلة
  - شروط وقواعد
- تفعيل/تعطيل الـ Flows

### 7. 📱 إدارة حسابات WhatsApp
- ربط حسابات WhatsApp متعددة
- **متابعة حالة الاتصال:**
  - متصل
  - غير متصل
  - في انتظار
- دعم مزودي خدمة مختلفين

### 8. 👨‍💼 إدارة المستخدمين
- دعوة أعضاء الفريق
- **تعيين الأدوار:**
  - مدير
  - مشرف
  - وكيل
- **متابعة الحالة:**
  - متصل
  - غير متصل
  - بعيد

### 9. 📋 السجلات (Logs)
- تتبع جميع الأنشطة
- فلترة حسب:
  - النوع
  - التاريخ
  - المستخدم
- تصدير السجلات

### 10. ⚙️ الإعدادات
- **إعدادات عامة:**
  - اسم الشركة
  - المنطقة الزمنية
  - اللغة الافتراضية
- **الإشعارات**
- **الأمان**
- **التكاملات**

---

## 🔒 RBAC & Delete Policy (صلاحيات المشرفين والحذف)

### قواعد الحذف للمشرف (Supervisor)
- **واجهة المستخدم:** لا تظهر أي أزرار أو عناصر "حذف" للمشرفين (جهات الاتصال، الحجوزات، العروض، الفروع، المستخدمين، الحسابات، التكاملات، مفاتيح API). لا توجد عناصر حذف في القوائم المنبثقة ولا اختصارات لوحة المفاتيح للحذف.
- **واجهة برمجة التطبيقات (API):** أي طلب `DELETE` من مستخدم بدور **Supervisor** يُرجع **403 Forbidden**. يتم تسجيل كل محاولة حذف (ناجحة أو مرفوضة) في سجل التدقيق.
- **التدقيق (Audit):** كل محاولة حذف تُسجَّل (الفاعل، الوقت، المورد، الحالة السابقة). المحاولات المرفوضة للمشرفين تُسجَّل أيضاً.
- **الاستثناء:** الحذف الفعلي (hard delete) مسموح فقط لـ **Admin** ويتم عبر مسار مُراجع ومسجّل.

### ملخص تقني (Technical summary)
- **UI:** Delete controls are hidden for Supervisor using `hasPermission(role, 'delete_*')` or Admin-only checks where no delete permission exists (e.g. accounts, integrations).
- **API:** `requireDeleteAllowed()` in `lib/api-auth.ts` blocks Supervisor (403) and logs the attempt; only Admin can proceed with hard delete.
- **Audit:** `logActivity({ action: 'DELETE_BLOCKED' | 'DELETE', entityType, entityId, oldValues, userId })` for all delete attempts.

---

## 🌐 الدعم متعدد اللغات (i18n)

### اللغات المدعومة
- ✅ **العربية** (دعم كامل RTL)
- ✅ **الإنجليزية**

### الترجمات المتاحة
- أكثر من **100 ترجمة** جاهزة
- تغطي جميع أجزاء التطبيق
- تبديل سلس بين اللغات
- حفظ تفضيلات المستخدم

### ملف الترجمة
جميع الترجمات موجودة في: [`lib/i18n.tsx`](./lib/i18n.tsx)

---

## 🎨 نظام التصميم

### الألوان الرئيسية
```css
/* تدرجات زرقاء وسماوية */
- Blue: #3B82F6
- Sky: #0EA5E9
- Cyan: #06B6D4

/* تدرجات رمادية */
- Slate: #64748B
- Gray: #6B7280
```

### الظلال
```css
- shadow-soft: ظل ناعم للبطاقات
- shadow-floating: ظل عائم للعناصر المرتفعة
```

### الزوايا المستديرة
```css
- rounded-xl: 0.75rem
- rounded-2xl: 1rem
- rounded-3xl: 1.5rem
```

### الحركات والانتقالات
- انتقالات سلسة (transition-all)
- تأثيرات hover جذابة
- رسوم متحركة للتحميل

---

## 🚀 البدء مع المشروع

### المتطلبات
- **Node.js** 18+ (موصى به)
- **pnpm** (مدير الحزم)

### التثبيت

```bash
# 1. استنساخ المشروع
git clone <repository-url>
cd MerasNode

# 2. تثبيت التبعيات
pnpm install

# 3. تشغيل بيئة التطوير
pnpm dev

# 4. فتح المتصفح على
http://localhost:3000
```

### الأوامر المتاحة

```bash
# تشغيل بيئة التطوير
pnpm dev

# بناء المشروع للإنتاج
pnpm build

# تشغيل النسخة المبنية
pnpm start

# فحص الأكواد (Linting)
pnpm lint
```

### نشر على AWS وتحديث المفاتيح

عند النشر عبر Git (`git push` ثم `git pull` على السيرفر): **تعديلات ملف `.env` (المفاتيح) لا تُرفع مع الريبو** لأن الملف مستثنى في `.gitignore`. لو غيّرت مفاتيحاً محلياً ولم تظهر على السيرفر، انسخ `.env` إلى السيرفر ثم أعد تشغيل التطبيق. التفاصيل في [docs/DEPLOY-FAST-WITH-GIT.md](./docs/DEPLOY-FAST-WITH-GIT.md#%D9%85%D9%87%D9%85-%D8%AA%D8%AD%D8%AF%D9%8A%D8%AB-%D8%A7%D9%84%D9%85%D9%81%D8%A7%D8%AA%D9%8A%D8%AD-env-%D8%B9%D9%84%D9%89-%D8%A7%D9%84%D8%B3%D9%8A%D8%B1%D9%81%D8%B1).

**صور المحادثات (Inbox):** لكي تظهر الصور بعد كل نشر أو عند فتح الواجهة من دومين آخر (مثلاً التطوير محلياً مع بيانات السيرفر)، ضع في `.env` على السيرفر عنوان التطبيق الفعلي، مثلاً: `NEXT_PUBLIC_APP_URL=https://pinchatcrm.com` (الدومين الحالي). بهذا تُحمَّل الوسائط دائماً من عنوان التطبيق الصحيح.

---

## 📦 التبعيات الرئيسية

### إطار العمل والمكتبات الأساسية
```json
{
  "next": "16.0.10",
  "react": "19.2.0",
  "react-dom": "19.2.0",
  "typescript": "^5"
}
```

### مكونات UI (Radix UI)
```json
{
  "@radix-ui/react-dialog": "1.1.4",
  "@radix-ui/react-dropdown-menu": "2.1.4",
  "@radix-ui/react-select": "2.1.4",
  "@radix-ui/react-tabs": "1.1.2",
  "@radix-ui/react-toast": "1.2.4",
  // ... +15 مكون إضافي
}
```

### التصميم
```json
{
  "tailwindcss": "^4.1.9",
  "@tailwindcss/postcss": "^4.1.9",
  "tailwindcss-animate": "^1.0.7"
}
```

### النماذج والتحقق
```json
{
  "react-hook-form": "^7.60.0",
  "zod": "3.25.76",
  "@hookform/resolvers": "^3.10.0"
}
```

---

## 🔧 الإعدادات

### TypeScript (`tsconfig.json`)
```json
{
  "compilerOptions": {
    "target": "ES6",
    "lib": ["dom", "dom.iterable", "esnext"],
    "strict": true,
    "jsx": "preserve",
    "paths": {
      "@/*": ["./*"]
    }
  }
}
```

### Next.js (`next.config.mjs`)
```javascript
{
  typescript: {
    ignoreBuildErrors: true  // تجاهل أخطاء TypeScript في البناء
  },
  images: {
    unoptimized: true  // الصور غير محسّنة
  }
}
```

---

## 📱 التوافق

### المتصفحات
- ✅ Chrome/Edge (آخر إصدارين)
- ✅ Firefox (آخر إصدارين)
- ✅ Safari (آخر إصدارين)

### الأجهزة
- ✅ Desktop (1920x1080+)
- ✅ Laptop (1366x768+)
- ✅ Tablet (768x1024)
- ✅ Mobile (375x667+)

### الميزات
- ✅ Responsive Design
- ✅ Dark/Light Mode
- ✅ RTL Support (Arabic)
- ✅ Touch Gestures

---

## 🔒 الأمان

### المصادقة الحالية
- نظام بسيط باستخدام `localStorage`
- **ملاحظة:** للإنتاج، يُنصح باستخدام:
  - JWT (JSON Web Tokens)
  - OAuth 2.0
  - NextAuth.js

### التوصيات
- [ ] إضافة نظام JWT
- [ ] تشفير البيانات الحساسة
- [ ] HTTPS في الإنتاج
- [ ] Rate Limiting
- [ ] CSRF Protection

---

## 🗺️ خارطة الطريق

### المرحلة الحالية ✅
- [x] واجهة مستخدم كاملة
- [x] نظام تنقل متكامل
- [x] دعم لغوي ثنائي (عربي/إنجليزي)
- [x] نظام تصميم موحد
- [x] مكونات UI قابلة لإعادة الاستخدام

### قيد التطوير 🚧
- [ ] ربط Backend API
- [ ] تكامل WhatsApp Business API
- [ ] قاعدة بيانات حقيقية
- [ ] نظام مصادقة متقدم
- [ ] WebSocket للرسائل الفورية

### المستقبل 🔮
- [ ] تطبيق موبايل (React Native)
- [ ] تحليلات متقدمة بالذكاء الاصطناعي
- [ ] دعم قنوات إضافية (Telegram, Instagram)
- [ ] API عامة للمطورين
- [ ] Marketplace للإضافات

---

## 📚 الموارد والمراجع

### التوثيق
- [Next.js Documentation](https://nextjs.org/docs)
- [React Documentation](https://react.dev)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [Radix UI](https://www.radix-ui.com/docs)
- [TypeScript](https://www.typescriptlang.org/docs)

### الأدوات المستخدمة
- [Vercel](https://vercel.com) - الاستضافة والنشر
- [shadcn/ui](https://ui.shadcn.com) - مكونات UI
- [Lucide Icons](https://lucide.dev) - الأيقونات

---

## 🤝 المساهمة

نرحب بالمساهمات! إذا كنت ترغب في المساهمة:

1. Fork المشروع
2. إنشاء فرع للميزة (`git checkout -b feature/AmazingFeature`)
3. Commit التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. Push للفرع (`git push origin feature/AmazingFeature`)
5. فتح Pull Request

---

## 📄 الترخيص

هذا المشروع مملوك لـ **بنتشات CRM (PinChat CRM)** © 2026. تصميم وتطوير Pencil Studio. جميع الحقوق محفوظة.

---

## 📞 التواصل والدعم

- **الموقع:** [pinchatcrm.com](https://pinchatcrm.com)
- **البريد:** support@pinchatcrm.com
- **الدعم الفني:** tech@pinchatcrm.com

---

## 🙏 شكر وتقدير

شكراً لاستخدامك **بنتشات CRM (PinChat CRM)**! نحن نعمل باستمرار على تحسين المنصة وإضافة ميزات جديدة.

إذا واجهت أي مشاكل أو لديك اقتراحات، لا تتردد في التواصل معنا.

---

**صُنع بـ ❤️ في السعودية**
