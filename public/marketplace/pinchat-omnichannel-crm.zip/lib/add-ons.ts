import type { ComponentType } from "react"
import {
  AlertCircle,
  Ampersand,
  AtSign,
  BarChart3,
  Brain,
  CalendarDays,
  ClipboardList,
  Code,
  CreditCard,
  Database,
  Download,
  FileText,
  FormInput,
  Globe,
  Instagram,
  Link2,
  Lock,
  Mail,
  Megaphone,
  MessageCircleMore,
  MessageSquare,
  MessagesSquare,
  MonitorSmartphone,
  PaletteIcon,
  Smartphone,
  Receipt,
  Send,
  Shield,
  Sparkles,
  Store,
  Tag,
  TrendingUp,
  Users,
  Video,
  Zap,
  Workflow,
} from "lucide-react"
import type { ChannelType } from "@/lib/channels"

export type AddOnSection = "channels" | "aiAutomation" | "business" | "analytics" | "commerce" | "marketing" | "team" | "platform"
export type AddOnType = "channel" | "module"
export type AddOnStatus = "connected" | "active" | "setup_ready" | "coming_soon" | "inactive"
export type AddOnCategory = "Messaging" | "Meta" | "Social" | "Communication" | "Web" | "Google" | "AI" | "Automation" | "CRM" | "Lead Generation" | "Analytics" | "Customer Experience" | "Sales CRM" | "Operations" | "Payments" | "Marketing" | "Team Collaboration" | "Developer Tools" | "Enterprise" | "Security" | "Data Management" | "Integrations" | "Platform"
export type AddOnIcon = ComponentType<{ className?: string }>
export type AddOnId =
  | "whatsapp"
  | "facebook_messenger"
  | "instagram_dm"
  | "telegram"
  | "tiktok"
  | "linkedin"
  | "x_twitter"
  | "email"
  | "website_live_chat"
  | "sms"
  | "google_business_messages"
  | "comment_leads"
  | "superfeliz_ai_agent"
  | "bot_flows"
  | "smart_templates"
  | "invoices"
  | "bookings"
  | "offers"
  | "ai_auto_reply"
  | "ai_knowledge_base"
  | "advanced_analytics"
  | "customer_surveys"
  | "sales_pipeline"
  | "lead_forms"
  | "appointments"
  | "payment_links"
  | "broadcast_campaigns"
  | "workflow_automation"
  | "sla_priority_rules"
  | "internal_team_chat"
  | "api_webhooks"
  | "white_label_portal"
  | "custom_roles_permissions"
  | "audit_logs"
  | "data_export"
  | "ecommerce_integrations"
  | "mobile_app"
  | "multi_branch_management"

export interface AddOnDefinition {
  id: AddOnId
  name: { en: string; ar: string }
  category: AddOnCategory
  type: AddOnType
  section: AddOnSection
  status: AddOnStatus
  defaultEnabled: boolean
  icon: AddOnIcon
  description: { en: string; ar: string }
  route?: string
  configurable: boolean
  comingSoon: boolean
  channelType?: ChannelType
}

export const ADD_ONS_STORAGE_KEY = "pinchat-enabled-addons"

export const ADD_ONS: AddOnDefinition[] = [
  {
    id: "whatsapp",
    name: { en: "WhatsApp", ar: "واتساب" },
    category: "Messaging",
    type: "channel",
    section: "channels",
    status: "connected",
    defaultEnabled: true,
    icon: MessageCircleMore,
    description: {
      en: "Manage WhatsApp customer conversations from the unified inbox.",
      ar: "إدارة محادثات عملاء واتساب من صندوق الوارد الموحد.",
    },
    route: "/accounts",
    configurable: true,
    comingSoon: false,
    channelType: "WHATSAPP",
  },
  {
    id: "facebook_messenger",
    name: { en: "Facebook Messenger", ar: "فيسبوك ماسنجر" },
    category: "Meta",
    type: "channel",
    section: "channels",
    status: "setup_ready",
    defaultEnabled: false,
    icon: MessagesSquare,
    description: {
      en: "Connect Facebook Page messages to your unified inbox.",
      ar: "ربط رسائل صفحات Facebook بصندوق الوارد الموحد.",
    },
    route: "/settings?tab=integrations#meta-settings",
    configurable: true,
    comingSoon: false,
    channelType: "FACEBOOK_MESSENGER",
  },
  {
    id: "instagram_dm",
    name: { en: "Instagram DM", ar: "رسائل إنستغرام المباشرة" },
    category: "Meta",
    type: "channel",
    section: "channels",
    status: "setup_ready",
    defaultEnabled: false,
    icon: Instagram,
    description: {
      en: "Connect Instagram Professional account messages to your unified inbox.",
      ar: "ربط رسائل حساب Instagram Professional بصندوق الوارد الموحد.",
    },
    route: "/settings?tab=integrations#meta-settings",
    configurable: true,
    comingSoon: false,
    channelType: "INSTAGRAM_DM",
  },
  {
    id: "telegram",
    name: { en: "Telegram", ar: "Telegram" },
    category: "Messaging",
    type: "channel",
    section: "channels",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Send,
    description: {
      en: "Prepare Telegram conversations for future omnichannel support.",
      ar: "تجهيز محادثات Telegram لدعم الأومنيتشانيل مستقبلًا.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "tiktok",
    name: { en: "TikTok", ar: "TikTok" },
    category: "Social",
    type: "channel",
    section: "channels",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Video,
    description: {
      en: "Prepare TikTok messaging and social engagement features.",
      ar: "تجهيز رسائل وتفاعلات TikTok مستقبلًا.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "linkedin",
    name: { en: "LinkedIn", ar: "LinkedIn" },
    category: "Social",
    type: "channel",
    section: "channels",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Link2,
    description: {
      en: "Prepare LinkedIn business messaging and lead communication.",
      ar: "تجهيز رسائل LinkedIn والتواصل مع العملاء المحتملين مستقبلًا.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "x_twitter",
    name: { en: "X / Twitter", ar: "X / Twitter" },
    category: "Social",
    type: "channel",
    section: "channels",
    status: "coming_soon",
    defaultEnabled: false,
    icon: AtSign,
    description: {
      en: "Prepare X / Twitter direct messages and brand conversations.",
      ar: "تجهيز رسائل X / Twitter ومحادثات العلامة التجارية مستقبلًا.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "email",
    name: { en: "Email", ar: "البريد الإلكتروني" },
    category: "Communication",
    type: "channel",
    section: "channels",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Mail,
    description: {
      en: "Manage customer emails alongside chat conversations.",
      ar: "إدارة رسائل البريد الإلكتروني للعملاء بجانب المحادثات.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "website_live_chat",
    name: { en: "Website Live Chat", ar: "الدردشة المباشرة للموقع" },
    category: "Web",
    type: "channel",
    section: "channels",
    status: "coming_soon",
    defaultEnabled: false,
    icon: MonitorSmartphone,
    description: {
      en: "Add a live chat widget to your website and manage messages here.",
      ar: "إضافة ويدجت دردشة مباشرة لموقعك وإدارة الرسائل من هنا.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "sms",
    name: { en: "SMS", ar: "SMS" },
    category: "Communication",
    type: "channel",
    section: "channels",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Smartphone,
    description: {
      en: "Prepare SMS messaging support for customer notifications and replies.",
      ar: "تجهيز دعم رسائل SMS لإشعارات العملاء والردود.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "google_business_messages",
    name: { en: "Google Business Messages", ar: "Google Business Messages" },
    category: "Google",
    type: "channel",
    section: "channels",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Globe,
    description: {
      en: "Prepare Google Business Messages for customer communication.",
      ar: "تجهيز Google Business Messages للتواصل مع العملاء.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "comment_leads",
    name: { en: "Comment Leads", ar: "عملاء الكومنتات" },
    category: "Lead Generation",
    type: "channel",
    section: "channels",
    status: "coming_soon",
    defaultEnabled: false,
    icon: MessageSquare,
    description: {
      en: "Capture leads from Facebook and Instagram post comments, extract phone numbers and emails from comment text when available, and convert interested commenters into CRM contacts.",
      ar: "اجمع العملاء المحتملين من تعليقات منشورات فيسبوك وإنستجرام، واستخرج أرقام الهاتف أو الإيميلات المكتوبة داخل التعليق عند توفرها، وحوّل المهتمين إلى جهات اتصال داخل الـ CRM.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "superfeliz_ai_agent",
    name: { en: "SuperFeliz AI Agent", ar: "SuperFeliz AI Agent" },
    category: "AI",
    type: "module",
    section: "aiAutomation",
    status: "active",
    defaultEnabled: true,
    icon: Sparkles,
    description: {
      en: "Pencil Studio’s intelligent AI agent for smart replies, automation, and customer assistance.",
      ar: "وكيل Pencil Studio الذكي للردود الذكية، الأتمتة، ومساعدة العملاء.",
    },
    route: "/settings",
    configurable: true,
    comingSoon: false,
  },
  {
    id: "bot_flows",
    name: { en: "Bot Flows", ar: "Bot Flows" },
    category: "Automation",
    type: "module",
    section: "aiAutomation",
    status: "active",
    defaultEnabled: true,
    icon: Workflow,
    description: {
      en: "Build automated conversation flows and response journeys.",
      ar: "إنشاء مسارات محادثة آلية ورحلات ردود ذكية.",
    },
    route: "/bot-flows",
    configurable: true,
    comingSoon: false,
  },
  {
    id: "smart_templates",
    name: { en: "Smart Templates", ar: "Smart Templates" },
    category: "Automation",
    type: "module",
    section: "aiAutomation",
    status: "active",
    defaultEnabled: true,
    icon: FileText,
    description: {
      en: "Manage reusable message templates for faster team replies.",
      ar: "إدارة قوالب رسائل قابلة لإعادة الاستخدام لتسريع ردود الفريق.",
    },
    route: "/templates",
    configurable: true,
    comingSoon: false,
  },
  {
    id: "invoices",
    name: { en: "Invoices", ar: "الفواتير" },
    category: "CRM",
    type: "module",
    section: "business",
    status: "active",
    defaultEnabled: true,
    icon: Receipt,
    description: {
      en: "Create and manage customer invoices inside the CRM.",
      ar: "إنشاء وإدارة فواتير العملاء داخل نظام إدارة العملاء.",
    },
    route: "/invoices",
    configurable: true,
    comingSoon: false,
  },
  {
    id: "bookings",
    name: { en: "Bookings", ar: "الحجوزات" },
    category: "CRM",
    type: "module",
    section: "business",
    status: "active",
    defaultEnabled: true,
    icon: CalendarDays,
    description: {
      en: "Track customer bookings and service requests.",
      ar: "متابعة حجوزات العملاء وطلبات الخدمات.",
    },
    route: "/bookings",
    configurable: true,
    comingSoon: false,
  },
  {
    id: "offers",
    name: { en: "Offers", ar: "العروض" },
    category: "CRM",
    type: "module",
    section: "business",
    status: "active",
    defaultEnabled: true,
    icon: Tag,
    description: {
      en: "Manage promotions and offers for customer campaigns.",
      ar: "إدارة العروض والحملات الترويجية للعملاء.",
    },
    route: "/offers",
    configurable: true,
    comingSoon: false,
  },
  {
    id: "ai_auto_reply",
    name: { en: "AI Auto Reply", ar: "الرد الآلي بالذكاء الاصطناعي" },
    category: "AI",
    type: "module",
    section: "aiAutomation",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Brain,
    description: {
      en: "Suggest or send smart replies based on customer messages, saved business knowledge, and conversation context.",
      ar: "اقترح أو أرسل ردوداً ذكية بناءً على رسائل العملاء ومعلومات النشاط وسياق المحادثة.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "ai_knowledge_base",
    name: { en: "AI Knowledge Base", ar: "قاعدة معرفة الذكاء الاصطناعي" },
    category: "AI",
    type: "module",
    section: "aiAutomation",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Database,
    description: {
      en: "Upload company information, FAQs, services, and policies so AI can answer customers accurately.",
      ar: "ارفع معلومات الشركة والأسئلة الشائعة والخدمات والسياسات ليتمكن الذكاء الاصطناعي من الرد بدقة على العملاء.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "advanced_analytics",
    name: { en: "Advanced Analytics", ar: "التحليلات المتقدمة" },
    category: "Analytics",
    type: "module",
    section: "analytics",
    status: "coming_soon",
    defaultEnabled: false,
    icon: BarChart3,
    description: {
      en: "Track team performance, response time, channel growth, conversion rates, and customer engagement.",
      ar: "تابع أداء الفريق ووقت الرد ونمو القنوات ومعدلات التحويل وتفاعل العملاء.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "customer_surveys",
    name: { en: "Customer Surveys", ar: "استطلاعات العملاء" },
    category: "Customer Experience",
    type: "module",
    section: "business",
    status: "coming_soon",
    defaultEnabled: false,
    icon: ClipboardList,
    description: {
      en: "Send satisfaction surveys after conversations and collect customer feedback inside the CRM.",
      ar: "أرسل استطلاعات رضا بعد المحادثات واجمع تقييمات العملاء داخل الـ CRM.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "sales_pipeline",
    name: { en: "Sales Pipeline", ar: "مسار المبيعات" },
    category: "Sales CRM",
    type: "module",
    section: "business",
    status: "coming_soon",
    defaultEnabled: false,
    icon: TrendingUp,
    description: {
      en: "Convert conversations and leads into deals, track stages, values, owners, and expected closing dates.",
      ar: "حوّل المحادثات والعملاء المحتملين إلى صفقات وتابع المراحل والقيم والمسؤولين ومواعيد الإغلاق المتوقعة.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "lead_forms",
    name: { en: "Lead Forms", ar: "نماذج العملاء المحتملين" },
    category: "Lead Generation",
    type: "module",
    section: "business",
    status: "coming_soon",
    defaultEnabled: false,
    icon: FormInput,
    description: {
      en: "Create public lead capture forms and automatically save submissions as contacts or leads.",
      ar: "أنشئ نماذج عامة لجمع العملاء المحتملين واحفظ الطلبات تلقائياً كجهات اتصال أو عملاء محتملين.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "appointments",
    name: { en: "Appointments / Bookings", ar: "المواعيد والحجوزات" },
    category: "Operations",
    type: "module",
    section: "business",
    status: "coming_soon",
    defaultEnabled: false,
    icon: CalendarDays,
    description: {
      en: "Let customers book appointments from chat and manage schedules from one dashboard.",
      ar: "اسمح للعملاء بحجز المواعيد من المحادثة وتابع الجداول من لوحة تحكم واحدة.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "payment_links",
    name: { en: "Payment Links", ar: "روابط الدفع" },
    category: "Payments",
    type: "module",
    section: "commerce",
    status: "coming_soon",
    defaultEnabled: false,
    icon: CreditCard,
    description: {
      en: "Send payment links inside conversations and track payment status from the customer profile.",
      ar: "أرسل روابط دفع داخل المحادثات وتابع حالة الدفع من ملف العميل.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "broadcast_campaigns",
    name: { en: "Broadcast Campaigns", ar: "حملات الإرسال الجماعي" },
    category: "Marketing",
    type: "module",
    section: "marketing",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Megaphone,
    description: {
      en: "Create segmented campaigns for announcements, offers, and follow-ups across supported channels.",
      ar: "أنشئ حملات مقسمة للإعلانات والعروض والمتابعات عبر القنوات المدعومة.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "workflow_automation",
    name: { en: "Workflow Automation", ar: "أتمتة سير العمل" },
    category: "Automation",
    type: "module",
    section: "aiAutomation",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Zap,
    description: {
      en: "Build rules to assign conversations, trigger tags, send replies, and notify teams automatically.",
      ar: "أنشئ قواعد لتوزيع المحادثات وإضافة الوسوم وإرسال الردود وتنبيه الفريق تلقائياً.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "sla_priority_rules",
    name: { en: "SLA & Priority Rules", ar: "قواعد الأولوية ووقت الاستجابة" },
    category: "Operations",
    type: "module",
    section: "aiAutomation",
    status: "coming_soon",
    defaultEnabled: false,
    icon: AlertCircle,
    description: {
      en: "Define response time targets, priority queues, escalation rules, and overdue conversation alerts.",
      ar: "حدد أهداف وقت الرد وقوائم الأولوية وقواعس التصعيد وتنبيهات المحادثات المتأخرة.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "internal_team_chat",
    name: { en: "Internal Team Chat", ar: "محادثات الفريق الداخلية" },
    category: "Team Collaboration",
    type: "module",
    section: "team",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Users,
    description: {
      en: "Allow agents and managers to collaborate internally around customers and conversations.",
      ar: "اسمح للموظفين والمديرين بالتعاون داخلياً حول العملاء والمحادثات.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "api_webhooks",
    name: { en: "API & Webhooks", ar: "واجهات API والويب هوكس" },
    category: "Developer Tools",
    type: "module",
    section: "platform",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Code,
    description: {
      en: "Connect PinChat CRM with external systems using secure APIs and outbound webhooks.",
      ar: "اربط PinChat CRM بالأنظمة الخارجية باستخدام واجهات API آمنة وويب هوكس خارجية.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "white_label_portal",
    name: { en: "White Label Portal", ar: "بوابة العلامة البيضاء" },
    category: "Enterprise",
    type: "module",
    section: "platform",
    status: "coming_soon",
    defaultEnabled: false,
    icon: PaletteIcon,
    description: {
      en: "Customize the platform with your company branding, logo, colors, and client-facing portal.",
      ar: "خصص المنصة بهوية شركتك والشعار والألوان وبوابة مخصصة لعملائك.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "custom_roles_permissions",
    name: { en: "Custom Roles & Permissions", ar: "الأدوار والصلاحيات المخصصة" },
    category: "Security",
    type: "module",
    section: "platform",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Lock,
    description: {
      en: "Create custom team roles, permission groups, and access rules for different departments.",
      ar: "أنشئ أدواراً مخصصة للفريق ومجموعات صلاحيات وقواعد وصول للأقسام المختلفة.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "audit_logs",
    name: { en: "Audit Logs", ar: "سجل النشاطات" },
    category: "Security",
    type: "module",
    section: "platform",
    status: "coming_soon",
    defaultEnabled: false,
    icon: FileText,
    description: {
      en: "Track important actions, login activity, data changes, and admin operations across the system.",
      ar: "تابع الإجراءات المهمة وعمليات الدخول وتغييرات البيانات وإجراءات الإدارة داخل النظام.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "data_export",
    name: { en: "Data Export", ar: "تصدير البيانات" },
    category: "Data Management",
    type: "module",
    section: "platform",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Download,
    description: {
      en: "Export contacts, conversations, reports, and CRM data in Excel, CSV, or PDF formats.",
      ar: "صدّر جهات الاتصال والمحادثات والتقارير وبيانات الـ CRM بصيغ Excel أو CSV أو PDF.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "ecommerce_integrations",
    name: { en: "E-commerce Integrations", ar: "تكاملات المتاجر الإلكترونية" },
    category: "Integrations",
    type: "module",
    section: "commerce",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Store,
    description: {
      en: "Connect stores like Shopify, WooCommerce, and custom e-commerce platforms to sync customers and orders.",
      ar: "اربط متاجر مثل Shopify وWooCommerce والمنصات المخصصة لمزامنة العملاء والطلبات.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "mobile_app",
    name: { en: "Mobile App", ar: "تطبيق الموبايل" },
    category: "Platform",
    type: "module",
    section: "platform",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Smartphone,
    description: {
      en: "Manage conversations, contacts, and notifications from a dedicated mobile app for teams.",
      ar: "تابع المحادثات وجهات الاتصال والتنبيهات من تطبيق موبايل مخصص للفرق.",
    },
    configurable: false,
    comingSoon: true,
  },
  {
    id: "multi_branch_management",
    name: { en: "Multi-Branch Management", ar: "إدارة الفروع المتعددة" },
    category: "Enterprise",
    type: "module",
    section: "platform",
    status: "coming_soon",
    defaultEnabled: false,
    icon: Globe,
    description: {
      en: "Manage multiple branches, teams, inboxes, permissions, and reports from one workspace.",
      ar: "أدر عدة فروع وفرق وصناديق محادثات وصلاحيات وتقارير من مساحة عمل واحدة.",
    },
    configurable: false,
    comingSoon: true,
  },
]

export const ADD_ONS_BY_ID = Object.fromEntries(ADD_ONS.map((addOn) => [addOn.id, addOn])) as Record<AddOnId, AddOnDefinition>

export function getDefaultEnabledAddOnIds() {
  return ADD_ONS.filter((addOn) => addOn.defaultEnabled).map((addOn) => addOn.id)
}

export function isAddOnId(value: unknown): value is AddOnId {
  return typeof value === "string" && value in ADD_ONS_BY_ID
}

export function isComingSoonAddOnId(addOnId: AddOnId): boolean {
  const addOn = ADD_ONS_BY_ID[addOnId]
  return addOn?.comingSoon === true
}

export function getInvalidAddOnIds(values: unknown) {
  if (!Array.isArray(values)) return []

  return values.filter((value): value is string => typeof value === "string" && !isAddOnId(value))
}

export function getComingSoonAddOnIds(values: unknown) {
  if (!Array.isArray(values)) return []

  return values.filter((value): value is AddOnId => isAddOnId(value) && isComingSoonAddOnId(value))
}

export function filterOutComingSoonAddOns(values: unknown) {
  if (!Array.isArray(values)) return []

  return values.filter((value): value is AddOnId => isAddOnId(value) && !isComingSoonAddOnId(value))
}

export function getEnabledAddOnIds(values: unknown) {
  if (!Array.isArray(values)) {
    return new Set<AddOnId>(getDefaultEnabledAddOnIds())
  }

  const validIds = values.filter(isAddOnId)
  if (validIds.length === 0 && values.length > 0) {
    return new Set<AddOnId>(getDefaultEnabledAddOnIds())
  }

  return new Set<AddOnId>(Array.from(new Set(validIds)))
}

export function loadEnabledAddOnIds() {
  if (typeof window === "undefined") {
    return new Set<AddOnId>(getDefaultEnabledAddOnIds())
  }

  try {
    const raw = window.localStorage.getItem(ADD_ONS_STORAGE_KEY)
    if (!raw) return new Set<AddOnId>(getDefaultEnabledAddOnIds())
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed)) return new Set<AddOnId>(getDefaultEnabledAddOnIds())
    const ids = parsed.filter((value): value is AddOnId => typeof value === "string" && value in ADD_ONS_BY_ID)
    if (ids.length > 0) {
      return new Set<AddOnId>(ids)
    }
    return parsed.length === 0 ? new Set<AddOnId>() : new Set<AddOnId>(getDefaultEnabledAddOnIds())
  } catch {
    return new Set<AddOnId>(getDefaultEnabledAddOnIds())
  }
}

export function saveEnabledAddOnIds(enabledIds: Set<AddOnId>) {
  if (typeof window === "undefined") return
  window.localStorage.setItem(ADD_ONS_STORAGE_KEY, JSON.stringify(Array.from(enabledIds)))
}

export function isAddOnEnabled(addOnId: AddOnId, enabledIds: Set<AddOnId>) {
  return enabledIds.has(addOnId)
}

export function getAddOnCategoryLabel(category: AddOnCategory, language: "en" | "ar") {
  const labels: Record<AddOnCategory, { en: string; ar: string }> = {
    Messaging: { en: "Messaging", ar: "الرسائل" },
    Meta: { en: "Meta", ar: "ميتا" },
    Social: { en: "Social", ar: "اجتماعي" },
    Communication: { en: "Communication", ar: "التواصل" },
    Web: { en: "Web", ar: "الويب" },
    Google: { en: "Google", ar: "جوجل" },
    "Lead Generation": { en: "Lead Generation", ar: "توليد العملاء المحتملين" },
    AI: { en: "AI", ar: "الذكاء الاصطناعي" },
    Automation: { en: "Automation", ar: "الأتمتة" },
    CRM: { en: "CRM", ar: "إدارة العملاء" },
    Analytics: { en: "Analytics", ar: "التحليلات" },
    "Customer Experience": { en: "Customer Experience", ar: "تجربة العميل" },
    "Sales CRM": { en: "Sales CRM", ar: "إدارة المبيعات" },
    Operations: { en: "Operations", ar: "العمليات" },
    Payments: { en: "Payments", ar: "المدفوعات" },
    Marketing: { en: "Marketing", ar: "التسويق" },
    "Team Collaboration": { en: "Team Collaboration", ar: "التعاون بين الفريق" },
    "Developer Tools": { en: "Developer Tools", ar: "أدوات المطورين" },
    Enterprise: { en: "Enterprise", ar: "المؤسسات" },
    Security: { en: "Security", ar: "الأمان" },
    "Data Management": { en: "Data Management", ar: "إدارة البيانات" },
    Integrations: { en: "Integrations", ar: "التكاملات" },
    Platform: { en: "Platform", ar: "المنصة" },
  }

  return labels[category][language]
}

export function getAddOnSectionLabel(section: AddOnSection, language: "en" | "ar") {
  const labels: Record<AddOnSection, { en: string; ar: string }> = {
    channels: {
      en: "Communication Channels",
      ar: "قنوات التواصل",
    },
    aiAutomation: {
      en: "AI & Automation Add-ons",
      ar: "الإضافات الخاصة بالذكاء الاصطناعي والأتمتة",
    },
    business: {
      en: "Business Add-ons",
      ar: "إضافات الأعمال",
    },
    analytics: {
      en: "Analytics & Insights",
      ar: "التحليلات والرؤى",
    },
    commerce: {
      en: "E-Commerce & Payments",
      ar: "التجارة الإلكترونية والدفع",
    },
    marketing: {
      en: "Marketing & Campaigns",
      ar: "التسويق والحملات",
    },
    team: {
      en: "Team Collaboration",
      ar: "التعاون بين الفريق",
    },
    platform: {
      en: "Platform & Enterprise",
      ar: "المنصة والمؤسسات",
    },
  }

  return labels[section][language]
}

export function getAddOnStatusLabel(status: AddOnStatus, language: "en" | "ar") {
  const labels: Record<AddOnStatus, { en: string; ar: string }> = {
    connected: { en: "Connected", ar: "متصل" },
    active: { en: "Active", ar: "نشط" },
    setup_ready: { en: "Setup Ready", ar: "جاهز للإعداد" },
    coming_soon: { en: "Coming Soon", ar: "قريباً" },
    inactive: { en: "Inactive", ar: "غير نشط" },
  }

  return labels[status][language]
}

export function getAddOnToggleLabel(enabled: boolean, language: "en" | "ar") {
  return enabled
    ? language === "ar" ? "مُفعّل" : "Enabled"
    : language === "ar" ? "مُعطّل" : "Disabled"
}

export function getAddOnActionLabel(addOn: AddOnDefinition, language: "en" | "ar") {
  if (addOn.comingSoon) {
    return language === "ar" ? "قريباً" : "Coming Soon"
  }

  if (addOn.configurable) {
    if (addOn.section === "channels" && addOn.channelType !== "WHATSAPP") {
      return language === "ar" ? "فتح الإعدادات" : "Open Settings"
    }

    if (addOn.section === "aiAutomation" && addOn.id === "superfeliz_ai_agent") {
      return language === "ar" ? "فتح الإعدادات" : "Open Settings"
    }

    return language === "ar" ? "إعداد" : "Configure"
  }

  return language === "ar" ? "فتح الإعدادات" : "Open Settings"
}
