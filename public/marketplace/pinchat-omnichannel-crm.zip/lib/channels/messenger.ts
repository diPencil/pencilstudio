import type { ChannelType } from "./types"
import { decryptSecret } from "@/lib/secure-tokens"

type MessengerAttachment = {
  type: string
  attachmentId?: string
  mimeType?: string
  title?: string
}

type MessengerWebhookMessage = {
  mid?: string
  text?: string
  attachments?: Array<{
    type?: string
    payload?: {
      attachment_id?: string
      mime_type?: string
      title?: string
    }
  }>
}

type MessengerWebhookEvent = {
  sender?: { id?: string }
  recipient?: { id?: string }
  timestamp?: number
  message?: MessengerWebhookMessage
}

type MessengerWebhookEventRecord = {
  sender?: { id?: string }
  recipient?: { id?: string }
  timestamp?: number
  message?: {
    mid?: string
    text?: string
    attachments?: MessengerWebhookMessage["attachments"]
  }
}

export type NormalizedMessengerMessageEvent = {
  channelType: ChannelType
  provider: "META"
  pageId: string
  recipientId: string
  senderId: string
  externalMessageId: string
  externalConversationId: string
  threadKey: string
  text: string
  attachments: MessengerAttachment[]
  timestamp: Date
  metadata: Record<string, unknown>
}

export type MessengerSendResult = {
  recipientId: string
  messageId?: string
  rawResponse: {
    recipient_id?: string
    message_id?: string
  }
}

function isObject(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value)
}

function getString(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value.trim() : null
}

function normalizeAttachments(attachments: MessengerWebhookMessage["attachments"]) {
  return Array.isArray(attachments)
    ? attachments
        .map((attachment) => {
          const type = getString(attachment?.type) || "unknown"
          const payload = attachment?.payload ?? {}
          return {
            type,
            attachmentId: getString(payload.attachment_id) || undefined,
            mimeType: getString(payload.mime_type) || undefined,
            title: getString(payload.title) || undefined,
          }
        })
        .filter((attachment) => Boolean(attachment.type))
    : []
}

function inferMessageType(text: string, attachments: MessengerAttachment[]) {
  if (text.trim()) return "TEXT"

  const attachmentType = attachments[0]?.type?.toUpperCase() || ""
  if (attachmentType.includes("IMAGE")) return "IMAGE"
  if (attachmentType.includes("VIDEO")) return "VIDEO"
  if (attachmentType.includes("AUDIO")) return "AUDIO"
  if (attachmentType.includes("DOCUMENT")) return "DOCUMENT"
  if (attachmentType.includes("LOCATION")) return "LOCATION"
  return "TEXT"
}

export function isMessengerWebhookEvent(payload: unknown) {
  if (!isObject(payload) || payload.object !== "page") return false

  const entries = Array.isArray(payload.entry) ? payload.entry : []
  return entries.some((entry) => {
    if (!isObject(entry)) return false
    const messaging = Array.isArray(entry.messaging) ? entry.messaging : []
    return messaging.some((event) => {
      if (!isObject(event)) return false
      return Boolean(event.sender && event.recipient && event.message)
    })
  })
}

export function normalizeMessengerMessageEvent(event: unknown): NormalizedMessengerMessageEvent | null {
  if (!isObject(event)) return null

  const webhookEvent = event as MessengerWebhookEventRecord
  const senderId = getString(webhookEvent.sender?.id)
  const recipientId = getString(webhookEvent.recipient?.id)
  const message = webhookEvent.message || null
  const externalMessageId = getString(message?.mid)

  if (!senderId || !recipientId || !message || !externalMessageId) {
    return null
  }

  const text = getString(message.text) || ""
  const attachments = normalizeAttachments(message.attachments)
  const timestampValue = typeof webhookEvent.timestamp === "number" ? webhookEvent.timestamp : Date.now()
  const timestamp = new Date(timestampValue)
  const threadKey = `meta-facebook:${recipientId}:${senderId}`
  const messageType = inferMessageType(text, attachments)

  return {
    channelType: "FACEBOOK_MESSENGER",
    provider: "META",
    pageId: recipientId,
    recipientId,
    senderId,
    externalMessageId,
    externalConversationId: threadKey,
    threadKey,
    text,
    attachments,
    timestamp,
    metadata: {
      provider: "META",
      pageId: recipientId,
      senderId,
      recipientId,
      messageType,
      hasAttachments: attachments.length > 0,
      attachmentCount: attachments.length,
      attachmentTypes: attachments.map((attachment) => attachment.type),
      timestamp: timestamp.toISOString(),
    },
  }
}

export function buildMessengerFallbackContactName(senderId: string) {
  const tail = senderId.slice(-4)
  return `Messenger User ${tail}`
}

export async function sendMessengerTextMessage(params: {
  pageId: string
  recipientId: string
  text: string
  encryptedPageAccessToken: string
  graphApiVersion: string
}): Promise<MessengerSendResult> {
  const text = params.text.trim()
  if (!text) {
    throw new Error("Messenger text content is required.")
  }

  if (!params.encryptedPageAccessToken) {
    throw new Error("Messenger encrypted page access token is missing.")
  }

  const pageAccessToken = decryptSecret(params.encryptedPageAccessToken)
  const sendUrl = `https://graph.facebook.com/${params.graphApiVersion}/me/messages`
  const body = new URLSearchParams({
    recipient: JSON.stringify({ id: params.recipientId }),
    message: JSON.stringify({ text }),
    messaging_type: "RESPONSE",
    access_token: pageAccessToken,
  })

  const response = await fetch(sendUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body,
    cache: "no-store",
  })

  const payload = await response.json().catch(() => null)
  const recipientId = typeof payload?.recipient_id === "string" ? payload.recipient_id : params.recipientId
  const messageId = typeof payload?.message_id === "string" ? payload.message_id : undefined

  if (!response.ok) {
    const errorMessage = typeof payload?.error?.message === "string"
      ? payload.error.message
      : `Meta Messenger send failed with status ${response.status}`
    throw new Error(errorMessage)
  }

  return {
    recipientId,
    messageId,
    rawResponse: {
      recipient_id: recipientId,
      message_id: messageId,
    },
  }
}
