import type { ChannelType } from "./types"
import { decryptSecret } from "@/lib/secure-tokens"

export type InstagramSendResult = {
  recipientId: string
  messageId?: string
  rawResponse: {
    recipient_id?: string
    message_id?: string
  }
}

type InstagramAttachment = {
  type: string
  url?: string
}

type InstagramWebhookMessage = {
  mid?: string
  text?: string
  attachments?: Array<{
    type?: string
    payload?: {
      url?: string
    }
  }>
}

type InstagramWebhookEventRecord = {
  sender?: { id?: string }
  recipient?: { id?: string }
  timestamp?: number
  message?: {
    mid?: string
    text?: string
    attachments?: InstagramWebhookMessage["attachments"]
  }
}

export type NormalizedInstagramMessageEvent = {
  channelType: ChannelType
  provider: "META"
  instagramBusinessAccountId: string
  recipientId: string
  senderId: string
  externalMessageId: string
  externalConversationId: string
  threadKey: string
  text: string
  attachments: InstagramAttachment[]
  timestamp: Date
  metadata: Record<string, unknown>
}

function isObject(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value)
}

function getString(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value.trim() : null
}

function normalizeAttachments(attachments: InstagramWebhookMessage["attachments"]) {
  return Array.isArray(attachments)
    ? attachments
        .map((attachment) => {
          const type = getString(attachment?.type) || "unknown"
          const payload = attachment?.payload ?? {}
          return {
            type,
            url: getString(payload.url) || undefined,
          }
        })
        .filter((attachment) => Boolean(attachment.type))
    : []
}

function inferMessageType(text: string, attachments: InstagramAttachment[]) {
  if (text.trim()) return "TEXT"

  const attachmentType = attachments[0]?.type?.toUpperCase() || ""
  if (attachmentType.includes("IMAGE")) return "IMAGE"
  if (attachmentType.includes("VIDEO")) return "VIDEO"
  if (attachmentType.includes("AUDIO")) return "AUDIO"
  if (attachmentType.includes("DOCUMENT")) return "DOCUMENT"
  if (attachmentType.includes("LOCATION")) return "LOCATION"
  return "TEXT"
}

export function isInstagramWebhookEvent(payload: unknown): boolean {
  if (!isObject(payload) || payload.object !== "instagram") return false

  const entries = Array.isArray(payload.entry) ? payload.entry : []
  return entries.some((entry) => {
    if (!isObject(entry)) return false
    const messaging = Array.isArray(entry.messaging) ? entry.messaging : []
    return messaging.some((event) => {
      if (!isObject(event)) return false
      return Boolean(event.sender && event.recipient && event.message)
    })
  })
}

export function normalizeInstagramMessageEvent(event: unknown): NormalizedInstagramMessageEvent | null {
  if (!isObject(event)) return null

  const webhookEvent = event as InstagramWebhookEventRecord
  const senderId = getString(webhookEvent.sender?.id)
  const recipientId = getString(webhookEvent.recipient?.id)
  const message = webhookEvent.message || null
  const externalMessageId = getString(message?.mid)

  if (!senderId || !recipientId || !message || !externalMessageId) {
    return null
  }

  const text = getString(message.text) || ""
  const attachments = normalizeAttachments(message.attachments)
  const timestampValue = typeof webhookEvent.timestamp === "number" ? webhookEvent.timestamp : Date.now()
  const timestamp = new Date(timestampValue)
  const threadKey = `meta-instagram:${recipientId}:${senderId}`
  const messageType = inferMessageType(text, attachments)

  return {
    channelType: "INSTAGRAM", // Maps to the database Prisma enum ChannelType
    provider: "META",
    instagramBusinessAccountId: recipientId,
    recipientId,
    senderId,
    externalMessageId,
    externalConversationId: threadKey,
    threadKey,
    text,
    attachments,
    timestamp,
    metadata: {
      provider: "META",
      instagramBusinessAccountId: recipientId,
      senderId,
      recipientId,
      messageType,
      hasAttachments: attachments.length > 0,
      attachmentCount: attachments.length,
      attachmentTypes: attachments.map((attachment) => attachment.type),
      timestamp: timestamp.toISOString(),
    },
  }
}

export function buildInstagramFallbackContactName(senderId: string) {
  const tail = senderId.slice(-4)
  return `Instagram User ${tail}`
}

export async function sendInstagramTextMessage(params: {
  instagramBusinessAccountId: string
  recipientId: string
  text: string
  encryptedPageAccessToken: string
  graphApiVersion: string
}): Promise<InstagramSendResult> {
  const text = params.text.trim()
  if (!text) {
    throw new Error("Instagram text content is required.")
  }

  if (!params.encryptedPageAccessToken) {
    throw new Error("Instagram encrypted page access token is missing.")
  }

  const pageAccessToken = decryptSecret(params.encryptedPageAccessToken)
  // For Instagram DM, the endpoint is the same: POST /v18.0/me/messages
  const sendUrl = `https://graph.facebook.com/${params.graphApiVersion}/me/messages`
  const body = new URLSearchParams({
    recipient: JSON.stringify({ id: params.recipientId }),
    message: JSON.stringify({ text }),
    // Meta requires messaging_type="RESPONSE" for replies within the 24h window
    messaging_type: "RESPONSE",
    access_token: pageAccessToken,
  })

  const response = await fetch(sendUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body,
    cache: "no-store",
  })

  const payload = await response.json().catch(() => null)
  const recipientId = typeof payload?.recipient_id === "string" ? payload.recipient_id : params.recipientId
  const messageId = typeof payload?.message_id === "string" ? payload.message_id : undefined

  if (!response.ok) {
    const errorMessage = typeof payload?.error?.message === "string"
      ? payload.error.message
      : `Meta Instagram DM send failed with status ${response.status}`
    throw new Error(errorMessage)
  }

  return {
    recipientId,
    messageId,
    rawResponse: {
      recipient_id: recipientId,
      message_id: messageId,
    },
  }
}
