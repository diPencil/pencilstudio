import { META_FACEBOOK_MESSENGER_CONFIG, META_INSTAGRAM_DM_CONFIG } from "./meta"
import { WHATSAPP_CHANNEL_CONFIG } from "./whatsapp"
import type { ChannelDisplayConfig, ChannelKey, ChannelType } from "./types"

export type ChannelRegistryEntry = ChannelDisplayConfig

const channelRegistry: Record<ChannelKey, ChannelRegistryEntry> = {
  whatsapp: WHATSAPP_CHANNEL_CONFIG,
  facebook: META_FACEBOOK_MESSENGER_CONFIG,
  instagram: META_INSTAGRAM_DM_CONFIG,
}

export function getChannelRegistryEntry(channel: ChannelType | ChannelKey | string | null | undefined) {
  const normalized = normalizeChannelKey(channel)
  return channelRegistry[normalized]
}

export function normalizeChannelKey(channel: ChannelType | ChannelKey | string | null | undefined): ChannelKey {
  const value = String(channel || "").toUpperCase()
  if (value.includes("FACEBOOK") || value === "FACEBOOK_MESSENGER") return "facebook"
  if (value.includes("INSTAGRAM") || value === "INSTAGRAM_DM") return "instagram"
  return "whatsapp"
}

export { channelRegistry }
