import type { ComponentType } from "react"
import { Facebook, Instagram, MessageCircleMore } from "lucide-react"
import { channelRegistry, getChannelRegistryEntry, normalizeChannelKey } from "./registry"
import type { ChannelKey, ChannelType } from "./types"

export function getChannelLabel(channelType: ChannelType | ChannelKey | string | null | undefined, language: "en" | "ar" = "en") {
  const entry = getChannelRegistryEntry(channelType)
  return entry.label[language] || entry.label.en
}

export function getChannelIcon(channelType: ChannelType | ChannelKey | string | null | undefined): ComponentType<{ className?: string }> {
  const normalized = normalizeChannelKey(channelType)
  switch (normalized) {
    case "facebook":
      return Facebook as unknown as ComponentType<{ className?: string }>
    case "instagram":
      return Instagram as unknown as ComponentType<{ className?: string }>
    default:
      return MessageCircleMore as unknown as ComponentType<{ className?: string }>
  }
}

export function getChannelBadgeConfig(channelType: ChannelType | ChannelKey | string | null | undefined, language: "en" | "ar" = "en") {
  const entry = getChannelRegistryEntry(channelType)
  const Icon = getChannelIcon(channelType)

  const variant: "default" | "secondary" | "outline" = entry.status === "CONNECTED" ? "default" : entry.status === "SETUP_READY" ? "secondary" : "outline"

  return {
    label: entry.label[language] || entry.label.en,
    icon: Icon,
    variant,
    status: entry.status,
    active: entry.active,
    className: entry.status === "SETUP_READY" ? "border-blue-200 bg-blue-50 text-blue-700" : entry.status === "CONNECTED" ? "border-green-200 bg-green-50 text-green-700" : undefined,
  }
}

export function isLegacyWhatsAppConversation(conversation: Partial<{ channelType?: string | null; whatsappAccountId?: string | null; messages?: Array<{ whatsappAccountId?: string | null }> }>) {
  return !conversation.channelType && Boolean(conversation.whatsappAccountId || conversation.messages?.some((message) => message.whatsappAccountId))
}

export function resolveConversationChannel(conversation: Partial<{ channelType?: string | null; whatsappAccountId?: string | null; platform?: string | null; messages?: Array<{ whatsappAccountId?: string | null }> }>) {
  if (isLegacyWhatsAppConversation(conversation)) return "whatsapp"
  return normalizeChannelKey(conversation.channelType || conversation.platform)
}

export function getChannelConfig(channelType: ChannelType | ChannelKey | string | null | undefined) {
  return getChannelRegistryEntry(channelType)
}

export { channelRegistry }
