export type ChannelType = "WHATSAPP" | "FACEBOOK_MESSENGER" | "INSTAGRAM_DM" | "INSTAGRAM"

export type ChannelKey = "whatsapp" | "facebook" | "instagram"

export type ChannelAccountStatus = "CONNECTED" | "DISCONNECTED" | "WAITING" | "COMING_SOON" | "SETUP_READY"

export type ChannelProvider = "whatsapp-web.js" | "meta" | "meta-oauth" | "unknown"

export interface ChannelCapabilities {
  supportsSending: boolean
  supportsReceiving: boolean
  supportsMedia: boolean
}

export interface ChannelDisplayConfig {
  key: ChannelKey
  type: ChannelType
  label: { en: string; ar: string }
  description?: { en: string; ar: string }
  status: ChannelAccountStatus
  active: boolean
  capabilities: ChannelCapabilities
  setupHref?: string
}

export interface ChannelSendPayload {
  channelType: ChannelType
  accountId?: string | null
  recipientId: string
  content?: string
  mediaUrl?: string | null
  metadata?: Record<string, unknown>
}

export interface ChannelIncomingPayload {
  channelType: ChannelType
  accountId?: string | null
  externalConversationId?: string | null
  externalMessageId?: string | null
  senderId?: string | null
  recipientId?: string | null
  content?: string | null
  mediaUrl?: string | null
  metadata?: Record<string, unknown>
}

export interface NormalizedContactIdentity {
  channelType: ChannelType
  externalId: string
  name?: string | null
  phone?: string | null
  avatarUrl?: string | null
}

export interface NormalizedMessage {
  id?: string
  channelType: ChannelType
  direction: "INCOMING" | "OUTGOING"
  content: string
  mediaUrl?: string | null
  status?: string
  createdAt?: Date | string
  metadata?: Record<string, unknown>
}

export interface NormalizedConversation {
  id?: string
  channelType: ChannelType
  contact: NormalizedContactIdentity
  lastMessage?: NormalizedMessage | null
  unreadCount?: number
  status?: string
  whatsappAccountId?: string | null
  branchId?: string | null
  metadata?: Record<string, unknown>
}
