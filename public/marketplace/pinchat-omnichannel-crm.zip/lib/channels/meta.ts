import crypto from "crypto"
import type { ChannelDisplayConfig } from "./types"

export const META_GRAPH_API_VERSION = process.env.META_GRAPH_API_VERSION || "v21.0"

export const META_FACEBOOK_MESSENGER_CONFIG: ChannelDisplayConfig = {
  key: "facebook",
  type: "FACEBOOK_MESSENGER",
  label: { en: "Facebook Messenger", ar: "فيسبوك ماسنجر" },
  description: { en: "Ready for Meta app setup", ar: "جاهز لإعداد تطبيق Meta" },
  status: "SETUP_READY",
  active: false,
  capabilities: {
    supportsSending: false,
    supportsReceiving: false,
    supportsMedia: false,
  },
  setupHref: "/settings?tab=integrations#meta-settings",
}

export const META_INSTAGRAM_DM_CONFIG: ChannelDisplayConfig = {
  key: "instagram",
  type: "INSTAGRAM_DM",
  label: { en: "Instagram DM", ar: "رسائل إنستغرام المباشرة" },
  description: { en: "Ready for Meta app setup", ar: "جاهز لإعداد تطبيق Meta" },
  status: "SETUP_READY",
  active: false,
  capabilities: {
    supportsSending: false,
    supportsReceiving: false,
    supportsMedia: false,
  },
  setupHref: "/settings?tab=integrations#meta-settings",
}

export function getMetaAppId() {
  return process.env.META_APP_ID || ""
}

export function getMetaRedirectUri() {
  return process.env.META_REDIRECT_URI || "http://localhost:3000/api/meta/oauth/callback"
}

export function getMetaGraphVersion() {
  return process.env.META_GRAPH_API_VERSION || META_GRAPH_API_VERSION
}

export function isMetaConfigured() {
  return Boolean(process.env.META_APP_ID && process.env.META_APP_SECRET && process.env.META_VERIFY_TOKEN)
}

export function getMetaGraphBaseUrl(version = META_GRAPH_API_VERSION) {
  return `https://graph.facebook.com/${version}`
}

export function verifyMetaWebhookToken(providedToken: string | null | undefined) {
  const expectedToken = process.env.META_VERIFY_TOKEN
  if (!expectedToken) {
    return false
  }
  return providedToken === expectedToken
}

function normalizeSignatureHeader(signatureHeader: string | null | undefined) {
  if (!signatureHeader) return null
  const trimmed = signatureHeader.trim()
  if (!trimmed) return null
  const value = trimmed.includes("=") ? trimmed.split("=", 2)[1] : trimmed
  return value || null
}

export function verifyMetaSignature(rawBody: string, signatureHeader: string | null | undefined) {
  const appSecret = process.env.META_APP_SECRET
  const signature = normalizeSignatureHeader(signatureHeader)

  // TODO: Enforce signature validation for production-only webhook hardening once Meta app settings are finalized.
  if (!appSecret || !signature) {
    return true
  }

  const expectedSignature = crypto
    .createHmac("sha256", appSecret)
    .update(rawBody, "utf8")
    .digest("hex")

  if (expectedSignature.length !== signature.length) {
    return false
  }

  return crypto.timingSafeEqual(Buffer.from(expectedSignature), Buffer.from(signature))
}

export function safeMetaWebhookLog(payload: unknown) {
  const event = payload as Record<string, unknown> | null
  const objectType = typeof event?.object === "string" ? event.object : "unknown"
  const entries = Array.isArray(event?.entry) ? event.entry : []

  return {
    objectType,
    entryCount: entries.length,
    entries: entries.slice(0, 3).map((entry) => {
      const record = entry as Record<string, unknown>
      const messaging = Array.isArray(record.messaging) ? record.messaging : []
      const changes = Array.isArray(record.changes) ? record.changes : []
      return {
        id: typeof record.id === "string" ? record.id : undefined,
        time: typeof record.time === "number" ? record.time : undefined,
        messagingCount: messaging.length,
        changeCount: changes.length,
        senderIds: messaging.slice(0, 3).flatMap((message) => {
          const messageRecord = message as Record<string, unknown>
          const sender = messageRecord.sender as Record<string, unknown> | undefined
          const senderId = typeof sender?.id === "string" ? sender.id : null
          return senderId ? [senderId] : []
        }),
      }
    }),
  }
}

export function detectMetaChannel(payload: unknown) {
  const event = payload as Record<string, unknown> | null
  const objectType = typeof event?.object === "string" ? event.object.toLowerCase() : ""
  if (objectType.includes("instagram") || objectType === "ig") {
    return "instagram"
  }
  if (objectType.includes("page") || objectType.includes("facebook")) {
    return "facebook"
  }

  const entries = Array.isArray(event?.entry) ? event.entry : []
  for (const entry of entries) {
    const record = entry as Record<string, unknown>
    const messaging = Array.isArray(record.messaging) ? record.messaging : []
    for (const message of messaging) {
      const messageRecord = message as Record<string, unknown>
      const source = typeof messageRecord.source === "string" ? messageRecord.source.toLowerCase() : ""
      const messagingProduct = typeof messageRecord.messaging_product === "string" ? messageRecord.messaging_product.toLowerCase() : ""
      if (messagingProduct.includes("instagram") || source.includes("instagram")) {
        return "instagram"
      }
      if (messagingProduct.includes("facebook") || source.includes("page")) {
        return "facebook"
      }
    }
  }

  return "unknown"
}
