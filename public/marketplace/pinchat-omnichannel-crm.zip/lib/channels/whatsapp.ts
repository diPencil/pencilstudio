import type { ChannelDisplayConfig } from "./types"

export const WHATSAPP_CHANNEL_CONFIG: ChannelDisplayConfig = {
  key: "whatsapp",
  type: "WHATSAPP",
  label: { en: "WhatsApp", ar: "واتساب" },
  description: { en: "Live customer messaging channel", ar: "قناة مراسلة العملاء المباشرة" },
  status: "CONNECTED",
  active: true,
  capabilities: {
    supportsSending: true,
    supportsReceiving: true,
    supportsMedia: true,
  },
}
