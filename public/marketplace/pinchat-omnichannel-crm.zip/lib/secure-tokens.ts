import crypto from "crypto"

const TOKEN_ENCRYPTION_ALGORITHM = "aes-256-gcm"
const TOKEN_ENCRYPTION_VERSION = "v1"
const TOKEN_ENCRYPTION_IV_LENGTH = 12

function getTokenEncryptionSecret() {
  const secret = process.env.TOKEN_ENCRYPTION_SECRET?.trim()

  if (!secret) {
    throw new Error(
      "TOKEN_ENCRYPTION_SECRET is not configured. Add a strong secret before storing third-party access tokens.",
    )
  }

  return secret
}

function getTokenEncryptionKey() {
  return crypto.createHash("sha256").update(getTokenEncryptionSecret(), "utf8").digest()
}

function parseEncryptedToken(encryptedValue: string) {
  const [version, ivValue, tagValue, ciphertextValue] = encryptedValue.split(":")

  if (version !== TOKEN_ENCRYPTION_VERSION || !ivValue || !tagValue || !ciphertextValue) {
    throw new Error("Invalid encrypted token format.")
  }

  return {
    iv: Buffer.from(ivValue, "base64url"),
    tag: Buffer.from(tagValue, "base64url"),
    ciphertext: Buffer.from(ciphertextValue, "base64url"),
  }
}

export function isTokenEncryptionConfigured() {
  return Boolean(process.env.TOKEN_ENCRYPTION_SECRET?.trim())
}

export function encryptSecret(plainText: string): string {
  const key = getTokenEncryptionKey()
  const iv = crypto.randomBytes(TOKEN_ENCRYPTION_IV_LENGTH)
  const cipher = crypto.createCipheriv(TOKEN_ENCRYPTION_ALGORITHM, key, iv)
  const ciphertext = Buffer.concat([cipher.update(plainText, "utf8"), cipher.final()])
  const authTag = cipher.getAuthTag()

  return [
    TOKEN_ENCRYPTION_VERSION,
    iv.toString("base64url"),
    authTag.toString("base64url"),
    ciphertext.toString("base64url"),
  ].join(":")
}

export function decryptSecret(encryptedValue: string): string {
  const key = getTokenEncryptionKey()
  const { iv, tag, ciphertext } = parseEncryptedToken(encryptedValue)
  const decipher = crypto.createDecipheriv(TOKEN_ENCRYPTION_ALGORITHM, key, iv)

  decipher.setAuthTag(tag)

  try {
    return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString("utf8")
  } catch {
    throw new Error("Unable to decrypt stored token.")
  }
}