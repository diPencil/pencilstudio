import { Prisma } from "@prisma/client"
import { prisma } from "@/lib/db"

type WhatsAppAccountLike = {
  id: string
  name: string
  phone: string
  provider: string
  status?: string
  branchId?: string | null
}

type MetaFacebookPageLike = {
  id: string
  name: string
  category?: string | null
  tasks?: string[]
  categoryList?: Array<{ id?: string; name?: string }>
  accessToken?: string | null
}

type MetaFacebookConnectionMetadata = {
  oauthSource?: string
  pageName?: string
  pageCategory?: string | null
  pageTasks?: string[]
  pageCategoryList?: Array<{ id?: string; name?: string }>
  scopes?: string[]
  connectionState?: string
  connectedAt?: string
  pageAccessTokenEncrypted?: string
  tokenStoredAt?: string
  tokenType?: string
}

function buildMetaFacebookChannelMetadata(
  page: MetaFacebookPageLike,
  metadata: MetaFacebookConnectionMetadata = {},
) : Prisma.InputJsonValue {
  const connectionMetadata: Record<string, unknown> = {
    oauthSource: metadata.oauthSource || "meta-oauth",
    pageName: page.name || "Facebook Page",
    pageCategory: page.category || null,
    pageTasks: Array.isArray(page.tasks) ? page.tasks : [],
    pageCategoryList: Array.isArray(page.categoryList) ? page.categoryList : [],
    scopes: Array.isArray(metadata.scopes) ? metadata.scopes : [],
    connectionState: metadata.connectionState || "CONNECTED",
    connectedAt: metadata.connectedAt || new Date().toISOString(),
  }

  if (metadata.pageAccessTokenEncrypted) {
    connectionMetadata.pageAccessTokenEncrypted = metadata.pageAccessTokenEncrypted
    connectionMetadata.tokenStoredAt = metadata.tokenStoredAt || new Date().toISOString()
    connectionMetadata.tokenType = metadata.tokenType || "page_access_token"
  }

  return connectionMetadata as Prisma.InputJsonValue
}

export async function findWhatsAppChannelAccountId(whatsappAccountId: string | null | undefined) {
  if (!whatsappAccountId) return null

  const channelAccount = await prisma.channelAccount.findFirst({
    where: {
      channelType: "WHATSAPP",
      externalAccountId: whatsappAccountId,
    },
    select: { id: true },
  })

  return channelAccount?.id ?? null
}

export async function upsertWhatsAppChannelAccount(account: WhatsAppAccountLike) {
  return prisma.channelAccount.upsert({
    where: {
      channelType_externalAccountId: {
        channelType: "WHATSAPP",
        externalAccountId: account.id,
      },
    },
    create: {
      name: account.name || "WhatsApp Account",
      channelType: "WHATSAPP",
      provider: account.provider || "WHATSAPP",
      status: account.status || "DISCONNECTED",
      externalAccountId: account.id,
      phoneNumberId: account.phone || null,
      branchId: account.branchId || null,
    },
    update: {
      name: account.name || "WhatsApp Account",
      provider: account.provider || "WHATSAPP",
      status: account.status || "DISCONNECTED",
      phoneNumberId: account.phone || null,
      branchId: account.branchId || null,
    },
  })
}

export async function findMetaFacebookChannelAccount() {
  return prisma.channelAccount.findFirst({
    where: {
      channelType: "FACEBOOK_MESSENGER",
      OR: [
        { provider: "META" },
        { provider: "meta" },
        { provider: "meta-oauth" },
      ],
    },
    orderBy: { createdAt: "desc" },
  })
}

export async function upsertMetaFacebookChannelAccount(
  page: MetaFacebookPageLike,
  metadata: MetaFacebookConnectionMetadata = {},
) {
  const connectionMetadata = buildMetaFacebookChannelMetadata(page, metadata)

  return prisma.channelAccount.upsert({
    where: {
      channelType_externalAccountId: {
        channelType: "FACEBOOK_MESSENGER",
        externalAccountId: page.id,
      },
    },
    create: {
      name: page.name || "Facebook Page",
      channelType: "FACEBOOK_MESSENGER",
      provider: "META",
      status: "CONNECTED",
      externalAccountId: page.id,
      pageId: page.id,
      metadata: connectionMetadata,
    },
    update: {
      name: page.name || "Facebook Page",
      provider: "META",
      status: "CONNECTED",
      pageId: page.id,
      metadata: connectionMetadata,
    },
  })
}

export async function upsertMetaInstagramChannelAccount(params: {
  instagramAccountId: string
  name: string
  pageId: string
  instagramUsername?: string | null
  instagramProfilePictureUrl?: string | null
  pageAccessTokenEncrypted?: string
  branchId?: string | null
}) {
  const metadata: Record<string, unknown> = {
    connectionState: "CONNECTED",
    connectedAt: new Date().toISOString(),
    instagramUsername: params.instagramUsername || null,
    instagramProfilePictureUrl: params.instagramProfilePictureUrl || null,
    pageId: params.pageId,
    pageAccessTokenEncrypted: params.pageAccessTokenEncrypted || null,
  }

  return prisma.channelAccount.upsert({
    where: {
      channelType_externalAccountId: {
        channelType: "INSTAGRAM",
        externalAccountId: params.instagramAccountId,
      },
    },
    create: {
      name: params.name || "Instagram Account",
      channelType: "INSTAGRAM",
      provider: "META",
      status: "CONNECTED",
      externalAccountId: params.instagramAccountId,
      instagramBusinessAccountId: params.instagramAccountId,
      pageId: params.pageId,
      branchId: params.branchId || null,
      metadata: metadata as Prisma.InputJsonValue,
    },
    update: {
      name: params.name || "Instagram Account",
      provider: "META",
      status: "CONNECTED",
      pageId: params.pageId,
      branchId: params.branchId || null,
      metadata: metadata as Prisma.InputJsonValue,
    },
  })
}