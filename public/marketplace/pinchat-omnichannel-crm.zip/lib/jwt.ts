import jwt from 'jsonwebtoken'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-this-in-production'
const JWT_EXPIRES_IN = '7d' // Token expires in 7 days

export interface JWTPayload {
    userId: string
    email: string
    role: string
}

/**
 * Generate JWT token for user
 */
export function generateToken(payload: JWTPayload): string {
    return jwt.sign(payload, JWT_SECRET, {
        expiresIn: JWT_EXPIRES_IN,
        issuer: 'pinchat-crm'
    })
}

/**
 * Verify and decode JWT token
 */
export function verifyToken(token: string): JWTPayload | null {
    try {
        const decoded = jwt.verify(token, JWT_SECRET, {
            issuer: 'pinchat-crm'
        }) as JWTPayload
        
        return decoded
    } catch (error) {
        console.error('JWT verification failed:', error)
        return null
    }
}

/**
 * Extract token from Authorization header
 */
export function extractTokenFromHeader(authHeader: string | null): string | null {
    if (!authHeader) return null
    
    // Format: "Bearer <token>"
    const parts = authHeader.split(' ')
    if (parts.length !== 2 || parts[0] !== 'Bearer') {
        return null
    }
    
    return parts[1]
}

/**
 * Decode token without verification (for debugging)
 */
export function decodeToken(token: string): any {
    try {
        return jwt.decode(token)
    } catch {
        return null
    }
}
