"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { AppLayout } from "@/components/app-layout"
import { useI18n } from "@/lib/i18n"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Smartphone, CheckCircle2, XCircle, Clock, Copy, QrCode, RefreshCw, Trash2 } from "lucide-react"
import { format } from "date-fns"
import { useToast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"
import { authenticatedFetch, getUserRole } from "@/lib/auth"
import { getEnabledAddOnIds, loadEnabledAddOnIds, saveEnabledAddOnIds } from "@/lib/add-ons"
import { ChannelCard } from "@/components/channels/channel-card"
import { getChannelIcon, getChannelLabel } from "@/lib/channels"

interface WhatsAppAccount {
  id: string
  name: string
  phone: string
  provider: string
  status: "CONNECTED" | "DISCONNECTED" | "WAITING"
  createdAt: string
  updatedAt: string
}

type MetaConnectionState = {
  metaConfigured: boolean
  tokenEncryptionConfigured: boolean
  missingEnv: string[]
  facebookPage: {
    connected: boolean
    channelAccountId: string | null
    pageId: string | null
    status: string
    pageName: string | null
    connectionState: string | null
    connectedAt: string | null
  }
  instagramPage: {
    connected: boolean
    channelAccountId: string | null
    instagramAccountId: string | null
    status: string
    name: string | null
    username: string | null
    connectedAt: string | null
  }
}

export default function AccountsPage() {
  const router = useRouter()
  const [accounts, setAccounts] = useState<WhatsAppAccount[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [provider, setProvider] = useState<"meta-cloud" | "whatsapp-web">("whatsapp-web")
  const [qrGenerated, setQrGenerated] = useState(false)
  const [enabledAddOnIds, setEnabledAddOnIds] = useState<Set<string>>(() => loadEnabledAddOnIds())
  const [newAccount, setNewAccount] = useState({
    name: "",
    phone: ""
  })
  const [createdAccountId, setCreatedAccountId] = useState<string | null>(null)
  const [accountToDelete, setAccountToDelete] = useState<string | null>(null)
  const canDeleteAccount = getUserRole() === "ADMIN"
  const { toast } = useToast()
  const { t, language } = useI18n()
  const metaSetupHref = "/settings?tab=integrations#meta-settings"
  const [metaConnection, setMetaConnection] = useState<MetaConnectionState>({
    metaConfigured: false,
    tokenEncryptionConfigured: false,
    missingEnv: [],
    facebookPage: {
      connected: false,
      channelAccountId: null,
      pageId: null,
      status: "DISCONNECTED",
      pageName: null,
      connectionState: "DISCONNECTED",
      connectedAt: null,
    },
    instagramPage: {
      connected: false,
      channelAccountId: null,
      instagramAccountId: null,
      status: "DISCONNECTED",
      name: null,
      username: null,
      connectedAt: null,
    },
  })
  const [metaConnectionLoading, setMetaConnectionLoading] = useState(true)

  useEffect(() => {
    fetchAccounts()
  }, [])

  useEffect(() => {
    let isMounted = true

    const loadEnabledAddOns = async () => {
      try {
        const response = await authenticatedFetch('/api/add-ons')
        const data = await response.json()

        if (response.ok && data.success && Array.isArray(data.enabledAddOns)) {
          const nextIds = getEnabledAddOnIds(data.enabledAddOns)
          if (isMounted) {
            setEnabledAddOnIds(nextIds)
            saveEnabledAddOnIds(nextIds)
          }
          return
        }
      } catch (error) {
        console.error('Error fetching add-ons settings:', error)
      }

      if (isMounted) {
        setEnabledAddOnIds(loadEnabledAddOnIds())
      }
    }

    loadEnabledAddOns()

    return () => {
      isMounted = false
    }
  }, [])

  useEffect(() => {
    let isMounted = true

    const loadMetaConnection = async () => {
      try {
        const response = await authenticatedFetch('/api/meta/connections')
        const data = await response.json()

        if (response.ok && data.success && isMounted) {
          setMetaConnection({
            metaConfigured: Boolean(data.metaConfigured ?? data.configured),
            tokenEncryptionConfigured: Boolean(data.tokenEncryptionConfigured),
            missingEnv: Array.isArray(data.missingEnv) ? data.missingEnv : [],
            facebookPage: data.facebookPage || {
              connected: false,
              channelAccountId: null,
              pageId: null,
              status: "DISCONNECTED",
              pageName: null,
              connectionState: "DISCONNECTED",
              connectedAt: null,
            },
            instagramPage: data.instagramPage || {
              connected: false,
              channelAccountId: null,
              instagramAccountId: null,
              status: "DISCONNECTED",
              name: null,
              username: null,
              connectedAt: null,
            },
          })
          return
        }
      } catch (error) {
        console.error('Error fetching Meta connection status:', error)
      }

      if (isMounted) {
        setMetaConnection((current) => ({ ...current, metaConfigured: false }))
      }
    }

    loadMetaConnection().finally(() => {
      if (isMounted) {
        setMetaConnectionLoading(false)
      }
    })

    return () => {
      isMounted = false
    }
  }, [])

  const facebookAddOnEnabled = enabledAddOnIds.has("facebook_messenger")
  const instagramAddOnEnabled = enabledAddOnIds.has("instagram_dm")
  const facebookPageConnected = Boolean(metaConnection.facebookPage.connected)
  const instagramPageConnected = Boolean(metaConnection.instagramPage.connected)

  const facebookCardStatus = !facebookAddOnEnabled
    ? t("disabled")
    : !metaConnection.metaConfigured
      ? (language === "ar" ? "مطلوبة بيانات Meta" : "Meta credentials required")
      : !metaConnection.tokenEncryptionConfigured
        ? (language === "ar" ? "مطلوب تشفير الرموز" : "Token encryption required")
      : facebookPageConnected
        ? (language === "ar" ? "متصل" : "Connected")
        : t("setupReady")

  const instagramCardStatus = !instagramAddOnEnabled
    ? t("disabled")
    : !metaConnection.metaConfigured
      ? (language === "ar" ? "مطلوبة بيانات Meta" : "Meta credentials required")
      : !metaConnection.tokenEncryptionConfigured
        ? (language === "ar" ? "مطلوب تشفير الرموز" : "Token encryption required")
      : instagramPageConnected
        ? (language === "ar" ? "متصل" : "Connected")
        : t("setupReady")

  const handleStartMetaOAuth = async () => {
    try {
      const response = await authenticatedFetch('/api/meta/oauth/start', {
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
          Accept: 'application/json',
        },
      })
      const data = await response.json()

      const redirectUrl = data.redirectUrl || data.authorizationUrl

      if (!response.ok || !redirectUrl) {
        toast({
          title: t("error"),
          description: data.message || (language === "ar" ? "Meta credentials are not configured yet." : "Meta credentials are not configured yet."),
          variant: "destructive",
        })
        return
      }

      window.location.href = redirectUrl
    } catch (error) {
      toast({
        title: t("error"),
        description: language === "ar" ? "تعذر بدء ربط Meta الآن." : "Unable to start Meta connection right now.",
        variant: "destructive",
      })
    }
  }

  const fetchAccounts = async () => {
    try {
      setIsLoading(true)
      const response = await authenticatedFetch('/api/whatsapp/accounts')
      const data = await response.json()

      if (data.success) {
        setAccounts(data.accounts)
      } else {
        toast({
          title: t("error"),
          description: data.error || t("failedToFetchAccounts"),
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: t("error"),
        description: t("failedToFetchWhatsAppAccounts"),
        variant: "destructive"
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreateAccount = async () => {
    if (createdAccountId) {
      // Account was already created during QR generation
      setIsCreateOpen(false)
      setNewAccount({ name: "", phone: "" })
      setCreatedAccountId(null)
      setQrGenerated(false)
      fetchAccounts()
      return
    }

    if (!newAccount.name || !newAccount.phone) {
      toast({
        title: t("validationError"),
        description: t("pleaseFillAllRequiredFields"),
        variant: "destructive"
      })
      return
    }

    try {
      const response = await authenticatedFetch('/api/whatsapp/accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newAccount,
          provider: provider === "meta-cloud" ? "meta-cloud-api" : "whatsapp-web.js"
        })
      })

      const data = await response.json()

      if (data.success) {
        toast({
          title: t("success"),
          description: t("whatsAppAccountCreatedSuccess")
        })
        setIsCreateOpen(false)
        setNewAccount({ name: "", phone: "" })
        setCreatedAccountId(null)
        setQrGenerated(false)
        fetchAccounts()
      } else {
        toast({
          title: t("errorTitle"),
          description: data.error || t("failedToCreateAccountDesc"),
          variant: "destructive"
        })
      }
    } catch (error) {
      toast({
        title: t("error"),
        description: t("failedToCreateWhatsAppAccount"),
        variant: "destructive"
      })
    }
  }

  const handleCopyWebhook = () => {
    navigator.clipboard.writeText("https://your-domain.com/api/webhook")
    toast({
      title: t("copiedToClipboard"),
      description: t("webhookUrlCopied"),
    })
  }

  const [status, setStatus] = useState<"DISCONNECTED" | "INITIALIZING" | "WAITING_FOR_SCAN" | "CONNECTED">("DISCONNECTED")
  const [qrCodeData, setQrCodeData] = useState<string | null>(null)

  useEffect(() => {
    let interval: NodeJS.Timeout

    if (qrGenerated || status === 'INITIALIZING' || status === 'WAITING_FOR_SCAN') {
      interval = setInterval(async () => {
        try {
          const url = createdAccountId ? `/api/whatsapp/auth?accountId=${createdAccountId}` : '/api/whatsapp/auth'
          const res = await authenticatedFetch(url)
          const data = await res.json()

          if (data.status) {
            setStatus(data.status)
            if (data.status === 'CONNECTED') {
              setQrGenerated(false)
              setIsCreateOpen(false)
              toast({ title: t("connectedTitle"), description: t("whatsAppWebConnectedSuccessfully") })
              fetchAccounts() // Refresh list
            }
          }
          if (data.qrCode) {
            setQrCodeData(data.qrCode)
          }
        } catch (error) {
          console.error("Polling error", error)
        }
      }, 2000)
    }

    return () => clearInterval(interval)
  }, [qrGenerated, status])

  const handleDeleteClick = (id: string) => {
    setAccountToDelete(id)
  }

  const handleConfirmDelete = async () => {
    if (!accountToDelete) return

    try {
      const response = await authenticatedFetch(`/api/whatsapp/accounts?id=${accountToDelete}`, {
        method: 'DELETE',
      })
      const data = await response.json()

      if (data.success) {
        toast({
          title: t("success"),
          description: t("accountDeletedSuccess"),
        })
        fetchAccounts()
      } else {
        toast({
          title: t("error"),
          description: data.error || t("failedToDeleteAccount"),
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: t("error"),
        description: t("failedToDeleteAccount"),
        variant: "destructive",
      })
    } finally {
      setAccountToDelete(null)
    }
  }



  const handleGenerateQR = async () => {
    if (!newAccount.name || !newAccount.phone) {
      toast({
        title: t("validationError"),
        description: t("pleaseFillAllRequiredFields"),
        variant: "destructive"
      })
      return
    }

    setQrGenerated(true)
    setStatus('INITIALIZING')

    try {
      let accountId = createdAccountId

      // 1. Create account first if not already created
      if (!accountId) {
        const createRes = await authenticatedFetch('/api/whatsapp/accounts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...newAccount,
            provider: provider === "meta-cloud" ? "meta-cloud-api" : "whatsapp-web.js"
          })
        })
        const createData = await createRes.json()

        if (!createData.success) {
          toast({ title: t("errorTitle"), description: createData.error || t("failedToCreateAccountDesc"), variant: "destructive" })
          setQrGenerated(false)
          setStatus('DISCONNECTED')
          return
        }

        accountId = createData.account.id
        setCreatedAccountId(accountId)
        fetchAccounts() // Refresh list in background
      }

      // 2. Start initialization
      const response = await authenticatedFetch('/api/whatsapp/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'init', accountId, force: true })
      })

      const data = await response.json()
      if (!data.success) {
        toast({ title: t("error"), description: data.error, variant: "destructive" })
        setQrGenerated(false)
        setStatus('DISCONNECTED')
      }
    } catch (error) {
      toast({ title: t("error"), description: t("failedToStartWhatsAppClient"), variant: "destructive" })
      setQrGenerated(false)
      setStatus('DISCONNECTED')
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'connected':
        return (
          <Badge className="bg-green-500 hover:bg-green-600">
            <CheckCircle2 className="mr-1 h-3 w-3" />
            {t("connectedTitle")}
          </Badge>
        )
      case 'waiting':
        return (
          <Badge variant="secondary">
            <Clock className="mr-1 h-3 w-3" />
            {t("waiting")}
          </Badge>
        )
      case 'disconnected':
      default:
        return (
          <Badge variant="destructive">
            <XCircle className="mr-1 h-3 w-3" />
            {t("disconnectedTitle")}
          </Badge>
        )
    }
  }

  // Calculate stats
  const totalAccounts = accounts.length
  const connectedAccounts = accounts.filter(a => a.status === 'CONNECTED').length
  const disconnectedAccounts = accounts.filter(a => a.status === 'DISCONNECTED').length

  return (
    <AppLayout title={t("connectedChannels")}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">{t("connectedChannels")}</h2>
            <p className="text-muted-foreground">{t("manageConnectedChannels")}</p>
          </div>

          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="rounded-full shadow-md gap-2">
                <Plus className="h-4 w-4" />
                {t("connectAccount")}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]" fullScreenMobile>
              <DialogHeader>
                <DialogTitle>{t("connectWhatsAppAccount")}</DialogTitle>
                <DialogDescription>{t("chooseConnectionMethod")}</DialogDescription>
              </DialogHeader>

              <Tabs value={provider} onValueChange={(v) => setProvider(v as any)}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="meta-cloud">Meta Cloud API</TabsTrigger>
                  <TabsTrigger value="whatsapp-web">WhatsApp Web</TabsTrigger>
                </TabsList>

                <TabsContent value="meta-cloud" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="account-name">Account Name</Label>
                    <Input id="account-name" placeholder="e.g., Main Sales Number" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input id="phone" placeholder="+1234567890" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone-number-id">Phone Number ID</Label>
                    <Input id="phone-number-id" placeholder="Enter phone number ID from Meta" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="business-account-id">Business Account ID</Label>
                    <Input id="business-account-id" placeholder="Enter business account ID" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="access-token">Access Token</Label>
                    <Input id="access-token" type="password" placeholder="Enter your access token" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="verify-token">Webhook Verify Token</Label>
                    <Input id="verify-token" placeholder="Create a verify token" />
                  </div>
                </TabsContent>

                <TabsContent value="whatsapp-web" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="web-account-name">Account Name</Label>
                    <Input
                      id="web-account-name"
                      placeholder="e.g., Support Line"
                      value={newAccount.name}
                      onChange={(e) => setNewAccount({ ...newAccount, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="web-phone">Phone Number</Label>
                    <Input
                      id="web-phone"
                      placeholder="+966501234567"
                      value={newAccount.phone}
                      onChange={(e) => setNewAccount({ ...newAccount, phone: e.target.value })}
                    />
                  </div>

                  {!qrGenerated ? (
                    <Button onClick={handleGenerateQR} className="w-full gap-2" size="lg">
                      <QrCode className="h-5 w-5" />
                      Generate QR Code
                    </Button>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center justify-center rounded-xl bg-muted/50 p-8">
                        <div className="h-64 w-64 rounded-lg bg-white shadow-soft-lg flex items-center justify-center overflow-hidden">
                          {status === 'INITIALIZING' ? (
                            <div className="flex flex-col items-center gap-2 text-muted-foreground">
                              <RefreshCw className="h-8 w-8 animate-spin" />
                              <span>Initializing Client...</span>
                            </div>
                          ) : qrCodeData ? (
                            /* eslint-disable-next-line @next/next/no-img-element */
                            <img src={qrCodeData} alt="WhatsApp QR Code" className="h-full w-full object-contain" />
                          ) : (
                            <div className="flex flex-col items-center gap-2 text-muted-foreground">
                              <RefreshCw className="h-8 w-8 animate-spin" />
                              <span>Waiting for QR...</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center justify-between rounded-lg bg-secondary/10 p-3 text-sm">
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-secondary" />
                          <span>Waiting for scan...</span>
                        </div>
                        <Button variant="ghost" size="sm" onClick={handleGenerateQR}>
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </TabsContent>
              </Tabs>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateAccount}>Connect Account</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Card className="rounded-2xl border-border/60 bg-muted/20 shadow-none">
          <CardContent className="p-4 text-sm leading-6 text-muted-foreground">
            {t("connectedChannelsVsAddOns")}
          </CardContent>
        </Card>

        {/* Connected channel cards */}
        <div className="grid gap-4 md:grid-cols-3">
          <ChannelCard
            title={getChannelLabel("WHATSAPP", language)}
            description={t("manageWhatsAppAccounts")}
            icon={getChannelIcon("WHATSAPP")}
            statusLabel={connectedAccounts > 0 ? (language === "ar" ? "نشط" : "Active") : t("notConnected")}
            statusVariant={connectedAccounts > 0 ? "default" : "secondary"}
            className={cn(
              "transition-all duration-300 shadow-sm hover:shadow-md border animate-fade-in",
              connectedAccounts > 0 
                ? "border-green-500/30 bg-gradient-to-br from-green-50/40 to-background dark:from-green-950/10" 
                : "border-dashed border-border bg-muted/5"
            )}
          >
            <div className="flex items-center justify-between gap-2 py-1">
              <div>
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">{connectedAccounts}/{totalAccounts}</div>
                <p className="text-xs text-muted-foreground">{language === "ar" ? "قنوات متصلة" : "Connected channels"}</p>
              </div>
            </div>
            <Button 
              className="w-full rounded-full mt-2 font-medium" 
              onClick={() => setIsCreateOpen(true)}
            >
              {connectedAccounts > 0 
                ? (language === "ar" ? "إدارة اتصال واتساب" : "Manage WhatsApp connection") 
                : t("connectWhatsAppAccount")}
            </Button>
          </ChannelCard>

          <ChannelCard
            title={getChannelLabel("FACEBOOK_MESSENGER", language)}
            description={language === "ar" ? "تواصل عبر رسائل صفحة الفيسبوك" : "Chat via Facebook Page Messages"}
            icon={getChannelIcon("FACEBOOK_MESSENGER")}
            statusLabel={facebookCardStatus}
            statusVariant={!facebookAddOnEnabled || !metaConnection.metaConfigured || !metaConnection.tokenEncryptionConfigured ? "destructive" : facebookPageConnected ? "default" : "secondary"}
            className={cn(
              "transition-all duration-300 shadow-sm hover:shadow-md border animate-fade-in",
              !facebookAddOnEnabled 
                ? "opacity-60 bg-muted/5 border-dashed border-border/40" 
                : facebookPageConnected 
                  ? "border-blue-500/30 bg-gradient-to-br from-blue-50/40 to-background dark:from-blue-950/10" 
                  : "border-dashed border-blue-200 dark:border-blue-900/40 bg-blue-50/5 dark:bg-blue-950/5"
            )}
          >
            {metaConnectionLoading ? (
              <div className="space-y-1 text-xs text-muted-foreground py-1">
                <p>{language === "ar" ? "جارٍ تحميل حالة الربط..." : "Loading connection status..."}</p>
              </div>
            ) : !facebookAddOnEnabled ? (
              <div className="space-y-1 text-xs text-muted-foreground py-1">
                <p>{t("metaWebhookReady")}</p>
                <p className="text-destructive font-medium">{language === "ar" ? "فعّل إضافة فيسبوك ماسنجر أولاً." : "Enable Facebook Messenger add-on first."}</p>
              </div>
            ) : !metaConnection.metaConfigured ? (
              <div className="space-y-2 rounded-xl bg-destructive/5 dark:bg-destructive/10 border border-destructive/20 p-3 text-xs text-destructive">
                <p className="font-semibold">{language === "ar" ? "إعدادات تطبيق Meta غير مكتملة" : "Meta App configuration incomplete"}</p>
                <p className="text-[11px] leading-relaxed text-muted-foreground">{t("metaAppConfigRequired")}</p>
                {metaConnection.missingEnv && metaConnection.missingEnv.length > 0 && (
                  <div className="mt-1 space-y-1">
                    <p className="font-semibold text-[10px] uppercase tracking-wider text-destructive/85">{language === "ar" ? "المتغيرات المفقودة:" : "Missing Variables:"}</p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {metaConnection.missingEnv.map(env => (
                        <code key={env} className="bg-destructive/10 text-destructive px-1.5 py-0.5 rounded font-mono text-[10px] border border-destructive/20">{env}</code>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : !metaConnection.tokenEncryptionConfigured ? (
              <div className="space-y-2 rounded-xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 p-3 text-xs text-amber-855 dark:text-amber-300">
                <p className="font-semibold">{language === "ar" ? "تشفير الرموز غير مكوّن" : "Token encryption not configured"}</p>
                <p className="text-[11px] leading-relaxed text-muted-foreground">
                  {language === "ar" ? "يرجى إضافة TOKEN_ENCRYPTION_SECRET إلى ملف الإعدادات قبل ربط قنوات Meta." : "Please add TOKEN_ENCRYPTION_SECRET to settings before connecting Meta channels."}
                </p>
              </div>
            ) : facebookPageConnected ? (
              <div className="space-y-1 text-xs text-muted-foreground py-1">
                <p>{language === "ar" ? "الصفحة المتصلة" : "Connected page"}: <span className="font-semibold text-foreground">{metaConnection.facebookPage.pageName || "Facebook Page"}</span></p>
                <p>{language === "ar" ? "معرّف الصفحة" : "Page ID"}: <span className="font-medium font-mono text-foreground">{metaConnection.facebookPage.pageId}</span></p>
                {metaConnection.facebookPage.connectedAt ? (
                  <p>{language === "ar" ? "متصل منذ" : "Connected at"}: <span className="font-medium text-foreground">{format(new Date(metaConnection.facebookPage.connectedAt), "PPp")}</span></p>
                ) : null}
              </div>
            ) : (
              <div className="space-y-1 text-xs text-muted-foreground py-1">
                <p className="text-green-600 dark:text-green-400 font-medium">✓ {t("metaWebhookReady")}</p>
                <p>{language === "ar" ? "جاهز للربط عبر حساب فيسبوك." : "Ready to link via Facebook account."}</p>
              </div>
            )}

            <div className="flex flex-col gap-2 mt-2">
              <Button
                className="w-full rounded-full font-medium"
                variant={facebookPageConnected ? "outline" : "default"}
                disabled={!facebookAddOnEnabled || !metaConnection.metaConfigured || !metaConnection.tokenEncryptionConfigured}
                onClick={facebookPageConnected ? () => router.push(metaSetupHref) : handleStartMetaOAuth}
              >
                {!facebookAddOnEnabled
                  ? (language === "ar" ? "فتح الإضافات" : "Open Add-ons")
                  : !metaConnection.metaConfigured
                    ? (language === "ar" ? "إعدادات Meta مطلوبة" : "Meta credentials required")
                    : !metaConnection.tokenEncryptionConfigured
                      ? (language === "ar" ? "مطلوب تشفير الرموز" : "Token encryption required")
                    : facebookPageConnected
                      ? (language === "ar" ? "إدارة الصفحة المتصلة" : "Manage Connected Page")
                      : (language === "ar" ? "ربط فيسبوك عبر Meta" : "Connect Facebook with Meta")}
              </Button>

              {facebookAddOnEnabled && (
                <Button
                  className="w-full rounded-full text-xs font-normal"
                  variant="ghost"
                  size="sm"
                  onClick={() => router.push(metaSetupHref)}
                >
                  {language === "ar" ? "عرض دليل الإعداد" : "View setup guide"}
                </Button>
              )}
            </div>
          </ChannelCard>

          <ChannelCard
            title={getChannelLabel("INSTAGRAM_DM", language)}
            description={language === "ar" ? "تواصل عبر رسائل إنستغرام المباشرة" : "Chat via Instagram Direct Messages"}
            icon={getChannelIcon("INSTAGRAM_DM")}
            statusLabel={instagramCardStatus}
            statusVariant={!instagramAddOnEnabled || !metaConnection.metaConfigured || !metaConnection.tokenEncryptionConfigured ? "destructive" : instagramPageConnected ? "default" : "secondary"}
            className={cn(
              "transition-all duration-300 shadow-sm hover:shadow-md border animate-fade-in",
              !instagramAddOnEnabled 
                ? "opacity-60 bg-muted/5 border-dashed border-border/40" 
                : instagramPageConnected 
                  ? "border-pink-500/30 bg-gradient-to-br from-pink-50/40 to-background dark:from-pink-950/10" 
                  : "border-dashed border-pink-200 dark:border-pink-900/40 bg-pink-50/5 dark:bg-pink-950/5"
            )}
          >
            {metaConnectionLoading ? (
              <div className="space-y-1 text-xs text-muted-foreground py-1">
                <p>{language === "ar" ? "جارٍ تحميل حالة الربط..." : "Loading connection status..."}</p>
              </div>
            ) : !instagramAddOnEnabled ? (
              <div className="space-y-1 text-xs text-muted-foreground py-1">
                <p>{t("metaWebhookReady")}</p>
                <p className="text-destructive font-medium">{language === "ar" ? "فعّل إضافة إنستغرام أولاً." : "Enable Instagram add-on first."}</p>
              </div>
            ) : !metaConnection.metaConfigured ? (
              <div className="space-y-2 rounded-xl bg-destructive/5 dark:bg-destructive/10 border border-destructive/20 p-3 text-xs text-destructive">
                <p className="font-semibold">{language === "ar" ? "إعدادات تطبيق Meta غير مكتملة" : "Meta App configuration incomplete"}</p>
                <p className="text-[11px] leading-relaxed text-muted-foreground">{t("metaAppConfigRequired")}</p>
                {metaConnection.missingEnv && metaConnection.missingEnv.length > 0 && (
                  <div className="mt-1 space-y-1">
                    <p className="font-semibold text-[10px] uppercase tracking-wider text-destructive/85">{language === "ar" ? "المتغيرات المفقودة:" : "Missing Variables:"}</p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {metaConnection.missingEnv.map(env => (
                        <code key={env} className="bg-destructive/10 text-destructive px-1.5 py-0.5 rounded font-mono text-[10px] border border-destructive/20">{env}</code>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : !metaConnection.tokenEncryptionConfigured ? (
              <div className="space-y-2 rounded-xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 p-3 text-xs text-amber-855 dark:text-amber-300">
                <p className="font-semibold">{language === "ar" ? "تشفير الرموز غير مكوّن" : "Token encryption not configured"}</p>
                <p className="text-[11px] leading-relaxed text-muted-foreground">
                  {language === "ar" ? "يرجى إضافة TOKEN_ENCRYPTION_SECRET إلى ملف الإعدادات قبل ربط قنوات Meta." : "Please add TOKEN_ENCRYPTION_SECRET to settings before connecting Meta channels."}
                </p>
              </div>
            ) : instagramPageConnected ? (
              <div className="space-y-1 text-xs text-muted-foreground py-1">
                <p>{language === "ar" ? "الحساب المتصل" : "Connected account"}: <span className="font-semibold text-foreground">{metaConnection.instagramPage.name || "Instagram Account"}</span></p>
                {metaConnection.instagramPage.username && (
                  <p>{language === "ar" ? "اسم المستخدم" : "Username"}: <span className="font-medium text-foreground">@{metaConnection.instagramPage.username}</span></p>
                )}
                {metaConnection.instagramPage.connectedAt ? (
                  <p>{language === "ar" ? "متصل منذ" : "Connected at"}: <span className="font-medium text-foreground">{format(new Date(metaConnection.instagramPage.connectedAt), "PPp")}</span></p>
                ) : null}
              </div>
            ) : (
              <div className="space-y-1 text-xs text-muted-foreground py-1">
                <p className="text-green-600 dark:text-green-400 font-medium">✓ {t("metaWebhookReady")}</p>
                <p>{t("instagramProfessionalRequired")}</p>
              </div>
            )}

            <div className="flex flex-col gap-2 mt-2">
              <Button
                className="w-full rounded-full font-medium"
                variant={instagramPageConnected ? "outline" : "default"}
                disabled={!instagramAddOnEnabled || !metaConnection.metaConfigured || !metaConnection.tokenEncryptionConfigured}
                onClick={instagramPageConnected ? () => router.push(metaSetupHref) : handleStartMetaOAuth}
              >
                {!instagramAddOnEnabled
                  ? (language === "ar" ? "فتح الإضافات" : "Open Add-ons")
                  : !metaConnection.metaConfigured
                    ? (language === "ar" ? "إعدادات Meta مطلوبة" : "Meta credentials required")
                    : !metaConnection.tokenEncryptionConfigured
                      ? (language === "ar" ? "مطلوب تشفير الرموز" : "Token encryption required")
                    : instagramPageConnected
                      ? (language === "ar" ? "إدارة الحساب المتصل" : "Manage Connected Account")
                      : (language === "ar" ? "ربط إنستغرام عبر Meta" : "Connect Instagram with Meta")}
              </Button>

              {instagramAddOnEnabled && (
                <Button
                  className="w-full rounded-full text-xs font-normal"
                  variant="ghost"
                  size="sm"
                  onClick={() => router.push(metaSetupHref)}
                >
                  {language === "ar" ? "عرض دليل الإعداد" : "View setup guide"}
                </Button>
              )}
            </div>
          </ChannelCard>
        </div>

        {/* Accounts Table */}
        <Card>
          <CardHeader>
            <CardTitle>{t("connectedChannels")}</CardTitle>
            <CardDescription>{t("manageConnectedChannels")}</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex h-32 items-center justify-center">
                <div className="text-muted-foreground">Loading accounts...</div>
              </div>
            ) : accounts.length === 0 ? (
              <div className="flex h-32 flex-col items-center justify-center gap-2">
                <Smartphone className="h-12 w-12 text-muted-foreground/50" />
                <p className="text-muted-foreground">No channels connected</p>
                <Button onClick={() => setIsCreateOpen(true)} variant="outline" size="sm">
                  Connect your first channel
                </Button>
              </div>
            ) : (
              <>
                {/* Mobile: Card list */}
                <div className="md:hidden space-y-3">
                  {accounts.map((account) => (
                    <div
                      key={account.id}
                      className="rounded-xl border bg-card p-4 space-y-4"
                    >
                      <div className="flex items-start gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                          <Smartphone className="h-5 w-5" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="font-semibold truncate">{account.name}</p>
                          <p className="text-sm text-muted-foreground font-mono">{account.phone}</p>
                          <div className="mt-2">{getStatusBadge(account.status)}</div>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="min-h-[44px] flex-1"
                          onClick={() => (window.location.href = "/whatsapp")}
                        >
                          Manage
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="min-h-[44px] flex-1"
                          onClick={() =>
                            toast({
                              title: "Test Message",
                              description: `Testing connection to ${account.name}`,
                            })
                          }
                        >
                          Test
                        </Button>
                        {canDeleteAccount && (
                        <Button
                          size="sm"
                          variant="destructive"
                          className="min-h-[44px] min-w-[44px]"
                          onClick={() => handleDeleteClick(account.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Desktop: Table */}
                <div className="hidden md:block rounded-md border overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[200px]">{t("accountName")}</TableHead>
                        <TableHead>{t("phoneNumber")}</TableHead>
                        <TableHead>{t("providerLabel")}</TableHead>
                        <TableHead>{t("statusLabel")}</TableHead>
                        <TableHead>{t("connectedDate")}</TableHead>
                        <TableHead className="text-end">{t("actionsTableHeader")}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {accounts.map((account) => (
                        <TableRow key={account.id}>
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
                                <Smartphone className="h-4 w-4" />
                              </div>
                              {account.name}
                            </div>
                          </TableCell>
                          <TableCell className="font-mono text-sm">{account.phone}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="rounded-full">
                              {account.provider === "meta-cloud-api" ? "Meta Cloud API" : "WhatsApp Web"}
                            </Badge>
                          </TableCell>
                          <TableCell>{getStatusBadge(account.status)}</TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {format(new Date(account.createdAt), "MMM dd, yyyy")}
                          </TableCell>
                          <TableCell className="text-end">
                            <div className="flex justify-end gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => (window.location.href = "/whatsapp")}
                              >
                                Manage
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() =>
                                  toast({
                                    title: "Test Message",
                                    description: `Testing connection to ${account.name}`,
                                  })
                                }
                              >
                                Test
                              </Button>
                              {canDeleteAccount && (
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleDeleteClick(account.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {canDeleteAccount && (
        <AlertDialog open={!!accountToDelete} onOpenChange={(open) => !open && setAccountToDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>
                {language === 'ar' ? 'هل أنت متأكد تماماً؟' : 'Are you absolutely sure?'}
              </AlertDialogTitle>
              <AlertDialogDescription>
                {language === 'ar'
                  ? 'لا يمكن التراجع عن هذا الإجراء. سوف يتم حذف ربط حساب واتساب نهائياً من الخوادم.'
                  : 'This action cannot be undone. This will permanently delete the WhatsApp account connection from our servers.'}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>
                {language === 'ar' ? 'إلغاء' : 'Cancel'}
              </AlertDialogCancel>
              <AlertDialogAction onClick={handleConfirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                {language === 'ar' ? 'حذف' : 'Delete'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
        )}
      </div>
    </AppLayout>
  )
}
