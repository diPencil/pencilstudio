import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { upsertWhatsAppChannelAccount } from '@/lib/channel-accounts'

const WHATSAPP_SERVICE_URL = 'http://localhost:3001'

// GET - Get WhatsApp connection status and QR code
export async function GET(req: NextRequest) {
    try {
        const { searchParams } = new URL(req.url);
        const accountId = searchParams.get('accountId');
        let account = null;
        if (accountId) {
            account = await prisma.whatsAppAccount.findUnique({ where: { id: accountId } });
        } else {
            account = await prisma.whatsAppAccount.findFirst({ orderBy: { createdAt: 'desc' } });
        }

        // Always fetch all accounts for UI
        const response = await fetch(`${WHATSAPP_SERVICE_URL}/status`);
        const data = await response.json();

        // If we have an account, get detailed status
        let detailedStatus = null;
        if (account) {
            try {
                const statusRes = await fetch(`${WHATSAPP_SERVICE_URL}/status/${account.id}`);
                detailedStatus = await statusRes.json();
                // Sync DB when service says connected but DB might be stale
                if (detailedStatus?.success && detailedStatus?.isReady && account.id) {
                    await prisma.whatsAppAccount.updateMany({
                        where: { id: account.id },
                        data: { status: 'CONNECTED', updatedAt: new Date() }
                    });
                }
            } catch (err) {
                console.error('Error getting detailed status:', err);
            }
        }

        // Format accounts with accountId
        const formattedAccounts = (data.accounts || []).map((acc: any) => ({
            ...acc,
            accountId: acc.accountId || acc.id || undefined
        }));

        return NextResponse.json({
            success: data.success,
            isReady: detailedStatus?.isReady || false,
            qrCode: detailedStatus?.qrCode || null,
            status: detailedStatus?.status || 'DISCONNECTED',
            userInfo: detailedStatus?.phone ? {
                name: account?.name || 'Unknown',
                phone: detailedStatus.phone,
                accountId: account?.id,
                branchId: account?.branchId || null,
            } : null,
            accounts: formattedAccounts
        });
    } catch (error: any) {
        console.error('Error getting WhatsApp status:', error);
        return NextResponse.json(
            {
                success: false,
                error: 'WhatsApp service unavailable',
                isReady: false,
                hasQR: false
            },
            { status: 503 }
        );
    }
}

// POST - Initialize WhatsApp connection
export async function POST(request: NextRequest) {
    try {
        const body = await request.json()
        const { action } = body

        // Get or create default account
        let account = await prisma.whatsAppAccount.findFirst({
            orderBy: { createdAt: 'desc' }
        })

        // If no account exists, create a default one
        if (!account) {
            account = await prisma.whatsAppAccount.create({
                data: {
                    name: 'Default Account',
                    phone: '',
                    provider: 'whatsapp-web',
                    status: 'DISCONNECTED'
                }
            })
            await upsertWhatsAppChannelAccount(account)
        }

        // Initialize the account
        const response = await fetch(`${WHATSAPP_SERVICE_URL}/initialize/${account.id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                phone: account.phone || '',
                force: true
            })
        })

        const data = await response.json()

        if (data.success) {
            await prisma.whatsAppAccount.update({
                where: { id: account.id },
                data: { status: 'WAITING' }
            })
            await upsertWhatsAppChannelAccount({
                id: account.id,
                name: account.name,
                phone: account.phone,
                provider: account.provider,
                status: 'WAITING',
                branchId: account.branchId,
            })
            return NextResponse.json({
                success: true,
                message: data.message || 'Initialization started',
                accountId: account.id
            })
        }

        return NextResponse.json({
            success: false,
            error: data.error || 'خدمة الواتساب رفضت الطلب',
            accountId: account.id
        }, { status: 400 })
    } catch (error: any) {
        console.error('Error initializing WhatsApp:', error)
        return NextResponse.json(
            { success: false, error: error.message || 'تعذر الاتصال بخدمة الواتساب (تأكد أن البورت 3001 شغال)' },
            { status: 503 }
        )
    }
}
