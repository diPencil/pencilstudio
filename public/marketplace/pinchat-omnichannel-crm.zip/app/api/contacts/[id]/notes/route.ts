import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/db"
import { requireAuthWithScope, unauthorizedResponse, forbiddenResponse } from "@/lib/api-auth"

// Helper function to verify contact scope
async function verifyContactScope(contactId: string, scope: any) {
    const contact = await prisma.contact.findUnique({
        where: { id: contactId },
    })

    if (!contact) {
        return { success: false, error: "Contact not found", status: 404 }
    }

    if (scope.role !== "ADMIN") {
        const inBranch = scope.branchIds?.length && contact.branchId && scope.branchIds.includes(contact.branchId)
        const hasConvFromWa = scope.whatsappAccountIds?.length
            ? await prisma.conversation.findFirst({
                where: {
                    contactId,
                    messages: {
                        some: { whatsappAccountId: { in: scope.whatsappAccountIds } },
                    },
                },
            })
            : null
        const assignedToMe = await prisma.conversation.findFirst({
            where: { contactId, assignedToId: scope.userId },
        })

        if (!inBranch && !hasConvFromWa && !assignedToMe) {
            return { success: false, error: "You do not have access to this contact.", status: 403 }
        }
    }

    return { success: true, contact }
}

// GET - Fetch notes for a contact (auth + scope check)
export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const scope = await requireAuthWithScope(request)
        const { id: contactId } = await params

        const scopeCheck = await verifyContactScope(contactId, scope)
        if (!scopeCheck.success) {
            if (scopeCheck.status === 403) return forbiddenResponse(scopeCheck.error || "")
            return NextResponse.json({ success: false, error: scopeCheck.error }, { status: scopeCheck.status })
        }

        const notes = await prisma.note.findMany({
            where: { contactId },
            orderBy: { createdAt: 'desc' },
            include: {
                creator: {
                    select: { id: true, name: true, role: true }
                }
            }
        })

        return NextResponse.json({
            success: true,
            data: notes
        })
    } catch (error) {
        if (error instanceof Error) {
            if (error.message === "Unauthorized") return unauthorizedResponse()
            if (error.message === "Forbidden") return forbiddenResponse()
        }
        console.error("Error fetching notes:", error)
        return NextResponse.json(
            { success: false, error: "Failed to fetch notes" },
            { status: 500 }
        )
    }
}

// POST - Add a new note to a contact (auth + scope check, creator set dynamically)
export async function POST(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const scope = await requireAuthWithScope(request)
        const { id: contactId } = await params
        const body = await request.json()

        if (!body.content || !body.content.trim()) {
            return NextResponse.json(
                { success: false, error: "Content is required" },
                { status: 400 }
            )
        }

        const scopeCheck = await verifyContactScope(contactId, scope)
        if (!scopeCheck.success) {
            if (scopeCheck.status === 403) return forbiddenResponse(scopeCheck.error || "")
            return NextResponse.json({ success: false, error: scopeCheck.error }, { status: scopeCheck.status })
        }

        const note = await prisma.note.create({
            data: {
                content: body.content.trim(),
                contactId,
                createdBy: scope.userId
            },
            include: {
                creator: {
                    select: { id: true, name: true, role: true }
                }
            }
        })

        return NextResponse.json({
            success: true,
            data: note
        })
    } catch (error) {
        if (error instanceof Error) {
            if (error.message === "Unauthorized") return unauthorizedResponse()
            if (error.message === "Forbidden") return forbiddenResponse()
        }
        console.error("Error creating note:", error)
        return NextResponse.json(
            { success: false, error: "Failed to create note" },
            { status: 500 }
        )
    }
}

// DELETE - Delete a note (auth + scope check + role/owner checks)
export async function DELETE(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const scope = await requireAuthWithScope(request)
        const { id: contactId } = await params
        const { searchParams } = new URL(request.url)
        const noteId = searchParams.get("noteId")

        if (!noteId) {
            return NextResponse.json(
                { success: false, error: "Note ID is required" },
                { status: 400 }
            )
        }

        // 1. Verify contact scope access
        const scopeCheck = await verifyContactScope(contactId, scope)
        if (!scopeCheck.success) {
            if (scopeCheck.status === 403) return forbiddenResponse(scopeCheck.error || "")
            return NextResponse.json({ success: false, error: scopeCheck.error }, { status: scopeCheck.status })
        }

        // 2. Fetch target note
        const note = await prisma.note.findUnique({
            where: { id: noteId }
        })

        if (!note || note.contactId !== contactId) {
            return NextResponse.json(
                { success: false, error: "Note not found" },
                { status: 404 }
            )
        }

        // 3. Permission logic: Admin, Supervisor, or creator can delete
        const isCreator = note.createdBy === scope.userId
        const isAdminOrSupervisor = scope.role === "ADMIN" || scope.role === "SUPERVISOR"

        if (!isCreator && !isAdminOrSupervisor) {
            return forbiddenResponse("Only the creator of the note or an Admin/Supervisor can delete it.")
        }

        await prisma.note.delete({
            where: { id: noteId }
        })

        return NextResponse.json({
            success: true,
            message: "Note deleted successfully"
        })
    } catch (error) {
        if (error instanceof Error) {
            if (error.message === "Unauthorized") return unauthorizedResponse()
            if (error.message === "Forbidden") return forbiddenResponse()
        }
        console.error("Error deleting note:", error)
        return NextResponse.json(
            { success: false, error: "Failed to delete note" },
            { status: 500 }
        )
    }
}
