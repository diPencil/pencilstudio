import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/db"
import { logActivity } from "@/lib/logger"
import { requireAuthWithScope, requireDeleteAllowed, unauthorizedResponse, forbiddenResponse } from "@/lib/api-auth"

// GET - Fetch single contact (scoped: non-Admin only within their branches)
export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const scope = await requireAuthWithScope(request)
        const { id } = await params
        const contact = await prisma.contact.findUnique({
            where: { id },
            include: {
                conversations: {
                    orderBy: { lastMessageAt: 'desc' },
                    take: 10
                }
            }
        })

        if (!contact) {
            return NextResponse.json(
                {
                    success: false,
                    error: "Contact not found"
                },
                { status: 404 }
            )
        }

        if (scope.role !== 'ADMIN') {
            const inScope = scope.branchIds?.length && contact.branchId && scope.branchIds.includes(contact.branchId)
            if (!inScope) {
                return forbiddenResponse("You do not have access to this contact")
            }
        }

        return NextResponse.json({
            success: true,
            data: contact
        })
    } catch (error) {
        console.error('Error fetching contact:', error)
        return NextResponse.json(
            {
                success: false,
                error: "Failed to fetch contact"
            },
            { status: 500 }
        )
    }
}

// PUT - Update contact (Admin + Scoped Agent/Supervisor)
export async function PUT(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const scope = await requireAuthWithScope(request)
        const { id } = await params
        const body = await request.json()

        // Get old values before update
        const oldContact = await prisma.contact.findUnique({
            where: { id }
        })

        if (!oldContact) {
            return NextResponse.json(
                {
                    success: false,
                    error: "Contact not found"
                },
                { status: 404 }
            )
        }

        // Scope check for non-Admin users
        if (scope.role !== "ADMIN") {
            const inBranch = scope.branchIds?.length && oldContact.branchId && scope.branchIds.includes(oldContact.branchId)
            const hasConvFromWa = scope.whatsappAccountIds?.length
                ? await prisma.conversation.findFirst({
                    where: {
                        contactId: id,
                        messages: {
                            some: { whatsappAccountId: { in: scope.whatsappAccountIds } },
                        },
                    },
                })
                : null
            const assignedToMe = await prisma.conversation.findFirst({
                where: { contactId: id, assignedToId: scope.userId },
            })
            if (!inBranch && !hasConvFromWa && !assignedToMe) {
                return forbiddenResponse("You do not have access to this contact.")
            }
        }

        // Build update data
        const updateData: any = {
            name: body.name !== undefined ? body.name : oldContact.name,
            email: body.email !== undefined ? (body.email || null) : oldContact.email,
            tags: body.tags !== undefined ? (body.tags && body.tags.length > 0 ? body.tags : null) : oldContact.tags,
            notes: body.notes !== undefined ? (body.notes || null) : oldContact.notes,
            followUpDate: body.followUpDate !== undefined ? (body.followUpDate ? new Date(body.followUpDate) : null) : oldContact.followUpDate,
        }

        if (scope.role === "ADMIN") {
            updateData.phone = body.phone !== undefined ? body.phone : oldContact.phone
            updateData.branchId = body.branchId !== undefined ? (body.branchId || null) : oldContact.branchId
        } else {
            // Protect phone & branchId from changes by non-admins
            updateData.phone = oldContact.phone
            updateData.branchId = oldContact.branchId
        }

        const contact = await prisma.contact.update({
            where: { id },
            data: updateData
        })

        // Log activity
        await logActivity({
            userId: scope.userId,
            action: "UPDATE",
            entityType: "Contact",
            entityId: contact.id,
            oldValues: {
                name: oldContact?.name,
                phone: oldContact?.phone,
                email: oldContact?.email
            },
            newValues: {
                name: contact.name,
                phone: contact.phone,
                email: contact.email
            },
            description: `Updated contact: ${contact.name}`
        })

        return NextResponse.json({
            success: true,
            data: contact
        })
    } catch (error: unknown) {
        if (error instanceof Error) {
            if (error.message === "Unauthorized") return unauthorizedResponse()
            if (error.message === "Forbidden") return forbiddenResponse()
        }
        console.error("Error updating contact:", error)

        const errorCode = typeof error === "object" && error !== null && "code" in error
            ? (error as { code?: string }).code
            : undefined

        if (errorCode === 'P2025') {
            return NextResponse.json(
                {
                    success: false,
                    error: "Contact not found"
                },
                { status: 404 }
            )
        }

        if (errorCode === 'P2002') {
            return NextResponse.json(
                {
                    success: false,
                    error: "Phone number already exists"
                },
                { status: 409 }
            )
        }

        return NextResponse.json(
            {
                success: false,
                error: "Failed to update contact"
            },
            { status: 500 }
        )
    }
}

// DELETE - Delete contact (Admin only; Supervisor blocked and audited)
export async function DELETE(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { id } = await params
        const contact = await prisma.contact.findUnique({ where: { id } })
        const prevState = contact ? { name: contact.name, phone: contact.phone, email: contact.email } : undefined
        const allowed = await requireDeleteAllowed(request, "Contact", id, prevState)
        if (allowed instanceof NextResponse) return allowed
        const { scope } = allowed

        await prisma.contact.delete({
            where: { id }
        })

        await logActivity({
            userId: scope.userId,
            action: "DELETE",
            entityType: "Contact",
            entityId: id,
            oldValues: prevState,
            description: `Deleted contact: ${contact?.name}`
        })

        return NextResponse.json({
            success: true,
            message: "Contact deleted successfully"
        })
    } catch (error: unknown) {
        if (error instanceof Error) {
            if (error.message === "Unauthorized") return unauthorizedResponse()
            if (error.message === "Forbidden") return forbiddenResponse()
        }
        console.error("Error deleting contact:", error)

        const errorCode = typeof error === "object" && error !== null && "code" in error
            ? (error as { code?: string }).code
            : undefined

        if (errorCode === 'P2025') {
            return NextResponse.json(
                {
                    success: false,
                    error: "Contact not found"
                },
                { status: 404 }
            )
        }

        return NextResponse.json(
            {
                success: false,
                error: "Failed to delete contact"
            },
            { status: 500 }
        )
    }
}
