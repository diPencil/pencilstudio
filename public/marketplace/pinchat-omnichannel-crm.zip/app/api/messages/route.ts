import { Prisma } from "@prisma/client"
import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/db"
import { findWhatsAppChannelAccountId } from "@/lib/channel-accounts"
import { logActivity } from "@/lib/logger"
import { getMetaGraphVersion } from "@/lib/meta"
import { isTokenEncryptionConfigured } from "@/lib/secure-tokens"
import { sendMessengerTextMessage } from "@/lib/channels/messenger"
import { sendInstagramTextMessage } from "@/lib/channels/instagram"
import {
    requireAuthWithScope,
    buildConversationScopeFilter,
    unauthorizedResponse,
    forbiddenResponse,
} from "@/lib/api-auth"

const WHATSAPP_SERVICE_URL = process.env.WHATSAPP_SERVICE_URL || 'http://localhost:3001'

// GET - Fetch messages for a conversation (auth + scope check)
export async function GET(request: NextRequest) {
    try {
        const scope = await requireAuthWithScope(request)

        const { searchParams } = new URL(request.url)
        const conversationId = searchParams.get('conversationId')

        if (!conversationId) {
            return NextResponse.json(
                { success: false, error: "Conversation ID is required" },
                { status: 400 }
            )
        }

        // Verify the user has access to this conversation
        const scopeFilter = buildConversationScopeFilter(scope)
        const conversationAccess = await prisma.conversation.findFirst({
            where: { id: conversationId, ...scopeFilter },
            select: { id: true },
        })

        if (!conversationAccess) {
            return NextResponse.json(
                { success: false, error: "Conversation not found" },
                { status: 404 }
            )
        }

        const messages = await prisma.message.findMany({
            where: { conversationId },
            include: {
                sender: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        username: true
                    }
                },
                quotedMessage: {
                    select: {
                        id: true,
                        content: true,
                        type: true,
                        mediaUrl: true,
                        senderId: true,
                        createdAt: true,
                        direction: true,
                        sender: { select: { name: true, username: true } }
                    }
                }
            },
            orderBy: { createdAt: 'asc' }
        })

        return NextResponse.json({
            success: true,
            messages,
            count: messages.length
        })
    } catch (error) {
        if (error instanceof Error) {
            if (error.message === 'Unauthorized') return unauthorizedResponse()
            if (error.message === 'Forbidden') return forbiddenResponse()
        }
        console.error('Error fetching messages:', error)
        return NextResponse.json(
            { success: false, error: "Failed to fetch messages" },
            { status: 500 }
        )
    }
}

// POST - Send a new message (auth + scope check)
export async function POST(request: NextRequest) {
    try {
        const internalTokenHeader = request.headers.get("x-internal-flow-token")
        const internalTokenEnv = process.env.FLOW_INTERNAL_TOKEN || process.env.JWT_SECRET || "dev-flow-internal-token"

        let scope: any
        if (internalTokenHeader && internalTokenHeader === internalTokenEnv) {
            // System scope for internal bot flows – treated as ADMIN
            scope = {
                userId: null,
                role: "ADMIN",
                branchIds: [],
                whatsappAccountIds: [],
            }
        } else {
            scope = await requireAuthWithScope(request)
        }

        const body = await request.json()

        const { conversationId, phone, content, direction = 'OUTGOING', mediaUrl, whatsappAccountId, replyToId, forwarded } = body;
        const contentToSend = typeof content === 'string' ? content.trim() : String(content ?? '').trim()

        // Require either text content OR media – allow pure media messages
        if (!content && !mediaUrl) {
            return NextResponse.json(
                { success: false, error: "Content or media is required" },
                { status: 400 }
            );
        }

        let targetConversationId = conversationId;
        let createdConversationFromPhone = false
        let phoneNumber = "";
        let accountId = whatsappAccountId || body.accountId;
        let targetConversation: Prisma.ConversationGetPayload<{
          include: {
            contact: {
              include: {
                channelIdentities: true
              }
            }
            channelAccount: true
          }
        }> | null = null;

        // 1. Resolve Conversation and Phone Number
        if (targetConversationId) {
            // Verify user has access to this conversation
            const scopeFilter = buildConversationScopeFilter(scope)
            targetConversation = await prisma.conversation.findFirst({
                where: { id: targetConversationId, ...scopeFilter },
                include: {
                    contact: {
                        include: {
                            channelIdentities: true,
                        },
                    },
                    channelAccount: true,
                },
            })

            if (!targetConversation) {
                return NextResponse.json({ success: false, error: "Conversation not found" }, { status: 404 });
            }
            phoneNumber = targetConversation.contact.phone;

            const conversationChannelType = (targetConversation.channelType || targetConversation.channelAccount?.channelType || (targetConversation.channelAccountId ? "WHATSAPP" : null)) as any

            if (conversationChannelType === "INSTAGRAM" || conversationChannelType === "INSTAGRAM_DM") {
                if (mediaUrl) {
                    return NextResponse.json(
                        { success: false, error: "Instagram DM media sending is not supported yet." },
                        { status: 400 }
                    )
                }

                const instagramChannelAccount = targetConversation.channelAccount
                if (!instagramChannelAccount || instagramChannelAccount.channelType !== "INSTAGRAM") {
                    return NextResponse.json(
                        { success: false, error: "Instagram ChannelAccount is missing." },
                        { status: 400 }
                    )
                }

                const instagramIdentity = targetConversation.contact.channelIdentities.find(
                    (identity) => identity.channelType === "INSTAGRAM" && identity.channelAccountId === instagramChannelAccount.id,
                )

                if (!instagramIdentity || !instagramIdentity.externalProfileId) {
                    return NextResponse.json(
                        { success: false, error: "Instagram recipient identity is missing." },
                        { status: 400 }
                    )
                }

                const encryptedPageAccessToken = (instagramChannelAccount.metadata as Record<string, unknown>)?.pageAccessTokenEncrypted
                if (typeof encryptedPageAccessToken !== "string" || !encryptedPageAccessToken) {
                    return NextResponse.json(
                        { success: false, error: "Instagram encrypted page access token is missing or invalid." },
                        { status: 500 }
                    )
                }

                if (!isTokenEncryptionConfigured()) {
                    return NextResponse.json(
                        { success: false, error: "Server token encryption is not configured. Cannot decrypt Instagram token." },
                        { status: 500 }
                    )
                }

                const resolvedInstagramBusinessAccountId = instagramChannelAccount.instagramBusinessAccountId || instagramChannelAccount.externalAccountId
                if (!resolvedInstagramBusinessAccountId) {
                    return NextResponse.json(
                        { success: false, error: "Instagram Business Account ID is missing from ChannelAccount." },
                        { status: 400 }
                    )
                }

                try {
                    const sendResult = await sendInstagramTextMessage({
                        instagramBusinessAccountId: resolvedInstagramBusinessAccountId,
                        recipientId: instagramIdentity.externalProfileId as string,
                        text: content,
                        encryptedPageAccessToken,
                        graphApiVersion: getMetaGraphVersion(),
                    })

                    const newMessage = await prisma.message.create({
                        data: {
                            conversationId: targetConversation.id,
                            channelType: "INSTAGRAM",
                            channelAccountId: instagramChannelAccount.id,
                            externalMessageId: sendResult.messageId || `outbound-${Date.now()}`,
                            content: content,
                            type: "TEXT",
                            direction: "OUTGOING",
                            status: "SENT",
                            senderId: scope.userId,
                            metadata: {
                                provider: "META",
                                channelType: "INSTAGRAM",
                                instagramBusinessAccountId: resolvedInstagramBusinessAccountId,
                                senderId: resolvedInstagramBusinessAccountId,
                                recipientId: sendResult.recipientId,
                                sentAt: new Date().toISOString(),
                                via: "PINCHAT_CRM",
                            },
                        },
                    })

                    await prisma.conversation.update({
                        where: { id: targetConversation.id },
                        data: {
                            lastMessageAt: new Date(),
                            lastExternalMessageId: sendResult.messageId,
                        },
                    })

                    return NextResponse.json({
                        success: true,
                        data: {
                            ...newMessage,
                            conversation: undefined,
                            user: scope.userId ? { id: scope.userId } : undefined,
                        },
                    })
                } catch (metaError) {
                    console.error("Meta API error while sending Instagram DM:", metaError)
                    return NextResponse.json(
                        { success: false, error: metaError instanceof Error ? metaError.message : "Failed to send Instagram DM via Meta." },
                        { status: 502 }
                    )
                }
            }

            if (conversationChannelType === "FACEBOOK_MESSENGER") {
                if (mediaUrl) {
                    return NextResponse.json(
                        { success: false, error: "Messenger media sending is not supported yet." },
                        { status: 400 }
                    )
                }

                const messengerChannelAccount = targetConversation.channelAccount
                if (!messengerChannelAccount || messengerChannelAccount.channelType !== "FACEBOOK_MESSENGER") {
                    return NextResponse.json(
                        { success: false, error: "Messenger ChannelAccount is missing." },
                        { status: 400 }
                    )
                }

                const messengerIdentity = targetConversation.contact.channelIdentities.find(
                    (identity) => identity.channelType === "FACEBOOK_MESSENGER" && identity.channelAccountId === messengerChannelAccount.id,
                )

                if (!messengerIdentity?.externalProfileId) {
                    return NextResponse.json(
                        { success: false, error: "Messenger recipient identity is missing." },
                        { status: 400 }
                    )
                }

                const messengerMetadata = messengerChannelAccount.metadata as Record<string, unknown> | null
                const encryptedPageAccessToken = typeof messengerMetadata?.pageAccessTokenEncrypted === "string"
                  ? messengerMetadata.pageAccessTokenEncrypted
                  : ""

                if (!isTokenEncryptionConfigured()) {
                    return NextResponse.json(
                        { success: false, error: "TOKEN_ENCRYPTION_SECRET is not configured." },
                        { status: 500 }
                    )
                }

                if (!encryptedPageAccessToken) {
                    return NextResponse.json(
                        { success: false, error: "Messenger encrypted page access token is missing." },
                        { status: 400 }
                    )
                }

                try {
                    const messengerSend = await sendMessengerTextMessage({
                        pageId: messengerChannelAccount.pageId || messengerChannelAccount.externalAccountId || messengerIdentity.externalProfileId,
                        recipientId: messengerIdentity.externalProfileId,
                        text: contentToSend,
                        encryptedPageAccessToken,
                        graphApiVersion: getMetaGraphVersion(),
                    })

                    const sentMessage = await prisma.message.create({
                        data: {
                            conversationId: targetConversationId,
                            senderId: scope.userId,
                            content: contentToSend,
                            type: "TEXT",
                            direction: "OUTGOING",
                            status: "SENT",
                            mediaUrl: null,
                            channelType: "FACEBOOK_MESSENGER",
                            channelAccountId: messengerChannelAccount.id,
                            externalMessageId: messengerSend.messageId || null,
                            metadata: {
                                provider: "META",
                                channelType: "FACEBOOK_MESSENGER",
                                pageId: messengerChannelAccount.pageId || messengerChannelAccount.externalAccountId,
                                recipientId: messengerSend.recipientId,
                                externalMessageId: messengerSend.messageId || null,
                                messagingType: "RESPONSE",
                            } as Prisma.InputJsonValue,
                        }
                    })

                    await logActivity({
                        userId: scope.userId,
                        action: "CREATE",
                        entityType: "Message",
                        entityId: sentMessage.id,
                        newValues: {
                            conversationId: sentMessage.conversationId,
                            direction: sentMessage.direction,
                            channelType: sentMessage.channelType,
                        },
                        description: `Sent ${sentMessage.direction} message`,
                    })

                    await prisma.conversation.update({
                        where: { id: targetConversationId },
                        data: {
                            lastMessageAt: new Date(),
                            lastExternalMessageId: messengerSend.messageId || targetConversation.lastExternalMessageId,
                            isRead: true,
                            lastSyncedAt: new Date(),
                        }
                    })

                    if (scope.userId) {
                        await prisma.user.update({
                            where: { id: scope.userId },
                            data: { lastActivityAt: new Date() }
                        }).catch(() => {})
                    }

                    return NextResponse.json({
                        success: true,
                        data: sentMessage,
                    }, { status: 201 })
                } catch (error) {
                    const errorMessage = error instanceof Error ? error.message : "Failed to send Messenger message"
                    console.error('Messenger Send Error:', errorMessage)
                    return NextResponse.json({ success: false, error: errorMessage }, { status: 502 })
                }
            }

            if (conversationChannelType && conversationChannelType !== "WHATSAPP") {
                return NextResponse.json(
                    { success: false, error: "Sending is not supported for this channel yet." },
                    { status: 400 }
                )
            }
        } else if (phone) {
            // Support sending to a new phone directly
            phoneNumber = phone.replace(/[^0-9]/g, '');

            // Basic validation: Phone should be a reasonable length, not a massive ID
            if (phoneNumber.length < 8 || phoneNumber.length > 15) {
                return NextResponse.json({
                    success: false,
                    error: "Invalid phone number format. If this is a Facebook contact, you cannot send WhatsApp messages to it."
                }, { status: 400 });
            }

            // Find or create contact
            let contact = await prisma.contact.findUnique({ where: { phone: phoneNumber } });
            if (!contact) {
                contact = await prisma.contact.create({
                    data: { name: phoneNumber, phone: phoneNumber, tags: ["new-from-system"] }
                });
            }

            // Find or create active conversation
            let conversation = await prisma.conversation.findFirst({
                where: { contactId: contact.id, status: 'ACTIVE' },
                orderBy: { updatedAt: 'desc' }
            });

            if (!conversation) {
                conversation = await prisma.conversation.create({
                    data: { contactId: contact.id, status: 'ACTIVE', channelType: 'WHATSAPP' }
                });
                createdConversationFromPhone = true
            }
            targetConversationId = conversation.id;
        } else {
            return NextResponse.json({ success: false, error: "Either conversationId or phone is required" }, { status: 400 });
        }

        // For AGENT: if sending, verify the WA account is in their scope
        if (accountId && scope.role === 'AGENT' && !scope.whatsappAccountIds.includes(accountId)) {
            return forbiddenResponse('You do not have access to this WhatsApp account')
        }

        const channelAccountId = await findWhatsAppChannelAccountId(accountId)

        if (createdConversationFromPhone && targetConversationId) {
            await prisma.conversation.update({
                where: { id: targetConversationId },
                data: {
                    channelType: 'WHATSAPP',
                    ...(channelAccountId && { channelAccountId }),
                    ...(accountId && { whatsappAccountId: accountId }),
                }
            }).catch(() => {})
        }

        // 2. Send via WhatsApp Service (if OUTGOING)
        if (direction === 'OUTGOING') {
            if (process.env.NODE_ENV === 'development' || process.env.SKIP_WHATSAPP === 'true') {
                console.log('Development mode: Skipping WhatsApp send');
            } else {
                try {
                    // Extract clean phone/JID for WA
                    let waPhone = phoneNumber;
                    let isGroup = phoneNumber.includes('@g.us') || (phoneNumber.length > 15 && !phoneNumber.includes('@'));

                    if (isGroup) {
                        // Ensure group ID ends with @g.us for the WhatsApp service
                        waPhone = phoneNumber.includes('@g.us') ? phoneNumber : `${phoneNumber}@g.us`;
                    } else {
                        waPhone = phoneNumber.replace(/[^0-9]/g, '');
                        // Double check if it looks like a Facebook ID (very long string of digits)
                        // Note: Only complain if we're sure it's not a WhatsApp group (length > 15 checked above)
                        if (waPhone.length > 20) {
                            throw new Error('This looks like a platform ID that doesn\'t support outgoing WhatsApp messages.');
                        }
                    }

                    if (!accountId) {
                        // For non-admin users, prefer their assigned connected accounts (direct user–account link)
                        if (scope.role !== 'ADMIN' && scope.whatsappAccountIds.length > 0) {
                            const connectedAccount = await prisma.whatsAppAccount.findFirst({
                                where: {
                                    id: { in: scope.whatsappAccountIds },
                                    status: 'CONNECTED',
                                },
                                orderBy: { createdAt: 'desc' },
                            });
                            if (connectedAccount) accountId = connectedAccount.id;
                        }

                        // For SUPERVISOR (and others) with no direct account: prefer account in their branches
                        if (!accountId && scope.role === 'SUPERVISOR' && scope.branchIds.length > 0) {
                            const accountInBranch = await prisma.whatsAppAccount.findFirst({
                                where: {
                                    status: 'CONNECTED',
                                    branchId: { in: scope.branchIds },
                                },
                                orderBy: { createdAt: 'desc' },
                            });
                            if (accountInBranch) accountId = accountInBranch.id;
                        }

                        // Fallback: any connected account (admin, or when no scoped account found)
                        if (!accountId) {
                            const connectedAccount = await prisma.whatsAppAccount.findFirst({
                                where: { status: 'CONNECTED' },
                                orderBy: { createdAt: 'desc' }
                            });
                            if (!connectedAccount) throw new Error('No connected WhatsApp account found');
                            accountId = connectedAccount.id;
                        }
                    }

                    let quotedMessageId: string | null = null
                    if (replyToId) {
                        const quoted = await prisma.message.findUnique({
                            where: { id: replyToId },
                            select: { metadata: true }
                        })
                        const meta = quoted?.metadata as { waMessageId?: string } | null
                        if (meta?.waMessageId) {
                            quotedMessageId = meta.waMessageId
                        } else {
                            console.warn(`[messages] Reply to ${replyToId}: no waMessageId (old message), will send as normal on WhatsApp`)
                        }
                    }

                    const whatsappRes = await fetch(`${WHATSAPP_SERVICE_URL}/send`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            accountId,
                            phoneNumber: waPhone,
                            message: content,
                            mediaUrl,
                            isGroup: isGroup,
                            quotedMessageId: quotedMessageId || undefined
                        })
                    });

                    const whatsappData = await whatsappRes.json();
                    if (!whatsappData.success) {
                        throw new Error(whatsappData.error || 'WhatsApp Service delivery failed');
                    }
                } catch (error: unknown) {
                    const errMsg = error instanceof Error ? error.message : 'Unknown WhatsApp Error';
                    console.error('WhatsApp Send Error:', error);
                    return NextResponse.json({ success: false, error: errMsg }, { status: 502 });
                }
            }
        }

        // 3. Save to Database (Create Message)
        // Type: explicit body.type (AUDIO voice, LOCATION) or infer from mediaUrl
        let messageType = (body.type as string) || 'TEXT'
        if (body.mediaUrl) {
            const url = body.mediaUrl.toLowerCase()
            if (messageType === 'LOCATION') {
                messageType = 'LOCATION'
            } else if (messageType === 'AUDIO' || url.match(/\.(mp3|wav|ogg|m4a|webm)$/)) {
                messageType = 'AUDIO'
            } else if (url.match(/\.(jpg|jpeg|png|gif|webp)$/)) {
                messageType = 'IMAGE'
            } else if (url.match(/\.(mp4|mov|avi)$/)) {
                messageType = 'VIDEO'
            } else {
                messageType = 'DOCUMENT'
            }
        }

        const metadata: Record<string, unknown> = {}
        if (forwarded === true) metadata.forwarded = true

        const message = await prisma.message.create({
            data: {
                conversationId: targetConversationId,
                senderId: scope.userId,
                content: body.content ?? '',
                type: messageType as any,
                direction: direction,
                status: 'SENT',
                mediaUrl: body.mediaUrl || null,
                channelType: 'WHATSAPP',
                ...(channelAccountId && { channelAccountId }),
                whatsappAccountId: accountId || null,
                quotedMessageId: replyToId || null,
                metadata: Object.keys(metadata).length > 0 ? (metadata as Prisma.InputJsonValue) : undefined
            }
        })

        // Log activity
        await logActivity({
            userId: scope.userId,
            action: "CREATE",
            entityType: "Message",
            entityId: message.id,
            newValues: {
                conversationId: message.conversationId,
                direction: message.direction
            },
            description: `Sent ${message.direction} message`
        })

        // 4. Update conversation last message time
        await prisma.conversation.update({
            where: { id: targetConversationId },
            data: {
                lastMessageAt: new Date(),
                isRead: direction === 'OUTGOING'
            }
        })

        // 5. Update sender last activity (for Online/Away status: 5 min without sending = Away)
        if (direction === 'OUTGOING' && scope.userId) {
            await prisma.user.update({
                where: { id: scope.userId },
                data: { lastActivityAt: new Date() }
            }).catch(() => {})
        }

        // When agent sends OUTGOING, dismiss any active bot flow for this conversation (so bot stops until next trigger)
        if (direction === 'OUTGOING' && scope.userId) {
            try {
                const conv = await prisma.conversation.findUnique({
                    where: { id: targetConversationId },
                    select: { contactId: true },
                })
                if (conv?.contactId) {
                    await prisma.flowInteraction.updateMany({
                        where: {
                            contactId: conv.contactId,
                            action: { in: ['TRIGGERED', 'STEP'] },
                        },
                        data: { action: 'DISMISSED', metadata: {} },
                    })
                }
            } catch (_) {
                /* non-blocking */
            }
        }

        // Trigger bot flows for incoming messages
        if (direction === 'INCOMING') {
            try {
                const conversation = await prisma.conversation.findUnique({
                    where: { id: targetConversationId },
                    include: { contact: true }
                })

                if (conversation) {
                    await fetch(`${process.env.NEXTAUTH_URL || 'http://localhost:3003'}/api/bot-flows/execute`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            triggerType: 'new_message',
                            context: {
                                contactId: conversation.contactId,
                                contactName: conversation.contact.name,
                                contactPhone: conversation.contact.phone,
                                message: body.content,
                                conversationId: targetConversationId
                            }
                        })
                    })
                }
            } catch (triggerError) {
                console.error('Error triggering bot flows for message:', triggerError)
            }
        }

        return NextResponse.json({
            success: true,
            data: message
        }, { status: 201 })
    } catch (error: unknown) {
        if (error instanceof Error) {
            if (error.message === 'Unauthorized') return unauthorizedResponse()
            if (error.message === 'Forbidden') return forbiddenResponse()
        }
        console.error('Error creating message:', error)

        const err = error as { code?: string }
        if (err.code === 'P2003') {
            return NextResponse.json(
                { success: false, error: "Conversation not found" },
                { status: 404 }
            )
        }

        const message = error instanceof Error ? error.message : "Failed to create message"
        return NextResponse.json(
            { success: false, error: message },
            { status: 500 }
        )
    }
}
