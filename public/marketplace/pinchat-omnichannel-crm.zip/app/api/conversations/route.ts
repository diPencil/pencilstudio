import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/db"
import { logActivity } from "@/lib/logger"
import {
  requireAuthWithScope,
  buildConversationScopeFilter,
  unauthorizedResponse,
  forbiddenResponse,
} from "@/lib/api-auth"

// GET - Fetch conversations (scoped by role)
export async function GET(request: NextRequest) {
  try {
    const scope = await requireAuthWithScope(request)

    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const isArchived = searchParams.get('archived')
    const isRead = searchParams.get('read')
    const branchId = searchParams.get('branchId')

    // Start with role-based scope filter
    const where: any = { ...buildConversationScopeFilter(scope) }

    if (status) where.status = status
    if (isArchived !== null) where.isArchived = isArchived === 'true'
    if (isRead !== null) where.isRead = isRead === 'true'
    // فرز حسب الفرع (Admins فقط). للمشرفين والـAgents نعتمد على buildConversationScopeFilter
    // لأن فيه منطق مخصص للفروع وحسابات الواتساب بالفعل.
    if (branchId && branchId !== 'all' && scope.role === 'ADMIN') {
      where.AND = where.AND || []
      where.AND.push({ contact: { branchId } })
    }

    const rawConversations = await prisma.conversation.findMany({
      where,
      include: {
        contact: {
          include: {
            branch: { select: { id: true, name: true } },
          },
        },
        assignedTo: {
          select: {
            id: true,
            name: true,
            email: true
          }
        },
        channelAccount: {
          select: {
            id: true,
            name: true,
            channelType: true,
            externalAccountId: true,
            pageId: true,
            instagramBusinessAccountId: true,
          }
        },
        messages: {
          orderBy: { createdAt: 'desc' },
          take: 1
        }
      },
      orderBy: { lastMessageAt: 'desc' }
    })

    // إزالة تكرار المحادثات: نفس الجهة قد تظهر بأكثر من contact (مثلاً رقم المجموعة مع وبدون @g.us)
    const conversationKey = (c: (typeof rawConversations)[0]) => {
      const phone = c.contact?.phone ?? ''
      if (phone.includes('@g.us')) return `group:${phone.split('@')[0]}`
      return `phone:${phone.replace(/\D/g, '')}`
    }
    const seen = new Map<string, (typeof rawConversations)[0]>()
    for (const c of rawConversations) {
      const key = conversationKey(c)
      const existing = seen.get(key)
      if (!existing || new Date(c.lastMessageAt) > new Date(existing.lastMessageAt)) {
        seen.set(key, c)
      }
    }
    const conversations = Array.from(seen.values()).sort(
      (a, b) => new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime()
    )

    return NextResponse.json({
      success: true,
      conversations,
      count: conversations.length
    })
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'Unauthorized') return unauthorizedResponse()
      if (error.message === 'Forbidden') return forbiddenResponse()
    }
    console.error('Error fetching conversations:', error)
    return NextResponse.json(
      { success: false, error: "Failed to fetch conversations" },
      { status: 500 }
    )
  }
}

// POST - Create a new conversation (auth required)
export async function POST(request: NextRequest) {
  try {
    const scope = await requireAuthWithScope(request)
    const body = await request.json()

    let contactId = body.contactId;
    const channelType = body.channelType || (body.phone ? 'WHATSAPP' : undefined)
    const channelAccountId = body.channelAccountId || null

    if (!contactId && body.phone) {
      // Clean phone number
      const phoneNumber = body.phone.replace(/[^0-9]/g, '');

      // Find or create contact
      let contact = await prisma.contact.findUnique({
        where: { phone: phoneNumber }
      });

      if (!contact) {
        contact = await prisma.contact.create({
          data: {
            name: body.phone,
            phone: phoneNumber,
            tags: ["whatsapp-contact"]
          }
        });
      }
      contactId = contact.id;
    }

    if (!contactId) {
      return NextResponse.json(
        { success: false, error: "Contact ID or phone is required" },
        { status: 400 }
      )
    }

    // Non-admin users: verify contact belongs to their branch scope
    if (scope.role !== 'ADMIN') {
      const contact = await prisma.contact.findUnique({
        where: { id: contactId },
        select: { branchId: true },
      })
      if (!contact) {
        return NextResponse.json(
          { success: false, error: "Contact not found" },
          { status: 404 }
        )
      }
      if (contact.branchId && !scope.branchIds.includes(contact.branchId)) {
        return forbiddenResponse('You do not have access to this contact')
      }
    }

    const conversation = await prisma.conversation.create({
      data: {
        contactId: contactId,
        status: body.status || 'ACTIVE',
        assignedToId: scope.userId,
        ...(channelType && { channelType }),
        ...(channelAccountId && { channelAccountId }),
        lastMessageAt: new Date()
      },
      include: {
        contact: true
      }
    })

    return NextResponse.json({
      success: true,
      data: conversation
    }, { status: 201 })
  } catch (error: any) {
    if (error instanceof Error) {
      if (error.message === 'Unauthorized') return unauthorizedResponse()
      if (error.message === 'Forbidden') return forbiddenResponse()
    }
    console.error('Error creating conversation:', error)

    if (error.code === 'P2003') {
      return NextResponse.json(
        { success: false, error: "Contact or user not found" },
        { status: 404 }
      )
    }

    return NextResponse.json(
      { success: false, error: "Failed to create conversation" },
      { status: 500 }
    )
  }
}
