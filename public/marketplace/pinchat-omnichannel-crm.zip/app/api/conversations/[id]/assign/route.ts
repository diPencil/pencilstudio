import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/db"
import { requireAuthWithScope, unauthorizedResponse, forbiddenResponse, buildConversationScopeFilter } from "@/lib/api-auth"

export async function POST(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const scope = await requireAuthWithScope(request)
        const { id } = await params
        const body = await request.json()
        const { agentId } = body

        // Verify conversation access based on user scope
        const scopeFilter = buildConversationScopeFilter(scope)
        const allowed = await prisma.conversation.findFirst({
            where: { id, ...scopeFilter },
            select: { id: true }
        })
        if (!allowed) {
            return NextResponse.json(
                { success: false, error: "Conversation not found" },
                { status: 404 }
            )
        }

        // Authorization: Admin / Supervisor can assign anyone. Agents can only assign to themselves.
        if (scope.role !== "ADMIN" && scope.role !== "SUPERVISOR") {
            if (agentId !== scope.userId) {
                return forbiddenResponse("Only Admin/Supervisor can assign other agents. Agents can only self-assign.")
            }
        }

        const conversation = await prisma.conversation.update({
            where: { id },
            data: {
                assignedToId: agentId || null
            },
            include: {
                contact: {
                    select: { name: true }
                },
                assignedTo: {
                    select: {
                        id: true,
                        name: true,
                        role: true
                    }
                }
            }
        })

        // Notify the assigned agent if someone else assigned them
        if (agentId && agentId !== scope.userId) {
            await prisma.notification.create({
                data: {
                    userId: agentId,
                    title: "Conversation Assigned",
                    message: `You have been assigned a conversation with ${conversation.contact?.name || 'a contact'}.`,
                    type: "INFO",
                    link: `/inbox?id=${id}`
                }
            })
        }

        return NextResponse.json({
            success: true,
            data: conversation
        })
    } catch (error) {
        if (error instanceof Error) {
            if (error.message === "Unauthorized") return unauthorizedResponse()
            if (error.message === "Forbidden") return forbiddenResponse()
        }
        return NextResponse.json(
            { success: false, error: "Failed to assign agent" },
            { status: 500 }
        )
    }
}
