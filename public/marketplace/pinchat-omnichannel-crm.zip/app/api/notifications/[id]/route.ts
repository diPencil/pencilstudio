import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/db"
import { requireAuthWithScope, unauthorizedResponse, forbiddenResponse } from "@/lib/api-auth"

export async function DELETE(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> } // Standard Next.js 15 async params
) {
    try {
        const scope = await requireAuthWithScope(request)
        const { id } = await params
        
        const notification = await prisma.notification.findUnique({
            where: { id }
        })

        if (!notification) {
            return NextResponse.json({ success: false, error: "Notification not found" }, { status: 404 })
        }

        if (notification.userId !== scope.userId) {
            return forbiddenResponse("You do not have permission to delete this notification.")
        }

        await prisma.notification.delete({
            where: { id }
        })

        return NextResponse.json({
            success: true,
            message: "Notification deleted"
        })
    } catch (error) {
        if (error instanceof Error && error.message === 'Unauthorized') return unauthorizedResponse()
        if (error instanceof Error && error.message === 'Forbidden') return forbiddenResponse()
        console.error('Error deleting notification:', error)
        return NextResponse.json(
            { success: false, error: "Failed to delete notification" },
            { status: 500 }
        )
    }
}
