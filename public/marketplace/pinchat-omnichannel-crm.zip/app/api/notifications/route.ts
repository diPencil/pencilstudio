import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { logActivity } from '@/lib/logger'
import { requireAuthWithScope, unauthorizedResponse, forbiddenResponse } from '@/lib/api-auth'

// GET - Fetch notifications for the authenticated user
export async function GET(request: NextRequest) {
    try {
        const scope = await requireAuthWithScope(request)

        const notifications = await prisma.notification.findMany({
            where: {
                userId: scope.userId
            },
            orderBy: {
                createdAt: 'desc'
            },
            take: 50 // Limit to last 50 notifications
        })

        return NextResponse.json({
            success: true,
            notifications,
            unreadCount: notifications.filter((n: any) => !n.isRead).length
        })
    } catch (error) {
        if (error instanceof Error && error.message === 'Unauthorized') return unauthorizedResponse()
        console.error('Error fetching notifications:', error)
        return NextResponse.json(
            { success: false, error: 'Failed to fetch notifications' },
            { status: 500 }
        )
    }
}

// POST - Create new notification
export async function POST(request: NextRequest) {
    try {
        const scope = await requireAuthWithScope(request)
        const body = await request.json()
        const { title, message, type = 'INFO', userId, link } = body

        if (!title || !message) {
            return NextResponse.json(
                { success: false, error: 'Title and message are required' },
                { status: 400 }
            )
        }

        // Authorization: Only Admin/Supervisor can create notifications for other users
        const targetUserId = userId || scope.userId
        if (targetUserId !== scope.userId && scope.role !== 'ADMIN' && scope.role !== 'SUPERVISOR') {
            return forbiddenResponse("Agents can only create notifications for themselves.")
        }

        const notification = await prisma.notification.create({
            data: {
                title,
                message,
                type,
                userId: targetUserId,
                link: link || null
            }
        })

        await logActivity({
            action: 'CREATE',
            entityType: 'Notification',
            entityId: notification.id,
            description: `Created notification: ${title}`
        })

        return NextResponse.json({
            success: true,
            notification
        })
    } catch (error) {
        if (error instanceof Error && error.message === 'Unauthorized') return unauthorizedResponse()
        if (error instanceof Error && error.message === 'Forbidden') return forbiddenResponse()
        console.error('Error creating notification:', error)
        return NextResponse.json(
            { success: false, error: 'Failed to create notification' },
            { status: 500 }
        )
    }
}

// PUT - Mark all as read for authenticated user
export async function PUT(request: NextRequest) {
    try {
        const scope = await requireAuthWithScope(request)

        const result = await prisma.notification.updateMany({
            where: {
                userId: scope.userId,
                isRead: false
            },
            data: {
                isRead: true
            }
        })

        await logActivity({
            action: 'UPDATE',
            entityType: 'Notification',
            description: `Marked ${result.count} notifications as read for user ${scope.userId}`
        })

        return NextResponse.json({
            success: true,
            message: `Marked ${result.count} notifications as read`
        })
    } catch (error) {
        if (error instanceof Error && error.message === 'Unauthorized') return unauthorizedResponse()
        console.error('Error marking notifications as read:', error)
        return NextResponse.json(
            { success: false, error: 'Failed to mark notifications as read' },
            { status: 500 }
        )
    }
}

// DELETE - Clear all notifications for authenticated user
export async function DELETE(request: NextRequest) {
    try {
        const scope = await requireAuthWithScope(request)

        const result = await prisma.notification.deleteMany({
            where: {
                userId: scope.userId
            }
        })

        await logActivity({
            action: 'DELETE',
            entityType: 'Notification',
            description: `Deleted ${result.count} notifications for user ${scope.userId}`
        })

        return NextResponse.json({
            success: true,
            message: `Deleted ${result.count} notifications`
        })
    } catch (error) {
        if (error instanceof Error && error.message === 'Unauthorized') return unauthorizedResponse()
        console.error('Error deleting notifications:', error)
        return NextResponse.json(
            { success: false, error: 'Failed to delete notifications' },
            { status: 500 }
        )
    }
}
