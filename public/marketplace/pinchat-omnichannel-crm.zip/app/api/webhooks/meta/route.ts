import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/db"
import { findMetaFacebookChannelAccount } from "@/lib/channel-accounts"
import { detectMetaChannel, safeMetaWebhookLog, verifyMetaSignature, verifyMetaWebhookToken } from "@/lib/meta"
import {
  buildMessengerFallbackContactName,
  isMessengerWebhookEvent,
  normalizeMessengerMessageEvent,
} from "@/lib/channels/messenger"
import {
  buildInstagramFallbackContactName,
  isInstagramWebhookEvent,
  normalizeInstagramMessageEvent,
} from "@/lib/channels/instagram"

export async function GET(request: NextRequest) {
  const url = new URL(request.url)
  const mode = url.searchParams.get("hub.mode")
  const verifyToken = url.searchParams.get("hub.verify_token")
  const challenge = url.searchParams.get("hub.challenge")

  if (mode === "subscribe" && verifyMetaWebhookToken(verifyToken) && challenge) {
    return new NextResponse(challenge, {
      status: 200,
      headers: { "content-type": "text/plain; charset=utf-8" },
    })
  }

  return new NextResponse("Forbidden", {
    status: 403,
    headers: { "content-type": "text/plain; charset=utf-8" },
  })
}

export async function POST(request: NextRequest) {
  const rawBody = await request.text()
  const signatureHeader = request.headers.get("x-hub-signature-256") || request.headers.get("x-hub-signature")

  if (!verifyMetaSignature(rawBody, signatureHeader)) {
    return NextResponse.json({ success: false, error: "Invalid Meta signature" }, { status: 403 })
  }

  let payload: unknown = null
  try {
    payload = rawBody ? JSON.parse(rawBody) : null
  } catch {
    payload = null
  }

  const channel = detectMetaChannel(payload)
  const logData = safeMetaWebhookLog(payload)

  // Branch 1: Facebook Messenger Webhook
  if (isMessengerWebhookEvent(payload)) {
    const entries = Array.isArray((payload as { entry?: unknown[] } | null)?.entry)
      ? ((payload as { entry: unknown[] }).entry)
      : []

    let processedCount = 0
    let skippedCount = 0

    for (const entry of entries) {
      if (!entry || typeof entry !== "object" || Array.isArray(entry)) continue
      const messaging = Array.isArray((entry as { messaging?: unknown[] }).messaging)
        ? ((entry as { messaging: unknown[] }).messaging)
        : []

      for (const messagingEvent of messaging) {
        const normalized = normalizeMessengerMessageEvent(messagingEvent)
        if (!normalized) {
          continue
        }

        const channelAccount = await findMetaFacebookChannelAccountByPageId(normalized.pageId)
        if (!channelAccount) {
          skippedCount += 1
          console.warn("[Meta Webhook] No connected ChannelAccount found for pageId", {
            pageId: normalized.pageId,
          })
          continue
        }

        await persistMessengerWebhookEvent(normalized, channelAccount.id, channelAccount.branchId)
        processedCount += 1
      }
    }

    console.info("[Meta Webhook] processed Messenger events", {
      processedCount,
      skippedCount,
      channel,
    })

    return NextResponse.json({ success: true })
  }

  // Branch 2: Instagram DM Webhook
  if (isInstagramWebhookEvent(payload)) {
    const entries = Array.isArray((payload as { entry?: unknown[] } | null)?.entry)
      ? ((payload as { entry: unknown[] }).entry)
      : []

    let processedCount = 0
    let skippedCount = 0

    for (const entry of entries) {
      if (!entry || typeof entry !== "object" || Array.isArray(entry)) continue
      const messaging = Array.isArray((entry as { messaging?: unknown[] }).messaging)
        ? ((entry as { messaging: unknown[] }).messaging)
        : []

      for (const messagingEvent of messaging) {
        const normalized = normalizeInstagramMessageEvent(messagingEvent)
        if (!normalized) {
          continue
        }

        const channelAccount = await findMetaInstagramChannelAccountByBusinessId(normalized.instagramBusinessAccountId)
        if (!channelAccount) {
          skippedCount += 1
          console.warn("[Meta Webhook] No connected ChannelAccount found for instagramBusinessAccountId", {
            instagramBusinessAccountId: normalized.instagramBusinessAccountId,
          })
          continue
        }

        await persistInstagramWebhookEvent(normalized, channelAccount.id, channelAccount.branchId)
        processedCount += 1
      }
    }

    console.info("[Meta Webhook] processed Instagram events", {
      processedCount,
      skippedCount,
      channel,
    })

    return NextResponse.json({ success: true })
  }

  console.info("[Meta Webhook] received other event", {
    channel,
    ...logData,
  })

  return NextResponse.json({ success: true })
}

async function findMetaFacebookChannelAccountByPageId(pageId: string) {
  return prisma.channelAccount.findFirst({
    where: {
      channelType: "FACEBOOK_MESSENGER",
      provider: "META",
      pageId,
    },
    select: {
      id: true,
      branchId: true,
    },
  })
}

async function findMetaInstagramChannelAccountByBusinessId(instagramBusinessAccountId: string) {
  return prisma.channelAccount.findFirst({
    where: {
      channelType: "INSTAGRAM",
      provider: "META",
      OR: [
        { instagramBusinessAccountId },
        { externalAccountId: instagramBusinessAccountId },
      ],
    },
    select: {
      id: true,
      branchId: true,
    },
  })
}

async function persistMessengerWebhookEvent(
  normalized: ReturnType<typeof normalizeMessengerMessageEvent> extends infer Result ? Result : never,
  channelAccountId: string,
  branchId: string | null,
) {
  if (!normalized) return

  const existingMessage = await prisma.message.findFirst({
    where: {
      channelType: "FACEBOOK_MESSENGER",
      channelAccountId,
      externalMessageId: normalized.externalMessageId,
    },
    select: { id: true },
  })

  if (existingMessage) {
    return
  }

  const contactIdentity = await prisma.contactChannelIdentity.findFirst({
    where: {
      channelType: "FACEBOOK_MESSENGER",
      channelAccountId,
      externalProfileId: normalized.senderId,
    },
    include: {
      contact: true,
    },
  })

  let contact = contactIdentity?.contact ?? null

  if (!contact) {
    contact = await prisma.contact.create({
      data: {
        name: buildMessengerFallbackContactName(normalized.senderId),
        phone: `messenger-${normalized.senderId}`,
        externalId: normalized.senderId,
        branchId: branchId || undefined,
      },
    })

    await prisma.contactChannelIdentity.create({
      data: {
        contactId: contact.id,
        channelType: "FACEBOOK_MESSENGER",
        channelAccountId,
        externalProfileId: normalized.senderId,
        displayName: contact.name,
        profilePayload: {
          channelType: "FACEBOOK_MESSENGER",
          provider: "META",
          pageId: normalized.pageId,
          senderId: normalized.senderId,
        },
      },
    })
  } else {
    if (!contact.externalId) {
      contact = await prisma.contact.update({
        where: { id: contact.id },
        data: { externalId: normalized.senderId },
      })
    }

    if (!contact.branchId && branchId) {
      contact = await prisma.contact.update({
        where: { id: contact.id },
        data: { branchId },
      })
    }

    if (!contactIdentity) {
      await prisma.contactChannelIdentity.create({
        data: {
          contactId: contact.id,
          channelType: "FACEBOOK_MESSENGER",
          channelAccountId,
          externalProfileId: normalized.senderId,
          displayName: contact.name,
          profilePayload: {
            channelType: "FACEBOOK_MESSENGER",
            provider: "META",
            pageId: normalized.pageId,
            senderId: normalized.senderId,
          },
        },
      })
    }
  }

  const conversation = await findOrCreateMessengerConversation({
    contactId: contact.id,
    channelAccountId,
    externalConversationId: normalized.externalConversationId,
    threadKey: normalized.threadKey,
    lastMessageAt: normalized.timestamp,
  })

  const content = normalized.text.trim() || `[${normalized.metadata.messageType || "MESSAGE"}]`
  const messageType = normalized.metadata.messageType === "IMAGE"
    ? "IMAGE"
    : normalized.metadata.messageType === "VIDEO"
      ? "VIDEO"
      : normalized.metadata.messageType === "AUDIO"
        ? "AUDIO"
        : normalized.metadata.messageType === "DOCUMENT"
          ? "DOCUMENT"
          : normalized.metadata.messageType === "LOCATION"
            ? "LOCATION"
            : "TEXT"

  await prisma.message.create({
    data: {
      conversationId: conversation.id,
      channelType: "FACEBOOK_MESSENGER",
      channelAccountId,
      externalMessageId: normalized.externalMessageId,
      externalParentId: normalized.externalConversationId,
      content,
      type: messageType,
      direction: "INCOMING",
      status: "DELIVERED",
      metadata: {
        provider: normalized.provider,
        channelType: normalized.channelType,
        pageId: normalized.pageId,
        senderId: normalized.senderId,
        recipientId: normalized.recipientId,
        externalConversationId: normalized.externalConversationId,
        externalMessageId: normalized.externalMessageId,
        attachments: normalized.attachments,
        attachmentCount: normalized.attachments.length,
        timestamp: normalized.timestamp.toISOString(),
      },
    },
  })

  // TODO: Implement Messenger media download and storage in a later phase.
}

async function findOrCreateMessengerConversation(params: {
  contactId: string
  channelAccountId: string
  externalConversationId: string
  threadKey: string
  lastMessageAt: Date
}) {
  const existing = await prisma.conversation.findFirst({
    where: {
      channelType: "FACEBOOK_MESSENGER",
      channelAccountId: params.channelAccountId,
      externalConversationId: params.externalConversationId,
    },
    select: { id: true },
  })

  if (existing) {
    await prisma.conversation.update({
      where: { id: existing.id },
      data: {
        lastMessageAt: params.lastMessageAt,
        lastExternalMessageId: params.threadKey,
        lastSyncedAt: params.lastMessageAt,
        isRead: false,
      },
    })

    return existing
  }

  return prisma.conversation.create({
    data: {
      contactId: params.contactId,
      channelType: "FACEBOOK_MESSENGER",
      channelAccountId: params.channelAccountId,
      externalConversationId: params.externalConversationId,
      externalThreadId: params.threadKey,
      lastExternalMessageId: params.threadKey,
      lastMessageAt: params.lastMessageAt,
      lastSyncedAt: params.lastMessageAt,
      status: "ACTIVE",
      isRead: false,
    },
    select: { id: true },
  })
}

async function persistInstagramWebhookEvent(
  normalized: ReturnType<typeof normalizeInstagramMessageEvent> extends infer Result ? Result : never,
  channelAccountId: string,
  branchId: string | null,
) {
  if (!normalized) return

  const existingMessage = await prisma.message.findFirst({
    where: {
      channelType: "INSTAGRAM",
      channelAccountId,
      externalMessageId: normalized.externalMessageId,
    },
    select: { id: true },
  })

  if (existingMessage) {
    return
  }

  const contactIdentity = await prisma.contactChannelIdentity.findFirst({
    where: {
      channelType: "INSTAGRAM",
      channelAccountId,
      externalProfileId: normalized.senderId,
    },
    include: {
      contact: true,
    },
  })

  let contact = contactIdentity?.contact ?? null

  if (!contact) {
    contact = await prisma.contact.create({
      data: {
        name: buildInstagramFallbackContactName(normalized.senderId),
        phone: `instagram-${normalized.senderId}`,
        externalId: normalized.senderId,
        branchId: branchId || undefined,
      },
    })

    await prisma.contactChannelIdentity.create({
      data: {
        contactId: contact.id,
        channelType: "INSTAGRAM",
        channelAccountId,
        externalProfileId: normalized.senderId,
        displayName: contact.name,
        profilePayload: {
          channelType: "INSTAGRAM",
          provider: "META",
          instagramBusinessAccountId: normalized.instagramBusinessAccountId,
          senderId: normalized.senderId,
        },
      },
    })
  } else {
    if (!contact.externalId) {
      contact = await prisma.contact.update({
        where: { id: contact.id },
        data: { externalId: normalized.senderId },
      })
    }

    if (!contact.branchId && branchId) {
      contact = await prisma.contact.update({
        where: { id: contact.id },
        data: { branchId },
      })
    }

    if (!contactIdentity) {
      await prisma.contactChannelIdentity.create({
        data: {
          contactId: contact.id,
          channelType: "INSTAGRAM",
          channelAccountId,
          externalProfileId: normalized.senderId,
          displayName: contact.name,
          profilePayload: {
            channelType: "INSTAGRAM",
            provider: "META",
            instagramBusinessAccountId: normalized.instagramBusinessAccountId,
            senderId: normalized.senderId,
          },
        },
      })
    }
  }

  const conversation = await findOrCreateInstagramConversation({
    contactId: contact.id,
    channelAccountId,
    externalConversationId: normalized.externalConversationId,
    threadKey: normalized.threadKey,
    lastMessageAt: normalized.timestamp,
  })

  const content = normalized.text.trim() || `[${normalized.metadata.messageType || "MESSAGE"}]`
  const messageType = normalized.metadata.messageType === "IMAGE"
    ? "IMAGE"
    : normalized.metadata.messageType === "VIDEO"
      ? "VIDEO"
      : normalized.metadata.messageType === "AUDIO"
        ? "AUDIO"
        : normalized.metadata.messageType === "DOCUMENT"
          ? "DOCUMENT"
          : normalized.metadata.messageType === "LOCATION"
            ? "LOCATION"
            : "TEXT"

  await prisma.message.create({
    data: {
      conversationId: conversation.id,
      channelType: "INSTAGRAM",
      channelAccountId,
      externalMessageId: normalized.externalMessageId,
      externalParentId: normalized.externalConversationId,
      content,
      type: messageType,
      direction: "INCOMING",
      status: "DELIVERED",
      metadata: {
        provider: normalized.provider,
        channelType: normalized.channelType,
        instagramBusinessAccountId: normalized.instagramBusinessAccountId,
        senderId: normalized.senderId,
        recipientId: normalized.recipientId,
        externalConversationId: normalized.externalConversationId,
        externalMessageId: normalized.externalMessageId,
        attachments: normalized.attachments,
        attachmentCount: normalized.attachments.length,
        timestamp: normalized.timestamp.toISOString(),
      },
    },
  })
}

async function findOrCreateInstagramConversation(params: {
  contactId: string
  channelAccountId: string
  externalConversationId: string
  threadKey: string
  lastMessageAt: Date
}) {
  const existing = await prisma.conversation.findFirst({
    where: {
      channelType: "INSTAGRAM",
      channelAccountId: params.channelAccountId,
      externalConversationId: params.externalConversationId,
    },
    select: { id: true },
  })

  if (existing) {
    await prisma.conversation.update({
      where: { id: existing.id },
      data: {
        lastMessageAt: params.lastMessageAt,
        lastExternalMessageId: params.threadKey,
        lastSyncedAt: params.lastMessageAt,
        isRead: false,
      },
    })

    return existing
  }

  return prisma.conversation.create({
    data: {
      contactId: params.contactId,
      channelType: "INSTAGRAM",
      channelAccountId: params.channelAccountId,
      externalConversationId: params.externalConversationId,
      externalThreadId: params.threadKey,
      lastExternalMessageId: params.threadKey,
      lastMessageAt: params.lastMessageAt,
      lastSyncedAt: params.lastMessageAt,
      status: "ACTIVE",
      isRead: false,
    },
    select: { id: true },
  })
}
