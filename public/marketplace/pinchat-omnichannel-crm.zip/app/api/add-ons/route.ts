import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { logActivity } from '@/lib/logger'
import { requireAuthWithScope, requireRoleWithScope, unauthorizedResponse, forbiddenResponse } from '@/lib/api-auth'
import { getDefaultEnabledAddOnIds, getEnabledAddOnIds, getInvalidAddOnIds, getComingSoonAddOnIds, filterOutComingSoonAddOns, type AddOnId } from '@/lib/add-ons'

async function getOrCreateSettingsRecord() {
  let settings = await prisma.settings.findFirst()

  if (!settings) {
    settings = await prisma.settings.create({
      data: {
        enabledAddOns: getDefaultEnabledAddOnIds(),
      },
    })
  } else if (!settings.enabledAddOns || !Array.isArray(settings.enabledAddOns) || settings.enabledAddOns.length === 0) {
    // Ensure enabledAddOns is initialized if null, not array, or empty
    settings = await prisma.settings.update({
      where: { id: settings.id },
      data: {
        enabledAddOns: getDefaultEnabledAddOnIds(),
      },
    })
  }

  return settings
}

export async function GET(request: NextRequest) {
  try {
    await requireAuthWithScope(request)

    const settings = await getOrCreateSettingsRecord()
    const enabledAddOns = getEnabledAddOnIds(settings.enabledAddOns)
    
    // Filter out any coming_soon add-ons that may exist in storage
    const safeAddOns = filterOutComingSoonAddOns(Array.from(enabledAddOns))

    return NextResponse.json({
      success: true,
      enabledAddOns: safeAddOns,
    })
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'Unauthorized') return unauthorizedResponse()
      if (error.message === 'Forbidden') return forbiddenResponse()
    }

    console.error('Error fetching add-ons settings:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch add-ons settings' },
      { status: 500 }
    )
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const scope = await requireRoleWithScope(request, ['ADMIN'])
    const body = await request.json()
    const requestedAddOns = body?.enabledAddOns

    if (!Array.isArray(requestedAddOns)) {
      return NextResponse.json(
        { success: false, error: 'enabledAddOns must be an array' },
        { status: 400 }
      )
    }

    const invalidAddOnIds = getInvalidAddOnIds(requestedAddOns)
    if (invalidAddOnIds.length > 0) {
      return NextResponse.json(
        {
          success: false,
          error: `Unknown add-on IDs: ${invalidAddOnIds.join(', ')}`,
        },
        { status: 400 }
      )
    }

    const comingSoonAddOns = getComingSoonAddOnIds(requestedAddOns)
    if (comingSoonAddOns.length > 0) {
      return NextResponse.json(
        {
          success: false,
          error: `Cannot enable coming soon add-ons: ${comingSoonAddOns.join(', ')}`,
        },
        { status: 400 }
      )
    }

    const settings = await getOrCreateSettingsRecord()
    const enabledAddOns = Array.from(new Set(getEnabledAddOnIds(requestedAddOns)))

    const updatedSettings = await prisma.settings.update({
      where: { id: settings.id },
      data: {
        enabledAddOns,
      },
    })

    await logActivity({
      userId: scope.userId,
      action: 'UPDATE',
      entityType: 'Settings',
      entityId: updatedSettings.id,
      description: 'Updated add-ons settings',
      newValues: {
        enabledAddOns,
      },
    })

    return NextResponse.json({
      success: true,
      enabledAddOns,
    })
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'Unauthorized') return unauthorizedResponse()
      if (error.message === 'Forbidden') return forbiddenResponse('Only admins can update add-ons')
    }

    console.error('Error updating add-ons settings:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to update add-ons settings' },
      { status: 500 }
    )
  }
}