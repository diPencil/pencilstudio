import { NextRequest, NextResponse } from "next/server"
import { requireAuthWithScope, unauthorizedResponse, forbiddenResponse } from "@/lib/api-auth"
import { isTokenEncryptionConfigured } from "@/lib/secure-tokens"

export async function GET(request: NextRequest) {
  try {
    // Basic auth check for safety. Admin scoping or workspace scope applies.
    await requireAuthWithScope(request)

    const metaAppIdConfigured = Boolean(process.env.META_APP_ID)
    const metaAppSecretConfigured = Boolean(process.env.META_APP_SECRET)
    const metaVerifyTokenConfigured = Boolean(process.env.META_VERIFY_TOKEN)
    const metaRedirectUriConfigured = Boolean(process.env.META_REDIRECT_URI)
    const metaGraphVersionConfigured = Boolean(process.env.META_GRAPH_API_VERSION)
    const tokenEncryptionConfigured = isTokenEncryptionConfigured()

    const readyForOAuth =
      metaAppIdConfigured &&
      metaAppSecretConfigured &&
      metaRedirectUriConfigured &&
      metaGraphVersionConfigured &&
      tokenEncryptionConfigured

    const readyForWebhookVerification = metaVerifyTokenConfigured

    return NextResponse.json({
      metaAppIdConfigured,
      metaAppSecretConfigured,
      metaVerifyTokenConfigured,
      metaRedirectUriConfigured,
      metaGraphVersionConfigured,
      tokenEncryptionConfigured,
      webhookUrl: "/api/webhooks/meta",
      oauthStartUrl: "/api/meta/oauth/start",
      oauthCallbackUrl: "/api/meta/oauth/callback",
      readyForOAuth,
      readyForWebhookVerification,
    })
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === "Unauthorized") return unauthorizedResponse()
      if (error.message === "Forbidden") return forbiddenResponse()
    }
    console.error("Error fetching Meta readiness:", error)
    return NextResponse.json(
      { success: false, error: "Failed to fetch Meta readiness" },
      { status: 500 },
    )
  }
}
