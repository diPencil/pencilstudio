import { NextRequest, NextResponse } from "next/server"
import { upsertMetaFacebookChannelAccount, upsertMetaInstagramChannelAccount } from "@/lib/channel-accounts"
import { encryptSecret, isTokenEncryptionConfigured } from "@/lib/secure-tokens"

const META_OAUTH_STATE_COOKIE = "pinchat_meta_oauth_state"

function getRequiredMetaOAuthConfig() {
  const appId = process.env.META_APP_ID || ""
  const appSecret = process.env.META_APP_SECRET || ""
  const redirectUri = process.env.META_REDIRECT_URI || ""
  const graphVersion = process.env.META_GRAPH_API_VERSION || ""
  const tokenEncryptionSecret = process.env.TOKEN_ENCRYPTION_SECRET || ""

  const missingEnv = [
    !appId ? "META_APP_ID" : null,
    !appSecret ? "META_APP_SECRET" : null,
    !redirectUri ? "META_REDIRECT_URI" : null,
    !graphVersion ? "META_GRAPH_API_VERSION" : null,
    !tokenEncryptionSecret ? "TOKEN_ENCRYPTION_SECRET" : null,
  ].filter((value): value is string => Boolean(value))

  return {
    appId,
    appSecret,
    redirectUri,
    graphVersion,
    missingEnv,
  }
}

function getMetaGraphBaseUrl(graphVersion: string) {
  return `https://graph.facebook.com/${graphVersion}`
}

function isJsonRequest(request: NextRequest) {
  const accept = request.headers.get("accept") || ""
  return request.headers.get("x-requested-with") === "XMLHttpRequest" || accept.includes("application/json")
}

function clearStateCookie(response: NextResponse, request: NextRequest) {
  response.cookies.set(META_OAUTH_STATE_COOKIE, "", {
    httpOnly: true,
    sameSite: "lax",
    secure: request.nextUrl.protocol === "https:",
    path: "/",
    maxAge: 0,
  })
}

async function exchangeCodeForAccessToken(code: string, config: { appId: string; appSecret: string; redirectUri: string; graphVersion: string }) {
  const tokenUrl = new URL(`${getMetaGraphBaseUrl(config.graphVersion)}/oauth/access_token`)
  tokenUrl.searchParams.set("client_id", config.appId)
  tokenUrl.searchParams.set("client_secret", config.appSecret)
  tokenUrl.searchParams.set("redirect_uri", config.redirectUri)
  tokenUrl.searchParams.set("code", code)

  const response = await fetch(tokenUrl.toString(), { cache: "no-store" })
  const payload = await response.json().catch(() => null)

  if (!response.ok || !payload || typeof payload.access_token !== "string") {
    throw new Error("Failed to exchange Meta OAuth code")
  }

  return payload.access_token as string
}

async function fetchMetaPages(userAccessToken: string, graphVersion: string) {
  const pagesUrl = new URL(`${getMetaGraphBaseUrl(graphVersion)}/me/accounts`)
  pagesUrl.searchParams.set("fields", "id,name,category,tasks,category_list,access_token,instagram_business_account{id,username,name,profile_picture_url}")
  pagesUrl.searchParams.set("limit", "100")
  pagesUrl.searchParams.set("access_token", userAccessToken)

  const response = await fetch(pagesUrl.toString(), { cache: "no-store" })
  const payload = await response.json().catch(() => null)

  if (!response.ok || !payload || !Array.isArray(payload.data)) {
    throw new Error("Failed to fetch Meta pages")
  }

  return payload.data as Array<{
    id: string
    name: string
    category?: string | null
    tasks?: string[]
    category_list?: Array<{ id?: string; name?: string }>
    access_token?: string | null
    instagram_business_account?: {
      id: string
      username?: string | null
      name?: string | null
      profile_picture_url?: string | null
    } | null
  }>
}

function buildSafePageList(pages: Array<{
  id: string
  name: string
  category?: string | null
  tasks?: string[]
  category_list?: Array<{ id?: string; name?: string }>
}>) {
  return pages.map((page) => ({
    id: page.id,
    name: page.name,
    category: page.category || null,
    tasks: Array.isArray(page.tasks) ? page.tasks : [],
    categoryList: Array.isArray(page.category_list) ? page.category_list : [],
  }))
}

export async function GET(request: NextRequest) {
  const url = new URL(request.url)
  const code = url.searchParams.get("code")
  const state = url.searchParams.get("state")
  const error = url.searchParams.get("error")
  const errorDescription = url.searchParams.get("error_description")
  const wantsJson = isJsonRequest(request)
  const config = getRequiredMetaOAuthConfig()

  if (error) {
    const message = errorDescription || error || "Meta OAuth was cancelled or failed."
    return wantsJson
      ? NextResponse.json({ success: false, message }, { status: 400 })
      : NextResponse.redirect(new URL(`/accounts?meta_oauth=error`, request.url))
  }

  if (config.missingEnv.length > 0) {
    const response = wantsJson
      ? NextResponse.json(
          {
            success: false,
            message: "Meta credentials are not configured yet.",
            missingEnv: config.missingEnv,
          },
          { status: 501 },
        )
      : NextResponse.redirect(new URL("/accounts?meta_oauth=missing_env", request.url))
    clearStateCookie(response, request)
    return response
  }

  if (!code || !state) {
    return NextResponse.json(
      { success: false, message: "Missing OAuth code or state." },
      { status: 400 },
    )
  }

  const expectedState = request.cookies.get(META_OAUTH_STATE_COOKIE)?.value
  if (!expectedState || expectedState !== state) {
    return NextResponse.json(
      { success: false, message: "Invalid OAuth state." },
      { status: 400 },
    )
  }

  if (!isTokenEncryptionConfigured()) {
    const response = wantsJson
      ? NextResponse.json(
          {
            success: false,
            message: "Token encryption is not configured. Add TOKEN_ENCRYPTION_SECRET before connecting Meta channels.",
            missingEnv: ["TOKEN_ENCRYPTION_SECRET"],
          },
          { status: 501 },
        )
      : NextResponse.redirect(new URL("/accounts?meta_oauth=token_encryption_required", request.url))
    clearStateCookie(response, request)
    return response
  }

  try {
    const userAccessToken = await exchangeCodeForAccessToken(code, config)
    const pages = await fetchMetaPages(userAccessToken, config.graphVersion)
    const safePages = buildSafePageList(pages)

    if (safePages.length === 0) {
      const response = NextResponse.json(
        { success: false, message: "No Facebook Pages were returned for this Meta account." },
        { status: 400 },
      )
      clearStateCookie(response, request)
      return response
    }

    // TODO: Add page selection UI for accounts with multiple Facebook Pages.
    const page = pages[0]
    const safePage = safePages[0]
    const pageAccessToken = typeof page.access_token === "string" ? page.access_token : ""

    if (!pageAccessToken) {
      throw new Error("Meta did not return a Facebook Page access token.")
    }

    const encryptedPageAccessToken = encryptSecret(pageAccessToken)
    await upsertMetaFacebookChannelAccount(page, {
      oauthSource: "meta-oauth",
      connectionState: "CONNECTED",
      connectedAt: new Date().toISOString(),
      pageName: safePage.name,
      pageCategory: safePage.category,
      pageTasks: safePage.tasks,
      pageCategoryList: safePage.categoryList,
      scopes: ["pages_show_list", "pages_manage_metadata", "pages_messaging"],
      pageAccessTokenEncrypted: encryptedPageAccessToken,
      tokenStoredAt: new Date().toISOString(),
      tokenType: "page_access_token",
    })

    console.log(`[Meta OAuth] Successfully connected Facebook Page: ${safePage.name} (${page.id})`)

    if (page.instagram_business_account) {
      await upsertMetaInstagramChannelAccount({
        instagramAccountId: page.instagram_business_account.id,
        name: page.instagram_business_account.name || page.instagram_business_account.username || "Instagram Account",
        pageId: page.id,
        instagramUsername: page.instagram_business_account.username || null,
        pageAccessTokenEncrypted: encryptedPageAccessToken,
      }).then(() => {
        console.log(`[Meta OAuth] Successfully linked Instagram Professional Account: ${page.instagram_business_account?.username || page.instagram_business_account?.name} (${page.instagram_business_account?.id})`)
      }).catch((err) => {
        console.error("[Meta OAuth] Failed to persist linked Instagram Business Account:", err)
      })
    }

    const response = NextResponse.redirect(new URL("/accounts?meta_oauth=connected", request.url))
    clearStateCookie(response, request)
    return response
  } catch (error) {
    console.error("Error completing Meta OAuth callback:", error instanceof Error ? error.message : error)
    return NextResponse.json(
      { success: false, message: "Failed to complete Meta OAuth." },
      { status: 500 },
    )
  }
}
