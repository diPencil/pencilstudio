import crypto from "crypto"
import { NextRequest, NextResponse } from "next/server"
import { requireRoleWithScope, unauthorizedResponse, forbiddenResponse } from "@/lib/api-auth"
import { isTokenEncryptionConfigured } from "@/lib/secure-tokens"

const META_OAUTH_STATE_COOKIE = "pinchat_meta_oauth_state"

function getRequiredMetaOAuthConfig() {
  const appId = process.env.META_APP_ID || ""
  const appSecret = process.env.META_APP_SECRET || ""
  const redirectUri = process.env.META_REDIRECT_URI || ""
  const graphVersion = process.env.META_GRAPH_API_VERSION || ""
  const tokenEncryptionSecret = process.env.TOKEN_ENCRYPTION_SECRET || ""

  const missingEnv = [
    !appId ? "META_APP_ID" : null,
    !appSecret ? "META_APP_SECRET" : null,
    !redirectUri ? "META_REDIRECT_URI" : null,
    !graphVersion ? "META_GRAPH_API_VERSION" : null,
    !tokenEncryptionSecret ? "TOKEN_ENCRYPTION_SECRET" : null,
  ].filter((value): value is string => Boolean(value))

  return {
    appId,
    appSecret,
    redirectUri,
    graphVersion,
    missingEnv,
  }
}

function buildMetaOAuthUrl(appId: string, redirectUri: string, graphVersion: string, state: string) {
  const scope = ["pages_show_list", "pages_manage_metadata", "pages_messaging"].join(",")
  const params = new URLSearchParams({
    client_id: appId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope,
    state,
  })

  return `https://www.facebook.com/${graphVersion}/dialog/oauth?${params.toString()}`
}

export async function GET(request: NextRequest) {
  try {
    await requireRoleWithScope(request, ["ADMIN"])

    const config = getRequiredMetaOAuthConfig()
    if (config.missingEnv.length > 0) {
      return NextResponse.json(
        {
          success: false,
          message: "Meta credentials are not configured yet.",
          missingEnv: config.missingEnv,
        },
        { status: 501 },
      )
    }

    if (!isTokenEncryptionConfigured()) {
      return request.headers.get("x-requested-with") === "XMLHttpRequest" || request.headers.get("accept")?.includes("application/json")
        ? NextResponse.json(
            {
              success: false,
              message: "Token encryption is not configured. Add TOKEN_ENCRYPTION_SECRET before connecting Meta channels.",
              missingEnv: ["TOKEN_ENCRYPTION_SECRET"],
            },
            { status: 501 },
          )
        : NextResponse.redirect(new URL("/accounts?meta_oauth=token_encryption_required", request.url))
    }

    const state = crypto.randomBytes(24).toString("hex")
    const authorizationUrl = buildMetaOAuthUrl(config.appId, config.redirectUri, config.graphVersion, state)
    const wantsJson = request.headers.get("x-requested-with") === "XMLHttpRequest" || request.headers.get("accept")?.includes("application/json")

    const response = wantsJson
      ? NextResponse.json({ success: true, redirectUrl: authorizationUrl, state })
      : NextResponse.redirect(authorizationUrl)

    response.cookies.set(META_OAUTH_STATE_COOKIE, state, {
      httpOnly: true,
      sameSite: "lax",
      secure: request.nextUrl.protocol === "https:",
      path: "/",
      maxAge: 10 * 60,
    })
    response.headers.set("Cache-Control", "no-store")

    return response
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'Unauthorized') return unauthorizedResponse()
      if (error.message === 'Forbidden') return forbiddenResponse('Only admins can start Meta OAuth')
    }

    console.error("Error starting Meta OAuth:", error)
    return NextResponse.json(
      { success: false, message: "Failed to start Meta OAuth." },
      { status: 500 },
    )
  }
}
