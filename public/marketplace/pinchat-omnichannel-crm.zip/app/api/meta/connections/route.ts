import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { requireAuthWithScope, unauthorizedResponse, forbiddenResponse } from '@/lib/api-auth'
import { findMetaFacebookChannelAccount } from '@/lib/channel-accounts'
import { isTokenEncryptionConfigured } from '@/lib/secure-tokens'

function getMissingMetaEnv() {
  const missing: string[] = []
  if (!process.env.META_APP_ID) missing.push('META_APP_ID')
  if (!process.env.META_APP_SECRET) missing.push('META_APP_SECRET')
  if (!process.env.META_REDIRECT_URI) missing.push('META_REDIRECT_URI')
  if (!process.env.META_GRAPH_API_VERSION) missing.push('META_GRAPH_API_VERSION')
  return missing
}

export async function GET(request: NextRequest) {
  try {
    await requireAuthWithScope(request)

    const missingEnv = getMissingMetaEnv()
    const channelAccount = await findMetaFacebookChannelAccount()
    const tokenEncryptionConfigured = isTokenEncryptionConfigured()

    const pageMetadata = (channelAccount?.metadata as Record<string, unknown> | null) || null
    const connectedAtFromMetadata = typeof pageMetadata?.connectedAt === 'string' ? pageMetadata.connectedAt : null
    const pageNameFromMetadata = typeof pageMetadata?.pageName === 'string' ? pageMetadata.pageName : null
    const connectionStateFromMetadata = typeof pageMetadata?.connectionState === 'string' ? pageMetadata.connectionState : null

    // Fetch linked Instagram DM channel account connection
    const instagramAccount = await prisma.channelAccount.findFirst({
      where: {
        channelType: "INSTAGRAM",
        OR: [
          { provider: "META" },
          { provider: "meta" },
        ],
      },
      orderBy: { createdAt: "desc" },
    })

    const instagramMetadata = (instagramAccount?.metadata as Record<string, unknown> | null) || null
    const instagramConnectedAt = typeof instagramMetadata?.connectedAt === 'string' ? instagramMetadata.connectedAt : null
    const instagramUsername = typeof instagramMetadata?.instagramUsername === 'string' ? instagramMetadata.instagramUsername : null

    return NextResponse.json({
      success: true,
      configured: missingEnv.length === 0,
      metaConfigured: missingEnv.length === 0,
      tokenEncryptionConfigured,
      missingEnv,
      facebookPage: channelAccount
        ? {
            connected: true,
            channelAccountId: channelAccount.id,
            pageId: channelAccount.pageId || channelAccount.externalAccountId,
            status: channelAccount.status,
            pageName: pageNameFromMetadata || channelAccount.name,
            connectedAt: connectedAtFromMetadata || channelAccount.createdAt.toISOString(),
            connectionState: connectionStateFromMetadata || channelAccount.status,
          }
        : {
            connected: false,
            channelAccountId: null,
            pageId: null,
            status: 'DISCONNECTED',
            pageName: null,
            connectedAt: null,
            connectionState: 'DISCONNECTED',
          },
      instagramPage: instagramAccount
        ? {
            connected: true,
            channelAccountId: instagramAccount.id,
            instagramAccountId: instagramAccount.instagramBusinessAccountId || instagramAccount.externalAccountId,
            status: instagramAccount.status,
            name: instagramAccount.name,
            username: instagramUsername,
            connectedAt: instagramConnectedAt || instagramAccount.createdAt.toISOString(),
          }
        : {
            connected: false,
            channelAccountId: null,
            instagramAccountId: null,
            status: 'DISCONNECTED',
            name: null,
            username: null,
            connectedAt: null,
          },
    })
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'Unauthorized') return unauthorizedResponse()
      if (error.message === 'Forbidden') return forbiddenResponse()
    }

    console.error('Error fetching Meta connections:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch Meta connections' },
      { status: 500 },
    )
  }
}