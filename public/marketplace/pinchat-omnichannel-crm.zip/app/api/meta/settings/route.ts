import { NextRequest, NextResponse } from "next/server"
import { requireRoleWithScope } from "@/lib/api-auth"
import { getMetaGraphVersion, getMetaRedirectUri, isMetaConfigured } from "@/lib/meta"

export async function GET(request: NextRequest) {
  // ADMIN-only endpoint: Check authorization
  await requireRoleWithScope(request, ["ADMIN"])

  // Check configuration readiness without exposing secrets
  const appId = process.env.META_APP_ID || ""
  const appSecret = process.env.META_APP_SECRET || ""
  const verifyToken = process.env.META_VERIFY_TOKEN || ""
  const redirectUri = getMetaRedirectUri()
  const graphVersion = getMetaGraphVersion()

  return NextResponse.json({
    success: true,
    configured: isMetaConfigured(),
    webhookUrl: "/api/webhooks/meta",
    redirectUri,
    graphVersion,
    // Readiness indicators (boolean only, no secret values)
    hasAppId: Boolean(appId),
    hasAppSecret: Boolean(appSecret),
    hasVerifyToken: Boolean(verifyToken),
    hasRedirectUri: Boolean(redirectUri),
  })
}
