"use client"

import { useEffect, useState } from "react"
import { AppLayout } from "@/components/app-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { useI18n } from "@/lib/i18n"
import { QrCode, CheckCircle2, Loader2, RefreshCw } from "lucide-react"
import { authenticatedFetch } from "@/lib/auth"

export default function WhatsAppPage() {
    const { toast } = useToast()
    const { t } = useI18n()
    const [isReady, setIsReady] = useState(false)
    const [qrCode, setQrCode] = useState<string | null>(null)
    const [isLoading, setIsLoading] = useState(true)
    const [isInitializing, setIsInitializing] = useState(false)
    const [isSyncing, setIsSyncing] = useState(false)
    const [accountInfo, setAccountInfo] = useState<{ name: string; phone: string; accountId?: string; branchId?: string | null } | null>(null)
    const [waitingForQr, setWaitingForQr] = useState(false)
    const [branches, setBranches] = useState<Array<{ id: string; name: string }>>([])
    const [selectedBranchId, setSelectedBranchId] = useState<string | undefined>(undefined)
    const [isSyncingBranch, setIsSyncingBranch] = useState(false)

    useEffect(() => {
        checkStatus()
        fetchAccountInfo()
        fetchBranches()
    }, [])

    useEffect(() => {
        const interval = setInterval(checkStatus, waitingForQr ? 2000 : 5000)
        return () => clearInterval(interval)
    }, [waitingForQr])

    const fetchAccountInfo = async () => {
        try {
            const response = await authenticatedFetch('/api/whatsapp/accounts')
            const data = await response.json()
            if (data.success && data.accounts && data.accounts.length > 0) {
                // Get the first account (assuming single account for now) or the connected one
                const account = data.accounts[0]
                if (account) {
                    setAccountInfo({
                        name: account.name,
                        phone: account.phone,
                        accountId: account.id,
                        branchId: account.branchId || null,
                    })
                    setSelectedBranchId(account.branchId || undefined)
                }
            }
        } catch (error) {
            console.error('Error fetching account info:', error)
        }
    }

    const fetchBranches = async () => {
        try {
            const res = await authenticatedFetch('/api/branches')
            const data = await res.json()
            if (data.success && Array.isArray(data.branches)) {
                setBranches(data.branches.map((b: any) => ({ id: b.id, name: b.name })))
            }
        } catch (error) {
            console.error('Error fetching branches for WhatsApp page:', error)
        }
    }

    const checkStatus = async (overrideAccountId?: string) => {
        const accountId = overrideAccountId || accountInfo?.accountId;
        let url = '/api/whatsapp';
        if (accountId) {
            url += `?accountId=${encodeURIComponent(accountId)}`;
        }
        try {
            console.log('[WhatsApp] Refresh Status requested', accountId ? `for accountId=${accountId}` : '(no accountId)');
            const response = await authenticatedFetch(url);
            const data = await response.json();
            console.log("[WhatsApp] init response", data);

            if (data.success) {
                setIsReady(data.isReady);
                if (data.qrCode) {
                    let normalizedQr = data.qrCode;
                    if (!normalizedQr.startsWith('data:image')) {
                        normalizedQr = `data:image/png;base64,${normalizedQr}`;
                    }
                    setQrCode(normalizedQr);
                    setWaitingForQr(false);
                    setIsInitializing(false);
                    console.log("[WhatsApp] qrCode exists", true);
                    console.log("[WhatsApp] qrCode startsWith data image", normalizedQr.startsWith("data:image"));
                } else {
                    setQrCode(null);
                }
                if (data.userInfo) {
                    setAccountInfo(data.userInfo);
                    setSelectedBranchId(data.userInfo.branchId || undefined);
                } else {
                    fetchAccountInfo();
                }
            } else {
                toast({
                    title: 'Error',
                    description: data.error || 'Failed to refresh WhatsApp status',
                    variant: 'destructive',
                });
            }
        } catch (err) {
            console.error('Error checking WhatsApp status:', err);
            toast({
                title: 'Error',
                description: err instanceof Error ? err.message : 'Failed to refresh WhatsApp status',
                variant: 'destructive',
            });
        } finally {
            setIsLoading(false);
        }
    }

    const handleInitialize = async () => {
        try {
            setIsInitializing(true);
            const response = await authenticatedFetch('/api/whatsapp', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'init' })
            });

            const data = await response.json();

            if (data.success && data.accountId) {
                const accountId = data.accountId;
                setWaitingForQr(true);
                setAccountInfo((prev) => prev ? { ...prev, accountId } : { name: '', phone: '', accountId });
                toast({
                    title: "Success",
                    description: "جاري تجهيز رمز QR... انتظر حتى ٦٠ ثانية ولا تغلق الصفحة."
                });

                let polling = true;
                let attempt = 0;
                const maxAttempts = 30; // 2s * 30 = 60s

                const pollForQr = async () => {
                    if (!polling) return;
                    attempt++;
                    const pollingUrl = `/api/whatsapp?accountId=${encodeURIComponent(accountId)}`;
                    console.log(`[WhatsApp] QR polling attempt #${attempt} for accountId=${accountId}`);
                    console.log("[WhatsApp] polling status", pollingUrl);
                    try {
                        const res = await authenticatedFetch(pollingUrl);
                        const status = await res.json();
                        if (status.success) {
                            if (status.isReady) {
                                setIsReady(true);
                                setQrCode(null);
                                setWaitingForQr(false);
                                setIsInitializing(false);
                                polling = false;
                                toast({ title: 'Connected', description: 'WhatsApp is now connected.' });
                                return;
                            }
                            if (status.qrCode) {
                                let normalizedQr = status.qrCode;
                                if (!normalizedQr.startsWith('data:image')) {
                                    normalizedQr = `data:image/png;base64,${normalizedQr}`;
                                }
                                setQrCode(normalizedQr);
                                setWaitingForQr(false);
                                setIsInitializing(false);
                                polling = false;
                                console.log("[WhatsApp] qrCode exists", true);
                                console.log("[WhatsApp] qrCode startsWith data image", normalizedQr.startsWith("data:image"));
                                toast({ title: 'QR Ready', description: 'Scan the QR code to connect WhatsApp.' });
                                return;
                            }
                        } else {
                            toast({
                                title: 'Error',
                                description: status.error || 'Failed to get WhatsApp status',
                                variant: 'destructive',
                            });
                            setWaitingForQr(false);
                            setIsInitializing(false);
                            polling = false;
                            return;
                        }
                    } catch (err) {
                        toast({
                            title: 'Error',
                            description: err instanceof Error ? err.message : 'Failed to poll WhatsApp status',
                            variant: 'destructive',
                        });
                        setWaitingForQr(false);
                        setIsInitializing(false);
                        polling = false;
                        return;
                    }
                    if (attempt < maxAttempts) {
                        setTimeout(pollForQr, 2000);
                    } else {
                        toast({
                            title: 'Timeout',
                            description: 'لم يتم تجهيز رمز QR في الوقت المحدد. حاول مرة أخرى.',
                            variant: 'destructive',
                        });
                        setWaitingForQr(false);
                        setIsInitializing(false);
                        polling = false;
                    }
                };
                setTimeout(pollForQr, 2000);
            } else {
                toast({
                    title: "Error",
                    description: data.error || 'فشل تهيئة الواتساب',
                    variant: "destructive"
                });
                setIsInitializing(false);
                setWaitingForQr(false);
            }
        } catch (err) {
            toast({
                title: "Error",
                description: err instanceof Error ? err.message : "Failed to initialize WhatsApp",
                variant: "destructive"
            });
            setIsInitializing(false);
            setWaitingForQr(false);
        }
    }

    const handleSync = async () => {
        if (!accountInfo?.accountId) {
            toast({
                title: "Error",
                description: "No account connected",
                variant: "destructive"
            })
            return
        }

        try {
            setIsSyncing(true)
            const response = await authenticatedFetch('/api/whatsapp/sync', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ accountId: accountInfo.accountId })
            })

            const data = await response.json()

            if (data.success) {
                toast({
                    title: "Success",
                    description: `Synced ${data.synced.contacts} contacts and ${data.synced.conversations} conversations`
                })
            } else {
                toast({
                    title: "Error",
                    description: data.error,
                    variant: "destructive"
                })
            }
        } catch (err) {
            toast({
                title: "Error",
                description: "Failed to sync WhatsApp data",
                variant: "destructive"
            })
        } finally {
            setIsSyncing(false)
        }
    }

    const handleSyncBranch = async () => {
        if (!accountInfo?.accountId || !selectedBranchId) {
            toast({
                title: "Error",
                description: t("pleaseSelectBranch") || "Please select a branch first",
                variant: "destructive"
            })
            return
        }

        try {
            setIsSyncingBranch(true)
            const response = await authenticatedFetch('/api/whatsapp/sync-branch', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ accountId: accountInfo.accountId, branchId: selectedBranchId })
            })

            const data = await response.json()

            if (data.success) {
                toast({
                    title: t("success") || "Success",
                    description: data.message || `Branch synced. Updated ${data.data?.updatedContacts ?? 0} contacts.`
                })
                // Update local state
                setAccountInfo(prev => prev ? { ...prev, branchId: selectedBranchId } : prev)
            } else {
                toast({
                    title: t("error") || "Error",
                    description: data.error,
                    variant: "destructive"
                })
            }
        } catch (err) {
            console.error('Error syncing WhatsApp branch:', err)
            toast({
                title: t("error") || "Error",
                description: "Failed to sync branch",
                variant: "destructive"
            })
        } finally {
            setIsSyncingBranch(false)
        }
    }

    return (
        <AppLayout title={t("whatsappIntegration")}>
            <div className="space-y-6">
                <p className="text-sm text-muted-foreground">
                    Connect your WhatsApp account to send and receive messages
                </p>

                <div className="grid gap-6 md:grid-cols-2">
                    {/* Status Card */}
                    <Card className="rounded-2xl shadow-soft">
                        <CardHeader>
                            <CardTitle>{t("connectionStatus")}</CardTitle>
                            <CardDescription>WhatsApp account connection status</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex items-center justify-between">
                                <span className="text-sm font-medium">Status:</span>
                                {isLoading ? (
                                    <Badge variant="outline">
                                        <Loader2 className="mr-2 h-3 w-3 animate-spin" />
                                        Checking...
                                    </Badge>
                                ) : isReady ? (
                                    <Badge className="bg-green-500/10 text-green-700 dark:text-green-400">
                                        <CheckCircle2 className="mr-2 h-3 w-3" />
                                        Connected
                                    </Badge>
                                ) : (
                                    <Badge variant="secondary">
                                        Disconnected
                                    </Badge>
                                )}
                            </div>

                            {/* Account Info */}
                            {accountInfo && (
                                <div className="space-y-4 rounded-lg bg-green-50/50 p-4 border border-green-100 dark:bg-green-900/10 dark:border-green-900/30">
                                    <div className="flex items-center gap-3">
                                        <div className="h-10 w-10 bg-green-100 text-green-600 rounded-full flex items-center justify-center dark:bg-green-900/30 dark:text-green-400">
                                            <QrCode className="h-5 w-5" />
                                        </div>
                                        <div>
                                            <div className="flex items-center gap-2">
                                                <p className="text-sm font-semibold">{accountInfo.name}</p>
                                                {!isReady && (
                                                    <Badge variant="outline" className="text-[10px] h-4 px-1 text-yellow-600 border-yellow-200 bg-yellow-50">
                                                        Offline
                                                    </Badge>
                                                )}
                                            </div>
                                            <p className="text-xs text-muted-foreground">{accountInfo.phone?.startsWith('+') ? accountInfo.phone : `+${accountInfo.phone || ''}`}</p>
                                        </div>
                                    </div>
                                    {branches.length > 0 && (
                                        <div className="space-y-2">
                                            <p className="text-xs font-medium text-muted-foreground">
                                                {t("branch") || "Branch"}
                                            </p>
                                            <div className="flex flex-col sm:flex-row gap-2">
                                                <Select
                                                    value={selectedBranchId || ""}
                                                    onValueChange={(v) => setSelectedBranchId(v || undefined)}
                                                >
                                                    <SelectTrigger className="w-full sm:w-48">
                                                        <SelectValue placeholder={t("selectBranch") || "Select branch"} />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        {branches.map((branch) => (
                                                            <SelectItem key={branch.id} value={branch.id}>
                                                                {branch.name}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                                <Button
                                                    type="button"
                                                    variant="outline"
                                                    disabled={!selectedBranchId || isSyncingBranch}
                                                    onClick={handleSyncBranch}
                                                    className="sm:flex-1"
                                                >
                                                    {isSyncingBranch ? (
                                                        <>
                                                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                                            {t("syncing") || "Syncing..."}
                                                        </>
                                                    ) : (
                                                        <>
                                                            <RefreshCw className="mr-2 h-4 w-4" />
                                                            {t("syncToBranch") || "Sync to Branch"}
                                                        </>
                                                    )}
                                                </Button>
                                            </div>
                                            <p className="text-[11px] text-muted-foreground">
                                                {t("syncBranchHelp") || "Use this to ensure contacts from this WhatsApp number are attached to the correct branch."}
                                            </p>
                                        </div>
                                    )}
                                </div>
                            )}

                            {!isReady && !qrCode && (
                                <Button
                                    onClick={handleInitialize}
                                    disabled={isInitializing}
                                    className="w-full"
                                >
                                    {isInitializing ? (
                                        <>
                                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                            Initializing...
                                        </>
                                    ) : (
                                        <>
                                            <QrCode className="mr-2 h-4 w-4" />
                                            Connect WhatsApp
                                        </>
                                    )}
                                </Button>
                            )}

                            {!isReady && (
                                <Button
                                    variant="outline"
                                    onClick={() => checkStatus()}
                                    className="w-full"
                                >
                                    <RefreshCw className="mr-2 h-4 w-4" />
                                    Refresh Status
                                </Button>
                            )}

                            {isReady && accountInfo && (
                                <Button
                                    variant="default"
                                    onClick={handleSync}
                                    disabled={isSyncing}
                                    className="w-full"
                                >
                                    {isSyncing ? (
                                        <>
                                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                            Syncing...
                                        </>
                                    ) : (
                                        <>
                                            <RefreshCw className="mr-2 h-4 w-4" />
                                            Sync Chats & Contacts
                                        </>
                                    )}
                                </Button>
                            )}
                        </CardContent>
                    </Card>

                    {/* QR Code Card */}
                    <Card className="rounded-2xl shadow-soft">
                        <CardHeader>
                            <CardTitle>QR Code</CardTitle>
                            <CardDescription>{t("scanWithWhatsApp")}</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {qrCode ? (
                                <div className="space-y-4">
                                    <div className="flex items-center justify-center rounded-lg bg-white p-4">
                                        <img
                                            src={qrCode}
                                            alt="WhatsApp QR Code"
                                            className="h-64 w-64 object-contain"
                                        />
                                    </div>
                                    <div className="space-y-2 text-sm text-muted-foreground">
                                        <p>1. Open WhatsApp on your phone</p>
                                        <p>2. Tap Menu or Settings → Linked Devices</p>
                                        <p>3. Tap "Link a Device"</p>
                                        <p>4. Scan this QR code</p>
                                    </div>
                                </div>
                            ) : isReady ? (
                                <div className="flex h-64 items-center justify-center text-center">
                                    <div>
                                        <CheckCircle2 className="mx-auto h-12 w-12 text-green-500" />
                                        <p className="mt-4 font-medium">WhatsApp Connected!</p>
                                        <p className="mt-2 text-sm text-muted-foreground">
                                            You can now send and receive messages
                                        </p>
                                    </div>
                                </div>
                            ) : waitingForQr ? (
                                <div className="flex h-64 flex-col items-center justify-center gap-4 text-center">
                                    <Loader2 className="h-12 w-12 animate-spin text-primary" />
                                    <div>
                                        <p className="font-medium">جاري تجهيز رمز QR</p>
                                        <p className="mt-2 text-sm text-muted-foreground">
                                            عادةً ١٠–٣٠ ثانية. لا تغلق الصفحة.
                                        </p>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex h-64 items-center justify-center text-center">
                                    <div>
                                        <QrCode className="mx-auto h-12 w-12 text-muted-foreground" />
                                        <p className="mt-4 text-sm text-muted-foreground">
                                            Click "Connect WhatsApp" to generate QR code
                                        </p>
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </AppLayout>
    )
}
