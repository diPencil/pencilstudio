"use client"

import { useEffect, useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import { AppLayout } from "@/components/app-layout"
import { PageGuard } from "@/components/page-guard"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { authenticatedFetch } from "@/lib/auth"
import { useI18n } from "@/lib/i18n"
import {
  ADD_ONS,
  getAddOnSectionLabel,
  getDefaultEnabledAddOnIds,
  getEnabledAddOnIds,
  isAddOnId,
  isComingSoonAddOnId,
  loadEnabledAddOnIds,
  saveEnabledAddOnIds,
  type AddOnDefinition,
  type AddOnId,
} from "@/lib/add-ons"
import { AddOnCard } from "@/components/add-ons/add-on-card"
import { cn } from "@/lib/utils"

type AddOnFilter = "all" | "channels" | "meta" | "ai" | "automation" | "crm" | "comingSoon" | "active"

const FILTERS: Array<{ value: AddOnFilter; labelKey: string }> = [
  { value: "all", labelKey: "all" },
  { value: "channels", labelKey: "channels" },
  { value: "meta", labelKey: "meta" },
  { value: "ai", labelKey: "ai" },
  { value: "automation", labelKey: "automation" },
  { value: "crm", labelKey: "crm" },
  { value: "comingSoon", labelKey: "comingSoon" },
  { value: "active", labelKey: "active" },
]

const SECTION_ORDER: Array<AddOnDefinition["section"]> = ["channels", "aiAutomation", "business"]

function matchesFilter(addOn: AddOnDefinition, filter: AddOnFilter) {
  if (filter === "all") return true
  if (filter === "channels") return addOn.section === "channels"
  if (filter === "meta") return addOn.section === "channels" && addOn.category === "Meta"
  if (filter === "ai") return addOn.section === "aiAutomation" && addOn.category === "AI"
  if (filter === "automation") return addOn.section === "aiAutomation" && addOn.category === "Automation"
  if (filter === "crm") return addOn.section === "business"
  if (filter === "comingSoon") return addOn.status === "coming_soon"
  if (filter === "active") return addOn.status === "connected" || addOn.status === "active"
  return true
}

export default function AddOnsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { t, language } = useI18n()
  const [selectedFilter, setSelectedFilter] = useState<AddOnFilter>("all")
  const [enabledAddOnIds, setEnabledAddOnIds] = useState<Set<AddOnId>>(new Set(getDefaultEnabledAddOnIds()))
  const [isLoadingAddOnState, setIsLoadingAddOnState] = useState(true)
  const [isSavingAddOnState, setIsSavingAddOnState] = useState(false)

  useEffect(() => {
    let isMounted = true

    const loadEnabledAddOns = async () => {
      try {
        const response = await authenticatedFetch("/api/add-ons")
        const data = await response.json()

        if (response.ok && data.success && Array.isArray(data.enabledAddOns)) {
          const ids = new Set<AddOnId>(data.enabledAddOns.filter(isAddOnId))
          const nextIds: Set<AddOnId> = ids.size > 0 || data.enabledAddOns.length === 0 ? ids : new Set<AddOnId>(getDefaultEnabledAddOnIds())

          if (isMounted) {
            setEnabledAddOnIds(nextIds)
            saveEnabledAddOnIds(nextIds)
          }
          return
        }
      } catch (error) {
        console.error("Failed to load add-ons settings", error)
      }

      if (isMounted) {
        setEnabledAddOnIds(loadEnabledAddOnIds())
      }
    }

    loadEnabledAddOns().finally(() => {
      if (isMounted) {
        setIsLoadingAddOnState(false)
      }
    })

    return () => {
      isMounted = false
    }
  }, [])

  const visibleAddOns = useMemo(() => ADD_ONS.filter((addOn) => matchesFilter(addOn, selectedFilter)), [selectedFilter])

  const enabledCount = enabledAddOnIds.size
  const activeCount = ADD_ONS.filter((addOn) => addOn.status === "connected" || addOn.status === "active").length
  const comingSoonCount = ADD_ONS.filter((addOn) => addOn.status === "coming_soon").length

  const toggleAddOn = (addOnId: AddOnId) => {
    // Prevent toggling of coming_soon add-ons
    if (isComingSoonAddOnId(addOnId)) {
      console.warn(`Attempted to toggle coming_soon add-on: ${addOnId}`)
      toast({
        title: language === "ar" ? "غير مسموح" : "Not allowed",
        description: language === "ar"
          ? "لا يمكن تفعيل الإضافات القادمة قريباً."
          : "Coming soon add-ons cannot be enabled.",
        variant: "destructive",
      })
      return
    }

    if (isSavingAddOnState) return

    setEnabledAddOnIds((current) => {
      const next = new Set(current)
      if (next.has(addOnId)) {
        next.delete(addOnId)
      } else {
        next.add(addOnId)
      }

      const nextIds = Array.from(next)
      setIsSavingAddOnState(true)
      authenticatedFetch("/api/add-ons", {
        method: "PATCH",
        body: JSON.stringify({ enabledAddOns: nextIds }),
      })
        .then(async (response) => {
          const data = await response.json()
          if (!response.ok || !data.success) {
            throw new Error(data.error || "Failed to save add-ons settings")
          }
          saveEnabledAddOnIds(next)
        })
        .catch((error) => {
          console.error("Failed to save add-ons settings", error)
          saveEnabledAddOnIds(next)
          toast({
            title: language === "ar" ? "تعذر الحفظ" : "Save failed",
            description: language === "ar"
              ? "تم حفظ التبديل محلياً فقط. حاول مرة أخرى عند توفر الاتصال بالخادم."
              : "Saved locally only. Try again when the backend is available.",
            variant: "destructive",
          })
        })
        .finally(() => {
          setIsSavingAddOnState(false)
        })

      return next
    })
  }

  const visibleSections = SECTION_ORDER
    .map((section) => ({
      section,
      addOns: visibleAddOns.filter((addOn) => addOn.section === section),
    }))
    .filter(({ addOns }) => addOns.length > 0)

  return (
    <PageGuard page="/add-ons">
      <AppLayout title={t("addOns")}>
        <div className="space-y-6">
          <div className="relative overflow-hidden rounded-3xl border border-border/60 bg-gradient-to-br from-background via-background to-muted/30 p-6 shadow-sm">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(59,130,246,0.12),transparent_35%),radial-gradient(circle_at_bottom_left,rgba(16,185,129,0.10),transparent_30%)]" />
            <div className="relative space-y-4">
              <div className="flex flex-wrap items-center gap-3">
                <Badge variant="outline" className="rounded-full px-3 py-1">
                  {t("addOns")}
                </Badge>
                <Badge variant="secondary" className="rounded-full px-3 py-1">
                  {language === "ar" ? "إعدادات مساحة العمل" : "Workspace settings"}
                </Badge>
              </div>

              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tight md:text-4xl">{t("addOns")}</h1>
                <p className="max-w-3xl text-sm leading-6 text-muted-foreground md:text-base">
                  {t("addOnsSubtitle")}
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-3">
                <Card className="rounded-2xl border-border/60 bg-background/80 shadow-none">
                  <CardHeader className="pb-2">
                    <CardDescription>{t("enabled")}</CardDescription>
                    <CardTitle className="text-2xl">{enabledCount}</CardTitle>
                  </CardHeader>
                </Card>
                <Card className="rounded-2xl border-border/60 bg-background/80 shadow-none">
                  <CardHeader className="pb-2">
                    <CardDescription>{t("active")}</CardDescription>
                    <CardTitle className="text-2xl">{activeCount}</CardTitle>
                  </CardHeader>
                </Card>
                <Card className="rounded-2xl border-border/60 bg-background/80 shadow-none">
                  <CardHeader className="pb-2">
                    <CardDescription>{t("comingSoon")}</CardDescription>
                    <CardTitle className="text-2xl">{comingSoonCount}</CardTitle>
                  </CardHeader>
                </Card>
              </div>

              {isLoadingAddOnState && (
                <div className="flex items-center gap-2 rounded-2xl border border-border/60 bg-background/80 px-4 py-3 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>{language === "ar" ? "جارٍ تحميل حالة الإضافات المحفوظة..." : "Loading saved add-ons state..."}</span>
                </div>
              )}
            </div>
          </div>

        <div className="rounded-2xl border border-blue-500/20 bg-blue-50/50 dark:bg-blue-950/20 p-4 text-sm text-blue-800 dark:text-blue-300">
          <div className="flex gap-3">
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-500 text-white text-[11px] font-bold">i</span>
            <div className="space-y-1">
              <p className="font-semibold text-xs leading-none">
                {language === "ar" ? "كيف تعمل الإضافات والقنوات؟" : "How Add-ons & Connected Channels Work:"}
              </p>
              <ul className="list-disc pl-4 space-y-1 text-xs text-blue-700/90 dark:text-blue-300/80">
                <li>
                  {language === "ar" 
                    ? "تفعيل الإضافة (Add-on) يجعل الميزة أو القناة متاحة داخل لوحة التحكم." 
                    : "Enabling an add-on makes the feature or channel available in your workspace."}
                </li>
                <li>
                  {language === "ar" 
                    ? "إدارة اتصال القناة الحقيقي (كربط رقم واتساب أو صفحة فيسبوك) يتم عبر صفحة القنوات المتصلة." 
                    : "Connecting the actual channel (e.g., linking a WhatsApp number or Facebook Page) is managed from Connected Channels."}
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-hide">
            {FILTERS.map((filter) => {
              const active = selectedFilter === filter.value
              return (
                <Button
                  key={filter.value}
                  type="button"
                  variant="outline"
                  size="sm"
                  className={cn(
                    "h-9 shrink-0 rounded-full px-4 transition-colors",
                    active
                      ? "!border-primary !bg-primary !text-primary-foreground shadow-soft hover:!bg-primary/90 hover:!text-primary-foreground dark:!border-primary dark:!bg-primary dark:!text-primary-foreground"
                      : "!border-border !bg-background !text-foreground hover:!bg-accent hover:!text-accent-foreground dark:!border-border dark:!bg-background/80 dark:!text-foreground dark:hover:!bg-accent/50 dark:hover:!text-accent-foreground"
                  )}
                  onClick={() => setSelectedFilter(filter.value)}
                >
                  {t(filter.labelKey)}
                </Button>
              )
            })}
          </div>

          {visibleSections.length === 0 ? (
            <Card className="rounded-2xl border-border/60">
              <CardContent className="flex min-h-[220px] items-center justify-center p-6 text-center">
                <div className="space-y-2">
                  <p className="text-base font-medium">{language === "ar" ? "لا توجد إضافات مطابقة" : "No add-ons match this filter"}</p>
                  <p className="max-w-md text-sm text-muted-foreground">
                    {language === "ar"
                      ? "جرّب تغيير الفلتر أو العودة إلى عرض الكل لرؤية الإضافات المتاحة."
                      : "Try a different filter or go back to All to see every available add-on."}
                  </p>
                </div>
              </CardContent>
            </Card>
          ) : (
            visibleSections.map(({ section, addOns }) => (
              <section key={section} className="space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="space-y-1">
                    <h2 className="text-xl font-semibold tracking-tight">{getAddOnSectionLabel(section, language)}</h2>
                    <p className="text-sm text-muted-foreground">
                      {section === "channels" && (language === "ar" ? "إدارة قنوات التواصل الحالية والمستقبلية." : "Manage current and future communication channels.")}
                      {section === "aiAutomation" && (language === "ar" ? "أدوات الذكاء والأتمتة الجاهزة للتفعيل." : "AI and automation tools ready to be enabled.")}
                      {section === "business" && (language === "ar" ? "إضافات الأعمال والعمليات الداخلية." : "Business and operational add-ons.")}
                    </p>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                  {addOns.map((addOn) => (
                    <AddOnCard
                      key={addOn.id}
                      addOn={addOn}
                      enabled={enabledAddOnIds.has(addOn.id)}
                      language={language}
                      disabled={isLoadingAddOnState || isSavingAddOnState}
                      onToggle={() => toggleAddOn(addOn.id)}
                      onAction={() => {
                        if (addOn.route) {
                          router.push(addOn.route)
                        }
                      }}
                    />
                  ))}
                </div>
              </section>
            ))
          )}

          <Card className="rounded-2xl border-dashed border-border/70 bg-muted/20">
            <CardContent className="p-4 text-sm text-muted-foreground">
              {language === "ar"
                ? "يتم حفظ تفعيل/تعطيل الإضافات في مساحة العمل، مع إبقاء النسخة المحلية كخطة احتياطية عند تعطل الخادم."
                : "Add-on enablement is saved at the workspace level, with a local fallback kept available if the backend is unavailable."}
            </CardContent>
          </Card>
        </div>
        </div>
      </AppLayout>
    </PageGuard>
  )
}