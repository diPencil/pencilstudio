"use client"

import { useState, useEffect } from "react"
import { AppLayout } from "@/components/app-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Copy, Trash2, Plus, Key, X } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog"
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select"
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { authenticatedFetch, getUserRole } from "@/lib/auth"
import { useI18n } from "@/lib/i18n"

interface ApiKey {
    id: string
    name: string
    key: string
    isActive: boolean
    createdAt: string
    expiresAt: string | null
}

export default function ApiKeysPage() {
    const [apiKeys, setApiKeys] = useState<ApiKey[]>([])
    const [isLoading, setIsLoading] = useState(true)
    const [isCreating, setIsCreating] = useState(false)
    const [isDialogOpen, setIsDialogOpen] = useState(false)
    const [newKeyName, setNewKeyName] = useState("")
    const [expiresIn, setExpiresIn] = useState("never")
    const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null)
    const canDeleteApiKey = getUserRole() === "ADMIN"
    const { toast } = useToast()
    const { t } = useI18n()

    useEffect(() => {
        fetchApiKeys()
    }, [])

    const fetchApiKeys = async () => {
        try {
            const response = await authenticatedFetch('/api/integrations/api-keys')
            const data = await response.json()
            if (data.success) {
                setApiKeys(data.apiKeys)
            }
        } catch (error) {
            console.error('Error fetching API keys:', error)
        } finally {
            setIsLoading(false)
        }
    }

    const handleDeleteKeyClick = (id: string) => {
        setDeleteConfirmId(id)
    }

    const confirmDeleteApiKey = async () => {
        if (!deleteConfirmId) return

        try {
            const response = await authenticatedFetch(`/api/integrations/api-keys?id=${deleteConfirmId}`, {
                method: 'DELETE',
            })
            const data = await response.json()

            if (data.success) {
                toast({ title: t("success"), description: t("apiKeyDeletedSuccessfully") })
                setDeleteConfirmId(null)
                fetchApiKeys()
            } else {
                toast({ title: t("error"), description: data.error || t("failedToDeleteApiKey"), variant: "destructive" })
            }
        } catch (error) {
            toast({ title: t("error"), description: t("failedToDeleteApiKey"), variant: "destructive" })
        }
    }

    const handleCreateKey = async () => {
        if (!newKeyName.trim()) {
            toast({
                title: t("error"),
                description: t("pleaseEnterApiKeyName"),
                variant: "destructive"
            })
            return
        }

        try {
            setIsCreating(true)
            const expiresInDays = expiresIn === "never" ? null : parseInt(expiresIn)

            const response = await authenticatedFetch('/api/integrations/api-keys', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: newKeyName,
                    expiresInDays
                })
            })

            const data = await response.json()

            if (data.success) {
                toast({
                    title: t("success"),
                    description: t("apiKeyCreatedSuccessfully")
                })
                setNewKeyName("")
                setExpiresIn("never")
                setIsDialogOpen(false)
                fetchApiKeys()
            } else {
                toast({
                    title: t("error"),
                    description: data.error || t("failedToCreateApiKey"),
                    variant: "destructive"
                })
            }
        } catch (error) {
            toast({
                title: t("error"),
                description: t("failedToCreateApiKey"),
                variant: "destructive"
            })
        } finally {
            setIsCreating(false)
        }
    }

    const handleCopyKey = (key: string) => {
        navigator.clipboard.writeText(key)
        toast({
            title: t("success"),
            description: t("apiKeyCopiedToClipboard")
        })
    }

    if (isLoading) {
        return (
            <AppLayout title={t("apiKeys")}>
                <div className="flex items-center justify-center h-64">
                    <Loader2 className="h-8 w-8 animate-spin" />
                </div>
            </AppLayout>
        )
    }

    return (
        <AppLayout title={t("apiKeys")}>
            {canDeleteApiKey && (
            <AlertDialog open={deleteConfirmId !== null} onOpenChange={(open) => !open && setDeleteConfirmId(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>{t("confirmDelete")}</AlertDialogTitle>
                        <AlertDialogDescription>{t("confirmDeleteApiKey")}</AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>{t("cancel")}</AlertDialogCancel>
                        <AlertDialogAction onClick={confirmDeleteApiKey} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                            {t("delete")}
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
            )}
            <div className="max-w-4xl space-y-6">
                <div className="flex items-center justify-between">
                    <div>
                        <h2 className="text-2xl font-bold">{t("apiKeys")}</h2>
                        <p className="text-muted-foreground">{t("manageApiKeys")}</p>
                    </div>

                    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                        <DialogTrigger asChild>
                            <Button>
                                <Plus className="me-2 h-4 w-4" />
                                {t("createApiKey")}
                            </Button>
                        </DialogTrigger>
                        <DialogContent>
                            <DialogHeader>
                                <DialogTitle>{t("createNewApiKey")}</DialogTitle>
                                <DialogDescription>
                                    {t("manageApiKeys")}
                                </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="name">{t("keyName")}</Label>
                                    <Input
                                        id="name"
                                        placeholder={t("placeholderApiKeyName")}
                                        value={newKeyName}
                                        onChange={(e) => setNewKeyName(e.target.value)}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="expires">{t("expiresIn")}</Label>
                                    <Select value={expiresIn} onValueChange={setExpiresIn}>
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="never">{t("neverExpires")}</SelectItem>
                                            <SelectItem value="30">{t("days30")}</SelectItem>
                                            <SelectItem value="90">{t("days90")}</SelectItem>
                                            <SelectItem value="365">{t("oneYear")}</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <Button
                                    onClick={handleCreateKey}
                                    disabled={isCreating}
                                    className="w-full"
                                >
                                    {isCreating && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
                                    {t("generateKey")}
                                </Button>
                            </div>
                        </DialogContent>
                    </Dialog>
                </div>

                {apiKeys.length === 0 ? (
                    <Card>
                        <CardContent className="flex flex-col items-center justify-center py-12">
                            <Key className="h-12 w-12 text-muted-foreground mb-4" />
                            <p className="text-lg font-medium mb-2">{t("noApiKeysYet")}</p>
                            <p className="text-sm text-muted-foreground mb-4">
                                {t("createFirstApiKeyPrompt")}
                            </p>
                        </CardContent>
                    </Card>
                ) : (
                    <div className="space-y-4">
                        {apiKeys.map((apiKey) => (
                            <Card key={apiKey.id}>
                                <CardHeader>
                                    <div className="flex items-start justify-between">
                                        <div>
                                            <CardTitle className="text-lg">{apiKey.name}</CardTitle>
                                            <CardDescription>
                                                {t("createdLabel")} {formatDistanceToNow(new Date(apiKey.createdAt), { addSuffix: true })}
                                                {apiKey.expiresAt && (
                                                    <> • {t("expiresLabel")} {formatDistanceToNow(new Date(apiKey.expiresAt), { addSuffix: true })}</>
                                                )}
                                            </CardDescription>
                                        </div>
                                        {canDeleteApiKey && (
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            onClick={() => handleDeleteKeyClick(apiKey.id)}
                                        >
                                            <Trash2 className="h-4 w-4 text-destructive" />
                                        </Button>
                                        )}
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <div className="flex items-center gap-2">
                                        <Input
                                            value={apiKey.key}
                                            readOnly
                                            className="font-mono text-sm"
                                        />
                                        <Button
                                            variant="outline"
                                            size="icon"
                                            onClick={() => handleCopyKey(apiKey.key)}
                                        >
                                            <Copy className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                )}
            </div>
        </AppLayout>
    )
}
