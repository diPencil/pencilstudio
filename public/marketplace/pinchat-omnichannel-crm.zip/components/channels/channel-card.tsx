import type { ComponentType, ReactNode } from "react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

type ChannelCardProps = {
  title: string
  description: string
  icon: ComponentType<{ className?: string }>
  statusLabel: string
  statusVariant?: "default" | "secondary" | "outline" | "destructive"
  className?: string
  children: ReactNode
}

export function ChannelCard({
  title,
  description,
  icon: Icon,
  statusLabel,
  statusVariant = "secondary",
  className,
  children,
}: ChannelCardProps) {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
        <div>
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
          <CardDescription>{description}</CardDescription>
        </div>
        <Icon className="h-4 w-4 shrink-0" />
      </CardHeader>
      <CardContent className="space-y-3">
        <Badge variant={statusVariant} className="rounded-full">
          {statusLabel}
        </Badge>
        {children}
      </CardContent>
    </Card>
  )
}
