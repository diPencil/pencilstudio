"use client"

import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { useRouter } from "next/navigation"
import {
  getAddOnActionLabel,
  getAddOnCategoryLabel,
  getAddOnStatusLabel,
  getAddOnToggleLabel,
  type AddOnDefinition,
} from "@/lib/add-ons"

type AddOnCardProps = {
  addOn: AddOnDefinition
  enabled: boolean
  language: "en" | "ar"
  onToggle: (checked: boolean) => void
  onAction: () => void
  disabled?: boolean
}

export function AddOnCard({ addOn, enabled, language, onToggle, onAction, disabled = false }: AddOnCardProps) {
  const router = useRouter()
  const Icon = addOn.icon
  const statusLabel = getAddOnStatusLabel(addOn.status, language)
  const categoryLabel = getAddOnCategoryLabel(addOn.category, language)
  const actionLabel = getAddOnActionLabel(addOn, language)
  const toggleLabel = getAddOnToggleLabel(enabled, language)

  const isChannel = addOn.type === "channel"

  return (
    <Card className={cn(
      "overflow-hidden transition-all duration-300 hover:shadow-soft-lg group relative flex flex-col justify-between border-border/60 bg-background/50 backdrop-blur-sm",
      enabled ? "border-primary/20 shadow-soft" : "border-dashed border-border/60 bg-muted/5",
      disabled && "opacity-75 cursor-not-allowed",
    )}>
      {/* Subtle corner gradient when enabled */}
      {enabled && (
        <div className="absolute top-0 right-0 h-16 w-16 bg-gradient-to-br from-primary/10 via-transparent to-transparent pointer-events-none rounded-tr-xl" />
      )}

      <div>
        <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-3">
          <div className="flex items-start gap-4">
            <div className={cn(
              "flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border transition-all duration-300 shadow-sm",
              addOn.status === "coming_soon" 
                ? "bg-muted/80 text-muted-foreground border-border/40" 
                : enabled 
                  ? "bg-primary/10 text-primary border-primary/20 scale-105" 
                  : "bg-background text-foreground border-border/80 group-hover:border-primary/30",
            )}>
              <Icon className="h-6 w-6" />
            </div>
            <div className="space-y-1.5 min-w-0">
              <CardTitle className="text-base font-semibold leading-tight tracking-tight text-foreground truncate">
                {addOn.name[language]}
              </CardTitle>
              <div className="flex flex-wrap gap-1.5">
                <Badge variant="secondary" className="rounded-full text-[10px] px-2 py-0 h-5 font-normal tracking-wide bg-muted/50 border border-border/40">
                  {categoryLabel}
                </Badge>
                <Badge
                  variant={addOn.status === "coming_soon" ? "outline" : addOn.status === "setup_ready" ? "secondary" : "success"}
                  className={cn(
                    "rounded-full text-[10px] px-2 py-0 h-5 font-medium border",
                    addOn.status === "coming_soon" && "bg-background text-muted-foreground border-border/50",
                    addOn.status === "setup_ready" && "bg-blue-50 text-blue-700 border-blue-100 dark:bg-blue-950/30 dark:text-blue-400 dark:border-blue-900/50",
                    (addOn.status === "connected" || addOn.status === "active") && "bg-green-50 text-green-700 border-green-100 dark:bg-green-950/30 dark:text-green-400 dark:border-green-900/50"
                  )}
                >
                  {statusLabel}
                </Badge>
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-4 pt-1">
          <CardDescription className="text-sm leading-6 text-muted-foreground min-h-[48px] line-clamp-2">
            {addOn.description[language]}
          </CardDescription>

          <div className="flex items-center justify-between gap-3 rounded-2xl border border-border/60 bg-muted/20 p-3">
            <div className="min-w-0">
              <p className="text-xs font-semibold text-foreground truncate">{toggleLabel}</p>
              <p className="text-[10px] text-muted-foreground truncate">
                {language === "ar" ? "تفعيل الميزة لمساحة العمل" : "Enable feature for workspace"}
              </p>
            </div>
            <Switch 
              checked={enabled} 
              onCheckedChange={onToggle} 
              disabled={disabled || addOn.status === "coming_soon"} 
              className="data-[state=checked]:bg-primary"
            />
          </div>
        </CardContent>
      </div>

      <div className="px-6 pb-6 pt-2 flex flex-col gap-2">
        <div className="flex items-center justify-between gap-2 border-t border-border/40 pt-4">
          <Badge variant={enabled && !addOn.comingSoon ? "success" : "secondary"} className={cn(
            "rounded-full text-xs font-medium px-2.5 py-0.5",
            addOn.comingSoon
              ? "bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20"
              : enabled 
                ? "bg-green-500/10 text-green-600 dark:text-green-400 border border-green-500/20" 
                : "bg-muted text-muted-foreground border border-border/30"
          )}>
            {addOn.comingSoon 
              ? (language === "ar" ? "قريباً" : "Coming Soon")
              : (enabled ? (language === "ar" ? "مُفعّل" : "Enabled") : (language === "ar" ? "مُعطّل" : "Disabled"))
            }
          </Badge>

          <div className="flex items-center gap-2">
            {isChannel && enabled && !addOn.comingSoon && (
              <Button
                variant="ghost"
                size="sm"
                className="h-8 rounded-full text-xs font-medium hover:bg-primary/5 hover:text-primary transition-all duration-200"
                onClick={() => router.push("/accounts")}
              >
                {language === "ar" ? "إدارة الاتصال" : "Manage connection"}
              </Button>
            )}

            {addOn.configurable ? (
              <Button 
                variant="outline" 
                size="sm" 
                className={cn(
                  "h-8 rounded-full text-xs font-semibold px-3 shadow-soft hover:bg-muted/80 transition-all duration-200 border-border/80",
                  enabled && !addOn.comingSoon ? "border-primary/30 text-primary hover:bg-primary/5" : ""
                )} 
                onClick={onAction} 
                disabled={disabled || addOn.comingSoon}
              >
                {actionLabel}
              </Button>
            ) : (
              <Button variant="outline" size="sm" className="h-8 rounded-full text-xs font-medium px-3 text-muted-foreground border-border/40" disabled>
                {actionLabel}
              </Button>
            )}
          </div>
        </div>
      </div>
    </Card>
  )
}