"use client"

import { useEffect, useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import { CheckCircle2, CreditCard, Eye, MoreHorizontal, ReceiptText, RefreshCcw, Ticket, User, UserPlus, XCircle } from "lucide-react"
import { toast } from "sonner"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { AdminPageHeader, MetricCard, TableSearch } from "@/components/admin/admin-primitives"
import { useAdminPermissions } from "@/components/admin/admin-shell"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { PaginationControls } from "@/components/admin/table-pagination"
import { TableDateTime } from "@/components/admin/table-date-time"
import { useLanguage } from "@/contexts/language-context"
import { adminStatusT, adminT } from "@/lib/admin-translations"
import { platformApi } from "@/lib/platform-api"

type BookingStatus = "paid" | "pending" | "cancelled" | "refunded"

type Booking = {
  id: string
  registrationId: number
  customer: string
  email: string
  role: string
  event: string
  tickets: number
  amount: number
  currency: string
  method: string
  status: BookingStatus
  createdAt: string
}

function normalizeBooking(row: any): Booking {
  const status = row.order_status === "refunded" ? "refunded" : row.order_status === "cancelled" ? "cancelled" : row.order_status === "paid" ? "paid" : row.registration_status === "cancelled" ? "cancelled" : row.payment_status === "approved" ? "paid" : row.payment_status === "rejected" ? "cancelled" : "pending"
  return {
    id: row.order_number || row.registration_number || `REG-${row.id}`,
    registrationId: Number(row.id),
    customer: row.doctor_name || row.customer_name || "Customer",
    email: row.doctor_email || row.customer_email || "",
    role: row.customer_role_name_en || "Guest",
    event: row.event_title_en || row.event_title_ar || "Event",
    tickets: Number(row.ticket_quantity || 1),
    amount: Number(row.selected_price || row.grand_total || 0),
    currency: row.selected_currency || row.order_currency || row.currency || "USD",
    method: row.payment_method ? String(row.payment_method).replace("bank_account:", "Bank transfer #") : row.payment_reference ? "Bank transfer" : "Pending proof",
    status,
    createdAt: row.created_at || "",
  }
}

function statusClass(status: BookingStatus) {
  if (status === "paid") return "bg-emerald-50 text-emerald-700 hover:bg-emerald-50"
  if (status === "pending") return "bg-amber-50 text-amber-700 hover:bg-amber-50"
  if (status === "refunded") return "bg-slate-100 text-slate-600 hover:bg-slate-100"
  return "bg-red-50 text-red-700 hover:bg-red-50"
}

function money(value: number, currency = "USD") {
  return `${currency} ${Number(value || 0).toLocaleString()}`
}

export function BookingsManager() {
  const { language } = useLanguage()
  const router = useRouter()
  const isAr = language === "ar"
  const { can } = useAdminPermissions()
  const [pending, setPending] = useState<null | { type: "paid" | "refunded" | "cancelled"; booking: Booking }>(null)
  const [bookings, setBookings] = useState<Booking[]>([])
  const [search, setSearch] = useState("")
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(20)
  const [totalBookings, setTotalBookings] = useState(0)

  useEffect(() => {
    let active = true
    platformApi.listRegistrations({ search, limit: pageSize, offset: (page - 1) * pageSize, includeMeta: true })
      .then((result: any) => {
        if (!active) return
        setBookings((result.data || []).map(normalizeBooking))
        setTotalBookings(Number(result.pagination?.total || 0))
      })
      .catch((error) => {
        if (active) toast.error("Could not load bookings", { description: error instanceof Error ? error.message : "Check the backend connection." })
      })
    return () => {
      active = false
    }
  }, [page, pageSize, search])

  useEffect(() => {
    setPage(1)
  }, [search, pageSize])

  const totalPages = Math.max(1, Math.ceil(totalBookings / pageSize))

  const totals = useMemo(() => {
    const paidRevenue = bookings.filter((booking) => booking.status === "paid").reduce((sum, booking) => sum + booking.amount, 0)
    const pendingRevenue = bookings.filter((booking) => booking.status === "pending").reduce((sum, booking) => sum + booking.amount, 0)
    const refundedRevenue = bookings.filter((booking) => booking.status === "refunded").reduce((sum, booking) => sum + booking.amount, 0)
    const cancelled = bookings.filter((booking) => booking.status === "cancelled").length
    return { paidRevenue, pendingRevenue, refundedRevenue, cancelled }
  }, [bookings])

  async function exportOrders() {
    let exportRows = bookings
    try {
      const rows = await platformApi.listRegistrations({ search, limit: 1000, offset: 0 })
      exportRows = (rows || []).map(normalizeBooking)
    } catch (error) {
      toast.error("Export used visible rows", { description: error instanceof Error ? error.message : "Could not load the full filtered order list." })
    }
    const headers = ["#", "Order", "Customer", "Email", "Role", "Event", "Tickets", "Amount", "Currency", "Method", "Status", "Created"]
    const escape = (value: string | number) => `"${String(value ?? "").replace(/"/g, '""')}"`
    const csvRows = exportRows.map((booking, index) => [
      index + 1,
      booking.id,
      booking.customer,
      booking.email,
      booking.role,
      booking.event,
      booking.tickets,
      booking.amount,
      booking.currency,
      booking.method,
      booking.status,
      booking.createdAt,
    ])
    const csv = [headers, ...csvRows].map((row) => row.map(escape).join(",")).join("\n")
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = "stylish-holidays-orders.csv"
    document.body.appendChild(link)
    link.click()
    link.remove()
    URL.revokeObjectURL(url)
    toast.success("Orders exported", { description: `${exportRows.length} booking rows downloaded.` })
  }

  async function updateStatus(booking: Booking, status: BookingStatus) {
    const apiStatus = status === "pending" ? "cancelled" : status
    try {
      await platformApi.updateRegistrationOrderStatus(booking.registrationId, apiStatus)
      setBookings((current) => current.map((item) => item.registrationId === booking.registrationId ? { ...item, status } : item))
      toast.success("Booking updated", { description: `${booking.id} is now ${status}.` })
    } catch (error) {
      toast.error("Booking update failed", { description: error instanceof Error ? error.message : "Could not update this booking." })
    }
  }

  async function runPending() {
    if (!pending) return
    await updateStatus(pending.booking, pending.type)
    setPending(null)
  }

  return (
    <div className="space-y-5">
      <AdminPageHeader
        eyebrow={adminT(language, "bookings.operations")}
        title={adminT(language, "bookings.title")}
        description={adminT(language, "bookings.subtitle")}
        actions={[
          ...(can("registrations.create_manual")
            ? [{ label: language === "ar" ? "حجز يدوي" : "Manual Booking", icon: UserPlus, href: "/admin/registrations/create", variant: "outline" as const }]
            : []),
          { label: adminT(language, "bookings.export"), icon: ReceiptText, onClick: exportOrders },
        ]}
      />

      <div className="grid gap-4 md:grid-cols-4">
        <MetricCard label={adminT(language, "bookings.paidRevenue")} value={money(totals.paidRevenue)} icon={CreditCard} />
        <MetricCard label={adminT(language, "bookings.pendingRevenue")} value={money(totals.pendingRevenue)} icon={RefreshCcw} />
        <MetricCard label={adminT(language, "bookings.refunded")} value={money(totals.refundedRevenue)} icon={XCircle} />
        <MetricCard label={adminT(language, "bookings.cancelled")} value={totals.cancelled} icon={XCircle} />
      </div>

      <Card className="overflow-hidden rounded-[28px] border-0 bg-white shadow-[0_16px_35px_rgba(15,23,42,0.06)]">
        <CardHeader className="flex flex-col gap-3 border-b border-slate-100 md:flex-row md:items-center md:justify-between">
          <div>
            <CardTitle className="text-base font-extrabold">{adminT(language, "bookings.table")}</CardTitle>
            <p className="mt-1 text-sm font-medium text-slate-400">{adminT(language, "bookings.tableCopy")}</p>
          </div>
          <TableSearch value={search} onChange={setSearch} placeholder={adminT(language, "bookings.search")} />
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table className="min-w-[1040px]">
              <TableHeader>
                <TableRow className="bg-slate-50/70 hover:bg-slate-50/70">
                  <TableHead className="w-14">#</TableHead>
                  <TableHead>{language === "ar" ? "الطلب" : "Order"}</TableHead>
                  <TableHead>{adminT(language, "common.customer")}</TableHead>
                  <TableHead>{adminT(language, "common.event")}</TableHead>
                  <TableHead>{adminT(language, "common.tickets")}</TableHead>
                  <TableHead>{adminT(language, "common.amount")}</TableHead>
                  <TableHead>{language === "ar" ? "طريقة الدفع" : "Method"}</TableHead>
                  <TableHead>{adminT(language, "common.status")}</TableHead>
                  <TableHead>{language === "ar" ? "تاريخ الإنشاء" : "Created"}</TableHead>
                  <TableHead className="w-20 text-center">{adminT(language, "common.actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bookings.map((booking, index) => (
                  <TableRow key={booking.id} className="hover:bg-[hsl(var(--primary)/0.04)]">
                    <TableCell className="text-sm font-extrabold text-slate-400">{(page - 1) * pageSize + index + 1}</TableCell>
                    <TableCell><p className="text-sm font-extrabold">{booking.id}</p></TableCell>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[hsl(var(--primary)/0.10)] text-[hsl(var(--primary))]"><User className="h-4 w-4" /></div>
                        <div>
                          <p className="text-sm font-extrabold">{booking.customer}</p>
                          <p className="text-xs font-medium text-slate-400">{booking.email}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="max-w-[240px]"><p className="line-clamp-2 text-sm font-bold text-slate-600">{booking.event}</p></TableCell>
                    <TableCell><Badge className="gap-2 rounded-lg bg-[hsl(var(--primary)/0.08)] text-[hsl(var(--primary))] hover:bg-[hsl(var(--primary)/0.08)]"><Ticket className="h-3.5 w-3.5" /> {booking.tickets}</Badge></TableCell>
                    <TableCell className="font-extrabold whitespace-nowrap">{money(booking.amount, booking.currency)}</TableCell>
                    <TableCell className="text-sm font-semibold text-slate-500">{booking.method}</TableCell>
                    <TableCell><Badge className={statusClass(booking.status)}>{adminStatusT(language, booking.status)}</Badge></TableCell>
                    <TableCell><TableDateTime value={booking.createdAt} /></TableCell>
                    <TableCell>
                      <div className="flex justify-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button size="icon" variant="ghost" className="h-9 w-9 rounded-xl bg-slate-50"><MoreHorizontal className="h-4 w-4" /></Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-48 rounded-2xl border-0 p-2 shadow-xl">
                            <DropdownMenuLabel className="text-xs text-slate-400">{adminT(language, "common.actions")}</DropdownMenuLabel>
                            <DropdownMenuItem
                              className="cursor-pointer rounded-xl px-3 py-2 font-semibold"
                              onSelect={(e) => { e.preventDefault(); router.push(`/admin/orders/${booking.registrationId}`) }}
                            >
                              <Eye className="h-4 w-4" />
                              {adminT(language, "common.viewOrder")}
                            </DropdownMenuItem>
                            {booking.status !== "paid" ? (
                              <DropdownMenuItem
                                className="cursor-pointer rounded-xl px-3 py-2 font-semibold text-emerald-600"
                                onSelect={(e) => { e.preventDefault(); setPending({ type: "paid", booking }) }}
                              >
                                <CheckCircle2 className="h-4 w-4" /> {adminT(language, "common.markPaid")}
                              </DropdownMenuItem>
                            ) : (
                              <DropdownMenuItem disabled className="rounded-xl px-3 py-2 font-semibold text-emerald-600 opacity-50"><CheckCircle2 className="h-4 w-4" /> {adminStatusT(language, "paid")}</DropdownMenuItem>
                            )}
                            <DropdownMenuItem
                              className="cursor-pointer rounded-xl px-3 py-2 font-semibold text-slate-600"
                              onSelect={(e) => { e.preventDefault(); setPending({ type: "refunded", booking }) }}
                            >
                              <RefreshCcw className="h-4 w-4" /> {adminT(language, "common.refund")}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              disabled={booking.status === "paid"}
                              className="cursor-pointer rounded-xl px-3 py-2 font-semibold text-red-600"
                              onSelect={(e) => { e.preventDefault(); setPending({ type: "cancelled", booking }) }}
                            >
                              <XCircle className="h-4 w-4" /> {adminT(language, "common.cancelBooking")}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {bookings.length === 0 && <div className="p-8 text-center text-sm font-semibold text-slate-400">{adminT(language, "bookings.empty")}</div>}
          </div>
          <PaginationControls
            page={page}
            pageSize={pageSize}
            total={totalBookings}
            totalPages={totalPages}
            onPageChange={setPage}
            onPageSizeChange={setPageSize}
          />
        </CardContent>
      </Card>

      {/* Confirm dialog lives outside the DropdownMenu so every row's menu works reliably. */}
      <AlertDialog open={Boolean(pending)} onOpenChange={(open) => { if (!open) setPending(null) }}>
        <AlertDialogContent dir={isAr ? "rtl" : "ltr"} className="max-w-[92vw] rounded-2xl sm:max-w-sm">
          <AlertDialogHeader>
            <AlertDialogTitle>
              {pending?.type === "paid" ? (isAr ? "تعليم كمدفوع؟" : "Mark as paid?") : pending?.type === "refunded" ? (isAr ? "استرداد الحجز؟" : "Refund booking?") : (isAr ? "إلغاء الحجز؟" : "Cancel booking?")}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {pending?.type === "paid"
                ? (isAr ? "سيتم تعليم هذا الطلب كمدفوع." : "This order will be marked as paid.")
                : pending?.type === "refunded"
                  ? (isAr ? "سيتم تعليم هذا الطلب كمسترد." : "This order will be marked refunded.")
                  : (isAr ? "سيتم إلغاء الحجز وإيقاف QR المرتبط." : "This booking will be cancelled and attendee QR will be revoked.")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="grid grid-cols-2 gap-3">
            <AlertDialogCancel className="mt-0 h-10 rounded-xl font-extrabold">{isAr ? "إلغاء" : "Cancel"}</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); runPending() }}
              className={pending?.type === "cancelled" ? "h-10 rounded-xl bg-red-600 font-extrabold text-white hover:bg-red-700" : "h-10 rounded-xl bg-[hsl(var(--primary))] font-extrabold text-white"}
            >
              {pending?.type === "paid" ? adminT(language, "common.markPaid") : pending?.type === "refunded" ? adminT(language, "common.refund") : adminT(language, "common.cancelBooking")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
