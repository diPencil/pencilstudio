"use client"

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { toast } from "sonner"
import { CalendarDays, Camera, CameraOff, CheckCircle2, Clock3, Play, QrCode, RotateCcw, ScanLine, Search, Square, Ticket, UserCheck, XCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ConfirmAction } from "@/components/admin/confirm-action"
import { AdminPageHeader, MetricCard } from "@/components/admin/admin-primitives"
import { useLanguage } from "@/contexts/language-context"
import { adminT } from "@/lib/admin-translations"
import { platformApi } from "@/lib/platform-api"
import jsQR from "jsqr"

type ScanStatus = "idle" | "scanning" | "accepted" | "duplicate" | "invalid" | "revoked" | "wrong_event" | "event_ended" | "camera_error" | "network"

type ScanResult = {
  status: ScanStatus
  message: string
  attendee?: any
  scannedAt?: string
}

type CheckinHistoryRow = {
  id: number
  scan_result: ScanStatus
  scan_source?: "scan" | "manual" | "unknown"
  scanned_at?: string
  attendee_number?: string
  full_name?: string
  email?: string
  event_title_en?: string
  event_title_ar?: string
  ticket_name_en?: string
  ticket_name_ar?: string
  scanned_by_name?: string
  days_attended?: number
  notes?: string
}

type BarcodeDetectorInstance = {
  detect: (source: HTMLVideoElement) => Promise<Array<{ rawValue?: string }>>
}

function formatTime(value?: string, isArabic = false) {
  if (!value) return "-"
  return new Intl.DateTimeFormat(isArabic ? "ar-EG" : "en-US", { hour: "2-digit", minute: "2-digit" }).format(new Date(value))
}

function formatDateTime(value?: string, isArabic = false) {
  if (!value) return "-"
  return new Intl.DateTimeFormat(isArabic ? "ar-EG" : "en", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value))
}

function resultClasses(status: ScanStatus) {
  if (status === "accepted") return "bg-emerald-50 text-emerald-800"
  if (status === "duplicate" || status === "wrong_event") return "bg-amber-50 text-amber-800"
  if (status === "event_ended") return "bg-slate-100 text-slate-700"
  if (status === "revoked" || status === "invalid" || status === "camera_error" || status === "network") return "bg-red-50 text-red-800"
  return "bg-slate-50 text-slate-700"
}

function statusLabel(status: ScanStatus | string | null | undefined, isArabic: boolean) {
  const labels: Record<ScanStatus, [string, string]> = {
    idle: ["Waiting", "في الانتظار"],
    scanning: ["Scanning", "جاري المسح"],
    accepted: ["Accepted", "مقبول"],
    duplicate: ["Duplicate", "مكرر"],
    invalid: ["Invalid", "غير صالح"],
    revoked: ["Revoked", "ملغي"],
    wrong_event: ["Wrong event", "فعالية أخرى"],
    event_ended: ["Event ended", "انتهت الفعالية"],
    camera_error: ["Camera error", "خطأ الكاميرا"],
    network: ["Network error", "خطأ اتصال"],
  }
  const label = status && status in labels ? labels[status as ScanStatus] : ["Unknown", "غير محدد"]
  return isArabic ? label[1] : label[0]
}

function sourceLabel(source: CheckinHistoryRow["scan_source"], isArabic: boolean) {
  if (source === "scan") return isArabic ? "مسح QR" : "QR scan"
  if (source === "manual") return isArabic ? "إدخال يدوي" : "Manual token"
  return isArabic ? "غير محدد" : "Unknown"
}

function classifyError(error: any): ScanStatus {
  const result = error?.details?.result
  if (result === "duplicate" || result === "revoked" || result === "invalid" || result === "wrong_event" || result === "event_ended") return result
  const message = error instanceof Error ? error.message.toLowerCase() : ""
  if (message.includes("already")) return "duplicate"
  if (message.includes("not active")) return "revoked"
  if (message.includes("already ended")) return "event_ended"
  if (message.includes("event")) return "wrong_event"
  if (message.includes("reachable") || message.includes("network")) return "network"
  return "invalid"
}

export function CheckinConsole() {
  const { language } = useLanguage()
  const isArabic = language === "ar"
  const [qrToken, setQrToken] = useState("")
  const [attendees, setAttendees] = useState<any[]>([])
  const [events, setEvents] = useState<any[]>([])
  const [selectedEventId, setSelectedEventId] = useState<string>("all")
  const [result, setResult] = useState<ScanResult>({ status: "idle", message: "" })
  const [logs, setLogs] = useState<ScanResult[]>([])
  const [history, setHistory] = useState<CheckinHistoryRow[]>([])
  const [historySearch, setHistorySearch] = useState("")
  const [historyDate, setHistoryDate] = useState("")
  const [historyLoading, setHistoryLoading] = useState(false)
  const [cameraActive, setCameraActive] = useState(false)
  const [cameraMessage, setCameraMessage] = useState("")
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const frameRef = useRef<number | null>(null)
  const detectorRef = useRef<BarcodeDetectorInstance | null>(null)
  const scanLockRef = useRef(false)
  const lastTokenRef = useRef("")
  const lastScanAtRef = useRef(0)

  const eventContext = selectedEventId === "all" ? undefined : Number(selectedEventId)

  const loadAttendees = useCallback(async () => {
    const rows = await platformApi.listAttendees(eventContext)
    setAttendees(rows || [])
  }, [eventContext])

  const loadHistory = useCallback(async () => {
    setHistoryLoading(true)
    try {
      const rows = await platformApi.listCheckinHistory({ eventId: eventContext, limit: 50, search: historySearch.trim(), date: historyDate || undefined })
      setHistory((rows || []) as CheckinHistoryRow[])
    } finally {
      setHistoryLoading(false)
    }
  }, [eventContext, historyDate, historySearch])

  useEffect(() => {
    Promise.all([
      platformApi.listEvents({ limit: 250 }).then((rows) => setEvents(rows || [])),
      loadAttendees(),
      loadHistory(),
    ]).catch((error) => {
      toast.error(isArabic ? "تعذر تحميل بيانات الدخول" : "Could not load check-in data", { description: error instanceof Error ? error.message : "Check the backend connection." })
    })
  }, [isArabic, loadAttendees, loadHistory])

  const totals = useMemo(() => {
    const checkedIn = attendees.filter((item) => item.checked_in_at || item.qr_status === "used").length
    const cancelled = attendees.filter((item) => item.qr_status === "revoked").length
    return {
      total: attendees.length,
      checkedIn,
      waiting: Math.max(attendees.length - checkedIn - cancelled, 0),
      cancelled,
    }
  }, [attendees])

  const pushLog = (entry: ScanResult) => {
    setResult(entry)
    setLogs((current) => [entry, ...current].slice(0, 8))
  }

  const scanValue = useCallback(async (rawToken: string, source: "scan" | "manual" = "manual") => {
    const token = rawToken.trim()
    const scannedAt = new Date().toISOString()

    if (!token) {
      pushLog({ status: "invalid", message: isArabic ? "أدخل رمز QR أولا" : "Enter QR token first", scannedAt })
      return
    }

    try {
      const attendee = await platformApi.checkin(token, eventContext, source)
      const accepted = { status: "accepted" as const, message: isArabic ? "تم قبول الدخول" : "Check-in accepted", attendee, scannedAt }
      pushLog(accepted)
      setQrToken("")
      await Promise.all([loadAttendees(), loadHistory()])
      toast.success(isArabic ? "تم قبول الدخول" : "Check-in accepted", { description: attendee.full_name || attendee.attendee_number })
    } catch (error: any) {
      const message = error instanceof Error ? error.message : isArabic ? "رمز QR غير صالح" : "Invalid QR token"
      const failed = { status: classifyError(error), message, scannedAt }
      pushLog(failed)
      setQrToken("")
      loadHistory().catch(() => undefined)
      toast.error(isArabic ? "فشل تسجيل الدخول" : "Check-in failed", { description: message })
    }
  }, [eventContext, isArabic, loadAttendees, loadHistory])

  const scanManual = useCallback(() => scanValue(qrToken, "manual"), [qrToken, scanValue])

  const stopCamera = useCallback(() => {
    if (frameRef.current) cancelAnimationFrame(frameRef.current)
    frameRef.current = null
    streamRef.current?.getTracks().forEach((track) => track.stop())
    streamRef.current = null
    if (videoRef.current) videoRef.current.srcObject = null
    scanLockRef.current = false
    setCameraActive(false)
  }, [])

  const loop = useCallback(async () => {
    if (!cameraActive || !videoRef.current) return

    if (!scanLockRef.current && videoRef.current.readyState >= 2) {
      try {
        let token: string | undefined = undefined

        if (detectorRef.current) {
          const codes = await detectorRef.current.detect(videoRef.current)
          token = codes[0]?.rawValue?.trim()
        } else if (canvasRef.current) {
          const canvas = canvasRef.current
          const context = canvas.getContext("2d", { willReadFrequently: true })
          if (context) {
            canvas.width = videoRef.current.videoWidth
            canvas.height = videoRef.current.videoHeight
            context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height)
            const imageData = context.getImageData(0, 0, canvas.width, canvas.height)
            const code = jsQR(imageData.data, imageData.width, imageData.height, { inversionAttempts: "dontInvert" })
            if (code) token = code.data.trim()
          }
        }

        const nowMs = Date.now()
        if (token && (token !== lastTokenRef.current || nowMs - lastScanAtRef.current > 3000)) {
          scanLockRef.current = true
          lastTokenRef.current = token
          lastScanAtRef.current = nowMs
          await scanValue(token, "scan")
          window.setTimeout(() => {
            scanLockRef.current = false
          }, 1200)
        }
      } catch {
        setCameraMessage(isArabic ? "تعذر قراءة الصورة من الكاميرا." : "Could not read the camera frame.")
      }
    }

    frameRef.current = requestAnimationFrame(loop)
  }, [cameraActive, isArabic, scanValue])

  const startCamera = useCallback(async () => {
    setCameraMessage("")
    if (!navigator.mediaDevices?.getUserMedia) {
      const message = isArabic ? "الكاميرا غير مدعومة في هذا المتصفح." : "Camera access is not supported in this browser."
      setCameraMessage(message)
      pushLog({ status: "camera_error", message, scannedAt: new Date().toISOString() })
      return
    }

    const DetectorCtor = (window as any).BarcodeDetector
    if (DetectorCtor) {
      detectorRef.current = new DetectorCtor({ formats: ["qr_code"] })
    } else {
      detectorRef.current = null // Fallback to jsQR will be used
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false })
      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        videoRef.current.setAttribute("playsinline", "true")
        await videoRef.current.play()
      }
      setCameraActive(true)
      setResult({ status: "scanning", message: isArabic ? "وجه الكاميرا إلى رمز QR" : "Point the camera at a QR code" })
    } catch (error) {
      const message = error instanceof Error ? error.message : isArabic ? "تعذر تشغيل الكاميرا." : "Could not start the camera."
      setCameraMessage(message)
      pushLog({ status: "camera_error", message, scannedAt: new Date().toISOString() })
      stopCamera()
    }
  }, [isArabic, stopCamera])

  useEffect(() => {
    if (cameraActive) frameRef.current = requestAnimationFrame(loop)
    return () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current)
    }
  }, [cameraActive, loop])

  useEffect(() => stopCamera, [stopCamera])

  return (
    <div className="space-y-5">
      <AdminPageHeader
        eyebrow={isArabic ? "تسجيل حضور QR" : "QR Check-in"}
        title={adminT(language, "checkin.title")}
        description={isArabic ? "تحقق من تذاكر QR مباشرة من قاعدة البيانات وامنع الدخول المكرر أو الملغي." : "Validate live attendee QR tickets from the database and prevent duplicate, wrong-event, or revoked access."}
      />

      <div className="grid gap-4 md:grid-cols-4">
        <MetricCard label={isArabic ? "إجمالي التذاكر" : "Total Tickets"} value={totals.total} icon={Ticket} />
        <MetricCard label={adminT(language, "overview.checkedIn")} value={totals.checkedIn} icon={UserCheck} />
        <MetricCard label={adminT(language, "status.waiting")} value={totals.waiting} icon={Clock3} />
        <MetricCard label={isArabic ? "ملغي" : "Revoked"} value={totals.cancelled} icon={XCircle} />
      </div>

      <div className="grid gap-5 xl:grid-cols-[1fr_420px]">
        <Card className="rounded-[28px] border-0 bg-white shadow-[0_16px_35px_rgba(15,23,42,0.06)]">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-extrabold">
              <ScanLine className="h-5 w-5 text-[hsl(var(--primary))]" />
              {adminT(language, "checkin.scanOrEnter")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_260px]">
              <div className="overflow-hidden rounded-[26px] border border-slate-100 bg-slate-950">
                <div className="relative aspect-[4/3]">
                  <video ref={videoRef} className="h-full w-full object-cover" muted playsInline />
                  <canvas ref={canvasRef} className="hidden" />
                  {!cameraActive ? (
                    <div className="absolute inset-0 flex items-center justify-center bg-slate-50 text-center">
                      <div>
                        <QrCode className="mx-auto h-20 w-20 text-[#17172f]" />
                        <p className="mt-4 text-sm font-bold text-slate-500">{isArabic ? "منطقة مسح QR للحضور" : "Camera scan area for attendee QR validation"}</p>
                      </div>
                    </div>
                  ) : null}
                  {cameraActive ? <div className="pointer-events-none absolute inset-[18%] rounded-3xl border-2 border-white/80 shadow-[0_0_0_999px_rgba(2,6,23,0.22)]" /> : null}
                </div>
              </div>
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label className="text-sm font-bold">{isArabic ? "نطاق الفعالية" : "Event context"}</Label>
                  <Select value={selectedEventId} onValueChange={(value) => { setSelectedEventId(value); stopCamera() }}>
                    <SelectTrigger className="h-11 rounded-xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{isArabic ? "كل الفعاليات" : "All events"}</SelectItem>
                      {events.map((event) => (
                        <SelectItem key={event.id} value={String(event.id)}>
                          {isArabic ? event.title_ar || event.title_en : event.title_en || event.title_ar}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex gap-2">
                  <Button type="button" onClick={startCamera} disabled={cameraActive} className="h-11 flex-1 rounded-xl bg-[hsl(var(--primary))] font-extrabold text-white">
                    <Play className="h-4 w-4" />
                    {isArabic ? "تشغيل" : "Start"}
                  </Button>
                  <Button type="button" onClick={stopCamera} disabled={!cameraActive} variant="outline" className="h-11 rounded-xl font-extrabold">
                    <Square className="h-4 w-4" />
                    {isArabic ? "إيقاف" : "Stop"}
                  </Button>
                </div>
                <div className="rounded-2xl bg-slate-50 p-3 text-xs font-bold leading-5 text-slate-500">
                  <div className="flex items-center gap-2 text-slate-700">
                    {cameraActive ? <Camera className="h-4 w-4 text-emerald-600" /> : <CameraOff className="h-4 w-4" />}
                    <span>{cameraActive ? (isArabic ? "الكاميرا جاهزة" : "Camera ready") : (isArabic ? "الكاميرا متوقفة" : "Camera stopped")}</span>
                  </div>
                  {cameraMessage ? <p className="mt-2">{cameraMessage}</p> : null}
                </div>
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-[1fr_auto]">
              <div className="space-y-2">
                <Label className="text-sm font-bold">{isArabic ? "رمز QR أو رقم التذكرة" : "QR token or ticket number"}</Label>
                <Input value={qrToken} onChange={(event) => setQrToken(event.target.value)} className="h-11 rounded-xl" placeholder={isArabic ? "الصق رمز QR أو رقم التذكرة" : "Paste QR token or ticket number"} />
              </div>
              <ConfirmAction title="Confirm Check-in" description="The QR token or ticket number will be validated against the live attendee database." confirmLabel="Check in" onConfirm={scanManual} tone="success">
                <Button className="h-11 self-end rounded-xl bg-[hsl(var(--primary))] px-8 font-extrabold text-white">{adminT(language, "checkin.checkIn")}</Button>
              </ConfirmAction>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-[28px] border-0 bg-white shadow-[0_16px_35px_rgba(15,23,42,0.06)]">
          <CardHeader>
            <CardTitle className="flex items-center justify-between gap-3 text-base font-extrabold">
              <span>{adminT(language, "checkin.scanResult")}</span>
              <Button type="button" variant="ghost" className="h-9 rounded-xl" onClick={() => setResult({ status: "idle", message: "" })}>
                <RotateCcw className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`rounded-[26px] p-5 ${resultClasses(result.status)}`}>
              {result.status === "accepted" ? <CheckCircle2 className="h-10 w-10" /> : <XCircle className="h-10 w-10" />}
              <p className="mt-4 text-lg font-extrabold">{result.message || adminT(language, "checkin.waiting")}</p>
              <p className="mt-2 text-xs font-black uppercase">{statusLabel(result.status, isArabic)}</p>
              {result.attendee && (
                <div className="mt-4 space-y-2 text-sm font-semibold">
                  <p>{result.attendee.full_name || result.attendee.attendee_number}</p>
                  <p className="opacity-80">{result.attendee.email}</p>
                </div>
              )}
            </div>
            <div className="mt-5 space-y-2">
              {logs.map((log, index) => (
                <div key={`${log.status}-${index}`} className="flex items-center justify-between gap-3 rounded-2xl border border-slate-100 p-3 text-sm">
                  <div className="min-w-0">
                    <p className="truncate font-extrabold">{log.attendee?.full_name || log.message}</p>
                    <p className="text-xs font-medium text-slate-400">{formatTime(log.scannedAt, isArabic)}</p>
                  </div>
                  <Badge variant={log.status === "accepted" ? "default" : "secondary"} className="shrink-0 capitalize">{statusLabel(log.status, isArabic)}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-[28px] border-0 bg-white shadow-[0_16px_35px_rgba(15,23,42,0.06)]">
        <CardHeader>
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <CardTitle className="flex items-center gap-2 text-base font-extrabold">
              <Clock3 className="h-5 w-5 text-[hsl(var(--primary))]" />
              {isArabic ? "تاريخ تسجيل الحضور" : "Check-in History"}
            </CardTitle>
            <div className="grid w-full gap-2 sm:grid-cols-[180px_1fr] lg:w-[520px]">
              <div className="relative">
                <CalendarDays className="absolute top-3 h-4 w-4 text-slate-400 ltr:left-3 rtl:right-3" />
                <Input
                  type="date"
                  value={historyDate}
                  onChange={(event) => setHistoryDate(event.target.value)}
                  className="h-10 rounded-xl bg-slate-50 ltr:pl-9 rtl:pr-9"
                />
              </div>
              <div className="relative">
                <Search className="absolute top-3 h-4 w-4 text-slate-400 ltr:left-3 rtl:right-3" />
                <Input
                  value={historySearch}
                  onChange={(event) => setHistorySearch(event.target.value)}
                  className="h-10 rounded-xl bg-slate-50 ltr:pl-9 rtl:pr-9"
                  placeholder={isArabic ? "بحث في التاريخ..." : "Search history..."}
                />
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {historyLoading ? (
            <div className="rounded-2xl bg-slate-50 p-5 text-sm font-bold text-slate-500">{isArabic ? "جاري تحميل التاريخ..." : "Loading history..."}</div>
          ) : history.length ? (
            <>
              <div className="hidden overflow-hidden rounded-2xl border border-slate-100 md:block">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 text-xs font-black uppercase tracking-wide text-slate-400">
                    <tr>
                      <th className="px-4 py-3 text-start">{isArabic ? "الوقت" : "Time"}</th>
                      <th className="px-4 py-3 text-start">{isArabic ? "الفعالية" : "Event"}</th>
                      <th className="px-4 py-3 text-start">{isArabic ? "الحاضر" : "Attendee"}</th>
                      <th className="px-4 py-3 text-start">{isArabic ? "التذكرة" : "Ticket"}</th>
                      <th className="px-4 py-3 text-start">{isArabic ? "أيام الحضور" : "Days"}</th>
                      <th className="px-4 py-3 text-start">{isArabic ? "الطريقة" : "Method"}</th>
                      <th className="px-4 py-3 text-start">{isArabic ? "النتيجة" : "Result"}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {history.map((row) => (
                      <tr key={row.id} className="align-top">
                        <td className="px-4 py-3 font-bold text-slate-600">{formatDateTime(row.scanned_at, isArabic)}</td>
                        <td className="px-4 py-3 font-extrabold text-slate-900">{isArabic ? row.event_title_ar || row.event_title_en : row.event_title_en || row.event_title_ar}</td>
                        <td className="px-4 py-3">
                          <p className="font-extrabold text-slate-900">{row.full_name || row.attendee_number || "-"}</p>
                          <p className="mt-1 text-xs font-bold text-slate-400" dir="ltr">{row.email || row.attendee_number}</p>
                        </td>
                        <td className="px-4 py-3 font-bold text-slate-600">{isArabic ? row.ticket_name_ar || row.ticket_name_en : row.ticket_name_en || row.ticket_name_ar || "-"}</td>
                        <td className="px-4 py-3 font-extrabold text-slate-900" dir="ltr">{Number(row.days_attended || 0).toLocaleString()}</td>
                        <td className="px-4 py-3"><Badge variant="outline" className="rounded-full">{sourceLabel(row.scan_source, isArabic)}</Badge></td>
                        <td className="px-4 py-3"><Badge variant={row.scan_result === "accepted" ? "default" : "secondary"} className="rounded-full">{statusLabel((row.scan_result || "invalid") as ScanStatus, isArabic)}</Badge></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="grid gap-3 md:hidden">
                {history.map((row) => (
                  <article key={row.id} className="rounded-2xl border border-slate-100 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="truncate font-extrabold text-slate-900">{row.full_name || row.attendee_number || "-"}</p>
                        <p className="mt-1 text-xs font-bold text-slate-400">{formatDateTime(row.scanned_at, isArabic)}</p>
                      </div>
                      <Badge variant={row.scan_result === "accepted" ? "default" : "secondary"} className="shrink-0 rounded-full">{statusLabel((row.scan_result || "invalid") as ScanStatus, isArabic)}</Badge>
                    </div>
                    <div className="mt-3 grid gap-2 text-sm font-bold text-slate-600">
                      <p>{isArabic ? row.event_title_ar || row.event_title_en : row.event_title_en || row.event_title_ar}</p>
                      <p>{sourceLabel(row.scan_source, isArabic)} · {isArabic ? "أيام الحضور" : "Days"}: <span dir="ltr">{Number(row.days_attended || 0).toLocaleString()}</span></p>
                    </div>
                  </article>
                ))}
              </div>
            </>
          ) : (
            <div className="rounded-2xl bg-slate-50 p-5 text-sm font-bold text-slate-500">{isArabic ? "لا يوجد تاريخ تسجيل حضور لهذه الفعالية بعد." : "No check-in history for this event yet."}</div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
