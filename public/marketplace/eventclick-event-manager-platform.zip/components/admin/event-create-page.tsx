"use client"

import { useEffect, useMemo, useState } from "react"
import Link from "next/link"
import { ArrowLeft, CalendarDays, CheckCircle2, FileText, ImageIcon, MapPin, Search, Settings2, Stethoscope, Ticket, UploadCloud } from "lucide-react"
import type { LucideIcon } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { ConfirmAction } from "@/components/admin/confirm-action"
import { CatalogSelect } from "@/components/admin/catalog-select"
import { ImageGalleryDropzone, ImageUrlDropzone } from "@/components/admin/image-url-dropzone"
import { apiAssetUrl, platformApi } from "@/lib/platform-api"
import { enabledCurrencyRates, formatCurrencyAmount, readCurrencySettings, type CurrencyRate, type CurrencySettings } from "@/lib/currency-settings"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import { useLanguage } from "@/contexts/language-context"
import { adminT } from "@/lib/admin-translations"

type CreateEventForm = {
  titleAr: string
  titleEn: string
  slug: string
  status: "draft" | "published" | "completed" | "disabled"
  type: string
  catalogIds: string[]
  organizer: string
  city: string
  venue: string
  googleMapsUrl: string
  capacity: string
  startsAt: string
  endsAt: string
  registrationOpensAt: string
  registrationClosesAt: string
  publicRegistrationEnabled: boolean
  registrationApprovalMode: "automatic" | "manual_review"
  registrationAccess: "guest_allowed" | "login_required"
  maxTicketsPerCheckout: string
  capacityHoldHoursOverride: string
  manualPaymentEnabled: boolean
  targetAllSpecialties: boolean
  specialtyIds: string[]
  summaryAr: string
  summaryEn: string
  descriptionAr: string
  descriptionEn: string
  agendaAr: string
  agendaEn: string
  checkInNotesAr: string
  checkInNotesEn: string
  termsAr: string
  termsEn: string
  heroImage: string
  detailsImage: string
  eventPdfUrl: string
  galleryImages: string
  seoTitle: string
  seoDescription: string
  seoKeywords: string
}

const initialForm: CreateEventForm = {
  titleAr: "",
  titleEn: "",
  slug: "",
  status: "draft",
  type: "conference",
  catalogIds: [],
  organizer: "Stylish Holidays",
  city: "",
  venue: "",
  googleMapsUrl: "",
  capacity: "",
  startsAt: "",
  endsAt: "",
  registrationOpensAt: "",
  registrationClosesAt: "",
  publicRegistrationEnabled: true,
  registrationApprovalMode: "automatic",
  registrationAccess: "guest_allowed",
  maxTicketsPerCheckout: "1",
  capacityHoldHoursOverride: "",
  manualPaymentEnabled: true,
  targetAllSpecialties: false,
  specialtyIds: [],
  summaryAr: "",
  summaryEn: "",
  descriptionAr: "",
  descriptionEn: "",
  agendaAr: "",
  agendaEn: "",
  checkInNotesAr: "",
  checkInNotesEn: "",
  termsAr: "",
  termsEn: "",
  heroImage: "",
  detailsImage: "",
  eventPdfUrl: "",
  galleryImages: "",
  seoTitle: "",
  seoDescription: "",
  seoKeywords: "",
}

export function EventCreatePage() {
  const { language } = useLanguage()
  const [form, setForm] = useState(initialForm)
  const [saveState, setSaveState] = useState<"idle" | "saved">("idle")
  const [currencySettings, setCurrencySettings] = useState<CurrencySettings>(() => readCurrencySettings())
  const [specialties, setSpecialties] = useState<any[]>([])

  const currencies = useMemo(() => enabledCurrencyRates(currencySettings), [currencySettings])
  const gallery = useMemo(() => form.galleryImages.split("\n").map((item) => item.trim()).filter(Boolean), [form.galleryImages])

  useEffect(() => {
    const syncCurrencySettings = () => setCurrencySettings(readCurrencySettings())
    window.addEventListener("stylish-holidays-currency-settings-updated", syncCurrencySettings)
    window.addEventListener("storage", syncCurrencySettings)
    return () => {
      window.removeEventListener("stylish-holidays-currency-settings-updated", syncCurrencySettings)
      window.removeEventListener("storage", syncCurrencySettings)
    }
  }, [])

  useEffect(() => {
    platformApi.listSpecialties(true).then(setSpecialties).catch(() => setSpecialties([]))
  }, [])

  const setField = <K extends keyof CreateEventForm>(key: K, value: CreateEventForm[K]) => {
    setForm((current) => ({ ...current, [key]: value }))
    setSaveState("idle")
  }

  const saveDraft = async () => {
    if (!form.titleEn.trim()) {
      toast.error(language === "ar" ? "بيانات الفعالية غير مكتملة" : "Missing event data", { description: language === "ar" ? "العنوان العربي والإنجليزي والرابط وتاريخ البداية والنهاية مطلوبة." : "Arabic title, English title, slug, start date, and end date are required." })
      return
    }

    try {
      const event = await platformApi.createEvent({
        slug: form.slug.trim() || null,
        titleAr: form.titleAr.trim() || null,
        titleEn: form.titleEn.trim(),
        summaryAr: form.summaryAr || null,
        summaryEn: form.summaryEn || null,
        descriptionAr: form.descriptionAr || null,
        descriptionEn: form.descriptionEn || null,
        agendaAr: form.agendaAr || null,
        agendaEn: form.agendaEn || null,
        checkInNotesAr: form.checkInNotesAr || null,
        checkInNotesEn: form.checkInNotesEn || null,
        termsAr: form.termsAr || null,
        termsEn: form.termsEn || null,
        type: form.type.toLowerCase(),
        status: form.status,
        startsAt: form.startsAt || null,
        endsAt: form.endsAt || null,
        registrationStartsAt: form.registrationOpensAt || null,
        registrationEndsAt: form.registrationClosesAt || null,
        publicRegistrationEnabled: form.publicRegistrationEnabled,
        registrationApprovalMode: form.registrationApprovalMode,
        registrationAccess: form.registrationAccess,
        maxTicketsPerCheckout: Number(form.maxTicketsPerCheckout) || 1,
        capacityHoldHoursOverride: Number(form.capacityHoldHoursOverride || 0) || null,
        manualPaymentEnabled: form.manualPaymentEnabled,
        timezone: "Africa/Cairo",
        maxAttendees: Number(form.capacity || 0) || null,
        coverImageUrl: form.heroImage || null,
        bannerImageUrl: form.heroImage || null,
        eventDetailsImageUrl: form.detailsImage || null,
        eventPdfUrl: form.eventPdfUrl || null,
        gallery: gallery,
        googleMapsUrl: form.googleMapsUrl || null,
        venueId: null,
        organizerId: null,
        organizerName: form.organizer.trim() || null,
        cityName: form.city.trim() || null,
        venueName: form.venue.trim() || null,
        seoTitle: form.seoTitle.trim() || null,
        seoDescription: form.seoDescription.trim() || null,
        seoKeywords: form.seoKeywords.trim() || null,
        targetAllSpecialties: form.targetAllSpecialties,
        specialtyIds: form.targetAllSpecialties ? [] : form.specialtyIds.map(Number),
        catalogIds: form.catalogIds.map(Number),
      })
      setSaveState("saved")
      toast.success(language === "ar" ? "تم إنشاء الفعالية" : "Event created", { description: language === "ar" ? "تم حفظ الفعالية كمسودة." : "Event was saved." })
    } catch (error) {
      toast.error(language === "ar" ? "فشل إنشاء الفعالية" : "Create event failed", { description: error instanceof Error ? error.message : (language === "ar" ? "راجع اتصال الباك إند." : "Please check the backend connection.") })
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
        <div>
          <Badge className="mb-3 rounded-xl bg-[hsl(var(--primary))] text-white hover:bg-[hsl(var(--primary))]">{adminT(language, "createEvent.badge")}</Badge>
          <h1 className="text-xl font-extrabold tracking-tight text-[#17172f] md:text-2xl">{adminT(language, "createEvent.title")}</h1>
          <p className="mt-2 max-w-3xl text-sm font-medium leading-6 text-slate-500">
            {adminT(language, "createEvent.subtitle")}
          </p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Button asChild variant="outline" className="h-10 rounded-2xl bg-white font-extrabold">
            <Link href="/admin/events">
              <ArrowLeft className="h-4 w-4" />
              {language === "ar" ? "رجوع للفعاليات" : "Back to events"}
            </Link>
          </Button>
          <ConfirmAction title={language === "ar" ? "حفظ مسودة الفعالية؟" : "Save event draft?"} description={language === "ar" ? "سيتم حفظ إعدادات الفعالية والصور والسيو كمسودة." : "The event setup, media, and SEO will be saved as a draft."} confirmLabel={language === "ar" ? "حفظ المسودة" : "Save draft"} onConfirm={saveDraft}>
            <Button className="h-10 rounded-2xl px-5 font-extrabold">
              <CheckCircle2 className="h-4 w-4" />
              {saveState === "saved" ? (language === "ar" ? "تم حفظ المسودة" : "Draft Saved") : adminT(language, "common.save")}
            </Button>
          </ConfirmAction>
        </div>
      </div>

      <div className="grid gap-5 xl:grid-cols-[1fr_360px]">
        <div className="space-y-5">
          <FormPanel icon={FileText} title="Event Identity" description="Arabic and English naming, slug, organizer, type, and publish state.">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Arabic title" value={form.titleAr} dir="rtl" onChange={(value) => setField("titleAr", value)} />
              <Field label="English title" value={form.titleEn} dir="ltr" onChange={(value) => setField("titleEn", value)} />
            </div>
            <div className="mt-4 grid gap-4 lg:grid-cols-3">
              <Field label="Slug" value={form.slug} dir="ltr" onChange={(value) => setField("slug", value)} />
              <SelectField label="Type" value={form.type} onChange={(value) => setField("type", value)} options={["conference", "exhibition", "forum", "workshop", "festival", "webinar", "other"]} />
              <Field label="Max attendees" value={form.capacity} onChange={(value) => setField("capacity", value)} type="number" />
            </div>
            <div className="mt-4 grid gap-4 lg:grid-cols-2">
              <CatalogSelect selectedIds={form.catalogIds} onChange={(catalogIds) => setField("catalogIds", catalogIds)} compact />
              <div className="space-y-4">
                <Field label="Organizer" value={form.organizer} onChange={(value) => setField("organizer", value)} />
                <div>
                  <Select value={form.status} onValueChange={(value) => setField("status", value as any)}>
                    <SelectTrigger className="h-11 rounded-2xl border-slate-200 bg-slate-50 font-bold">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft (Hidden)</SelectItem>
                      <SelectItem value="published">{language === "ar" ? "منشور (القادم / السابق تلقائيًا حسب تاريخ النهاية)" : "Published (auto Upcoming / Previous by end date)"}</SelectItem>
                      <SelectItem value="disabled">Disabled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </FormPanel>

          <FormPanel icon={Stethoscope} title={language === "ar" ? "التخصصات المستهدفة" : "Target Specialties"} description={language === "ar" ? "تحدد هذه الخيارات توصيات الأطباء وإشعاراتهم فقط، ولا تخفي الفعالية من الموقع العام." : "These options power doctor recommendations and notifications only; public browsing still shows published events."}>
            <div className="space-y-3">
              <label className="flex min-h-12 cursor-pointer items-center gap-3 rounded-2xl bg-slate-50 px-4 text-sm font-extrabold text-slate-700">
                <Checkbox checked={form.targetAllSpecialties} onCheckedChange={(checked) => setField("targetAllSpecialties", Boolean(checked))} />
                {language === "ar" ? "كل التخصصات" : "All Specialties"}
              </label>
              {!form.targetAllSpecialties ? (
                <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                  {specialties.map((specialty) => {
                    const id = String(specialty.id)
                    const checked = form.specialtyIds.includes(id)
                    return (
                      <label key={id} className="flex min-h-11 cursor-pointer items-center gap-3 rounded-2xl border border-slate-100 bg-white px-3 text-sm font-bold text-slate-600">
                        <Checkbox checked={checked} onCheckedChange={(value) => setField("specialtyIds", value ? [...form.specialtyIds, id] : form.specialtyIds.filter((item) => item !== id))} />
                        {language === "ar" ? specialty.nameAr : specialty.nameEn}
                      </label>
                    )
                  })}
                </div>
              ) : null}
            </div>
          </FormPanel>

          <FormPanel icon={MapPin} title="Venue & Capacity" description="Location details and maximum available seats for the event.">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="City" value={form.city} onChange={(value) => setField("city", value)} />
              <Field label="Venue" value={form.venue} onChange={(value) => setField("venue", value)} />
            </div>
          </FormPanel>

          <FormPanel icon={CalendarDays} title="Dates & Registration" description="Separate event schedule from registration availability.">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Event starts" value={form.startsAt} onChange={(value) => setField("startsAt", value)} type="datetime-local" />
              <Field label="Event ends" value={form.endsAt} onChange={(value) => setField("endsAt", value)} type="datetime-local" />
              <Field label="Registration opens" value={form.registrationOpensAt} onChange={(value) => setField("registrationOpensAt", value)} type="datetime-local" />
              <Field label="Registration closes" value={form.registrationClosesAt} onChange={(value) => setField("registrationClosesAt", value)} type="datetime-local" />
            </div>
          </FormPanel>
          <FormPanel icon={Settings2} title={language === "ar" ? "التسجيل والدفع" : "Registration & Checkout"} description={language === "ar" ? "تحكم في سلوك التسجيل العام والمراجعة والدفع لهذه الفعالية." : "Control public registration, review, and payment behavior for this event."}>
            <div className="grid gap-4 md:grid-cols-2">
              <Select value={form.publicRegistrationEnabled ? "enabled" : "disabled"} onValueChange={(value) => setField("publicRegistrationEnabled", value === "enabled")}>
                <SelectTrigger className="h-11 rounded-2xl border-slate-200 bg-slate-50 font-bold"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="enabled">{language === "ar" ? "تفعيل التسجيل العام" : "Public registration enabled"}</SelectItem>
                  <SelectItem value="disabled">{language === "ar" ? "إيقاف التسجيل العام" : "Public registration disabled"}</SelectItem>
                </SelectContent>
              </Select>
              <Select value={form.registrationApprovalMode} onValueChange={(value) => setField("registrationApprovalMode", value as CreateEventForm["registrationApprovalMode"])}>
                <SelectTrigger className="h-11 rounded-2xl border-slate-200 bg-slate-50 font-bold"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="automatic">{language === "ar" ? "اعتماد تلقائي" : "Automatic approval"}</SelectItem>
                  <SelectItem value="manual_review">{language === "ar" ? "مراجعة يدوية" : "Manual review"}</SelectItem>
                </SelectContent>
              </Select>
              <Select value={form.registrationAccess} onValueChange={(value) => setField("registrationAccess", value as CreateEventForm["registrationAccess"])}>
                <SelectTrigger className="h-11 rounded-2xl border-slate-200 bg-slate-50 font-bold"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="guest_allowed">{language === "ar" ? "السماح للضيف والعميل" : "Guest and customer checkout"}</SelectItem>
                  <SelectItem value="login_required">{language === "ar" ? "تسجيل الدخول مطلوب" : "Login required"}</SelectItem>
                </SelectContent>
              </Select>
              <Select value={form.manualPaymentEnabled ? "enabled" : "disabled"} onValueChange={(value) => setField("manualPaymentEnabled", value === "enabled")}>
                <SelectTrigger className="h-11 rounded-2xl border-slate-200 bg-slate-50 font-bold"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="enabled">{language === "ar" ? "تفعيل التحويل البنكي" : "Manual bank payment enabled"}</SelectItem>
                  <SelectItem value="disabled">{language === "ar" ? "إيقاف التحويل البنكي" : "Manual bank payment disabled"}</SelectItem>
                </SelectContent>
              </Select>
              <Field label={language === "ar" ? "أقصى عدد تذاكر في الطلب" : "Maximum tickets per checkout"} value={form.maxTicketsPerCheckout} onChange={(value) => setField("maxTicketsPerCheckout", value)} type="number" />
              <Field label={language === "ar" ? "مدة حجز المقعد بالساعات" : "Seat reservation hours override"} value={form.capacityHoldHoursOverride} onChange={(value) => setField("capacityHoldHoursOverride", value)} type="number" />
            </div>
          </FormPanel>

          <FormPanel icon={ImageIcon} title="Event Media" description="Hero image and gallery images shown on the public event page.">
            <div className="grid gap-4 lg:grid-cols-[1fr_300px]">
              <div className="space-y-4">
                <ImageUrlDropzone label="Event image URL" value={form.heroImage} onChange={(value) => setField("heroImage", value)} />
                <ImageUrlDropzone label="Event details image URL" value={form.detailsImage} onChange={(value) => setField("detailsImage", value)} />
                <PdfUploadField value={form.eventPdfUrl} onChange={(value) => setField("eventPdfUrl", value)} />
                <ImageGalleryDropzone label="Gallery images" value={form.galleryImages} onChange={(value) => setField("galleryImages", value)} />
              </div>
              <div className="rounded-[22px] border border-slate-100 bg-slate-50 p-3">
                <div className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-slate-200">
                  {form.heroImage ? <img src={apiAssetUrl(form.heroImage)} alt="Event hero preview" className="h-full w-full object-cover" /> : <MediaEmpty />}
                </div>
                <div className="mt-3 grid grid-cols-3 gap-2">
                  {gallery.slice(0, 6).map((image) => (
                    <div key={image} className="aspect-square overflow-hidden rounded-xl bg-white">
                      <img src={apiAssetUrl(image)} alt="Event gallery preview" className="h-full w-full object-cover" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </FormPanel>

          <FormPanel icon={Settings2} title="Content & Operations" description="Public descriptions plus internal notes for support, check-in, and attendee rules.">
            <div className="grid gap-4 md:grid-cols-2">
              <TextAreaField label="Arabic summary" value={form.summaryAr} dir="rtl" onChange={(value) => setField("summaryAr", value)} />
              <TextAreaField label="English summary" value={form.summaryEn} dir="ltr" onChange={(value) => setField("summaryEn", value)} />
              <TextAreaField label="Arabic description" value={form.descriptionAr} dir="rtl" onChange={(value) => setField("descriptionAr", value)} />
              <TextAreaField label="English description" value={form.descriptionEn} dir="ltr" onChange={(value) => setField("descriptionEn", value)} />
              <Field label="Google maps URL" value={form.googleMapsUrl} dir="ltr" onChange={(value) => setField("googleMapsUrl", value)} className="md:col-span-2" />
              <TextAreaField label="Arabic agenda" value={form.agendaAr} dir="rtl" onChange={(value) => setField("agendaAr", value)} />
              <TextAreaField label="English agenda" value={form.agendaEn} dir="ltr" onChange={(value) => setField("agendaEn", value)} />
              <TextAreaField label="Arabic check-in notes" value={form.checkInNotesAr} dir="rtl" onChange={(value) => setField("checkInNotesAr", value)} />
              <TextAreaField label="English check-in notes" value={form.checkInNotesEn} dir="ltr" onChange={(value) => setField("checkInNotesEn", value)} />
              <TextAreaField label="Arabic ticket terms" value={form.termsAr} dir="rtl" onChange={(value) => setField("termsAr", value)} />
              <TextAreaField label="English ticket terms" value={form.termsEn} dir="ltr" onChange={(value) => setField("termsEn", value)} />
            </div>
          </FormPanel>

          <FormPanel icon={Search} title="SEO" description="Metadata used by the public event page and social previews.">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="SEO title" value={form.seoTitle} onChange={(value) => setField("seoTitle", value)} />
              <Field label="Keywords" value={form.seoKeywords} onChange={(value) => setField("seoKeywords", value)} />
              <TextAreaField label="SEO description" value={form.seoDescription} onChange={(value) => setField("seoDescription", value)} />
            </div>
          </FormPanel>
        </div>

        <aside className="space-y-5">
          <Card className="sticky top-4 rounded-[28px] border-0 bg-white shadow-[0_18px_45px_rgba(15,23,42,0.07)]">
            <CardHeader>
              <CardTitle className="text-base font-extrabold text-[#17172f]">{adminT(language, "createEvent.eventPreview")}</CardTitle>
              <p className="text-sm font-medium text-slate-400">{adminT(language, "createEvent.previewCopy")}</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="overflow-hidden rounded-[24px] bg-slate-950">
                <div className="aspect-[4/3] bg-slate-200">
                  {form.heroImage ? <img src={apiAssetUrl(form.heroImage)} alt="Event preview" className="h-full w-full object-cover" /> : <MediaEmpty />}
                </div>
                <div className="p-4 text-white">
                  <Badge className="mb-3 rounded-xl bg-white/15 text-white hover:bg-white/15">{form.type}</Badge>
                  <h2 className="text-lg font-extrabold">{form.titleEn || "Event title"}</h2>
                  <p className="mt-2 text-sm font-medium text-white/70">{form.venue}</p>
                </div>
              </div>
              <SummaryItem label="Display Page" value={form.status === "published" ? "Published (Visible)" : form.status === "draft" ? "Draft (Hidden)" : "Disabled"} />
              <SummaryItem label="Seats" value={Number(form.capacity || 0).toLocaleString()} />
              <ConfirmAction title="Save event draft?" description="This will save the current event setup as a draft workflow." confirmLabel="Save draft" onConfirm={saveDraft}>
                <Button className="h-11 w-full rounded-2xl font-extrabold">
                  <CheckCircle2 className="h-4 w-4" />
                  {saveState === "saved" ? "Draft Saved" : "Save Event"}
                </Button>
              </ConfirmAction>
            </CardContent>
          </Card>
        </aside>
      </div>
    </div>
  )
}

function FormPanel({ icon: Icon, title, description, children }: { icon: LucideIcon; title: string; description: string; children: React.ReactNode }) {
  return (
    <Card className="rounded-[28px] border-0 bg-white shadow-[0_16px_35px_rgba(15,23,42,0.055)]">
      <CardHeader className="flex flex-row items-start gap-3 space-y-0">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[hsl(var(--primary)/0.10)] text-[hsl(var(--primary))]">
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <CardTitle className="text-base font-extrabold text-[#17172f]">{title}</CardTitle>
          <p className="mt-1 text-sm font-medium leading-6 text-slate-500">{description}</p>
        </div>
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  )
}

function Field({ label, value, onChange, type = "text", className, disabled, dir }: { label: string; value: string; onChange: (value: string) => void; type?: string; className?: string; disabled?: boolean; dir?: "ltr" | "rtl" }) {
  return (
    <div className={cn("space-y-2", className)}>
      <Label className="text-xs font-extrabold uppercase tracking-[0.08em] text-slate-500">{label}</Label>
      <Input
        type={type}
        value={value}
        dir={dir}
        onChange={(event) => onChange(event.target.value)}
        disabled={disabled}
        className={cn("h-11 rounded-2xl border-slate-200 bg-slate-50 font-bold disabled:opacity-70", dir === "rtl" && "text-right")}
      />
    </div>
  )
}

function TextAreaField({ label, value, onChange, dir }: { label: string; value: string; onChange: (value: string) => void; dir?: "ltr" | "rtl" }) {
  return (
    <div className="space-y-2">
      <Label className="text-xs font-extrabold uppercase tracking-[0.08em] text-slate-500">{label}</Label>
      <Textarea
        value={value}
        dir={dir}
        onChange={(event) => onChange(event.target.value)}
        className={cn("min-h-[112px] rounded-2xl border-slate-200 bg-slate-50 font-semibold leading-6", dir === "rtl" && "text-right")}
      />
    </div>
  )
}

function SelectField({ label, value, onChange, options }: { label: string; value: string; onChange: (value: string) => void; options: string[] }) {
  return (
    <div className="space-y-2">
      <Label className="text-xs font-extrabold uppercase tracking-[0.08em] text-slate-500">{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="h-11 rounded-2xl border-slate-200 bg-slate-50 font-bold">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {options.map((option) => <SelectItem key={option} value={option}>{option}</SelectItem>)}
        </SelectContent>
      </Select>
    </div>
  )
}

function CurrencySelect({ value, onChange, currencies }: { value: string; onChange: (value: string) => void; currencies: CurrencyRate[] }) {
  const { language } = useLanguage()
  return (
    <div className="space-y-2">
      <Label className="text-xs font-extrabold uppercase tracking-[0.08em] text-slate-500">{adminT(language, "common.currency")}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="h-11 rounded-2xl border-slate-200 bg-slate-50 font-bold">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {currencies.map((currency) => (
            <SelectItem key={currency.code} value={currency.code}>
              {currency.code} - {currency.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

function PdfUploadField({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  const { language } = useLanguage()
  const [uploading, setUploading] = useState(false)

  async function upload(file?: File | null) {
    if (!file) return
    if (file.type !== "application/pdf") {
      toast.error(language === "ar" ? "ملف PDF فقط" : "PDF only")
      return
    }
    setUploading(true)
    try {
      const uploaded = await platformApi.uploadPlatformAssetFile(file)
      onChange(uploaded.url || "")
      toast.success(language === "ar" ? "تم رفع ملف الفعالية" : "Event PDF uploaded")
    } catch (error) {
      toast.error(language === "ar" ? "فشل رفع PDF" : "PDF upload failed", { description: error instanceof Error ? error.message : "" })
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="space-y-2">
      <Label className="text-xs font-extrabold uppercase tracking-[0.08em] text-slate-500">{language === "ar" ? "ملف الفعالية PDF" : "Event PDF"}</Label>
      <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50 p-4">
        <Input type="file" accept="application/pdf" disabled={uploading} onChange={(event) => upload(event.target.files?.[0])} className="h-11 rounded-xl bg-white font-bold" />
        {value ? (
          <div className="mt-3 flex flex-wrap gap-2">
            <Button asChild variant="outline" className="h-9 rounded-xl text-xs font-bold">
              <Link href={apiAssetUrl(value)} target="_blank">{language === "ar" ? "عرض PDF" : "View PDF"}</Link>
            </Button>
            <Button type="button" variant="outline" onClick={() => onChange("")} className="h-9 rounded-xl text-xs font-bold text-red-600">
              {language === "ar" ? "إزالة" : "Remove"}
            </Button>
          </div>
        ) : null}
      </div>
    </div>
  )
}

function SummaryItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl bg-slate-50 px-4 py-3">
      <span className="text-xs font-extrabold uppercase tracking-[0.08em] text-slate-400">{label}</span>
      <span className="text-sm font-extrabold text-[#17172f]">{value}</span>
    </div>
  )
}

function MediaEmpty() {
  const { language } = useLanguage()
  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-2 text-slate-400">
      <UploadCloud className="h-8 w-8" />
      <span className="text-xs font-extrabold">{adminT(language, "common.imagePreview")}</span>
    </div>
  )
}
