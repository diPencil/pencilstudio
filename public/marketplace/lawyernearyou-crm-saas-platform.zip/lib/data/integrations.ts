export type IntegrationCategory = 'Storage' | 'Communications' | 'Finance' | 'Productivity';

export interface IntegrationApp {
    id: string
    name: string
    category: IntegrationCategory
    description: { en: string; ar: string }
    connected: boolean
    iconName: string // Store the string name of the icon to avoid passing React components in pure data files
}

export const initialApps: IntegrationApp[] = [
    {
        id: 'google-drive',
        name: 'Google Drive',
        category: 'Storage',
        description: {
            en: 'Sync case files directly to your drive.',
            ar: 'مزامنة ملفات القضايا مباشرة مع جوجل درايف.'
        },
        connected: true,
        iconName: 'Globe'
    },
    {
        id: 'zoom',
        name: 'Zoom',
        category: 'Communications',
        description: {
            en: 'Automate virtual consultations and hearings.',
            ar: 'أتمتة الاستشارات والجلسات الافتراضية.'
        },
        connected: false,
        iconName: 'Activity'
    },
    {
        id: 'stripe',
        name: 'Stripe',
        category: 'Finance',
        description: {
            en: 'Accept online payments for invoices.',
            ar: 'قبول المدفوعات عبر الإنترنت للفواتير.'
        },
        connected: true,
        iconName: 'Zap'
    },
    {
        id: 'slack',
        name: 'Slack',
        category: 'Productivity',
        description: {
            en: 'Get real-time case updates in your channels.',
            ar: 'احصل على تحديثات القضايا في قنوات سلاك.'
        },
        connected: false,
        iconName: 'MessageSquare'
    },
    {
        id: 'whatsapp',
        name: 'WhatsApp Business',
        category: 'Communications',
        description: {
            en: 'Send automated hearing reminders to clients.',
            ar: 'إرسال تذكيرات تلقائية بالجلسات للعملاء.'
        },
        connected: false,
        iconName: 'Mail'
    },
    {
        id: 'google-meet',
        name: 'Google Meet',
        category: 'Communications',
        description: {
            en: 'Schedule and join case hearings via Google Meet.',
            ar: 'جدولة الانضمام إلى جلسات القضايا عبر جوجل ميت.'
        },
        connected: false,
        iconName: 'Video'
    },
]
