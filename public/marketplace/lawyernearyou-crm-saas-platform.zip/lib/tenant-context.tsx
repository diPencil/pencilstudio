'use client'

import React, { createContext, useContext, useEffect, useState } from 'react'

export type Tenant = {
    id: string
    name: string
    subdomain?: string | null
    customDomain?: string | null
    logoUrl?: string | null
    primaryColor: string
    accentColor: string
    brandName?: string | null
    phone?: string | null
    address?: string | null
    email?: string | null
    website?: string | null
    description?: string | null
    plan: 'Starter' | 'Pro' | 'Enterprise'
}

interface TenantContextType {
    currentTenant: Tenant
    isLoading: boolean
    updateBranding: (branding: Partial<Tenant>) => Promise<void>
}

const TenantContext = createContext<TenantContextType | undefined>(undefined)

export function TenantProvider({ children }: { children: React.ReactNode }) {
    const [currentTenant, setCurrentTenant] = useState<Tenant>({
        id: 'default',
        name: 'LawCRM Default',
        primaryColor: '#14b8a6',
        accentColor: '#0f766e',
        plan: 'Pro'
    })
    const [isLoading, setIsLoading] = useState(true)

    useEffect(() => {
        const fetchBranding = async () => {
            try {
                // In a real SaaS, this would detect domain/subdomain
                // For now, we fetch the first org from our SQLite
                const res = await fetch('/api/tenant/branding')
                if (res.ok) {
                    const data = await res.json()
                    setCurrentTenant(data)
                    applyBranding(data)
                }
            } catch (err) {
                console.error('Failed to fetch tenant branding:', err)
            } finally {
                setIsLoading(false)
            }
        }
        fetchBranding()
    }, [])

    const applyBranding = (tenant: Tenant) => {
        if (typeof document !== 'undefined') {
            const root = document.documentElement
            // We convert HEX to OKLCH or use hex directly if preferred
            // For simplicity with Tailwind, let's inject them as variables
            root.style.setProperty('--primary-hex', tenant.primaryColor)
            root.style.setProperty('--accent-hex', tenant.accentColor)
            
            // If you want to overwrite Tailwind's primary dynamically:
            // This requires using a color library or simple hex injection
            // For now, we'll just set the variables that globals.css will use
        }
    }

    const updateBranding = async (branding: Partial<Tenant>) => {
        const res = await fetch('/api/tenant/branding', {
            method: 'PATCH',
            body: JSON.stringify(branding),
        })
        if (res.ok) {
            const updated = await res.json()
            setCurrentTenant(updated)
            applyBranding(updated)
        }
    }

    const value = React.useMemo(() => ({ 
        currentTenant, 
        isLoading, 
        updateBranding 
    }), [currentTenant, isLoading])

    return (
        <TenantContext.Provider value={value}>
            {children}
        </TenantContext.Provider>
    )
}

export function useTenant() {
    const context = useContext(TenantContext)
    if (context === undefined) {
        throw new Error('useTenant must be used within a TenantProvider')
    }
    return context
}

export const mockTenants = [
    {
        id: '1',
        name: 'Al-Tamimi & Co.',
        domain: 'altamimi',
        plan: 'Enterprise' as const,
        status: 'active',
        mrr: 25000,
        users: 124,
        joined: '2025-01-15',
    },
    {
        id: '2',
        name: 'Cairo Legal Alliance',
        domain: 'cla',
        plan: 'Pro' as const,
        status: 'active',
        mrr: 8500,
        users: 42,
        joined: '2025-03-10',
    },
    {
        id: '3',
        name: 'Mansour & Associates',
        domain: 'mansour-law',
        plan: 'Starter' as const,
        status: 'past_due',
        mrr: 3200,
        users: 8,
        joined: '2025-04-01',
    },
    {
        id: '4',
        name: 'Nile Juris Chambers',
        domain: 'nile-juris',
        plan: 'Enterprise' as const,
        status: 'suspended',
        mrr: 0,
        users: 85,
        joined: '2024-11-20',
    }
]
