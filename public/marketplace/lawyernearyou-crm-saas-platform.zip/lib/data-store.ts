import useSWR, { mutate } from 'swr'
import type { LegalCase, Client, Consultation, CaseHistory, AgentSettings, User, Invoice, CaseTask, LegalDocument, PaymentLog } from './types'

/**
 * LawCRM Professional Data Store (SQLite + Prisma Edition)
 */

const fetcher = (url: string) => fetch(url).then((res) => res.json())

// Hooks - Cases
export function useCases() {
  const { data, error, isLoading } = useSWR<LegalCase[]>('/api/cases', fetcher)
  return { cases: data ?? [], error, isLoading }
}

export function useCase(id: string) {
  const { data, error, isLoading } = useSWR<LegalCase>(id ? `/api/cases/${id}` : null, fetcher)
  return { legalCase: data, error, isLoading }
}

// Hooks - Clients
export function useClients() {
  const { data, error, isLoading } = useSWR<Client[]>('/api/clients', fetcher)
  return { clients: data ?? [], error, isLoading }
}

export function useClient(id: string) {
  const { data, error, isLoading } = useSWR<Client>(id ? `/api/clients/${id}` : null, fetcher)
  return { client: data, error, isLoading }
}

// Hooks - Consultations
export function useConsultations() {
  const { data, error, isLoading } = useSWR<Consultation[]>('/api/consultations', fetcher)
  return { consultations: data ?? [], error, isLoading }
}

// Hooks - Users
export function useUsers() {
  const { data, error, isLoading } = useSWR<User[]>('/api/users', fetcher)
  return { users: data ?? [], error, isLoading }
}

// Hooks - Invoices
export function useInvoices(clientId?: string) {
  const url = clientId ? `/api/invoices?clientId=${clientId}` : '/api/invoices'
  const { data, error, isLoading } = useSWR<Invoice[]>(url, fetcher)
  return { invoices: data ?? [], error, isLoading }
}

// Hooks - Tasks
export function useTasks(caseId?: string) {
  const url = caseId ? `/api/tasks?caseId=${caseId}` : '/api/tasks'
  const { data, error, isLoading } = useSWR<CaseTask[]>(url, fetcher)
  return { tasks: data ?? [], error, isLoading }
}

// Hooks - Documents
export function useDocuments(caseId?: string) {
  const url = caseId ? `/api/documents?caseId=${caseId}` : '/api/documents'
  const { data, error, isLoading } = useSWR<LegalDocument[]>(url, fetcher)
  return { documents: data ?? [], error, isLoading }
}

// Hooks - Agent Settings (The missing export)
export function useAgentSettings() {
  const { data, error, isLoading } = useSWR<AgentSettings>('/api/settings/agent', fetcher)
  return { settings: data, error, isLoading }
}

// Mutations - CRUD placeholders (These will call our new APIs)
export const addCase = async (data: Partial<LegalCase>) => {
  const res = await fetch('/api/cases', {
    method: 'POST',
    body: JSON.stringify(data),
  })
  mutate('/api/cases')
  return res.json()
}

export const updateCase = async (id: string, data: Partial<LegalCase>) => {
  const res = await fetch(`/api/cases/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
  mutate('/api/cases')
  mutate(`/api/cases/${id}`)
  return res.json()
}

export const deleteCase = async (id: string) => {
  const res = await fetch(`/api/cases/${id}`, {
    method: 'DELETE',
  })
  mutate('/api/cases')
  return res.json()
}

export const addClient = async (data: Partial<Client>) => {
  const res = await fetch('/api/clients', {
    method: 'POST',
    body: JSON.stringify(data),
  })
  mutate('/api/clients')
  return res.json()
}

export const updateClient = async (id: string, data: Partial<Client>) => {
  const res = await fetch(`/api/clients/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
  mutate('/api/clients')
  mutate(`/api/clients/${id}`)
  return res.json()
}

export const deleteClient = async (id: string) => {
  const res = await fetch(`/api/clients/${id}`, {
    method: 'DELETE',
  })
  mutate('/api/clients')
  return res.json()
}

export const addConsultation = async (data: Partial<Consultation>) => {
  const res = await fetch('/api/consultations', {
    method: 'POST',
    body: JSON.stringify(data),
  })
  mutate('/api/consultations')
  return res.json()
}

export const updateConsultation = async (id: string, data: Partial<Consultation>) => {
  const res = await fetch(`/api/consultations/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
  mutate('/api/consultations')
  mutate(`/api/consultations/${id}`)
  return res.json()
}

export const deleteConsultation = async (id: string) => {
  const res = await fetch(`/api/consultations/${id}`, {
    method: 'DELETE',
  })
  mutate('/api/consultations')
  return res.json()
}

export const addInvoice = async (data: Partial<Invoice> & { items?: any[] }) => {
  const res = await fetch('/api/invoices', {
    method: 'POST',
    body: JSON.stringify(data),
  })
  mutate('/api/invoices')
  return res.json()
}

export const updateInvoice = async (id: string, data: Partial<Invoice>) => {
  const res = await fetch(`/api/invoices/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
  mutate('/api/invoices')
  mutate(`/api/invoices/${id}`)
  return res.json()
}

export const addCaseHistory = async (data: Partial<CaseHistory>) => {
  const res = await fetch('/api/case-history', {
    method: 'POST',
    body: JSON.stringify(data),
  })
  mutate('/api/case-history')
  mutate('/api/cases')
  if (data.caseId) {
    mutate(`/api/cases/${data.caseId}`)
    mutate(`/api/case-history?caseId=${data.caseId}`)
  }
  return res.json()
}

export const updateAgentSettings = async (data: Partial<AgentSettings>) => {
  const res = await fetch('/api/settings/agent', {
    method: 'POST',
    body: JSON.stringify(data),
  })
  mutate('/api/settings/agent')
  return res.json()
}

// Helper utilities
export function useCaseHistory(caseId?: string) {
  const url = caseId ? `/api/case-history?caseId=${caseId}` : '/api/case-history'
  const { data, error, isLoading } = useSWR<CaseHistory[]>(url, fetcher)
  return { history: data ?? [], error, isLoading }
}

export function usePaymentLogs(invoiceId?: string) {
  const url = invoiceId ? `/api/payments?invoiceId=${invoiceId}` : '/api/payments'
  const { data, error, isLoading } = useSWR<PaymentLog[]>(url, fetcher)
  return { paymentLogs: data ?? [], error, isLoading }
}
