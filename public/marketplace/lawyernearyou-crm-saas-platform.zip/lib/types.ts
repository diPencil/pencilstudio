import React from "react"

export type UserRole = 'admin' | 'lawyer' | 'assistant' | 'accountant'

export interface User {
  id: string
  tenantId: string
  name: string
  email: string
  role: UserRole
  avatarUrl?: string
  lastActive: string
}

export interface LegalCase {
  id: string
  tenantId: string
  name: string
  caseType: 'civil' | 'criminal' | 'corporate' | 'family' | 'labor' | 'estate' | 'other'
  category: string
  filingDate: string
  priority: 'low' | 'medium' | 'high' | 'urgent'
  status: 'active' | 'closed' | 'pending' | 'on-hold'
  clientId: string
  assignedLawyerId: string
  courtName?: string
  circleNumber?: string
  caseNumber?: string // Official Court Case Number
  notes: string
  createdAt: string
}

export interface Client {
  id: string
  tenantId: string
  firstName: string
  lastName: string
  email: string
  phone: string
  address: string
  nationalId?: string // Egyptian context
  caseIds: string[]
  createdAt: string
}

export interface Consultation {
  id: string
  tenantId: string
  caseId: string
  clientId: string
  date: string
  time: string
  type: 'initial' | 'follow-up' | 'strategy' | 'court-prep' | 'emergency' | 'mediation'
  status: 'scheduled' | 'confirmed' | 'in-progress' | 'completed' | 'cancelled'
  notes: string
  lawyerId: string
  createdAt: string
}

export interface CaseHistory {
  id: string
  tenantId: string
  caseId: string
  consultationId?: string
  date: string
  type: 'filing' | 'evidence' | 'judgment' | 'hearing' | 'mediation' | 'note'
  title: string
  description: string
  lawyerId: string
  attachments?: string[]
  createdAt: string
}

export interface CaseTask {
  id: string
  tenantId: string
  caseId: string
  title: string
  description?: string
  assignedToId: string
  dueDate: string
  priority: 'low' | 'medium' | 'high' | 'urgent'
  status: 'todo' | 'in-progress' | 'completed'
  createdAt: string
}

export interface InvoiceItem {
  id: string
  description: string
  amount: number
  quantity: number
}

export interface Invoice {
  id: string
  tenantId: string
  caseId: string
  clientId: string
  invoiceNumber: string
  issueDate: string
  dueDate: string
  items: InvoiceItem[]
  totalAmount: number
  status: 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled' | 'partially-paid'
  paymentMethod?: string
  createdAt: string
}

export interface PaymentLog {
  id: string
  tenantId: string
  invoiceId: string
  clientId: string
  amount: number
  paymentMethod: string
  date: string
  referenceNumber?: string
  notes?: string
  recordedById: string
  createdAt: string
}

export interface LegalDocument {
  id: string
  tenantId: string
  caseId: string
  title: string
  type: 'contract' | 'pleading' | 'evidence' | 'id_copy' | 'power_of_attorney' | 'other'
  status: 'draft' | 'final' | 'verified' | 'court_submitted'
  url: string
  uploadedById: string
  createdAt: string
}

export interface AgentSettings {
  tenantId: string
  model: string
  temperature: number
  systemPrompt: string
}

export type NavItem = {
  title: string
  href: string
  icon: React.ComponentType<{ className?: string }>
}
