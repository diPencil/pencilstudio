const fs = require('fs');
const storePath = 'd:/Development/dashboard/lib/data-store.ts';
let storeCode = fs.readFileSync(storePath, 'utf8');

storeCode = storeCode.replace(/Omit<LegalCase, 'id' \| 'createdAt'>/g, "Omit<LegalCase, 'id' | 'createdAt' | 'tenantId'>");
storeCode = storeCode.replace(/Omit<Client, 'id' \| 'createdAt' \| 'caseIds'>/g, "Omit<Client, 'id' | 'createdAt' | 'caseIds' | 'tenantId'>");
storeCode = storeCode.replace(/Omit<Consultation, 'id' \| 'createdAt'>/g, "Omit<Consultation, 'id' | 'createdAt' | 'tenantId'>");
storeCode = storeCode.replace(/Omit<CaseHistory, 'id' \| 'createdAt'>/g, "Omit<CaseHistory, 'id' | 'createdAt' | 'tenantId'>");
storeCode = storeCode.replace(/Omit<Invoice, 'id' \| 'createdAt'>/g, "Omit<Invoice, 'id' | 'createdAt' | 'tenantId'>");
storeCode = storeCode.replace(/createdAt: new Date\(\)\.toISOString\(\),/g, "tenantId: typeof window !== 'undefined' ? localStorage.getItem('tenantId') || 't-100' : 't-100',\n    createdAt: new Date().toISOString(),");
// Also update fetchers to dynamically get tenant
storeCode = storeCode.replace(/export const CURRENT_TENANT_ID = 'tenant-1' \/\/ Mock active workspace/g, "export const getTenantId = () => typeof window !== 'undefined' ? localStorage.getItem('tenantId') || 't-100' : 't-100'");
storeCode = storeCode.replace(/CURRENT_TENANT_ID/g, "getTenantId()");

fs.writeFileSync(storePath, storeCode);

const mockPath = 'd:/Development/dashboard/lib/mock-data.ts';
let mockCode = fs.readFileSync(mockPath, 'utf8');
let tenantToggle = true;
mockCode = mockCode.replace(/    id: (['`"][^'`"]+['`"]),/g, (match, id) => {
    let tId = tenantToggle ? 't-100' : 't-101';
    tenantToggle = !tenantToggle;
    return match + `\n    tenantId: '${tId}',`;
});
fs.writeFileSync(mockPath, mockCode);
console.log('Fixed');
