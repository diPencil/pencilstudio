'use client'

import React from "react"
import { useState, useEffect } from 'react'
import { addConsultation, updateConsultation, useCases, useClients, useUsers } from '@/lib/data-store'
import type { Consultation } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface ConsultationFormDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  consultation?: Consultation | null
  defaultType?: Consultation['type']
}

const typeOptions: { value: Consultation['type']; label: string }[] = [
  { value: 'initial', label: 'Initial Consultation' },
  { value: 'strategy', label: 'Strategy Session' },
  { value: 'court-prep', label: 'Court Preparation' },
  { value: 'mediation', label: 'Mediation / ADR' },
  { value: 'emergency', label: 'Emergency Briefing' },
  { value: 'follow-up', label: 'Follow-up' },
]

const statusOptions: { value: Consultation['status']; label: string }[] = [
  { value: 'scheduled', label: 'Scheduled' },
  { value: 'confirmed', label: 'Confirmed' },
  { value: 'in-progress', label: 'In Progress' },
  { value: 'completed', label: 'Completed' },
  { value: 'cancelled', label: 'Cancelled' },
]

// Hardcoded lawyers array removed in favor of useUsers hook

export function ConsultationFormDialog({
  open,
  onOpenChange,
  consultation,
  defaultType = 'initial',
}: ConsultationFormDialogProps) {
  const { cases } = useCases()
  const { clients } = useClients()
  const { users } = useUsers()
  const isEditing = !!consultation

  const [formData, setFormData] = useState({
    caseId: '',
    clientId: '',
    date: '',
    time: '',
    type: 'initial' as Consultation['type'],
    status: 'scheduled' as Consultation['status'],
    notes: '',
    lawyerId: '',
  })

  useEffect(() => {
    if (consultation) {
      setFormData({
        caseId: consultation.caseId,
        clientId: consultation.clientId,
        date: consultation.date,
        time: consultation.time,
        type: consultation.type,
        status: consultation.status,
        notes: consultation.notes,
        lawyerId: consultation.lawyerId,
      })
    } else {
      const today = new Date().toISOString().split('T')[0]
      setFormData({
        caseId: cases[0]?.id || '',
        clientId: cases[0]?.clientId || clients[0]?.id || '',
        date: today,
        time: '09:00',
        type: defaultType,
        status: 'scheduled',
        notes: '',
        lawyerId: users[0]?.id || '',
      })
    }
  }, [consultation, cases, clients, users])

  const handleCaseChange = (caseId: string) => {
    const legalCase = cases.find((c) => c.id === caseId)
    setFormData({
      ...formData,
      caseId,
      clientId: legalCase?.clientId || formData.clientId,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (isEditing && consultation) {
      updateConsultation(consultation.id, formData)
    } else {
      addConsultation(formData)
    }

    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto backdrop-blur-sm">
        <DialogHeader>
          <DialogTitle>{isEditing ? 'Edit Consultation' : 'Schedule Consultation'}</DialogTitle>
          <DialogDescription>
            {isEditing
              ? 'Update the consultation schedule and details below.'
              : 'Fill in the details to schedule a new legal consultation.'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="case">Legal Case</Label>
              <Select value={formData.caseId} onValueChange={handleCaseChange}>
                <SelectTrigger id="case">
                  <SelectValue placeholder="Select case" />
                </SelectTrigger>
                <SelectContent>
                  {cases.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="client">Client</Label>
              <Select
                value={formData.clientId}
                onValueChange={(value) => setFormData({ ...formData, clientId: value })}
              >
                <SelectTrigger id="client">
                  <SelectValue placeholder="Select client" />
                </SelectTrigger>
                <SelectContent>
                  {clients.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.firstName} {c.lastName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, date: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={formData.time}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, time: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Consultation Type</Label>
              <Select
                value={formData.type}
                onValueChange={(value: Consultation['type']) =>
                  setFormData({ ...formData, type: value })
                }
              >
                <SelectTrigger id="type">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {typeOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: Consultation['status']) =>
                  setFormData({ ...formData, status: value })
                }
              >
                <SelectTrigger id="status">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  {statusOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="lawyer">Assigned Lawyer</Label>
            <Select
              value={formData.lawyerId}
              onValueChange={(value) => setFormData({ ...formData, lawyerId: value })}
            >
              <SelectTrigger id="lawyer">
                <SelectValue placeholder="Select lawyer" />
              </SelectTrigger>
              <SelectContent>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Meeting Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Confidential meeting notes or agenda..."
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">{isEditing ? 'Update Record' : 'Schedule Meeting'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
