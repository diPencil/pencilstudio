'use client'

import React from "react"
import { useState } from 'react'
import { useConsultations, useCases, useClients, useUsers, updateConsultation, deleteConsultation } from '@/lib/data-store'
import type { Consultation } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Plus,
  MoreHorizontal,
  Edit,
  Trash2,
  Calendar,
  Check,
  X,
  Clock,
  Play,
  Briefcase,
  User,
  ChevronLeft,
  ChevronRight,
  Gavel,
  Users,
} from 'lucide-react'
import Link from 'next/link'
import { ConsultationFormDialog } from './consultation-form-dialog'

type StatusFilter = Consultation['status'] | 'all'
type TypeFilter = Consultation['type'] | 'all'

import { useLanguage } from '@/lib/language-context'

export function ConsultationsContent() {
  const { t, language } = useLanguage()
  const { consultations, isLoading } = useConsultations()
  const { cases } = useCases()
  const { clients } = useClients()
  const { users } = useUsers()
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all')
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('all')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingConsultation, setEditingConsultation] = useState<Consultation | null>(null)
  const [deletingConsultation, setDeletingConsultation] = useState<Consultation | null>(null)
  const [currentDate, setCurrentDate] = useState(new Date())
  const [defaultType, setDefaultType] = useState<Consultation['type']>('initial')

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))
  }
  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))
  }

  const handleQuickSchedule = (type: Consultation['type']) => {
    setDefaultType(type)
    setEditingConsultation(null)
    setDialogOpen(true)
  }

  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate()
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay()
  const calendarDays = Array.from({ length: daysInMonth }, (_, i) => i + 1)
  const emptyDays = Array.from({ length: firstDayOfMonth }, (_, i) => i)

  const getCaseName = (caseId: string) => cases.find((c) => c.id === caseId)?.name || 'Unknown Case'
  const getClientName = (clientId: string) => {
    const client = clients.find((c) => c.id === clientId)
    return client ? `${client.firstName} ${client.lastName}` : 'Unknown Client'
  }
  const getLawyerName = (lawyerId: string) => users.find((u) => u.id === lawyerId)?.name || 'Unknown Lawyer'

  const filteredConsultations = consultations
    .filter((cons: Consultation) => {
      const matchesStatus = statusFilter === 'all' || cons.status === statusFilter
      const matchesType = typeFilter === 'all' || cons.type === typeFilter
      return matchesStatus && matchesType
    })
    .sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time))

  const statusOptions: { value: StatusFilter; label: string }[] = [
    { value: 'all', label: 'All Status' },
    { value: 'scheduled', label: 'Scheduled' },
    { value: 'confirmed', label: 'Confirmed' },
    { value: 'in-progress', label: 'In Progress' },
    { value: 'completed', label: 'Completed' },
    { value: 'cancelled', label: 'Cancelled' },
  ]

  const typeOptions: { value: TypeFilter; label: string }[] = [
    { value: 'all', label: 'All Types' },
    { value: 'initial', label: 'Initial' },
    { value: 'strategy', label: 'Strategy' },
    { value: 'court-prep', label: 'Court Prep' },
    { value: 'mediation', label: 'Mediation' },
    { value: 'emergency', label: 'Emergency' },
    { value: 'follow-up', label: 'Follow-up' },
  ]

  const getStatusBadge = (status: Consultation['status']) => {
    const variants: Record<string, { variant: 'default' | 'secondary' | 'destructive' | 'outline'; label: string }> = {
      scheduled: { variant: 'secondary', label: 'Scheduled' },
      confirmed: { variant: 'default', label: 'Confirmed' },
      'in-progress': { variant: 'outline', label: 'In Progress' },
      completed: { variant: 'secondary', label: 'Completed' },
      cancelled: { variant: 'destructive', label: 'Cancelled' },
    }
    const config = variants[status]
    return <Badge variant={config.variant}>{config.label}</Badge>
  }

  const handleEdit = (consultation: Consultation) => {
    setEditingConsultation(consultation)
    setDialogOpen(true)
  }

  const handleStatusChange = (id: string, status: Consultation['status']) => {
    updateConsultation(id, { status })
  }

  const confirmDelete = () => {
    if (deletingConsultation) {
      deleteConsultation(deletingConsultation.id)
      setDeletingConsultation(null)
    }
  }

  const handleDialogClose = () => {
    setDialogOpen(false)
    setEditingConsultation(null)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-pulse text-muted-foreground">Loading consultations...</div>
      </div>
    )
  }

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{language === 'ar' ? 'الجلسات والمواعيد' : 'Legal Consultations'}</h1>
          <p className="text-muted-foreground">{language === 'ar' ? 'إدارة وجدولة اجتماعات العملاء والمحاكم' : 'Manage and schedule client meetings'}</p>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button>
              <Plus className="size-4 mr-2" />
              {language === 'ar' ? 'جدولة سريعة' : 'Quick Schedule'}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => handleQuickSchedule('initial')} className="cursor-pointer font-medium p-2">
              <Users className="size-4 mr-2" />
              {language === 'ar' ? 'اجتماع مع موكل' : 'Client Meeting'}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleQuickSchedule('court-prep')} className="cursor-pointer font-medium p-2">
              <Gavel className="size-4 mr-2" />
              {language === 'ar' ? 'جلسة محكمة' : 'Court Hearing'}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <Tabs defaultValue="list" className="space-y-4">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="list">{language === 'ar' ? 'عرض القائمة' : 'List View'}</TabsTrigger>
            <TabsTrigger value="calendar">{language === 'ar' ? 'عرض التقويم' : 'Calendar View'}</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="list" className="space-y-4">
          <Card>
            <CardHeader className="pb-4">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <CardTitle>Consultation Schedule</CardTitle>
                  <CardDescription>{filteredConsultations.length} upcoming and past meetings</CardDescription>
                </div>
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
                  <div className="flex gap-1 flex-wrap">
                    {statusOptions.map((option) => (
                      <button
                        key={option.value}
                        type="button"
                        onClick={() =>
                          setStatusFilter(option.value === statusFilter ? 'all' : option.value)
                        }
                        className={`px-3 py-1.5 text-sm rounded-full transition-colors ${statusFilter === option.value
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted text-muted-foreground hover:bg-muted/80'
                          }`}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex gap-1 flex-wrap mt-2">
                {typeOptions.map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setTypeFilter(option.value === typeFilter ? 'all' : option.value)}
                    className={`px-3 py-1.5 text-sm rounded-full transition-colors ${typeFilter === option.value
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-muted-foreground hover:bg-muted/80'
                      }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </CardHeader>
            <CardContent>
              {filteredConsultations.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Calendar className="size-12 text-muted-foreground/50 mb-4" />
                  <h3 className="text-lg font-medium">No consultations found</h3>
                  <p className="text-muted-foreground">
                    {statusFilter !== 'all' || typeFilter !== 'all'
                      ? 'Try adjusting your filters'
                      : 'Get started by scheduling your first consultation'}
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date & Time</TableHead>
                        <TableHead>Legal Case</TableHead>
                        <TableHead className="hidden sm:table-cell">Client</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead className="hidden md:table-cell">Lawyer</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="w-10"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredConsultations.map((cons: Consultation) => (
                        <TableRow key={cons.id}>
                          <TableCell>
                            <div className="flex flex-col">
                              <span className="font-medium">
                                {new Date(cons.date).toLocaleDateString('en-US', {
                                  month: 'short',
                                  day: 'numeric',
                                  year: 'numeric'
                                })}
                              </span>
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <Clock className="size-3" />
                                {cons.time}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Link
                              href={`/cases/${cons.caseId}`}
                              className="font-medium hover:text-primary transition-colors flex items-center gap-2"
                            >
                              <Briefcase className="size-3 text-muted-foreground" />
                              <span className="truncate max-w-[150px]">{getCaseName(cons.caseId)}</span>
                            </Link>
                          </TableCell>
                          <TableCell className="hidden sm:table-cell">
                            <Link
                              href={`/clients/${cons.clientId}`}
                              className="hover:text-primary transition-colors flex items-center gap-2"
                            >
                              <User className="size-3 text-muted-foreground" />
                              <span className="truncate max-w-[150px]">{getClientName(cons.clientId)}</span>
                            </Link>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="capitalize">
                              {cons.type.replace('-', ' ')}
                            </Badge>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">{getLawyerName(cons.lawyerId)}</TableCell>
                          <TableCell>{getStatusBadge(cons.status)}</TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="size-8">
                                  <MoreHorizontal className="size-4" />
                                  <span className="sr-only">Actions</span>
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => handleEdit(cons)}>
                                  <Edit className="size-4 mr-2" />
                                  Edit Info
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  onClick={() => handleStatusChange(cons.id, 'confirmed')}
                                  disabled={cons.status === 'confirmed'}
                                >
                                  <Check className="size-4 mr-2" />
                                  Confirm
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => handleStatusChange(cons.id, 'in-progress')}
                                  disabled={cons.status === 'in-progress'}
                                >
                                  <Play className="size-4 mr-2" />
                                  Start Meeting
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => handleStatusChange(cons.id, 'completed')}
                                  disabled={cons.status === 'completed'}
                                >
                                  <Clock className="size-4 mr-2" />
                                  Complete
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => handleStatusChange(cons.id, 'cancelled')}
                                  disabled={cons.status === 'cancelled'}
                                  className="text-destructive focus:text-destructive"
                                >
                                  <X className="size-4 mr-2" />
                                  Cancel
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  onClick={() => setDeletingConsultation(cons)}
                                  className="text-destructive focus:text-destructive"
                                >
                                  <Trash2 className="size-4 mr-2" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendar">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-4">
              <div>
                <CardTitle className="text-xl">{currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</CardTitle>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="icon" onClick={prevMonth}>
                  <ChevronLeft className="size-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={nextMonth}>
                  <ChevronRight className="size-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-px rounded-md border bg-muted p-px">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className="bg-background p-2 text-center text-sm font-semibold text-muted-foreground">{day}</div>
                ))}
                {emptyDays.map(empty => (
                  <div key={`empty-${empty}`} className="bg-background min-h-[120px] p-2 opacity-50" />
                ))}
                {calendarDays.map(day => {
                  const msStr = String(currentDate.getMonth() + 1).padStart(2, '0')
                  const dsStr = String(day).padStart(2, '0')
                  const dateString = `${currentDate.getFullYear()}-${msStr}-${dsStr}`
                  const dayCons = consultations.filter(c => c.date === dateString)
                  const isToday = new Date().getDate() === day && new Date().getMonth() === currentDate.getMonth() && new Date().getFullYear() === currentDate.getFullYear()

                  return (
                    <div key={day} className="bg-background min-h-[120px] p-2 flex flex-col gap-1 border-t transition-colors hover:bg-muted/30">
                      <span className={`text-sm font-medium w-fit ${isToday ? 'bg-primary text-primary-foreground size-6 rounded-full flex items-center justify-center' : ''}`}>{day}</span>
                      <div className="flex flex-col gap-1 mt-1 overflow-y-auto max-h-[90px] no-scrollbar">
                        {dayCons.map(cons => (
                          <div
                            key={cons.id}
                            onClick={() => handleEdit(cons)}
                            className="text-xs p-1 px-1.5 rounded bg-secondary truncate cursor-pointer hover:bg-primary/20 hover:text-primary transition-colors border border-border/50 font-medium flex gap-1 items-center"
                            title={`${cons.time} - ${getCaseName(cons.caseId)}`}
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0"></span>
                            <span className="truncate">{cons.time} {getClientName(cons.clientId)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <ConsultationFormDialog
        open={dialogOpen}
        onOpenChange={handleDialogClose}
        consultation={editingConsultation}
        defaultType={defaultType}
      />

      <AlertDialog open={!!deletingConsultation} onOpenChange={() => setDeletingConsultation(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Consultation Record</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this consultation record? This cannot be undone and will remove the meeting from all calendars.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep Record</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete Record
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
