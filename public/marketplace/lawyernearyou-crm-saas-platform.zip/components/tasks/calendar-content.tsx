'use client'

import React, { useState } from 'react'
import { ChevronLeft, ChevronRight, Plus, Clock } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
    Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import { useLanguage } from '@/lib/language-context'

interface CalendarEvent {
    id: string
    title: string
    time: string
    type: 'hearing' | 'meeting' | 'deadline' | 'consultation'
    day: number
}

const typeColors: Record<string, string> = {
    hearing: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 border-red-200',
    meeting: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 border-blue-200',
    deadline: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400 border-yellow-200',
    consultation: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 border-green-200',
}

const defaultEvents: CalendarEvent[] = [
    { id: '1', title: 'Mansour Case Hearing', time: '09:00 AM', type: 'hearing', day: 5 },
    { id: '2', title: 'Team Standup', time: '10:30 AM', type: 'meeting', day: 8 },
    { id: '3', title: 'NDA Deadline - TechCorp', time: '11:59 PM', type: 'deadline', day: 12 },
    { id: '4', title: 'Client Consultation - Sara', time: '02:00 PM', type: 'consultation', day: 15 },
    { id: '5', title: 'Appeal Filing Deadline', time: '05:00 PM', type: 'deadline', day: 20 },
    { id: '6', title: 'Partner Meeting', time: '03:00 PM', type: 'meeting', day: 22 },
    { id: '7', title: 'Court Session - Zaki', time: '10:00 AM', type: 'hearing', day: 25 },
]

const DAYS_AR = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']
const DAYS_EN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const MONTHS_AR = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']
const MONTHS_EN = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']

export function CalendarContent() {
    const { language } = useLanguage()
    const [currentMonth, setCurrentMonth] = useState(2) // March (0-indexed)
    const [currentYear] = useState(2024)
    const [events, setEvents] = useState<CalendarEvent[]>(defaultEvents)
    const [dialogOpen, setDialogOpen] = useState(false)
    const [newEvent, setNewEvent] = useState({ title: '', time: '09:00', type: 'meeting' as CalendarEvent['type'], day: 1 })
    const [selectedDay, setSelectedDay] = useState<number | null>(null)
    const [feedback, setFeedback] = useState<string | null>(null)

    const showFeedback = (msg: string) => { setFeedback(msg); setTimeout(() => setFeedback(null), 2500) }

    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate()
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay()

    const handleAddEvent = () => {
        if (!newEvent.title) return
        const event: CalendarEvent = { id: Date.now().toString(), ...newEvent }
        setEvents(prev => [...prev, event])
        setNewEvent({ title: '', time: '09:00', type: 'meeting', day: selectedDay || 1 })
        setDialogOpen(false)
        showFeedback(language === 'ar' ? '✅ تمت إضافة الحدث' : '✅ Event added')
    }

    const deleteEvent = (id: string) => {
        setEvents(prev => prev.filter(e => e.id !== id))
        showFeedback(language === 'ar' ? '🗑️ تم حذف الحدث' : '🗑️ Event removed')
    }

    const dayLabels = language === 'ar' ? DAYS_AR : DAYS_EN
    const monthName = language === 'ar' ? MONTHS_AR[currentMonth] : MONTHS_EN[currentMonth]

    const typeLabels: Record<string, Record<string, string>> = {
        hearing: { ar: 'جلسة', en: 'Hearing' },
        meeting: { ar: 'اجتماع', en: 'Meeting' },
        deadline: { ar: 'موعد نهائي', en: 'Deadline' },
        consultation: { ar: 'استشارة', en: 'Consultation' },
    }

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && (
                <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300">
                    <div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div>
                </div>
            )}

            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'التقويم القضائي' : 'Legal Calendar'}</h1>
                    <p className="text-muted-foreground">{language === 'ar' ? 'تتبع جميع المواعيد والجلسات والمواعيد النهائية.' : 'Track all hearings, meetings, and deadlines.'}</p>
                </div>
                <div className="flex items-center gap-2">
                    <Button variant="outline" size="icon" onClick={() => setCurrentMonth(p => p > 0 ? p - 1 : 11)}><ChevronLeft className="size-4 rtl:rotate-180" /></Button>
                    <span className="font-semibold min-w-[140px] text-center">{monthName} {currentYear}</span>
                    <Button variant="outline" size="icon" onClick={() => setCurrentMonth(p => p < 11 ? p + 1 : 0)}><ChevronRight className="size-4 rtl:rotate-180" /></Button>
                    <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                        <DialogTrigger asChild>
                            <Button className="gap-2 ms-4"><Plus className="size-4" />{language === 'ar' ? 'حدث جديد' : 'New Event'}</Button>
                        </DialogTrigger>
                        <DialogContent>
                            <DialogHeader>
                                <DialogTitle>{language === 'ar' ? 'إضافة حدث جديد' : 'Add New Event'}</DialogTitle>
                                <DialogDescription>{language === 'ar' ? 'أضف موعداً أو جلسة أو حدثاً مهماً للتقويم.' : 'Add a hearing, meeting, or important event to the calendar.'}</DialogDescription>
                            </DialogHeader>
                            <div className="grid gap-4 py-4">
                                <div className="grid gap-2"><Label>{language === 'ar' ? 'العنوان *' : 'Title *'}</Label><Input value={newEvent.title} onChange={e => setNewEvent(p => ({ ...p, title: e.target.value }))} /></div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="grid gap-2"><Label>{language === 'ar' ? 'اليوم' : 'Day'}</Label><Input type="number" min={1} max={daysInMonth} value={newEvent.day} onChange={e => setNewEvent(p => ({ ...p, day: parseInt(e.target.value) || 1 }))} /></div>
                                    <div className="grid gap-2"><Label>{language === 'ar' ? 'الوقت' : 'Time'}</Label><Input type="time" value={newEvent.time} onChange={e => setNewEvent(p => ({ ...p, time: e.target.value }))} /></div>
                                </div>
                                <div className="grid gap-2">
                                    <Label>{language === 'ar' ? 'النوع' : 'Type'}</Label>
                                    <div className="flex flex-wrap gap-2">
                                        {(['hearing', 'meeting', 'deadline', 'consultation'] as const).map(type => (
                                            <Badge key={type} variant={newEvent.type === type ? 'default' : 'outline'} className="cursor-pointer" onClick={() => setNewEvent(p => ({ ...p, type }))}>{typeLabels[type][language]}</Badge>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            <DialogFooter>
                                <Button variant="outline" onClick={() => setDialogOpen(false)}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button>
                                <Button onClick={handleAddEvent} disabled={!newEvent.title}>{language === 'ar' ? 'إضافة' : 'Add'}</Button>
                            </DialogFooter>
                        </DialogContent>
                    </Dialog>
                </div>
            </div>

            {/* Legend */}
            <div className="flex flex-wrap gap-3">
                {Object.entries(typeLabels).map(([type, label]) => (
                    <div key={type} className="flex items-center gap-1.5 text-xs">
                        <div className={`size-2.5 rounded-full ${typeColors[type].split(' ')[0]}`} />
                        <span className="text-muted-foreground">{label[language]}</span>
                    </div>
                ))}
            </div>

            {/* Calendar Grid */}
            <Card className="border-none shadow-sm overflow-hidden">
                <CardContent className="p-0">
                    <div className="grid grid-cols-7">
                        {dayLabels.map(day => (
                            <div key={day} className="p-3 text-center text-xs font-semibold text-muted-foreground border-b bg-muted/30">{day}</div>
                        ))}
                        {Array.from({ length: firstDayOfMonth }).map((_, i) => (
                            <div key={`empty-${i}`} className="min-h-[100px] border-b border-r border-muted/30 bg-muted/10" />
                        ))}
                        {Array.from({ length: daysInMonth }).map((_, i) => {
                            const day = i + 1
                            const dayEvents = events.filter(e => e.day === day)
                            const isToday = day === 8 // mock today
                            return (
                                <div key={day} className={`min-h-[100px] border-b border-r border-muted/30 p-1.5 cursor-pointer hover:bg-muted/20 transition-colors ${isToday ? 'bg-primary/5' : ''} ${selectedDay === day ? 'ring-2 ring-primary ring-inset' : ''}`} onClick={() => { setSelectedDay(day); setNewEvent(p => ({ ...p, day })) }}>
                                    <div className={`text-xs font-medium mb-1 ${isToday ? 'bg-primary text-primary-foreground size-6 rounded-full flex items-center justify-center' : ''}`}>{day}</div>
                                    {dayEvents.slice(0, 2).map(ev => (
                                        <div key={ev.id} className={`text-[10px] px-1 py-0.5 rounded mb-0.5 truncate border ${typeColors[ev.type]} cursor-pointer`} title={`${ev.title} - ${ev.time}`} onClick={e => { e.stopPropagation(); deleteEvent(ev.id) }}>{ev.title}</div>
                                    ))}
                                    {dayEvents.length > 2 && <div className="text-[10px] text-muted-foreground px-1">+{dayEvents.length - 2} {language === 'ar' ? 'أخرى' : 'more'}</div>}
                                </div>
                            )
                        })}
                    </div>
                </CardContent>
            </Card>

            {/* Selected Day Events */}
            {selectedDay && events.filter(e => e.day === selectedDay).length > 0 && (
                <Card className="border-none shadow-sm">
                    <CardContent className="p-4">
                        <h3 className="font-semibold mb-3">{language === 'ar' ? `أحداث يوم ${selectedDay}` : `Events on Day ${selectedDay}`}</h3>
                        <div className="space-y-2">
                            {events.filter(e => e.day === selectedDay).map(ev => (
                                <div key={ev.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                                    <div className="flex items-center gap-3">
                                        <Badge variant="secondary" className={typeColors[ev.type]}>{typeLabels[ev.type][language]}</Badge>
                                        <div>
                                            <p className="font-medium text-sm">{ev.title}</p>
                                            <p className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="size-3" />{ev.time}</p>
                                        </div>
                                    </div>
                                    <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive text-xs" onClick={() => deleteEvent(ev.id)}>{language === 'ar' ? 'حذف' : 'Delete'}</Button>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    )
}
