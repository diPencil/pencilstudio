'use client'

import React, { useState } from 'react'
import { Plus, MoreHorizontal, Calendar, Clock, User, Filter, GripVertical, Trash2 } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
    Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { useLanguage } from '@/lib/language-context'

interface Task {
    id: string
    title: string
    priority: 'High' | 'Medium' | 'Low'
    deadline: string
    category: string
}

interface Column {
    title: { ar: string; en: string }
    tasks: Task[]
}

const defaultColumns: Record<string, Column> = {
    todo: {
        title: { ar: 'قيد الانتظار', en: 'To Do' },
        tasks: [
            { id: '1', title: 'Review Case Files - Mansour', priority: 'High', deadline: 'Mar 15', category: 'Legal' },
            { id: '2', title: 'Draft NDA for TechCorp', priority: 'Medium', deadline: 'Mar 18', category: 'Corporate' },
        ]
    },
    inProgress: {
        title: { ar: 'قيد التنفيذ', en: 'In Progress' },
        tasks: [
            { id: '3', title: 'Prepare Hearing Witnesses', priority: 'High', deadline: 'Mar 10', category: 'Litigation' },
            { id: '4', title: 'Client Consultation - Sara K.', priority: 'Low', deadline: 'Mar 09', category: 'Family' },
        ]
    },
    completed: {
        title: { ar: 'تم الانتهاء', en: 'Completed' },
        tasks: [
            { id: '5', title: 'File Tax Appeal', priority: 'Medium', deadline: 'Mar 05', category: 'Tax' },
        ]
    }
}

export function KanbanBoard() {
    const { language } = useLanguage()
    const [columns, setColumns] = useState<Record<string, Column>>(defaultColumns)
    const [addingTo, setAddingTo] = useState<string | null>(null)
    const [newTask, setNewTask] = useState({ title: '', priority: 'Medium' as Task['priority'], category: 'Legal', deadline: '' })
    const [globalDialogOpen, setGlobalDialogOpen] = useState(false)
    const [globalNewTask, setGlobalNewTask] = useState({ title: '', priority: 'Medium' as Task['priority'], category: 'Legal', deadline: '', column: 'todo' })
    const [feedback, setFeedback] = useState<string | null>(null)

    const showFeedback = (msg: string) => {
        setFeedback(msg)
        setTimeout(() => setFeedback(null), 2500)
    }

    const addTask = (columnId: string) => {
        if (!newTask.title) return
        const task: Task = { id: Date.now().toString(), ...newTask }
        setColumns(prev => ({
            ...prev,
            [columnId]: { ...prev[columnId], tasks: [...prev[columnId].tasks, task] }
        }))
        setNewTask({ title: '', priority: 'Medium', category: 'Legal', deadline: '' })
        setAddingTo(null)
        showFeedback(language === 'ar' ? '✅ تمت إضافة المهمة' : '✅ Task added')
    }

    const addGlobalTask = () => {
        if (!globalNewTask.title) return
        const task: Task = { id: Date.now().toString(), title: globalNewTask.title, priority: globalNewTask.priority, category: globalNewTask.category, deadline: globalNewTask.deadline }
        setColumns(prev => ({
            ...prev,
            [globalNewTask.column]: { ...prev[globalNewTask.column], tasks: [...prev[globalNewTask.column].tasks, task] }
        }))
        setGlobalNewTask({ title: '', priority: 'Medium', category: 'Legal', deadline: '', column: 'todo' })
        setGlobalDialogOpen(false)
        showFeedback(language === 'ar' ? '✅ تمت إضافة المهمة' : '✅ Task added')
    }

    const deleteTask = (columnId: string, taskId: string) => {
        setColumns(prev => ({
            ...prev,
            [columnId]: { ...prev[columnId], tasks: prev[columnId].tasks.filter(t => t.id !== taskId) }
        }))
        showFeedback(language === 'ar' ? '🗑️ تم حذف المهمة' : '🗑️ Task removed')
    }

    const moveTask = (fromCol: string, taskId: string, toCol: string) => {
        const task = columns[fromCol].tasks.find(t => t.id === taskId)
        if (!task) return
        setColumns(prev => ({
            ...prev,
            [fromCol]: { ...prev[fromCol], tasks: prev[fromCol].tasks.filter(t => t.id !== taskId) },
            [toCol]: { ...prev[toCol], tasks: [...prev[toCol].tasks, task] }
        }))
        showFeedback(language === 'ar' ? '➡️ تم نقل المهمة' : '➡️ Task moved')
    }

    const getPriorityBadge = (priority: string) => {
        const labels: Record<string, Record<string, string>> = { High: { ar: 'عالي', en: 'High' }, Medium: { ar: 'متوسط', en: 'Medium' }, Low: { ar: 'منخفض', en: 'Low' } }
        const colors: Record<string, string> = { High: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400', Medium: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400', Low: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' }
        return <Badge variant="secondary" className={`${colors[priority]} text-[10px] h-5`}>{labels[priority]?.[language] || priority}</Badge>
    }

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && (
                <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300">
                    <div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div>
                </div>
            )}

            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'لوحة المهام (Kanban)' : 'Kanban Board'}</h1>
                    <p className="text-muted-foreground">{language === 'ar' ? 'إدارة مهام القضايا والمكتب بكفاءة عالية.' : 'Efficiently manage legal cases and administrative tasks.'}</p>
                </div>
                <Dialog open={globalDialogOpen} onOpenChange={setGlobalDialogOpen}>
                    <DialogTrigger asChild>
                        <Button className="gap-2"><Plus className="size-4" />{language === 'ar' ? 'مهمة جديدة' : 'New Task'}</Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>{language === 'ar' ? 'إضافة مهمة جديدة' : 'New Task'}</DialogTitle>
                            <DialogDescription>{language === 'ar' ? 'أنشئ مهمة جديدة وأضفها إلى العمود المناسب.' : 'Create a new task and assign it to a column.'}</DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid gap-2">
                                <Label>{language === 'ar' ? 'عنوان المهمة *' : 'Task Title *'}</Label>
                                <Input value={globalNewTask.title} onChange={e => setGlobalNewTask(p => ({ ...p, title: e.target.value }))} placeholder={language === 'ar' ? 'مثال: مراجعة ملفات القضية' : 'e.g. Review Case Files'} />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="grid gap-2">
                                    <Label>{language === 'ar' ? 'الأولوية' : 'Priority'}</Label>
                                    <Select value={globalNewTask.priority} onValueChange={v => setGlobalNewTask(p => ({ ...p, priority: v as Task['priority'] }))}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="High">{language === 'ar' ? 'عالي' : 'High'}</SelectItem>
                                            <SelectItem value="Medium">{language === 'ar' ? 'متوسط' : 'Medium'}</SelectItem>
                                            <SelectItem value="Low">{language === 'ar' ? 'منخفض' : 'Low'}</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="grid gap-2">
                                    <Label>{language === 'ar' ? 'العمود' : 'Column'}</Label>
                                    <Select value={globalNewTask.column} onValueChange={v => setGlobalNewTask(p => ({ ...p, column: v }))}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            {Object.entries(columns).map(([id, col]) => (
                                                <SelectItem key={id} value={id}>{col.title[language]}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                            <div className="grid gap-2">
                                <Label>{language === 'ar' ? 'التصنيف' : 'Category'}</Label>
                                <Input value={globalNewTask.category} onChange={e => setGlobalNewTask(p => ({ ...p, category: e.target.value }))} placeholder="Legal, Corporate, etc." />
                            </div>
                            <div className="grid gap-2">
                                <Label>{language === 'ar' ? 'الموعد النهائي' : 'Deadline'}</Label>
                                <Input value={globalNewTask.deadline} onChange={e => setGlobalNewTask(p => ({ ...p, deadline: e.target.value }))} placeholder="Mar 20" />
                            </div>
                        </div>
                        <DialogFooter>
                            <Button variant="outline" onClick={() => setGlobalDialogOpen(false)}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button>
                            <Button onClick={addGlobalTask} disabled={!globalNewTask.title}>{language === 'ar' ? 'إضافة' : 'Add Task'}</Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>

            <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
                {Object.entries(columns).map(([colId, column]) => (
                    <div key={colId} className="flex flex-col gap-4">
                        <div className="flex items-center justify-between px-2">
                            <div className="flex items-center gap-2">
                                <h3 className="font-semibold">{column.title[language]}</h3>
                                <Badge variant="secondary" className="rounded-full px-2 py-0">{column.tasks.length}</Badge>
                            </div>
                        </div>
                        <div className="flex flex-col gap-3 min-h-[400px] rounded-lg bg-muted/30 p-2">
                            {column.tasks.map((task) => (
                                <Card key={task.id} className="group hover:ring-2 hover:ring-primary/20 transition-all border-none shadow-sm">
                                    <CardContent className="p-4 space-y-3">
                                        <div className="flex items-center justify-between">
                                            <Badge variant="outline" className="text-[10px] font-normal uppercase tracking-wider">{task.category}</Badge>
                                            {getPriorityBadge(task.priority)}
                                        </div>
                                        <h4 className="font-medium text-sm leading-tight">{task.title}</h4>
                                        <div className="flex items-center justify-between pt-2">
                                            <div className="flex items-center gap-3 text-xs text-muted-foreground">
                                                {task.deadline && <div className="flex items-center gap-1"><Calendar className="size-3" /><span>{task.deadline}</span></div>}
                                            </div>
                                            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                                {/* Move buttons */}
                                                {Object.entries(columns).filter(([id]) => id !== colId).map(([id, col]) => (
                                                    <Button key={id} variant="ghost" size="icon" className="size-6" title={`Move to ${col.title[language]}`} onClick={() => moveTask(colId, task.id, id)}>
                                                        <GripVertical className="size-3" />
                                                    </Button>
                                                ))}
                                                <Button variant="ghost" size="icon" className="size-6 text-destructive hover:text-destructive" onClick={() => deleteTask(colId, task.id)}>
                                                    <Trash2 className="size-3" />
                                                </Button>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))}

                            {/* Inline Add Card */}
                            {addingTo === colId ? (
                                <Card className="border-dashed border-2 border-primary/30">
                                    <CardContent className="p-3 space-y-2">
                                        <Input placeholder={language === 'ar' ? 'عنوان المهمة...' : 'Task title...'} value={newTask.title} onChange={e => setNewTask(p => ({ ...p, title: e.target.value }))} autoFocus onKeyDown={e => e.key === 'Enter' && addTask(colId)} />
                                        <div className="flex gap-2">
                                            <Button size="sm" className="h-7 text-xs" onClick={() => addTask(colId)} disabled={!newTask.title}>{language === 'ar' ? 'إضافة' : 'Add'}</Button>
                                            <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => { setAddingTo(null); setNewTask({ title: '', priority: 'Medium', category: 'Legal', deadline: '' }) }}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            ) : (
                                <Button variant="ghost" className="w-full justify-start gap-2 text-muted-foreground hover:text-foreground h-9 text-xs" size="sm" onClick={() => setAddingTo(colId)}>
                                    <Plus className="size-3" />{language === 'ar' ? 'إضافة بطاقة' : 'Add card'}
                                </Button>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}
