'use client'

import React, { useState, useEffect } from "react"
import { useTenant } from '@/lib/tenant-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Building2, Phone, MapPin, Mail, Globe, Info } from 'lucide-react'

interface FirmInfoSettingsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function FirmInfoSettingsDialog({ open, onOpenChange }: FirmInfoSettingsDialogProps) {
  const { currentTenant, updateBranding } = useTenant()
  const [isSaving, setIsSaving] = useState(false)
  const [formData, setFormData] = useState({
    name: currentTenant.name || '',
    phone: currentTenant.phone || '',
    address: currentTenant.address || '',
    email: currentTenant.email || '',
    website: currentTenant.website || '',
    description: currentTenant.description || '',
  })

  useEffect(() => {
    setFormData({
      name: currentTenant.name || '',
      phone: currentTenant.phone || '',
      address: currentTenant.address || '',
      email: currentTenant.email || '',
      website: currentTenant.website || '',
      description: currentTenant.description || '',
    })
  }, [currentTenant, open])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)
    try {
      await updateBranding(formData)
      onOpenChange(false)
    } catch (err) {
      console.error(err)
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building2 className="size-5 text-primary" />
            Law Firm Information
          </DialogTitle>
          <DialogDescription>
            Update your public profile and contact details used in invoices and documents.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <Card>
            <CardHeader className="pb-3 border-b mb-4">
              <CardTitle className="text-sm flex items-center gap-2 font-bold">
                <Info className="size-4" />
                Basic Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Official Firm Name</Label>
                <Input 
                  value={formData.name} 
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  placeholder="e.g. Justice & Partners"
                />
              </div>
              <div className="space-y-2">
                <Label>Short Description</Label>
                <Textarea 
                  value={formData.description}
                  onChange={e => setFormData({...formData, description: e.target.value})}
                  placeholder="Tell clients about your expertise..."
                  className="min-h-[80px]"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3 border-b mb-4">
              <CardTitle className="text-sm flex items-center gap-2 font-bold">
                <Phone className="size-4" />
                Contact & Location
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="flex items-center gap-1.5">
                    <Phone className="size-3" /> Phone Number
                  </Label>
                  <Input 
                    value={formData.phone}
                    onChange={e => setFormData({...formData, phone: e.target.value})}
                    placeholder="+20 123 456 789"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="flex items-center gap-1.5">
                    <Mail className="size-3" /> Email Address
                  </Label>
                  <Input 
                    value={formData.email}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                    placeholder="contact@firm.com"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5">
                  <Globe className="size-3" /> Website
                </Label>
                <Input 
                  value={formData.website}
                  onChange={e => setFormData({...formData, website: e.target.value})}
                  placeholder="https://www.justice-partners.com"
                />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1.5">
                  <MapPin className="size-3" /> Office Address
                </Label>
                <Textarea 
                  value={formData.address}
                  onChange={e => setFormData({...formData, address: e.target.value})}
                  placeholder="123 Legal St, Cairo, Egypt"
                  className="min-h-[60px]"
                />
              </div>
            </CardContent>
          </Card>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSaving}>
              {isSaving ? 'Saving Changes...' : 'Save Firm Info'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
