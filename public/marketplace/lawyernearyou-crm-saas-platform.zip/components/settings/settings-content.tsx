'use client'

import { useState } from 'react'
import { useAgentSettings } from '@/lib/data-store'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  Settings,
  Bot,
  Building2,
  Bell,
  Shield,
  Database,
  ChevronRight,
} from 'lucide-react'
import { AgentSettingsDialog } from '@/components/assistant/agent-settings-dialog'
import { BrandingSettingsDialog } from '@/components/settings/branding-settings-dialog'
import { FirmInfoSettingsDialog } from './firm-info-settings-dialog'

export function SettingsContent() {
  const { settings } = useAgentSettings()
  const [agentSettingsOpen, setAgentSettingsOpen] = useState(false)
  const [brandingOpen, setBrandingOpen] = useState(false)
  const [firmInfoOpen, setFirmInfoOpen] = useState(false)

  const settingsSections = [
    {
      title: 'Legal AI Assistant',
      description: 'Configure the AI research partner behavior, model, and system prompt',
      icon: Bot,
      badge: settings?.model ? settings.model.split('/').pop() : 'Default',
      onClick: () => setAgentSettingsOpen(true),
    },
    {
      title: 'Branding & White-label',
      description: 'Customize logos, colors, and connect your own domain',
      icon: Building2,
      badge: 'PRO',
      onClick: () => setBrandingOpen(true),
    },
    {
      title: 'Law Firm Information',
      description: 'Update your firm name, practice areas, and contact details',
      icon: Database,
      badge: null,
      onClick: () => setFirmInfoOpen(true),
    },
    {
      title: 'Notifications & Alerts',
      description: 'Manage filing deadlines, hearing reminders, and SMS preferences',
      icon: Bell,
      badge: null,
      onClick: () => { },
      disabled: true,
    },
    {
      title: 'Security & Compliance',
      description: 'Two-factor authentication, session management, and audit logs',
      icon: Shield,
      badge: null,
      onClick: () => { },
      disabled: true,
    },
    {
      title: 'Cloud Data & Archiving',
      description: 'Case backup, document export, and data retention policies',
      icon: Database,
      badge: null,
      onClick: () => { },
      disabled: true,
    },
  ]

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold tracking-tight">System Configuration</h1>
        <p className="text-muted-foreground">Manage your law firm and application environment settings.</p>
      </div>

      <Card className="border-shadow shadow-sm overflow-hidden">
        <CardHeader className="bg-muted/30 border-b">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Settings className="size-5 text-primary" />
            Core Application Preferences
          </CardTitle>
          <CardDescription>
            Configure LawCRM to match your firm&apos;s operational workflow
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {settingsSections.map((section, index) => (
            <div key={section.title}>
              {index > 0 && <Separator />}
              <button
                type="button"
                onClick={section.onClick}
                disabled={section.disabled}
                className="flex items-center gap-4 w-full p-5 text-left transition-all hover:bg-muted/50 disabled:opacity-40 disabled:cursor-not-allowed group"
              >
                <div className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-primary/5 text-primary group-hover:scale-110 transition-transform">
                  <section.icon className="size-6" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-[15px]">{section.title}</h3>
                    {section.badge && (
                      <Badge variant="secondary" className="text-[10px] px-1.5 h-4 uppercase tracking-tighter">
                        {section.badge}
                      </Badge>
                    )}
                    {section.disabled && (
                      <Badge variant="outline" className="text-[10px] px-1.5 h-4 border-dashed uppercase tracking-tighter">
                        Roadmapped
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mt-0.5">{section.description}</p>
                </div>
                <ChevronRight className="size-5 text-muted-foreground opacity-30 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
              </button>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-shadow shadow-sm overflow-hidden">
        <CardHeader className="bg-muted/30 border-b">
          <CardTitle className="text-lg">System Metadata</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">LawCRM Build Version</span>
            <span className="text-sm font-bold bg-muted px-2 py-1 rounded">1.0.0-PRO</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Deployment Tier</span>
            <Badge variant="secondary" className="rounded-full px-3">Enterprise Dev</Badge>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Database Engine</span>
            <span className="text-sm font-medium flex items-center gap-1.5">
              <Database className="size-3.5" />
              Ephemeral Demo Store
            </span>
          </div>
          <Separator className="my-2" />
          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
            <p className="text-xs text-primary/80 leading-relaxed font-medium">
              LawCRM is a mission-critical legal management ecosystem. To enable persistent document indexing
              and case archiving, please contact your systems administrator to link a PostgreSQL instance.
            </p>
          </div>
        </CardContent>
      </Card>

      <AgentSettingsDialog open={agentSettingsOpen} onOpenChange={setAgentSettingsOpen} />
      <BrandingSettingsDialog open={brandingOpen} onOpenChange={setBrandingOpen} />
      <FirmInfoSettingsDialog open={firmInfoOpen} onOpenChange={setFirmInfoOpen} />
    </div>
  )
}
