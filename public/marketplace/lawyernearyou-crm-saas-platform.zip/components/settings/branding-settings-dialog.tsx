'use client'

import React, { useState, useEffect } from "react"
import { useTenant } from '@/lib/tenant-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Palette, Globe, Image as ImageIcon, CheckCircle2 } from 'lucide-react'

interface BrandingSettingsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function BrandingSettingsDialog({ open, onOpenChange }: BrandingSettingsDialogProps) {
  const { currentTenant, updateBranding } = useTenant()
  const [isSaving, setIsSaving] = useState(false)
  const [formData, setFormData] = useState({
    brandName: currentTenant.brandName || '',
    primaryColor: currentTenant.primaryColor || '#14b8a6',
    accentColor: currentTenant.accentColor || '#0f766e',
    subdomain: currentTenant.subdomain || '',
    customDomain: currentTenant.customDomain || '',
    logoUrl: currentTenant.logoUrl || '',
  })

  useEffect(() => {
    setFormData({
      brandName: currentTenant.brandName || '',
      primaryColor: currentTenant.primaryColor || '#14b8a6',
      accentColor: currentTenant.accentColor || '#0f766e',
      subdomain: currentTenant.subdomain || '',
      customDomain: currentTenant.customDomain || '',
      logoUrl: currentTenant.logoUrl || '',
    })
  }, [currentTenant, open])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)
    try {
      await updateBranding(formData)
      onOpenChange(false)
    } catch (err) {
      console.error(err)
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Palette className="size-5 text-primary" />
            White-label & Branding
          </DialogTitle>
          <DialogDescription>
            Customize your law firm's identity across the entire platform.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2 font-bold">
                <ImageIcon className="size-4" />
                Visual Identity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Brand Name</Label>
                <Input 
                  value={formData.brandName} 
                  onChange={e => setFormData({...formData, brandName: e.target.value})}
                  placeholder="e.g. Al-Qasim Legal"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Primary Color</Label>
                  <div className="flex gap-2">
                    <Input 
                      type="color" 
                      className="w-12 h-10 p-1"
                      value={formData.primaryColor}
                      onChange={e => setFormData({...formData, primaryColor: e.target.value})}
                    />
                    <Input 
                      value={formData.primaryColor}
                      onChange={e => setFormData({...formData, primaryColor: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Accent Color</Label>
                  <div className="flex gap-2">
                    <Input 
                      type="color" 
                      className="w-12 h-10 p-1"
                      value={formData.accentColor}
                      onChange={e => setFormData({...formData, accentColor: e.target.value})}
                    />
                    <Input 
                      value={formData.accentColor}
                      onChange={e => setFormData({...formData, accentColor: e.target.value})}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2 font-bold">
                <Globe className="size-4" />
                Domain Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Subdomain</Label>
                <div className="flex items-center gap-2">
                  <Input 
                    value={formData.subdomain}
                    onChange={e => setFormData({...formData, subdomain: e.target.value})}
                    placeholder="my-firm"
                  />
                  <span className="text-sm text-muted-foreground">.lawcrm.com</span>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Custom Domain</Label>
                <Input 
                  value={formData.customDomain}
                  onChange={e => setFormData({...formData, customDomain: e.target.value})}
                  placeholder="www.lawyer-name.com"
                />
                <p className="text-[10px] text-muted-foreground italic">Enterprise feature: Point your A record to our IP.</p>
              </div>
            </CardContent>
          </Card>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSaving}>
              {isSaving ? 'Saving...' : 'Deploy Branding'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
