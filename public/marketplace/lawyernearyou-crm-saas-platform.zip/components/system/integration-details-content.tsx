'use client'

import React, { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft, Check, Copy, ExternalLink, Globe, Power, Puzzle, RefreshCcw, Save, Shield, Terminal, Settings2 } from 'lucide-react'
import { useLanguage } from '@/lib/language-context'
import { initialApps, IntegrationApp } from '@/lib/data/integrations'
import { toast } from 'sonner'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

export function IntegrationDetailsContent({ id }: { id: string }) {
    const { language } = useLanguage()
    const router = useRouter()

    // In a real app, this would be fetched from an API
    const [app, setApp] = useState<IntegrationApp | null>(null)
    const [isLoading, setIsLoading] = useState(true)
    const [isSaving, setIsSaving] = useState(false)

    // Form states
    const [apiKey, setApiKey] = useState('')
    const [secretKey, setSecretKey] = useState('')
    const [webhookUrl, setWebhookUrl] = useState(`https://api.lawcrm.com/webhooks/${id}/event`)

    useEffect(() => {
        // Simulate API fetch
        const found = initialApps.find(a => a.id === id)
        if (found) {
            setApp(found)
        }
        setIsLoading(false)
    }, [id])

    const handleSave = () => {
        setIsSaving(true)
        setTimeout(() => {
            setIsSaving(false)
            toast.success(language === 'ar' ? 'تم حفظ الإعدادات بنجاح!' : 'Settings saved successfully!')
        }, 1000)
    }

    const handleConnectToggle = () => {
        if (!app) return
        const newState = !app.connected
        setApp({ ...app, connected: newState })
        if (newState) {
            toast.success(language === 'ar' ? `تم تفعيل ${app.name}` : `${app.name} activated`)
        } else {
            toast.info(language === 'ar' ? `تم إيقاف ${app.name}` : `${app.name} deactivated`)
        }
    }

    if (isLoading) {
        return <div className="flex h-[400px] items-center justify-center"><RefreshCcw className="size-6 animate-spin text-muted-foreground" /></div>
    }

    if (!app) {
        return (
            <div className="flex flex-col h-[400px] items-center justify-center gap-4">
                <Puzzle className="size-12 text-muted-foreground/30" />
                <h2 className="text-xl font-bold">{language === 'ar' ? 'التطبيق غير موجود' : 'Integration Not Found'}</h2>
                <Button variant="outline" onClick={() => router.push('/system/integrations')}><ArrowLeft className="mr-2 size-4" />{language === 'ar' ? 'العودة' : 'Go Back'}</Button>
            </div>
        )
    }

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-5xl mx-auto">
            {/* Header */}
            <div className="flex flex-col gap-4">
                <Button variant="ghost" size="sm" className="w-fit -ml-2 text-muted-foreground hover:text-foreground" onClick={() => router.push('/system/integrations')}>
                    <ArrowLeft className="mr-2 size-4 rtl:rotate-180" />
                    {language === 'ar' ? 'العودة إلى التطبيقات' : 'Back to Integrations'}
                </Button>

                <div className="flex flex-col md:flex-row md:items-start justify-between gap-6 bg-card p-6 rounded-2xl border shadow-sm">
                    <div className="flex items-start gap-5">
                        <div className="size-16 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0 border border-primary/20">
                            {/* Assuming Globe as fallback for now since we can't map string -> icon easily in a dynamic generic file without a massive map */}
                            <Puzzle className="size-8 text-primary" />
                        </div>
                        <div>
                            <div className="flex items-center gap-3 mb-1">
                                <h1 className="text-2xl font-bold">{app.name}</h1>
                                {app.connected ? (
                                    <Badge variant="secondary" className="bg-green-100/50 text-green-700 dark:bg-green-900/20 dark:text-green-400 gap-1"><Check className="size-3" />{language === 'ar' ? 'نشط' : 'Active'}</Badge>
                                ) : (
                                    <Badge variant="outline" className="text-muted-foreground gap-1"><Power className="size-3" />{language === 'ar' ? 'غير نشط' : 'Inactive'}</Badge>
                                )}
                            </div>
                            <p className="text-muted-foreground max-w-lg text-sm">{app.description[language]}</p>
                        </div>
                    </div>

                    <div className="flex shrink-0 items-center gap-3">
                        <Button variant={app.connected ? "destructive" : "default"} onClick={handleConnectToggle} className="w-full md:w-auto">
                            {app.connected ? (
                                language === 'ar' ? 'إلغاء التفعيل' : 'Deactivate'
                            ) : (
                                language === 'ar' ? 'تفعيل الربط' : 'Activate Integration'
                            )}
                        </Button>
                    </div>
                </div>
            </div>

            <Tabs defaultValue="config" className="w-full">
                <TabsList className="w-full justify-start h-auto p-1 bg-transparent border-b rounded-none gap-6">
                    <TabsTrigger value="config" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 pb-3 pt-2 font-medium">
                        <Settings2 className="mr-2 size-4" />
                        {language === 'ar' ? 'الإعدادات' : 'Configuration'}
                    </TabsTrigger>
                    <TabsTrigger value="api" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 pb-3 pt-2 font-medium">
                        <Terminal className="mr-2 size-4" />
                        {language === 'ar' ? 'المطورين (API)' : 'Developer (API)'}
                    </TabsTrigger>
                </TabsList>

                <TabsContent value="config" className="mt-6 focus-visible:outline-none">
                    {app.id === 'whatsapp' ? (
                        <WhatsAppConfig language={language} isConnected={app.connected} />
                    ) : app.id === 'stripe' ? (
                        <StripeConfig language={language} apiKey={apiKey} setApiKey={setApiKey} secretKey={secretKey} setSecretKey={setSecretKey} isSaving={isSaving} onSave={handleSave} />
                    ) : app.id === 'google-meet' ? (
                        <GoogleMeetConfig language={language} isConnected={app.connected} />
                    ) : (
                        <GenericConfig language={language} appName={app.name} />
                    )}
                </TabsContent>

                <TabsContent value="api" className="mt-6 focus-visible:outline-none">
                    <div className="grid gap-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-lg">{language === 'ar' ? 'رابط الإشعارات (Webhook URL)' : 'Webhook URL'}</CardTitle>
                                <CardDescription>
                                    {language === 'ar' ? 'قم بنسخ هذا الرابط ووضعه في تطبيقك الخارجي لاستقبال التحديثات.' : 'Copy this URL and paste it into your external provider to receive events.'}
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="flex items-center gap-2">
                                    <Input value={webhookUrl} readOnly className="bg-muted font-mono text-xs" />
                                    <Button variant="secondary" size="icon" onClick={() => {
                                        navigator.clipboard.writeText(webhookUrl)
                                        toast.success(language === 'ar' ? 'تم النسخ!' : 'Copied!')
                                    }}>
                                        <Copy className="size-4" />
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader>
                                <CardTitle className="text-lg">{language === 'ar' ? 'دليل الاستخدام' : 'Documentation'}</CardTitle>
                                <CardDescription>
                                    {language === 'ar' ? `اقرأ وثائق المطورين لمعرفة كيفية الربط مع ${app.name}.` : `Read the developer docs to learn how to integrate with ${app.name}.`}
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Button variant="outline" className="gap-2">
                                    <ExternalLink className="size-4" />
                                    {language === 'ar' ? 'عرض الوثائق' : 'View Documentation'}
                                </Button>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>
            </Tabs>
        </div>
    )
}

// ----------------------------------------------------------------------
// Specific Configuration Components
// ----------------------------------------------------------------------

function WhatsAppConfig({ language, isConnected }: { language: 'en' | 'ar', isConnected: boolean }) {
    if (isConnected) {
        return (
            <Card className="border-green-200 dark:border-green-900/50 shadow-sm overflow-hidden">
                <div className="bg-green-50 dark:bg-green-900/20 px-6 py-4 border-b border-green-100 dark:border-green-900/50 flex items-center gap-3">
                    <Shield className="size-5 text-green-600 dark:text-green-500" />
                    <div>
                        <h3 className="font-semibold text-green-900 dark:text-green-400">{language === 'ar' ? 'الجهاز متصل وموثق' : 'Device Connected & Authenticated'}</h3>
                        <p className="text-xs text-green-700/80 dark:text-green-400/80">{language === 'ar' ? 'رسائل واتساب تتم مزامنتها الآن مع صندوق الوارد الخاص بك.' : 'WhatsApp messages are now syncing to your Omnichannel Inbox.'}</p>
                    </div>
                </div>
                <CardContent className="p-6">
                    <h4 className="text-sm font-medium mb-4 uppercase tracking-wider text-muted-foreground">{language === 'ar' ? 'الأجهزة النشطة' : 'Active Devices'}</h4>
                    <div className="flex items-center justify-between p-4 border rounded-xl bg-background">
                        <div className="flex items-center gap-4">
                            <div className="size-10 rounded-full bg-muted flex items-center justify-center"><Globe className="size-5 text-muted-foreground" /></div>
                            <div>
                                <p className="font-medium text-sm">Mac OS - Google Chrome</p>
                                <p className="text-xs text-muted-foreground mt-0.5">{language === 'ar' ? 'آخر نشاط: منذ دقيقتين' : 'Last active: 2 minutes ago'}</p>
                            </div>
                        </div>
                        <Badge variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-100">{language === 'ar' ? 'الحالي' : 'Current'}</Badge>
                    </div>
                </CardContent>
            </Card>
        )
    }

    return (
        <Card className="shadow-sm">
            <CardHeader className="pb-4">
                <CardTitle>{language === 'ar' ? 'ربط جهاز جديد' : 'Link New Device'}</CardTitle>
                <CardDescription>
                    {language === 'ar' ? 'قم بمسح رمز الاستجابة السريعة باستخدام تطبيق واتساب على هاتفك لتسجيل الدخول.' : 'Scan the QR code using the WhatsApp app on your phone to log in.'}
                </CardDescription>
            </CardHeader>
            <CardContent>
                <div className="flex flex-col md:flex-row items-center gap-12 bg-muted/30 p-8 rounded-2xl border border-dashed">
                    <div className="w-full max-w-[240px] aspect-square bg-white p-4 rounded-xl border flex items-center justify-center relative">
                        {/* Mock QR */}
                        <div className="grid grid-cols-6 grid-rows-6 gap-1 size-full relative">
                            {Array.from({ length: 36 }).map((_, i) => (
                                <div key={i} className={`bg-slate-900 rounded-sm ${Math.random() > 0.5 ? 'opacity-100' : 'opacity-10'}`} />
                            ))}
                            <div className="absolute top-0 left-0 size-12 bg-white p-1 border-[6px] border-slate-900 rounded-tl-lg"><div className="size-full bg-slate-900" /></div>
                            <div className="absolute top-0 right-0 size-12 bg-white p-1 border-[6px] border-slate-900 rounded-tr-lg"><div className="size-full bg-slate-900" /></div>
                            <div className="absolute bottom-0 left-0 size-12 bg-white p-1 border-[6px] border-slate-900 rounded-bl-lg"><div className="size-full bg-slate-900" /></div>
                        </div>

                        {/* Loading spinner overlay indicating waiting for scan */}
                        <div className="absolute inset-0 bg-white/80 backdrop-blur-[1px] rounded-xl flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                            <Button size="sm">{language === 'ar' ? 'إعادة التحميل' : 'Reload QR'}</Button>
                        </div>
                    </div>

                    <div className="space-y-6 flex-1">
                        <ol className="list-decimal list-inside space-y-4 text-sm text-muted-foreground rtl:marker:mr-0 pl-0 rtl:pr-0">
                            <li><strong className="text-foreground">{language === 'ar' ? 'افتح واتساب' : 'Open WhatsApp'}</strong> {language === 'ar' ? 'على هاتفك' : 'on your phone'}</li>
                            <li><strong className="text-foreground">{language === 'ar' ? 'اضغط على القائمة' : 'Tap Menu'}</strong> <span className="text-xs border px-1 rounded mx-1">⋮</span> {language === 'ar' ? 'أو الإعدادات' : 'or Settings'} <span className="text-xs border px-1 rounded mx-1">⚙</span></li>
                            <li><strong className="text-foreground">{language === 'ar' ? 'اختر الأجهزة المرتبطة' : 'Select Linked Devices'}</strong> {language === 'ar' ? 'ثم اضغط على ربط جهاز' : 'then tap Link a Device'}</li>
                            <li><strong className="text-foreground">{language === 'ar' ? 'وجه الكاميرا' : 'Point your camera'}</strong> {language === 'ar' ? 'نحو الشاشة لمسح الرمز أعلاه' : 'at the screen to scan the code above'}</li>
                        </ol>
                    </div>
                </div>
            </CardContent>
        </Card>
    )
}

function StripeConfig({ language, apiKey, setApiKey, secretKey, setSecretKey, isSaving, onSave }: any) {
    return (
        <Card className="shadow-sm">
            <CardHeader>
                <CardTitle>{language === 'ar' ? 'مفاتيح واجهة برمجة التطبيقات (API Keys)' : 'API Keys'}</CardTitle>
                <CardDescription>
                    {language === 'ar' ? 'أدخل مفاتيح Stripe الخاصة بك لتفعيل الدفع الإلكتروني. نوصي بإنشاء مفاتيح مقيدة.' : 'Enter your Stripe API keys to enable inline payments. We recommend restricted keys.'}
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="space-y-2">
                    <Label htmlFor="pk">{language === 'ar' ? 'المفتاح العام (Publishable Key)' : 'Publishable Key'}</Label>
                    <Input id="pk" placeholder="pk_live_..." value={apiKey} onChange={e => setApiKey(e.target.value)} />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="sk">{language === 'ar' ? 'المفتاح السري (Secret Key)' : 'Secret Key'}</Label>
                    <Input id="sk" type="password" placeholder="sk_live_..." value={secretKey} onChange={e => setSecretKey(e.target.value)} />
                </div>

                <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-900/50 rounded-lg p-4 text-sm text-amber-800 dark:text-amber-500">
                    {language === 'ar' ? 'تبدأ هذه المفاتيح بالعمل فور حفظها. تأكد من أنك في وضع التشغيل (Live Mode) وليس وضع الاختبار (Test Mode).' : 'These keys become active immediately upon saving. Ensure you are using Live Mode keys, not Test Mode.'}
                </div>
            </CardContent>
            <CardFooter className="bg-muted/30 border-t justify-end py-4">
                <Button onClick={onSave} disabled={isSaving}>
                    {isSaving && <RefreshCcw className="mr-2 size-4 animate-spin rtl:ml-2 rtl:mr-0" />}
                    <Save className="mr-2 size-4 rtl:ml-2 rtl:mr-0" />
                    {language === 'ar' ? 'حفظ التغييرات' : 'Save Changes'}
                </Button>
            </CardFooter>
        </Card>
    )
}

function GoogleMeetConfig({ language, isConnected }: { language: 'en' | 'ar', isConnected: boolean }) {
    return (
        <Card className="shadow-sm">
            <CardHeader>
                <CardTitle>{language === 'ar' ? 'تكوين جوجل ميت' : 'Google Meet Setup'}</CardTitle>
                <CardDescription>
                    {language === 'ar' ? 'قم بربط حساب جوجل الخاص بك لجدولة الاجتماعات مباشرة من ملفات القضايا.' : 'Link your Google account to schedule meetings directly from case files.'}
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="flex flex-col items-center justify-center py-8 bg-muted/30 rounded-2xl border border-dashed gap-4">
                    <div className="size-16 rounded-full bg-white shadow-sm flex items-center justify-center border">
                        <svg className="size-8" viewBox="0 0 24 24">
                            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
                            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                        </svg>
                    </div>
                    <div className="text-center">
                        <p className="font-medium">{isConnected ? (language === 'ar' ? 'تم ربط الحساب بنجاح' : 'Account Linked Successfully') : (language === 'ar' ? 'لم يتم ربط حساب جوجل بعد' : 'No Google account linked yet')}</p>
                        <p className="text-xs text-muted-foreground mt-1">{isConnected ? 'lawfirm-admin@gmail.com' : (language === 'ar' ? 'اربط حسابك للبدء في استخدام جوجل ميت.' : 'Link your account to start using Google Meet.')}</p>
                    </div>
                    <Button variant={isConnected ? "outline" : "default"} className="mt-2">
                        {isConnected ? (language === 'ar' ? 'تغيير الحساب' : 'Change Account') : (language === 'ar' ? 'ربط حساب جوجل' : 'Connect Google Account')}
                    </Button>
                </div>

                <div className="space-y-4">
                    <h4 className="text-sm font-semibold">{language === 'ar' ? 'تفضيلات الاجتماع' : 'Meeting Preferences'}</h4>
                    <div className="grid gap-3">
                        <div className="flex items-center justify-between p-3 border rounded-lg">
                            <div>
                                <p className="text-sm font-medium">{language === 'ar' ? 'مزامنة مع تقويم جوجل' : 'Sync with Google Calendar'}</p>
                                <p className="text-xs text-muted-foreground">{language === 'ar' ? 'إضافة المواعيد تلقائياً إلى تقويمك.' : 'Automatically add appointments to your calendar.'}</p>
                            </div>
                            <div className="size-5 rounded-full bg-primary flex items-center justify-center"><Check className="size-3 text-primary-foreground" /></div>
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    )
}

function GenericConfig({ language, appName }: { language: 'en' | 'ar', appName: string }) {
    return (
        <Card className="shadow-sm border-dashed">
            <CardContent className="p-12 flex flex-col items-center justify-center text-center gap-4">
                <Settings2 className="size-12 text-muted-foreground/30" />
                <div>
                    <h3 className="text-lg font-medium text-foreground">{language === 'ar' ? 'لا توجد إعدادات إضافية' : 'No Additional Configuration'}</h3>
                    <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">
                        {language === 'ar'
                            ? `تطبيق ${appName} لا يتطلب إعدادات متقدمة للعمل. لقد تم تكوينه مسبقاً للعمل مع تدفق عملك بأمان.`
                            : `${appName} does not require any advanced setup. It is pre-configured to securely work with your workflow.`}
                    </p>
                </div>
            </CardContent>
        </Card>
    )
}
