'use client'

import React, { useState } from 'react'
import {
    History, Search, Filter, ShieldAlert, User, FileEdit, Trash2, PlusCircle, Clock, Download
} from 'lucide-react'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { useLanguage } from '@/lib/language-context'

interface LogEntry {
    id: number
    action: string
    target: string
    user: string
    time: string
    type: 'edit' | 'add' | 'delete' | 'security' | 'export'
    level: 'info' | 'success' | 'warning' | 'danger'
}

const initialLogs: LogEntry[] = [
    { id: 1, action: 'Updated Case', target: 'Case #2024-001', user: 'Ahmed Mansour', time: '5 mins ago', type: 'edit', level: 'info' },
    { id: 2, action: 'Added New Lead', target: 'Sara Kamel', user: 'Mohamed Admin', time: '1 hour ago', type: 'add', level: 'success' },
    { id: 3, action: 'Deleted Document', target: 'Contract_Draft_v1.pdf', user: 'Laila Assistant', time: '2 hours ago', type: 'delete', level: 'warning' },
    { id: 4, action: 'Exported Revenue Report', target: 'Feb 2024 Finances', user: 'Ahmed Mansour', time: '4 hours ago', type: 'export', level: 'info' },
    { id: 5, action: 'Security Login Alert', target: 'New IP detected', user: 'System', time: 'Yesterday', type: 'security', level: 'danger' },
    { id: 6, action: 'Updated User Permissions', target: 'Laila Assistant', user: 'Mohamed Admin', time: 'Yesterday', type: 'edit', level: 'info' },
    { id: 7, action: 'Failed Login Attempt', target: 'Unknown IP 192.168.1.50', user: 'System', time: '2 days ago', type: 'security', level: 'danger' },
]

export function AuditLogsContent() {
    const { language } = useLanguage()
    const [logs] = useState<LogEntry[]>(initialLogs)
    const [searchTerm, setSearchTerm] = useState('')
    const [levelFilter, setLevelFilter] = useState<string>('all')
    const [feedback, setFeedback] = useState<string | null>(null)

    const showFeedback = (msg: string) => { setFeedback(msg); setTimeout(() => setFeedback(null), 2500) }

    const filteredLogs = logs.filter(log => {
        const matchSearch = log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
            log.target.toLowerCase().includes(searchTerm.toLowerCase()) ||
            log.user.toLowerCase().includes(searchTerm.toLowerCase())
        const matchLevel = levelFilter === 'all' || log.level === levelFilter
        return matchSearch && matchLevel
    })

    const securityAlerts = logs.filter(l => l.level === 'danger').length

    const handleExport = () => {
        const csvContent = filteredLogs.map(l => `${l.action},${l.target},${l.user},${l.time},${l.level}`).join('\n')
        const blob = new Blob([`Action,Target,User,Time,Level\n${csvContent}`], { type: 'text/csv' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = 'audit_logs.csv'
        a.click()
        URL.revokeObjectURL(url)
        showFeedback(language === 'ar' ? '📥 تم تصدير السجلات بنجاح' : '📥 Logs exported successfully')
    }

    const getLogIcon = (type: string) => {
        switch (type) {
            case 'edit': return <FileEdit className="size-3.5 text-blue-500" />
            case 'add': return <PlusCircle className="size-3.5 text-green-500" />
            case 'delete': return <Trash2 className="size-3.5 text-red-500" />
            case 'security': return <ShieldAlert className="size-3.5 text-orange-500" />
            default: return <History className="size-3.5" />
        }
    }

    const getLevelBadge = (level: string) => {
        const labels: Record<string, Record<string, string>> = {
            success: { ar: 'نجاح', en: 'Success' },
            warning: { ar: 'تحذير', en: 'Warning' },
            danger: { ar: 'تنبيه أمني', en: 'Alert' },
            info: { ar: 'معلومات', en: 'Info' },
        }
        const colors: Record<string, string> = {
            success: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
            warning: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400',
            danger: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
            info: 'bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-400',
        }
        return <Badge variant="secondary" className={`${colors[level]} text-[10px]`}>{labels[level]?.[language] || level}</Badge>
    }

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && (
                <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300">
                    <div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div>
                </div>
            )}

            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'سجلات الأمان والتدقيق' : 'Audit Logs & Security'}</h1>
                    <p className="text-muted-foreground">{language === 'ar' ? 'تتبع كل نشاط يتم داخل نظام المكتب لضمان الأمان والشفافية.' : 'Track every activity within the firm system to ensure security and transparency.'}</p>
                </div>
                <Button variant="outline" className="gap-2" onClick={handleExport}><Download className="size-4" />{language === 'ar' ? 'تصدير السجلات' : 'Export Logs'}</Button>
            </div>

            <Card className="border-none shadow-sm">
                <CardHeader className="pb-3 border-b border-muted/50">
                    <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                        <div className="flex flex-1 items-center gap-2 max-w-md">
                            <div className="relative w-full">
                                <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground rtl:left-auto rtl:right-2.5" />
                                <Input className="pl-8 rtl:pl-3 rtl:pr-8" placeholder={language === 'ar' ? 'البحث في السجلات...' : 'Search activity logs...'} value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                            </div>
                            <Select value={levelFilter} onValueChange={setLevelFilter}>
                                <SelectTrigger className="w-[140px]"><Filter className="size-4 mr-2 rtl:mr-0 rtl:ml-2" /><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">{language === 'ar' ? 'الكل' : 'All'}</SelectItem>
                                    <SelectItem value="info">{language === 'ar' ? 'معلومات' : 'Info'}</SelectItem>
                                    <SelectItem value="success">{language === 'ar' ? 'نجاح' : 'Success'}</SelectItem>
                                    <SelectItem value="warning">{language === 'ar' ? 'تحذير' : 'Warning'}</SelectItem>
                                    <SelectItem value="danger">{language === 'ar' ? 'تنبيهات أمنية' : 'Alerts'}</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <div className="flex items-center gap-1.5 p-2 rounded-lg bg-orange-100/10 text-orange-600"><ShieldAlert className="size-4" /><span>{securityAlerts} {language === 'ar' ? 'تنبيهات أمنية' : 'Security Alerts'}</span></div>
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="p-0">
                    <div className="relative w-full overflow-auto">
                        <table className="w-full caption-bottom text-sm rtl:text-right">
                            <thead className="[&_tr]:border-b bg-muted/20">
                                <tr className="border-b transition-colors hover:bg-muted/50">
                                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground rtl:text-right whitespace-nowrap">{language === 'ar' ? 'النشاط' : 'Activity'}</th>
                                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground rtl:text-right whitespace-nowrap">{language === 'ar' ? 'المستخدم' : 'User'}</th>
                                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground rtl:text-right whitespace-nowrap">{language === 'ar' ? 'الهدف' : 'Target'}</th>
                                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground rtl:text-right whitespace-nowrap">{language === 'ar' ? 'الوقت' : 'Time'}</th>
                                    <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground rtl:text-left whitespace-nowrap">{language === 'ar' ? 'المستوى' : 'Level'}</th>
                                </tr>
                            </thead>
                            <tbody className="[&_tr:last-child]:border-0">
                                {filteredLogs.length === 0 ? (
                                    <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">{language === 'ar' ? 'لا توجد سجلات' : 'No logs found'}</td></tr>
                                ) : filteredLogs.map((log) => (
                                    <tr key={log.id} className="border-b transition-colors hover:bg-muted/30">
                                        <td className="p-4 align-middle"><div className="flex items-center gap-2.5"><div className="rounded-full bg-muted p-1.5">{getLogIcon(log.type)}</div><span className="font-medium whitespace-nowrap">{log.action}</span></div></td>
                                        <td className="p-4 align-middle whitespace-nowrap"><div className="flex items-center gap-2"><div className="size-6 rounded-full bg-primary/10 flex items-center justify-center text-[10px] text-primary"><User className="size-3" /></div>{log.user}</div></td>
                                        <td className="p-4 align-middle font-mono text-xs">{log.target}</td>
                                        <td className="p-4 align-middle"><div className="flex items-center gap-1.5 text-muted-foreground whitespace-nowrap"><Clock className="size-3" />{log.time}</div></td>
                                        <td className="p-4 align-middle text-right rtl:text-left">{getLevelBadge(log.level)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>
        </div>
    )
}
