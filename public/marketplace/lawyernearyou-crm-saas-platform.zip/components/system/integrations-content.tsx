'use client'

import React, { useState } from 'react'
import {
    Puzzle, Search, Check, ExternalLink, Shield, Activity, Zap, Box, Globe, MessageSquare, Mail
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { useLanguage } from '@/lib/language-context'

import Link from 'next/link'
import { initialApps, IntegrationApp } from '@/lib/data/integrations'

export function IntegrationsContent() {
    const { language } = useLanguage()
    const [apps, setApps] = useState<IntegrationApp[]>(initialApps)
    const [searchTerm, setSearchTerm] = useState('')
    const [feedback, setFeedback] = useState<string | null>(null)

    const showFeedback = (msg: string) => { setFeedback(msg); setTimeout(() => setFeedback(null), 2500) }

    const toggleConnection = (appId: string) => {
        setApps(prev => prev.map(app => {
            if (app.id === appId) {
                const newState = !app.connected
                showFeedback(newState
                    ? (language === 'ar' ? `✅ تم ربط ${app.name} بنجاح` : `✅ ${app.name} connected successfully`)
                    : (language === 'ar' ? `❌ تم فصل ${app.name}` : `❌ ${app.name} disconnected`))
                return { ...app, connected: newState }
            }
            return app
        }))
    }

    const filteredApps = apps.filter(app =>
        app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.category.toLowerCase().includes(searchTerm.toLowerCase())
    )

    const connectedCount = apps.filter(a => a.connected).length

    // Map stored string icon names back to Lucide components
    const iconMap: Record<string, React.ElementType> = {
        'Globe': Globe,
        'Activity': Activity,
        'Zap': Zap,
        'MessageSquare': MessageSquare,
        'Mail': Mail
    };

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && (
                <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300">
                    <div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div>
                </div>
            )}

            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'سوق التطبيقات والربط' : 'Integrations Marketplace'}</h1>
                    <p className="text-muted-foreground">{language === 'ar' ? 'اربط مكتبك مع أفضل الأدوات والخدمات العالمية.' : 'Connect your firm with the world\'s best tools and services.'}</p>
                </div>
                <div className="flex items-center gap-2">
                    <Badge variant="outline" className="px-3 h-8 gap-1"><Shield className="size-3 text-green-500" />{connectedCount} {language === 'ar' ? 'متصل' : 'Connected'}</Badge>
                </div>
            </div>

            <div className="relative max-w-md">
                <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground rtl:left-auto rtl:right-2.5" />
                <Input className="pl-8 rtl:pl-3 rtl:pr-8" placeholder={language === 'ar' ? 'بحث عن تطبيق...' : 'Search apps...'} value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredApps.length === 0 ? (
                    <p className="text-muted-foreground col-span-full text-center py-12">{language === 'ar' ? 'لا توجد نتائج' : 'No apps found'}</p>
                ) : filteredApps.map((app) => {
                    const AppIcon = iconMap[app.iconName] || Puzzle;
                    return (
                        <Link href={`/system/integrations/${app.id}`} key={app.id} className="block group">
                            <Card className="h-full hover:border-primary/50 transition-all hover:shadow-md cursor-pointer border-none bg-muted/30 shadow-sm overflow-hidden flex flex-col relative group-hover:bg-muted/50">
                                <CardHeader className="pb-2">
                                    <div className="flex items-center justify-between mb-4">
                                        <div className="rounded-xl bg-background p-2.5 shadow-sm group-hover:scale-110 transition-transform"><AppIcon className="size-6 text-primary" /></div>
                                        {app.connected ? (
                                            <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 gap-1 uppercase text-[10px]"><Check className="size-3" />{language === 'ar' ? 'متصل' : 'Connected'}</Badge>
                                        ) : (
                                            <Badge variant="outline" className="text-muted-foreground gap-1 uppercase text-[10px] bg-background/50">{language === 'ar' ? 'غير متصل' : 'Not Connected'}</Badge>
                                        )}
                                    </div>
                                    <CardTitle className="text-lg group-hover:text-primary transition-colors">{app.name}</CardTitle>
                                    <CardDescription className="text-xs uppercase tracking-wider">{app.category}</CardDescription>
                                </CardHeader>
                                <CardContent className="flex-1 py-4"><p className="text-sm text-balance leading-relaxed text-muted-foreground">{app.description[language]}</p></CardContent>
                                <CardFooter className="pt-2 bg-muted/20 border-t border-muted/50 justify-end">
                                    <div className="flex items-center text-xs text-primary font-medium gap-1 opacity-0 group-hover:opacity-100 transition-opacity translate-y-1 group-hover:translate-y-0 duration-300">
                                        {language === 'ar' ? 'إدارة الإعدادات' : 'Manage Settings'} <ExternalLink className="size-3 rtl:rotate-180" />
                                    </div>
                                </CardFooter>
                            </Card>
                        </Link>
                    );
                })}
            </div>

            <div className="rounded-2xl bg-primary/5 border border-primary/10 p-8 text-center mt-12">
                <Box className="mx-auto size-12 text-primary/40 mb-4" />
                <h3 className="text-xl font-bold mb-2">{language === 'ar' ? 'هل تريد ربط خدمة مخصصة؟' : 'Need a custom integration?'}</h3>
                <p className="text-muted-foreground max-w-lg mx-auto mb-6">{language === 'ar' ? 'يمكنك استخدام LawCRM API للربط مع أي تطبيق خارجي آخر أو استخدام Zapier للأتمتة.' : 'Explore our Developer Portal to build your own integrations or use Zapier for automation.'}</p>
                <Button variant="outline" className="gap-2" onClick={() => showFeedback(language === 'ar' ? '📚 جاري فتح وثائق المطورين...' : '📚 Opening Developer Docs...')}>{language === 'ar' ? 'وثائق المطورين' : 'Developer Docs'}<ExternalLink className="size-4" /></Button>
            </div>
        </div>
    )
}
