'use client'

import React, { useState } from 'react'
import { Megaphone, Plus, Pin, Trash2, Eye } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { useLanguage } from '@/lib/language-context'

interface Announcement { id: number; title: string; body: string; author: string; date: string; pinned: boolean; views: number }

const initial: Announcement[] = [
    { id: 1, title: 'Office Closure - National Holiday', body: 'The office will be closed on March 20th for the national holiday. All hearings have been rescheduled.', author: 'Admin', date: '2024-03-07', pinned: true, views: 24 },
    { id: 2, title: 'New Billing System', body: 'We have upgraded to a new billing system. Please check the Invoices section for updated features.', author: 'Mohamed Admin', date: '2024-03-05', pinned: false, views: 18 },
    { id: 3, title: 'Team Building Event', body: 'Join us for a team building event this Friday at 5 PM. Attendance is highly encouraged!', author: 'Admin', date: '2024-03-03', pinned: false, views: 12 },
]

export function AnnouncementsContent() {
    const { language } = useLanguage()
    const [announcements, setAnnouncements] = useState<Announcement[]>(initial)
    const [open, setOpen] = useState(false)
    const [form, setForm] = useState({ title: '', body: '' })
    const [feedback, setFeedback] = useState<string | null>(null)
    const show = (m: string) => { setFeedback(m); setTimeout(() => setFeedback(null), 2500) }

    const add = () => {
        if (!form.title || !form.body) return
        setAnnouncements(p => [{ id: Date.now(), title: form.title, body: form.body, author: 'You', date: new Date().toISOString().split('T')[0], pinned: false, views: 0 }, ...p])
        setForm({ title: '', body: '' }); setOpen(false)
        show(language === 'ar' ? '✅ تم نشر الإعلان' : '✅ Announcement published')
    }

    const togglePin = (id: number) => { setAnnouncements(p => p.map(a => a.id === id ? { ...a, pinned: !a.pinned } : a)); show(language === 'ar' ? '📌 تم التحديث' : '📌 Updated') }
    const del = (id: number) => { setAnnouncements(p => p.filter(a => a.id !== id)); show(language === 'ar' ? '🗑️ تم الحذف' : '🗑️ Removed') }

    const sorted = [...announcements].sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0))

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300"><div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div></div>}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div><h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'الإعلانات الداخلية' : 'Announcements'}</h1><p className="text-muted-foreground">{language === 'ar' ? 'إعلانات إدارية للفريق والموظفين.' : 'Internal announcements for the team.'}</p></div>
                <Dialog open={open} onOpenChange={setOpen}>
                    <DialogTrigger asChild><Button className="gap-2"><Plus className="size-4" />{language === 'ar' ? 'إعلان جديد' : 'New Announcement'}</Button></DialogTrigger>
                    <DialogContent>
                        <DialogHeader><DialogTitle>{language === 'ar' ? 'إنشاء إعلان' : 'New Announcement'}</DialogTitle><DialogDescription>{language === 'ar' ? 'أنشئ إعلاناً جديداً للفريق.' : 'Create an announcement for the team.'}</DialogDescription></DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'العنوان *' : 'Title *'}</Label><Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} /></div>
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'المحتوى *' : 'Content *'}</Label><Textarea value={form.body} onChange={e => setForm(p => ({ ...p, body: e.target.value }))} rows={4} /></div>
                        </div>
                        <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button><Button onClick={add} disabled={!form.title || !form.body}>{language === 'ar' ? 'نشر' : 'Publish'}</Button></DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
            <div className="space-y-4">
                {sorted.map(a => (
                    <Card key={a.id} className={`border-none shadow-sm transition-all ${a.pinned ? 'ring-2 ring-primary/30 bg-primary/5' : 'hover:bg-muted/30'}`}>
                        <CardContent className="p-6">
                            <div className="flex items-start justify-between gap-4">
                                <div className="flex-1">
                                    <div className="flex items-center gap-2 mb-2">{a.pinned && <Badge className="h-5 text-[10px] gap-1"><Pin className="size-2.5" />{language === 'ar' ? 'مثبت' : 'Pinned'}</Badge>}<span className="text-xs text-muted-foreground">{a.author} · {a.date}</span></div>
                                    <h3 className="text-lg font-semibold mb-1">{a.title}</h3>
                                    <p className="text-sm text-muted-foreground leading-relaxed">{a.body}</p>
                                    <div className="flex items-center gap-1 mt-3 text-xs text-muted-foreground"><Eye className="size-3" />{a.views} {language === 'ar' ? 'مشاهدة' : 'views'}</div>
                                </div>
                                <div className="flex flex-col gap-1 shrink-0">
                                    <Button variant="ghost" size="icon" className="size-7" onClick={() => togglePin(a.id)} title={a.pinned ? 'Unpin' : 'Pin'}><Pin className={`size-3.5 ${a.pinned ? 'text-primary' : ''}`} /></Button>
                                    <Button variant="ghost" size="icon" className="size-7 text-destructive hover:text-destructive" onClick={() => del(a.id)}><Trash2 className="size-3.5" /></Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    )
}
