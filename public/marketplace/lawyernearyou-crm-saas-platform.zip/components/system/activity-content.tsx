'use client'

import React, { useState } from 'react'
import { Activity, Filter, Briefcase, UserPlus, FileEdit, Trash2, CreditCard, LogIn, Settings } from 'lucide-react'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useLanguage } from '@/lib/language-context'

interface ActivityItem { id: number; action: string; detail: string; user: string; time: string; type: 'case' | 'lead' | 'edit' | 'delete' | 'billing' | 'auth' | 'settings' }

const typeIcons: Record<string, React.ElementType> = { case: Briefcase, lead: UserPlus, edit: FileEdit, delete: Trash2, billing: CreditCard, auth: LogIn, settings: Settings }
const typeColors: Record<string, string> = { case: 'text-blue-500', lead: 'text-green-500', edit: 'text-yellow-500', delete: 'text-red-500', billing: 'text-purple-500', auth: 'text-orange-500', settings: 'text-gray-500' }

const initial: ActivityItem[] = [
    { id: 1, action: 'Case Updated', detail: 'Case #2024-015 status changed to "In Progress"', user: 'Ahmed M.', time: 'Just now', type: 'case' },
    { id: 2, action: 'New Lead Added', detail: 'Omar Fathy added via website form', user: 'System', time: '5 mins ago', type: 'lead' },
    { id: 3, action: 'Document Edited', detail: 'Contract_NDA_v2.docx modified', user: 'Laila H.', time: '15 mins ago', type: 'edit' },
    { id: 4, action: 'Invoice Sent', detail: 'INV-0046 sent to Ahmed Mansour ($3,500)', user: 'Mohamed Z.', time: '1 hour ago', type: 'billing' },
    { id: 5, action: 'User Login', detail: 'Ahmed Mansour logged in from Cairo, EG', user: 'System', time: '2 hours ago', type: 'auth' },
    { id: 6, action: 'File Deleted', detail: 'Draft_Lease_v1.pdf permanently removed', user: 'Laila H.', time: '3 hours ago', type: 'delete' },
    { id: 7, action: 'Settings Changed', detail: 'Firm timezone updated to Africa/Cairo', user: 'Admin', time: '5 hours ago', type: 'settings' },
    { id: 8, action: 'Case Created', detail: 'New case #2024-016 "Al-Nile vs. Ministry"', user: 'Ahmed M.', time: 'Yesterday', type: 'case' },
    { id: 9, action: 'Lead Converted', detail: 'Sara Kamel converted from lead to client', user: 'Mohamed Z.', time: 'Yesterday', type: 'lead' },
    { id: 10, action: 'Payment Received', detail: '$12,000 received for INV-0045 from TechCorp', user: 'System', time: '2 days ago', type: 'billing' },
]

export function ActivityContent() {
    const { language } = useLanguage()
    const [filter, setFilter] = useState('all')
    const filtered = initial.filter(a => filter === 'all' || a.type === filter)

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div><h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'شريط الأنشطة' : 'Activity Feed'}</h1><p className="text-muted-foreground">{language === 'ar' ? 'جميع الأنشطة والتحديثات في الوقت الفعلي.' : 'Real-time feed of all system activities and updates.'}</p></div>
                <Select value={filter} onValueChange={setFilter}><SelectTrigger className="w-[150px]"><Filter className="size-4 mr-2 rtl:mr-0 rtl:ml-2" /><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">{language === 'ar' ? 'الكل' : 'All'}</SelectItem><SelectItem value="case">{language === 'ar' ? 'قضايا' : 'Cases'}</SelectItem><SelectItem value="lead">{language === 'ar' ? 'عملاء' : 'Leads'}</SelectItem><SelectItem value="billing">{language === 'ar' ? 'مالية' : 'Billing'}</SelectItem><SelectItem value="auth">{language === 'ar' ? 'دخول' : 'Auth'}</SelectItem></SelectContent></Select>
            </div>
            <div className="relative">
                <div className="absolute top-0 bottom-0 inset-s-6 w-px bg-border" />
                <div className="space-y-1">
                    {filtered.map(a => {
                        const Icon = typeIcons[a.type] || Activity; return (
                            <div key={a.id} className="relative flex items-start gap-4 ps-12 py-3 group">
                                <div className={`absolute inset-s-3.5 top-4 size-5 rounded-full bg-background border-2 border-border flex items-center justify-center z-10 ${typeColors[a.type]}`}><Icon className="size-2.5" /></div>
                                <Card className="flex-1 border-none shadow-sm group-hover:bg-muted/30 transition-colors"><CardContent className="p-3"><div className="flex items-start justify-between"><div><h4 className="text-sm font-medium">{a.action}</h4><p className="text-xs text-muted-foreground mt-0.5">{a.detail}</p></div><div className="text-right rtl:text-left shrink-0 ms-4"><p className="text-[10px] text-muted-foreground">{a.time}</p><Badge variant="outline" className="text-[9px] mt-1">{a.user}</Badge></div></div></CardContent></Card>
                            </div>
                        )
                    })}
                </div>
            </div>
        </div>
    )
}
