'use client'

import { useState } from 'react'
import { useUsers } from '@/lib/data-store'
import { useLanguage } from '@/lib/language-context'
import {
    Plus,
    Search,
    UserPlus,
    Mail,
    Shield,
    MoreHorizontal,
    CheckCircle2,
    Clock,
    Filter
} from 'lucide-react'
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from '@/components/ui/card'
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from '@/components/ui/table'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'

export function TeamManagement() {
    const { users, isLoading } = useUsers()
    const { t, language } = useLanguage()
    const [searchQuery, setSearchQuery] = useState('')

    const filteredUsers = users.filter(user =>
        user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.email.toLowerCase().includes(searchQuery.toLowerCase())
    )

    const getRoleBadge = (role: string) => {
        const variants: Record<string, { variant: 'default' | 'secondary' | 'outline' | 'destructive', label: string }> = {
            admin: { variant: 'default', label: language === 'ar' ? 'مسؤول' : 'Admin' },
            lawyer: { variant: 'secondary', label: language === 'ar' ? 'محامي' : 'Lawyer' },
            assistant: { variant: 'outline', label: language === 'ar' ? 'مساعد' : 'Assistant' },
            accountant: { variant: 'outline', label: language === 'ar' ? 'محاسب' : 'Accountant' },
        }
        const config = variants[role] || { variant: 'outline', label: role }
        return <Badge variant={config.variant}>{config.label}</Badge>
    }

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                    <h2 className="text-2xl font-bold tracking-tight text-start">
                        {language === 'ar' ? 'إدارة الفريق' : 'Team Management'}
                    </h2>
                    <p className="text-muted-foreground text-start">
                        {language === 'ar'
                            ? 'إدارة المحامين والموظفين وصلاحياتهم في المكتب.'
                            : 'Manage lawyers, staff and their permissions in the firm.'}
                    </p>
                </div>
                <div className="flex items-center gap-2">
                    <Button className="gap-2">
                        <UserPlus className="size-4" />
                        {language === 'ar' ? 'دعوة عضو جديد' : 'Invite Member'}
                    </Button>
                </div>
            </div>

            <Card>
                <CardHeader className="pb-3">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <CardTitle className="text-lg font-medium text-start">
                            {language === 'ar' ? 'أعضاء المكتب' : 'Firm Members'}
                        </CardTitle>
                        <div className="flex gap-2">
                            <div className="relative w-full md:w-72">
                                <Search className={`absolute ${language === 'ar' ? 'right-3' : 'left-3'} top-2.5 h-4 w-4 text-muted-foreground`} />
                                <Input
                                    placeholder={language === 'ar' ? 'البحث عن عضو...' : 'Search member...'}
                                    className={language === 'ar' ? 'pr-9' : 'pl-9'}
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                />
                            </div>
                            <Button variant="outline" size="icon">
                                <Filter className="h-4 w-4" />
                            </Button>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="rounded-md border">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead className="text-start">{language === 'ar' ? 'العضو' : 'Member'}</TableHead>
                                    <TableHead className="text-start">{language === 'ar' ? 'الدور' : 'Role'}</TableHead>
                                    <TableHead className="text-start">{language === 'ar' ? 'الحالة' : 'Status'}</TableHead>
                                    <TableHead className="text-start">{language === 'ar' ? 'آخر نشاط' : 'Last Active'}</TableHead>
                                    <TableHead className="text-end"></TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {isLoading ? (
                                    <TableRow>
                                        <TableCell colSpan={5} className="h-24 text-center">
                                            {language === 'ar' ? 'جاري التحميل...' : 'Loading...'}
                                        </TableCell>
                                    </TableRow>
                                ) : filteredUsers.length === 0 ? (
                                    <TableRow>
                                        <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                                            {language === 'ar' ? 'لا يوجد أعضاء.' : 'No members found.'}
                                        </TableCell>
                                    </TableRow>
                                ) : (
                                    filteredUsers.map((user) => (
                                        <TableRow key={user.id}>
                                            <TableCell className="text-start">
                                                <div className="flex items-center gap-3">
                                                    <Avatar className="size-8">
                                                        <AvatarImage src={user.avatarUrl} alt={user.name} />
                                                        <AvatarFallback>{user.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                                                    </Avatar>
                                                    <div className="flex flex-col">
                                                        <span className="font-medium">{user.name}</span>
                                                        <span className="text-xs text-muted-foreground">{user.email}</span>
                                                    </div>
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-start">
                                                {getRoleBadge(user.role)}
                                            </TableCell>
                                            <TableCell className="text-start">
                                                <Badge variant="outline" className="gap-1 border-green-500/30 text-green-600 bg-green-500/5">
                                                    <CheckCircle2 className="size-3" />
                                                    {language === 'ar' ? 'نشط' : 'Active'}
                                                </Badge>
                                            </TableCell>
                                            <TableCell className="text-start">
                                                <span className="text-sm text-muted-foreground">
                                                    {new Date(user.lastActive).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US')}
                                                </span>
                                            </TableCell>
                                            <TableCell className="text-end">
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="ghost" size="icon" className="h-8 w-8">
                                                            <MoreHorizontal className="h-4 w-4" />
                                                        </Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align={language === 'ar' ? 'start' : 'end'}>
                                                        <DropdownMenuLabel>{language === 'ar' ? 'الإجراءات' : 'Actions'}</DropdownMenuLabel>
                                                        <DropdownMenuSeparator />
                                                        <DropdownMenuItem className="gap-2">
                                                            {language === 'ar' ? 'تعديل الدور' : 'Edit Role'}
                                                        </DropdownMenuItem>
                                                        <DropdownMenuItem className="gap-2">
                                                            {language === 'ar' ? 'إرسال رسالة' : 'Send Message'}
                                                        </DropdownMenuItem>
                                                        <DropdownMenuSeparator />
                                                        <DropdownMenuItem className="gap-2 text-destructive">
                                                            {language === 'ar' ? 'تعطيل الحساب' : 'Disable Account'}
                                                        </DropdownMenuItem>
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <Card className="bg-primary/5 border-primary/20">
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium flex items-center gap-2">
                            <Shield className="size-4 text-primary" />
                            {language === 'ar' ? 'الأدوار والصلاحيات' : 'Roles & Permissions'}
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-xs text-muted-foreground text-start">
                            {language === 'ar'
                                ? 'يمكنك التحكم في ما يمكن لكل عضو الوصول إليه من خلال تعديل إعدادات الأدوار.'
                                : "Control what each member can access by modifying role settings."}
                        </p>
                        <Button variant="link" className="px-0 h-auto text-xs mt-2" size="sm">
                            {language === 'ar' ? 'عرض مصفوفة الصلاحيات' : 'View Permission Matrix'}
                        </Button>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium flex items-center gap-2">
                            <Clock className="size-4 text-orange-500" />
                            {language === 'ar' ? 'الدعوات المعلقة' : 'Pending Invitations'}
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">0</div>
                        <p className="text-xs text-muted-foreground text-start mt-1">
                            {language === 'ar' ? 'لا يوجد دعوات بانتظار القبول حالياً.' : 'No invitations waiting for acceptance.'}
                        </p>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium flex items-center gap-2">
                            <Mail className="size-4 text-blue-500" />
                            {language === 'ar' ? 'البريد المؤسسي' : 'Organization Email'}
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-xs text-muted-foreground text-start">
                            @lawcrm.com
                        </p>
                        <p className="text-xs text-muted-foreground text-start mt-1">
                            {language === 'ar' ? 'جميع الموظفين يستخدمون نطاق المكتب للعمل.' : 'All staff use the firm domain for work.'}
                        </p>
                    </CardContent>
                </Card>
            </div>
        </div>
    )
}
