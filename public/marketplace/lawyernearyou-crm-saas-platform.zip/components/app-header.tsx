'use client'

import { useState, useEffect } from 'react'
import { Menu, User, LogOut, Calendar as CalendarIcon, Clock, Sun, Moon, Bell, Globe, Shield } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Breadcrumb,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb'
import { useSidebar } from '@/components/ui/sidebar'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel
} from '@/components/ui/dropdown-menu'
import { useLanguage } from '@/lib/language-context'

interface AppHeaderProps {
  breadcrumbs?: { label: string; href?: string }[]
}

export function AppHeader({ breadcrumbs = [] }: AppHeaderProps) {
  const { toggleSidebar, isMobile } = useSidebar()
  const [mounted, setMounted] = useState(false)
  const [time, setTime] = useState<Date | null>(null)
  const { t, language, setLanguage } = useLanguage()

  useEffect(() => {
    setMounted(true)
    setTime(new Date())
    const interval = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(interval)
  }, [])

  const currentHour = time?.getHours() || 0
  const isMorning = currentHour >= 5 && currentHour < 12
  const isAfternoon = currentHour >= 12 && currentHour < 17
  const isEvening = currentHour >= 17 || currentHour < 5

  let greetingMessage = "Good Evening"
  let GreetingIcon = Moon

  if (isMorning) {
    greetingMessage = t('header.goodMorning')
    GreetingIcon = Sun
  } else if (isAfternoon) {
    greetingMessage = t('header.goodAfternoon')
    GreetingIcon = Sun
  } else {
    greetingMessage = t('header.goodEvening')
  }

  return (
    <header className="sticky top-0 z-40 flex h-16 shrink-0 items-center justify-between gap-2 border-b bg-sidebar md:bg-background/95 backdrop-blur supports-backdrop-filter:bg-background/60 text-sidebar-foreground md:text-foreground border-sidebar-border md:border-border px-4 shadow-sm w-full">
      <div className="flex items-center gap-4">
        {isMobile && (
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            onClick={toggleSidebar}
            aria-label={language === 'ar' ? 'تبديل القائمة' : 'Toggle menu'}
          >
            <Menu className="size-5" />
          </Button>
        )}

        <div className="hidden lg:flex items-center gap-2 text-primary bg-primary/10 px-3 py-1.5 rounded-full border border-primary/20">
          {mounted && (
            <>
              <GreetingIcon className="size-4" />
              <span className="font-bold text-sm">
                {language === 'ar' ? `${greetingMessage}، محمد` : `${greetingMessage}, Mohamed`}
              </span>
            </>
          )}
        </div>

        <Breadcrumb className="hidden md:flex ms-2">
          <BreadcrumbList>
            <BreadcrumbLink href="/" className="font-semibold text-sidebar-primary md:text-primary">
              LawCRM
            </BreadcrumbLink>

            {breadcrumbs.map((crumb, index) => (
              <span key={crumb.label} className="contents">
                <BreadcrumbSeparator className="text-sidebar-foreground/50 md:text-muted-foreground rtl:rotate-180" />
                {index === breadcrumbs.length - 1 || !crumb.href ? (
                  <BreadcrumbPage className="text-sidebar-foreground md:text-foreground">{crumb.label}</BreadcrumbPage>
                ) : (
                  <BreadcrumbLink href={crumb.href} className="text-sidebar-foreground/80 md:text-muted-foreground">{crumb.label}</BreadcrumbLink>
                )}
              </span>
            ))}
          </BreadcrumbList>
        </Breadcrumb>
      </div>

      <div className="flex items-center gap-3 md:gap-5 ms-auto">
        {mounted && time && (
          <div className="hidden sm:flex flex-col items-end me-2" dir={language === 'ar' ? 'rtl' : 'ltr'}>
            <div className="flex items-center gap-1.5 text-sm font-semibold">
              <CalendarIcon className="size-4 text-muted-foreground" />
              <span>
                {time.toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-medium">
              <Clock className="size-3.5" />
              <span dir="ltr">
                {time.toLocaleTimeString(language === 'ar' ? 'ar-EG' : 'en-US', { hour: '2-digit', minute: '2-digit', hour12: true })}
              </span>
            </div>
          </div>
        )}

        {/* Interactions */}
        <div className="flex items-center gap-1 md:gap-2 me-2">
          <Button
            variant="ghost"
            size="icon"
            className="relative size-10 rounded-full text-foreground hover:bg-muted"
            onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
            title={t('header.toggleLanguage')}
          >
            <Globe className="size-5 text-muted-foreground" />
            <span className="sr-only">{t('header.toggleLanguage')}</span>
          </Button>
          <Button variant="ghost" size="icon" className="relative size-10 rounded-full text-foreground hover:bg-muted" title={t('header.notifications')}>
            <Bell className="size-5 text-muted-foreground" />
            <span className="absolute top-2 right-2 flex size-2.5 rounded-full bg-destructive border-2 border-background"></span>
          </Button>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative size-10 rounded-full p-0">
              <Avatar className="size-10 border-2 border-primary/20 hover:border-primary/50 transition-colors">
                <AvatarImage src="https://i.pravatar.cc/150?u=a042581f4e29026704d" alt="Avatar" />
                <AvatarFallback className="bg-primary/20 text-primary font-bold">M</AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56" align="end" forceMount>
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium leading-none">Lawyer / Mohamed Ahmed</p>
                <p className="text-xs leading-none text-muted-foreground">mohamed@lawcrm.com</p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="cursor-pointer gap-2">
              <User className="size-4" />
              <span className="font-medium">{t('profile')}</span>
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer gap-2" onClick={() => alert('Switched to Accountant Role (RBAC Simulation)')}>
              <Shield className="size-4" />
              <span className="font-medium">{t('switch.role')}</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="cursor-pointer gap-2 text-destructive focus:bg-destructive focus:text-destructive-foreground">
              <LogOut className="size-4" />
              <span className="font-medium">{t('logout')}</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
