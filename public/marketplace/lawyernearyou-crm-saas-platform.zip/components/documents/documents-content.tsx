'use client'

import React, { useState } from "react"
import { useCases, useUsers } from '@/lib/data-store'
import type { LegalDocument } from '@/lib/types'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from '@/components/ui/table'
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
    Plus,
    MoreHorizontal,
    FileText,
    Search,
    Download,
    Trash2,
    FileCheck,
    Briefcase,
    User,
    ExternalLink,
    Gavel,
} from 'lucide-react'
import Link from 'next/link'

// Mock documents for demonstration
const mockDocuments: LegalDocument[] = [
    {
        id: 'doc-1',
        caseId: 'case-1',
        tenantId: 'tenant-1',
        title: 'توكيل رسمي عام قضايا - أحمد محمد',
        type: 'power_of_attorney',
        status: 'final',
        url: '#',
        uploadedById: 'user-1',
        createdAt: '2024-03-01T10:00:00Z',
    },
    {
        id: 'doc-2',
        caseId: 'case-2',
        tenantId: 'tenant-1',
        title: 'عقد بيع نهائي - شركة النيل',
        type: 'contract',
        status: 'verified',
        url: '#',
        uploadedById: 'user-2',
        createdAt: '2024-03-05T14:30:00Z',
    },
    {
        id: 'doc-3',
        caseId: 'case-3',
        tenantId: 'tenant-1',
        title: 'مذكرة دفاع - قضية التعويضات',
        type: 'pleading',
        status: 'court_submitted',
        url: '#',
        uploadedById: 'user-1',
        createdAt: '2024-03-12T09:00:00Z',
    },
]

import { useLanguage } from '@/lib/language-context'

export function DocumentsContent() {
    const { t, language } = useLanguage()
    const { cases } = useCases()
    const { users } = useUsers()
    const [searchQuery, setSearchQuery] = useState('')

    const getCaseName = (caseId: string) => cases.find(c => c.id === caseId)?.name || (language === 'ar' ? 'عام' : 'General')
    const getUploaderName = (userId: string) => users.find(u => u.id === userId)?.name || (language === 'ar' ? 'مسؤول' : 'Admin')

    const filteredDocs = mockDocuments.filter(doc =>
        doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        getCaseName(doc.caseId).toLowerCase().includes(searchQuery.toLowerCase())
    )

    const getStatusBadge = (status: LegalDocument['status']) => {
        const variants: Record<string, { variant: 'default' | 'secondary' | 'outline' | 'success'; label: string }> = {
            draft: { variant: 'secondary', label: t('status.scheduled') }, // Reusing scheduled for draft or adding docs.draft
            final: { variant: 'default', label: t('docs.final') },
            verified: { variant: 'outline', label: t('docs.verified') },
            court_submitted: { variant: 'outline', label: t('docs.court') },
        }
        const config = variants[status] || variants.draft
        return <Badge variant={config.variant as any}>{config.label}</Badge>
    }

    const getTypeIcon = (type: LegalDocument['type']) => {
        switch (type) {
            case 'power_of_attorney': return <FileCheck className="size-4 text-orange-500" />
            case 'contract': return <FileText className="size-4 text-blue-500" />
            case 'pleading': return <Gavel className="size-4 text-purple-500" />
            default: return <FileText className="size-4" />
        }
    }

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                    <h2 className="text-2xl font-bold tracking-tight">{t('docs.title')}</h2>
                    <p className="text-muted-foreground">
                        {t('docs.desc')}
                    </p>
                </div>
                <div className="flex items-center gap-2">
                    <Button className="gap-2">
                        <Plus className="size-4" />
                        {t('docs.upload')}
                    </Button>
                </div>
            </div>

            <Card>
                <CardHeader className="pb-3">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <CardTitle className="text-lg font-medium">{t('docs.all')}</CardTitle>
                        <div className="relative w-full md:w-72">
                            <Search className={`absolute ${language === 'ar' ? 'right-3' : 'left-3'} top-2.5 h-4 w-4 text-muted-foreground`} />
                            <Input
                                placeholder={t('docs.search')}
                                className={language === 'ar' ? 'pr-9' : 'pl-9'}
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                            />
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="rounded-md border overflow-hidden">
                        <Table>
                            <TableHeader>
                                <TableRow className="bg-muted/50">
                                    <TableHead className="w-[300px]">{t('docs.header.name')}</TableHead>
                                    <TableHead>{t('docs.header.case')}</TableHead>
                                    <TableHead>{t('docs.header.status')}</TableHead>
                                    <TableHead>{t('docs.header.uploadedBy')}</TableHead>
                                    <TableHead className="text-right">{t('docs.header.date')}</TableHead>
                                    <TableHead className="w-[80px]"></TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {filteredDocs.length > 0 ? (
                                    filteredDocs.map((doc) => (
                                        <TableRow key={doc.id}>
                                            <TableCell className="font-medium">
                                                <div className="flex items-center gap-2">
                                                    <FileText className="h-4 w-4 text-primary" />
                                                    <span>{doc.title}</span>
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-1.5 font-medium">
                                                    <Briefcase className="h-4 w-4 text-muted-foreground" />
                                                    {getCaseName(doc.caseId)}
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                {getStatusBadge(doc.status)}
                                            </TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-1.5">
                                                    <User className="h-4 w-4 text-muted-foreground" />
                                                    {getUploaderName(doc.uploadedById)}
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-right text-sm text-muted-foreground">
                                                {new Date(doc.createdAt).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', {
                                                    year: 'numeric',
                                                    month: 'short',
                                                    day: 'numeric'
                                                })}
                                            </TableCell>
                                            <TableCell>
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="ghost" size="icon" className="h-8 w-8">
                                                            <MoreHorizontal className="h-4 w-4" />
                                                        </Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align="end">
                                                        <DropdownMenuItem className="gap-2">
                                                            <ExternalLink className="h-4 w-4" />
                                                            {language === 'ar' ? 'فتح' : 'Open'}
                                                        </DropdownMenuItem>
                                                        <DropdownMenuItem className="gap-2">
                                                            <Download className="h-4 w-4" />
                                                            {language === 'ar' ? 'تحميل' : 'Download'}
                                                        </DropdownMenuItem>
                                                        <DropdownMenuSeparator />
                                                        <DropdownMenuItem className="gap-2 text-destructive">
                                                            <Trash2 className="h-4 w-4" />
                                                            {language === 'ar' ? 'حذف' : 'Delete'}
                                                        </DropdownMenuItem>
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                ) : (
                                    <TableRow>
                                        <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                                            {language === 'ar' ? 'لا توجد مستندات مطابقة للبحث.' : 'No documents found matching yours search.'}
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>
        </div>
    )
}
