'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  LayoutDashboard,
  Briefcase,
  Users,
  Gavel,
  Scale,
  MessageSquare,
  Settings,
  CreditCard,
  FolderOpen,
  HelpCircle,
  BarChart3,
  ShieldCheck,
  Calendar,
  Trello,
  UserPlus,
  BookOpen,
  Puzzle,
  History,
  Bell,
  FileText,
  FileSignature,
  Timer,
  BarChart,
  Shield,
  Building2,
  Receipt,
  Wallet,
  Activity,
  Megaphone,
  MessageCircle,
  Inbox,
  Video,
} from 'lucide-react'
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from '@/components/ui/sidebar'

import { useLanguage } from '@/lib/language-context'
import { TenantSwitcher } from '@/components/tenant-switcher'

const coreItems = [
  { title: 'Dashboard', i18nKey: 'nav.dashboard', href: '/', icon: LayoutDashboard },
  { title: 'Calendar', i18nKey: 'nav.calendar', href: '/tasks/calendar', icon: Calendar },
  { title: 'Kanban Board', i18nKey: 'nav.kanban', href: '/tasks/kanban', icon: Trello },
  { title: 'Notifications', i18nKey: 'nav.notifications', href: '/notifications', icon: Bell },
]

const growthItems = [
  { title: 'Leads', i18nKey: 'nav.leads', href: '/leads', icon: UserPlus },
  { title: 'Contracts', i18nKey: 'nav.contracts', href: '/contracts', icon: FileText },
  { title: 'Proposals', i18nKey: 'nav.proposals', href: '/proposals', icon: FileSignature },
]

const legalItems = [
  { title: 'Cases', i18nKey: 'nav.cases', href: '/cases', icon: Briefcase },
  { title: 'Clients', i18nKey: 'nav.clients', href: '/clients', icon: Users },
  { title: 'Consultations', i18nKey: 'nav.consultations', href: '/consultations', icon: Gavel },
  { title: 'Case History', i18nKey: 'nav.caseHistory', href: '/case-history', icon: Scale },
  { title: 'Court Sessions', i18nKey: 'nav.courtSessions', href: '/court-sessions', icon: Gavel },
  { title: 'Legal Timers', i18nKey: 'nav.timers', href: '/timers', icon: Timer },
]

const managementItems = [
  { title: 'Team', i18nKey: 'nav.team', href: '/team', icon: Users },
  { title: 'Analytics', i18nKey: 'nav.analytics', href: '/analytics', icon: BarChart3 },
  { title: 'Reports', i18nKey: 'nav.reports', href: '/reports', icon: BarChart },
  { title: 'Roles & Permissions', i18nKey: 'nav.roles', href: '/roles', icon: Shield },
  { title: 'Branches', i18nKey: 'nav.branches', href: '/branches', icon: Building2 },
]

const resourceItems = [
  { title: 'Knowledge Base', i18nKey: 'nav.knowledge', href: '/resources/knowledge', icon: BookOpen },
  { title: 'Documents', i18nKey: 'nav.documents', href: '/documents', icon: FolderOpen },
]

const financeItems = [
  { title: 'Billing', i18nKey: 'nav.billing', href: '/billing', icon: CreditCard },
  { title: 'Subscriptions', i18nKey: 'nav.subscriptions', href: '/billing/subscription', icon: ShieldCheck },
  { title: 'Invoices', i18nKey: 'nav.invoices', href: '/invoices', icon: Receipt },
  { title: 'Expenses', i18nKey: 'nav.expenses', href: '/expenses', icon: Wallet },
]

const systemItems = [
  { title: 'Integrations', i18nKey: 'nav.integrations', href: '/system/integrations', icon: Puzzle },
  { title: 'Audit Logs', i18nKey: 'nav.auditLogs', href: '/system/audit-logs', icon: History },
  { title: 'Activity Feed', i18nKey: 'nav.activity', href: '/system/activity', icon: Activity },
  { title: 'Announcements', i18nKey: 'nav.announcements', href: '/system/announcements', icon: Megaphone },
]

const commItems = [
  { title: 'AI Assistant', i18nKey: 'nav.assistant', href: '/assistant', icon: MessageSquare },
  { title: 'Zoom Meetings', i18nKey: 'nav.zoom', href: '/system/integrations/zoom', icon: Video, color: '#2D8CFF' },
  { title: 'Google Meet', i18nKey: 'nav.google-meet', href: '/system/integrations/google-meet', icon: Video, color: '#00832D' },
  { title: 'Omnichannel Inbox', i18nKey: 'nav.omnichannel', href: '/omnichannel', icon: Inbox },
  { title: 'Inter Chat', i18nKey: 'nav.messages', href: '/messages', icon: MessageCircle },
]

const bottomNavItems = [
  { title: 'Settings', i18nKey: 'nav.settings', href: '/settings', icon: Settings },
  { title: 'Help Center', i18nKey: 'nav.help', href: '/help', icon: HelpCircle },
]

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const pathname = usePathname()
  const { setOpenMobile } = useSidebar()
  const { t, language } = useLanguage()

  const handleNavClick = () => {
    setOpenMobile(false)
  }

  const renderNavGroup = (items: any[], labelKey?: string) => (
    <SidebarGroup>
      {labelKey && <SidebarGroupLabel className="px-2 py-2 text-xs font-bold text-sidebar-foreground/50 uppercase tracking-wider">{t(labelKey)}</SidebarGroupLabel>}
      <SidebarGroupContent>
        <SidebarMenu>
          {items.map((item) => {
            const isActive = pathname === item.href ||
              (item.href !== '/' && pathname.startsWith(item.href))
            return (
              <SidebarMenuItem key={item.title}>
                <SidebarMenuButton asChild isActive={isActive}>
                  <Link href={item.href} onClick={handleNavClick} scroll={!isActive}>
                    <item.icon className="size-4" style={item.color ? { color: item.color } : {}} />
                    <span>{t(item.i18nKey)}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            )
          })}
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  )

  return (
    <Sidebar
      side={language === 'ar' ? 'right' : 'left'}
      variant="inset"
      dir={language === 'ar' ? 'rtl' : 'ltr'}
      {...props}
    >
      <SidebarHeader className="border-b border-sidebar-border px-4 py-4 space-y-4">
        <Link
          href="/"
          className="flex items-center gap-3"
          onClick={handleNavClick}
        >
          <div className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Scale className="size-5" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-semibold">LawCRM</span>
            <span className="text-xs text-sidebar-foreground/70">{language === 'ar' ? 'إدارة مكاتب المحاماة' : 'Legal Management'}</span>
          </div>
        </Link>
        <TenantSwitcher />
      </SidebarHeader>

      <SidebarContent dir={language === 'ar' ? 'rtl' : 'ltr'} className="gap-2">
        {renderNavGroup(coreItems, 'section.core')}
        {renderNavGroup(commItems, 'section.communications')}
        {renderNavGroup(growthItems, 'section.growth')}
        {renderNavGroup(legalItems, 'section.legal')}
        {renderNavGroup(managementItems, 'section.management')}
        {renderNavGroup(resourceItems, 'section.resources')}
        {renderNavGroup(financeItems, 'section.finances')}
        {renderNavGroup(systemItems, 'section.system')}
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {bottomNavItems.map((item) => {
                const isActive = pathname === item.href ||
                  (item.href !== '/' && pathname.startsWith(item.href))
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild isActive={isActive}>
                      <Link href={item.href} onClick={handleNavClick} scroll={!isActive}>
                        <item.icon className="size-4" />
                        <span>{t(item.i18nKey)}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarFooter>
    </Sidebar>
  )
}
