'use client'

import React, { useState } from 'react'
import { MessageCircle, Send, Search, Plus, Paperclip, Phone, Video, MoreVertical, Smartphone, Facebook, Instagram, Filter, Link2 } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useLanguage } from '@/lib/language-context'
import { toast } from 'sonner'
import Link from 'next/link'

type ContactChannel = 'whatsapp' | 'messenger' | 'instagram'
type FilterChannel = ContactChannel | 'all'

interface Contact { id: number; name: string; lastMessage: string; time: string; unread: number; channel: ContactChannel; phone?: string; handle?: string }
interface Message { id: number; text: string; sender: 'me' | 'them'; time: string; channel: ContactChannel }

const contacts: Contact[] = [
    { id: 1, name: 'Tarek Mahmoud', lastMessage: 'هل يمكنني إرسال المستندات هنا؟', time: '10 min', unread: 2, channel: 'whatsapp', phone: '+20 100 123 4567' },
    { id: 2, name: 'Nour Youssef', lastMessage: 'Thanks for the phone consultation.', time: '1 hr', unread: 0, channel: 'messenger', handle: '@nour.youssef' },
    { id: 3, name: 'Hassan Ali', lastMessage: 'متى الجلسة القادمة؟', time: '3 hr', unread: 1, channel: 'whatsapp', phone: '+20 111 987 6543' },
    { id: 4, name: 'Rania Magdi', lastMessage: 'Great layout for the new contract.', time: 'Yesterday', unread: 0, channel: 'instagram', handle: '@rania_m' },
]

const defaultMsgs: Record<number, Message[]> = {
    1: [
        { id: 1, text: 'مرحباً أستاذ طارق، بخصوص قضية الإيجار.', sender: 'me', time: '9:00 AM', channel: 'whatsapp' },
        { id: 2, text: 'أهلاً بك. نعم، هل يمكنني إرسال المستندات هنا؟', sender: 'them', time: '9:05 AM', channel: 'whatsapp' },
    ],
    2: [
        { id: 1, text: 'Your contract draft is ready for review.', sender: 'me', time: '10:00 AM', channel: 'messenger' },
        { id: 2, text: 'Thanks for the phone consultation.', sender: 'them', time: '11:00 AM', channel: 'messenger' }
    ],
    3: [{ id: 1, text: 'متى الجلسة القادمة؟', sender: 'them', time: '11:00 AM', channel: 'whatsapp' }],
    4: [{ id: 1, text: 'Great layout for the new contract.', sender: 'them', time: 'Yesterday', channel: 'instagram' }],
}

const WhatsappIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.77-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86s.274.066.376-.043c.101-.108.433-.506.549-.68.116-.173.231-.145.39-.087s1.011.477 1.184.564.289.13.332.202c.045.072.045.419-.1.824zm-3.423-14.416c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm.029 18.88c-1.161 0-2.305-.292-3.318-.844l-3.677.964.984-3.595c-.607-1.052-.927-2.246-.926-3.468.001-3.825 3.113-6.937 6.937-6.937 1.856.001 3.598.723 4.907 2.034 1.31 1.311 2.031 3.054 2.03 4.908-.001 3.825-3.113 6.938-6.937 6.938z" />
    </svg>
)

const MessengerIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M12 2C6.477 2 2 6.145 2 11.25c0 2.898 1.488 5.485 3.812 7.152v3.136c0 .408.468.64.8.4l3.58-2.583a10.884 10.884 0 001.808.145c5.523 0 10-4.145 10-9.25S17.523 2 12 2zm1.094 12.378l-2.617-2.793-5.115 2.793 5.629-5.976 2.645 2.792 5.088-2.792-5.63 5.976z" />
    </svg>
)

const InstagramIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
    </svg>
)

const channelIcons = {
    whatsapp: <WhatsappIcon className="size-4" />,
    messenger: <MessengerIcon className="size-4" />,
    instagram: <InstagramIcon className="size-4" />,
    all: <MessageCircle className="size-4" />
}

const channelColors = {
    whatsapp: 'bg-green-500/10 text-green-600 border-green-200',
    messenger: 'bg-blue-500/10 text-blue-600 border-blue-200',
    instagram: 'bg-pink-500/10 text-pink-600 border-pink-200',
}

const channelBgColors = {
    whatsapp: 'bg-green-50',
    messenger: 'bg-blue-50',
    instagram: 'bg-pink-50',
}

export function OmnichannelContent() {
    const { language } = useLanguage()
    const [selectedId, setSelectedId] = useState(1)
    const [messages, setMessages] = useState<Record<number, Message[]>>(defaultMsgs)
    const [newMsg, setNewMsg] = useState('')
    const [searchTerm, setSearchTerm] = useState('')
    const [filter, setFilter] = useState<FilterChannel>('all')

    const sendMessage = () => {
        if (!newMsg.trim() || !selected) return
        const msg: Message = { id: Date.now(), text: newMsg, sender: 'me', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), channel: selected.channel }
        setMessages(p => ({ ...p, [selectedId]: [...(p[selectedId] || []), msg] }))
        setNewMsg('')
    }

    const selected = contacts.find(c => c.id === selectedId)
    const filteredContacts = contacts.filter(c =>
        c.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
        (filter === 'all' || c.channel === filter)
    )

    return (
        <div className="flex flex-col h-[calc(100vh-8rem)] animate-in fade-in duration-500">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between mb-4 shrink-0">
                <div><h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'صندوق الوارد الموحد' : 'Omnichannel Inbox'}</h1><p className="text-muted-foreground">{language === 'ar' ? 'تواصل مع عملائك عبر واتساب، ماسنجر، وإنستجرام من مكان واحد.' : 'Communicate with clients across WhatsApp, Messenger, and Instagram.'}</p></div>
                <div className="flex gap-2">
                    <Button variant="outline" className="gap-2" asChild><Link href="/system/integrations"><Link2 className="size-4" />{language === 'ar' ? 'ربط القنوات' : 'Connect Channels'}</Link></Button>
                </div>
            </div>
            <Card className="border-none shadow-sm overflow-hidden flex-1 flex flex-col p-0 gap-0 min-h-0">
                <div className="grid grid-cols-1 md:grid-cols-3 flex-1 min-h-0">
                    {/* Contacts */}
                    <div className="border-r border-border md:col-span-1 flex flex-col overflow-hidden bg-muted/5">
                        <div className="p-3 border-b space-y-3">
                            <div className="relative"><Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground rtl:left-auto rtl:right-2.5" /><Input className="pl-8 rtl:pl-3 rtl:pr-8 h-9" placeholder={language === 'ar' ? 'بحث في العملاء...' : 'Search clients...'} value={searchTerm} onChange={e => setSearchTerm(e.target.value)} /></div>
                            <Select value={filter} onValueChange={(v: FilterChannel) => setFilter(v)}><SelectTrigger className="w-full h-8 text-xs"><SelectValue placeholder="Filter channels" /></SelectTrigger><SelectContent><SelectItem value="all">{language === 'ar' ? 'كل القنوات' : 'All Channels'}</SelectItem><SelectItem value="whatsapp">WhatsApp</SelectItem><SelectItem value="messenger">Messenger</SelectItem><SelectItem value="instagram">Instagram</SelectItem></SelectContent></Select>
                        </div>
                        <div className="flex-1 overflow-y-auto">
                            {filteredContacts.map(c => (
                                <div key={c.id} className={`flex items-center gap-3 p-3 cursor-pointer transition-colors hover:bg-muted/30 ${selectedId === c.id ? 'bg-background border-s-2 border-primary shadow-sm' : ''}`} onClick={() => setSelectedId(c.id)}>
                                    <div className="relative">
                                        <Avatar className="size-10"><AvatarFallback className="bg-primary/10 text-primary text-sm">{c.name.split(' ').map(n => n[0]).join('')}</AvatarFallback></Avatar>
                                        <div className={`absolute -bottom-1 -right-1 size-5 rounded-full flex items-center justify-center border-2 border-background ${channelColors[c.channel].split(' ')[0]} ${channelColors[c.channel].split(' ')[1]}`}>
                                            {c.channel === 'whatsapp' && <WhatsappIcon className="size-3" />}
                                            {c.channel === 'messenger' && <MessengerIcon className="size-3" />}
                                            {c.channel === 'instagram' && <InstagramIcon className="size-3" />}
                                        </div>
                                    </div>
                                    <div className="flex-1 min-w-0"><div className="flex items-center justify-between"><h4 className="text-sm font-medium truncate">{c.name}</h4><span className="text-[10px] text-muted-foreground">{c.time}</span></div><p className="text-xs text-muted-foreground truncate">{c.lastMessage}</p></div>
                                    {c.unread > 0 && <Badge className="size-5 rounded-full p-0 flex items-center justify-center text-[10px]">{c.unread}</Badge>}
                                </div>
                            ))}
                            {filteredContacts.length === 0 && <div className="p-8 text-center text-muted-foreground text-sm">{language === 'ar' ? 'لا توجد محادثات' : 'No conversations found'}</div>}
                        </div>
                    </div>
                    {/* Chat */}
                    <div className="md:col-span-2 flex flex-col relative overflow-hidden bg-background">
                        {selected ? (
                            <>
                                <div className="flex items-center justify-between p-3 border-b bg-background/95 backdrop-blur z-10">
                                    <div className="flex items-center gap-3">
                                        <Avatar className="size-10"><AvatarFallback className="bg-primary/10 text-primary">{selected.name.split(' ').map(n => n[0]).join('')}</AvatarFallback></Avatar>
                                        <div>
                                            <h4 className="text-sm font-bold flex items-center gap-2">
                                                {selected.name}
                                                <Badge variant="outline" className={`text-[9px] h-4 px-1 ${channelColors[selected.channel]}`}>{selected.channel}</Badge>
                                            </h4>
                                            <p className="text-xs text-muted-foreground">{selected.phone || selected.handle || 'Client'}</p>
                                        </div>
                                    </div>
                                    <div className="flex gap-1"><Button variant="ghost" size="icon" className="size-8" onClick={() => toast.success(language === 'ar' ? 'جاري بدء المكالمة الصوتية...' : 'Starting voice call...')}><Phone className="size-4" /></Button><Button variant="ghost" size="icon" className="size-8" onClick={() => toast.success(language === 'ar' ? 'جاري بدء مكالمة الفيديو...' : 'Starting video call...')}><Video className="size-4" /></Button><Button variant="ghost" size="icon" className="size-8" onClick={() => toast.info(language === 'ar' ? 'خيارات إضافية' : 'More options')}><MoreVertical className="size-4" /></Button></div>
                                </div>

                                <div className={`flex-1 overflow-y-auto p-4 space-y-4 ${channelBgColors[selected.channel]} bg-opacity-30 dark:bg-opacity-5`}>
                                    {(messages[selectedId] || []).map(m => (
                                        <div key={m.id} className={`flex ${m.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
                                            <div className={`max-w-[75%] rounded-2xl px-4 py-2 shadow-sm ${m.sender === 'me' ? 'bg-primary text-primary-foreground rounded-br-sm' : 'bg-background border rounded-bl-sm'}`}>
                                                <p className="text-sm">{m.text}</p>
                                                <div className={`flex items-center justify-end gap-1 mt-1 ${m.sender === 'me' ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>
                                                    <span className="text-[9px]">{m.channel}</span> • <span className="text-[9px]">{m.time}</span>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                <div className="p-3 border-t bg-background">
                                    <div className="flex gap-2 items-end">
                                        <Button variant="ghost" size="icon" className="size-9 shrink-0" onClick={() => toast.info(language === 'ar' ? 'إجراءات إضافية' : 'Additional actions')}><Plus className="size-4" /></Button>
                                        <Button variant="ghost" size="icon" className="size-9 shrink-0" onClick={() => {
                                            const input = document.createElement('input');
                                            input.type = 'file';
                                            input.click();
                                            input.onchange = () => toast.success(language === 'ar' ? 'تم اختيار المرفق' : 'Attachment selected');
                                        }}><Paperclip className="size-4" /></Button>
                                        <div className="flex-1 relative">
                                            <Input className="h-10 pr-10 rtl:pr-3 rtl:pl-10" placeholder={language === 'ar' ? `رد عبر ${selected.channel}...` : `Reply via ${selected.channel}...`} value={newMsg} onChange={e => setNewMsg(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendMessage()} />
                                        </div>
                                        <Button size="icon" className={`size-10 shrink-0 ${newMsg.trim() ? 'bg-primary' : 'bg-muted text-muted-foreground'}`} onClick={sendMessage} disabled={!newMsg.trim()}><Send className="size-4" /></Button>
                                    </div>
                                    <div className="mt-2 text-center"><span className="text-[10px] text-muted-foreground">{language === 'ar' ? 'يتم إرسال الرسالة إلى تطبيق العميل مباشرة' : 'Message will be sent directly to the client\'s app'}</span></div>
                                </div>
                            </>
                        ) : (
                            <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
                                <MessageCircle className="size-10 mb-4 opacity-20" />
                                <p>{language === 'ar' ? 'اختر محادثة للبدء' : 'Select a conversation to start'}</p>
                            </div>
                        )}
                    </div>
                </div>
            </Card>
        </div>
    )
}
