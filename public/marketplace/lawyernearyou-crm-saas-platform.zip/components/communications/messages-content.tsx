'use client'

import React, { useState } from 'react'
import { MessageCircle, Send, Search, Plus, Paperclip, Phone, Video, MoreVertical } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { useLanguage } from '@/lib/language-context'
import { toast } from 'sonner'

interface Contact { id: number; name: string; lastMessage: string; time: string; unread: number; online: boolean }
interface Message { id: number; text: string; sender: 'me' | 'them'; time: string }

const contacts: Contact[] = [
    { id: 1, name: 'Ahmed Mansour', lastMessage: 'Please review the attached documents.', time: '2 min', unread: 2, online: true },
    { id: 2, name: 'Sara Kamel', lastMessage: 'The hearing has been postponed to next week.', time: '1 hr', unread: 0, online: true },
    { id: 3, name: 'Mohamed Admin', lastMessage: 'Updated the invoice for TechCorp.', time: '3 hr', unread: 1, online: false },
    { id: 4, name: 'Laila Hassan', lastMessage: 'Can we schedule a meeting tomorrow?', time: 'Yesterday', unread: 0, online: false },
]

const defaultMsgs: Record<number, Message[]> = {
    1: [
        { id: 1, text: 'Good morning, I need an update on the Mansour case.', sender: 'them', time: '9:00 AM' },
        { id: 2, text: 'Good morning! The documents are being prepared and should be ready by noon.', sender: 'me', time: '9:05 AM' },
        { id: 3, text: 'Please review the attached documents.', sender: 'them', time: '9:10 AM' },
    ],
    2: [{ id: 1, text: 'The hearing has been postponed to next week.', sender: 'them', time: '10:00 AM' }],
    3: [{ id: 1, text: 'Updated the invoice for TechCorp.', sender: 'them', time: '11:00 AM' }],
    4: [{ id: 1, text: 'Can we schedule a meeting tomorrow?', sender: 'them', time: 'Yesterday' }],
}

export function MessagesContent() {
    const { language } = useLanguage()
    const [selectedId, setSelectedId] = useState(1)
    const [messages, setMessages] = useState<Record<number, Message[]>>(defaultMsgs)
    const [newMsg, setNewMsg] = useState('')
    const [searchTerm, setSearchTerm] = useState('')

    const sendMessage = () => {
        if (!newMsg.trim()) return
        const msg: Message = { id: Date.now(), text: newMsg, sender: 'me', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }
        setMessages(p => ({ ...p, [selectedId]: [...(p[selectedId] || []), msg] }))
        setNewMsg('')
    }

    const selected = contacts.find(c => c.id === selectedId)
    const filteredContacts = contacts.filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()))

    return (
        <div className="flex flex-col h-[calc(100vh-8rem)] animate-in fade-in duration-500">
            <div className="mb-4 shrink-0"><h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'التواصل الداخلي' : 'Inter Chat'}</h1><p className="text-muted-foreground">{language === 'ar' ? 'تواصل بشكل داخلي وآمن مع أعضاء النركز.' : 'Communicate internally and securely with your team members.'}</p></div>
            <Card className="border-none shadow-sm overflow-hidden flex-1 flex flex-col p-0 gap-0 min-h-0">
                <div className="grid grid-cols-1 md:grid-cols-3 flex-1 min-h-0">
                    {/* Contacts */}
                    <div className="border-r border-border md:col-span-1 flex flex-col overflow-hidden">
                        <div className="p-3 border-b"><div className="relative"><Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground rtl:left-auto rtl:right-2.5" /><Input className="pl-8 rtl:pl-3 rtl:pr-8 h-9" placeholder={language === 'ar' ? 'بحث...' : 'Search...'} value={searchTerm} onChange={e => setSearchTerm(e.target.value)} /></div></div>
                        <div className="flex-1 overflow-y-auto">
                            {filteredContacts.map(c => (
                                <div key={c.id} className={`flex items-center gap-3 p-3 cursor-pointer transition-colors hover:bg-muted/30 ${selectedId === c.id ? 'bg-primary/5 border-s-2 border-primary' : ''}`} onClick={() => setSelectedId(c.id)}>
                                    <div className="relative"><Avatar className="size-10"><AvatarFallback className="bg-primary/10 text-primary text-sm">{c.name.split(' ').map(n => n[0]).join('')}</AvatarFallback></Avatar>{c.online && <div className="absolute bottom-0 right-0 size-3 rounded-full bg-green-500 border-2 border-background" />}</div>
                                    <div className="flex-1 min-w-0"><div className="flex items-center justify-between"><h4 className="text-sm font-medium truncate">{c.name}</h4><span className="text-[10px] text-muted-foreground">{c.time}</span></div><p className="text-xs text-muted-foreground truncate">{c.lastMessage}</p></div>
                                    {c.unread > 0 && <Badge className="size-5 rounded-full p-0 flex items-center justify-center text-[10px]">{c.unread}</Badge>}
                                </div>
                            ))}
                        </div>
                    </div>
                    {/* Chat */}
                    <div className="md:col-span-2 flex flex-col overflow-hidden">
                        {selected && (
                            <>
                                <div className="flex items-center justify-between p-3 border-b">
                                    <div className="flex items-center gap-3"><Avatar className="size-9"><AvatarFallback className="bg-primary/10 text-primary text-xs">{selected.name.split(' ').map(n => n[0]).join('')}</AvatarFallback></Avatar><div><h4 className="text-sm font-medium">{selected.name}</h4><p className="text-[10px] text-green-500">{selected.online ? (language === 'ar' ? 'متصل' : 'Online') : (language === 'ar' ? 'غير متصل' : 'Offline')}</p></div></div>
                                    <div className="flex gap-1"><Button variant="ghost" size="icon" className="size-8" onClick={() => toast.success(language === 'ar' ? 'جاري بدء المكالمة الصوتية...' : 'Starting voice call...')}><Phone className="size-4" /></Button><Button variant="ghost" size="icon" className="size-8" onClick={() => toast.success(language === 'ar' ? 'جاري بدء مكالمة الفيديو...' : 'Starting video call...')}><Video className="size-4" /></Button></div>
                                </div>
                                <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-muted/10">
                                    {(messages[selectedId] || []).map(m => (
                                        <div key={m.id} className={`flex ${m.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
                                            <div className={`max-w-[70%] rounded-2xl px-4 py-2 ${m.sender === 'me' ? 'bg-primary text-primary-foreground rounded-br-sm' : 'bg-muted rounded-bl-sm'}`}>
                                                <p className="text-sm">{m.text}</p><p className={`text-[10px] mt-1 ${m.sender === 'me' ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>{m.time}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                <div className="p-3 border-t">
                                    <div className="flex gap-2"><Button variant="ghost" size="icon" className="size-9 shrink-0" onClick={() => {
                                        const input = document.createElement('input');
                                        input.type = 'file';
                                        input.click();
                                        input.onchange = () => toast.success(language === 'ar' ? 'تم اختيار المرفق' : 'Attachment selected');
                                    }}><Paperclip className="size-4" /></Button><Input className="h-9" placeholder={language === 'ar' ? 'اكتب رسالة...' : 'Type a message...'} value={newMsg} onChange={e => setNewMsg(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendMessage()} /><Button size="icon" className="size-9 shrink-0" onClick={sendMessage} disabled={!newMsg.trim()}><Send className="size-4" /></Button></div>
                                </div>
                            </>
                        )}
                    </div>
                </div>
            </Card>
        </div>
    )
}
