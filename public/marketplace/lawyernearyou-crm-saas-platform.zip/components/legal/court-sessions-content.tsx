'use client'

import React, { useState } from 'react'
import { Scale, Plus, Search, MapPin, Clock, User, Calendar } from 'lucide-react'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useLanguage } from '@/lib/language-context'

interface Session { id: number; caseTitle: string; court: string; judge: string; date: string; time: string; status: 'Upcoming' | 'Completed' | 'Postponed' }

const initial: Session[] = [
    { id: 1, caseTitle: 'Mansour vs. Ministry of Housing', court: 'Cairo Administrative Court', judge: 'Justice Ibrahim', date: '2024-03-15', time: '10:00 AM', status: 'Upcoming' },
    { id: 2, caseTitle: 'Al-Nile Corp Tax Appeal', court: 'Tax Appeals Tribunal', judge: 'Justice Hassan', date: '2024-03-20', time: '11:30 AM', status: 'Upcoming' },
    { id: 3, caseTitle: 'Kamel Family Inheritance', court: 'Giza Family Court', judge: 'Justice Fatma', date: '2024-03-05', time: '09:00 AM', status: 'Completed' },
    { id: 4, caseTitle: 'Zaki Commercial Dispute', court: 'Cairo Economic Court', judge: 'Justice Omar', date: '2024-03-12', time: '02:00 PM', status: 'Postponed' },
]

const statusCfg: Record<string, { color: string; ar: string }> = {
    Upcoming: { color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400', ar: 'قادمة' },
    Completed: { color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400', ar: 'منتهية' },
    Postponed: { color: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400', ar: 'مؤجلة' },
}

export function CourtSessionsContent() {
    const { language } = useLanguage()
    const [sessions, setSessions] = useState<Session[]>(initial)
    const [search, setSearch] = useState('')
    const [filter, setFilter] = useState('all')
    const [open, setOpen] = useState(false)
    const [form, setForm] = useState({ caseTitle: '', court: '', judge: '', date: '', time: '10:00' })
    const [feedback, setFeedback] = useState<string | null>(null)
    const show = (m: string) => { setFeedback(m); setTimeout(() => setFeedback(null), 2500) }

    const add = () => {
        if (!form.caseTitle || !form.court) return
        setSessions(p => [{ id: Date.now(), ...form, time: form.time || '10:00 AM', status: 'Upcoming' }, ...p])
        setForm({ caseTitle: '', court: '', judge: '', date: '', time: '10:00' }); setOpen(false)
        show(language === 'ar' ? '✅ تمت إضافة الجلسة' : '✅ Session added')
    }

    const changeStatus = (id: number, s: Session['status']) => { setSessions(p => p.map(x => x.id === id ? { ...x, status: s } : x)); show(language === 'ar' ? '✅ تم التحديث' : '✅ Updated') }

    const filtered = sessions.filter(s => {
        const m1 = s.caseTitle.toLowerCase().includes(search.toLowerCase()) || s.court.toLowerCase().includes(search.toLowerCase())
        const m2 = filter === 'all' || s.status === filter
        return m1 && m2
    })

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300"><div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div></div>}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div><h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'جلسات المحكمة' : 'Court Sessions'}</h1><p className="text-muted-foreground">{language === 'ar' ? 'تتبع جميع الجلسات القادمة والسابقة.' : 'Track all upcoming and past court hearings.'}</p></div>
                <Dialog open={open} onOpenChange={setOpen}>
                    <DialogTrigger asChild><Button className="gap-2"><Plus className="size-4" />{language === 'ar' ? 'جلسة جديدة' : 'Add Session'}</Button></DialogTrigger>
                    <DialogContent>
                        <DialogHeader><DialogTitle>{language === 'ar' ? 'إضافة جلسة' : 'New Court Session'}</DialogTitle><DialogDescription>{language === 'ar' ? 'أضف تفاصيل الجلسة القادمة.' : 'Enter session details.'}</DialogDescription></DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'القضية *' : 'Case *'}</Label><Input value={form.caseTitle} onChange={e => setForm(p => ({ ...p, caseTitle: e.target.value }))} /></div>
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'المحكمة *' : 'Court *'}</Label><Input value={form.court} onChange={e => setForm(p => ({ ...p, court: e.target.value }))} /></div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="grid gap-2"><Label>{language === 'ar' ? 'القاضي' : 'Judge'}</Label><Input value={form.judge} onChange={e => setForm(p => ({ ...p, judge: e.target.value }))} /></div>
                                <div className="grid gap-2"><Label>{language === 'ar' ? 'التاريخ' : 'Date'}</Label><Input type="date" value={form.date} onChange={e => setForm(p => ({ ...p, date: e.target.value }))} /></div>
                            </div>
                        </div>
                        <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button><Button onClick={add} disabled={!form.caseTitle || !form.court}>{language === 'ar' ? 'إضافة' : 'Add'}</Button></DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
            <div className="flex items-center gap-2 max-w-lg">
                <div className="relative flex-1"><Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground rtl:left-auto rtl:right-2.5" /><Input className="pl-8 rtl:pl-3 rtl:pr-8" placeholder={language === 'ar' ? 'بحث...' : 'Search...'} value={search} onChange={e => setSearch(e.target.value)} /></div>
                <Select value={filter} onValueChange={setFilter}><SelectTrigger className="w-[130px]"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">{language === 'ar' ? 'الكل' : 'All'}</SelectItem><SelectItem value="Upcoming">{language === 'ar' ? 'قادمة' : 'Upcoming'}</SelectItem><SelectItem value="Completed">{language === 'ar' ? 'منتهية' : 'Completed'}</SelectItem><SelectItem value="Postponed">{language === 'ar' ? 'مؤجلة' : 'Postponed'}</SelectItem></SelectContent></Select>
            </div>
            <div className="space-y-3">
                {filtered.length === 0 ? <p className="text-center text-muted-foreground py-12">{language === 'ar' ? 'لا توجد جلسات' : 'No sessions'}</p> : filtered.map(s => (
                    <Card key={s.id} className="border-none shadow-sm hover:bg-muted/30 transition-colors">
                        <CardContent className="flex items-center justify-between p-4">
                            <div className="flex items-start gap-4">
                                <div className="rounded-xl bg-primary/10 p-3 text-primary"><Scale className="size-5" /></div>
                                <div className="space-y-1">
                                    <h4 className="font-medium text-sm">{s.caseTitle}</h4>
                                    <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                                        <span className="flex items-center gap-1"><MapPin className="size-3" />{s.court}</span>
                                        <span className="flex items-center gap-1"><User className="size-3" />{s.judge}</span>
                                        <span className="flex items-center gap-1"><Calendar className="size-3" />{s.date}</span>
                                        <span className="flex items-center gap-1"><Clock className="size-3" />{s.time}</span>
                                    </div>
                                </div>
                            </div>
                            <Select value={s.status} onValueChange={v => changeStatus(s.id, v as Session['status'])}>
                                <SelectTrigger className="h-7 w-auto border-none shadow-none p-0 bg-transparent"><Badge variant="secondary" className={statusCfg[s.status].color}>{language === 'ar' ? statusCfg[s.status].ar : s.status}</Badge></SelectTrigger>
                                <SelectContent><SelectItem value="Upcoming">{language === 'ar' ? 'قادمة' : 'Upcoming'}</SelectItem><SelectItem value="Completed">{language === 'ar' ? 'منتهية' : 'Completed'}</SelectItem><SelectItem value="Postponed">{language === 'ar' ? 'مؤجلة' : 'Postponed'}</SelectItem></SelectContent>
                            </Select>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    )
}
