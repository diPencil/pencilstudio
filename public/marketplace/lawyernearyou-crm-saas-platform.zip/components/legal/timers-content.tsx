'use client'

import React, { useState, useEffect } from 'react'
import { Timer, Plus, Play, Pause, Square, Briefcase, DollarSign } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { useLanguage } from '@/lib/language-context'

interface TimeEntry { id: number; caseTitle: string; description: string; duration: number; rate: number; date: string; running: boolean }

const initial: TimeEntry[] = [
    { id: 1, caseTitle: 'Mansour vs. Ministry', description: 'Document review and preparation', duration: 7200, rate: 150, date: '2024-03-07', running: false },
    { id: 2, caseTitle: 'TechCorp NDA', description: 'Contract drafting', duration: 3600, rate: 200, date: '2024-03-07', running: false },
    { id: 3, caseTitle: 'Kamel Inheritance', description: 'Client consultation', duration: 5400, rate: 175, date: '2024-03-06', running: false },
]

const fmtTime = (s: number) => { const h = Math.floor(s / 3600); const m = Math.floor((s % 3600) / 60); const sec = s % 60; return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}` }

export function TimersContent() {
    const { language } = useLanguage()
    const [entries, setEntries] = useState<TimeEntry[]>(initial)
    const [open, setOpen] = useState(false)
    const [form, setForm] = useState({ caseTitle: '', description: '', rate: '150' })
    const [feedback, setFeedback] = useState<string | null>(null)
    const show = (m: string) => { setFeedback(m); setTimeout(() => setFeedback(null), 2500) }

    useEffect(() => {
        const interval = setInterval(() => {
            setEntries(p => p.map(e => e.running ? { ...e, duration: e.duration + 1 } : e))
        }, 1000)
        return () => clearInterval(interval)
    }, [])

    const toggleTimer = (id: number) => {
        setEntries(p => p.map(e => e.id === id ? { ...e, running: !e.running } : e))
    }
    const stopTimer = (id: number) => {
        setEntries(p => p.map(e => e.id === id ? { ...e, running: false } : e))
        show(language === 'ar' ? '⏹️ تم إيقاف المؤقت' : '⏹️ Timer stopped')
    }

    const add = () => {
        if (!form.caseTitle) return
        setEntries(p => [{ id: Date.now(), caseTitle: form.caseTitle, description: form.description, duration: 0, rate: parseInt(form.rate) || 150, date: new Date().toISOString().split('T')[0], running: true }, ...p])
        setForm({ caseTitle: '', description: '', rate: '150' }); setOpen(false)
        show(language === 'ar' ? '⏱️ تم بدء المؤقت' : '⏱️ Timer started')
    }

    const totalHours = entries.reduce((a, e) => a + e.duration, 0) / 3600
    const totalBillable = entries.reduce((a, e) => a + (e.duration / 3600) * e.rate, 0)
    const activeCount = entries.filter(e => e.running).length

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300"><div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div></div>}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div><h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'ساعات العمل القانونية' : 'Legal Timers'}</h1><p className="text-muted-foreground">{language === 'ar' ? 'تتبع ساعات العمل المدفوعة لكل قضية.' : 'Track billable hours for each case.'}</p></div>
                <Dialog open={open} onOpenChange={setOpen}>
                    <DialogTrigger asChild><Button className="gap-2"><Plus className="size-4" />{language === 'ar' ? 'مؤقت جديد' : 'New Timer'}</Button></DialogTrigger>
                    <DialogContent>
                        <DialogHeader><DialogTitle>{language === 'ar' ? 'بدء مؤقت جديد' : 'Start New Timer'}</DialogTitle><DialogDescription>{language === 'ar' ? 'سيبدأ المؤقت فوراً.' : 'Timer will start immediately.'}</DialogDescription></DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'القضية *' : 'Case *'}</Label><Input value={form.caseTitle} onChange={e => setForm(p => ({ ...p, caseTitle: e.target.value }))} /></div>
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'الوصف' : 'Description'}</Label><Input value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} /></div>
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'السعر بالساعة ($)' : 'Hourly Rate ($)'}</Label><Input type="number" value={form.rate} onChange={e => setForm(p => ({ ...p, rate: e.target.value }))} /></div>
                        </div>
                        <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button><Button onClick={add} disabled={!form.caseTitle}><Play className="size-4 mr-1" />{language === 'ar' ? 'بدء' : 'Start'}</Button></DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
                {[{ l: language === 'ar' ? 'إجمالي الساعات' : 'Total Hours', v: totalHours.toFixed(1) + 'h', i: Timer }, { l: language === 'ar' ? 'قيمة الفواتير' : 'Billable Amount', v: '$' + totalBillable.toFixed(0), i: DollarSign }, { l: language === 'ar' ? 'مؤقتات نشطة' : 'Active Timers', v: activeCount, i: Play }].map((s, i) => (
                    <Card key={i} className="border-none bg-primary/5 shadow-sm"><CardContent className="p-6"><div className="flex items-center justify-between"><div><p className="text-sm font-medium text-muted-foreground">{s.l}</p><p className="text-2xl font-bold">{s.v}</p></div><div className="rounded-full bg-primary/10 p-2"><s.i className="size-5 text-primary" /></div></div></CardContent></Card>
                ))}
            </div>
            <div className="space-y-3">
                {entries.map(e => (
                    <Card key={e.id} className={`border-none shadow-sm transition-all ${e.running ? 'ring-2 ring-primary/50 bg-primary/5' : 'hover:bg-muted/30'}`}>
                        <CardContent className="flex items-center justify-between p-4">
                            <div className="flex items-center gap-4">
                                <div className={`rounded-xl p-3 ${e.running ? 'bg-primary text-primary-foreground animate-pulse' : 'bg-muted'}`}><Timer className="size-5" /></div>
                                <div>
                                    <div className="flex items-center gap-2"><h4 className="font-medium text-sm">{e.caseTitle}</h4>{e.running && <Badge className="h-5 text-[10px] animate-pulse">{language === 'ar' ? 'يعمل' : 'Running'}</Badge>}</div>
                                    <p className="text-xs text-muted-foreground">{e.description}</p>
                                    <p className="text-[10px] text-muted-foreground mt-0.5">${e.rate}/hr · {e.date}</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-3">
                                <span className={`font-mono text-lg font-bold tabular-nums ${e.running ? 'text-primary' : ''}`}>{fmtTime(e.duration)}</span>
                                <div className="flex gap-1">
                                    <Button variant={e.running ? 'outline' : 'default'} size="icon" className="size-8" onClick={() => toggleTimer(e.id)}>{e.running ? <Pause className="size-4" /> : <Play className="size-4" />}</Button>
                                    {e.running && <Button variant="ghost" size="icon" className="size-8 text-destructive" onClick={() => stopTimer(e.id)}><Square className="size-4" /></Button>}
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    )
}
