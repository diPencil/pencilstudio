'use client'

import { useState } from 'react'
import { useCases, useClients, deleteCase } from '@/lib/data-store'
import { useLanguage } from '@/lib/language-context'
import type { LegalCase } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Plus, Search, MoreHorizontal, Edit, Trash2, Briefcase, Eye, Scale } from 'lucide-react'
import Link from 'next/link'
import { CaseFormDialog } from './case-form-dialog'

const caseTypeLabels: Record<string, string> = {
  civil: 'Civil',
  criminal: 'Criminal',
  corporate: 'Corporate',
  family: 'Family',
  estate: 'Estate',
  other: 'Other',
}

type TypeFilter = LegalCase['caseType'] | 'all'

export function CasesContent() {
  const { t, language } = useLanguage()
  const { cases, isLoading } = useCases()
  const { clients } = useClients()
  const [searchQuery, setSearchQuery] = useState('')
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('all')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingCase, setEditingCase] = useState<LegalCase | null>(null)
  const [deletingCase, setDeletingCase] = useState<LegalCase | null>(null)

  const getClientName = (clientId: string) => {
    const client = clients.find((c) => c.id === clientId)
    return client ? `${client.firstName} ${client.lastName}` : (language === 'ar' ? 'غير معروف' : 'Unknown')
  }

  const getPriorityBadge = (priority: LegalCase['priority']) => {
    const labels: Record<LegalCase['priority'], string> = {
      low: language === 'ar' ? 'منخفضة' : 'Low',
      medium: language === 'ar' ? 'متوسطة' : 'Medium',
      high: language === 'ar' ? 'عالية' : 'High',
      urgent: language === 'ar' ? 'عاجلة' : 'Urgent',
    }
    const variants: Record<LegalCase['priority'], 'outline' | 'secondary' | 'default' | 'destructive'> = {
      low: 'outline',
      medium: 'secondary',
      high: 'default',
      urgent: 'destructive',
    }
    return <Badge variant={variants[priority]}>{labels[priority]}</Badge>
  }

  const filteredCases = cases.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      getClientName(c.clientId).toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = typeFilter === 'all' || c.caseType === typeFilter
    return matchesSearch && matchesType
  })

  const typeOptions: { value: TypeFilter; label: string }[] = [
    { value: 'all', label: language === 'ar' ? 'جميع الأنواع' : 'All Types' },
    { value: 'civil', label: language === 'ar' ? 'مدني' : 'Civil' },
    { value: 'criminal', label: language === 'ar' ? 'جنائي' : 'Criminal' },
    { value: 'corporate', label: language === 'ar' ? 'شركات' : 'Corporate' },
    { value: 'family', label: language === 'ar' ? 'أسرة' : 'Family' },
    { value: 'estate', label: language === 'ar' ? 'عقارات' : 'Estate' },
    { value: 'other', label: language === 'ar' ? 'أخرى' : 'Other' },
  ]

  const handleEdit = (legalCase: LegalCase) => {
    setEditingCase(legalCase)
    setDialogOpen(true)
  }

  const handleDelete = (legalCase: LegalCase) => {
    setDeletingCase(legalCase)
  }

  const handleDialogClose = () => {
    setDialogOpen(false)
    setEditingCase(null)
  }

  const confirmDelete = async () => {
    if (deletingCase) {
      await deleteCase(deletingCase.id)
      setDeletingCase(null)
    }
  }

  return (
    <div className="p-3 md:p-6 space-y-4 md:space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t('cases.title')}</h1>
          <p className="text-muted-foreground">{t('cases.desc')}</p>
        </div>
        <Button onClick={() => { setEditingCase(null); setDialogOpen(true) }} className="gap-2">
          <Plus className="size-4" />
          {t('cases.new')}
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3 px-4 md:px-6">
          <div className="flex flex-col md:flex-row gap-4 justify-between">
            <div className="relative w-full md:w-96">
              <Search className={`absolute ${language === 'ar' ? 'right-3' : 'left-3'} top-2.5 h-4 w-4 text-muted-foreground`} />
              <Input
                placeholder={t('cases.search')}
                className={language === 'ar' ? 'pr-9' : 'pl-9'}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-2 overflow-x-auto pb-1 md:pb-0">
              {typeOptions.map((opt) => (
                <Button
                  key={opt.value}
                  variant={typeFilter === opt.value ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setTypeFilter(opt.value)}
                  className="whitespace-nowrap"
                >
                  {opt.label}
                </Button>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="px-4 md:px-6">{language === 'ar' ? 'اسم القضية' : 'Case Name'}</TableHead>
                  <TableHead>{language === 'ar' ? 'الموكل' : 'Client'}</TableHead>
                  <TableHead>{language === 'ar' ? 'النوع' : 'Type'}</TableHead>
                  <TableHead>{language === 'ar' ? 'الأولوية' : 'Priority'}</TableHead>
                  <TableHead>{language === 'ar' ? 'الحالة' : 'Status'}</TableHead>
                  <TableHead className="text-right px-4 md:px-6">{language === 'ar' ? 'إجراءات' : 'Actions'}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                      {language === 'ar' ? 'جاري التحميل...' : 'Loading cases...'}
                    </TableCell>
                  </TableRow>
                ) : filteredCases.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                      {language === 'ar' ? 'لم يتم العثور على قضايا.' : 'No cases found.'}
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredCases.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-medium px-4 md:px-6 text-start">
                        <div className="flex flex-col">
                          <span>{c.name}</span>
                          <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{c.caseNumber}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-start">{getClientName(c.clientId)}</TableCell>
                      <TableCell className="text-start">
                        <Badge variant="outline">
                          {language === 'ar' ? (caseTypeLabels[c.caseType] === 'Civil' ? 'مدني' :
                            caseTypeLabels[c.caseType] === 'Criminal' ? 'جنائي' :
                              caseTypeLabels[c.caseType] === 'Corporate' ? 'شركات' :
                                caseTypeLabels[c.caseType] || c.caseType === 'family' ? 'أسرة' :
                                  caseTypeLabels[c.caseType] === 'Estate' ? 'عقارات' : 'أخرى') : (caseTypeLabels[c.caseType] || c.caseType)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-start">{getPriorityBadge(c.priority)}</TableCell>
                      <TableCell className="text-start">
                        <Badge
                          variant={c.status === 'active' ? 'default' : 'secondary'}
                        >
                          {c.status === 'active'
                            ? (language === 'ar' ? 'نشط' : 'Active')
                            : (language === 'ar' ? 'مغلق' : 'Closed')}
                        </Badge>
                      </TableCell>
                      <TableCell className={`${language === 'ar' ? 'text-left' : 'text-right'} px-4 md:px-6`}>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align={language === 'ar' ? 'start' : 'end'}>
                            <DropdownMenuItem asChild>
                              <Link href={`/cases/${c.id}`} className="flex items-center gap-2">
                                <Eye className={`h-4 w-4 ${language === 'ar' ? 'ml-2' : ''}`} />
                                {language === 'ar' ? 'عرض التفاصيل' : 'View Details'}
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEdit(c)} className="gap-2">
                              <Edit className="h-4 w-4" />
                              {language === 'ar' ? 'تعديل' : 'Edit'}
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleDelete(c)} className="gap-2 text-destructive">
                              <Trash2 className="h-4 w-4" />
                              {language === 'ar' ? 'حذف' : 'Delete'}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <CaseFormDialog
        open={dialogOpen}
        onOpenChange={handleDialogClose}
        legalCase={editingCase || undefined}
      />

      <AlertDialog open={!!deletingCase} onOpenChange={() => setDeletingCase(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{language === 'ar' ? 'هل أنت متأكد؟' : 'Are you absolutely sure?'}</AlertDialogTitle>
            <AlertDialogDescription>
              {language === 'ar'
                ? 'سيتم حذف القضية نهائياً من قاعدة البيانات.'
                : 'This action cannot be undone. This will permanently delete the case record.'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{language === 'ar' ? 'إلغاء' : 'Cancel'}</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              {language === 'ar' ? 'حذف' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
