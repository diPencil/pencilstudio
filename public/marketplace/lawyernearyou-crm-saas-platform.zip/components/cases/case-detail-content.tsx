'use client'

import React from "react"
import { useState } from 'react'
import Link from 'next/link'
import { useCase, useClient, useCaseHistory, useConsultations, useUsers, useTasks, useDocuments } from '@/lib/data-store'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Briefcase,
  User,
  Calendar,
  FileText,
  Phone,
  Mail,
  MapPin,
  Edit,
  ArrowLeft,
  Gavel,
  Scale,
  FileSearch,
  Users,
  StickyNote,
  Clock,
  CheckCircle2,
  Circle,
  AlertCircle,
  FileCheck,
  FolderOpen,
  Download,
} from 'lucide-react'
import { useLanguage } from '@/lib/language-context'
import { CaseFormDialog } from './case-form-dialog'

interface CaseDetailContentProps {
  caseId: string
}

const historyTypeIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  filing: FileText,
  evidence: FileSearch,
  judgment: Gavel,
  hearing: Gavel,
  mediation: Users,
  note: StickyNote,
}

export function CaseDetailContent({ caseId }: CaseDetailContentProps) {
  const { t, language, isRtl } = useLanguage()
  const { legalCase, isLoading: caseLoading } = useCase(caseId)
  const { client, isLoading: clientLoading } = useClient(legalCase?.clientId || '')
  const { history } = useCaseHistory(caseId)
  const { consultations } = useConsultations()
  const { users } = useUsers()
  const { tasks } = useTasks(caseId)
  const { documents } = useDocuments(caseId)
  const [editDialogOpen, setEditDialogOpen] = useState(false)

  const getLawyerName = (lawyerId: string) => users.find((u) => u.id === lawyerId)?.name || (language === 'ar' ? 'محامي غير معروف' : 'Unknown Lawyer')

  const caseConsultations = consultations
    .filter((c) => c.caseId === caseId)
    .sort((a, b) => b.date.localeCompare(a.date))

  const getPriorityBadge = (priority: string) => {
    const labels: Record<string, string> = {
      low: language === 'ar' ? 'منخفضة' : 'Low',
      medium: language === 'ar' ? 'متوسطة' : 'Medium',
      high: language === 'ar' ? 'عالية' : 'High',
      urgent: language === 'ar' ? 'عاجلة' : 'Urgent',
    }
    const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      low: 'outline',
      medium: 'secondary',
      high: 'default',
      urgent: 'destructive',
    }
    return <Badge variant={variants[priority] || 'outline'}>{labels[priority] || priority}</Badge>
  }

  if (caseLoading || clientLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-pulse text-muted-foreground">{language === 'ar' ? 'جاري تحميل تفاصيل القضية...' : 'Loading case details...'}</div>
      </div>
    )
  }

  if (!legalCase) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center">
        <Briefcase className="size-12 text-muted-foreground/50 mb-4" />
        <h2 className="text-xl font-semibold">{language === 'ar' ? 'القضية غير موجودة' : 'Case Not Found'}</h2>
        <p className="text-muted-foreground mb-4">{language === 'ar' ? 'تعذر العثور على القضية المطلوبة.' : 'The requested case could not be found.'}</p>
        <Button asChild>
          <Link href="/cases">
            <ArrowLeft className={`size-4 ${isRtl ? 'ml-2 rotate-180' : 'mr-2'}`} />
            {language === 'ar' ? 'الرجوع للقضايا' : 'Back to Cases'}
          </Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/cases">
              <ArrowLeft className={`size-4 ${isRtl ? 'rotate-180' : ''}`} />
            </Link>
          </Button>
          <div className="flex items-center gap-3">
            <div className="flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Briefcase className="size-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">{legalCase.name}</h1>
              <p className="text-muted-foreground">
                {legalCase.category} ({language === 'ar' ? (
                  legalCase.caseType === 'civil' ? 'مدني' :
                    legalCase.caseType === 'criminal' ? 'جنائي' :
                      legalCase.caseType === 'corporate' ? 'شركات' :
                        legalCase.caseType === 'family' ? 'أسرة' :
                          legalCase.caseType === 'estate' ? 'عقارات' : 'أخرى'
                ) : legalCase.caseType})
              </p>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="hidden sm:flex" onClick={() => {
            alert(language === 'ar' ? 'تم إنشاء وتحميل ملف PDF لملخص القضية.' : 'Case Summary PDF has been generated and downloaded.')
          }}>
            <Download className={`size-4 ${isRtl ? 'ml-2' : 'mr-2'}`} />
            {t('case.export')}
          </Button>
          <Button onClick={() => setEditDialogOpen(true)}>
            <Edit className={`size-4 ${isRtl ? 'ml-2' : 'mr-2'}`} />
            {t('case.edit')}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="mb-4 bg-muted/50 p-1 w-full flex overflow-x-auto justify-start h-auto">
          <TabsTrigger value="overview" className="flex-1 whitespace-nowrap">
            <Briefcase className={`size-4 ${isRtl ? 'ml-2' : 'mr-2'} hidden sm:inline-block`} />
            {t('case.overview')}
          </TabsTrigger>
          <TabsTrigger value="history" className="flex-1 whitespace-nowrap">
            <FileText className={`size-4 ${isRtl ? 'ml-2' : 'mr-2'} hidden sm:inline-block`} />
            {t('case.history')}
          </TabsTrigger>
          <TabsTrigger value="tasks" className="flex-1 whitespace-nowrap">
            <CheckCircle2 className={`size-4 ${isRtl ? 'ml-2' : 'mr-2'} hidden sm:inline-block`} />
            {t('case.todo')}
          </TabsTrigger>
          <TabsTrigger value="documents" className="flex-1 whitespace-nowrap">
            <FolderOpen className={`size-4 ${isRtl ? 'ml-2' : 'mr-2'} hidden sm:inline-block`} />
            {t('case.documents')}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-6 text-start">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Scale className="size-5" />
                    {t('case.info')}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <p className="text-sm text-muted-foreground">{t('case.type')}</p>
                      <p className="font-medium capitalize">
                        {language === 'ar' ? (
                          legalCase.caseType === 'civil' ? 'مدني' :
                            legalCase.caseType === 'criminal' ? 'جنائي' :
                              legalCase.caseType === 'corporate' ? 'شركات' :
                                legalCase.caseType === 'family' ? 'أسرة' :
                                  legalCase.caseType === 'estate' ? 'عقارات' : 'أخرى'
                        ) : legalCase.caseType}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">{t('case.category')}</p>
                      <p className="font-medium">{legalCase.category}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">{t('case.priority')}</p>
                      <div className="mt-1">{getPriorityBadge(legalCase.priority)}</div>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">{t('case.status')}</p>
                      <Badge variant="outline" className="mt-1 capitalize">
                        {language === 'ar' ? (legalCase.status === 'active' ? 'نشط' : 'مغلق') : legalCase.status}
                      </Badge>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">{t('case.lawyer')}</p>
                      <p className="font-medium">{getLawyerName(legalCase.assignedLawyerId)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">{t('case.filingDate')}</p>
                      <p className="font-medium">
                        {new Date(legalCase.filingDate).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                        })}
                      </p>
                    </div>
                    {legalCase.courtName && (
                      <div>
                        <p className="text-sm text-muted-foreground">{t('case.court')}</p>
                        <p className="font-medium">{legalCase.courtName}</p>
                      </div>
                    )}
                    {legalCase.caseNumber && (
                      <div>
                        <p className="text-sm text-muted-foreground">{t('case.number')}</p>
                        <p className="font-medium">{legalCase.caseNumber}</p>
                      </div>
                    )}
                    {legalCase.circleNumber && (
                      <div>
                        <p className="text-sm text-muted-foreground">{t('case.circle')}</p>
                        <p className="font-medium">{legalCase.circleNumber}</p>
                      </div>
                    )}
                    <div>
                      <p className="text-sm text-muted-foreground">{t('case.systemEntry')}</p>
                      <p className="font-medium">
                        {new Date(legalCase.createdAt).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                        })}
                      </p>
                    </div>
                  </div>
                  {legalCase.notes && (
                    <>
                      <Separator className="my-4" />
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">{t('case.notes')}</p>
                        <p className="text-sm">{legalCase.notes}</p>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6 text-start">
              {client && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User className="size-5" />
                      {t('case.clientInfo')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Link
                        href={`/clients/${client.id}`}
                        className="text-lg font-medium hover:text-primary transition-colors"
                      >
                        {client.firstName} {client.lastName}
                      </Link>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Phone className="size-4 text-muted-foreground" />
                        <span dir="ltr">{client.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Mail className="size-4 text-muted-foreground" />
                        <span className="break-all">{client.email}</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <MapPin className="size-4 text-muted-foreground mt-0.5" />
                        <span>{client.address}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="size-5" />
                    {t('case.consultations')}
                  </CardTitle>
                  <CardDescription>{language === 'ar' ? 'المواعيد المجدولة والماضية' : 'Scheduled and past meetings'}</CardDescription>
                </CardHeader>
                <CardContent>
                  {caseConsultations.length === 0 ? (
                    <div className="text-center py-4 text-muted-foreground text-sm">
                      {language === 'ar' ? 'لا توجد جلسات مجدولة' : 'No consultations scheduled'}
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {caseConsultations.slice(0, 4).map((cons) => (
                        <div key={cons.id} className="flex justify-between items-center text-sm">
                          <div className="flex items-start gap-2">
                            <Clock className="size-4 mt-0.5 text-muted-foreground" />
                            <div>
                              <p className="font-medium capitalize">
                                {language === 'ar' ? (
                                  cons.type === 'initial' ? 'أولى' :
                                    cons.type === 'follow-up' ? 'متابعة' :
                                      cons.type === 'strategy' ? 'استراتيجية' :
                                        cons.type === 'court-prep' ? 'تحضير مرافعة' :
                                          cons.type === 'emergency' ? 'طارئة' : 'وساطة'
                                ) : cons.type.replace('-', ' ')}
                              </p>
                              <p className="text-muted-foreground">
                                {new Date(cons.date).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US')} {language === 'ar' ? 'في' : 'at'} {cons.time}
                              </p>
                            </div>
                          </div>
                          <Badge
                            variant={
                              cons.status === 'completed'
                                ? 'secondary'
                                : cons.status === 'confirmed'
                                  ? 'default'
                                  : 'outline'
                            }
                          >
                            {language === 'ar' ? (
                              cons.status === 'completed' ? 'مكتمل' :
                                cons.status === 'confirmed' ? 'مؤكد' :
                                  cons.status === 'scheduled' ? 'مجدول' : 'ملغى'
                            ) : cons.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-start">
                <FileText className="size-5" />
                {t('case.history')}
              </CardTitle>
              <CardDescription className="text-start">
                {t('case.records').replace('{count}', history.length.toString())}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {history.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  {t('case.noHistory')}
                </div>
              ) : (
                <div className="space-y-4">
                  {history.map((record) => {
                    const Icon = historyTypeIcons[record.type] || FileText
                    return (
                      <div key={record.id} className="flex gap-4 rounded-lg border p-4 transition-colors hover:bg-muted/50 text-start">
                        <div className="flex size-10 shrink-0 items-center justify-center rounded-full bg-muted">
                          <Icon className="size-5" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <p className="font-medium text-lg">{record.title}</p>
                              <p className="text-sm text-muted-foreground">
                                {getLawyerName(record.lawyerId)} -{' '}
                                {new Date(record.date).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US')}
                              </p>
                            </div>
                            <Badge variant="outline" className="capitalize">
                              {language === 'ar' ? (
                                record.type === 'filing' ? 'تقديم مستند' :
                                  record.type === 'evidence' ? 'دليل' :
                                    record.type === 'judgment' ? 'حكم' :
                                      record.type === 'hearing' ? 'جلسة' :
                                        record.type === 'mediation' ? 'وساطة' : 'ملاحظة'
                              ) : record.type}
                            </Badge>
                          </div>
                          <p className={`mt-2 text-sm text-muted-foreground ${isRtl ? 'border-r-2 pr-3 mr-1' : 'border-l-2 pl-3 ml-1'} py-1`}>
                            {record.description}
                          </p>
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tasks">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-start">
                <CheckCircle2 className="size-5" />
                {t('case.todo')}
              </CardTitle>
              <CardDescription className="text-start">{language === 'ar' ? 'المهام النشطة والمواعيد النهائية لهذه القضية' : 'Active assignments and deadlines for this case'}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-start">{language === 'ar' ? 'الحالة' : 'Status'}</TableHead>
                      <TableHead className="text-start">{language === 'ar' ? 'المهمة' : 'Task'}</TableHead>
                      <TableHead className="text-start">{language === 'ar' ? 'مسندة إلى' : 'Assigned To'}</TableHead>
                      <TableHead className="text-start">{language === 'ar' ? 'تاريخ الاستحقاق' : 'Due Date'}</TableHead>
                      <TableHead className="text-start">{language === 'ar' ? 'الأولوية' : 'Priority'}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {tasks.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                          {t('case.noTasks')}
                        </TableCell>
                      </TableRow>
                    ) : (
                      tasks.map((task) => (
                        <TableRow key={task.id} className={task.status === 'completed' ? 'opacity-50' : ''}>
                          <TableCell>
                            {task.status === 'completed' ? (
                              <CheckCircle2 className="size-5 text-green-500" />
                            ) : task.status === 'in-progress' ? (
                              <Clock className="size-5 text-blue-500" />
                            ) : (
                              <Circle className="size-5 text-muted-foreground" />
                            )}
                          </TableCell>
                          <TableCell className="text-start">
                            <p className="font-medium">{task.title}</p>
                            <p className="text-xs text-muted-foreground">{task.description}</p>
                          </TableCell>
                          <TableCell className="text-start">{getLawyerName(task.assignedToId)}</TableCell>
                          <TableCell className="text-start">{new Date(task.dueDate).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US')}</TableCell>
                          <TableCell className="text-start">{getPriorityBadge(task.priority)}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-start">
                <FolderOpen className="size-5" />
                {language === 'ar' ? 'المستندات المرتبطة' : 'Linked Documents'}
              </CardTitle>
              <CardDescription className="text-start">{language === 'ar' ? 'جميع المستندات المرتبطة مباشرة بهذه القضية' : 'All documents associated directly with this case'}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3">
                {documents.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground border rounded-lg border-dashed">
                    {t('case.noDocs')}
                  </div>
                ) : (
                  documents.map((doc) => (
                    <div key={doc.id} className="flex items-center justify-between p-3 border rounded-lg hover:border-primary transition-colors cursor-pointer group text-start">
                      <div className="flex items-center gap-3">
                        <div className="bg-primary/10 p-2 rounded-lg text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                          {doc.type === 'power_of_attorney' ? <FileCheck className="size-5" /> : <FileText className="size-5" />}
                        </div>
                        <div>
                          <p className="font-medium">{doc.title}</p>
                          <p className="text-xs text-muted-foreground">
                            {language === 'ar' ? (
                              doc.type === 'power_of_attorney' ? 'توكيل' :
                                doc.type === 'contract' ? 'عقد' :
                                  doc.type === 'pleading' ? 'مذكرة' :
                                    doc.type === 'evidence' ? 'دليل' : 'أخرى'
                            ) : doc.type.replace('_', ' ')} • {language === 'ar' ? 'تم الرفع' : 'Uploaded'} {new Date(doc.createdAt).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US')}
                          </p>
                        </div>
                      </div>
                      <Badge variant={doc.status === 'final' || doc.status === 'verified' ? 'default' : 'secondary'}>
                        {language === 'ar' ? (
                          doc.status === 'final' ? 'نهائي' :
                            doc.status === 'verified' ? 'موثق' :
                              doc.status === 'draft' ? 'مسودة' : 'مقدم للمحكمة'
                        ) : doc.status.replace('_', ' ')}
                      </Badge>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <CaseFormDialog open={editDialogOpen} onOpenChange={setEditDialogOpen} legalCase={legalCase} />
    </div>
  )
}
