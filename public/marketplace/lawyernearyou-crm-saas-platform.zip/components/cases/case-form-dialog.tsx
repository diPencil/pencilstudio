'use client'

import React from "react"
import { useState, useEffect } from 'react'
import { addCase, updateCase, useClients, useUsers } from '@/lib/data-store'
import type { LegalCase } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface CaseFormDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  legalCase?: LegalCase | null
}

const caseTypeOptions: { value: LegalCase['caseType']; label: string }[] = [
  { value: 'civil', label: 'Civil' },
  { value: 'criminal', label: 'Criminal' },
  { value: 'corporate', label: 'Corporate' },
  { value: 'family', label: 'Family' },
  { value: 'estate', label: 'Estate' },
  { value: 'other', label: 'Other' },
]

const priorityOptions: { value: LegalCase['priority']; label: string }[] = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
  { value: 'urgent', label: 'Urgent' },
]

const statusOptions: { value: LegalCase['status']; label: string }[] = [
  { value: 'active', label: 'Active' },
  { value: 'pending', label: 'Pending' },
  { value: 'on-hold', label: 'On Hold' },
  { value: 'closed', label: 'Closed' },
]

export function CaseFormDialog({ open, onOpenChange, legalCase }: CaseFormDialogProps) {
  const { clients } = useClients()
  const { users } = useUsers()
  const isEditing = !!legalCase

  const [formData, setFormData] = useState({
    name: '',
    caseType: 'civil' as LegalCase['caseType'],
    category: '',
    priority: 'medium' as LegalCase['priority'],
    filingDate: new Date().toISOString().split('T')[0],
    clientId: '',
    status: 'active' as LegalCase['status'],
    assignedLawyerId: '',
    courtName: '',
    caseNumber: '',
    circleNumber: '',
    notes: '',
  })

  useEffect(() => {
    if (legalCase) {
      setFormData({
        name: legalCase.name,
        caseType: legalCase.caseType,
        category: legalCase.category,
        priority: legalCase.priority,
        filingDate: legalCase.filingDate,
        clientId: legalCase.clientId,
        status: legalCase.status,
        assignedLawyerId: legalCase.assignedLawyerId,
        courtName: legalCase.courtName || '',
        caseNumber: legalCase.caseNumber || '',
        circleNumber: legalCase.circleNumber || '',
        notes: legalCase.notes || '',
      })
    } else {
      setFormData({
        name: '',
        caseType: 'civil',
        category: '',
        priority: 'medium',
        filingDate: new Date().toISOString().split('T')[0],
        clientId: clients[0]?.id || '',
        status: 'active',
        assignedLawyerId: users[0]?.id || '',
        courtName: '',
        caseNumber: '',
        circleNumber: '',
        notes: '',
      })
    }
  }, [legalCase, clients, users])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const caseData = {
      name: formData.name,
      caseType: formData.caseType,
      category: formData.category,
      priority: formData.priority,
      filingDate: formData.filingDate,
      clientId: formData.clientId,
      status: formData.status,
      assignedLawyerId: formData.assignedLawyerId,
      courtName: formData.courtName,
      caseNumber: formData.caseNumber,
      circleNumber: formData.circleNumber,
      notes: formData.notes,
    }

    if (isEditing && legalCase) {
      updateCase(legalCase.id, caseData)
    } else {
      addCase(caseData)
    }

    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto backdrop-blur-sm">
        <DialogHeader>
          <DialogTitle>{isEditing ? 'Edit Case' : 'Add New Case'}</DialogTitle>
          <DialogDescription>
            {isEditing
              ? 'Update the case information below.'
              : 'Enter the details for the new legal case.'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2 col-span-2">
              <Label htmlFor="name">Case Name / Title</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Johnson vs. City Corp"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="caseType">Case Type</Label>
              <Select
                value={formData.caseType}
                onValueChange={(value: LegalCase['caseType']) =>
                  setFormData({ ...formData, caseType: value })
                }
              >
                <SelectTrigger id="caseType">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {caseTypeOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                value={formData.category}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, category: e.target.value })}
                placeholder="e.g., Personal Injury"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="priority">Priority</Label>
              <Select
                value={formData.priority}
                onValueChange={(value: LegalCase['priority']) =>
                  setFormData({ ...formData, priority: value })
                }
              >
                <SelectTrigger id="priority">
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  {priorityOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: LegalCase['status']) =>
                  setFormData({ ...formData, status: value })
                }
              >
                <SelectTrigger id="status">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  {statusOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="filingDate">Filing Date</Label>
              <Input
                id="filingDate"
                type="date"
                value={formData.filingDate}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, filingDate: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="client">Client</Label>
              <Select
                value={formData.clientId}
                onValueChange={(value) => setFormData({ ...formData, clientId: value })}
              >
                <SelectTrigger id="client">
                  <SelectValue placeholder="Select client" />
                </SelectTrigger>
                <SelectContent>
                  {clients.map((client) => (
                    <SelectItem key={client.id} value={client.id}>
                      {client.firstName} {client.lastName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="lawyer">Assigned Lawyer</Label>
              <Select
                value={formData.assignedLawyerId}
                onValueChange={(value) => setFormData({ ...formData, assignedLawyerId: value })}
              >
                <SelectTrigger id="lawyer">
                  <SelectValue placeholder="Select lawyer" />
                </SelectTrigger>
                <SelectContent>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="courtName">Court Name</Label>
              <Input
                id="courtName"
                value={formData.courtName}
                onChange={(e) => setFormData({ ...formData, courtName: e.target.value })}
                placeholder="e.g., Cairo Family Court"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="caseNumber">Court Case Number</Label>
              <Input
                id="caseNumber"
                value={formData.caseNumber}
                onChange={(e) => setFormData({ ...formData, caseNumber: e.target.value })}
                placeholder="e.g., 1234 / 2024"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="circleNumber">Circle Number</Label>
              <Input
                id="circleNumber"
                value={formData.circleNumber}
                onChange={(e) => setFormData({ ...formData, circleNumber: e.target.value })}
                placeholder="e.g., Circle 15 Family"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Any additional notes about the case..."
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">{isEditing ? 'Save Changes' : 'Create Case'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
