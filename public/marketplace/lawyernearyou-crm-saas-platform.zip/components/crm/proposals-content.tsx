'use client'

import React, { useState } from 'react'
import { FileSignature, Plus, Search, Send, Eye, CheckCircle2, Clock, XCircle, DollarSign } from 'lucide-react'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { useLanguage } from '@/lib/language-context'

interface Proposal { id: number; title: string; client: string; amount: string; status: 'Draft' | 'Sent' | 'Accepted' | 'Rejected'; date: string }

const initial: Proposal[] = [
    { id: 1, title: 'Corporate Legal Advisory Package', client: 'TechCorp Ltd.', amount: '$15,000/mo', status: 'Accepted', date: '2024-03-02' },
    { id: 2, title: 'Litigation Support - Land Dispute', client: 'Ahmed Mansour', amount: '$8,500', status: 'Sent', date: '2024-03-06' },
    { id: 3, title: 'Annual Compliance Review', client: 'Al-Nile Corp', amount: '$22,000', status: 'Draft', date: '2024-03-07' },
    { id: 4, title: 'Tax Advisory Services', client: 'Mohamed Zaki', amount: '$5,000', status: 'Rejected', date: '2024-02-20' },
]

const statusCfg: Record<string, { color: string; ar: string }> = {
    Draft: { color: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400', ar: 'مسودة' },
    Sent: { color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400', ar: 'مُرسل' },
    Accepted: { color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400', ar: 'مقبول' },
    Rejected: { color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400', ar: 'مرفوض' },
}

export function ProposalsContent() {
    const { language } = useLanguage()
    const [proposals, setProposals] = useState<Proposal[]>(initial)
    const [search, setSearch] = useState('')
    const [open, setOpen] = useState(false)
    const [form, setForm] = useState({ title: '', client: '', amount: '', description: '' })
    const [feedback, setFeedback] = useState<string | null>(null)
    const show = (m: string) => { setFeedback(m); setTimeout(() => setFeedback(null), 2500) }

    const add = () => {
        if (!form.title || !form.client) return
        setProposals(p => [{ id: Date.now(), title: form.title, client: form.client, amount: form.amount, status: 'Draft', date: new Date().toISOString().split('T')[0] }, ...p])
        setForm({ title: '', client: '', amount: '', description: '' }); setOpen(false)
        show(language === 'ar' ? '✅ تم إنشاء العرض' : '✅ Proposal created')
    }

    const sendProposal = (id: number) => { setProposals(p => p.map(pr => pr.id === id ? { ...pr, status: 'Sent' } : pr)); show(language === 'ar' ? '📧 تم إرسال العرض' : '📧 Proposal sent') }

    const filtered = proposals.filter(p => p.title.toLowerCase().includes(search.toLowerCase()) || p.client.toLowerCase().includes(search.toLowerCase()))
    const accepted = proposals.filter(p => p.status === 'Accepted').length
    const pending = proposals.filter(p => p.status === 'Sent').length

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300"><div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div></div>}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div><h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'العروض والمقترحات' : 'Proposals'}</h1><p className="text-muted-foreground">{language === 'ar' ? 'إنشاء وإرسال عروض الأسعار للعملاء المحتملين.' : 'Create and send proposals to potential clients.'}</p></div>
                <Dialog open={open} onOpenChange={setOpen}>
                    <DialogTrigger asChild><Button className="gap-2"><Plus className="size-4" />{language === 'ar' ? 'عرض جديد' : 'New Proposal'}</Button></DialogTrigger>
                    <DialogContent>
                        <DialogHeader><DialogTitle>{language === 'ar' ? 'إنشاء عرض جديد' : 'New Proposal'}</DialogTitle><DialogDescription>{language === 'ar' ? 'عيّن العنوان والعميل والمبلغ.' : 'Set a title, client, and amount.'}</DialogDescription></DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'العنوان *' : 'Title *'}</Label><Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} /></div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="grid gap-2"><Label>{language === 'ar' ? 'العميل *' : 'Client *'}</Label><Input value={form.client} onChange={e => setForm(p => ({ ...p, client: e.target.value }))} /></div>
                                <div className="grid gap-2"><Label>{language === 'ar' ? 'المبلغ' : 'Amount'}</Label><Input value={form.amount} onChange={e => setForm(p => ({ ...p, amount: e.target.value }))} placeholder="$10,000" /></div>
                            </div>
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'الوصف' : 'Description'}</Label><Textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} rows={3} /></div>
                        </div>
                        <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button><Button onClick={add} disabled={!form.title || !form.client}>{language === 'ar' ? 'إنشاء' : 'Create'}</Button></DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
                {[{ l: language === 'ar' ? 'إجمالي العروض' : 'Total', v: proposals.length, i: FileSignature }, { l: language === 'ar' ? 'مقبول' : 'Accepted', v: accepted, i: CheckCircle2 }, { l: language === 'ar' ? 'بانتظار الرد' : 'Pending', v: pending, i: Clock }].map((s, i) => (
                    <Card key={i} className="border-none bg-primary/5 shadow-sm"><CardContent className="p-6"><div className="flex items-center justify-between"><div><p className="text-sm font-medium text-muted-foreground">{s.l}</p><p className="text-2xl font-bold">{s.v}</p></div><div className="rounded-full bg-primary/10 p-2"><s.i className="size-5 text-primary" /></div></div></CardContent></Card>
                ))}
            </div>
            <Card className="border-none shadow-sm">
                <CardHeader><div className="relative max-w-sm"><Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground rtl:left-auto rtl:right-2.5" /><Input className="pl-8 rtl:pl-3 rtl:pr-8" placeholder={language === 'ar' ? 'بحث...' : 'Search...'} value={search} onChange={e => setSearch(e.target.value)} /></div></CardHeader>
                <CardContent><div className="space-y-3">{filtered.length === 0 ? <p className="text-center text-muted-foreground py-8">{language === 'ar' ? 'لا توجد عروض' : 'No proposals'}</p> : filtered.map(p => (
                    <div key={p.id} className="flex items-center justify-between p-4 rounded-lg border bg-card hover:bg-muted/30 transition-colors">
                        <div className="flex-1 min-w-0"><h4 className="font-medium text-sm truncate">{p.title}</h4><div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground"><span>{p.client}</span><span className="font-mono">{p.amount}</span><span>{p.date}</span></div></div>
                        <div className="flex items-center gap-2 ms-4"><Badge variant="secondary" className={statusCfg[p.status].color}>{language === 'ar' ? statusCfg[p.status].ar : p.status}</Badge>
                            {p.status === 'Draft' && <Button size="sm" variant="outline" className="gap-1 h-7 text-xs" onClick={() => sendProposal(p.id)}><Send className="size-3" />{language === 'ar' ? 'إرسال' : 'Send'}</Button>}
                            <Button size="icon" variant="ghost" className="size-7" onClick={() => show(language === 'ar' ? '👁️ عرض التفاصيل...' : '👁️ Viewing...')}><Eye className="size-3.5" /></Button>
                        </div>
                    </div>
                ))}</div></CardContent>
            </Card>
        </div>
    )
}
