'use client'

import React, { useState } from 'react'
import { FileText, Search, Plus, Eye, Send, CheckCircle2, Clock, AlertCircle, Download } from 'lucide-react'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useLanguage } from '@/lib/language-context'

interface Contract { id: number; title: string; client: string; status: 'Draft' | 'Sent' | 'Signed' | 'Expired'; value: string; date: string }

const initial: Contract[] = [
    { id: 1, title: 'Employment Agreement - TechCorp', client: 'TechCorp Ltd.', status: 'Signed', value: '$12,000', date: '2024-03-01' },
    { id: 2, title: 'NDA - Mansour Holdings', client: 'Ahmed Mansour', status: 'Sent', value: '$3,500', date: '2024-03-05' },
    { id: 3, title: 'Service Agreement - Al-Nile Corp', client: 'Al-Nile Corp', status: 'Draft', value: '$8,000', date: '2024-03-07' },
    { id: 4, title: 'Lease Agreement - Downtown Office', client: 'Sara Kamel', status: 'Expired', value: '$25,000', date: '2023-12-15' },
]

const statusConfig: Record<string, { icon: React.ElementType; color: string; ar: string }> = {
    Draft: { icon: Clock, color: 'bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-400', ar: 'مسودة' },
    Sent: { icon: Send, color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400', ar: 'مُرسل' },
    Signed: { icon: CheckCircle2, color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400', ar: 'موقّع' },
    Expired: { icon: AlertCircle, color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400', ar: 'منتهي' },
}

export function ContractsContent() {
    const { language } = useLanguage()
    const [contracts, setContracts] = useState<Contract[]>(initial)
    const [search, setSearch] = useState('')
    const [statusFilter, setStatusFilter] = useState('all')
    const [dialogOpen, setDialogOpen] = useState(false)
    const [form, setForm] = useState({ title: '', client: '', value: '' })
    const [feedback, setFeedback] = useState<string | null>(null)
    const show = (m: string) => { setFeedback(m); setTimeout(() => setFeedback(null), 2500) }

    const add = () => {
        if (!form.title || !form.client) return
        setContracts(p => [{ id: Date.now(), ...form, status: 'Draft', date: new Date().toISOString().split('T')[0] }, ...p])
        setForm({ title: '', client: '', value: '' }); setDialogOpen(false)
        show(language === 'ar' ? '✅ تم إنشاء العقد' : '✅ Contract created')
    }

    const filtered = contracts.filter(c => {
        const m1 = c.title.toLowerCase().includes(search.toLowerCase()) || c.client.toLowerCase().includes(search.toLowerCase())
        const m2 = statusFilter === 'all' || c.status === statusFilter
        return m1 && m2
    })

    const stats = { total: contracts.length, signed: contracts.filter(c => c.status === 'Signed').length, pending: contracts.filter(c => c.status === 'Sent').length }

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300"><div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div></div>}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div><h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'إدارة العقود' : 'Contracts'}</h1><p className="text-muted-foreground">{language === 'ar' ? 'إنشاء وتتبع وإدارة جميع العقود القانونية.' : 'Create, track, and manage all legal contracts.'}</p></div>
                <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                    <DialogTrigger asChild><Button className="gap-2"><Plus className="size-4" />{language === 'ar' ? 'عقد جديد' : 'New Contract'}</Button></DialogTrigger>
                    <DialogContent>
                        <DialogHeader><DialogTitle>{language === 'ar' ? 'إنشاء عقد جديد' : 'New Contract'}</DialogTitle><DialogDescription>{language === 'ar' ? 'أدخل تفاصيل العقد.' : 'Enter contract details.'}</DialogDescription></DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'عنوان العقد *' : 'Title *'}</Label><Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} /></div>
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'العميل *' : 'Client *'}</Label><Input value={form.client} onChange={e => setForm(p => ({ ...p, client: e.target.value }))} /></div>
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'القيمة' : 'Value'}</Label><Input value={form.value} onChange={e => setForm(p => ({ ...p, value: e.target.value }))} placeholder="$10,000" /></div>
                        </div>
                        <DialogFooter><Button variant="outline" onClick={() => setDialogOpen(false)}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button><Button onClick={add} disabled={!form.title || !form.client}>{language === 'ar' ? 'إنشاء' : 'Create'}</Button></DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
                {[{ label: language === 'ar' ? 'إجمالي العقود' : 'Total Contracts', val: stats.total, icon: FileText }, { label: language === 'ar' ? 'موقّعة' : 'Signed', val: stats.signed, icon: CheckCircle2 }, { label: language === 'ar' ? 'بانتظار التوقيع' : 'Pending', val: stats.pending, icon: Send }].map((s, i) => (
                    <Card key={i} className="border-none bg-primary/5 shadow-sm"><CardContent className="p-6"><div className="flex items-center justify-between"><div className="space-y-1"><p className="text-sm font-medium text-muted-foreground">{s.label}</p><p className="text-2xl font-bold">{s.val}</p></div><div className="rounded-full bg-primary/10 p-2"><s.icon className="size-5 text-primary" /></div></div></CardContent></Card>
                ))}
            </div>
            <Card className="border-none shadow-sm">
                <CardHeader><div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between"><div className="flex flex-1 items-center gap-2 max-w-sm"><div className="relative w-full"><Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground rtl:left-auto rtl:right-2.5" /><Input className="pl-8 rtl:pl-3 rtl:pr-8" placeholder={language === 'ar' ? 'بحث...' : 'Search...'} value={search} onChange={e => setSearch(e.target.value)} /></div></div><Select value={statusFilter} onValueChange={setStatusFilter}><SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">{language === 'ar' ? 'الكل' : 'All'}</SelectItem><SelectItem value="Draft">{language === 'ar' ? 'مسودة' : 'Draft'}</SelectItem><SelectItem value="Sent">{language === 'ar' ? 'مُرسل' : 'Sent'}</SelectItem><SelectItem value="Signed">{language === 'ar' ? 'موقّع' : 'Signed'}</SelectItem><SelectItem value="Expired">{language === 'ar' ? 'منتهي' : 'Expired'}</SelectItem></SelectContent></Select></div></CardHeader>
                <CardContent>
                    <div className="rounded-md border"><div className="relative w-full overflow-auto"><table className="w-full text-sm rtl:text-right"><thead className="[&_tr]:border-b bg-muted/50"><tr><th className="h-12 px-4 text-left rtl:text-right font-medium text-muted-foreground">{language === 'ar' ? 'العقد' : 'Contract'}</th><th className="h-12 px-4 text-left rtl:text-right font-medium text-muted-foreground">{language === 'ar' ? 'العميل' : 'Client'}</th><th className="h-12 px-4 text-left rtl:text-right font-medium text-muted-foreground">{language === 'ar' ? 'القيمة' : 'Value'}</th><th className="h-12 px-4 text-left rtl:text-right font-medium text-muted-foreground">{language === 'ar' ? 'الحالة' : 'Status'}</th><th className="h-12 px-4 text-right rtl:text-left font-medium text-muted-foreground">{language === 'ar' ? 'إجراءات' : 'Actions'}</th></tr></thead>
                        <tbody className="[&_tr:last-child]:border-0">
                            {filtered.length === 0 ? <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">{language === 'ar' ? 'لا توجد عقود' : 'No contracts'}</td></tr> : filtered.map(c => {
                                const cfg = statusConfig[c.status]
                                return (<tr key={c.id} className="border-b hover:bg-muted/50 transition-colors"><td className="p-4"><div className="font-medium">{c.title}</div><div className="text-xs text-muted-foreground">{c.date}</div></td><td className="p-4">{c.client}</td><td className="p-4 font-mono">{c.value || '-'}</td><td className="p-4"><Badge variant="secondary" className={`${cfg.color} gap-1`}><cfg.icon className="size-3" />{language === 'ar' ? cfg.ar : c.status}</Badge></td><td className="p-4 text-right rtl:text-left"><div className="flex justify-end rtl:justify-start gap-1"><Button variant="ghost" size="icon" className="size-8" onClick={() => show(language === 'ar' ? '👁️ عرض العقد...' : '👁️ Viewing contract...')}><Eye className="size-4" /></Button><Button variant="ghost" size="icon" className="size-8" onClick={() => show(language === 'ar' ? '📥 جاري التحميل...' : '📥 Downloading...')}><Download className="size-4" /></Button></div></td></tr>)
                            })}
                        </tbody></table></div></div>
                </CardContent>
            </Card>
        </div>
    )
}
