'use client'

import React, { useState } from 'react'
import {
    UserPlus,
    Search,
    Filter,
    MoreVertical,
    Mail,
    Phone,
    Calendar as CalendarIcon,
    TrendingUp,
    Target,
    UserCheck,
    X,
    Check,
} from 'lucide-react'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from '@/components/ui/dialog'
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select'
import { useLanguage } from '@/lib/language-context'

interface Lead {
    id: number
    name: string
    source: string
    status: 'New' | 'Contacted' | 'Qualified' | 'Lost'
    email: string
    phone: string
    date: string
}

const initialLeads: Lead[] = [
    { id: 1, name: 'Ahmed Mansour', source: 'Facebook Ads', status: 'New', email: 'ahmed@example.com', phone: '+20 101 234 5678', date: '2024-03-07' },
    { id: 2, name: 'Sara Kamel', source: 'Website', status: 'Contacted', email: 'sara@example.com', phone: '+20 109 876 5432', date: '2024-03-06' },
    { id: 3, name: 'Mohamed Zaki', source: 'Referral', status: 'Qualified', email: 'zaki@example.com', phone: '+20 105 555 4444', date: '2024-03-05' },
    { id: 4, name: 'Laila Hassan', source: 'Google', status: 'Lost', email: 'laila@example.com', phone: '+20 101 111 2222', date: '2024-03-04' },
    { id: 5, name: 'Omar Fathy', source: 'LinkedIn', status: 'New', email: 'omar@example.com', phone: '+20 112 333 4444', date: '2024-03-03' },
]

export function LeadsContent() {
    const { t, language } = useLanguage()
    const [leads, setLeads] = useState<Lead[]>(initialLeads)
    const [searchTerm, setSearchTerm] = useState('')
    const [statusFilter, setStatusFilter] = useState<string>('all')
    const [dialogOpen, setDialogOpen] = useState(false)
    const [newLead, setNewLead] = useState({ name: '', email: '', phone: '', source: 'Website' })
    const [actionFeedback, setActionFeedback] = useState<string | null>(null)

    const showFeedback = (msg: string) => {
        setActionFeedback(msg)
        setTimeout(() => setActionFeedback(null), 2500)
    }

    const handleAddLead = () => {
        if (!newLead.name || !newLead.email) return
        const lead: Lead = {
            id: Date.now(),
            name: newLead.name,
            email: newLead.email,
            phone: newLead.phone || '-',
            source: newLead.source,
            status: 'New',
            date: new Date().toISOString().split('T')[0],
        }
        setLeads(prev => [lead, ...prev])
        setNewLead({ name: '', email: '', phone: '', source: 'Website' })
        setDialogOpen(false)
        showFeedback(language === 'ar' ? `✅ تمت إضافة "${lead.name}" بنجاح` : `✅ "${lead.name}" added successfully`)
    }

    const handleDeleteLead = (id: number) => {
        const lead = leads.find(l => l.id === id)
        setLeads(prev => prev.filter(l => l.id !== id))
        showFeedback(language === 'ar' ? `🗑️ تم حذف "${lead?.name}"` : `🗑️ "${lead?.name}" removed`)
    }

    const handleStatusChange = (id: number, newStatus: Lead['status']) => {
        setLeads(prev => prev.map(l => l.id === id ? { ...l, status: newStatus } : l))
        showFeedback(language === 'ar' ? '✅ تم تحديث الحالة' : '✅ Status updated')
    }

    const filteredLeads = leads.filter(lead => {
        const matchSearch = lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            lead.email.toLowerCase().includes(searchTerm.toLowerCase())
        const matchStatus = statusFilter === 'all' || lead.status === statusFilter
        return matchSearch && matchStatus
    })

    const stats = {
        total: leads.length,
        conversion: leads.length > 0 ? Math.round((leads.filter(l => l.status === 'Qualified').length / leads.length) * 100) : 0,
        newCount: leads.filter(l => l.status === 'New').length,
    }

    const getStatusBadge = (status: string) => {
        const labels: Record<string, Record<string, string>> = {
            New: { ar: 'جديد', en: 'New' },
            Contacted: { ar: 'تم التواصل', en: 'Contacted' },
            Qualified: { ar: 'مؤهل', en: 'Qualified' },
            Lost: { ar: 'مستبعد', en: 'Lost' },
        }
        const colors: Record<string, string> = {
            New: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
            Contacted: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400',
            Qualified: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
            Lost: 'text-gray-500 border-gray-300',
        }
        return (
            <Badge variant={status === 'Lost' ? 'outline' : 'secondary'} className={colors[status]}>
                {labels[status]?.[language] || status}
            </Badge>
        )
    }

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {/* Feedback Toast */}
            {actionFeedback && (
                <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300">
                    <div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{actionFeedback}</div>
                </div>
            )}

            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">{t('nav.leads')}</h1>
                    <p className="text-muted-foreground">{language === 'ar' ? 'تتبع وإدارة العملاء المحتملين لزيادة نمو المكتب.' : 'Track and manage potential clients to grow your firm.'}</p>
                </div>
                <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                    <DialogTrigger asChild>
                        <Button className="gap-2">
                            <UserPlus className="size-4" />
                            {language === 'ar' ? 'إضافة عميل محتمل' : 'Add New Lead'}
                        </Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>{language === 'ar' ? 'إضافة عميل محتمل جديد' : 'Add New Lead'}</DialogTitle>
                            <DialogDescription>{language === 'ar' ? 'أدخل بيانات العميل المحتمل لإضافته إلى قائمة المتابعة.' : 'Enter the lead\'s details to add them to your pipeline.'}</DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid gap-2">
                                <Label>{language === 'ar' ? 'الاسم الكامل *' : 'Full Name *'}</Label>
                                <Input value={newLead.name} onChange={e => setNewLead(p => ({ ...p, name: e.target.value }))} placeholder={language === 'ar' ? 'مثال: أحمد محمود' : 'e.g. John Doe'} />
                            </div>
                            <div className="grid gap-2">
                                <Label>{language === 'ar' ? 'البريد الإلكتروني *' : 'Email *'}</Label>
                                <Input type="email" value={newLead.email} onChange={e => setNewLead(p => ({ ...p, email: e.target.value }))} placeholder="email@example.com" />
                            </div>
                            <div className="grid gap-2">
                                <Label>{language === 'ar' ? 'رقم الهاتف' : 'Phone'}</Label>
                                <Input type="tel" value={newLead.phone} onChange={e => setNewLead(p => ({ ...p, phone: e.target.value }))} placeholder="+20 1xx xxx xxxx" />
                            </div>
                            <div className="grid gap-2">
                                <Label>{language === 'ar' ? 'المصدر' : 'Source'}</Label>
                                <Select value={newLead.source} onValueChange={v => setNewLead(p => ({ ...p, source: v }))}>
                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Website">Website</SelectItem>
                                        <SelectItem value="Facebook Ads">Facebook Ads</SelectItem>
                                        <SelectItem value="Google">Google</SelectItem>
                                        <SelectItem value="Referral">Referral</SelectItem>
                                        <SelectItem value="LinkedIn">LinkedIn</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                        <DialogFooter>
                            <Button variant="outline" onClick={() => setDialogOpen(false)}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button>
                            <Button onClick={handleAddLead} disabled={!newLead.name || !newLead.email}>{language === 'ar' ? 'إضافة' : 'Add Lead'}</Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>

            {/* Stats */}
            <div className="grid gap-4 md:grid-cols-3">
                <Card className="overflow-hidden border-none bg-primary/5 shadow-sm">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div className="space-y-1">
                                <p className="text-sm font-medium text-muted-foreground">{language === 'ar' ? 'إجمالي المحتملين' : 'Total Leads'}</p>
                                <p className="text-2xl font-bold">{stats.total}</p>
                            </div>
                            <div className="rounded-full bg-primary/10 p-2"><Target className="size-5 text-primary" /></div>
                        </div>
                    </CardContent>
                </Card>
                <Card className="overflow-hidden border-none bg-primary/5 shadow-sm">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div className="space-y-1">
                                <p className="text-sm font-medium text-muted-foreground">{language === 'ar' ? 'معدل التحويل' : 'Conversion Rate'}</p>
                                <p className="text-2xl font-bold">{stats.conversion}%</p>
                            </div>
                            <div className="rounded-full bg-primary/10 p-2"><UserCheck className="size-5 text-primary" /></div>
                        </div>
                    </CardContent>
                </Card>
                <Card className="overflow-hidden border-none bg-primary/5 shadow-sm">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div className="space-y-1">
                                <p className="text-sm font-medium text-muted-foreground">{language === 'ar' ? 'عملاء جدد' : 'New Leads'}</p>
                                <p className="text-2xl font-bold">{stats.newCount}</p>
                            </div>
                            <div className="rounded-full bg-primary/10 p-2"><CalendarIcon className="size-5 text-primary" /></div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Table */}
            <Card className="border-none shadow-sm">
                <CardHeader>
                    <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                        <div className="flex flex-1 items-center gap-2 max-w-sm">
                            <div className="relative w-full">
                                <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground rtl:left-auto rtl:right-2.5" />
                                <Input className="pl-8 rtl:pl-3 rtl:pr-8" placeholder={language === 'ar' ? 'البحث بالاسم أو البريد...' : 'Search leads...'} value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                            </div>
                        </div>
                        <Select value={statusFilter} onValueChange={setStatusFilter}>
                            <SelectTrigger className="w-[160px]">
                                <Filter className="size-4 mr-2 rtl:mr-0 rtl:ml-2" />
                                <SelectValue placeholder={language === 'ar' ? 'تصفية' : 'Filter'} />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">{language === 'ar' ? 'الكل' : 'All'}</SelectItem>
                                <SelectItem value="New">{language === 'ar' ? 'جديد' : 'New'}</SelectItem>
                                <SelectItem value="Contacted">{language === 'ar' ? 'تم التواصل' : 'Contacted'}</SelectItem>
                                <SelectItem value="Qualified">{language === 'ar' ? 'مؤهل' : 'Qualified'}</SelectItem>
                                <SelectItem value="Lost">{language === 'ar' ? 'مستبعد' : 'Lost'}</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="rounded-md border">
                        <div className="relative w-full overflow-auto">
                            <table className="w-full caption-bottom text-sm rtl:text-right">
                                <thead className="[&_tr]:border-b bg-muted/50">
                                    <tr className="border-b">
                                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground rtl:text-right whitespace-nowrap">{language === 'ar' ? 'الاسم' : 'Name'}</th>
                                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground rtl:text-right whitespace-nowrap">{language === 'ar' ? 'المصدر' : 'Source'}</th>
                                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground rtl:text-right whitespace-nowrap">{language === 'ar' ? 'الحالة' : 'Status'}</th>
                                        <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground rtl:text-right whitespace-nowrap">{language === 'ar' ? 'التاريخ' : 'Date'}</th>
                                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground rtl:text-left whitespace-nowrap">{language === 'ar' ? 'الإجراءات' : 'Actions'}</th>
                                    </tr>
                                </thead>
                                <tbody className="[&_tr:last-child]:border-0">
                                    {filteredLeads.length === 0 ? (
                                        <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">{language === 'ar' ? 'لا توجد نتائج' : 'No leads found'}</td></tr>
                                    ) : filteredLeads.map((lead) => (
                                        <tr key={lead.id} className="border-b transition-colors hover:bg-muted/50">
                                            <td className="p-4 align-middle">
                                                <div className="font-medium">{lead.name}</div>
                                                <div className="text-xs text-muted-foreground">{lead.email}</div>
                                            </td>
                                            <td className="p-4 align-middle whitespace-nowrap">{lead.source}</td>
                                            <td className="p-4 align-middle">
                                                <Select value={lead.status} onValueChange={(v) => handleStatusChange(lead.id, v as Lead['status'])}>
                                                    <SelectTrigger className="h-7 w-auto border-none shadow-none p-0 bg-transparent">
                                                        {getStatusBadge(lead.status)}
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="New">{language === 'ar' ? 'جديد' : 'New'}</SelectItem>
                                                        <SelectItem value="Contacted">{language === 'ar' ? 'تم التواصل' : 'Contacted'}</SelectItem>
                                                        <SelectItem value="Qualified">{language === 'ar' ? 'مؤهل' : 'Qualified'}</SelectItem>
                                                        <SelectItem value="Lost">{language === 'ar' ? 'مستبعد' : 'Lost'}</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </td>
                                            <td className="p-4 align-middle whitespace-nowrap">{lead.date}</td>
                                            <td className="p-4 align-middle text-right rtl:text-left">
                                                <div className="flex justify-end rtl:justify-start gap-1">
                                                    <Button variant="ghost" size="icon" className="size-8" title={language === 'ar' ? 'إرسال بريد' : 'Send Email'} onClick={() => showFeedback(language === 'ar' ? `📧 جاري إرسال بريد لـ ${lead.name}` : `📧 Sending email to ${lead.name}`)}>
                                                        <Mail className="size-4" />
                                                    </Button>
                                                    <Button variant="ghost" size="icon" className="size-8" title={language === 'ar' ? 'اتصال' : 'Call'} onClick={() => showFeedback(language === 'ar' ? `📞 جاري الاتصال بـ ${lead.phone}` : `📞 Calling ${lead.phone}`)}>
                                                        <Phone className="size-4" />
                                                    </Button>
                                                    <Button variant="ghost" size="icon" className="size-8 text-destructive hover:text-destructive" title={language === 'ar' ? 'حذف' : 'Delete'} onClick={() => handleDeleteLead(lead.id)}>
                                                        <X className="size-4" />
                                                    </Button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    )
}
