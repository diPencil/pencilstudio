'use client'

import React, { useState } from 'react'
import { Wallet, Plus, Search, Receipt, TrendingDown, Car, Hammer, Building } from 'lucide-react'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useLanguage } from '@/lib/language-context'

interface Expense { id: number; title: string; category: string; amount: string; date: string; paidBy: string }

const catIcons: Record<string, React.ElementType> = { 'Court Fees': Hammer, 'Travel': Car, 'Office': Building, 'Expert': Wallet, 'Other': Receipt }
const catColors: Record<string, string> = { 'Court Fees': 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400', 'Travel': 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400', 'Office': 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400', 'Expert': 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400', 'Other': 'bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-400' }
const catAr: Record<string, string> = { 'Court Fees': 'رسوم محكمة', 'Travel': 'سفر', 'Office': 'مكتبي', 'Expert': 'خبراء', 'Other': 'أخرى' }

const initial: Expense[] = [
    { id: 1, title: 'Court stamp fees - Case #2024-001', category: 'Court Fees', amount: '$120', date: '2024-03-07', paidBy: 'Ahmed Mansour' },
    { id: 2, title: 'Uber to Alexandria Court', category: 'Travel', amount: '$45', date: '2024-03-06', paidBy: 'Mohamed Zaki' },
    { id: 3, title: 'Office printer cartridges', category: 'Office', amount: '$85', date: '2024-03-05', paidBy: 'Admin' },
    { id: 4, title: 'Expert witness consultation', category: 'Expert', amount: '$500', date: '2024-03-04', paidBy: 'Laila Hassan' },
    { id: 5, title: 'Notarization fees', category: 'Court Fees', amount: '$60', date: '2024-03-03', paidBy: 'Ahmed Mansour' },
]

export function ExpensesContent() {
    const { language } = useLanguage()
    const [expenses, setExpenses] = useState<Expense[]>(initial)
    const [search, setSearch] = useState('')
    const [catFilter, setCatFilter] = useState('all')
    const [open, setOpen] = useState(false)
    const [form, setForm] = useState({ title: '', category: 'Office', amount: '', paidBy: '' })
    const [feedback, setFeedback] = useState<string | null>(null)
    const show = (m: string) => { setFeedback(m); setTimeout(() => setFeedback(null), 2500) }

    const add = () => {
        if (!form.title || !form.amount) return
        setExpenses(p => [{ id: Date.now(), ...form, date: new Date().toISOString().split('T')[0] }, ...p])
        setForm({ title: '', category: 'Office', amount: '', paidBy: '' }); setOpen(false)
        show(language === 'ar' ? '✅ تم تسجيل المصروف' : '✅ Expense recorded')
    }

    const filtered = expenses.filter(e => { const m1 = e.title.toLowerCase().includes(search.toLowerCase()); const m2 = catFilter === 'all' || e.category === catFilter; return m1 && m2 })
    const total = expenses.reduce((a, e) => a + parseFloat(e.amount.replace('$', '').replace(',', '')), 0)

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300"><div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div></div>}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div><h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'المصروفات' : 'Expenses'}</h1><p className="text-muted-foreground">{language === 'ar' ? 'تتبع جميع مصروفات المكتب والقضايا.' : 'Track all firm and case expenses.'}</p></div>
                <Dialog open={open} onOpenChange={setOpen}>
                    <DialogTrigger asChild><Button className="gap-2"><Plus className="size-4" />{language === 'ar' ? 'مصروف جديد' : 'New Expense'}</Button></DialogTrigger>
                    <DialogContent>
                        <DialogHeader><DialogTitle>{language === 'ar' ? 'تسجيل مصروف' : 'Record Expense'}</DialogTitle><DialogDescription>{language === 'ar' ? 'أدخل تفاصيل المصروف.' : 'Enter expense details.'}</DialogDescription></DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'الوصف *' : 'Description *'}</Label><Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} /></div>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="grid gap-2"><Label>{language === 'ar' ? 'المبلغ *' : 'Amount *'}</Label><Input value={form.amount} onChange={e => setForm(p => ({ ...p, amount: e.target.value }))} placeholder="$100" /></div>
                                <div className="grid gap-2"><Label>{language === 'ar' ? 'التصنيف' : 'Category'}</Label><Select value={form.category} onValueChange={v => setForm(p => ({ ...p, category: v }))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{Object.keys(catIcons).map(c => <SelectItem key={c} value={c}>{language === 'ar' ? catAr[c] : c}</SelectItem>)}</SelectContent></Select></div>
                            </div>
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'المدفوع بواسطة' : 'Paid By'}</Label><Input value={form.paidBy} onChange={e => setForm(p => ({ ...p, paidBy: e.target.value }))} /></div>
                        </div>
                        <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button><Button onClick={add} disabled={!form.title || !form.amount}>{language === 'ar' ? 'تسجيل' : 'Record'}</Button></DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
                <Card className="border-none bg-primary/5 shadow-sm"><CardContent className="p-6"><div className="flex items-center justify-between"><div><p className="text-sm font-medium text-muted-foreground">{language === 'ar' ? 'إجمالي المصروفات' : 'Total Expenses'}</p><p className="text-2xl font-bold">${total.toFixed(0)}</p></div><div className="rounded-full bg-primary/10 p-2"><TrendingDown className="size-5 text-primary" /></div></div></CardContent></Card>
                <Card className="border-none bg-primary/5 shadow-sm"><CardContent className="p-6"><div className="flex items-center justify-between"><div><p className="text-sm font-medium text-muted-foreground">{language === 'ar' ? 'عدد المصروفات' : 'Entries'}</p><p className="text-2xl font-bold">{expenses.length}</p></div><div className="rounded-full bg-primary/10 p-2"><Receipt className="size-5 text-primary" /></div></div></CardContent></Card>
            </div>
            <Card className="border-none shadow-sm">
                <CardHeader><div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between"><div className="relative max-w-sm"><Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground rtl:left-auto rtl:right-2.5" /><Input className="pl-8 rtl:pl-3 rtl:pr-8" placeholder={language === 'ar' ? 'بحث...' : 'Search...'} value={search} onChange={e => setSearch(e.target.value)} /></div><Select value={catFilter} onValueChange={setCatFilter}><SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">{language === 'ar' ? 'الكل' : 'All'}</SelectItem>{Object.keys(catIcons).map(c => <SelectItem key={c} value={c}>{language === 'ar' ? catAr[c] : c}</SelectItem>)}</SelectContent></Select></div></CardHeader>
                <CardContent><div className="space-y-2">{filtered.length === 0 ? <p className="text-center text-muted-foreground py-8">{language === 'ar' ? 'لا نتائج' : 'No expenses'}</p> : filtered.map(e => {
                    const Icon = catIcons[e.category] || Receipt; return (
                        <div key={e.id} className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-muted/30 transition-colors"><div className="flex items-center gap-3"><div className="rounded-lg bg-muted p-2"><Icon className="size-4" /></div><div><h4 className="font-medium text-sm">{e.title}</h4><p className="text-xs text-muted-foreground">{e.paidBy} · {e.date}</p></div></div><div className="flex items-center gap-2"><Badge variant="secondary" className={catColors[e.category]}>{language === 'ar' ? catAr[e.category] : e.category}</Badge><span className="font-mono font-semibold text-sm">{e.amount}</span></div></div>
                    )
                })}</div></CardContent>
            </Card>
        </div>
    )
}
