'use client'

import React, { useState } from 'react'
import { Receipt, Plus, Search, Send, Eye, DollarSign, Clock, CheckCircle2, XCircle } from 'lucide-react'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useLanguage } from '@/lib/language-context'

interface Invoice { id: number; number: string; client: string; amount: string; status: 'Paid' | 'Pending' | 'Overdue'; date: string; dueDate: string }

const initial: Invoice[] = [
    { id: 1, number: 'INV-0045', client: 'TechCorp Ltd.', amount: '$12,000', status: 'Paid', date: '2024-03-01', dueDate: '2024-03-15' },
    { id: 2, number: 'INV-0046', client: 'Ahmed Mansour', amount: '$3,500', status: 'Pending', date: '2024-03-05', dueDate: '2024-03-20' },
    { id: 3, number: 'INV-0047', client: 'Al-Nile Corp', amount: '$8,200', status: 'Overdue', date: '2024-02-15', dueDate: '2024-03-01' },
    { id: 4, number: 'INV-0048', client: 'Sara Kamel', amount: '$5,000', status: 'Paid', date: '2024-03-07', dueDate: '2024-03-21' },
]

const statusCfg: Record<string, { color: string; ar: string; icon: React.ElementType }> = {
    Paid: { color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400', ar: 'مدفوعة', icon: CheckCircle2 },
    Pending: { color: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400', ar: 'معلّقة', icon: Clock },
    Overdue: { color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400', ar: 'متأخرة', icon: XCircle },
}

export function InvoicesContent() {
    const { language } = useLanguage()
    const [invoices, setInvoices] = useState<Invoice[]>(initial)
    const [search, setSearch] = useState('')
    const [filter, setFilter] = useState('all')
    const [open, setOpen] = useState(false)
    const [form, setForm] = useState({ client: '', amount: '' })
    const [feedback, setFeedback] = useState<string | null>(null)
    const show = (m: string) => { setFeedback(m); setTimeout(() => setFeedback(null), 2500) }

    const add = () => {
        if (!form.client || !form.amount) return
        const num = `INV-${String(49 + invoices.length).padStart(4, '0')}`
        setInvoices(p => [{ id: Date.now(), number: num, client: form.client, amount: form.amount, status: 'Pending', date: new Date().toISOString().split('T')[0], dueDate: '—' }, ...p])
        setForm({ client: '', amount: '' }); setOpen(false)
        show(language === 'ar' ? '✅ تم إنشاء الفاتورة' : '✅ Invoice created')
    }

    const markPaid = (id: number) => { setInvoices(p => p.map(i => i.id === id ? { ...i, status: 'Paid' } : i)); show(language === 'ar' ? '✅ تم التحديث' : '✅ Marked as paid') }

    const filtered = invoices.filter(i => { const m1 = i.client.toLowerCase().includes(search.toLowerCase()) || i.number.toLowerCase().includes(search.toLowerCase()); const m2 = filter === 'all' || i.status === filter; return m1 && m2 })
    const totalPaid = invoices.filter(i => i.status === 'Paid').length
    const totalOverdue = invoices.filter(i => i.status === 'Overdue').length

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300"><div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div></div>}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div><h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'الفواتير' : 'Invoices'}</h1><p className="text-muted-foreground">{language === 'ar' ? 'إنشاء وتتبع جميع فواتير المكتب.' : 'Create and track all firm invoices.'}</p></div>
                <Dialog open={open} onOpenChange={setOpen}>
                    <DialogTrigger asChild><Button className="gap-2"><Plus className="size-4" />{language === 'ar' ? 'فاتورة جديدة' : 'New Invoice'}</Button></DialogTrigger>
                    <DialogContent>
                        <DialogHeader><DialogTitle>{language === 'ar' ? 'إنشاء فاتورة' : 'New Invoice'}</DialogTitle><DialogDescription>{language === 'ar' ? 'أدخل بيانات الفاتورة.' : 'Enter invoice details.'}</DialogDescription></DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'العميل *' : 'Client *'}</Label><Input value={form.client} onChange={e => setForm(p => ({ ...p, client: e.target.value }))} /></div>
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'المبلغ *' : 'Amount *'}</Label><Input value={form.amount} onChange={e => setForm(p => ({ ...p, amount: e.target.value }))} placeholder="$5,000" /></div>
                        </div>
                        <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button><Button onClick={add} disabled={!form.client || !form.amount}>{language === 'ar' ? 'إنشاء' : 'Create'}</Button></DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
                {[{ l: language === 'ar' ? 'إجمالي الفواتير' : 'Total', v: invoices.length, i: Receipt }, { l: language === 'ar' ? 'مدفوعة' : 'Paid', v: totalPaid, i: CheckCircle2 }, { l: language === 'ar' ? 'متأخرة' : 'Overdue', v: totalOverdue, i: XCircle }].map((s, i) => (
                    <Card key={i} className="border-none bg-primary/5 shadow-sm"><CardContent className="p-6"><div className="flex items-center justify-between"><div><p className="text-sm font-medium text-muted-foreground">{s.l}</p><p className="text-2xl font-bold">{s.v}</p></div><div className="rounded-full bg-primary/10 p-2"><s.i className="size-5 text-primary" /></div></div></CardContent></Card>
                ))}
            </div>
            <Card className="border-none shadow-sm">
                <CardHeader><div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between"><div className="relative max-w-sm"><Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground rtl:left-auto rtl:right-2.5" /><Input className="pl-8 rtl:pl-3 rtl:pr-8" placeholder={language === 'ar' ? 'بحث...' : 'Search...'} value={search} onChange={e => setSearch(e.target.value)} /></div><Select value={filter} onValueChange={setFilter}><SelectTrigger className="w-[130px]"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">{language === 'ar' ? 'الكل' : 'All'}</SelectItem><SelectItem value="Paid">{language === 'ar' ? 'مدفوعة' : 'Paid'}</SelectItem><SelectItem value="Pending">{language === 'ar' ? 'معلّقة' : 'Pending'}</SelectItem><SelectItem value="Overdue">{language === 'ar' ? 'متأخرة' : 'Overdue'}</SelectItem></SelectContent></Select></div></CardHeader>
                <CardContent><div className="rounded-md border"><div className="w-full overflow-auto"><table className="w-full text-sm rtl:text-right"><thead className="bg-muted/50 [&_tr]:border-b"><tr><th className="h-12 px-4 text-left rtl:text-right font-medium text-muted-foreground">#{language === 'ar' ? ' الرقم' : ''}</th><th className="h-12 px-4 text-left rtl:text-right font-medium text-muted-foreground">{language === 'ar' ? 'العميل' : 'Client'}</th><th className="h-12 px-4 text-left rtl:text-right font-medium text-muted-foreground">{language === 'ar' ? 'المبلغ' : 'Amount'}</th><th className="h-12 px-4 text-left rtl:text-right font-medium text-muted-foreground">{language === 'ar' ? 'الحالة' : 'Status'}</th><th className="h-12 px-4 text-right rtl:text-left font-medium text-muted-foreground">{language === 'ar' ? 'إجراءات' : 'Actions'}</th></tr></thead>
                    <tbody className="[&_tr:last-child]:border-0">{filtered.length === 0 ? <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">{language === 'ar' ? 'لا فواتير' : 'No invoices'}</td></tr> : filtered.map(inv => {
                        const cfg = statusCfg[inv.status]; return (
                            <tr key={inv.id} className="border-b hover:bg-muted/50"><td className="p-4 font-mono text-xs">{inv.number}</td><td className="p-4">{inv.client}</td><td className="p-4 font-mono font-semibold">{inv.amount}</td><td className="p-4"><Badge variant="secondary" className={`${cfg.color} gap-1`}><cfg.icon className="size-3" />{language === 'ar' ? cfg.ar : inv.status}</Badge></td><td className="p-4 text-right rtl:text-left"><div className="flex justify-end rtl:justify-start gap-1">{inv.status !== 'Paid' && <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => markPaid(inv.id)}><CheckCircle2 className="size-3" />{language === 'ar' ? 'تم الدفع' : 'Mark Paid'}</Button>}<Button variant="ghost" size="icon" className="size-7" onClick={() => show(language === 'ar' ? '📧 جاري الإرسال...' : '📧 Sending...')}><Send className="size-3.5" /></Button></div></td></tr>
                        )
                    })}</tbody></table></div></div></CardContent>
            </Card>
        </div>
    )
}
