'use client'

import React from "react"
import { useState } from 'react'
import Link from 'next/link'
import { useClient, useCases, useConsultations, useUsers } from '@/lib/data-store'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Users,
  Phone,
  Mail,
  MapPin,
  Briefcase,
  Calendar,
  Edit,
  ArrowLeft,
  Plus,
  Clock,
  FileText,
} from 'lucide-react'
import { ClientFormDialog } from './client-form-dialog'
import { CaseFormDialog } from '@/components/cases/case-form-dialog'

interface ClientDetailContentProps {
  clientId: string
}

export function ClientDetailContent({ clientId }: ClientDetailContentProps) {
  const { client, isLoading } = useClient(clientId)
  const { cases } = useCases()
  const { consultations } = useConsultations()
  const { users } = useUsers()
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [addCaseDialogOpen, setAddCaseDialogOpen] = useState(false)

  const getLawyerName = (lawyerId: string) => users.find((u) => u.id === lawyerId)?.name || 'Unknown Lawyer'

  const clientCases = cases.filter((c) => c.clientId === clientId)
  const clientConsultations = consultations
    .filter((c) => c.clientId === clientId)
    .sort((a, b) => b.date.localeCompare(a.date))

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-pulse text-muted-foreground">Loading client details...</div>
      </div>
    )
  }

  if (!client) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center">
        <Users className="size-12 text-muted-foreground/50 mb-4" />
        <h2 className="text-xl font-semibold">Client Not Found</h2>
        <p className="text-muted-foreground mb-4">The requested client could not be found.</p>
        <Button asChild>
          <Link href="/clients">
            <ArrowLeft className="size-4 mr-2" />
            Back to Clients
          </Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/clients">
              <ArrowLeft className="size-4" />
            </Link>
          </Button>
          <div className="flex items-center gap-3">
            <div className="flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Users className="size-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">
                {client.firstName} {client.lastName}
              </h1>
              <p className="text-muted-foreground">Client since {new Date(client.createdAt).toLocaleDateString()}</p>
            </div>
          </div>
        </div>
        <Button onClick={() => setEditDialogOpen(true)}>
          <Edit className="size-4 mr-2" />
          Edit Client
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="size-5" />
                  Legal Cases
                  <Badge variant="secondary" className="ml-2">{clientCases.length}</Badge>
                </CardTitle>
                <CardDescription>Active and historical cases for this client</CardDescription>
              </div>
              <Button size="sm" onClick={() => setAddCaseDialogOpen(true)}>
                <Plus className="size-4 mr-2" />
                Add Case
              </Button>
            </CardHeader>
            <CardContent>
              {clientCases.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No cases registered for this client
                </div>
              ) : (
                <div className="grid gap-4 sm:grid-cols-2">
                  {clientCases.map((c) => (
                    <Link
                      key={c.id}
                      href={`/cases/${c.id}`}
                      className="flex items-center gap-4 rounded-lg border p-4 transition-colors hover:bg-muted/50"
                    >
                      <div className="flex size-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                        <Briefcase className="size-5" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium truncate">{c.name}</p>
                        <p className="text-sm text-muted-foreground capitalize">
                          {c.caseType} • {c.priority}
                        </p>
                      </div>
                      <Badge variant={c.status === 'active' ? 'default' : 'secondary'} className="capitalize text-[10px]">
                        {c.status}
                      </Badge>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="size-5" />
                Consultation History
              </CardTitle>
              <CardDescription>All scheduled meetings and conferences</CardDescription>
            </CardHeader>
            <CardContent>
              {clientConsultations.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No consultation history
                </div>
              ) : (
                <div className="space-y-4">
                  {clientConsultations.slice(0, 6).map((cons) => {
                    const legalCase = cases.find((c) => c.id === cons.caseId)
                    return (
                      <div
                        key={cons.id}
                        className="flex items-start justify-between gap-4 rounded-lg border p-4"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium truncate max-w-[200px]">{legalCase?.name || 'General Consultation'}</span>
                            <Badge variant="outline" className="capitalize">
                              {cons.type.replace('-', ' ')}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground flex items-center gap-1">
                            <Clock className="size-3" />
                            {new Date(cons.date).toLocaleDateString('en-US', {
                              weekday: 'short',
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                            })}{' '}
                            at {cons.time}
                          </p>
                          <p className="text-sm text-muted-foreground">{getLawyerName(cons.lawyerId)}</p>
                        </div>
                        <Badge
                          variant={
                            cons.status === 'completed'
                              ? 'secondary'
                              : cons.status === 'confirmed'
                                ? 'default'
                                : cons.status === 'cancelled'
                                  ? 'destructive'
                                  : 'outline'
                          }
                          className="capitalize"
                        >
                          {cons.status}
                        </Badge>
                      </div>
                    )
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="size-5" />
                Contact Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex size-9 items-center justify-center rounded-full bg-muted">
                  <Phone className="size-4 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Phone</p>
                  <p className="font-medium">{client.phone}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex size-9 items-center justify-center rounded-full bg-muted">
                  <Mail className="size-4 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Email</p>
                  <p className="font-medium break-all">{client.email}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="flex size-9 items-center justify-center rounded-full bg-muted">
                  <MapPin className="size-4 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Address</p>
                  <p className="font-medium leading-tight">{client.address}</p>
                </div>
              </div>

              {client.nationalId && (
                <div className="flex items-center gap-3">
                  <div className="flex size-9 items-center justify-center rounded-full bg-muted">
                    <FileText className="size-4 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground font-semibold">National ID</p>
                    <p className="font-medium">{client.nationalId}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Case Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div className="flex justify-between items-center border-b pb-2">
                <span className="text-muted-foreground">Total Cases</span>
                <span className="font-bold">{clientCases.length}</span>
              </div>
              <div className="flex justify-between items-center border-b pb-2">
                <span className="text-muted-foreground">Total Consultations</span>
                <span className="font-bold">{clientConsultations.length}</span>
              </div>
              <div className="flex justify-between items-center border-b pb-2">
                <span className="text-muted-foreground">Active Litigation</span>
                <span className="font-bold">
                  {clientCases.filter((c) => c.status === 'active').length}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Completed / Closed</span>
                <span className="font-bold">
                  {clientCases.filter((c) => c.status === 'closed').length}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <ClientFormDialog open={editDialogOpen} onOpenChange={setEditDialogOpen} client={client} />
      <CaseFormDialog
        open={addCaseDialogOpen}
        onOpenChange={setAddCaseDialogOpen}
        legalCase={{ clientId } as any}
      />
    </div>
  )
}
