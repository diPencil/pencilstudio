'use client'

import React from "react"
import { useState, useEffect } from 'react'
import { addCaseHistory, useCases, useUsers } from '@/lib/data-store'
import type { CaseHistory } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface CaseHistoryFormDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  caseId?: string
}

const typeOptions: { value: CaseHistory['type']; label: string }[] = [
  { value: 'filing', label: 'Legal Filing' },
  { value: 'evidence', label: 'Evidence Submission' },
  { value: 'judgment', label: 'Court Judgment' },
  { value: 'mediation', label: 'Mediation Record' },
  { value: 'hearing', label: 'Hearing Outcome' },
  { value: 'note', label: 'Case Note' },
]

// Hardcoded lawyers array removed in favor of useUsers hook

export function CaseHistoryFormDialog({
  open,
  onOpenChange,
  caseId: initialCaseId,
}: CaseHistoryFormDialogProps) {
  const { cases } = useCases()
  const { users } = useUsers()

  const [formData, setFormData] = useState({
    caseId: initialCaseId || '',
    date: '',
    type: 'filing' as CaseHistory['type'],
    title: '',
    description: '',
    lawyerId: '',
  })

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0]
    setFormData({
      caseId: initialCaseId || cases[0]?.id || '',
      date: today,
      type: 'filing',
      title: '',
      description: '',
      lawyerId: users[0]?.id || '',
    })
  }, [initialCaseId, cases, users, open])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    addCaseHistory(formData)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto backdrop-blur-sm">
        <DialogHeader>
          <DialogTitle>Add Case Record</DialogTitle>
          <DialogDescription>
            Create a new historical record or filing update for this case.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="case">Associated Case</Label>
              <Select
                value={formData.caseId}
                onValueChange={(value) => setFormData({ ...formData, caseId: value })}
              >
                <SelectTrigger id="case">
                  <SelectValue placeholder="Select case" />
                </SelectTrigger>
                <SelectContent>
                  {cases.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="date">Date of Record</Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, date: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Record Category</Label>
              <Select
                value={formData.type}
                onValueChange={(value: CaseHistory['type']) =>
                  setFormData({ ...formData, type: value })
                }
              >
                <SelectTrigger id="type">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {typeOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="lawyer">Assigning Lawyer</Label>
              <Select
                value={formData.lawyerId}
                onValueChange={(value) => setFormData({ ...formData, lawyerId: value })}
              >
                <SelectTrigger id="lawyer">
                  <SelectValue placeholder="Select lawyer" />
                </SelectTrigger>
                <SelectContent>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">Subject / Title</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, title: e.target.value })}
              placeholder="e.g., Motion to Dismiss Filed, Witness Statement"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Detailed Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Provide a comprehensive summary of this event or document..."
              rows={4}
              required
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">Add Record to File</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
