'use client'

import React from "react"
import { useState } from 'react'
import { useCaseHistory, useCases, useUsers } from '@/lib/data-store'
import type { CaseHistory } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Plus,
  Search,
  FileText,
  Scale,
  Scroll,
  Briefcase,
  History,
  FileCheck,
  StickyNote,
  User,
} from 'lucide-react'
import Link from 'next/link'
import { CaseHistoryFormDialog } from './case-history-form-dialog'

type TypeFilter = CaseHistory['type'] | 'all'

const recordTypeIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  filing: Scroll,
  evidence: FileCheck,
  judgment: Scale,
  mediation: Briefcase,
  hearing: Scale,
  note: StickyNote,
}

const recordTypeLabels: Record<string, string> = {
  filing: 'Legal Filing',
  evidence: 'Evidence',
  judgment: 'Judgment',
  mediation: 'Mediation',
  hearing: 'Hearing',
  note: 'Case Note',
}

export function CaseHistoryContent() {
  const { history, isLoading } = useCaseHistory()
  const { cases } = useCases()
  const { users } = useUsers()
  const [searchQuery, setSearchQuery] = useState('')
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('all')
  const [dialogOpen, setDialogOpen] = useState(false)

  const getCaseName = (caseId: string) => cases.find((c) => c.id === caseId)?.name || 'Unknown Case'
  const getLawyerName = (lawyerId: string) => users.find((u) => u.id === lawyerId)?.name || 'Unknown Lawyer'

  const filteredRecords = history
    .filter((record: CaseHistory) => {
      const lawyerName = getLawyerName(record.lawyerId)
      const matchesSearch =
        record.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        record.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        getCaseName(record.caseId).toLowerCase().includes(searchQuery.toLowerCase()) ||
        lawyerName.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesType = typeFilter === 'all' || record.type === typeFilter
      return matchesSearch && matchesType
    })
    .sort((a, b) => b.date.localeCompare(a.date))

  const typeOptions: { value: TypeFilter; label: string }[] = [
    { value: 'all', label: 'All Record Types' },
    { value: 'filing', label: 'Filings' },
    { value: 'evidence', label: 'Evidence' },
    { value: 'judgment', label: 'Judgments' },
    { value: 'mediation', label: 'Mediation' },
    { value: 'hearing', label: 'Hearings' },
    { value: 'note', label: 'Notes' },
  ]

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-pulse text-muted-foreground">Retrieving case history...</div>
      </div>
    )
  }

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Case History & Filings</h1>
          <p className="text-muted-foreground">Comprehensive record of all legal actions and outcomes</p>
        </div>
        <Button onClick={() => setDialogOpen(true)}>
          <Plus className="size-4 mr-2" />
          Add Case Record
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-4">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <CardTitle>Master Case Records</CardTitle>
              <CardDescription>{filteredRecords.length} historical entries on file</CardDescription>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search history and filings..."
                value={searchQuery}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
                className="pl-9 w-full sm:w-80"
              />
            </div>
          </div>
          <div className="flex gap-1 flex-wrap mt-2">
            {typeOptions.map((option) => (
              <button
                key={option.value}
                type="button"
                onClick={() => setTypeFilter(option.value === typeFilter ? 'all' : option.value)}
                className={`px-3 py-1.5 text-sm rounded-full transition-colors ${typeFilter === option.value
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
                  }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </CardHeader>
        <CardContent>
          {filteredRecords.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <History className="size-12 text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-medium">No records found</h3>
              <p className="text-muted-foreground">
                {searchQuery || typeFilter !== 'all'
                  ? 'No results match your current filters'
                  : 'Start building a case history by adding records'}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredRecords.map((record: CaseHistory) => {
                const Icon = recordTypeIcons[record.type] || FileText
                return (
                  <div key={record.id} className="flex gap-4 rounded-lg border p-4 hover:bg-muted/30 transition-colors">
                    <div className="flex size-12 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                      <Icon className="size-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                        <div>
                          <h3 className="font-semibold text-lg">{record.title}</h3>
                          <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground mt-1">
                            <Link
                              href={`/cases/${record.caseId}`}
                              className="font-medium text-primary hover:underline flex items-center gap-1"
                            >
                              <Briefcase className="size-3" />
                              {getCaseName(record.caseId)}
                            </Link>
                            <span className="flex items-center gap-1">
                              <User className="size-3" />
                              {getLawyerName(record.lawyerId)}
                            </span>
                            <span className="flex items-center gap-1">
                              <FileText className="size-3" />
                              {new Date(record.date).toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: 'short',
                                day: 'numeric',
                              })}
                            </span>
                          </div>
                        </div>
                        <Badge variant="outline" className="capitalize">
                          {recordTypeLabels[record.type]}
                        </Badge>
                      </div>
                      <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                        {record.description}
                      </p>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <CaseHistoryFormDialog open={dialogOpen} onOpenChange={setDialogOpen} />
    </div>
  )
}
