'use client'

import { BuildingIcon } from 'lucide-react'
import { useTenant } from '@/lib/tenant-context'
import { useLanguage } from '@/lib/language-context'

export function TenantSwitcher() {
    const { currentTenant } = useTenant()
    const { language } = useLanguage()

    return (
        <div className="flex items-center gap-2 p-2 w-full">
            <div className="flex size-8 items-center justify-center rounded-lg bg-primary/10 shrink-0 border border-primary/20">
                <BuildingIcon className="size-5 text-primary" />
            </div>
            <div className="flex flex-col items-start leading-tight truncate flex-1">
                <span className="text-sm font-bold truncate w-full text-start">{currentTenant.brandName || currentTenant.name}</span>
                <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">{currentTenant.plan} Plan</span>
            </div>
        </div>
    )
}

function Plus(props: any) {
    return (
        <svg
            {...props}
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
        >
            <path d="M5 12h14" />
            <path d="M12 5v14" />
        </svg>
    )
}
