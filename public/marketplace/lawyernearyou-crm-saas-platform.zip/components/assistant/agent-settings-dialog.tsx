'use client'

import React from "react"

import { useState, useEffect } from 'react'
import { useAgentSettings, updateAgentSettings } from '@/lib/data-store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Slider } from '@/components/ui/slider'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Bot, Thermometer, FileText, Cpu } from 'lucide-react'

interface AgentSettingsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const modelOptions = [
  { value: 'anthropic/claude-opus-4.5', label: 'Claude Opus 4.5', provider: 'Anthropic', recommended: true },
  { value: 'anthropic/claude-sonnet-4', label: 'Claude Sonnet 4', provider: 'Anthropic' },
  { value: 'anthropic/claude-3-5-haiku', label: 'Claude 3.5 Haiku', provider: 'Anthropic' },
  { value: 'openai/gpt-4o', label: 'GPT-4o', provider: 'OpenAI' },
  { value: 'openai/gpt-4o-mini', label: 'GPT-4o Mini', provider: 'OpenAI' },
  { value: 'xai/grok-3', label: 'Grok 3', provider: 'xAI' },
]

export function AgentSettingsDialog({ open, onOpenChange }: AgentSettingsDialogProps) {
  const { settings } = useAgentSettings()

  const [formData, setFormData] = useState({
    model: settings?.model || 'anthropic/claude-opus-4.5',
    temperature: settings?.temperature ?? 0.7,
    systemPrompt: settings?.systemPrompt || '',
  })

  useEffect(() => {
    if (settings) {
      setFormData({
        model: settings.model,
        temperature: settings.temperature,
        systemPrompt: settings.systemPrompt,
      })
    }
  }, [settings, open])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    updateAgentSettings(formData)
    onOpenChange(false)
  }

  const handleReset = () => {
    const defaultSettings = {
      model: 'anthropic/claude-opus-4.5',
      temperature: 0.7,
      systemPrompt: `You are a helpful legal assistant for LawCRM. You help staff with:
- Looking up case and client information
- Scheduling consultations
- Answering common legal process questions
- Providing reminders about deadlines and filings

Always be professional, precise, and objective in your responses.`,
    }
    setFormData(defaultSettings)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto backdrop-blur-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Bot className="size-5" />
            Legal AI Assistant Configuration
          </DialogTitle>
          <DialogDescription>
            Fine-tune the behavior and domain knowledge of your legal AI research partner.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Cpu className="size-4" />
                Intelligence Model
              </CardTitle>
              <CardDescription>Select the underlying LLM powering your assistant</CardDescription>
            </CardHeader>
            <CardContent>
              <Select
                value={formData.model}
                onValueChange={(value) => setFormData({ ...formData, model: value })}
              >
                <SelectTrigger className="h-11">
                  <SelectValue placeholder="Select model" />
                </SelectTrigger>
                <SelectContent>
                  {modelOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{option.label}</span>
                        <Badge variant="outline" className="text-[10px] h-5">
                          {option.provider}
                        </Badge>
                        {option.recommended && (
                          <Badge variant="default" className="text-[10px] h-5">
                            Recommended
                          </Badge>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Thermometer className="size-4" />
                Response Precision (Temperature)
              </CardTitle>
              <CardDescription>
                Controls randomness. Lower values are more factual and concise, higher values are more expressive.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Precise</span>
                <span className="text-sm font-bold bg-primary/10 text-primary px-2 py-1 rounded">{formData.temperature.toFixed(1)}</span>
                <span className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Creative</span>
              </div>
              <Slider
                value={[formData.temperature]}
                onValueChange={([value]) => setFormData({ ...formData, temperature: value })}
                min={0}
                max={1}
                step={0.1}
                className="w-full"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <FileText className="size-4" />
                Executive System Instructions
              </CardTitle>
              <CardDescription>
                Direct the AI&apos;s persona, ethics, and specific firm-wide instructions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                value={formData.systemPrompt}
                onChange={(e) => setFormData({ ...formData, systemPrompt: e.target.value })}
                placeholder="Enter system prompt..."
                rows={8}
                className="font-mono text-xs leading-relaxed"
              />
            </CardContent>
          </Card>

          <Separator />

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Firm Intelligence Access</CardTitle>
              <CardDescription>
                Capabilities currently available to the assistant
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary" className="rounded-full">Read Case Data</Badge>
                <Badge variant="secondary" className="rounded-full">Read Client Files</Badge>
                <Badge variant="secondary" className="rounded-full">Legal Process Q&A</Badge>
                <Badge variant="secondary" className="rounded-full">Draft Templates</Badge>
                <Badge variant="outline" className="rounded-full border-dashed">Schedule Hearings (soon)</Badge>
                <Badge variant="outline" className="rounded-full border-dashed">Auto-filing (soon)</Badge>
              </div>
            </CardContent>
          </Card>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button type="button" variant="ghost" onClick={handleReset}>
              Restore LawCRM Defaults
            </Button>
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit">Deploy Settings</Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
