'use client'

import React from "react"
import { useRef, useEffect, useState } from 'react'
import { useChat } from '@ai-sdk/react'
import { DefaultChatTransport } from 'ai'
import { useAgentSettings, useCases, useClients, useConsultations } from '@/lib/data-store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { ScrollArea } from '@/components/ui/scroll-area'
import { MessageSquare, Send, Bot, User, Settings, Loader2, Briefcase } from 'lucide-react'
import { AgentSettingsDialog } from './agent-settings-dialog'
import { cn } from '@/lib/utils'
import ReactMarkdown from 'react-markdown'
import { useLanguage } from '@/lib/language-context'
import { useTenant } from '@/lib/tenant-context'

export function AssistantContent() {
  const { language } = useLanguage()
  const { currentTenant } = useTenant()
  const { settings } = useAgentSettings()
  const { cases } = useCases()
  const { clients } = useClients()
  const { consultations } = useConsultations()
  const [settingsOpen, setSettingsOpen] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  // Build context about the law firm data
  const lawFirmContext = `
Current law firm data summary:
- Total active cases: ${cases.length}
- Total clients: ${clients.length}
- Total consultations: ${consultations.length}
- Today's date: ${new Date().toLocaleDateString()}

Recent cases: ${cases.slice(0, 3).map((c) => `${c.name} (${c.caseType})`).join(', ')}
Recent clients: ${clients.slice(0, 3).map((o) => `${o.firstName} ${o.lastName}`).join(', ')}
`

  const { messages, sendMessage, status, setMessages } = useChat({
    transport: new DefaultChatTransport({
      api: '/api/chat',
      body: {
        model: settings?.model || 'gpt-4o',
        temperature: settings?.temperature ?? 0.7,
        systemPrompt: (settings?.systemPrompt || 'You are a legal assistant.') + '\n\n' + lawFirmContext,
      },
    }),
  })

  // Mock input state for the UI since this version of useChat might not provide it
  const [input, setInput] = useState('')

  const isLoading = status === 'streaming' || status === 'submitted'

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  const clearChat = () => {
    setMessages([])
  }

  if (currentTenant.plan === 'Starter') {
    return (
      <div className="flex flex-col h-full items-center justify-center p-4 md:p-8 bg-muted/10 text-center">
        <div className="bg-primary/10 p-6 rounded-full mb-6">
          <Bot className="size-16 text-primary" />
        </div>
        <h2 className="text-2xl font-bold mb-3">{language === 'ar' ? 'ميزة الذكاء الاصطناعي للمحامين' : 'AI Legal Assistant'}</h2>
        <p className="text-muted-foreground text-center max-w-md mb-8">
          {language === 'ar' ? 'قم بترقية باقتك إلى Pro أو Enterprise للوصول إلى المساعد القانوني الذكي وبحث القضايا.' : 'Upgrade your plan to Pro or Enterprise to access the AI Legal Assistant and automated case summarization.'}
        </p>
        <Button size="lg">{language === 'ar' ? 'ترقية الباقة' : 'Upgrade Plan'}</Button>
      </div>
    )
  }

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return
    sendMessage({ text: input })
    setInput('')
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      if (!input.trim() || isLoading) return
      sendMessage({ text: input })
      setInput('')
    }
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] min-h-0">
      <Card className="flex-1 flex flex-col p-0 gap-0 min-h-0 overflow-hidden border-none shadow-none md:border md:shadow-sm bg-transparent">
        <CardHeader className="border-b py-2 md:py-3 px-3 md:px-6 shadow-sm pb-2! md:pb-3! space-y-0 m-0">
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm md:text-base min-w-0">
              <Bot className="size-4 md:size-5 text-primary shrink-0" />
              <div className="flex flex-col">
                <span className="truncate font-bold">Legal Research AI</span>
                <span className="text-[10px] md:text-xs text-muted-foreground font-normal truncate">
                  {settings?.model || 'gpt-4o'}
                </span>
              </div>
            </div>
            <div className="flex gap-1 shrink-0">
              <Button variant="ghost" size="icon" className="size-8" onClick={clearChat} disabled={messages.length === 0}>
                <MessageSquare className="size-4" />
                <span className="sr-only">Clear Chat</span>
              </Button>
              <Button variant="ghost" size="icon" className="size-8" onClick={() => setSettingsOpen(true)}>
                <Settings className="size-4" />
                <span className="sr-only">Settings</span>
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col p-0 min-h-0 overflow-hidden bg-background md:bg-muted/5">
          <ScrollArea className="flex-1 min-h-0" ref={scrollRef}>
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center py-8 px-4">
                <div className="bg-primary/10 p-4 rounded-full mb-4">
                  <Briefcase className="size-10 md:size-12 text-primary/70" />
                </div>
                <h3 className="text-base md:text-lg font-bold">Unified Legal Intelligence</h3>
                <p className="text-sm text-muted-foreground max-w-sm mt-2 leading-relaxed">
                  I can analyze discovery, retrieve case history, summarize filings, and assist with document drafting.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-6 md:mt-10 w-full max-w-2xl">
                  {[
                    "Summary of active criminal cases",
                    "Recent filings for client records",
                    "Analyze case load for this month",
                    "Drafting templates for summons",
                  ].map((suggestion) => (
                    <Button
                      key={suggestion}
                      variant="outline"
                      size="sm"
                      className="text-xs md:text-sm bg-background hover:bg-primary/5 hover:border-primary/40 hover:text-primary justify-start h-auto py-3 px-4 text-left whitespace-normal leading-tight"
                      onClick={() => setInput(suggestion)}
                    >
                      {suggestion}
                    </Button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4 md:space-y-6 max-w-4xl mx-auto p-4 md:p-6">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={cn(
                      'flex gap-2 md:gap-4',
                      message.role === 'user' ? 'justify-end' : 'justify-start'
                    )}
                  >
                    {message.role === 'assistant' && (
                      <div className="flex size-8 md:size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary border border-primary/20">
                        <Bot className="size-5 md:size-6" />
                      </div>
                    )}
                    <div
                      className={cn(
                        'rounded-2xl px-4 py-3 md:px-5 max-w-[90%] md:max-w-[80%] shadow-sm',
                        message.role === 'user'
                          ? 'bg-primary text-primary-foreground rounded-tr-none'
                          : 'bg-background border rounded-tl-none'
                      )}
                    >
                      {message.role === 'user' ? (
                        <p className="text-sm md:text-base whitespace-pre-wrap wrap-break-word">
                          {message.parts
                            .filter((p) => p.type === 'text')
                            .map((p) => (p as any).text)
                            .join('')}
                        </p>
                      ) : (
                        <div className="text-sm md:text-base prose prose-slate dark:prose-invert max-w-none prose-p:my-2 prose-ul:my-2 prose-ol:my-2 prose-li:my-1 prose-headings:font-bold prose-headings:text-foreground prose-pre:bg-muted/50 prose-pre:rounded-xl">
                          <ReactMarkdown>
                            {message.parts
                              .filter((p) => p.type === 'text')
                              .map((p) => (p as any).text)
                              .join('')}
                          </ReactMarkdown>
                        </div>
                      )}
                    </div>
                    {message.role === 'user' && (
                      <div className="flex size-8 md:size-10 shrink-0 items-center justify-center rounded-lg bg-secondary text-secondary-foreground border">
                        <User className="size-5 md:size-6" />
                      </div>
                    )}
                  </div>
                ))}
                {isLoading && (
                  <div className="flex gap-2 md:gap-4">
                    <div className="flex size-8 md:size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary border border-primary/20">
                      <Bot className="size-5 md:size-6" />
                    </div>
                    <div className="rounded-2xl px-4 py-3 bg-background border rounded-tl-none flex items-center gap-2">
                      <Loader2 className="size-4 animate-spin text-primary" />
                      <span className="text-sm text-muted-foreground font-medium italic">Synthesizing legal data...</span>
                    </div>
                  </div>
                )}
              </div>
            )}
          </ScrollArea>

          <form
            onSubmit={handleSubmit}
            className="border-t bg-background p-3 md:p-4 shrink-0"
          >
            <div className="relative max-w-4xl mx-auto flex items-end gap-2 bg-background md:bg-muted/30 rounded-2xl border-2 border-primary/20 p-2 focus-within:ring-4 focus-within:ring-primary/10 focus-within:border-primary/40 transition-all shadow-sm">
              <Textarea
                value={input}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about cases, filings, or draft document templates..."
                className="flex-1 min-h-[44px] max-h-32 md:max-h-48 resize-none bg-transparent border-0 focus-visible:ring-0 text-sm md:text-base py-2.5 px-3"
                rows={1}
                disabled={isLoading}
              />
              <Button
                type="submit"
                size="icon"
                className="h-10 w-10 shrink-0 rounded-xl"
                disabled={isLoading || !input.trim()}
              >
                <Send className="size-4 md:size-5" />
                <span className="sr-only">Send message</span>
              </Button>
            </div>
            <p className="text-[10px] text-center text-muted-foreground mt-3 uppercase tracking-widest font-bold">
              AI-generated responses should be verified with official legal counsel.
            </p>
          </form>
        </CardContent>
      </Card>

      <AgentSettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />
    </div>
  )
}
