'use client'

import { useCases, useInvoices, useUsers } from '@/lib/data-store'
import { useLanguage } from '@/lib/language-context'
import {
    BarChart3,
    TrendingUp,
    TrendingDown,
    Target,
    Users,
    Briefcase,
    PieChart as PieChartIcon,
    Download
} from 'lucide-react'
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
    LineChart,
    Line,
    PieChart,
    Pie,
    Cell,
} from 'recharts'

export function AnalyticsContent() {
    const { cases } = useCases()
    const { invoices } = useInvoices()
    const { users } = useUsers()
    const { t, language } = useLanguage()

    // Calculate stats
    const totalRevenue = invoices
        .filter(inv => inv.status === 'paid' || inv.status === 'partially-paid')
        .reduce((acc, inv) => acc + inv.totalAmount, 0)

    const pendingRevenue = invoices
        .filter(inv => inv.status === 'sent' || inv.status === 'overdue')
        .reduce((acc, inv) => acc + inv.totalAmount, 0)

    // Case Status Data
    const caseStatusDistribution = cases.reduce((acc, c) => {
        acc[c.status] = (acc[c.status] || 0) + 1
        return acc
    }, {} as Record<string, number>)

    const pieData = Object.keys(caseStatusDistribution).map(key => ({
        name: language === 'ar' ? (
            key === 'active' ? 'نشط' :
                key === 'closed' ? 'مغلق' :
                    key === 'pending' ? 'معلق' : 'قيد الانتظار'
        ) : key.charAt(0).toUpperCase() + key.slice(1),
        value: caseStatusDistribution[key]
    }))

    const COLORS = ['#0ea5e9', '#10b981', '#f59e0b', '#ef4444']

    // Lawyer Workload Data
    const lawyerWorkload = users.filter(u => u.role === 'lawyer').map(lawyer => ({
        name: lawyer.name,
        count: cases.filter(c => c.assignedLawyerId === lawyer.id).length
    })).slice(0, 5)

    // Monthly Revenue Data (Mocked with real total)
    const revenueTrend = [
        { month: language === 'ar' ? 'يناير' : 'Jan', revenue: 15400, cases: 12 },
        { month: language === 'ar' ? 'فبراير' : 'Feb', revenue: 18200, cases: 15 },
        { month: language === 'ar' ? 'مارس' : 'Mar', revenue: 26000, cases: 22 },
        { month: language === 'ar' ? 'أبريل' : 'Apr', revenue: 22000, cases: 18 },
        { month: language === 'ar' ? 'مايو' : 'May', revenue: totalRevenue > 0 ? totalRevenue : 32000, cases: 25 },
    ]

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                    <h2 className="text-2xl font-bold tracking-tight text-start">
                        {language === 'ar' ? 'التحليلات والتقارير' : 'Analytics & Reports'}
                    </h2>
                    <p className="text-muted-foreground text-start">
                        {language === 'ar'
                            ? 'نظرة شاملة على أداء المكتب، القضايا، والموارد المالية.'
                            : 'Comprehensive overview of firm performance, cases, and finances.'}
                    </p>
                </div>
                <Button variant="outline" className="gap-2">
                    <Download className="size-4" />
                    {language === 'ar' ? 'تصدير التقرير السنوي' : 'Export Annual Report'}
                </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">
                            {language === 'ar' ? 'إجمالي المحصل' : 'Total Collected'}
                        </CardTitle>
                        <TrendingUp className="h-4 w-4 text-green-500" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">EGP {totalRevenue.toLocaleString()}</div>
                        <p className="text-xs text-muted-foreground text-start mt-1">+12.5% {language === 'ar' ? 'من الشهر الماضي' : 'from last month'}</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">
                            {language === 'ar' ? 'مستحقات متأخرة' : 'Pending Revenue'}
                        </CardTitle>
                        <TrendingDown className="h-4 w-4 text-orange-500" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">EGP {pendingRevenue.toLocaleString()}</div>
                        <p className="text-xs text-muted-foreground text-start mt-1">4 {language === 'ar' ? 'فواتير قيد الانتظار' : 'pending invoices'}</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">
                            {language === 'ar' ? 'معدل النجاح' : 'Success Rate'}
                        </CardTitle>
                        <Target className="h-4 w-4 text-blue-500" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">84%</div>
                        <p className="text-xs text-muted-foreground text-start mt-1">{language === 'ar' ? 'بناءً على القضايا المنتهية' : 'based on closed cases'}</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">
                            {language === 'ar' ? 'القضايا النشطة' : 'Active Cases'}
                        </CardTitle>
                        <Briefcase className="h-4 w-4 text-primary" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{cases.filter(c => c.status === 'active').length}</div>
                        <p className="text-xs text-muted-foreground text-start mt-1">+2 {language === 'ar' ? 'قضايا هذا الأسبوع' : 'new cases this week'}</p>
                    </CardContent>
                </Card>
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <BarChart3 className="size-5 text-primary" />
                            {language === 'ar' ? 'اتجاهات الإيرادات والقضايا' : 'Revenue & Case Trends'}
                        </CardTitle>
                        <CardDescription className="text-start">
                            {language === 'ar' ? 'مقارنة بين الدخل الشهري وعدد القضايا المفتوحة.' : 'Comparison between monthly income and open cases.'}
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="h-[300px] w-full">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={revenueTrend}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                    <XAxis dataKey="month" />
                                    <YAxis yAxisId="left" orientation={language === 'ar' ? 'right' : 'left'} />
                                    <YAxis yAxisId="right" orientation={language === 'ar' ? 'left' : 'right'} />
                                    <Tooltip />
                                    <Bar yAxisId="left" dataKey="revenue" fill="#0ea5e9" radius={[4, 4, 0, 0]} name={language === 'ar' ? 'الإيرادات' : 'Revenue'} />
                                    <Bar yAxisId="right" dataKey="cases" fill="#10b981" radius={[4, 4, 0, 0]} name={language === 'ar' ? 'القضايا' : 'Cases'} />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </CardContent>
                </Card>

                <div className="grid gap-6">
                    <Card>
                        <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium flex items-center gap-2">
                                <PieChartIcon className="size-4 text-primary" />
                                {language === 'ar' ? 'توزيع حالات القضايا' : 'Case Status Distribution'}
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="flex items-center justify-between pb-2">
                            <div className="h-[180px] w-[200px]">
                                <ResponsiveContainer width="100%" height="100%">
                                    <PieChart>
                                        <Pie
                                            data={pieData}
                                            cx="50%"
                                            cy="50%"
                                            innerRadius={60}
                                            outerRadius={80}
                                            paddingAngle={5}
                                            dataKey="value"
                                        >
                                            {pieData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                            ))}
                                        </Pie>
                                        <Tooltip />
                                    </PieChart>
                                </ResponsiveContainer>
                            </div>
                            <div className="space-y-1 flex-1 px-4">
                                {pieData.map((entry, index) => (
                                    <div key={entry.name} className="flex items-center justify-between text-sm">
                                        <div className="flex items-center gap-2">
                                            <div className="size-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                                            <span>{entry.name}</span>
                                        </div>
                                        <span className="font-semibold">{entry.value}</span>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-medium flex items-center gap-2">
                                <Users className="size-4 text-primary" />
                                {language === 'ar' ? 'توزيع عبء العمل (أعلى 5 محامين)' : 'Workload Distribution (Top 5 Lawyers)'}
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="h-[120px] w-full">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={lawyerWorkload} layout="vertical">
                                        <XAxis type="number" hide />
                                        <YAxis dataKey="name" type="category" width={100} fontSize={12} orientation={language === 'ar' ? 'right' : 'left'} />
                                        <Tooltip />
                                        <Bar dataKey="count" fill="#8b5cf6" radius={[0, 4, 4, 0]} name={language === 'ar' ? 'القضايا' : 'Cases'} />
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    )
}
