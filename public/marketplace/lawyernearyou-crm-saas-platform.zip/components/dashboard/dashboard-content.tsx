'use client'

import { useCases, useClients, useConsultations, useInvoices } from '@/lib/data-store'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Briefcase, Users, Gavel, Clock, CheckCircle, AlertCircle, Search, Plus, Scale, BarChart3, TrendingUp } from 'lucide-react'
import Link from 'next/link'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts'
import { useLanguage } from '@/lib/language-context'

export function DashboardContent() {
  const { cases } = useCases()
  const { clients } = useClients()
  const { consultations } = useConsultations()
  const { invoices } = useInvoices()
  const { t, language } = useLanguage()

  const today = new Date().toISOString().split('T')[0]
  const todayConsultations = consultations.filter((c) => c.date === today)
  const upcomingConsultations = consultations
    .filter((c) => c.date >= today && c.status !== 'completed' && c.status !== 'cancelled')
    .sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time))
    .slice(0, 5)

  const urgentCases = cases.filter(c => c.priority === 'urgent' || c.priority === 'high')

  const totalRevenue = invoices
    .filter((inv) => inv.status === 'paid' || inv.status === 'partially-paid')
    .reduce((acc, inv) => acc + inv.totalAmount, 0)

  const overdueInvoices = invoices.filter((inv) => inv.status === 'overdue').length

  const stats = [
    {
      title: t('dash.activeCases'),
      value: cases.filter(c => c.status === 'active').length,
      icon: Briefcase,
      href: '/cases',
    },
    {
      title: t('dash.totalRevenue'),
      value: `EGP ${totalRevenue.toLocaleString()}`,
      icon: Scale,
      href: '/billing',
    },
    {
      title: t('dash.overdueInvoices'),
      value: overdueInvoices,
      icon: AlertCircle,
      href: '/billing',
      color: overdueInvoices > 0 ? 'text-destructive' : 'text-muted-foreground',
    },
    {
      title: t('dash.todayAppointments'),
      value: todayConsultations.length,
      icon: Clock,
      href: '/consultations',
    },
  ]

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: 'default' | 'secondary' | 'destructive' | 'outline'; label: string }> = {
      scheduled: { variant: 'secondary', label: t('status.scheduled') },
      confirmed: { variant: 'default', label: t('status.confirmed') },
      'in-progress': { variant: 'outline', label: t('status.in-progress') },
      completed: { variant: 'secondary', label: t('status.completed') },
      cancelled: { variant: 'destructive', label: t('status.cancelled') },
    }
    const config = variants[status] || { variant: 'secondary' as const, label: status }
    return <Badge variant={config.variant}>{config.label}</Badge>
  }

  const getConsultationTypeBadge = (type: string) => {
    const labels: Record<string, string> = {
      initial: t('type.initial'),
      'follow-up': t('type.follow-up'),
      strategy: t('type.strategy'),
      'court-prep': t('type.court-prep'),
      emergency: t('type.emergency'),
      mediation: t('type.mediation'),
    }
    return <Badge variant="outline">{labels[type] || type}</Badge>
  }

  const getCaseById = (caseId: string) => cases.find((c) => c.id === caseId)
  const getClientById = (clientId: string) => clients.find((c) => c.id === clientId)

  const caseTypeDistribution = cases.reduce((acc, c) => {
    acc[c.caseType] = (acc[c.caseType] || 0) + 1
    return acc
  }, {} as Record<string, number>)

  const caseChartData = Object.keys(caseTypeDistribution).map(key => ({
    name: key.charAt(0).toUpperCase() + key.slice(1),
    count: caseTypeDistribution[key]
  }))

  const incomeTrendData = [
    { name: language === 'ar' ? 'نوفمبر' : 'Nov', revenue: 15400 },
    { name: language === 'ar' ? 'ديسمبر' : 'Dec', revenue: 18200 },
    { name: language === 'ar' ? 'يناير' : 'Jan', revenue: 26000 },
    { name: language === 'ar' ? 'فبراير' : 'Feb', revenue: 22000 },
    { name: language === 'ar' ? 'مارس' : 'Mar', revenue: Math.max(28000, totalRevenue) },
  ]

  return (
    <div className="p-3 md:p-6 space-y-4 md:space-y-6">
      {/* Quick Actions - Mobile First */}
      <div className="grid grid-cols-4 gap-2 md:hidden">
        {stats.map((stat) => (
          <Link key={stat.title} href={stat.href}>
            <div className="flex flex-col items-center gap-1 p-3 rounded-xl bg-card border transition-colors active:bg-muted">
              <div className="flex size-10 items-center justify-center rounded-full bg-primary/10">
                <stat.icon className="size-5 text-primary" />
              </div>
              <span className="text-xs font-medium text-center">{stat.title}</span>
              <span className="text-lg font-bold">{stat.value}</span>
            </div>
          </Link>
        ))}
      </div>

      {/* Quick Action Buttons - Mobile */}
      <div className="flex gap-2 md:hidden">
        <Button asChild className="flex-1 h-12">
          <Link href="/consultations">
            <Plus className={`size-4 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
            {t('dash.newConsultation')}
          </Link>
        </Button>
        <Button asChild variant="secondary" className="flex-1 h-12">
          <Link href="/assistant">
            <Search className={`size-4 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
            {t('dash.smartSearch')}
          </Link>
        </Button>
      </div>

      {/* Urgent Alerts Section */}
      {urgentCases.length > 0 && (
        <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-destructive text-destructive-foreground p-2 rounded-full">
              <AlertCircle className="size-5" />
            </div>
            <div>
              <p className="font-bold text-destructive">{t('dash.urgentAlert')}</p>
              <p className="text-sm text-destructive/80">
                {t('dash.urgentDesc').replace('{count}', urgentCases.length.toString())}
              </p>
            </div>
          </div>
          <Button variant="destructive" size="sm" asChild>
            <Link href="/cases?priority=urgent">{t('dash.viewUrgent')}</Link>
          </Button>
        </div>
      )}

      {/* Desktop Header */}
      <div className="hidden md:block">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-balance italic">LawCRM Enterprise</h1>
            <p className="text-muted-foreground">{t('dash.welcome')}</p>
          </div>
          <div className="flex gap-2">
            <Button asChild>
              <Link href="/consultations">
                <Plus className={`size-4 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
                {t('dash.newConsultation')}
              </Link>
            </Button>
            <Button asChild variant="outline" className="bg-transparent">
              <Link href="/assistant">
                <Search className={`size-4 ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
                {t('dash.smartSearch')}
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Desktop Stats */}
      <div className="hidden md:grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Link key={stat.title} href={stat.href}>
            <Card className="transition-colors hover:bg-muted/50 cursor-pointer">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <stat.icon className="size-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid gap-4 md:gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base md:text-lg">
              <BarChart3 className="size-4 md:size-5 text-primary" />
              {t('dash.caseDistribution')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={caseChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip cursor={{ fill: 'transparent' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base md:text-lg">
              <TrendingUp className="size-4 md:size-5 text-primary" />
              {t('dash.incomeTrends')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={incomeTrendData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value / 1000}k`} />
                  <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                  <Line type="monotone" dataKey="revenue" stroke="hsl(var(--primary))" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base md:text-lg">
                <Gavel className="size-4 md:size-5 text-primary" />
                {t('dash.upcoming')}
              </CardTitle>
              <Button asChild variant="ghost" size="sm" className="text-xs">
                <Link href="/consultations">{language === 'ar' ? 'عرض الكل' : 'View All'}</Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            {upcomingConsultations.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-6 text-center">
                <CheckCircle className="size-10 text-muted-foreground/50 mb-2" />
                <p className="text-sm text-muted-foreground">All clear for now</p>
              </div>
            ) : (
              <div className="space-y-2">
                {upcomingConsultations.slice(0, 4).map((consultation) => {
                  const legalCase = getCaseById(consultation.caseId)
                  return (
                    <Link
                      key={consultation.id}
                      href="/consultations"
                      className="flex items-center justify-between gap-3 rounded-lg border p-2.5 transition-colors hover:bg-muted/50 active:bg-muted"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="flex size-9 items-center justify-center rounded-full bg-primary/10 shrink-0">
                          <Briefcase className="size-4 text-primary" />
                        </div>
                        <div className="min-w-0">
                          <p className="font-medium text-sm truncate">{legalCase?.name || 'Unknown Case'}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(consultation.date).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', {
                              weekday: 'short',
                              month: 'short',
                              day: 'numeric',
                            })}{' '}
                            {consultation.time}
                          </p>
                        </div>
                      </div>
                      <div className="shrink-0">
                        {getConsultationTypeBadge(consultation.type)}
                      </div>
                    </Link>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base md:text-lg">
                <Scale className="size-4 md:size-5 text-primary" />
                {language === 'ar' ? 'آخر القضايا' : 'Recent Cases'}
              </CardTitle>
              <Button asChild variant="ghost" size="sm" className="text-xs">
                <Link href="/cases">{language === 'ar' ? 'عرض الكل' : 'View All'}</Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            {cases.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-6 text-center">
                <AlertCircle className="size-10 text-muted-foreground/50 mb-2" />
                <p className="text-sm text-muted-foreground">No cases yet</p>
              </div>
            ) : (
              <div className="space-y-2">
                {cases.slice(0, 4).map((legalCase) => {
                  const client = getClientById(legalCase.clientId)
                  return (
                    <Link
                      key={legalCase.id}
                      href={`/cases/${legalCase.id}`}
                      className="flex items-center gap-3 rounded-lg border p-2.5 transition-colors hover:bg-muted/50 active:bg-muted"
                    >
                      <div className="flex size-9 items-center justify-center rounded-full bg-primary/10 shrink-0">
                        <Briefcase className="size-4 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{legalCase.name}</p>
                        <p className="text-xs text-muted-foreground truncate">
                          {legalCase.category} - {client ? (language === 'ar' ? `${client.firstName} ${client.lastName}` : `${client.firstName} ${client.lastName[0]}.`) : (language === 'ar' ? 'عميل غير معروف' : 'Unknown Client')}
                        </p>
                      </div>
                      <Badge variant="outline" className="shrink-0 text-xs">
                        {legalCase.caseType}
                      </Badge>
                    </Link>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
