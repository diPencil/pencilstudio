'use client'

import React, { useState } from 'react'
import { Building2, Plus, MapPin, Phone, Users, Globe, Edit } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { useLanguage } from '@/lib/language-context'

interface Branch { id: number; name: string; city: string; address: string; phone: string; members: number; isHQ: boolean }

const initial: Branch[] = [
    { id: 1, name: 'Cairo HQ', city: 'Cairo', address: 'Downtown, Tahrir Square', phone: '+20 2 2345 6789', members: 8, isHQ: true },
    { id: 2, name: 'Alexandria Office', city: 'Alexandria', address: 'Corniche Road, Building 15', phone: '+20 3 4567 8901', members: 4, isHQ: false },
    { id: 3, name: 'Giza Branch', city: 'Giza', address: 'Mohandessin, Lebanon St.', phone: '+20 2 3456 7890', members: 3, isHQ: false },
]

export function BranchesContent() {
    const { language } = useLanguage()
    const [branches, setBranches] = useState<Branch[]>(initial)
    const [open, setOpen] = useState(false)
    const [form, setForm] = useState({ name: '', city: '', address: '', phone: '' })
    const [feedback, setFeedback] = useState<string | null>(null)
    const show = (m: string) => { setFeedback(m); setTimeout(() => setFeedback(null), 2500) }

    const add = () => {
        if (!form.name || !form.city) return
        setBranches(p => [...p, { id: Date.now(), ...form, members: 0, isHQ: false }])
        setForm({ name: '', city: '', address: '', phone: '' }); setOpen(false)
        show(language === 'ar' ? '✅ تم إضافة الفرع' : '✅ Branch added')
    }

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300"><div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div></div>}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div><h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'الفروع' : 'Branches'}</h1><p className="text-muted-foreground">{language === 'ar' ? 'إدارة فروع المكتب في مختلف المدن.' : 'Manage firm offices across different cities.'}</p></div>
                <Dialog open={open} onOpenChange={setOpen}>
                    <DialogTrigger asChild><Button className="gap-2"><Plus className="size-4" />{language === 'ar' ? 'فرع جديد' : 'New Branch'}</Button></DialogTrigger>
                    <DialogContent>
                        <DialogHeader><DialogTitle>{language === 'ar' ? 'إضافة فرع' : 'Add Branch'}</DialogTitle><DialogDescription>{language === 'ar' ? 'أدخل بيانات الفرع الجديد.' : 'Enter branch details.'}</DialogDescription></DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid grid-cols-2 gap-4"><div className="grid gap-2"><Label>{language === 'ar' ? 'الاسم *' : 'Name *'}</Label><Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></div><div className="grid gap-2"><Label>{language === 'ar' ? 'المدينة *' : 'City *'}</Label><Input value={form.city} onChange={e => setForm(p => ({ ...p, city: e.target.value }))} /></div></div>
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'العنوان' : 'Address'}</Label><Input value={form.address} onChange={e => setForm(p => ({ ...p, address: e.target.value }))} /></div>
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'الهاتف' : 'Phone'}</Label><Input value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} /></div>
                        </div>
                        <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button><Button onClick={add} disabled={!form.name || !form.city}>{language === 'ar' ? 'إضافة' : 'Add'}</Button></DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
            <div className="grid gap-6 md:grid-cols-3">
                {branches.map(b => (
                    <Card key={b.id} className="border-none shadow-sm hover:shadow-md transition-all group">
                        <CardHeader>
                            <div className="flex items-start justify-between">
                                <div className="rounded-xl bg-primary/10 p-3 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors"><Building2 className="size-6" /></div>
                                {b.isHQ && <Badge className="text-[10px]">{language === 'ar' ? 'المقر الرئيسي' : 'HQ'}</Badge>}
                            </div>
                            <CardTitle className="text-lg mt-2">{b.name}</CardTitle>
                            <CardDescription className="flex items-center gap-1"><MapPin className="size-3" />{b.city}</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-2 text-sm text-muted-foreground">
                            {b.address && <p className="flex items-center gap-2"><Globe className="size-3.5 shrink-0" />{b.address}</p>}
                            {b.phone && <p className="flex items-center gap-2"><Phone className="size-3.5 shrink-0" />{b.phone}</p>}
                            <p className="flex items-center gap-2"><Users className="size-3.5" />{b.members} {language === 'ar' ? 'أعضاء' : 'members'}</p>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    )
}
