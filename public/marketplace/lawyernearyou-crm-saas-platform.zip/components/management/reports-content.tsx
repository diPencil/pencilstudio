'use client'

import React, { useState } from 'react'
import { BarChart3, Download, Calendar, TrendingUp, Users, Briefcase, DollarSign } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useLanguage } from '@/lib/language-context'

const reports = [
    { id: 'cases', title: { en: 'Cases Overview Report', ar: 'تقرير نظرة عامة على القضايا' }, desc: { en: 'Summary of all active, closed, and pending cases.', ar: 'ملخص لجميع القضايا النشطة والمغلقة والمعلقة.' }, icon: Briefcase, lastGenerated: '2024-03-01' },
    { id: 'revenue', title: { en: 'Revenue & Billing Report', ar: 'تقرير الإيرادات والفواتير' }, desc: { en: 'Financial overview including revenue, expenses, and outstanding invoices.', ar: 'نظرة مالية شاملة تشمل الإيرادات والمصروفات والفواتير المعلقة.' }, icon: DollarSign, lastGenerated: '2024-03-05' },
    { id: 'team', title: { en: 'Team Performance Report', ar: 'تقرير أداء الفريق' }, desc: { en: 'Lawyer workload, case assignments, and billable hours summary.', ar: 'حمل العمل وتوزيع القضايا وملخص الساعات للمحامين.' }, icon: Users, lastGenerated: '2024-02-28' },
    { id: 'clients', title: { en: 'Client Acquisition Report', ar: 'تقرير اكتساب العملاء' }, desc: { en: 'Lead sources, conversion rates, and client satisfaction metrics.', ar: 'مصادر العملاء المحتملين ومعدلات التحويل ومقاييس الرضا.' }, icon: TrendingUp, lastGenerated: '2024-03-03' },
]

export function ReportsContent() {
    const { language } = useLanguage()
    const [period, setPeriod] = useState('month')
    const [feedback, setFeedback] = useState<string | null>(null)
    const show = (m: string) => { setFeedback(m); setTimeout(() => setFeedback(null), 2500) }

    const download = (title: string) => show(language === 'ar' ? `📥 جاري تحميل "${title}"...` : `📥 Downloading "${title}"...`)

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300"><div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div></div>}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div><h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'التقارير' : 'Reports'}</h1><p className="text-muted-foreground">{language === 'ar' ? 'تقارير شاملة لأداء المكتب والفريق والمالية.' : 'Comprehensive reports for firm performance, team, and finances.'}</p></div>
                <Select value={period} onValueChange={setPeriod}>
                    <SelectTrigger className="w-[160px]"><Calendar className="size-4 mr-2 rtl:mr-0 rtl:ml-2" /><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="week">{language === 'ar' ? 'هذا الأسبوع' : 'This Week'}</SelectItem><SelectItem value="month">{language === 'ar' ? 'هذا الشهر' : 'This Month'}</SelectItem><SelectItem value="quarter">{language === 'ar' ? 'هذا الربع' : 'This Quarter'}</SelectItem><SelectItem value="year">{language === 'ar' ? 'هذه السنة' : 'This Year'}</SelectItem></SelectContent>
                </Select>
            </div>
            <div className="grid gap-6 md:grid-cols-2">
                {reports.map(r => (
                    <Card key={r.id} className="border-none shadow-sm hover:shadow-md transition-all group">
                        <CardHeader>
                            <div className="flex items-start justify-between">
                                <div className="rounded-xl bg-primary/10 p-3 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors"><r.icon className="size-6" /></div>
                                <Badge variant="outline" className="text-[10px]">{language === 'ar' ? `آخر إنشاء: ${r.lastGenerated}` : `Last: ${r.lastGenerated}`}</Badge>
                            </div>
                            <CardTitle className="text-lg mt-3">{r.title[language]}</CardTitle>
                            <CardDescription>{r.desc[language]}</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="flex gap-2">
                                <Button className="gap-2 flex-1" onClick={() => download(r.title[language])}><Download className="size-4" />{language === 'ar' ? 'تحميل PDF' : 'Download PDF'}</Button>
                                <Button variant="outline" className="gap-2" onClick={() => show(language === 'ar' ? '📊 جاري إنشاء التقرير...' : '📊 Generating report...')}><BarChart3 className="size-4" />{language === 'ar' ? 'عرض' : 'View'}</Button>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    )
}
