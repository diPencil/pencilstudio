'use client'

import React, { useState } from 'react'
import { Shield, Plus, Search, Edit, Trash2, Check, Users } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { useLanguage } from '@/lib/language-context'

interface Role { id: number; name: string; members: number; permissions: string[] }

const allPermissions = ['cases.view', 'cases.edit', 'cases.delete', 'clients.view', 'clients.edit', 'billing.view', 'billing.edit', 'team.manage', 'reports.view', 'settings.admin']
const permLabels: Record<string, Record<string, string>> = {
    'cases.view': { en: 'View Cases', ar: 'عرض القضايا' }, 'cases.edit': { en: 'Edit Cases', ar: 'تعديل القضايا' }, 'cases.delete': { en: 'Delete Cases', ar: 'حذف القضايا' },
    'clients.view': { en: 'View Clients', ar: 'عرض العملاء' }, 'clients.edit': { en: 'Edit Clients', ar: 'تعديل العملاء' },
    'billing.view': { en: 'View Billing', ar: 'عرض الفواتير' }, 'billing.edit': { en: 'Edit Billing', ar: 'تعديل الفواتير' },
    'team.manage': { en: 'Manage Team', ar: 'إدارة الفريق' }, 'reports.view': { en: 'View Reports', ar: 'عرض التقارير' }, 'settings.admin': { en: 'Admin Settings', ar: 'إعدادات المدير' },
}

const initial: Role[] = [
    { id: 1, name: 'Admin', members: 2, permissions: allPermissions },
    { id: 2, name: 'Senior Lawyer', members: 3, permissions: ['cases.view', 'cases.edit', 'clients.view', 'clients.edit', 'billing.view', 'reports.view'] },
    { id: 3, name: 'Junior Lawyer', members: 5, permissions: ['cases.view', 'clients.view'] },
    { id: 4, name: 'Accountant', members: 1, permissions: ['billing.view', 'billing.edit', 'reports.view'] },
]

export function RolesContent() {
    const { language } = useLanguage()
    const [roles, setRoles] = useState<Role[]>(initial)
    const [open, setOpen] = useState(false)
    const [form, setForm] = useState({ name: '', permissions: [] as string[] })
    const [editingId, setEditingId] = useState<number | null>(null)
    const [feedback, setFeedback] = useState<string | null>(null)
    const show = (m: string) => { setFeedback(m); setTimeout(() => setFeedback(null), 2500) }

    const togglePerm = (p: string) => setForm(f => ({ ...f, permissions: f.permissions.includes(p) ? f.permissions.filter(x => x !== p) : [...f.permissions, p] }))

    const save = () => {
        if (!form.name) return
        if (editingId) { setRoles(p => p.map(r => r.id === editingId ? { ...r, name: form.name, permissions: form.permissions } : r)); show(language === 'ar' ? '✅ تم التحديث' : '✅ Updated') }
        else { setRoles(p => [...p, { id: Date.now(), name: form.name, members: 0, permissions: form.permissions }]); show(language === 'ar' ? '✅ تم إنشاء الدور' : '✅ Role created') }
        setForm({ name: '', permissions: [] }); setEditingId(null); setOpen(false)
    }

    const edit = (r: Role) => { setForm({ name: r.name, permissions: r.permissions }); setEditingId(r.id); setOpen(true) }
    const del = (id: number) => { setRoles(p => p.filter(r => r.id !== id)); show(language === 'ar' ? '🗑️ تم حذف الدور' : '🗑️ Role deleted') }

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300"><div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div></div>}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div><h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'الأدوار والصلاحيات' : 'Roles & Permissions'}</h1><p className="text-muted-foreground">{language === 'ar' ? 'تحكم في صلاحيات كل مستخدم داخل النظام.' : 'Control user access and permissions within the system.'}</p></div>
                <Dialog open={open} onOpenChange={o => { setOpen(o); if (!o) { setEditingId(null); setForm({ name: '', permissions: [] }) } }}>
                    <DialogTrigger asChild><Button className="gap-2"><Plus className="size-4" />{language === 'ar' ? 'دور جديد' : 'New Role'}</Button></DialogTrigger>
                    <DialogContent className="max-w-lg">
                        <DialogHeader><DialogTitle>{editingId ? (language === 'ar' ? 'تعديل الدور' : 'Edit Role') : (language === 'ar' ? 'دور جديد' : 'New Role')}</DialogTitle><DialogDescription>{language === 'ar' ? 'حدد الاسم والصلاحيات.' : 'Set name and permissions.'}</DialogDescription></DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'اسم الدور *' : 'Role Name *'}</Label><Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></div>
                            <div className="grid gap-2"><Label>{language === 'ar' ? 'الصلاحيات' : 'Permissions'}</Label>
                                <div className="grid grid-cols-2 gap-2">{allPermissions.map(p => (
                                    <div key={p} className="flex items-center justify-between rounded-lg border p-2 text-xs"><span>{permLabels[p]?.[language] || p}</span><Switch checked={form.permissions.includes(p)} onCheckedChange={() => togglePerm(p)} /></div>
                                ))}</div>
                            </div>
                        </div>
                        <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button><Button onClick={save} disabled={!form.name}>{language === 'ar' ? 'حفظ' : 'Save'}</Button></DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
                {roles.map(r => (
                    <Card key={r.id} className="border-none shadow-sm hover:shadow-md transition-all">
                        <CardHeader className="pb-2">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3"><div className="rounded-full bg-primary/10 p-2"><Shield className="size-5 text-primary" /></div><div><CardTitle className="text-base">{r.name}</CardTitle><p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5"><Users className="size-3" />{r.members} {language === 'ar' ? 'أعضاء' : 'members'}</p></div></div>
                                <div className="flex gap-1"><Button variant="ghost" size="icon" className="size-7" onClick={() => edit(r)}><Edit className="size-3.5" /></Button>{r.name !== 'Admin' && <Button variant="ghost" size="icon" className="size-7 text-destructive hover:text-destructive" onClick={() => del(r.id)}><Trash2 className="size-3.5" /></Button>}</div>
                            </div>
                        </CardHeader>
                        <CardContent><div className="flex flex-wrap gap-1.5">{r.permissions.map(p => <Badge key={p} variant="secondary" className="text-[10px] gap-1"><Check className="size-2.5" />{permLabels[p]?.[language] || p}</Badge>)}</div></CardContent>
                    </Card>
                ))}
            </div>
        </div>
    )
}
