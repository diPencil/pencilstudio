'use client'

import React, { useState } from 'react'
import {
    BookOpen, Search, FileText, ChevronRight, Star, Download, Eye, Plus, ArrowRight, Upload, X
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import {
    Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import { useLanguage } from '@/lib/language-context'

interface Article {
    id: number
    title: string
    date: string
    views: number
    rating: number
    category: string
}

const categories = [
    { id: 'contracts', name: { ar: 'نماذج العقود', en: 'Contract Templates' }, count: 24, icon: FileText },
    { id: 'precedents', name: { ar: 'السوابق القضائية', en: 'Legal Precedents' }, count: 18, icon: BookOpen },
    { id: 'procedures', name: { ar: 'إجراءات المكتب', en: 'Internal Procedures' }, count: 12, icon: FileText },
]

const initialArticles: Article[] = [
    { id: 1, title: 'Commercial Arbitration Procedures in Egypt', date: '2024-03-01', views: 450, rating: 4.8, category: 'precedents' },
    { id: 2, title: 'Standard Employment Contract 2024', date: '2024-02-15', views: 320, rating: 5.0, category: 'contracts' },
    { id: 3, title: 'Supreme Court Ruling on Land Disputes', date: '2024-01-20', views: 180, rating: 4.5, category: 'precedents' },
    { id: 4, title: 'Client Onboarding Procedure', date: '2024-01-10', views: 90, rating: 4.2, category: 'procedures' },
]

export function KnowledgeContent() {
    const { language } = useLanguage()
    const [articles, setArticles] = useState<Article[]>(initialArticles)
    const [searchTerm, setSearchTerm] = useState('')
    const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
    const [uploadDialogOpen, setUploadDialogOpen] = useState(false)
    const [newArticle, setNewArticle] = useState({ title: '', category: 'contracts' })
    const [feedback, setFeedback] = useState<string | null>(null)

    const showFeedback = (msg: string) => { setFeedback(msg); setTimeout(() => setFeedback(null), 2500) }

    const filteredArticles = articles.filter(a => {
        const matchSearch = a.title.toLowerCase().includes(searchTerm.toLowerCase())
        const matchCat = !selectedCategory || a.category === selectedCategory
        return matchSearch && matchCat
    })

    const handleUpload = () => {
        if (!newArticle.title) return
        const article: Article = { id: Date.now(), title: newArticle.title, date: new Date().toISOString().split('T')[0], views: 0, rating: 0, category: newArticle.category }
        setArticles(prev => [article, ...prev])
        setNewArticle({ title: '', category: 'contracts' })
        setUploadDialogOpen(false)
        showFeedback(language === 'ar' ? '✅ تمت إضافة الملف بنجاح' : '✅ File uploaded successfully')
    }

    const handleDownload = (article: Article) => {
        setArticles(prev => prev.map(a => a.id === article.id ? { ...a, views: a.views + 1 } : a))
        showFeedback(language === 'ar' ? `📥 جاري تحميل "${article.title}"` : `📥 Downloading "${article.title}"`)
    }

    return (
        <div className="space-y-8 animate-in fade-in duration-500">
            {feedback && (
                <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300">
                    <div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div>
                </div>
            )}

            {/* Hero Search */}
            <div className="relative overflow-hidden rounded-3xl bg-primary px-8 py-12 text-primary-foreground shadow-lg">
                <div className="relative z-10 max-w-2xl space-y-4">
                    <h1 className="text-4xl font-bold tracking-tight">{language === 'ar' ? 'المكتبة القانونية والأبحاث' : 'Knowledge Base & Research'}</h1>
                    <p className="text-primary-foreground/80 text-lg">{language === 'ar' ? 'ابحث في آلاف السوابق القضائية والتقارير والنماذج القانونية الجاهزة.' : 'Search through thousands of legal precedents, reports, and templates.'}</p>
                    <div className="relative max-w-lg pt-4">
                        <Search className="absolute left-3 top-7 size-5 text-muted-foreground rtl:left-auto rtl:right-3" />
                        <Input className="h-12 border-none bg-white text-black shadow-md pl-10 rtl:pl-4 rtl:pr-10" placeholder={language === 'ar' ? 'ابحث عن موضوع، قضية، أو نموذج...' : 'Search for a topic, case, or template...'} value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                    </div>
                </div>
                <div className="absolute -bottom-12 -right-12 size-64 rounded-full bg-white/10 blur-3xl" />
                <div className="absolute -top-12 -left-12 size-64 rounded-full bg-white/10 blur-3xl" />
            </div>

            {/* Categories */}
            <div className="grid gap-6 md:grid-cols-3">
                {categories.map((cat) => (
                    <Card key={cat.id} className={`group cursor-pointer hover:shadow-md transition-all border-none bg-muted/50 overflow-hidden ${selectedCategory === cat.id ? 'ring-2 ring-primary' : ''}`} onClick={() => setSelectedCategory(selectedCategory === cat.id ? null : cat.id)}>
                        <CardContent className="p-6">
                            <div className="flex items-center gap-4">
                                <div className={`rounded-xl p-3 transition-colors ${selectedCategory === cat.id ? 'bg-primary text-primary-foreground' : 'bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground'}`}>
                                    <cat.icon className="size-6" />
                                </div>
                                <div className="flex-1">
                                    <h3 className="font-semibold text-lg">{cat.name[language]}</h3>
                                    <p className="text-sm text-muted-foreground">{articles.filter(a => a.category === cat.id).length} {language === 'ar' ? 'ملف' : 'files'}</p>
                                </div>
                                <ChevronRight className="size-5 text-muted-foreground rtl:rotate-180" />
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            <div className="grid gap-8 md:grid-cols-2">
                {/* Articles */}
                <div className="space-y-4">
                    <div className="flex items-center justify-between">
                        <h2 className="text-xl font-bold">{selectedCategory ? categories.find(c => c.id === selectedCategory)?.name[language] : (language === 'ar' ? 'أحدث الإضافات' : 'Recently Added')}</h2>
                        {selectedCategory && <Button variant="ghost" size="sm" onClick={() => setSelectedCategory(null)}><X className="size-4 mr-1" />{language === 'ar' ? 'إلغاء التصفية' : 'Clear filter'}</Button>}
                    </div>
                    <div className="space-y-3">
                        {filteredArticles.length === 0 ? (
                            <p className="text-center text-muted-foreground py-8">{language === 'ar' ? 'لا توجد نتائج' : 'No results found'}</p>
                        ) : filteredArticles.map((article) => (
                            <Card key={article.id} className="border-none shadow-sm hover:bg-muted/30 transition-colors">
                                <CardContent className="flex items-center justify-between p-4">
                                    <div className="space-y-1 flex-1 min-w-0">
                                        <h4 className="font-medium text-sm leading-tight truncate">{article.title}</h4>
                                        <p className="text-xs text-muted-foreground">{article.date}</p>
                                    </div>
                                    <div className="flex items-center gap-4 text-xs text-muted-foreground ms-4">
                                        {article.rating > 0 && <div className="flex items-center gap-1"><Star className="size-3 text-yellow-500 fill-yellow-500" /><span>{article.rating}</span></div>}
                                        <div className="flex items-center gap-1"><Eye className="size-3" /><span>{article.views}</span></div>
                                        <Button variant="ghost" size="icon" className="size-8" onClick={() => handleDownload(article)}><Download className="size-4" /></Button>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>

                {/* Upload Section */}
                <Card className="border-none bg-primary/5 shadow-inner">
                    <CardHeader>
                        <CardTitle>{language === 'ar' ? 'مساهمة المحامي' : 'Lawyer Contribution'}</CardTitle>
                        <CardDescription>{language === 'ar' ? 'شارك خبرتك مع الفريق بإضافة سابقة قضائية جديدة.' : 'Share your expertise with the team by adding a new precedent.'}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
                            <DialogTrigger asChild>
                                <div className="rounded-xl border-2 border-dashed border-primary/20 p-8 text-center bg-white/50 dark:bg-black/20 cursor-pointer hover:border-primary/40 transition-colors">
                                    <FileText className="mx-auto size-12 text-primary/40 mb-4" />
                                    <p className="text-sm font-medium mb-1">{language === 'ar' ? 'اضغط لإضافة ملف جديد' : 'Click to add a new file'}</p>
                                    <p className="text-xs text-muted-foreground mb-4">{language === 'ar' ? 'أو اضغط لاختيار ملف PDF أو Word' : 'Add a PDF, Word document, or text entry'}</p>
                                    <Button size="sm" className="gap-2"><Upload className="size-4" />{language === 'ar' ? 'رفع ملف' : 'Upload File'}</Button>
                                </div>
                            </DialogTrigger>
                            <DialogContent>
                                <DialogHeader>
                                    <DialogTitle>{language === 'ar' ? 'رفع ملف جديد' : 'Upload New File'}</DialogTitle>
                                    <DialogDescription>{language === 'ar' ? 'أضف عنوااً واختر التصنيف المناسب.' : 'Enter a title and select the appropriate category.'}</DialogDescription>
                                </DialogHeader>
                                <div className="grid gap-4 py-4">
                                    <div className="grid gap-2"><Label>{language === 'ar' ? 'عنوان الملف *' : 'File Title *'}</Label><Input value={newArticle.title} onChange={e => setNewArticle(p => ({ ...p, title: e.target.value }))} placeholder={language === 'ar' ? 'مثال: عقد بيع عقاري' : 'e.g. Real Estate Sale Contract'} /></div>
                                    <div className="grid gap-2">
                                        <Label>{language === 'ar' ? 'التصنيف' : 'Category'}</Label>
                                        <div className="flex flex-wrap gap-2">
                                            {categories.map(cat => (
                                                <Badge key={cat.id} variant={newArticle.category === cat.id ? 'default' : 'outline'} className="cursor-pointer" onClick={() => setNewArticle(p => ({ ...p, category: cat.id }))}>{cat.name[language]}</Badge>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                <DialogFooter>
                                    <Button variant="outline" onClick={() => setUploadDialogOpen(false)}>{language === 'ar' ? 'إلغاء' : 'Cancel'}</Button>
                                    <Button onClick={handleUpload} disabled={!newArticle.title}>{language === 'ar' ? 'رفع' : 'Upload'}</Button>
                                </DialogFooter>
                            </DialogContent>
                        </Dialog>
                    </CardContent>
                </Card>
            </div>
        </div>
    )
}
