'use client'

import React from "react"

import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar'
import { AppSidebar } from '@/components/app-sidebar'
import { AppHeader } from '@/components/app-header'
import { useLanguage } from '@/lib/language-context'

interface BreadcrumbItem {
  label: string
  href?: string
}

interface AppLayoutProps {
  breadcrumbs?: BreadcrumbItem[]
}

export function AppLayout({ children, breadcrumbs }: React.PropsWithChildren<AppLayoutProps>) {
  const { language } = useLanguage()

  return (
    <div className="overflow-wrapper" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <SidebarProvider defaultOpen={true}>
        <AppSidebar side={language === 'ar' ? 'right' : 'left'} />
        <SidebarInset className="flex flex-col min-h-screen">
          <AppHeader />
          <main className="flex-1 p-6 overflow-x-hidden">
            {children}
          </main>
        </SidebarInset>
      </SidebarProvider>
    </div>
  )
}
