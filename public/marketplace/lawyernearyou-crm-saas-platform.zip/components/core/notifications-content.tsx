'use client'

import React, { useState } from 'react'
import { Bell, Check, CheckCheck, Trash2, Filter, Mail, Briefcase, CreditCard, ShieldAlert, UserPlus, Settings } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useLanguage } from '@/lib/language-context'

interface Notification {
    id: number; title: string; description: string; time: string; read: boolean
    type: 'case' | 'billing' | 'security' | 'lead' | 'system'
}

const initial: Notification[] = [
    { id: 1, title: 'New case assigned', description: 'Case #2024-015 has been assigned to you by Admin.', time: '2 mins ago', read: false, type: 'case' },
    { id: 2, title: 'Invoice overdue', description: 'Invoice #INV-0042 for client Sara Kamel is 7 days overdue.', time: '1 hour ago', read: false, type: 'billing' },
    { id: 3, title: 'New lead received', description: 'Omar Fathy submitted a consultation request via the website.', time: '3 hours ago', read: false, type: 'lead' },
    { id: 4, title: 'Login from new device', description: 'A login was detected from Cairo, EG on Chrome/Windows.', time: 'Yesterday', read: true, type: 'security' },
    { id: 5, title: 'System update completed', description: 'LawCRM v2.4 has been deployed with new features.', time: '2 days ago', read: true, type: 'system' },
    { id: 6, title: 'Hearing reminder', description: 'Case #2024-001 hearing is tomorrow at 10:00 AM.', time: '2 days ago', read: true, type: 'case' },
]

const typeIcons: Record<string, React.ElementType> = { case: Briefcase, billing: CreditCard, security: ShieldAlert, lead: UserPlus, system: Settings }
const typeColors: Record<string, string> = { case: 'text-blue-500', billing: 'text-yellow-500', security: 'text-red-500', lead: 'text-green-500', system: 'text-purple-500' }

export function NotificationsContent() {
    const { language } = useLanguage()
    const [notifications, setNotifications] = useState<Notification[]>(initial)
    const [filter, setFilter] = useState('all')
    const [feedback, setFeedback] = useState<string | null>(null)
    const show = (m: string) => { setFeedback(m); setTimeout(() => setFeedback(null), 2500) }

    const markRead = (id: number) => setNotifications(p => p.map(n => n.id === id ? { ...n, read: true } : n))
    const markAllRead = () => { setNotifications(p => p.map(n => ({ ...n, read: true }))); show(language === 'ar' ? '✅ تم تعليم الكل كمقروء' : '✅ All marked as read') }
    const deleteNotif = (id: number) => { setNotifications(p => p.filter(n => n.id !== id)); show(language === 'ar' ? '🗑️ تم الحذف' : '🗑️ Removed') }

    const filtered = notifications.filter(n => filter === 'all' ? true : filter === 'unread' ? !n.read : n.type === filter)
    const unread = notifications.filter(n => !n.read).length

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {feedback && <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-2 duration-300"><div className="bg-background border shadow-lg rounded-lg px-6 py-3 text-sm font-medium">{feedback}</div></div>}
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">{language === 'ar' ? 'مركز الإشعارات' : 'Notifications'}</h1>
                    <p className="text-muted-foreground">{unread > 0 ? (language === 'ar' ? `لديك ${unread} إشعارات غير مقروءة` : `You have ${unread} unread notifications`) : (language === 'ar' ? 'لا إشعارات جديدة' : 'All caught up!')}</p>
                </div>
                <div className="flex gap-2">
                    <Select value={filter} onValueChange={setFilter}>
                        <SelectTrigger className="w-[150px]"><Filter className="size-4 mr-2 rtl:mr-0 rtl:ml-2" /><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">{language === 'ar' ? 'الكل' : 'All'}</SelectItem>
                            <SelectItem value="unread">{language === 'ar' ? 'غير مقروء' : 'Unread'}</SelectItem>
                            <SelectItem value="case">{language === 'ar' ? 'القضايا' : 'Cases'}</SelectItem>
                            <SelectItem value="billing">{language === 'ar' ? 'المالية' : 'Billing'}</SelectItem>
                            <SelectItem value="security">{language === 'ar' ? 'الأمان' : 'Security'}</SelectItem>
                        </SelectContent>
                    </Select>
                    <Button variant="outline" className="gap-2" onClick={markAllRead}><CheckCheck className="size-4" />{language === 'ar' ? 'تعليم الكل كمقروء' : 'Mark all read'}</Button>
                </div>
            </div>
            <div className="space-y-2">
                {filtered.length === 0 ? <p className="text-center text-muted-foreground py-12">{language === 'ar' ? 'لا توجد إشعارات' : 'No notifications'}</p> : filtered.map(n => {
                    const Icon = typeIcons[n.type] || Bell
                    return (
                        <Card key={n.id} className={`border-none shadow-sm transition-colors cursor-pointer ${!n.read ? 'bg-primary/5 hover:bg-primary/10' : 'hover:bg-muted/30'}`} onClick={() => markRead(n.id)}>
                            <CardContent className="flex items-start gap-4 p-4">
                                <div className={`rounded-full p-2 bg-muted mt-0.5 ${typeColors[n.type]}`}><Icon className="size-4" /></div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2">
                                        <h4 className={`text-sm font-medium ${!n.read ? 'font-semibold' : ''}`}>{n.title}</h4>
                                        {!n.read && <Badge className="h-5 text-[10px]">{language === 'ar' ? 'جديد' : 'New'}</Badge>}
                                    </div>
                                    <p className="text-xs text-muted-foreground mt-0.5">{n.description}</p>
                                    <p className="text-[10px] text-muted-foreground mt-1">{n.time}</p>
                                </div>
                                <Button variant="ghost" size="icon" className="size-7 text-destructive hover:text-destructive shrink-0" onClick={e => { e.stopPropagation(); deleteNotif(n.id) }}><Trash2 className="size-3.5" /></Button>
                            </CardContent>
                        </Card>
                    )
                })}
            </div>
        </div>
    )
}
