'use client'

import { useLanguage } from '@/lib/language-context'
import {
    ShieldCheck,
    CreditCard,
    CheckCircle2,
    Zap,
    ArrowUpCircle,
    Clock,
    ExternalLink,
    Shield
} from 'lucide-react'
import {
    Card,
    CardContent,
    CardDescription,
    CardFooter,
    CardHeader,
    CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'

export function SubscriptionContent() {
    const { language } = useLanguage()

    const plans = [
        {
            name: language === 'ar' ? 'الأساسية (Starter)' : 'Starter',
            price: 'Free',
            features: [
                language === 'ar' ? 'تا مستخدم واحد فقط' : '1 User Only',
                language === 'ar' ? 'حتى 10 قضايا نشطة' : 'Up to 10 Active Cases',
                language === 'ar' ? 'دعم عبر البريد الإلكتروني' : 'Email Support',
            ],
            current: false,
        },
        {
            name: language === 'ar' ? 'الاحترافية (Pro)' : 'Pro Plan',
            price: 'EGP 999 / mo',
            features: [
                language === 'ar' ? 'حتى 10 مستخدمين' : 'Up to 10 Users',
                language === 'ar' ? 'قضايا غير محدودة' : 'Unlimited Cases',
                language === 'ar' ? 'المساعد الذكي (AI)' : 'AI Assistant Access',
                language === 'ar' ? 'دعم فني متواصل' : 'Priority Support',
            ],
            current: true,
            popular: true,
        },
        {
            name: language === 'ar' ? 'المؤسسات (Enterprise)' : 'Enterprise',
            price: 'Custom',
            features: [
                language === 'ar' ? 'مستخدمين غير محدودين' : 'Unlimited Users',
                language === 'ar' ? 'تخزين ملفات غير محدود' : 'Unlimited Storage',
                language === 'ar' ? 'API مخصص' : 'Custom API Access',
                language === 'ar' ? 'مدير حساب مخصص' : 'Dedicated Account Manager',
            ],
            current: false,
        },
    ]

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                    <h2 className="text-2xl font-bold tracking-tight text-start">
                        {language === 'ar' ? 'إدارة الاشتراك والاشتراكات' : 'Subscription & Billing'}
                    </h2>
                    <p className="text-muted-foreground text-start">
                        {language === 'ar'
                            ? 'إدارة باقتك الحالية ومتابعة معدل الاستهلاك المتاح لمكتبك.'
                            : 'Manage your current plan and monitor your workspace usage quotas.'}
                    </p>
                </div>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
                <Card className="md:col-span-2 border-primary/20 shadow-sm overflow-hidden">
                    <div className="bg-primary/5 px-6 py-4 border-b flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="bg-primary text-primary-foreground p-2 rounded-lg">
                                <ShieldCheck className="size-5" />
                            </div>
                            <div className="text-start">
                                <p className="text-sm font-medium opacity-80">{language === 'ar' ? 'الباقة الحالية' : 'Current Plan'}</p>
                                <h3 className="text-xl font-bold">LawCRM Pro (SaaS)</h3>
                            </div>
                        </div>
                        <Badge className="bg-primary">{language === 'ar' ? 'نشط' : 'Active'}</Badge>
                    </div>
                    <CardContent className="pt-6">
                        <div className="grid gap-8 md:grid-cols-2">
                            <div className="space-y-4">
                                <div className="space-y-2">
                                    <div className="flex justify-between text-sm">
                                        <span className="text-muted-foreground">{language === 'ar' ? 'المستخدمين' : 'Users'}</span>
                                        <span className="font-medium text-start">5 / 10 {language === 'ar' ? 'مستخدم' : 'users'}</span>
                                    </div>
                                    <Progress value={50} className="h-2" />
                                </div>
                                <div className="space-y-2">
                                    <div className="flex justify-between text-sm">
                                        <span className="text-muted-foreground">{language === 'ar' ? 'تخزين الملفات' : 'File Storage'}</span>
                                        <span className="font-medium text-start">4.2 GB / 20 GB</span>
                                    </div>
                                    <Progress value={21} className="h-2" />
                                </div>
                                <div className="space-y-2">
                                    <div className="flex justify-between text-sm">
                                        <span className="text-muted-foreground">{language === 'ar' ? 'استهلاك الـ AI' : 'AI Assistant Usage'}</span>
                                        <span className="font-medium text-start">750 / 2,000 {language === 'ar' ? 'رسالة' : 'messages'}</span>
                                    </div>
                                    <Progress value={37.5} className="h-2" />
                                </div>
                            </div>
                            <div className="bg-muted/30 p-4 rounded-xl space-y-3">
                                <h4 className="text-sm font-bold flex items-center gap-2">
                                    <Clock className="size-4 text-primary" />
                                    {language === 'ar' ? 'تفاصيل التجديد' : 'Billing Cycle'}
                                </h4>
                                <div className="space-y-2 border-t pt-2">
                                    <div className="flex justify-between text-sm">
                                        <span className="text-muted-foreground">{language === 'ar' ? 'التجديد القادم' : 'Next Renewal'}</span>
                                        <span className="font-medium">10 {language === 'ar' ? 'أبريل' : 'April'}, 2026</span>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                        <span className="text-muted-foreground">{language === 'ar' ? 'طريقة الدفع' : 'Payment Method'}</span>
                                        <span className="font-medium flex items-center gap-1">
                                            <CreditCard className="size-3" /> Visa •••• 4242
                                        </span>
                                    </div>
                                </div>
                                <Button variant="outline" className="w-full mt-2 text-xs" size="sm">
                                    {language === 'ar' ? 'تغيير بطاقة الدفع' : 'Change Payment Method'}
                                </Button>
                            </div>
                        </div>
                    </CardContent>
                    <CardFooter className="bg-muted/10 border-t flex justify-between items-center py-4">
                        <span className="text-sm text-muted-foreground">
                            {language === 'ar' ? 'تم تفعيل الاشتراك في 10 مارس 2026' : 'Subscription active since Mar 10, 2026'}
                        </span>
                        <Button variant="link" className="text-primary gap-1">
                            {language === 'ar' ? 'عرض الفواتير السابقة' : 'View Invoices'} <ExternalLink className="size-3" />
                        </Button>
                    </CardFooter>
                </Card>

                <Card className="bg-slate-900 text-slate-50 border-none shadow-xl">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Zap className="size-5 text-yellow-500 fill-yellow-500" />
                            {language === 'ar' ? 'هل تحتاج لمساحة أكبر؟' : 'Need more space?'}
                        </CardTitle>
                        <CardDescription className="text-slate-400">
                            {language === 'ar'
                                ? 'قم بالترقية للباقة الأعلى للحصول على موارد غير محدودة.'
                                : 'Upgrade to our Enterprise plan for unlimited resources and priority support.'}
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="p-3 rounded-lg bg-white/5 border border-white/10">
                            <p className="text-xs text-slate-400 mb-1">{language === 'ar' ? 'باقة Enterprise ستمكنك من:' : 'Enterprise Plan enables:'}</p>
                            <ul className="text-sm space-y-2">
                                <li className="flex items-center gap-2">
                                    <CheckCircle2 className="size-3 text-yellow-500" />
                                    {language === 'ar' ? 'موظفين غير محدودين' : 'Unlimited Staff Members'}
                                </li>
                                <li className="flex items-center gap-2">
                                    <CheckCircle2 className="size-3 text-yellow-500" />
                                    {language === 'ar' ? 'تخزين سحابي ضخم' : 'Bulk Cloud Storage'}
                                </li>
                            </ul>
                        </div>
                    </CardContent>
                    <CardFooter>
                        <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-bold gap-2">
                            <ArrowUpCircle className="size-4" />
                            {language === 'ar' ? 'التحدث مع المبيعات' : 'Contact Sales'}
                        </Button>
                    </CardFooter>
                </Card>
            </div>

            <div className="grid gap-6 md:grid-cols-3 pt-4">
                {plans.map((plan) => (
                    <Card key={plan.name} className={`relative flex flex-col ${plan.current ? 'border-primary shadow-md' : ''}`}>
                        {plan.popular && !plan.current && (
                            <Badge className="absolute top-0 right-1/2 translate-x-1/2 -translate-y-1/2 bg-primary">
                                {language === 'ar' ? 'الأكثر شيوعاً' : 'Most Popular'}
                            </Badge>
                        )}
                        {plan.current && (
                            <Badge variant="outline" className="absolute top-0 right-1/2 translate-x-1/2 -translate-y-1/2 bg-background border-primary text-primary">
                                {language === 'ar' ? 'باقتك الحالية' : 'Your Plan'}
                            </Badge>
                        )}
                        <CardHeader>
                            <CardTitle>{plan.name}</CardTitle>
                            <CardDescription className="text-xl font-bold text-foreground">{plan.price}</CardDescription>
                        </CardHeader>
                        <CardContent className="flex-1">
                            <ul className="space-y-2">
                                {plan.features.map((feature) => (
                                    <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                                        <CheckCircle2 className="size-4 text-green-500" />
                                        {feature}
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                        <CardFooter>
                            <Button
                                variant={plan.current ? 'outline' : 'default'}
                                className="w-full"
                                disabled={plan.current}
                            >
                                {plan.current ? (language === 'ar' ? 'قيد العمل' : 'Active') : (language === 'ar' ? 'اختيار هذه الباقة' : 'Choose Plan')}
                            </Button>
                        </CardFooter>
                    </Card>
                ))}
            </div>
        </div>
    )
}
