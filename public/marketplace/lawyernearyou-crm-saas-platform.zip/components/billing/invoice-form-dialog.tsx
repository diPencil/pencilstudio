'use client'

import React, { useState, useEffect } from "react"
import { addInvoice, useCases, useClients } from '@/lib/data-store'
import type { Invoice, InvoiceItem } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog'
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select'
import { Plus, Trash2, Calculator } from 'lucide-react'

interface InvoiceFormDialogProps {
    open: boolean
    onOpenChange: (open: boolean) => void
}

export function InvoiceFormDialog({ open, onOpenChange }: InvoiceFormDialogProps) {
    const { cases } = useCases()
    const { clients } = useClients()

    const [formData, setFormData] = useState({
        caseId: '',
        clientId: '',
        invoiceNumber: `INV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
        issueDate: new Date().toISOString().split('T')[0],
        dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 14 days later
        items: [] as Omit<InvoiceItem, 'id'>[],
        status: 'draft' as Invoice['status'],
    })

    useEffect(() => {
        if (open) {
            setFormData(prev => ({
                ...prev,
                invoiceNumber: `INV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
                issueDate: new Date().toISOString().split('T')[0],
            }))
        }
    }, [open])

    const addItem = () => {
        setFormData({
            ...formData,
            items: [...formData.items, { description: '', amount: 0, quantity: 1 }]
        })
    }

    const removeItem = (index: number) => {
        setFormData({
            ...formData,
            items: formData.items.filter((_, i) => i !== index)
        })
    }

    const updateItem = (index: number, field: keyof Omit<InvoiceItem, 'id'>, value: string | number) => {
        const newItems = [...formData.items]
        newItems[index] = { ...newItems[index], [field]: value }
        setFormData({ ...formData, items: newItems })
    }

    const calculateTotal = () => {
        return formData.items.reduce((acc, item) => acc + (item.amount * item.quantity), 0)
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault()

        const itemsWithIds: InvoiceItem[] = formData.items.map((item, idx) => ({
            ...item,
            id: `item-${Date.now()}-${idx}`
        }))

        addInvoice({
            ...formData,
            items: itemsWithIds,
            totalAmount: calculateTotal(),
        })

        onOpenChange(false)
        setFormData({
            ...formData,
            items: [],
            caseId: '',
            clientId: '',
        })
    }

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>Create New Invoice</DialogTitle>
                    <DialogDescription>
                        Generate a new professional invoice for your legal services.
                    </DialogDescription>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid gap-4 sm:grid-cols-2">
                        <div className="space-y-2">
                            <Label htmlFor="invoiceNumber">Invoice Number</Label>
                            <Input
                                id="invoiceNumber"
                                value={formData.invoiceNumber}
                                onChange={(e) => setFormData({ ...formData, invoiceNumber: e.target.value })}
                                required
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="status">Status</Label>
                            <Select
                                value={formData.status}
                                onValueChange={(v: Invoice['status']) => setFormData({ ...formData, status: v })}
                            >
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="draft">Draft</SelectItem>
                                    <SelectItem value="sent">Sent to Client</SelectItem>
                                    <SelectItem value="paid">Paid</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="client">Client</Label>
                            <Select
                                value={formData.clientId}
                                onValueChange={(v) => setFormData({ ...formData, clientId: v })}
                                required
                            >
                                <SelectTrigger id="client">
                                    <SelectValue placeholder="Select client" />
                                </SelectTrigger>
                                <SelectContent>
                                    {clients.map(c => (
                                        <SelectItem key={c.id} value={c.id}>{c.firstName} {c.lastName}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="case">Associated Case (Optional)</Label>
                            <Select
                                value={formData.caseId}
                                onValueChange={(v) => setFormData({ ...formData, caseId: v })}
                            >
                                <SelectTrigger id="case">
                                    <SelectValue placeholder="Select case" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="none">No specific case</SelectItem>
                                    {cases.filter(c => c.clientId === formData.clientId).map(c => (
                                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                                    ))}
                                    {formData.clientId === '' && cases.map(c => (
                                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="issueDate">Issue Date</Label>
                            <Input
                                id="issueDate"
                                type="date"
                                value={formData.issueDate}
                                onChange={(e) => setFormData({ ...formData, issueDate: e.target.value })}
                                required
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="dueDate">Due Date</Label>
                            <Input
                                id="dueDate"
                                type="date"
                                value={formData.dueDate}
                                onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                                required
                            />
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div className="flex items-center justify-between border-b pb-2">
                            <Label className="text-base">Invoice Items</Label>
                            <Button type="button" variant="outline" size="sm" onClick={addItem}>
                                <Plus className="size-4 mr-2" />
                                Add Item
                            </Button>
                        </div>

                        {formData.items.length === 0 ? (
                            <div className="text-center py-6 border rounded-lg border-dashed text-muted-foreground text-sm">
                                No items added yet. Click &quot;Add Item&quot; to begin.
                            </div>
                        ) : (
                            <div className="space-y-3">
                                {formData.items.map((item, index) => (
                                    <div key={index} className="flex gap-4 items-end">
                                        <div className="flex-1 space-y-1">
                                            <Label className="text-[10px] uppercase font-bold text-muted-foreground">Description</Label>
                                            <Input
                                                value={item.description}
                                                onChange={(e) => updateItem(index, 'description', e.target.value)}
                                                placeholder="e.g., Legal Consultation"
                                                required
                                            />
                                        </div>
                                        <div className="w-24 space-y-1">
                                            <Label className="text-[10px] uppercase font-bold text-muted-foreground">Qty</Label>
                                            <Input
                                                type="number"
                                                value={item.quantity}
                                                onChange={(e) => updateItem(index, 'quantity', parseInt(e.target.value) || 0)}
                                                min="1"
                                                required
                                            />
                                        </div>
                                        <div className="w-32 space-y-1">
                                            <Label className="text-[10px] uppercase font-bold text-muted-foreground">Amount (EGP)</Label>
                                            <Input
                                                type="number"
                                                value={item.amount}
                                                onChange={(e) => updateItem(index, 'amount', parseFloat(e.target.value) || 0)}
                                                min="0"
                                                required
                                            />
                                        </div>
                                        <Button
                                            type="button"
                                            variant="ghost"
                                            size="icon"
                                            onClick={() => removeItem(index)}
                                            className="text-destructive hover:text-destructive hover:bg-destructive/10"
                                        >
                                            <Trash2 className="size-4" />
                                        </Button>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>

                    <div className="flex justify-between items-center bg-primary/5 p-4 rounded-lg">
                        <div className="flex items-center gap-2 text-primary font-medium">
                            <Calculator className="size-5" />
                            Total Amount
                        </div>
                        <div className="text-2xl font-bold font-mono">
                            EGP {calculateTotal().toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </div>
                    </div>

                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                            Discard
                        </Button>
                        <Button type="submit" disabled={formData.items.length === 0}>
                            Create Professional Invoice
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    )
}
