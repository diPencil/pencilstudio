'use client'

import React, { useState } from "react"
import { useInvoices, useCases, useClients, updateInvoice, usePaymentLogs } from '@/lib/data-store'
import type { Invoice, PaymentLog } from '@/lib/types'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from '@/components/ui/table'
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
    Plus,
    MoreHorizontal,
    FileText,
    CreditCard,
    Printer,
    Mail,
    Download,
    CheckCircle,
    AlertCircle,
    Clock,
    BarChart,
} from 'lucide-react'
import Link from 'next/link'
import { useLanguage } from '@/lib/language-context'
import { useTenant } from '@/lib/tenant-context'
import { InvoiceFormDialog } from './invoice-form-dialog'

export function BillingContent() {
    const { t, language } = useLanguage()
    const { currentTenant } = useTenant()
    const { invoices, isLoading } = useInvoices()
    const { paymentLogs } = usePaymentLogs()
    const { cases } = useCases()
    const { clients } = useClients()
    const [dialogOpen, setDialogOpen] = useState(false)
    const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null)

    const getCaseName = (caseId: string) => cases.find(c => c.id === caseId)?.name || 'General Legal Services'
    const getClientName = (clientId: string) => {
        const client = clients.find(c => c.id === clientId)
        return client ? `${client.firstName} ${client.lastName}` : 'Unknown Client'
    }

    const getStatusBadge = (status: Invoice['status']) => {
        const variants: Record<string, { variant: 'default' | 'secondary' | 'destructive' | 'outline'; label: string; icon: any }> = {
            draft: { variant: 'outline', label: 'Draft', icon: Clock },
            sent: { variant: 'outline', label: 'Sent', icon: Mail },
            paid: { variant: 'default', label: 'Paid', icon: CheckCircle },
            overdue: { variant: 'destructive', label: 'Overdue', icon: AlertCircle },
            cancelled: { variant: 'secondary', label: 'Cancelled', icon: AlertCircle },
            'partially-paid': { variant: 'secondary', label: 'Partial', icon: CreditCard },
        }
        const config = variants[status] || variants.draft
        const Icon = config.icon
        return (
            <Badge variant={config.variant} className="flex items-center gap-1">
                <Icon className="size-3" />
                {config.label}
            </Badge>
        )
    }

    const handleStatusChange = (id: string, status: Invoice['status']) => {
        updateInvoice(id, { status })
    }

    if (isLoading) {
        return (
            <div className="flex items-center justify-center p-8">
                <div className="animate-pulse text-muted-foreground italic">جارٍ تحميل الفواتير... Loading Invoices...</div>
            </div>
        )
    }

    return (
        <div className="p-4 md:p-6 space-y-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-2xl font-bold tracking-tight">{language === 'ar' ? 'المالية والفواتير' : 'Billing & Invoicing'}</h1>
                    <p className="text-muted-foreground">{language === 'ar' ? 'إدارة فواتير العملاء والمدفوعات والسجلات المالية' : 'Manage client billing, payments, and financial records'}</p>
                </div>
                <div className="flex gap-2">
                    <Button
                        variant="secondary"
                        onClick={() => {
                            if (currentTenant.plan === 'Starter') {
                                alert(language === 'ar' ? ' ترقية الباقة مطلوبة: ميزة التقارير الشهرية متاحة في باقات Pro و Enterprise' : 'Upgrade Required: Monthly Reports are available on Pro and Enterprise plans.')
                                return
                            }
                            alert('Monthly Financial Report (Accountant Role Only) generated and downloaded.')
                        }}
                        className="hidden sm:flex"
                    >
                        <BarChart className="size-4 mr-2" />
                        {language === 'ar' ? 'تقرير شهري' : 'Monthly Report'}
                    </Button>
                    <Button onClick={() => setDialogOpen(true)}>
                        <Plus className="size-4 mr-2" />
                        {language === 'ar' ? 'إنشاء فاتورة' : 'Create Invoice'}
                    </Button>
                </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
                <Card className="bg-primary/5 border-primary/20">
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-muted-foreground tracking-wider uppercase">{language === 'ar' ? 'إجمالي المستحقات' : 'Total Outstanding'}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">
                            EGP {invoices
                                .filter(inv => inv.status === 'sent' || inv.status === 'overdue' || inv.status === 'partially-paid')
                                .reduce((acc, inv) => acc + inv.totalAmount, 0)
                                .toLocaleString()}
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-muted-foreground tracking-wider uppercase">{language === 'ar' ? 'المدفوع (هذا الشهر)' : 'Paid (This Month)'}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">
                            EGP {invoices
                                .filter(inv => inv.status === 'paid')
                                .reduce((acc, inv) => acc + inv.totalAmount, 0)
                                .toLocaleString()}
                        </div>
                    </CardContent>
                </Card>
                <Card className="border-destructive/30 bg-destructive/5">
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-destructive tracking-wider uppercase">{language === 'ar' ? 'متأخرات' : 'Overdue'}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold text-destructive">
                            EGP {invoices
                                .filter(inv => inv.status === 'overdue')
                                .reduce((acc, inv) => acc + inv.totalAmount, 0)
                                .toLocaleString()}
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Tabs defaultValue="invoices" className="space-y-4">
                <TabsList>
                    <TabsTrigger value="invoices">{language === 'ar' ? 'الفواتير' : 'Invoices / Bills'}</TabsTrigger>
                    <TabsTrigger value="payments">{language === 'ar' ? 'سجلات الدفع' : 'Payment History Logs'}</TabsTrigger>
                </TabsList>

                <TabsContent value="invoices" className="space-y-4">
                    <Card className="backdrop-blur-md bg-card/80">
                        <CardHeader>
                            <CardTitle>Invoices</CardTitle>
                            <CardDescription>A list of all client invoices and their current status</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="overflow-x-auto">
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Invoice #</TableHead>
                                            <TableHead>Client</TableHead>
                                            <TableHead className="hidden md:table-cell">Case</TableHead>
                                            <TableHead>Issued</TableHead>
                                            <TableHead>Amount</TableHead>
                                            <TableHead>Status</TableHead>
                                            <TableHead className="w-10"></TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {invoices.length === 0 ? (
                                            <TableRow>
                                                <TableCell colSpan={7} className="text-center py-10 text-muted-foreground italic">
                                                    No invoices found. Start by creating your first invoice.
                                                </TableCell>
                                            </TableRow>
                                        ) : (
                                            invoices.map((inv) => (
                                                <TableRow key={inv.id}>
                                                    <TableCell className="font-medium text-primary">{inv.invoiceNumber}</TableCell>
                                                    <TableCell>{getClientName(inv.clientId)}</TableCell>
                                                    <TableCell className="hidden md:table-cell truncate max-w-[200px]">
                                                        {getCaseName(inv.caseId)}
                                                    </TableCell>
                                                    <TableCell>{new Date(inv.issueDate).toLocaleDateString()}</TableCell>
                                                    <TableCell className="font-bold">EGP {inv.totalAmount.toLocaleString()}</TableCell>
                                                    <TableCell>{getStatusBadge(inv.status)}</TableCell>
                                                    <TableCell>
                                                        <DropdownMenu>
                                                            <DropdownMenuTrigger asChild>
                                                                <Button variant="ghost" size="icon" className="size-8">
                                                                    <MoreHorizontal className="size-4" />
                                                                </Button>
                                                            </DropdownMenuTrigger>
                                                            <DropdownMenuContent align="end" className="w-48">
                                                                <DropdownMenuItem>
                                                                    <Printer className="size-4 mr-2" />
                                                                    Print / PDF
                                                                </DropdownMenuItem>
                                                                <DropdownMenuItem>
                                                                    <Mail className="size-4 mr-2" />
                                                                    Email to Client
                                                                </DropdownMenuItem>
                                                                <DropdownMenuItem>
                                                                    <Download className="size-4 mr-2" />
                                                                    Download
                                                                </DropdownMenuItem>
                                                                <DropdownMenuSeparator />
                                                                <DropdownMenuItem onClick={() => handleStatusChange(inv.id, 'paid')}>
                                                                    <CheckCircle className="size-4 mr-2 text-green-500" />
                                                                    Mark as Paid
                                                                </DropdownMenuItem>
                                                                <DropdownMenuItem onClick={() => handleStatusChange(inv.id, 'sent')}>
                                                                    <Mail className="size-4 mr-2 text-blue-500" />
                                                                    Mark as Sent
                                                                </DropdownMenuItem>
                                                                <DropdownMenuItem onClick={() => handleStatusChange(inv.id, 'cancelled')} className="text-destructive">
                                                                    <AlertCircle className="size-4 mr-2" />
                                                                    Cancel Invoice
                                                                </DropdownMenuItem>
                                                            </DropdownMenuContent>
                                                        </DropdownMenu>
                                                    </TableCell>
                                                </TableRow>
                                            ))
                                        )}
                                    </TableBody>
                                </Table>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="payments" className="space-y-4">
                    <Card className="backdrop-blur-md bg-card/80">
                        <CardHeader>
                            <CardTitle>Payment History Logs</CardTitle>
                            <CardDescription>Record of all payments received from clients</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="overflow-x-auto">
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Date</TableHead>
                                            <TableHead>Client</TableHead>
                                            <TableHead>Invoice #</TableHead>
                                            <TableHead>Amount Paid</TableHead>
                                            <TableHead>Method</TableHead>
                                            <TableHead>Reference</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {paymentLogs.length === 0 ? (
                                            <TableRow>
                                                <TableCell colSpan={6} className="text-center py-10 text-muted-foreground italic">
                                                    No payment logs found.
                                                </TableCell>
                                            </TableRow>
                                        ) : (
                                            paymentLogs.map((log: PaymentLog) => {
                                                const invoice = invoices.find((inv) => inv.id === log.invoiceId)
                                                return (
                                                    <TableRow key={log.id}>
                                                        <TableCell>{new Date(log.date).toLocaleDateString()}</TableCell>
                                                        <TableCell className="font-medium">{getClientName(log.clientId)}</TableCell>
                                                        <TableCell>{invoice?.invoiceNumber || log.invoiceId}</TableCell>
                                                        <TableCell className="font-bold text-green-600">EGP {log.amount.toLocaleString()}</TableCell>
                                                        <TableCell>
                                                            <Badge variant="outline">{log.paymentMethod}</Badge>
                                                        </TableCell>
                                                        <TableCell className="text-xs text-muted-foreground">{log.referenceNumber || '-'}</TableCell>
                                                    </TableRow>
                                                )
                                            })
                                        )}
                                    </TableBody>
                                </Table>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            <InvoiceFormDialog
                open={dialogOpen}
                onOpenChange={setDialogOpen}
            />
        </div>
    )
}
