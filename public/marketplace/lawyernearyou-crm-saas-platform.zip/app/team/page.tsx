'use client'

import { AppLayout } from '@/components/app-layout'
import { TeamManagement } from '@/components/team/team-management'

export default function TeamPage() {
    return (
        <AppLayout>
            <TeamManagement />
        </AppLayout>
    )
}
