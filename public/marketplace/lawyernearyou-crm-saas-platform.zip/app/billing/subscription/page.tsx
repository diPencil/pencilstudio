'use client'

import { AppLayout } from '@/components/app-layout'
import { SubscriptionContent } from '@/components/billing/subscription-content'

export default function SubscriptionPage() {
    return (
        <AppLayout>
            <SubscriptionContent />
        </AppLayout>
    )
}
