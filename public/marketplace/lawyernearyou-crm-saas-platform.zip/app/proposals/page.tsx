import { AppLayout } from '@/components/app-layout'
import { ProposalsContent } from '@/components/crm/proposals-content'
export default function ProposalsPage() { return <AppLayout><ProposalsContent /></AppLayout> }
