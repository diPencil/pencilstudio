'use client'

import { AppLayout } from '@/components/app-layout'
import { DocumentsContent } from '@/components/documents/documents-content'

export default function DocumentsPage() {
    return (
        <AppLayout>
            <DocumentsContent />
        </AppLayout>
    )
}
