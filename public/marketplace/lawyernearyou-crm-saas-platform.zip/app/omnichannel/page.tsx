import { AppLayout } from '@/components/app-layout'
import { OmnichannelContent } from '@/components/communications/omnichannel-content'
export default function OmnichannelPage() { return <AppLayout><OmnichannelContent /></AppLayout> }
