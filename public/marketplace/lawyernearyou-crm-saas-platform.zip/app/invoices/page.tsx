import { AppLayout } from '@/components/app-layout'
import { InvoicesContent } from '@/components/finance/invoices-content'
export default function InvoicesPage() { return <AppLayout><InvoicesContent /></AppLayout> }
