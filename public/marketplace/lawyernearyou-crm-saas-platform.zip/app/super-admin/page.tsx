'use client'

import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from '@/components/ui/table'
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { BarChart3, Users, Building, AlertCircle, CheckCircle, MoreVertical, CreditCard, Ban } from 'lucide-react'
import { mockTenants } from '@/lib/tenant-context'

export default function SuperAdminDashboard() {
    const [tenants, setTenants] = useState(mockTenants)

    const mrr = tenants.filter(t => t.status !== 'suspended').reduce((acc, curr) => acc + curr.mrr, 0)
    const activeWorkspaces = tenants.filter(t => t.status === 'active').length
    const totalUsers = tenants.reduce((acc, curr) => acc + curr.users, 0)

    const getStatusBadge = (status: string) => {
        switch (status) {
            case 'active': return <Badge variant="default" className="bg-green-600 hover:bg-green-700 uppercase">{status}</Badge>
            case 'past_due': return <Badge variant="destructive" className="uppercase">{status.replace('_', ' ')}</Badge>
            case 'suspended': return <Badge variant="secondary" className="uppercase">{status}</Badge>
            default: return <Badge variant="outline" className="uppercase">{status}</Badge>
        }
    }

    return (
        <div className="min-h-screen bg-slate-50 p-4 md:p-8">
            <div className="max-w-7xl mx-auto space-y-8">
                {/* Header */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight text-slate-900">Platform Overview</h1>
                        <p className="text-muted-foreground">Manage your SaaS tenants, subscriptions, and global metrics.</p>
                    </div>
                    <div className="flex gap-2">
                        <Button variant="outline"><CreditCard className="size-4 mr-2" /> Billing Settings</Button>
                        <Button><BarChart3 className="size-4 mr-2" /> Global Reports</Button>
                    </div>
                </div>

                {/* Global KPIs */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card className="border-t-4 border-t-primary shadow-sm bg-white">
                        <CardContent className="p-6">
                            <div className="flex justify-between items-start">
                                <div className="space-y-2">
                                    <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Monthly Recurring Revenue</p>
                                    <p className="text-4xl font-extrabold text-slate-900">EGP {mrr.toLocaleString()}</p>
                                </div>
                                <div className="p-3 bg-primary/10 rounded-full">
                                    <BarChart3 className="size-6 text-primary" />
                                </div>
                            </div>
                            <p className="text-sm text-green-600 font-medium mt-4 flex items-center">
                                <CheckCircle className="size-4 mr-1" /> +12% from last month
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="border-t-4 border-t-blue-500 shadow-sm bg-white">
                        <CardContent className="p-6">
                            <div className="flex justify-between items-start">
                                <div className="space-y-2">
                                    <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Active Workspaces</p>
                                    <p className="text-4xl font-extrabold text-slate-900">{activeWorkspaces} <span className="text-lg text-muted-foreground font-medium">/ {tenants.length}</span></p>
                                </div>
                                <div className="p-3 bg-blue-500/10 rounded-full">
                                    <Building className="size-6 text-blue-500" />
                                </div>
                            </div>
                            <p className="text-sm text-green-600 font-medium mt-4 flex items-center">
                                <CheckCircle className="size-4 mr-1" /> 2 new this week
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="border-t-4 border-t-indigo-500 shadow-sm bg-white">
                        <CardContent className="p-6">
                            <div className="flex justify-between items-start">
                                <div className="space-y-2">
                                    <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Total Platform Users</p>
                                    <p className="text-4xl font-extrabold text-slate-900">{totalUsers}</p>
                                </div>
                                <div className="p-3 bg-indigo-500/10 rounded-full">
                                    <Users className="size-6 text-indigo-500" />
                                </div>
                            </div>
                            <p className="text-sm text-muted-foreground font-medium mt-4 flex items-center">
                                Distributed across all tenants
                            </p>
                        </CardContent>
                    </Card>
                </div>

                {/* Tenant Table */}
                <Card className="shadow-sm border-slate-200">
                    <CardHeader className="bg-white border-b border-slate-100 pb-4">
                        <CardTitle>Registered Law Firms (Tenants)</CardTitle>
                        <CardDescription>All workspaces provisioned on the SaaS platform.</CardDescription>
                    </CardHeader>
                    <CardContent className="p-0">
                        <div className="overflow-x-auto">
                            <Table>
                                <TableHeader className="bg-slate-50">
                                    <TableRow>
                                        <TableHead className="font-semibold text-slate-600">Firm Name & Domain</TableHead>
                                        <TableHead className="font-semibold text-slate-600">Plan</TableHead>
                                        <TableHead className="font-semibold text-slate-600">Status</TableHead>
                                        <TableHead className="font-semibold text-slate-600">MRR</TableHead>
                                        <TableHead className="font-semibold text-slate-600">Users</TableHead>
                                        <TableHead className="font-semibold text-slate-600">Joined</TableHead>
                                        <TableHead className="w-[50px]"></TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody className="bg-white">
                                    {tenants.map(tenant => (
                                        <TableRow key={tenant.id} className="hover:bg-slate-50 transition-colors">
                                            <TableCell>
                                                <p className="font-bold text-slate-900">{tenant.name}</p>
                                                <p className="text-xs text-muted-foreground font-mono mt-0.5">{tenant.domain}.lawcrm.eg</p>
                                            </TableCell>
                                            <TableCell>
                                                <Badge variant="outline" className="font-medium text-slate-600 bg-slate-100">{tenant.plan}</Badge>
                                            </TableCell>
                                            <TableCell>
                                                {getStatusBadge(tenant.status)}
                                            </TableCell>
                                            <TableCell className="font-semibold">
                                                EGP {tenant.mrr.toLocaleString()}
                                            </TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-1.5">
                                                    <Users className="size-3.5 text-muted-foreground" />
                                                    <span className="font-medium">{tenant.users}</span>
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-sm text-slate-600">
                                                {new Date(tenant.joined).toLocaleDateString()}
                                            </TableCell>
                                            <TableCell>
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="ghost" size="icon" className="hover:bg-slate-200">
                                                            <MoreVertical className="size-4" />
                                                        </Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align="end" className="w-48">
                                                        <DropdownMenuItem className="cursor-pointer">
                                                            <BarChart3 className="size-4 mr-2 text-slate-500" /> View Analytics
                                                        </DropdownMenuItem>
                                                        <DropdownMenuItem className="cursor-pointer">
                                                            <CreditCard className="size-4 mr-2 text-slate-500" /> Billing History
                                                        </DropdownMenuItem>
                                                        <DropdownMenuSeparator />
                                                        <DropdownMenuItem className="cursor-pointer text-amber-600">
                                                            <AlertCircle className="size-4 mr-2" /> Force Password Reset
                                                        </DropdownMenuItem>
                                                        {tenant.status !== 'suspended' && (
                                                            <DropdownMenuItem className="cursor-pointer text-destructive focus:bg-destructive focus:text-destructive-foreground"
                                                                onClick={() => setTenants(tenants.map(t => t.id === tenant.id ? { ...t, status: 'suspended', mrr: 0 } : t))}
                                                            >
                                                                <Ban className="size-4 mr-2" /> Suspend Workspace
                                                            </DropdownMenuItem>
                                                        )}
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    )
}
