import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function GET() {
  try {
    // In a production SaaS, you'd find the org based on req.headers.get('host')
    // For local dev, we fetch the first organization available
    const org = await prisma.organization.findFirst()
    
    if (!org) {
      // Return a stable default object to prevent UI crashes and 500 retry storms
      return NextResponse.json({
        id: 'default',
        name: 'LawCRM Demo',
        primaryColor: '#14b8a6',
        accentColor: '#0f766e',
        plan: 'Pro'
      })
    }

    return NextResponse.json({
      id: org.id,
      name: org.name,
      subdomain: org.subdomain,
      customDomain: org.customDomain,
      logoUrl: org.logoUrl,
      primaryColor: org.primaryColor || '#14b8a6',
      accentColor: org.accentColor || '#0f766e',
      brandName: org.brandName,
      phone: org.phone,
      address: org.address,
      email: org.email,
      website: org.website,
      description: org.description,
      plan: 'Pro' // Default for now
    })
  } catch (error) {
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
  }
}

export async function PATCH(req: Request) {
  try {
    const body = await req.json()
    const org = await prisma.organization.findFirst()
    
    if (!org) {
      return NextResponse.json({ error: 'Organization not found' }, { status: 404 })
    }

    const updated = await prisma.organization.update({
      where: { id: org.id },
      data: {
        primaryColor: body.primaryColor,
        accentColor: body.accentColor,
        logoUrl: body.logoUrl,
        brandName: body.brandName,
        subdomain: body.subdomain,
        customDomain: body.customDomain,
        phone: body.phone,
        address: body.address,
        email: body.email,
        website: body.website,
        description: body.description,
      }
    })

    return NextResponse.json({
      id: updated.id,
      name: updated.name,
      subdomain: updated.subdomain,
      customDomain: updated.customDomain,
      logoUrl: updated.logoUrl,
      primaryColor: updated.primaryColor,
      accentColor: updated.accentColor,
      brandName: updated.brandName,
      phone: updated.phone,
      address: updated.address,
      email: updated.email,
      website: updated.website,
      description: updated.description,
      plan: 'Pro'
    })
  } catch (error) {
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
  }
}
