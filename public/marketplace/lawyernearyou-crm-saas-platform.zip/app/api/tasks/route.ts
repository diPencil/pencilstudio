import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const caseId = searchParams.get('caseId')
    
    const tasks = await prisma.caseTask.findMany({
      where: caseId ? { caseId } : undefined,
      orderBy: { dueDate: 'asc' }
    })
    return NextResponse.json(tasks)
  } catch (error) {
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const task = await prisma.caseTask.create({
      data: {
        caseId: body.caseId,
        title: body.title,
        description: body.description || '',
        status: body.status || 'todo',
        priority: body.priority || 'medium',
        dueDate: new Date(body.dueDate),
      }
    })
    return NextResponse.json(task)
  } catch (error) {
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}
