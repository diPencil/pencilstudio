import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function GET() {
  try {
    const settings = await prisma.agentSettings.findFirst()
    
    if (!settings) {
      // Return a default object if none exists yet, rather than 404
      return NextResponse.json({
        model: 'anthropic/claude-3-5-sonnet',
        systemPrompt: 'You are a helpful legal assistant.',
        temperature: 0.7,
      })
    }
    return NextResponse.json(settings)
  } catch (error) {
    console.error('❌ Detailed Error in /api/settings/agent:', error)
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const org = await prisma.organization.findFirst()
    
    if (!org) {
      return NextResponse.json({ error: 'Org not found' }, { status: 400 })
    }

    const settings = await prisma.agentSettings.upsert({
      where: { organizationId: org.id },
      update: {
        model: body.model,
        temperature: body.temperature,
        systemPrompt: body.systemPrompt,
      },
      create: {
        organizationId: org.id,
        model: body.model,
        temperature: body.temperature,
        systemPrompt: body.systemPrompt,
      },
    })
    
    return NextResponse.json(settings)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update settings' }, { status: 500 })
  }
}
