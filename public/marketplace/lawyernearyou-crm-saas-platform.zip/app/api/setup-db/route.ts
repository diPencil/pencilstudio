import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function GET() {
  try {
    console.log('🌱 بدء إعداد قاعدة بيانات Saas كاملة...')

    // 1. المنظمة والمستخدم الرئيسي
    const org = await prisma.organization.upsert({
      where: { clerkId: 'org_demo' },
      update: {
        subdomain: 'demo',
        primaryColor: '#8b5cf6', // A nice violet to show it's working
        accentColor: '#7c3aed',
      },
      create: {
        clerkId: 'org_demo',
        name: 'مجموعة قاسم وماجد للمحاماة والتحكيم',
        subdomain: 'demo',
        primaryColor: '#8b5cf6',
        accentColor: '#7c3aed',
      },
    })

    const lawyer = await prisma.user.upsert({
      where: { email: 'admin@lawcrm.com' },
      update: {},
      create: {
        clerkId: 'user_demo',
        organizationId: org.id,
        name: 'أحمد محمود القاسم',
        email: 'admin@lawcrm.com',
        role: 'admin',
      },
    })

    // 2. العملاء
    const client1 = await prisma.client.create({
      data: {
        organizationId: org.id,
        firstName: 'إبراهيم',
        lastName: 'العربي',
        email: 'i.arabi@email.com',
        phone: '01011223344',
        address: 'شارع التسعين، التجمع الخامس',
      }
    })

    // 3. القضايا
    const case1 = await prisma.legalCase.create({
      data: {
        organizationId: org.id,
        name: 'قضية نزاع ملكية أرض - الشيخ زايد',
        caseType: 'civil',
        category: 'عقارات',
        filingDate: new Date(),
        priority: 'high',
        status: 'active',
        clientId: client1.id,
        assignedLawyerId: lawyer.id,
        notes: 'مراجعة أوراق الملكية الأصلية قبل الجلسة القادمة.',
      }
    })

    // 4. المهام
    await prisma.caseTask.createMany({
      data: [
        { caseId: case1.id, title: 'تحضير مذكرة الدفاع الأولى', status: 'todo', priority: 'high', dueDate: new Date(Date.now() + 86400000) },
        { caseId: case1.id, title: 'التواصل مع الشهود', status: 'in-progress', priority: 'medium', dueDate: new Date(Date.now() + 172800000) },
      ]
    })

    // 5. الفواتير
    await prisma.invoice.create({
      data: {
        organizationId: org.id,
        clientId: client1.id,
        amount: 15000,
        status: 'pending',
        dueDate: new Date(Date.now() + 604800000),
        invoiceNumber: 'INV-2024-001',
      }
    })

    // 6. تاريخ القضية
    await prisma.caseHistory.create({
      data: {
        caseId: case1.id,
        title: 'فتح ملف القضية',
        description: 'تم التعاقد مع العميل واستلام التوكيلات الرسمية.',
        eventType: 'milestone',
        eventDate: new Date(),
      }
    })

    // 7. إعدادات الذكاء الاصطناعي
    await prisma.agentSettings.upsert({
      where: { organizationId: org.id },
      update: {},
      create: {
        organizationId: org.id,
        model: 'anthropic/claude-opus-4.5',
        temperature: 0.7,
        systemPrompt: 'أنت مساعد قانوني متخصص في القانون المصري والتحكيم الدولي لمكتب القاسم.'
      }
    })

    return NextResponse.json({
      status: 'success',
      message: '✅ مبروك! الباكند جاهز ومليء بالبيانات الآن.',
      setupResult: 'Full Project Backend Seeded'
    })
  } catch (error: any) {
    console.error('❌ خطأ في الإعداد:', error)
    return NextResponse.json({ status: 'error', message: error.message }, { status: 500 })
  }
}
