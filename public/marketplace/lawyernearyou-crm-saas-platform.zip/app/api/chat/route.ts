import { streamText, convertToModelMessages, UIMessage } from 'ai'
import { createAnthropic } from '@ai-sdk/anthropic'

export async function POST(req: Request) {
  const { messages, model, temperature, systemPrompt }: {
    messages: UIMessage[]
    model?: string
    temperature?: number
    systemPrompt?: string
  } = await req.json()

  // 1. Check for API Key
  const apiKey = process.env.ANTHROPIC_API_KEY

  // 2. Mock Mode if no key is present
  if (!apiKey) {
    // Correctly extract text from UIMessage parts
    const lastMessage = messages[messages.length - 1]
    const lastMessageContent = lastMessage?.parts
      ?.filter(p => p.type === 'text')
      .map(p => (p as any).text)
      .join('') || ''

    // Create a simulated readable stream
    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      async start(controller) {
        const responses = [
          "Based on the LawCRM files, I've analyzed your request: ",
          `"${lastMessageContent}"`,
          "\n\nIn a legal context, this involves several standard procedures: \n1. Discovery review of associated filings. \n2. Cross-referencing current statutes. \n3. Verifying consistency with client intake notes.",
          "\n\nSince no ANTHROPIC_API_KEY is configured in your environment, I am providing this simulated response to demonstrate the UI flow. To enable real intelligence, please add your key to `.env`.",
          "\n\nHow else can I assist with your case research today?"
        ]

        for (const part of responses) {
          // Send text parts in the format expected by the AI SDK UI
          controller.enqueue(encoder.encode(`0:${JSON.stringify(part)}\n`))
          await new Promise(r => setTimeout(r, 100))
        }
        controller.close()
      }
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'x-vercel-ai-data-stream': 'v1',
      }
    })
  }

  // 3. Real Implementation
  const anthropic = createAnthropic({
    apiKey: apiKey,
  })

  const result = streamText({
    model: anthropic(model || 'claude-3-5-sonnet-20240620'),
    system: systemPrompt || 'You are a helpful legal assistant for LawCRM.',
    messages: await convertToModelMessages(messages),
    temperature: temperature ?? 0.7,
  })

  return result.toUIMessageStreamResponse()
}
