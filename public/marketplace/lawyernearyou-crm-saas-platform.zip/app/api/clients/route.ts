import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

// GET /api/clients - جلب جميع العملاء من SQLite
export async function GET() {
  try {
    const clients = await prisma.client.findMany({
      orderBy: {
        createdAt: 'desc',
      },
      include: {
        cases: true
      }
    })
    return NextResponse.json(clients)
  } catch (error) {
    console.error('Error fetching clients:', error)
    return NextResponse.json({ error: 'Failed to fetch clients' }, { status: 500 })
  }
}

// POST /api/clients - إضافة عميل جديد للقاعدة الحقيقية
export async function POST(req: Request) {
  try {
    const body = await req.json()
    
    // استخدام أول منظمة للتجربة المحلية
    const org = await prisma.organization.findFirst()
    
    if (!org) {
      return NextResponse.json({ error: 'System not seeded' }, { status: 400 })
    }

    const newClient = await prisma.client.create({
      data: {
        organizationId: org.id,
        firstName: body.firstName,
        lastName: body.lastName,
        email: body.email,
        phone: body.phone,
        address: body.address,
        nationalId: body.nationalId || '',
      },
    })
    
    return NextResponse.json(newClient)
  } catch (error) {
    console.error('Error creating client:', error)
    return NextResponse.json({ error: 'Failed to create client' }, { status: 500 })
  }
}
