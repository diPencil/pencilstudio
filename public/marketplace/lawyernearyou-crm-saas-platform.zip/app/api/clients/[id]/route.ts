import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function PATCH(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params
    const body = await req.json()

    const updatedClient = await prisma.client.update({
      where: { id },
      data: {
        firstName: body.firstName,
        lastName: body.lastName,
        email: body.email,
        phone: body.phone,
        address: body.address,
        nationalId: body.nationalId,
      },
    })

    return NextResponse.json(updatedClient)
  } catch (error) {
    console.error('Error updating client:', error)
    return NextResponse.json({ error: 'Failed to update client' }, { status: 500 })
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    // Delete related cases, consultations, invoices, payment logs first to prevent sqlite foreign key constraint failures
    await prisma.consultation.deleteMany({ where: { clientId: id } })
    await prisma.paymentLog.deleteMany({ where: { clientId: id } })
    await prisma.invoice.deleteMany({ where: { clientId: id } })
    
    // For cases, let's delete them (this will cascade delete histories, tasks, docs since we handle it)
    const clientCases = await prisma.legalCase.findMany({ where: { clientId: id } })
    for (const c of clientCases) {
      await prisma.caseHistory.deleteMany({ where: { caseId: c.id } })
      await prisma.caseTask.deleteMany({ where: { caseId: c.id } })
      await prisma.legalDocument.deleteMany({ where: { caseId: c.id } })
      await prisma.consultation.deleteMany({ where: { caseId: c.id } })
      await prisma.invoice.deleteMany({ where: { caseId: c.id } })
      await prisma.legalCase.delete({ where: { id: c.id } })
    }

    const deletedClient = await prisma.client.delete({
      where: { id },
    })

    return NextResponse.json(deletedClient)
  } catch (error) {
    console.error('Error deleting client:', error)
    return NextResponse.json({ error: 'Failed to delete client' }, { status: 500 })
  }
}
