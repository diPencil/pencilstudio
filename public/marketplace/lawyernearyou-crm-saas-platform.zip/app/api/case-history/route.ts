import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const caseId = searchParams.get('caseId')
    
    const history = await prisma.caseHistory.findMany({
      where: caseId ? { caseId } : undefined,
      include: {
        lawyer: true,
        case: true,
      },
      orderBy: { date: 'desc' }
    })
    return NextResponse.json(history)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch history' }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const org = await prisma.organization.findFirst()
    
    if (!org) {
      return NextResponse.json({ error: 'Org not found' }, { status: 400 })
    }

    const entry = await prisma.caseHistory.create({
      data: {
        organizationId: org.id,
        caseId: body.caseId,
        date: new Date(body.date),
        type: body.type || 'filing',
        title: body.title,
        description: body.description || '',
        lawyerId: body.lawyerId,
      }
    })
    return NextResponse.json(entry)
  } catch (error) {
    console.error('Error creating history:', error)
    return NextResponse.json({ error: 'Failed to create case history' }, { status: 500 })
  }
}
