import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const caseId = searchParams.get('caseId')
    
    const documents = await prisma.legalDocument.findMany({
      where: caseId ? { caseId } : undefined,
      orderBy: { createdAt: 'desc' }
    })
    return NextResponse.json(documents)
  } catch (error) {
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const document = await prisma.legalDocument.create({
      data: {
        caseId: body.caseId,
        name: body.name,
        fileUrl: body.fileUrl,
        fileType: body.fileType,
        category: body.category || 'general',
      }
    })
    return NextResponse.json(document)
  } catch (error) {
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}
