import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function PATCH(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params
    const body = await req.json()

    // Update invoice basic properties
    // If the body contains items, we might want to recreate/update them, but for basic updates like changing status, we can do it directly.
    const updatedInvoice = await prisma.invoice.update({
      where: { id },
      data: {
        status: body.status,
        dueDate: body.dueDate ? new Date(body.dueDate) : undefined,
        paymentMethod: body.paymentMethod,
        totalAmount: body.totalAmount !== undefined ? parseFloat(body.totalAmount) : undefined,
      },
    })

    return NextResponse.json(updatedInvoice)
  } catch (error) {
    console.error('Error updating invoice:', error)
    return NextResponse.json({ error: 'Failed to update invoice' }, { status: 500 })
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    // Delete related items and payments log first to prevent foreign key errors
    await prisma.invoiceItem.deleteMany({ where: { invoiceId: id } })
    await prisma.paymentLog.deleteMany({ where: { invoiceId: id } })

    const deletedInvoice = await prisma.invoice.delete({
      where: { id },
    })

    return NextResponse.json(deletedInvoice)
  } catch (error) {
    console.error('Error deleting invoice:', error)
    return NextResponse.json({ error: 'Failed to delete invoice' }, { status: 500 })
  }
}
