import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const clientId = searchParams.get('clientId')
    
    const invoices = await prisma.invoice.findMany({
      where: clientId ? { clientId } : undefined,
      include: { 
        client: true,
        case: true,
        items: true,
      },
      orderBy: { createdAt: 'desc' }
    })
    return NextResponse.json(invoices)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch invoices' }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const org = await prisma.organization.findFirst()
    if (!org) return NextResponse.json({ error: 'Org not found' }, { status: 400 })

    const invoice = await prisma.invoice.create({
      data: {
        organizationId: org.id,
        clientId: body.clientId,
        caseId: body.caseId && body.caseId !== 'none' ? body.caseId : null,
        invoiceNumber: body.invoiceNumber || `INV-${Date.now().toString().slice(-6)}`,
        issueDate: body.issueDate ? new Date(body.issueDate) : new Date(),
        dueDate: new Date(body.dueDate),
        totalAmount: parseFloat(body.totalAmount) || 0,
        status: body.status || 'draft',
        items: {
          create: (body.items || []).map((item: any) => ({
            description: item.description,
            amount: parseFloat(item.amount) || 0,
            quantity: parseInt(item.quantity) || 1,
          })),
        },
      },
      include: {
        items: true,
      },
    })
    return NextResponse.json(invoice)
  } catch (error) {
    console.error('Error creating invoice:', error)
    return NextResponse.json({ error: 'Failed to create invoice' }, { status: 500 })
  }
}
