import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

// GET /api/cases - جلب جميع القضايا من SQLite
export async function GET() {
  try {
    const cases = await prisma.legalCase.findMany({
      include: {
        client: true,
        assignedLawyer: true,
      },
      orderBy: {
        createdAt: 'desc',
      },
    })
    return NextResponse.json(cases)
  } catch (error) {
    console.error('Error fetching cases:', error)
    return NextResponse.json({ error: 'Failed to fetch cases' }, { status: 500 })
  }
}

// POST /api/cases - إضافة قضية جديدة للقاعدة الحقيقية
export async function POST(req: Request) {
  try {
    const body = await req.json()
    
    // لغرض التجربة المحلية، سنستخدم أول منظمة وأول مستخدم موجودين
    const org = await prisma.organization.findFirst()
    const lawyer = await prisma.user.findFirst()
    
    if (!org || !lawyer) {
      return NextResponse.json({ error: 'System not seeded. Please run seed script first.' }, { status: 400 })
    }

    const newCase = await prisma.legalCase.create({
      data: {
        organizationId: org.id,
        name: body.name,
        caseType: body.caseType,
        category: body.category,
        filingDate: new Date(body.filingDate),
        priority: body.priority,
        status: body.status,
        clientId: body.clientId,
        assignedLawyerId: lawyer.id,
        notes: body.notes || '',
      },
    })
    
    return NextResponse.json(newCase)
  } catch (error) {
    console.error('Error creating case:', error)
    return NextResponse.json({ error: 'Failed to create case' }, { status: 500 })
  }
}
