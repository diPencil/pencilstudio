import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

// PATCH /api/cases/[id] - تحديث قضية
export async function PATCH(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params
    const body = await req.json()

    const updatedCase = await prisma.legalCase.update({
      where: { id },
      data: {
        name: body.name,
        caseType: body.caseType,
        category: body.category,
        filingDate: body.filingDate ? new Date(body.filingDate) : undefined,
        priority: body.priority,
        status: body.status,
        clientId: body.clientId,
        assignedLawyerId: body.assignedLawyerId,
        courtName: body.courtName,
        caseNumber: body.caseNumber,
        circleNumber: body.circleNumber,
        notes: body.notes || '',
      },
    })

    return NextResponse.json(updatedCase)
  } catch (error) {
    console.error('Error updating case:', error)
    return NextResponse.json({ error: 'Failed to update case' }, { status: 500 })
  }
}

// DELETE /api/cases/[id] - حذف قضية
export async function DELETE(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    // حذف السجلات المرتبطة أولاً لتجنب مشاكل المفاتيح الخارجية في SQLite
    await prisma.caseHistory.deleteMany({ where: { caseId: id } })
    await prisma.caseTask.deleteMany({ where: { caseId: id } })
    await prisma.legalDocument.deleteMany({ where: { caseId: id } })
    await prisma.consultation.deleteMany({ where: { caseId: id } })
    await prisma.invoice.deleteMany({ where: { caseId: id } })

    const deletedCase = await prisma.legalCase.delete({
      where: { id },
    })

    return NextResponse.json(deletedCase)
  } catch (error) {
    console.error('Error deleting case:', error)
    return NextResponse.json({ error: 'Failed to delete case' }, { status: 500 })
  }
}
