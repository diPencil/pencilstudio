import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function PATCH(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params
    const body = await req.json()

    const updatedConsultation = await prisma.consultation.update({
      where: { id },
      data: {
        clientId: body.clientId,
        caseId: body.caseId || null,
        date: body.date ? new Date(body.date) : undefined,
        time: body.time,
        type: body.type,
        status: body.status,
        notes: body.notes || '',
        lawyerId: body.lawyerId,
      },
    })

    return NextResponse.json(updatedConsultation)
  } catch (error) {
    console.error('Error updating consultation:', error)
    return NextResponse.json({ error: 'Failed to update consultation' }, { status: 500 })
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    const deletedConsultation = await prisma.consultation.delete({
      where: { id },
    })

    return NextResponse.json(deletedConsultation)
  } catch (error) {
    console.error('Error deleting consultation:', error)
    return NextResponse.json({ error: 'Failed to delete consultation' }, { status: 500 })
  }
}
