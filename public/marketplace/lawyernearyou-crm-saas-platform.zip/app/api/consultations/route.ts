import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function GET() {
  try {
    const consultations = await prisma.consultation.findMany({
      include: {
        client: true,
        case: true,
        lawyer: true,
      },
      orderBy: {
        date: 'desc',
      },
    })
    return NextResponse.json(consultations)
  } catch (error) {
    console.error('❌ Detailed Error in /api/consultations:', error)
    return NextResponse.json({ error: 'Failed to fetch consultations' }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const org = await prisma.organization.findFirst()
    
    if (!org) {
      return NextResponse.json({ error: 'Org not found' }, { status: 400 })
    }

    const consultation = await prisma.consultation.create({
      data: {
        organizationId: org.id,
        clientId: body.clientId,
        caseId: body.caseId || null,
        date: new Date(body.date),
        time: body.time,
        type: body.type || 'initial',
        status: body.status || 'scheduled',
        notes: body.notes || '',
        lawyerId: body.lawyerId,
      },
    })
    
    return NextResponse.json(consultation)
  } catch (error) {
    console.error('Error creating consultation:', error)
    return NextResponse.json({ error: 'Failed to create consultation' }, { status: 500 })
  }
}
