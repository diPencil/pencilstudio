import type { Metadata } from 'next'
import { Geist, Geist_Mono, Cairo } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { LanguageProvider } from '@/lib/language-context'
import { TenantProvider } from '@/lib/tenant-context'
import './globals.css'

const _geist = Geist({ subsets: ["latin"] });
const _geistMono = Geist_Mono({ subsets: ["latin"] });
const cairo = Cairo({ subsets: ["arabic"], weight: ["400", "500", "600", "700"], variable: '--font-cairo' });

export const metadata: Metadata = {
  title: 'LawCRM - Legal Firm & Case Management Dashboard',
  description: 'Enterprise Legal CRM for managing case history, client files, court consultations, and document indexing. Features AI-powered legal research and discovery assistance.',
  generator: 'v0.app',
  icons: {
    icon: [
      { url: '/favicon-16x16.png', sizes: '16x16', type: 'image/png' },
      { url: '/favicon-32x32.png', sizes: '32x32', type: 'image/png' },
      { url: '/icon-512.png', sizes: '512x512', type: 'image/png' },
    ],
    apple: '/apple-touch-icon.png',
  },
  openGraph: {
    type: 'website',
    title: 'LawCRM - Professional Case & Firm Management',
    description: 'Enterprise Legal CRM for managing case history, client files, court consultations, and document indexing.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'LawCRM Dashboard Preview',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'LawCRM - Legal Practice & Case Discovery Dashboard',
    description: 'Empowering law firms with AI-driven case history tracking, client file management, and automated filing schedules.',
    images: ['/og-image.png'],
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${_geist.className} ${cairo.variable} antialiased`}>
        <LanguageProvider>
          <TenantProvider>
            {children}
            <Analytics />
          </TenantProvider>
        </LanguageProvider>
      </body>
    </html>
  )
}
