import { AppLayout } from '@/components/app-layout'
import { AnnouncementsContent } from '@/components/system/announcements-content'
export default function AnnouncementsPage() { return <AppLayout><AnnouncementsContent /></AppLayout> }
