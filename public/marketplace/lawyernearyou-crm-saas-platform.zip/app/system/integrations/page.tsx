import { AppLayout } from '@/components/app-layout'
import { IntegrationsContent } from '@/components/system/integrations-content'

export default function IntegrationsPage() {
    return (
        <AppLayout>
            <IntegrationsContent />
        </AppLayout>
    )
}
