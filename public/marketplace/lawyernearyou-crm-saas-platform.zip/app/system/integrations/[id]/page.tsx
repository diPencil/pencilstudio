import { AppLayout } from '@/components/app-layout'
import { IntegrationDetailsContent } from '@/components/system/integration-details-content'

export default async function IntegrationDetailsPage({ params }: { params: Promise<{ id: string }> }) {
    const { id } = await params

    return (
        <AppLayout>
            <IntegrationDetailsContent id={id} />
        </AppLayout>
    )
}
