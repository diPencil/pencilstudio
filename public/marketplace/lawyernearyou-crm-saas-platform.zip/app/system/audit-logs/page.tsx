import { AppLayout } from '@/components/app-layout'
import { AuditLogsContent } from '@/components/system/audit-logs-content'

export default function AuditLogsPage() {
    return (
        <AppLayout>
            <AuditLogsContent />
        </AppLayout>
    )
}
