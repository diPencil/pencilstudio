import { AppLayout } from '@/components/app-layout'
import { ActivityContent } from '@/components/system/activity-content'
export default function ActivityPage() { return <AppLayout><ActivityContent /></AppLayout> }
