'use client'

import { AppLayout } from '@/components/app-layout'
import { CasesContent } from '@/components/cases/cases-content'

export default function CasesPage() {
  return (
    <AppLayout breadcrumbs={[{ label: 'Cases' }]}>
      <CasesContent />
    </AppLayout>
  )
}
