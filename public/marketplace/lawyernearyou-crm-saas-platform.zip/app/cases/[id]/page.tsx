'use client'

import { use } from 'react'
import { AppLayout } from '@/components/app-layout'
import { CaseDetailContent } from '@/components/cases/case-detail-content'

interface CaseDetailPageProps {
  params: Promise<{ id: string }>
}

export default function CaseDetailPage({ params }: CaseDetailPageProps) {
  const { id } = use(params)

  return (
    <AppLayout breadcrumbs={[{ label: 'Cases', href: '/cases' }, { label: 'Case Details' }]}>
      <CaseDetailContent caseId={id} />
    </AppLayout>
  )
}
