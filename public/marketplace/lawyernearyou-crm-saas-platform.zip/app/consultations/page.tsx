'use client'

import { AppLayout } from '@/components/app-layout'
import { ConsultationsContent } from '@/components/consultations/consultations-content'

export default function ConsultationsPage() {
  return (
    <AppLayout breadcrumbs={[{ label: 'Consultations' }]}>
      <ConsultationsContent />
    </AppLayout>
  )
}
