'use client'

import { AppLayout } from '@/components/app-layout'
import { CaseHistoryContent } from '@/components/case-history/case-history-content'

export default function CaseHistoryPage() {
  return (
    <AppLayout breadcrumbs={[{ label: 'Case History & Filings' }]}>
      <CaseHistoryContent />
    </AppLayout>
  )
}
