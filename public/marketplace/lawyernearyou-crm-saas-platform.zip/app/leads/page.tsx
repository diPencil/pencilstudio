import { AppLayout } from '@/components/app-layout'
import { LeadsContent } from '@/components/crm/leads-content'

export default function LeadsPage() {
    return (
        <AppLayout>
            <LeadsContent />
        </AppLayout>
    )
}
