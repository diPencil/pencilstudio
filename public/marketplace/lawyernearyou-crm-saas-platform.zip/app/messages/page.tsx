import { AppLayout } from '@/components/app-layout'
import { MessagesContent } from '@/components/communications/messages-content'
export default function MessagesPage() { return <AppLayout><MessagesContent /></AppLayout> }
