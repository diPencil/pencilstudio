import { AppLayout } from '@/components/app-layout'
import { ExpensesContent } from '@/components/finance/expenses-content'
export default function ExpensesPage() { return <AppLayout><ExpensesContent /></AppLayout> }
