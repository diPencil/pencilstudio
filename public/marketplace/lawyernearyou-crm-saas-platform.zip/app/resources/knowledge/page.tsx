import { AppLayout } from '@/components/app-layout'
import { KnowledgeContent } from '@/components/resources/knowledge-content'

export default function KnowledgePage() {
    return (
        <AppLayout>
            <KnowledgeContent />
        </AppLayout>
    )
}
