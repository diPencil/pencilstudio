import React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { HelpCircle, BookOpen, MessageSquare, PlayCircle, ShieldCheck } from "lucide-react"

export default function HelpCenterPage() {
    return (
        <div className="p-4 md:p-6 space-y-6 max-w-5xl mx-auto">
            <div className="flex flex-col gap-2">
                <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
                    <HelpCircle className="size-8 text-primary" />
                    Help Center & Onboarding
                </h1>
                <p className="text-muted-foreground">Find guides, tutorials, and frequently asked questions about using your Firm Dashboard.</p>
            </div>

            <Tabs defaultValue="quick-start" className="w-full">
                <TabsList className="mb-4 bg-muted/50 p-1 w-full flex overflow-x-auto justify-start h-auto">
                    <TabsTrigger value="quick-start" className="flex-1 whitespace-nowrap"><PlayCircle className="size-4 mr-2" /> Quick Start Guide</TabsTrigger>
                    <TabsTrigger value="faq" className="flex-1 whitespace-nowrap"><MessageSquare className="size-4 mr-2" /> FAQs</TabsTrigger>
                    <TabsTrigger value="rbac" className="flex-1 whitespace-nowrap"><ShieldCheck className="size-4 mr-2" /> Roles & Permissions</TabsTrigger>
                </TabsList>

                <TabsContent value="quick-start">
                    <Card>
                        <CardHeader>
                            <CardTitle className="text-xl">Getting Started with LawCRM</CardTitle>
                            <CardDescription>Follow these 3 simple steps to set up your firm.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="grid gap-4 md:grid-cols-3">
                                <div className="flex flex-col gap-2 p-4 border rounded-xl bg-muted/20">
                                    <div className="size-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">1</div>
                                    <h3 className="font-semibold text-lg">Add Your Clients</h3>
                                    <p className="text-sm text-muted-foreground">Go to the Clients page and start adding your client's basic information and national IDs.</p>
                                </div>
                                <div className="flex flex-col gap-2 p-4 border rounded-xl bg-muted/20">
                                    <div className="size-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">2</div>
                                    <h3 className="font-semibold text-lg">Create a Case Profile</h3>
                                    <p className="text-sm text-muted-foreground">Link a client to a new active case. You can then add documents, view history, and assign tasks.</p>
                                </div>
                                <div className="flex flex-col gap-2 p-4 border rounded-xl bg-muted/20">
                                    <div className="size-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">3</div>
                                    <h3 className="font-semibold text-lg">Schedule & Bill</h3>
                                    <p className="text-sm text-muted-foreground">Use the consultations calendar to block time, and the billing module to generate invoices.</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="faq">
                    <Card>
                        <CardHeader>
                            <CardTitle>Frequently Asked Questions</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <Accordion type="single" collapsible className="w-full">
                                <AccordionItem value="item-1">
                                    <AccordionTrigger>How do I export case summaries?</AccordionTrigger>
                                    <AccordionContent>
                                        You can navigate to the specific case detail page and click on the "Export Summary (PDF)" button in the top right corner.
                                    </AccordionContent>
                                </AccordionItem>
                                <AccordionItem value="item-2">
                                    <AccordionTrigger>Who can see the Financial Reports?</AccordionTrigger>
                                    <AccordionContent>
                                        Only users with the Administrator or Accountant roles can view full financial dashboards and access the Monthly Financial Reports within the Billing section.
                                    </AccordionContent>
                                </AccordionItem>
                                <AccordionItem value="item-3">
                                    <AccordionTrigger>Can I link a consultation directly to a case?</AccordionTrigger>
                                    <AccordionContent>
                                        Yes, when scheduling a new consultation or court hearing via the Calendar View Quick Schedule button, you can assign it directly to a legal case.
                                    </AccordionContent>
                                </AccordionItem>
                            </Accordion>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="rbac">
                    <Card>
                        <CardHeader>
                            <CardTitle>Role-Based Access Control (RBAC)</CardTitle>
                            <CardDescription>Understanding what different team members can see.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="space-y-4">
                                <div className="border p-4 rounded-lg">
                                    <h4 className="font-bold flex items-center gap-2"><span className="w-3 h-3 rounded-full bg-blue-500"></span> Admin</h4>
                                    <p className="text-sm text-muted-foreground mt-1">Has full access to all features including billing, firm settings, AI configuration, and all client records.</p>
                                </div>
                                <div className="border p-4 rounded-lg">
                                    <h4 className="font-bold flex items-center gap-2"><span className="w-3 h-3 rounded-full bg-green-500"></span> Accountant</h4>
                                    <p className="text-sm text-muted-foreground mt-1">Can access billing, issue invoices, view payment logs, and export monthly financial reports. Cannot edit case history.</p>
                                </div>
                                <div className="border p-4 rounded-lg">
                                    <h4 className="font-bold flex items-center gap-2"><span className="w-3 h-3 rounded-full bg-purple-500"></span> Lawyer / Helper</h4>
                                    <p className="text-sm text-muted-foreground mt-1">Can view assigned cases, schedule consultations, and log case history. Restricted from viewing full firm revenue.</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    )
}
