import { AppLayout } from '@/components/app-layout'
import { KanbanBoard } from '@/components/tasks/kanban-board'

export default function KanbanPage() {
    return (
        <AppLayout>
            <KanbanBoard />
        </AppLayout>
    )
}
