import { AppLayout } from '@/components/app-layout'
import { CalendarContent } from '@/components/tasks/calendar-content'

export default function CalendarPage() {
    return (
        <AppLayout>
            <CalendarContent />
        </AppLayout>
    )
}
