import { AppLayout } from '@/components/app-layout'
import { BranchesContent } from '@/components/management/branches-content'
export default function BranchesPage() { return <AppLayout><BranchesContent /></AppLayout> }
