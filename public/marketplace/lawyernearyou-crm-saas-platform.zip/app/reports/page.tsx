import { AppLayout } from '@/components/app-layout'
import { ReportsContent } from '@/components/management/reports-content'
export default function ReportsPage() { return <AppLayout><ReportsContent /></AppLayout> }
