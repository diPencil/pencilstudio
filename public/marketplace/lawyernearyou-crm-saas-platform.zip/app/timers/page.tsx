import { AppLayout } from '@/components/app-layout'
import { TimersContent } from '@/components/legal/timers-content'
export default function TimersPage() { return <AppLayout><TimersContent /></AppLayout> }
