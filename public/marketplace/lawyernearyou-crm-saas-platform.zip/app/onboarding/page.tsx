'use client'

import React, { useState } from 'react'
import { useRouter } from 'next/navigation'
import { CheckCircle2, ChevronRight, ChevronLeft, CreditCard, Building2, UserCircle, ShieldAlert, Mail, Lock, Info, Rocket, ShieldCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import Link from 'next/link'

import { useLanguage } from '@/lib/language-context'

export default function OnboardingPage() {
    const { t, language } = useLanguage()
    const router = useRouter()
    const [step, setStep] = useState(1)
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        firmName: '',
        subdomain: '',
        plan: 'pro'
    })
    const [isSubmitting, setIsSubmitting] = useState(false)

    const nextStep = () => setStep(prev => Math.min(prev + 1, 3))
    const prevStep = () => setStep(prev => Math.max(prev - 1, 1))

    const handleComplete = () => {
        setIsSubmitting(true)
        setTimeout(() => {
            // Simulate API call and redirect
            router.push('/')
        }, 1500)
    }

    // Removed generateSubdomain as it's not used in the new snippet for subdomain generation logic

    return (
        <div className="min-h-screen bg-slate-50 flex flex-col items-center py-12 px-4">
            <div className="max-w-2xl w-full">
                <div className="text-center mb-10">
                    <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">{t('onboarding.title')}</h1>
                </div>

                {/* Progress Bar */}
                <div className="mb-8 relative">
                    <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-primary/20">
                        <div style={{ width: `${(step / 3) * 100}%` }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-primary transition-all duration-500"></div>
                    </div>
                    <div className="flex justify-between text-xs font-semibold text-muted-foreground">
                        <span className={step >= 1 ? 'text-primary' : ''}>1. {t('onboarding.step1')}</span>
                        <span className={step >= 2 ? 'text-primary' : ''}>2. {t('onboarding.step2')}</span>
                        <span className={step >= 3 ? 'text-primary' : ''}>3. {t('onboarding.step3')}</span>
                    </div>
                </div>

                <Card className="border-none shadow-xl bg-white/80 backdrop-blur-sm">
                    <CardHeader className="pb-4">
                        <CardTitle className="text-2xl font-bold">
                            {step === 1 && t('onboarding.adminTitle')}
                            {step === 2 && (language === 'ar' ? 'بيانات مكتب المحاماة' : 'Your Legal Firm Details')}
                            {step === 3 && (language === 'ar' ? 'بدء التجربة المجانية لمدة 14 يوماً' : 'Start your Free 14-Day Trial')}
                        </CardTitle>
                        <CardDescription>
                            {step === 1 && t('onboarding.adminDesc')}
                            {step === 2 && (language === 'ar' ? 'سيؤدي هذا إلى إنشاء مساحة عمل معزولة لفريقك القانوني بالكامل.' : 'This will create an isolated (multi-tenant) workspace for your entire legal team.')}
                            {step === 3 && (language === 'ar' ? 'لا يوجد التزام مطلوب. يمكنك الإلغاء في أي وقت.' : "No commitment required. Cancel anytime.")}
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        {step === 1 && (
                            <div className="space-y-4 pt-2 animate-in fade-in slide-in-from-right-4 duration-500">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2 text-start">
                                        <Label htmlFor="firstName">{t('onboarding.firstName')}</Label>
                                        <Input
                                            id="firstName"
                                            placeholder="Ahmed"
                                            value={formData.firstName}
                                            onChange={e => setFormData({ ...formData, firstName: e.target.value })}
                                        />
                                    </div>
                                    <div className="space-y-2 text-start">
                                        <Label htmlFor="lastName">{t('onboarding.lastName')}</Label>
                                        <Input
                                            id="lastName"
                                            placeholder="Mahmoud"
                                            value={formData.lastName}
                                            onChange={e => setFormData({ ...formData, lastName: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div className="space-y-2 text-start">
                                    <Label htmlFor="email">{t('onboarding.email')}</Label>
                                    <div className="relative">
                                        <Mail className={`absolute ${language === 'ar' ? 'right-3' : 'left-3'} top-3 size-4 text-muted-foreground`} />
                                        <Input
                                            id="email"
                                            type="email"
                                            className={language === 'ar' ? 'pr-10' : 'pl-10'}
                                            placeholder="ahmed@lawcrm.com"
                                            value={formData.email}
                                            onChange={e => setFormData({ ...formData, email: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div className="space-y-2 text-start">
                                    <Label htmlFor="password">{t('onboarding.password')}</Label>
                                    <div className="relative">
                                        <Lock className={`absolute ${language === 'ar' ? 'right-3' : 'left-3'} top-3 size-4 text-muted-foreground`} />
                                        <Input
                                            id="password"
                                            type="password"
                                            className={language === 'ar' ? 'pr-10' : 'pl-10'}
                                            value={formData.password}
                                            onChange={e => setFormData({ ...formData, password: e.target.value })}
                                        />
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Step 2: Workspace Setup */}
                        {step === 2 && (
                            <div className="space-y-4 pt-2 animate-in fade-in slide-in-from-right-4 duration-500">
                                <div className="space-y-2 text-start">
                                    <Label htmlFor="firmName">{language === 'ar' ? 'اسم مكتب المحاماة' : 'Law Firm Name'}</Label>
                                    <div className="relative">
                                        <Building2 className={`absolute ${language === 'ar' ? 'right-3' : 'left-3'} top-3 size-4 text-muted-foreground`} />
                                        <Input
                                            id="firmName"
                                            className={language === 'ar' ? 'pr-10' : 'pl-10'}
                                            placeholder={language === 'ar' ? 'مكتب النجار للمحاماة' : "El-Nagar Law Office"}
                                            value={formData.firmName}
                                            onChange={e => {
                                                const newName = e.target.value;
                                                setFormData({ ...formData, firmName: newName })
                                            }}
                                        />
                                    </div>
                                </div>
                                <div className="space-y-2 text-start">
                                    <Label htmlFor="subdomain">{language === 'ar' ? 'عنوان مساحة العمل (URL)' : 'Workspace Subdomain URL'}</Label>
                                    <div className="flex gap-1 items-center">
                                        <Input
                                            id="subdomain"
                                            placeholder="nari-law"
                                            className="max-w-[200px]"
                                            value={formData.subdomain}
                                            onChange={e => setFormData({ ...formData, subdomain: e.target.value })}
                                        />
                                        <span className="text-sm font-medium text-muted-foreground">.lawcrm.com</span>
                                    </div>
                                    <p className="text-xs text-muted-foreground">{language === 'ar' ? 'هذا هو رابط الدخول الخاص بمكتبك. جميع بياناتك معزولة تماماً.' : "This is your firm's private login portal. All tenant data is fully isolated."}</p>
                                </div>
                            </div>
                        )}

                        {/* Step 3: Checkout */}
                        {step === 3 && (
                            <div className="space-y-6 pt-2 animate-in fade-in slide-in-from-right-4 duration-500 text-start">
                                <div className="rounded-xl border p-4 bg-muted/30">
                                    <div className="flex justify-between items-center mb-2">
                                        <span className="font-bold text-lg">{language === 'ar' ? 'باقة Pro (الاحترافية)' : 'Pro Plan'}</span>
                                        <Badge className="bg-primary">{language === 'ar' ? 'مساحة عمل SaaS' : 'SaaS Instance'}</Badge>
                                    </div>
                                    <div className="flex items-baseline gap-1">
                                        <span className="text-3xl font-extrabold">0</span>
                                        <span className="text-muted-foreground">EGP / {language === 'ar' ? 'أول 14 يوم' : 'first 14 days'}</span>
                                    </div>
                                </div>

                                <div className="space-y-3">
                                    <div className="flex items-center gap-2 text-sm text-slate-600">
                                        <CheckCircle2 className="size-4 text-primary" />
                                        <span>{language === 'ar' ? 'تفعيل فوري لمساحة العمل' : 'Instant workspace activation'}</span>
                                    </div>
                                    <div className="flex items-center gap-2 text-sm text-slate-600">
                                        <CheckCircle2 className="size-4 text-primary" />
                                        <span>{language === 'ar' ? 'مستخدمين غير محدودين للتجربة' : 'Unlimited users during trial'}</span>
                                    </div>
                                    <div className="flex items-center gap-2 text-sm text-slate-600">
                                        <ShieldCheck className="size-4 text-primary" />
                                        <span>{language === 'ar' ? 'بيانات مشفرة ومعزولة' : 'Encrypted & Isolated data'}</span>
                                    </div>
                                </div>

                                <div className="bg-slate-100 p-4 rounded-lg flex items-start gap-3 mt-4">
                                    <CreditCard className="size-5 text-slate-500 mt-0.5 shrink-0" />
                                    <div>
                                        <p className="text-sm font-semibold">{language === 'ar' ? 'بدء تجربة مجانية لمدة 14 يومًا' : 'Start free 14-day trial'}</p>
                                        <p className="text-xs text-muted-foreground mt-1">
                                            {language === 'ar'
                                                ? 'لن يتم الخصم إلا بعد انتهاء الفترة التجريبية. سنرسل لك تذكيراً قبل 3 أيام.'
                                                : "You won't be charged until the trial ends. We'll send you a reminder 3 days before."}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}
                    </CardContent>
                    <CardFooter className="flex justify-between pt-6 border-t">
                        {step > 1 ? (
                            <Button variant="ghost" onClick={prevStep} className="gap-2">
                                <ChevronRight className={`size-4 ${language === 'ar' ? '' : 'rotate-180'}`} /> {t('onboarding.back')}
                            </Button>
                        ) : (
                            <div></div>
                        )}
                        {step < 3 ? (
                            <Button
                                onClick={nextStep}
                                className="px-8 font-bold gap-2"
                            >
                                {t('onboarding.next')}
                                <ChevronRight className={`size-4 ${language === 'ar' ? 'rotate-180' : ''}`} />
                            </Button>
                        ) : (
                            <Button onClick={handleComplete} disabled={isSubmitting} className="px-8 font-bold gap-2">
                                {isSubmitting ? t('onboarding.provisioning') : t('onboarding.complete')}
                                {!isSubmitting && <Rocket className="size-4" />}
                            </Button>
                        )}
                    </CardFooter>
                </Card>

                <p className="text-center text-xs text-muted-foreground mt-6">
                    {t('onboarding.terms')
                        .replace('{terms}', `<a href="#" class="underline hover:text-primary">${t('onboarding.tos')}</a>`)
                        .replace('{dpa}', `<a href="#" class="underline hover:text-primary">${t('onboarding.dpa')}</a>`)
                        .split(/(<a.*<\/a>)/).map((part, i) => {
                            if (part.startsWith('<a')) {
                                const isTos = part.includes('onboarding.tos') || part.includes(t('onboarding.tos'))
                                return (
                                    <a key={i} href="#" className="underline hover:text-primary">
                                        {isTos ? t('onboarding.tos') : t('onboarding.dpa')}
                                    </a>
                                )
                            }
                            return part
                        })
                    }
                </p>
            </div>
        </div >
    )
}
