'use client'

import { use } from 'react'
import { AppLayout } from '@/components/app-layout'
import { ClientDetailContent } from '@/components/clients/client-detail-content'

interface ClientDetailPageProps {
  params: Promise<{ id: string }>
}

export default function ClientDetailPage({ params }: ClientDetailPageProps) {
  const { id } = use(params)

  return (
    <AppLayout breadcrumbs={[{ label: 'Clients', href: '/clients' }, { label: 'Client Details' }]}>
      <ClientDetailContent clientId={id} />
    </AppLayout>
  )
}
