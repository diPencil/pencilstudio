'use client'

import { AppLayout } from '@/components/app-layout'
import { ClientsContent } from '@/components/clients/clients-content'

export default function ClientsPage() {
  return (
    <AppLayout breadcrumbs={[{ label: 'Clients' }]}>
      <ClientsContent />
    </AppLayout>
  )
}
