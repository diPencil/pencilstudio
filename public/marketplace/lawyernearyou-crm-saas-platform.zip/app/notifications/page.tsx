import { AppLayout } from '@/components/app-layout'
import { NotificationsContent } from '@/components/core/notifications-content'
export default function NotificationsPage() { return <AppLayout><NotificationsContent /></AppLayout> }
