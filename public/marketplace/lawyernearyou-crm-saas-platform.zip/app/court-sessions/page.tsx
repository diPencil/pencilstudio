import { AppLayout } from '@/components/app-layout'
import { CourtSessionsContent } from '@/components/legal/court-sessions-content'
export default function CourtSessionsPage() { return <AppLayout><CourtSessionsContent /></AppLayout> }
