import { AppLayout } from '@/components/app-layout'
import { ContractsContent } from '@/components/crm/contracts-content'
export default function ContractsPage() { return <AppLayout><ContractsContent /></AppLayout> }
