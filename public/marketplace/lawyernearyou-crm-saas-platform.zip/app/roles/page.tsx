import { AppLayout } from '@/components/app-layout'
import { RolesContent } from '@/components/management/roles-content'
export default function RolesPage() { return <AppLayout><RolesContent /></AppLayout> }
