'use client'

import React, { useState } from 'react'
import { CheckCircle2, ChevronRight, Calculator, Globe, Building2, Users, Rocket, Zap, ShieldCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import Link from 'next/link'

import { useLanguage } from '@/lib/language-context'

export default function PricingPage() {
    const { t, language } = useLanguage()
    const [isAnnual, setIsAnnual] = useState(false)
    const [currency, setCurrency] = useState<'EGP' | 'USD'>('EGP')

    const plans = [
        {
            name: language === 'ar' ? 'الأساسية / Starter' : 'Starter',
            description: language === 'ar' ? 'مثالية للمحامين الممارسين المستقلين والمكاتب الصغيرة.' : 'Perfect for solo practitioners and small law offices.',
            icon: <Users className="size-6 text-blue-500" />,
            monthlyPrice: { EGP: 999, USD: 29 },
            annualPrice: { EGP: 8990, USD: 290 },
            features: language === 'ar' ? [
                'حتى 3 مستخدمين (محامين/مساعدين)',
                'حد القضايا النشطة (50/شهر)',
                'إصدار فواتير ومطالبات بسيطة',
                'مساحة تخزين قياسية (10 جيجابايت)',
                'دعم عبر البريد الإلكتروني',
            ] : [
                'Up to 3 Users (Lawyers/Assistants)',
                'Active Cases limitation (50/mo)',
                'Basic Invoicing & Billing',
                'Standard Document Storage (10 GB)',
                'Email Support',
            ],
            ctaText: t('pricing.startTrial'),
            popular: false,
        },
        {
            name: language === 'ar' ? 'الاحترافية / Pro' : 'Pro',
            description: language === 'ar' ? 'مثالية لمكاتب المحاماة متوسطة الحجم الطموحة.' : 'Ideal for growing mid-sized law firms.',
            icon: <Rocket className="size-6 text-indigo-500" />,
            monthlyPrice: { EGP: 2499, USD: 79 },
            annualPrice: { EGP: 22490, USD: 790 },
            features: language === 'ar' ? [
                'حتى 10 مستخدمين',
                'قضايا نشطة غير محدودة',
                'محرك فوترة واشتراكات متقدم',
                'مساحة تخزين موسعة (100 جيجابايت)',
                'تكامل مع تقويم جوجل',
                'بوابة عملاء وتذكيرات تلقائية',
                'دعم هاتفي ذو أولوية',
            ] : [
                'Up to 10 Users',
                'Unlimited Active Cases',
                'Advanced Billing & Subscription Engine',
                'Extended Storage (100 GB)',
                'Google Calendar Integration',
                'Client Portal & Auto Reminders',
                'Priority Phone Support',
            ],
            ctaText: language === 'ar' ? 'ترقية إلى Pro' : 'Upgrade to Pro',
            popular: true,
        },
        {
            name: language === 'ar' ? 'المؤسسات / Enterprise' : 'Enterprise',
            description: language === 'ar' ? 'حلول مخصصة للفرق القانونية الكبيرة والشركات.' : 'Tailored solutions for large corporate legal teams.',
            icon: <ShieldCheck className="size-6 text-purple-500" />,
            priceDisplay: language === 'ar' ? 'مخصص' : 'Custom',
            features: language === 'ar' ? [
                'مستخدمين غير محدودين',
                'مساحة تخزين وقضايا غير محدودة',
                'هوية مخصصة (نطاق خاص)',
                'دخول موحد (SSO) للأمان',
                'تحليلات متقدمة ووصول للـ API',
                'مدير نجاح عملاء مخصص',
                'عقود وإعداد مخصص للمنشأة',
            ] : [
                'Unlimited Users',
                'Unlimited Storage & Cases',
                'White-label Branding (Custom Domain)',
                'SSO (SAML/OAuth) for Security',
                'Advanced Analytics & API Access',
                'Dedicated Customer Success Manager',
                'Custom Contract & Onboarding',
            ],
            ctaText: language === 'ar' ? 'اتصل بالمبيعات' : 'Contact Sales',
            popular: false,
        }
    ]

    return (
        <div className="min-h-screen bg-slate-50/50 flex flex-col items-center py-16 px-4 md:px-8">
            {/* Header */}
            <div className="text-center max-w-3xl mb-12 space-y-4">
                <Badge variant="outline" className="border-primary text-primary px-3 py-1 mb-4">
                    LawCRM SaaS
                </Badge>
                <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight">
                    {t('pricing.title')}
                </h1>
                <p className="text-lg md:text-xl text-muted-foreground">
                    {t('pricing.desc')}
                </p>

                {/* Toggles */}
                <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mt-8 p-4 bg-white rounded-2xl shadow-sm border mx-auto max-w-fit">
                    <div className="flex items-center space-x-2">
                        <Label htmlFor="currency-mode" className="text-sm font-medium cursor-pointer" onClick={() => setCurrency('EGP')}>EGP (مصر)</Label>
                        <Switch
                            id="currency-mode"
                            checked={currency === 'USD'}
                            onCheckedChange={(checked) => setCurrency(checked ? 'USD' : 'EGP')}
                        />
                        <Label htmlFor="currency-mode" className="text-sm font-medium cursor-pointer" onClick={() => setCurrency('USD')}>USD (Global)</Label>
                    </div>

                    <div className="hidden sm:block w-px h-8 bg-border"></div>

                    <div className="flex items-center space-x-2">
                        <Label htmlFor="annual-mode" className="text-sm font-medium cursor-pointer" onClick={() => setIsAnnual(false)}>{t('pricing.monthly')}</Label>
                        <Switch
                            id="annual-mode"
                            checked={isAnnual}
                            onCheckedChange={setIsAnnual}
                        />
                        <Label htmlFor="annual-mode" className="text-sm font-medium cursor-pointer flex items-center gap-1" onClick={() => setIsAnnual(true)}>
                            {t('pricing.annually')} <Badge className="bg-green-100 text-green-700 hover:bg-green-100 px-1.5 py-0 text-[10px]">{t('pricing.save')}</Badge>
                        </Label>
                    </div>
                </div>
            </div>

            {/* Pricing Cards */}
            <div className="grid md:grid-cols-3 gap-8 max-w-6xl w-full">
                {plans.map((plan) => {
                    const price = plan.priceDisplay ? plan.priceDisplay :
                        (isAnnual ? plan.annualPrice?.[currency] : plan.monthlyPrice?.[currency])

                    return (
                        <Card key={plan.name} className={`relative flex flex-col ${plan.popular ? 'border-primary shadow-lg scale-105' : 'border-border'}`}>
                            {plan.popular && (
                                <div className="absolute top-0 inset-x-0 transform -translate-y-1/2 flex justify-center">
                                    <Badge className="bg-primary text-primary-foreground uppercase tracking-widest text-xs px-3 py-1 font-bold">
                                        {t('pricing.popular')}
                                    </Badge>
                                </div>
                            )}

                            <CardHeader className="text-center pt-8 pb-4">
                                <div className="mx-auto flex size-12 items-center justify-center rounded-full bg-muted/50 mb-4">
                                    {plan.icon}
                                </div>
                                <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                                <CardDescription className="h-10 text-sm mt-2">{plan.description}</CardDescription>
                            </CardHeader>

                            <CardContent className="flex-1 flex flex-col text-center">
                                <div className="my-6">
                                    {plan.priceDisplay ? (
                                        <span className="text-4xl font-extrabold">{plan.priceDisplay}</span>
                                    ) : (
                                        <div className="flex items-center justify-center gap-1">
                                            <span className="text-2xl font-semibold text-muted-foreground mr-1">
                                                {currency === 'EGP' ? 'EGP' : '$'}
                                            </span>
                                            <span className="text-5xl font-extrabold">{price?.toLocaleString()}</span>
                                            <span className="text-muted-foreground">/{isAnnual ? (language === 'ar' ? 'سنة' : 'yr') : (language === 'ar' ? 'شهر' : 'mo')}</span>
                                        </div>
                                    )}
                                    {isAnnual && !plan.priceDisplay && (
                                        <p className="text-sm text-green-600 font-medium mt-2">{language === 'ar' ? 'فاتورة سنوية' : 'Billed annually'}</p>
                                    )}
                                </div>

                                <div className="space-y-4 text-left border-t pt-6">
                                    <p className="text-sm font-semibold uppercase text-muted-foreground tracking-wider mb-4">{t('pricing.included')}</p>
                                    {plan.features.map((feature) => (
                                        <div key={feature} className="flex items-start gap-3">
                                            <CheckCircle2 className="size-5 text-primary shrink-0" />
                                            <span className="text-sm leading-tight text-foreground/80">{feature}</span>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>

                            <CardFooter className="mt-auto pt-6">
                                <Button
                                    asChild
                                    className={`w-full h-12 text-md font-bold ${plan.popular ? '' : 'bg-muted-foreground/10 hover:bg-muted-foreground/20 text-foreground'}`}
                                    variant={plan.popular ? 'default' : 'secondary'}
                                >
                                    <Link href="/onboarding">
                                        {plan.ctaText} <ChevronRight className="size-4 ml-1" />
                                    </Link>
                                </Button>
                            </CardFooter>
                        </Card>
                    )
                })}
            </div>

            {/* Trust Badges */}
            <div className="mt-20 text-center space-y-6 max-w-2xl">
                <p className="text-sm font-medium text-muted-foreground uppercase tracking-widest">{language === 'ar' ? 'موثوق به لدى أكثر من 50 مكتب محاماة في مصر والشرق الأوسط' : 'Trusted by 50+ Law Firms in Egypt & MENA'}</p>
                <div className="flex flex-wrap justify-center gap-8 opacity-50 grayscale">
                    {/* Mock Logos */}
                    <div className="flex items-center gap-2 font-bold text-xl"><Globe className="size-6" /> EL-NAGAR LAW</div>
                    <div className="flex items-center gap-2 font-bold text-xl"><Zap className="size-6" /> JUSTICE LEAGUE</div>
                    <div className="flex items-center gap-2 font-bold text-xl"><ShieldCheck className="size-6" /> MENA LEGAL</div>
                </div>
            </div>
        </div>
    )
}
