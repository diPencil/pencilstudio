const { PrismaClient } = require('@prisma/client')
const prisma = new PrismaClient()

async function main() {
  // 1. Create a Default Organization (Firm)
  const org = await prisma.organization.upsert({
    where: { clerkId: 'org_demo' },
    update: {},
    create: {
      clerkId: 'org_demo',
      name: 'LawCRM Enterprise Firm',
    },
  })

  // 2. Create a Default User (Lawyer)
  const lawyer = await prisma.user.upsert({
    where: { email: 'admin@lawcrm.com' },
    update: {},
    create: {
      clerkId: 'user_demo',
      organizationId: org.id,
      name: 'أحمد محمود',
      email: 'admin@lawcrm.com',
      role: 'admin',
    },
  })

  // 3. Create a Client
  const client = await prisma.client.create({
    data: {
      organizationId: org.id,
      firstName: 'محمد',
      lastName: 'علي',
      email: 'm.ali@email.com',
      phone: '01012345678',
      address: 'القاهرة، مصر',
    }
  })

  // 4. Create a Case
  await prisma.legalCase.create({
    data: {
      organizationId: org.id,
      name: 'قضية تعويضات عقارية',
      caseType: 'civil',
      category: 'عقارات',
      filingDate: new Date(),
      priority: 'high',
      status: 'active',
      clientId: client.id,
      assignedLawyerId: lawyer.id,
      notes: 'قضية هامة تتعلق بنزاع على أرض في التجمع الخامس.',
    }
  })

  console.log('✅ Database Seeded Successfully!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
