import { PrismaClient } from '@prisma/client'
import { PrismaBetterSqlite3 } from '@prisma/adapter-better-sqlite3'

const url = process.env.DATABASE_URL || 'file:./dev.db'
const adapter = new PrismaBetterSqlite3({ url })
const prisma = new PrismaClient({ adapter })

async function main() {
  console.log('🚀 بدأنا عملية ربط البيانات الحقيقية...')

  // 1. إنشاء المكتب
  const org = await prisma.organization.upsert({
    where: { clerkId: 'org_demo' },
    update: {},
    create: {
      clerkId: 'org_demo',
      name: 'مجموعة قاسم وماجد للمحاماة',
    },
  })

  // 2. إنشاء المدير المستخدِم
  const lawyer = await prisma.user.upsert({
    where: { email: 'admin@lawcrm.com' },
    update: {},
    create: {
      clerkId: 'user_demo',
      organizationId: org.id,
      name: 'أحمد محمود',
      email: 'admin@lawcrm.com',
      role: 'admin',
    },
  })

  // 3. إضافة بيانات عميل
  const client = await prisma.client.create({
    data: {
      organizationId: org.id,
      firstName: 'محمد',
      lastName: 'علي',
      email: 'm.ali@email.com',
      phone: '01012345678',
      address: 'القاهرة، مصر',
    }
  })

  // 4. إضافة أول قضية في الداتابيز
  await prisma.legalCase.create({
    data: {
      organizationId: org.id,
      name: 'نزاع عقاري - التجمع الخامس',
      caseType: 'civil',
      category: 'عقارات',
      filingDate: new Date(),
      priority: 'high',
      status: 'active',
      clientId: client.id,
      assignedLawyerId: lawyer.id,
      notes: 'تم تفعيل قاعدة البيانات بنجاح والحفظ في ملف dev.db',
    }
  })

  console.log('✅ ممتاز! الداتابيز اشتغلت كملف محلي عندك حالياً.')
}

main()
  .catch((e) => {
    console.error('❌ خطأ في الاتصال:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
