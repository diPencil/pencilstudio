# LawCRM - Enterprise Legal Case Management System

A comprehensive CRM solution for modern law firms, designed to streamline case management, client relations, and legal research. Built with Next.js, Tailwind CSS, and shadcn/ui.

## ⚖️ Features

### Dashboard
- Key performance metrics (active cases, billable hours, upcoming hearings)
- Recent consultations and filing snapshots
- Quick action menu for common firm tasks

### Case Management
- Full lifecycle tracking for legal cases (Civil, Criminal, Corporate, etc.)
- Advanced filtering and status management (Active, Pending, Won, Settled, Closed)
- Detailed case profiles with complete filing history
- Direct linkage between cases and clients

### Client Directory
- Centralized client database with instantaneous search
- Relationship mapping between clients, cases, and associated counsel
- Communication logs and integrated case notes

### Legal Consultations
- Schedule hearings, trials, and client strategy sessions
- Real-time status tracking (Scheduled, In Progress, Completed, Adjourned)
- Conflict check integration for new consultations

### Case History & Filings
- Master repository for all legal records and filings
- Categorize by Evidence, Filing, Mediation, Settlement, and Judgments
- Chronological tracking for audit compliance

### Unified Legal Intelligence (AI Assistant)
- Built-in AI research partner powered by Vercel AI SDK
- Domain-specific knowledge for discovery, drafting, and case summaries
- Secure context handling for firm-specific data indexing
- Multi-model support with precise response controls

## 🛠️ Tech Stack

- **Framework**: Next.js 15 (App Router)
- **Styling**: Tailwind CSS v4 (Glassmorphism & High-End Design)
- **UI Components**: shadcn/ui
- **State Management**: SWR
- **AI Engine**: Vercel AI SDK with Unified Gateway
- **Icons**: Lucide React (Legal/Professional Set)

## 📁 Project Structure

```
/app
  /api/chat          # AI Legal Partner API
  /consultations     # Hearing & Meeting management
  /assistant         # AI Assistant research lab
  /case-history      # Filings & Records repository
  /clients           # Client database
    /[id]            # Client detail view
  /cases             # Case management
    /[id]            # Case detail view
  /settings          # Firm & Environment settings
  page.tsx           # Dashboard Command Center

/components
  /consultations     # Consultation components
  /assistant         # AI research components
  /dashboard         # Analytics & Overview components
  /case-history      # Filing & Evidence components
  /clients           # Client management components
  /cases             # Case tracking components
  /settings          # Configuration components
  /ui                # UI primitives (shadcn)
  app-header.tsx     # Breadcrumb navigation
  app-layout.tsx     # Enterprise layout wrapper
  app-sidebar.tsx    # Firm-wide navigation
  mobile-nav.tsx     # Mobile command interface

/lib
  data-store.ts      # Multi-tenant simulated data store
  mock-data.ts       # Legal domain sample data
  types.ts           # Enterprise TypeDefinitions
  utils.ts           # Performance utilities
```

## 🚀 Getting Started

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Boot the firm environment:
   ```bash
   npm run dev
   ```
4. Access the command center at [http://localhost:3000](http://localhost:3000)

## 🔒 Security & Data Persistence

LawCRM currently operates with an ephemeral demo engine. For production deployment:
1. Link a PostgreSQL instance (e.g., Supabase or Neon) via Vercel env
2. Migrate UI queries in `/lib/data-store.ts` to secure SQL transactions
3. Configure RBAC (Role-Based Access Control) for sensitive document access

## 📝 License

MIT - Enterprise Edition
