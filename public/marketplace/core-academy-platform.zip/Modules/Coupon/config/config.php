<?php

return [
    'name' => 'Coupon',
];
