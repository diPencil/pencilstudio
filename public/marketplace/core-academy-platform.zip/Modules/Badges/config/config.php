<?php

return [
    'name' => 'Badges',
];
