<?php

return [
    'name' => 'ContactMessage',
];
