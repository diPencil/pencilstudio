<th {{ $attributes }}>
    {{ $slot }}
</th>
