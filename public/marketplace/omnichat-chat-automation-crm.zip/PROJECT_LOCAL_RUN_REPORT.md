# OmniChat CRM - Local Run & Inspection Report

## Project Overview
OmniChat-CRM is a powerful customer relationship management (CRM) system designed for multi-channel communication (primarily focusing on WhatsApp Integration using Baileys/Meta API). It is an Express-based Node.js backend combined with a pre-built React frontend, supporting functionalities like chatbots, agent chat assignments, broadcast campaigns (templates, custom variables), contact/phonebook management, and loop automation (warmers, campaigns).

---

## Folder Structure Explanation
- **`database/`**: Contains database configs, promise-wrapper query helpers, and the database schema dump (`import.sql`).
- **`routes/`**: API endpoints grouped by modules:
  - `user.js` (User auth, billing, subscription, profile)
  - `admin.js` (System stats, global config, user lists)
  - `agent.js` (Agent profiles, task assignments, chat permissions)
  - `inbox.js` (Messaging, chats retrieval)
  - `chatbot.js`, `chatFlow.js` (Interactive automated chat replies/builder logic)
  - `broadcast.js`, `templet.js` (Bulk broadcasting templates)
  - `qr.js` (Baileys/QR-code-based WhatsApp authentication)
- **`middlewares/`**: Authentication checks (e.g., `admin.js`, `user.js`, `agent.js`, `plan.js` for checking features/limit rules).
- **`functions/`**: Helper methods for AI integrations (e.g. Gemini API), chatbot node traversal, and message dispatch.
- **`loops/`**: Background worker loops managing:
  - Broadcast campaigns (`campaignLoop.js`, `campaignBeta.js`).
- **`helper/`**: QR session helpers, socket event routing, and warmer loops.
- **`client/`**: Holds pre-built React application files inside the `public/` directory (ready to be served statically by Express).
- **`server.js` / `app.js`**: Application entry points initializing Express, routes, sockets, and starting loop campaigns.

---

## Tech Stack
- **Backend Runtime**: Node.js (version 20.18.3 or higher recommended)
- **Framework**: Express.js
- **Real-Time Communication**: Socket.IO
- **Database**: MySQL / MariaDB
- **Key Dependencies**:
  - `@whiskeysockets/baileys` (WhatsApp Web API client)
  - `mysql2` (Database driver)
  - `jsonwebtoken`, `bcrypt` (Authentication & Security)
  - `@google/generative-ai` (Gemini API integrations)

---

## Installation Steps
1. **Unzip/Extract** the project folder to your local machine.
2. **Install Dependencies**: Run the following command in the project root:
   ```bash
   npm install
   ```
3. **Frontend Domain Config (Optional/Production)**:
   In `client/public/static/js/main.e694f0ef.js`, replace references to `yourdomain.com` with your local domain or IP if running in non-localhost proxy setups.

---

## Environment Variables
The application requires a `.env` file at the root of the project. A template config is configured for local running below:

```ini
HOST=127.0.0.1
PORT=8001
DBHOST=localhost
DBNAME=whatscrm
DBUSER=root
DBPASS=
DBPORT=3306
JWTKEY=NCRUp5hKovUAcZd9OwIw0BCKmjZj9JxpNCRUp5hKovUAcZd9OwIw0BCKmjZj9JxpNCRUp5hKovUAcZd9OwIw0BCKmjZj9Jxp
FRONTENDURI=http://localhost:8001
BACKURI=http://localhost:8001
STRIPE_LANG=en
```

---

## Database Setup Requirements
The project database was configured and initialized on the local MySQL server:
1. **Created Database**:
   ```sql
   CREATE DATABASE IF NOT EXISTS whatscrm CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
2. **Imported Schema and Seed Data**:
   Populated the database tables by executing `database/import.sql` into the local `whatscrm` database.
3. **Configured Credentials**:
   Updated `.env` settings to point to `localhost:3306` with user `root` (no password) and database name `whatscrm`.

**Default Seeded Credentials:**
- **Admin Login**: `admin@admin.com`
- **Password**: `Password@123`

---

## Local Run Steps
Start the server:
```bash
npm start
```
The server starts successfully on port `8001`.

---

## Main Modules/Features Found
1. **Live Chat Inbox**: Real-time message synchronization with agents via Socket.IO.
2. **Chatbot Flow Builder**: Node-based automated answers, including AI auto-replies using Google's Generative AI (Gemini).
3. **Campaign Broadcasts**: Batch template message dispatch with custom placeholder variables.
4. **WhatsApp Session Warmer**: Automates WhatsApp interactions between sessions to prevent number blocking (uses `warmerLoopInit`).
5. **Agent Task Manager**: Enables admin owners to assign tasks and chat tickets to custom agent accounts.

---

## Current Status (Working vs. Broken / Errors Encountered)
- **Dependencies**: Installed successfully.
- **Database Connection**: Successfully connected to the local MySQL instance.
- **Server Runtime**: Running successfully under background tasks.
- **Status of Tests**:
  - `http://localhost:8001` serves index.html successfully.
  - `http://localhost:8001/admin/login` serves index.html successfully (routing handled client-side).
