# Full Project Analysis

## 1. Project Overview
The system is **OmniChat CRM** (also referred to as **whatsCRM** or **WaCrm** in the code and database). It is a customer relationship management (CRM) tool built for WhatsApp integration. It permits businesses to:
* Manage customer support tickets and live chats.
* Build flow-based chatbots and route chats.
* Automate responses using Gemini AI.
* Execute broadcast campaigns using Meta Cloud API.
* Warm up WhatsApp sessions (via standard Baileys libraries) to reduce spam filters/ban risks.
* Allocate permissions, tasks, and chats to specific agent accounts.
* Sell subscription plans using multiple payment integrations (Stripe, Paypal, Razorpay, Paystack).

---

## 2. Tech Stack
* **Runtime**: Node.js (tested on v20.18.3 / v24.13.0)
* **Backend Framework**: Express.js
* **Real-time Server**: Socket.IO
* **Database**: MySQL / MariaDB (managed via `mysql2` driver and `mysql-baileys` schema extensions)
* **WhatsApp Gateway API**: `@whiskeysockets/baileys` (WhatsApp Web protocol) & Meta Cloud API (Official API)
* **AI engine**: `@google/generative-ai` (Gemini API integration)
* **Security & Tokens**: JWT (`jsonwebtoken`) & `bcrypt` password hashing
* **Frontend**: React (Pre-compiled/built static bundle served from `client/public/`)
* **Package Manager**: npm

---

## 3. Local Run Status
* **Local Landing URL**: [http://localhost:8001](http://localhost:8001)
* **Local Admin URL**: [http://localhost:8001/admin/login] (Sign in via `admin@admin.com` / `Password@123`)
* **Database Name**: `whatscrm` (MySQL)
* **Status**: **Running successfully** in background tasks on port `8001`.

---

## 4. Folder Structure
* **`server.js` / `app.js`**: Core entry points of the backend app. Starts the port listener, registers routes, and triggers campaign loops.
* **`socket.js`**: Socket.IO initializer and connection event orchestrator.
* **`env.js`**: Holds static configuration tokens (e.g. `appVersion`, `addON`).
* **`database/`**:
  - `config.js`: MySQL pool setup.
  - `dbpromise.js`: Promisified query wrapper.
  - `import.sql`: Complete database structure and seed data.
* **`routes/`**: Contains API routes:
  - `user.js`: Main user profile, plan subscription, stripe integration, contacts, meta API templates.
  - `admin.js`: User list control, plan management, page customization, SMTP/payment configs.
  - `agent.js`: Task assignments, ticket allocations, agent registrations.
  - `inbox.js`: Message feeds and chat retrieval.
  - `chatbot.js` & `chatFlow.js`: Logic to execute chatbot node maps and templates.
  - `broadcast.js`: Managing broadcast message templates.
  - `qr.js`: Baileys WhatsApp QR session pairing endpoints.
  - `ai.js`: AI context training and Gemini credentials.
  - `web.js`: Public configuration metadata for currency, logo, and terms.
* **`middlewares/`**: Route guards (`user.js`, `admin.js`, `agent.js`, `plan.js` limits check).
* **`functions/`**:
  - `function.js`: Core execution algorithms (Meta API sends, file processing, plan updates).
  - `chatbot.js`: Traverses JSON nodes to find the next automated reply.
* **`loops/`**: Background loop orchestrators:
  - `campaignLoop.js`: Scans pending campaigns to send broadcasts.
  - `campaignBeta.js`: Fair-scheduler queue dispatcher for template messages.
* **`helper/`**: WhatsApp session engines, socket events (`helper/socket.js`), and session warmers.
* **`client/`**: Pre-built static SPA frontend inside `public/`.

---

## 5. Database Structure
Key tables populated from [import.sql](file:///d:/Development/OmniChat-CRM%20system/Omnichat-CRM/database/import.sql):
* **`user`**: Stores user customer records, timezone, billing API keys, and active plan metadata.
* **`admin`**: Stores system administrator credentials (default: `admin@admin.com`).
* **`agents`**: Secondary accounts created by users to handle customer tickets.
* **`agent_chats`**: Chat assignment routing mapping agents to conversations.
* **`instance`**: QR code session state (number, status, unique QR token).
* **`beta_campaign` / `beta_campaign_logs`**: Broadcast logs, scheduling timestamps, and delivery indicators.
* **`beta_chatbot` / `beta_flows`**: Chatbot JSON configuration graphs and node trees.
* **`plan`**: Subscription tiers (Trial, Premium, Platinum) and limits (contact limits, API access flags).
* **`web_public` / `web_private`**: Configuration files for Stripe IDs, app title, customized URLs, and logo paths.

---

## 6. Authentication & Roles
Authentication is done via **JSON Web Tokens (JWT)**:
1. **Admin (`role = 'admin'`)**: Can access statistics, change plans, customize frontpages, configure global SMTP, and view all registered users.
2. **User (`role = 'user'`)**: A business owner account. Can configure Meta credentials, create instances, pair WhatsApp QR codes, assign agent tasks, build flowcharts, and purchase plan subscriptions.
3. **Agent (`role = 'agent'`)**: Lower-privilege accounts created by Users. Assigned to specific chats to talk to customers and update task states.

---

## 7. Main Features Found
1. **CRM Dashboard**: Statistics showing active campaigns, messages sent/received, chatbot usage, and billing stats.
2. **Real-time Live Chat Inbox**: Real-time customer support chat box with assign-to-agent buttons.
3. **Contact Manager**: CSV contact import/export with support for 5 custom variables (`var1` to `var5`).
4. **WhatsApp Sessions**: Multiple QR session pairings via Baileys API.
5. **Broadcast Campaigns**: Scheduler tool sending template messages fairly to selected lists.
6. **Chatbot Flow Builder**: Node builder that replies to customer texts, fetches custom Webhooks, and updates tags.
7. **Gemini AI Replies**: Integrates generative AI to answer unrecognized customer queries.
8. **WhatsApp Warmer**: Loop system to automate conversations between registered instances to warm up new numbers.

---

## 8. Backend Routes
* **`/api/user`**: Login, profile changes, note saving, stripe checkouts, Meta template management.
* **`/api/admin`**: Global system controls (CRUD on plans, front pages, site settings, partner lists).
* **`/api/agent`**: Task tracking, tickets assignment, credentials modification.
* **`/api/inbox`**: Retrieves chats list, messages, updates tag indicators.
* **`/api/chatbot` & `/api/chat_flow`**: Triggers node sequences and manages saved flows.
* **`/api/qr`**: Connects/disconnects WhatsApp QR instances.
* **`/api/ai`**: AI context training and Gemini APIs.

---

## 9. Socket System
Socket.IO handles real-time sync across agents and the dashboard:
* **Events**:
  - `connection`: Authenticates socket handshakes via JWT (`token` parameter in query).
  - `connection_ack`: Sends connected user context back.
  - `message`: Broadcasts incoming/outgoing messages to agents assigned to the conversation.
* **Broadcast helpers**: `sendToUid`, `sendToSocket`, and `sendToAll` are exposed to dispatch UI logs.

---

## 10. Background Workers / Loops
* **`loops/campaignLoop.js`**: Scans the `broadcast` table for items scheduled in the queue and executes messages via `sendMessage`.
* **`loops/campaignBeta.js`**: Utilizes a batching worker (checks every 5 seconds) to dispatch campaign templates with variables fairly across users.
* **`helper/addon/qr/warmer/index.js`**: Rotates through paired instances to execute simulated conversation messages.

---

## 11. Frontend / Client UI
* Served statically via Express middleware `express.static('client/public')` under `server.js`.
* Built on React with client-side routing. Static resources are inside `client/public/static/`.

---

## 12. Environment Variables
* **`HOST`**: Port binding address (`127.0.0.1`).
* **`PORT`**: Server listener port (`8001`).
* **`DBHOST` / `DBPORT` / `DBNAME` / `DBUSER` / `DBPASS`**: MySQL server credentials.
* **`JWTKEY`**: Secret key signature for JWT tokens.
* **`FRONTENDURI` / `BACKURI`**: Web address URLs.
* **`STRIPE_LANG`**: Localization for Stripe.

---

## 13. Current Branding / Naming
* **Application name**: Default name is **whatsCRM** (saved in `web_public`).
* **Copyright & Info**: Hampton/Codeyon links in `package.json` (`hamidsaifi.com` & `codecanyon.net`).
* **Tutorial URLs**: Hardcoded YouTube links in `web_public` table.

---

## 14. Current Issues / Risks
* **Lack of DB Error Catching**: Inside `campaignLoop.js` and `warmer/index.js`, unhandled query promises reject when the database is unreachable, causing full Node.js server crashes (uncaught rejections).
* **Missing API Key Validation**: Some public-facing hooks inside api routes contain minimal rate-limiting guards.
* **Pre-compiled Client**: The client React source code is missing; only the compiled public bundle `static/js/main.e694f0ef.js` is included. Any modifications to frontend UI require modifying the built JS bundle or recreating/replacing pages.

---

## 15. Recommended Refactor Plan
1. **Safety Wrappers**: Add `try...catch` blocks to background campaign loops (`runCampaign()` and `warmerLoopInit()`) to prevent unhandled rejection server crashes.
2. **Branding Configurations**: Extract title constants, logos, and hardcoded portfolio names into config files.
3. **Database Constraints**: Set up proper foreign keys with CASCADE deletes in the database mapping.

---

## 16. Files Changed
* [PROJECT_LOCAL_RUN_REPORT.md](file:///d:/Development/OmniChat-CRM system/Omnichat-CRM/PROJECT_LOCAL_RUN_REPORT.md) (Created)
* [FULL_PROJECT_ANALYSIS.md](file:///d:/Development/OmniChat-CRM system/Omnichat-CRM/FULL_PROJECT_ANALYSIS.md) (Created)
* [.env](file:///d:/Development/OmniChat-CRM system/Omnichat-CRM/.env) (Modified)
