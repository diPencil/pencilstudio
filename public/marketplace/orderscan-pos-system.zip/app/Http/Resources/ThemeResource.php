<?php

namespace App\Http\Resources;


use App\Models\ThemeSetting;
use Illuminate\Http\Resources\Json\JsonResource;
use Smartisan\Settings\Facades\Settings;

class ThemeResource extends JsonResource
{

    public array $info;

    public function __construct($info)
    {
        parent::__construct($info);
        $this->info = $info;
    }

    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request) : array
    {
        return [
            "theme_logo"                     => $this->themeImage('theme_logo')->logo,
            "theme_favicon_logo"             => $this->themeImage('theme_favicon_logo')->faviconLogo,
            "theme_footer_logo"              => $this->themeImage('theme_footer_logo')->footerLogo,
            "primary_color"                  => Settings::group('theme')->get('primary_color') ?? '#1772ff',
            "secondary_color"                => Settings::group('theme')->get('secondary_color') ?? '#6e7191',
            "sidebar_bg_color"               => Settings::group('theme')->get('sidebar_bg_color') ?? '#ffffff',
            "sidebar_text_color"             => Settings::group('theme')->get('sidebar_text_color') ?? '#1f1f39',
            "button_color"                   => Settings::group('theme')->get('button_color') ?? '#1772ff',
            "login_hero_start_color"         => Settings::group('theme')->get('login_hero_start_color') ?? (Settings::group('theme')->get('primary_color') ?? '#FF3B1F'),
            "login_hero_end_color"           => Settings::group('theme')->get('login_hero_end_color') ?? '#111827',
            "login_button_color"             => Settings::group('theme')->get('login_button_color') ?? (Settings::group('theme')->get('button_color') ?? '#FF3B1F'),
            "login_button_text_color"        => Settings::group('theme')->get('login_button_text_color') ?? '#FFFFFF',
            "login_card_bg_color"            => Settings::group('theme')->get('login_card_bg_color') ?? '#FFFFFF',
            "login_text_color"               => Settings::group('theme')->get('login_text_color') ?? '#111827',
            "login_muted_text_color"         => Settings::group('theme')->get('login_muted_text_color') ?? '#6B7280',
            "login_input_bg_color"           => Settings::group('theme')->get('login_input_bg_color') ?? '#F8FAFC',
            "login_input_border_color"       => Settings::group('theme')->get('login_input_border_color') ?? '#E5E7EB',
            "login_link_color"               => Settings::group('theme')->get('login_link_color') ?? '#FF3B1F',
            "loader_type"                    => Settings::group('theme')->get('loader_type') ?? 'bars',
            "loader_color"                   => Settings::group('theme')->get('loader_color') ?? '#1772ff',
            "loader_use_logo"                => Settings::group('theme')->get('loader_use_logo') ?? 'false',
            "loader_logo_size"               => Settings::group('theme')->get('loader_logo_size') ?? '64',
            "sidebar_scrollbar_color"        => Settings::group('theme')->get('sidebar_scrollbar_color') ?? '#D1D5DB',
            "sidebar_scrollbar_thumb_color"  => Settings::group('theme')->get('sidebar_scrollbar_thumb_color') ?? '#9CA3AF',
            "sidebar_active_border_color"    => Settings::group('theme')->get('sidebar_active_border_color') ?? '#1772ff',
            "sidebar_active_bg_color"        => Settings::group('theme')->get('sidebar_active_bg_color') ?? '#F3F4F6',
            "sidebar_active_text_color"      => Settings::group('theme')->get('sidebar_active_text_color') ?? '#111827',
            "sidebar_active_icon_color"      => Settings::group('theme')->get('sidebar_active_icon_color') ?? '#FF3B1F',
            "sidebar_hover_bg_color"         => Settings::group('theme')->get('sidebar_hover_bg_color') ?? '#F9FAFB',
            "dashboard_sales_card_start_color"     => Settings::group('theme')->get('dashboard_sales_card_start_color') ?? '#EC4899',
            "dashboard_sales_card_end_color"       => Settings::group('theme')->get('dashboard_sales_card_end_color') ?? '#F43F5E',
            "dashboard_orders_card_start_color"    => Settings::group('theme')->get('dashboard_orders_card_start_color') ?? '#8B5CF6',
            "dashboard_orders_card_end_color"      => Settings::group('theme')->get('dashboard_orders_card_end_color') ?? '#6366F1',
            "dashboard_customers_card_start_color" => Settings::group('theme')->get('dashboard_customers_card_start_color') ?? '#3B82F6',
            "dashboard_customers_card_end_color"   => Settings::group('theme')->get('dashboard_customers_card_end_color') ?? '#2563EB',
            "dashboard_items_card_start_color"     => Settings::group('theme')->get('dashboard_items_card_start_color') ?? '#A855F7',
            "dashboard_items_card_end_color"       => Settings::group('theme')->get('dashboard_items_card_end_color') ?? '#9333EA',
            "account_dropdown_bg_color"            => Settings::group('theme')->get('account_dropdown_bg_color') ?? '#FFFFFF',
            "account_dropdown_text_color"          => Settings::group('theme')->get('account_dropdown_text_color') ?? '#111827',
            "account_dropdown_muted_text_color"    => Settings::group('theme')->get('account_dropdown_muted_text_color') ?? '#6B7280',
            "account_dropdown_icon_color"          => Settings::group('theme')->get('account_dropdown_icon_color') ?? '#6B7280',
            "account_dropdown_link_color"          => Settings::group('theme')->get('account_dropdown_link_color') ?? '#FF3B1F',
            "account_dropdown_hover_bg_color"      => Settings::group('theme')->get('account_dropdown_hover_bg_color') ?? '#F9FAFB',
            "account_dropdown_divider_color"       => Settings::group('theme')->get('account_dropdown_divider_color') ?? '#E5E7EB',
            "avatar_ring_color"                    => Settings::group('theme')->get('avatar_ring_color') ?? '#FF3B1F',
            "avatar_edit_button_bg_color"          => Settings::group('theme')->get('avatar_edit_button_bg_color') ?? '#111827',
            "avatar_edit_button_icon_color"        => Settings::group('theme')->get('avatar_edit_button_icon_color') ?? '#FFFFFF',
            "dashboard_sales_card_icon_color"      => Settings::group('theme')->get('dashboard_sales_card_icon_color') ?? '#EC4899',
            "dashboard_sales_card_icon_bg_color"   => Settings::group('theme')->get('dashboard_sales_card_icon_bg_color') ?? '#FFFFFF',
            "dashboard_orders_card_icon_color"     => Settings::group('theme')->get('dashboard_orders_card_icon_color') ?? '#8B5CF6',
            "dashboard_orders_card_icon_bg_color"  => Settings::group('theme')->get('dashboard_orders_card_icon_bg_color') ?? '#FFFFFF',
            "dashboard_customers_card_icon_color"  => Settings::group('theme')->get('dashboard_customers_card_icon_color') ?? '#3B82F6',
            "dashboard_customers_card_icon_bg_color" => Settings::group('theme')->get('dashboard_customers_card_icon_bg_color') ?? '#FFFFFF',
            "dashboard_items_card_icon_color"      => Settings::group('theme')->get('dashboard_items_card_icon_color') ?? '#A855F7',
            "dashboard_items_card_icon_bg_color"   => Settings::group('theme')->get('dashboard_items_card_icon_bg_color') ?? '#FFFFFF',
        ];
    }

    public function themeImage($key)
    {
        return ThemeSetting::where(['key' => $key])->first();
    }
}
