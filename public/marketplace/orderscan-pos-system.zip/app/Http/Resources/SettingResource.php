<?php

namespace App\Http\Resources;


use App\Models\ThemeSetting;
use Illuminate\Http\Resources\Json\JsonResource;
use Smartisan\Settings\Facades\Settings;

class SettingResource extends JsonResource
{

    public array $info;

    public function __construct($info)
    {
        parent::__construct($info);
        $this->info = $info;
    }

    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request): array
    {
        return [
            'company_name'                         => $this->info['company_name'],
            'company_email'                        => $this->info['company_email'],
            'company_phone'                        => $this->info['company_phone'],
            'company_address'                      => $this->info['company_address'],
            'company_country_code'                 => $this->info['company_country_code'],
            'site_default_branch'                  => $this->info['site_default_branch'],
            'site_default_language'                => $this->info['site_default_language'],
            'site_copyright'                       => $this->info['site_copyright'],
            'site_currency_position'               => $this->info['site_currency_position'],
            'site_digit_after_decimal_point'       => $this->info['site_digit_after_decimal_point'],
            'site_default_currency_symbol'         => $this->info['site_default_currency_symbol'],
            'site_phone_verification'              => $this->info['site_phone_verification'],
            'site_language_switch'                 => $this->info['site_language_switch'],
            'site_online_payment_gateway'          => $this->info['site_online_payment_gateway'],
            'site_food_preparation_time'           => $this->info['site_food_preparation_time'],
            'theme_logo'                           => $this->themeImage('theme_logo')->logo,
            'theme_footer_logo'                    => $this->themeImage('theme_footer_logo')->footerLogo,
            'theme_favicon_logo'                   => $this->themeImage('theme_favicon_logo')->faviconLogo,
            'primary_color'                        => Settings::group('theme')->get('primary_color') ?? '#1772ff',
            'secondary_color'                      => Settings::group('theme')->get('secondary_color') ?? '#6e7191',
            'button_color'                         => Settings::group('theme')->get('button_color') ?? '#1772ff',
            'login_hero_start_color'               => Settings::group('theme')->get('login_hero_start_color') ?? (Settings::group('theme')->get('primary_color') ?? '#FF3B1F'),
            'login_hero_end_color'                 => Settings::group('theme')->get('login_hero_end_color') ?? '#111827',
            'login_button_color'                   => Settings::group('theme')->get('login_button_color') ?? (Settings::group('theme')->get('button_color') ?? '#FF3B1F'),
            'login_button_text_color'              => Settings::group('theme')->get('login_button_text_color') ?? '#FFFFFF',
            'login_card_bg_color'                  => Settings::group('theme')->get('login_card_bg_color') ?? '#FFFFFF',
            'login_text_color'                     => Settings::group('theme')->get('login_text_color') ?? '#111827',
            'login_muted_text_color'               => Settings::group('theme')->get('login_muted_text_color') ?? '#6B7280',
            'login_input_bg_color'                 => Settings::group('theme')->get('login_input_bg_color') ?? '#F8FAFC',
            'login_input_border_color'             => Settings::group('theme')->get('login_input_border_color') ?? '#E5E7EB',
            'login_link_color'                     => Settings::group('theme')->get('login_link_color') ?? '#FF3B1F',
            'loader_type'                          => Settings::group('theme')->get('loader_type') ?? 'bars',
            'loader_color'                         => Settings::group('theme')->get('loader_color') ?? '#1772ff',
            'loader_use_logo'                      => Settings::group('theme')->get('loader_use_logo') ?? 'false',
            'loader_logo_size'                     => Settings::group('theme')->get('loader_logo_size') ?? '64',
            'sidebar_scrollbar_color'              => Settings::group('theme')->get('sidebar_scrollbar_color') ?? '#D1D5DB',
            'sidebar_scrollbar_thumb_color'        => Settings::group('theme')->get('sidebar_scrollbar_thumb_color') ?? '#9CA3AF',
            'sidebar_active_border_color'          => Settings::group('theme')->get('sidebar_active_border_color') ?? '#1772ff',
            'sidebar_active_bg_color'              => Settings::group('theme')->get('sidebar_active_bg_color') ?? '#F3F4F6',
            'sidebar_active_text_color'            => Settings::group('theme')->get('sidebar_active_text_color') ?? '#111827',
            'sidebar_active_icon_color'            => Settings::group('theme')->get('sidebar_active_icon_color') ?? '#FF3B1F',
            'sidebar_hover_bg_color'               => Settings::group('theme')->get('sidebar_hover_bg_color') ?? '#F9FAFB',
            'dashboard_sales_card_start_color'     => Settings::group('theme')->get('dashboard_sales_card_start_color') ?? '#EC4899',
            'dashboard_sales_card_end_color'       => Settings::group('theme')->get('dashboard_sales_card_end_color') ?? '#F43F5E',
            'dashboard_orders_card_start_color'    => Settings::group('theme')->get('dashboard_orders_card_start_color') ?? '#8B5CF6',
            'dashboard_orders_card_end_color'      => Settings::group('theme')->get('dashboard_orders_card_end_color') ?? '#6366F1',
            'dashboard_customers_card_start_color' => Settings::group('theme')->get('dashboard_customers_card_start_color') ?? '#3B82F6',
            'dashboard_customers_card_end_color'   => Settings::group('theme')->get('dashboard_customers_card_end_color') ?? '#2563EB',
            'dashboard_items_card_start_color'     => Settings::group('theme')->get('dashboard_items_card_start_color') ?? '#A855F7',
            'dashboard_items_card_end_color'       => Settings::group('theme')->get('dashboard_items_card_end_color') ?? '#9333EA',
            'account_dropdown_bg_color'            => Settings::group('theme')->get('account_dropdown_bg_color') ?? '#FFFFFF',
            'account_dropdown_text_color'          => Settings::group('theme')->get('account_dropdown_text_color') ?? '#111827',
            'account_dropdown_muted_text_color'    => Settings::group('theme')->get('account_dropdown_muted_text_color') ?? '#6B7280',
            'account_dropdown_icon_color'          => Settings::group('theme')->get('account_dropdown_icon_color') ?? '#6B7280',
            'account_dropdown_link_color'          => Settings::group('theme')->get('account_dropdown_link_color') ?? '#FF3B1F',
            'account_dropdown_hover_bg_color'      => Settings::group('theme')->get('account_dropdown_hover_bg_color') ?? '#F9FAFB',
            'account_dropdown_divider_color'       => Settings::group('theme')->get('account_dropdown_divider_color') ?? '#E5E7EB',
            'avatar_ring_color'                    => Settings::group('theme')->get('avatar_ring_color') ?? '#FF3B1F',
            'avatar_edit_button_bg_color'          => Settings::group('theme')->get('avatar_edit_button_bg_color') ?? '#111827',
            'avatar_edit_button_icon_color'        => Settings::group('theme')->get('avatar_edit_button_icon_color') ?? '#FFFFFF',
            'dashboard_sales_card_icon_color'      => Settings::group('theme')->get('dashboard_sales_card_icon_color') ?? '#EC4899',
            'dashboard_sales_card_icon_bg_color'   => Settings::group('theme')->get('dashboard_sales_card_icon_bg_color') ?? '#FFFFFF',
            'dashboard_orders_card_icon_color'     => Settings::group('theme')->get('dashboard_orders_card_icon_color') ?? '#8B5CF6',
            'dashboard_orders_card_icon_bg_color'  => Settings::group('theme')->get('dashboard_orders_card_icon_bg_color') ?? '#FFFFFF',
            'dashboard_customers_card_icon_color'  => Settings::group('theme')->get('dashboard_customers_card_icon_color') ?? '#3B82F6',
            'dashboard_customers_card_icon_bg_color' => Settings::group('theme')->get('dashboard_customers_card_icon_bg_color') ?? '#FFFFFF',
            'dashboard_items_card_icon_color'      => Settings::group('theme')->get('dashboard_items_card_icon_color') ?? '#A855F7',
            'dashboard_items_card_icon_bg_color'   => Settings::group('theme')->get('dashboard_items_card_icon_bg_color') ?? '#FFFFFF',
            'otp_type'                             => $this->info['otp_type'],
            'otp_digit_limit'                      => $this->info['otp_digit_limit'],
            'otp_expire_time'                      => $this->info['otp_expire_time'],
            'social_media_facebook'                => $this->info['social_media_facebook'],
            'social_media_instagram'               => $this->info['social_media_instagram'],
            'social_media_twitter'                 => $this->info['social_media_twitter'],
            'social_media_youtube'                 => $this->info['social_media_youtube'],
            'order_setup_takeaway'                 => $this->info['order_setup_takeaway'],
            'order_setup_delivery'                 => $this->info['order_setup_delivery'],
            'order_setup_free_delivery_kilometer'  => $this->info['order_setup_free_delivery_kilometer'],
            'order_setup_basic_delivery_charge'    => $this->info['order_setup_basic_delivery_charge'],
            'order_setup_charge_per_kilo'          => $this->info['order_setup_charge_per_kilo'],
            'notification_fcm_api_key'             => $this->info['notification_fcm_api_key'],
            'notification_fcm_auth_domain'         => $this->info['notification_fcm_auth_domain'],
            'notification_fcm_project_id'          => $this->info['notification_fcm_project_id'],
            'notification_fcm_storage_bucket'      => $this->info['notification_fcm_storage_bucket'],
            'notification_fcm_messaging_sender_id' => $this->info['notification_fcm_messaging_sender_id'],
            'notification_fcm_app_id'              => $this->info['notification_fcm_app_id'],
            'notification_fcm_measurement_id'      => $this->info['notification_fcm_measurement_id'],
            'notification_fcm_public_vapid_key'    => $this->info['notification_fcm_public_vapid_key'],
            'notification_audio'                   => asset('/audio/notification.mp3'),
            'image_cart'                           => asset('/images/cart/empty-cart.gif'),
            'image_confirm'                        => asset('/images/cart/confirm.gif'),
            'image_vag'                            => asset('/images/item-type/veg.png'),
            'image_non_vag'                        => asset('/images/item-type/non-veg.png'),
            'image_app_store'                      => asset('/images/store/app-store.png'),
            'image_play_store'                     => asset('/images/store/play-store.png'),
            'image_order_track'                    => asset('/images/order/track.png'),
            'image_order_placed'                   => asset('/images/order/placed.gif'),
            'image_order_complete'                 => asset('/images/order/complete.gif'),
            'image_order_delivered'                => asset('/images/order/delivered.gif'),
            'image_order_preparing'                => asset('/images/order/preparing_order.gif'),
            'image_order_prepared'                 => asset('/images/order/prepared_order.gif'),
            'image_order_out_for_delivery'         => asset('/images/order/out_for_delivery.gif'),
            'image_order_rejected'                 => asset('/images/order/rejected.gif'),
            'image_order_canceled'                 => asset('/images/order/canceled.gif'),
            'image_order_returned'                 => asset('/images/order/returned.gif'),
            'image_four_zero_four_page'            => asset('/images/accessible/404.gif'),
            'image_four_zero_three_page'           => asset('/images/accessible/403.gif'),
            'item_not_found'                       => asset('/images/item/item-not-found.png'),
            'image_order_not_found'                => asset('/images/default/not-found.png'),
        ];
    }

    public function themeImage($key)
    {
        return ThemeSetting::where(['key' => $key])->first();
    }
}
