import React from 'react';
import { renderToString } from 'react-dom/server';
import { MemoryRouter } from 'react-router-dom';
import { LocaleProvider } from './src/localization/useLocale';
import { ToastProvider } from './src/contexts/ToastContext';
import { OmnichannelMockStoreProvider } from './src/components/omnichannel/store/OmnichannelMockStore';

import { OmnichannelInboxFilters } from './src/components/omnichannel/inbox/OmnichannelInboxFilters';
import { OmnichannelConversationList } from './src/components/omnichannel/inbox/OmnichannelConversationList';
import { OmnichannelConversationWorkspace } from './src/components/omnichannel/inbox/OmnichannelConversationWorkspace';
import { OmnichannelCustomerContextPanel } from './src/components/omnichannel/inbox/OmnichannelCustomerContextPanel';
import { OmnichannelConversionModal } from './src/components/omnichannel/inbox/OmnichannelConversionModal';

const wrap = (children: React.ReactNode) => (
  <LocaleProvider>
    <ToastProvider>
      <MemoryRouter>
        <OmnichannelMockStoreProvider>
          {children}
        </OmnichannelMockStoreProvider>
      </MemoryRouter>
    </ToastProvider>
  </LocaleProvider>
);

const tryRender = (name: string, Component: any, props: any = {}) => {
  try {
    renderToString(wrap(<Component {...props} />));
    console.log(`${name} rendered successfully`);
  } catch (error: any) {
    console.error(`Crash in ${name}:`, error.message);
  }
};

tryRender("OmnichannelInboxFilters", OmnichannelInboxFilters, { filters: {}, tags: [], onFiltersChange: () => {} });
tryRender("OmnichannelConversationList", OmnichannelConversationList, { conversations: [], onSelect: () => {} });
tryRender("OmnichannelConversationWorkspace", OmnichannelConversationWorkspace, { conversation: {tagIds: []}, messages: [], tags: [], composerAttachments: [] });
tryRender("OmnichannelCustomerContextPanel", OmnichannelCustomerContextPanel, { conversation: {linkedRecords: []}, notes: [], removedRecords: [], activityEvents: [] });
tryRender("OmnichannelConversionModal", OmnichannelConversionModal, { staffOptions: [], teamOptions: [], existingRecords: [] });

import { OmnichannelInboxPage } from './src/components/omnichannel/OmnichannelInboxPage';
tryRender("OmnichannelInboxPage", OmnichannelInboxPage);
