const fs = require('fs');
const path = require('path');

function walk(dir) {
    let results = [];
    const list = fs.readdirSync(dir);
    list.forEach(file => {
        file = path.join(dir, file);
        const stat = fs.statSync(file);
        if (stat && stat.isDirectory()) {
            results = results.concat(walk(file));
        } else if (file.endsWith('.tsx')) {
            results.push(file);
        }
    });
    return results;
}

const files = walk('d:/Development/CRM Travel/TravneedsSystem/src/components');
let modifiedCount = 0;

for (const file of files) {
    let content = fs.readFileSync(file, 'utf8');
    let original = content;

    // We want to transform buttons inside the banner.
    // Let's find the banner first.
    if (!content.includes('bg-[#2563EB]')) continue;

    // Most buttons inside these banners look like:
    // <Button variant="outline" className="bg-white/10 text-white border-transparent hover:bg-white/20" ...>
    //     <Icon className={isRTL ? "h-4 w-4 ml-2" : "h-4 w-4 mr-2"} />
    //     {text}
    // </Button>
    // 
    // We want to change them to:
    // <Button variant="outline" className="bg-white/10 text-white border-transparent hover:bg-white/20 px-2 sm:px-4" ...>
    //     <Icon className={isRTL ? "h-4 w-4 sm:ml-2" : "h-4 w-4 sm:mr-2"} />
    //     <span className="hidden sm:inline">{text}</span>
    // </Button>

    // Also the primary button:
    // <Button className="bg-white text-blue-600 hover:bg-gray-50" ...>
    //     <Icon className={isRTL ? "h-4 w-4 ml-2" : "h-4 w-4 mr-2"} />
    //     {text}
    // </Button>
    //
    // Let's replace button classNames to add px-2 sm:px-4, or p-2 sm:px-4.
    // It's easier if we just match the whole button structure inside the action container.
    // The action container is usually:
    // <div className={cn("flex flex-wrap items-center gap-3", isRTL && "flex-row-reverse")}>
    
    // Instead of complex AST, let's use regex to find `<Button ...> ... </Button>` that contains an icon and text.
    // Wait, not all buttons are in the banner.
    // So we first split the file by `bg-[#2563EB]`.
    
    let parts = content.split(/bg-\[\#2563EB\][^>]+>/);
    if (parts.length < 2) continue;
    
    // The banner content is right after the split, up to the end of its div.
    // Let's just find the first `</div>` that balances the banner's open div.
    // But it's simpler to just do this:
    // The user wants it "like the Dashboard page".
    // In Dashboard, the buttons are in a `bg-white/10` rounded-2xl container.
    // Let's just wrap the `button` contents.
    
    // Let's replace: `className={isRTL ? "h-4 w-4 ml-2" : "h-4 w-4 mr-2"}`
    // with: `className={isRTL ? "h-4 w-4 sm:ml-2" : "h-4 w-4 sm:mr-2"}`
    content = content.replace(/"h-4 w-4 ml-2" : "h-4 w-4 mr-2"/g, '"h-4 w-4 sm:ml-2" : "h-4 w-4 sm:mr-2"');
    
    // Sometimes it's `"mr-2 h-4 w-4"` or similar? 
    content = content.replace(/className="h-4 w-4 mr-2"/g, 'className="h-4 w-4 sm:mr-2"');
    content = content.replace(/className="mr-2 h-4 w-4"/g, 'className="sm:mr-2 h-4 w-4"');
    
    // Now we need to hide the text.
    // How to find text nodes in Buttons?
    // <Button ...>\n  <Icon ... />\n  {isRTL ? 'متابعات متأخرة' : 'Overdue'}\n</Button>
    // We can replace `<Button([^>]*)>([\s\S]*?)<\/Button>`
    
    // Let's do it manually on a few key files if the script is too risky.
    // But there are 40+ files. The user said "all pages".
    // Let's use a regex to match the buttons in the action bar.
    // Usually the action bar has `gap-3` or `gap-4`.
    // Let's replace the whole action bar if it's the standard one.
    // But they have different links and texts.
}

console.log('Modified', modifiedCount, 'files');
