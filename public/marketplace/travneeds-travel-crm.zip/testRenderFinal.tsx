import React from 'react';
import { renderToString } from 'react-dom/server';
import { MemoryRouter } from 'react-router-dom';
import { LocaleContext } from './src/localization/LocaleContext';
import { ToastProvider } from './src/contexts/ToastContext';
import { OmnichannelMockStoreProvider } from './src/components/omnichannel/store/OmnichannelMockStore';
import { OmnichannelInboxPage } from './src/components/omnichannel/OmnichannelInboxPage';

const mockLocaleContext = {
  locale: 'en',
  direction: 'ltr' as 'ltr' | 'rtl',
  isRTL: false,
  setLocale: () => {},
  t: (key: string) => key,
};

try {
  console.log("Starting render test...");
  renderToString(
    <LocaleContext.Provider value={mockLocaleContext}>
      <ToastProvider>
        <MemoryRouter>
          <OmnichannelMockStoreProvider>
            <OmnichannelInboxPage />
          </OmnichannelMockStoreProvider>
        </MemoryRouter>
      </ToastProvider>
    </LocaleContext.Provider>
  );
  console.log("SUCCESSFULLY RENDERED!");
} catch (e: any) {
  console.error("RUNTIME CRASH:", e.stack || e.message);
}
