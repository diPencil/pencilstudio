window.addEventListener('error', (e) => { fetch('http://localhost:9999', { method: 'POST', body: String(e.error?.stack || e.message) }).catch(()=>0); }); window.addEventListener('unhandledrejection', (e) => { fetch('http://localhost:9999', { method: 'POST', body: String(e.reason?.stack || e.reason) }).catch(()=>0); });
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
