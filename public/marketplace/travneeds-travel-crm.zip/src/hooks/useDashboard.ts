import { useEffect, useState } from "react";
import api from "@/services/api";

type Summary = {
  newLeadsToday: number;
  totalLeads: number;
  monthlyRevenue: number;
  leadsBySource: Record<string, number>;
};

export default function useDashboard() {
  const [data, setData] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const res = await api.get("/dashboard/summary");
        if (mounted) setData(res.data);
      } catch (e: any) {
        setError(e?.message || "Failed to load summary");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  return { data, loading, error };
}
