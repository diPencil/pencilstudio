
import { useEffect, useState } from "react";
import api from "@/services/api";

type Lead = {
  id: number;
  name: string;
  email?: string;
  phone?: string;
  source?: string;
  status?: string;
  expected_revenue?: number;
  created_at?: string;
};

export default function LeadsPage() {
  const [rows, setRows] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");

  const load = async () => {
    setLoading(true);
    const res = await api.get("/leads"); // Laravel returns paginate: {data:[], ...}
    setRows(res.data.data || res.data);  // Works in both cases
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const addLead = async () => {
    if (!name.trim()) return;
    await api.post("/leads", { name, source: "website", expected_revenue: 1000 });
    setName("");
    load();
  };

  return (
    <div className="p-4">
      <div className="flex gap-2 mb-4">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Lead name"
          className="border rounded px-3 py-2"
        />
        <button onClick={addLead} className="rounded-2xl shadow px-4 py-2 bg-black text-white">
          Add Lead
        </button>
      </div>

      {loading ? (
        <div>Loading…</div>
      ) : (
        <table className="w-full text-left">
          <thead>
            <tr>
              <th className="py-2">Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Source</th>
              <th>Status</th>
              <th>Revenue</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="border-t">
                <td className="py-2">{r.name}</td>
                <td>{r.email || "-"}</td>
                <td>{r.phone || "-"}</td>
                <td>{r.source || "-"}</td>
                <td>{r.status || "-"}</td>
                <td>{r.expected_revenue ?? 0}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
