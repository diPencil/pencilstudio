import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BarChart3, CheckCircle, Clock, Copy, Edit, Eye, FileText, Filter, Plus, Printer, Search, Send, TrendingUp, X, XCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { mockCases, mockQuotations } from '../../services/mockData';
import { formatCurrency, formatDate } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { QuotationStatus, QuotationVersion } from '../../types/quotation';
import { QuotationStatusBadge } from './QuotationStatusBadge';
import { cn } from '../../utils/cn';

type QuoteRow = {
  id: string;
  reference: string;
  caseId: string;
  customer: string;
  owner: string;
  version: QuotationVersion;
  versionCount: number;
  totalCost: number;
  totalSelling: number;
  profit: number;
  margin: number;
  createdAt: string;
};

const statusOptions: Array<'All Statuses' | QuotationStatus | 'Pending Approval'> = [
  'All Statuses',
  'Draft',
  'Sent',
  'Revised',
  'Approved',
  'Rejected',
  'Expired',
  'Pending Approval'
];

export const QuotationDashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const { isRTL } = useLocale();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<typeof statusOptions[number]>('All Statuses');
  const [ownerFilter, setOwnerFilter] = useState('All Owners');
  const [marginFilter, setMarginFilter] = useState('All Margins');
  const [selectedRow, setSelectedRow] = useState<QuoteRow | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const rows = useMemo<QuoteRow[]>(() => mockQuotations.flatMap(quotation => {
    const salesCase = mockCases.find(item => item.id === quotation.caseId);
    const latestVersion = quotation.versions[quotation.versions.length - 1];
    if (!latestVersion) return [];

    const totalCost = latestVersion.costSummary?.groupTotalCost ?? latestVersion.pricing.grandTotalCost ?? 0;
    const totalSelling = latestVersion.pricing.totalSellingPrice;
    const profit = latestVersion.profitAnalysis?.grossProfit ?? latestVersion.pricing.profitAmount ?? totalSelling - totalCost;
    const margin = totalSelling > 0 ? Math.round((profit / totalSelling) * 100) : 0;

    return [{
      id: quotation.id,
      reference: quotation.reference,
      caseId: quotation.caseId,
      customer: latestVersion.customerInfo.name || salesCase?.customer || 'Unknown Customer',
      owner: latestVersion.preparedBy || salesCase?.assignedAgent || salesCase?.agent || 'Current User',
      version: latestVersion,
      versionCount: quotation.versions.length,
      totalCost,
      totalSelling,
      profit,
      margin,
      createdAt: latestVersion.createdAt || quotation.createdAt
    }];
  }), []);

  const owners = useMemo(() => ['All Owners', ...Array.from(new Set(rows.map(row => row.owner)))], [rows]);

  const pendingApprovalRows = rows.filter(row => needsApproval(row));
  const filteredRows = rows.filter(row => {
    const term = searchTerm.trim().toLowerCase();
    const matchesSearch = !term
      || row.reference.toLowerCase().includes(term)
      || row.id.toLowerCase().includes(term)
      || row.caseId.toLowerCase().includes(term)
      || row.customer.toLowerCase().includes(term)
      || row.version.programOverview.title.toLowerCase().includes(term);
    const matchesStatus = statusFilter === 'All Statuses'
      || (statusFilter === 'Pending Approval' ? needsApproval(row) : row.version.status === statusFilter);
    const matchesOwner = ownerFilter === 'All Owners' || row.owner === ownerFilter;
    const matchesMargin = marginFilter === 'All Margins'
      || (marginFilter === 'Low Margin' && row.margin < 15)
      || (marginFilter === 'Healthy Margin' && row.margin >= 15);

    return matchesSearch && matchesStatus && matchesOwner && matchesMargin;
  });

  const selectedRows = rows.filter(row => selectedIds.includes(row.id));
  const metrics = {
    total: rows.length,
    totalValue: rows.reduce((sum, row) => sum + row.totalSelling, 0),
    approvedValue: rows.filter(row => row.version.status === 'Approved').reduce((sum, row) => sum + row.totalSelling, 0),
    pendingApproval: pendingApprovalRows.length,
    avgMargin: rows.length ? Math.round(rows.reduce((sum, row) => sum + row.margin, 0) / rows.length) : 0,
    conversion: rows.length ? Math.round((rows.filter(row => row.version.status === 'Approved').length / rows.length) * 100) : 0
  };

  const resetFilters = () => {
    setSearchTerm('');
    setStatusFilter('All Statuses');
    setOwnerFilter('All Owners');
    setMarginFilter('All Margins');
  };

  const toggleSelected = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]);
  };

  const toggleAllVisible = () => {
    const visibleIds = filteredRows.map(row => row.id);
    const allVisibleSelected = visibleIds.length > 0 && visibleIds.every(id => selectedIds.includes(id));
    setSelectedIds(prev => allVisibleSelected ? prev.filter(id => !visibleIds.includes(id)) : Array.from(new Set([...prev, ...visibleIds])));
  };

  const openFirstCreatePath = () => {
    const firstCaseId = mockCases[0]?.id || 'CASE-2025-001';
    navigate(`/sales/cases/${firstCaseId}/quotations/new`);
  };

  return (
    <div className="w-full pb-8" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className="flex flex-col gap-4 rounded-3xl bg-[#2563EB] p-6 text-white shadow-lg shadow-blue-500/20 sm:flex-row sm:items-center sm:justify-between sm:p-8">
          <div className={cn('min-w-0', isRTL ? 'text-right' : 'text-left')}>
            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Quotation Dashboard</h1>
            <p className="mt-1 text-sm text-blue-100 opacity-90">Pricing pipeline, approvals, versions, and proposal health in one workspace.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" className="border-transparent bg-white/10 text-white hover:bg-white/20" onClick={() => setStatusFilter('Pending Approval')}>
              <Clock className="h-4 w-4" />
              Pending Approvals
            </Button>
            <Button className="bg-white text-blue-600 hover:bg-gray-50" onClick={openFirstCreatePath}>
              <Plus className="h-4 w-4" />
              New Proposal
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-5">
          <MetricCard icon={FileText} label="Total Quotations" value={metrics.total.toString()} detail={`${filteredRows.length} visible`} />
          <MetricCard icon={TrendingUp} label="Pipeline Value" value={formatCurrency(metrics.totalValue)} detail={`${formatCurrency(metrics.approvedValue)} approved`} />
          <MetricCard icon={Clock} label="Pending Approval" value={metrics.pendingApproval.toString()} detail="Low margin or manual override" tone="amber" />
          <MetricCard icon={BarChart3} label="Average Margin" value={`${metrics.avgMargin}%`} detail="Across active quote data" tone={metrics.avgMargin < 15 ? 'red' : 'green'} />
          <MetricCard icon={CheckCircle} label="Conversion" value={`${metrics.conversion}%`} detail="Approved / total quotations" tone="green" />
        </div>

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1fr)_320px]">
          <div className="space-y-4 min-w-0">
            <Card>
              <CardContent className="p-4">
                <div className="grid grid-cols-1 gap-3 lg:grid-cols-[minmax(0,1fr)_160px_160px_160px_auto_auto]">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400 rtl:left-auto rtl:right-3" />
                    <Input className="pl-10 rtl:pl-4 rtl:pr-10" placeholder="Search quote, customer, case, package..." value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} />
                  </div>
                  <Select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value as typeof statusFilter)}>
                    {statusOptions.map(option => <option key={option} value={option}>{option}</option>)}
                  </Select>
                  <Select value={ownerFilter} onChange={(event) => setOwnerFilter(event.target.value)}>
                    {owners.map(option => <option key={option} value={option}>{option}</option>)}
                  </Select>
                  <Select value={marginFilter} onChange={(event) => setMarginFilter(event.target.value)}>
                    <option>All Margins</option>
                    <option>Low Margin</option>
                    <option>Healthy Margin</option>
                  </Select>
                  <Button variant="outline" onClick={resetFilters}>
                    <X className="h-4 w-4" />
                    Reset
                  </Button>
                  <Button variant="outline" onClick={() => setSelectedIds(filteredRows.map(row => row.id))}>
                    <Filter className="h-4 w-4" />
                    Select Visible
                  </Button>
                </div>
              </CardContent>
            </Card>

            {selectedRows.length > 0 && (
              <Card className="border-blue-100 bg-blue-50/60 dark:border-blue-900/30 dark:bg-blue-950/20">
                <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="text-sm font-semibold text-blue-900 dark:text-blue-200">
                    {selectedRows.length} quotations selected / {formatCurrency(selectedRows.reduce((sum, row) => sum + row.totalSelling, 0))} selected value
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button variant="outline" size="sm" onClick={() => setSelectedIds([])}>Clear</Button>
                    <Button size="sm" onClick={() => setStatusFilter('Pending Approval')}>Review Approval Queue</Button>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-blue-600" />
                  Quotations List
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[1040px] text-sm">
                    <thead className="bg-gray-50 text-xs uppercase tracking-wide text-gray-500 dark:bg-gray-800/60">
                      <tr>
                        <th className="px-3 py-3 text-left rtl:text-right">
                          <input type="checkbox" checked={filteredRows.length > 0 && filteredRows.every(row => selectedIds.includes(row.id))} onChange={toggleAllVisible} />
                        </th>
                        <th className="px-3 py-3 text-left rtl:text-right">Quotation</th>
                        <th className="px-3 py-3 text-left rtl:text-right">Customer / Package</th>
                        <th className="px-3 py-3 text-left rtl:text-right">Status</th>
                        <th className="px-3 py-3 text-left rtl:text-right">Version</th>
                        <th className="px-3 py-3 text-right rtl:text-left">Selling</th>
                        <th className="px-3 py-3 text-right rtl:text-left">Profit</th>
                        <th className="px-3 py-3 text-left rtl:text-right">Owner</th>
                        <th className="px-3 py-3 text-right rtl:text-left">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredRows.map(row => (
                        <tr key={row.id} className="border-t border-gray-100 hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-800/50" onClick={() => setSelectedRow(row)}>
                          <td className="px-3 py-3" onClick={(event) => event.stopPropagation()}>
                            <input type="checkbox" checked={selectedIds.includes(row.id)} onChange={() => toggleSelected(row.id)} />
                          </td>
                          <td className="px-3 py-3">
                            <div className="font-bold text-gray-900 dark:text-white">{row.reference}</div>
                            <div className="text-xs text-gray-500">{row.caseId} / {formatDate(row.createdAt)}</div>
                          </td>
                          <td className="px-3 py-3">
                            <div className="font-semibold">{row.customer}</div>
                            <div className="text-xs text-gray-500">{row.version.programOverview.title || 'Untitled Package'}</div>
                          </td>
                          <td className="px-3 py-3">
                            <div className="space-y-1">
                              <QuotationStatusBadge status={row.version.status} />
                              {needsApproval(row) && <span className="block text-[10px] font-bold uppercase text-amber-600">Approval required</span>}
                            </div>
                          </td>
                          <td className="px-3 py-3">
                            <div className="font-mono font-bold">v{row.version.versionNumber}</div>
                            <div className="text-xs text-gray-500">{row.versionCount} logged</div>
                          </td>
                          <td className="px-3 py-3 text-right font-bold rtl:text-left">{formatCurrency(row.totalSelling, { currency: row.version.pricing.currency })}</td>
                          <td className="px-3 py-3 text-right rtl:text-left">
                            <div className={cn('font-bold', row.margin < 15 ? 'text-rose-600' : 'text-emerald-600')}>{formatCurrency(row.profit, { currency: row.version.pricing.currency })}</div>
                            <div className="text-xs text-gray-500">{row.margin}% margin</div>
                          </td>
                          <td className="px-3 py-3">{row.owner}</td>
                          <td className="px-3 py-3 text-right rtl:text-left" onClick={(event) => event.stopPropagation()}>
                            <TableActionsDropdown
                              actions={[
                                { label: 'Preview', icon: Eye, onClick: () => navigate(`/sales/cases/${row.caseId}/quotations/${row.id}/preview`) },
                                { label: 'Edit', icon: Edit, onClick: () => navigate(`/sales/cases/${row.caseId}/quotations/${row.id}/edit`) },
                                { label: 'Print', icon: Printer, onClick: () => navigate(`/sales/cases/${row.caseId}/quotations/${row.id}/print`) },
                                { label: 'Duplicate Version', icon: Copy, onClick: () => navigate(`/sales/cases/${row.caseId}/quotations/${row.id}/edit`) },
                                { label: 'Open Case', icon: FileText, onClick: () => navigate(`/sales/cases/${row.caseId}`) }
                              ]}
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {filteredRows.length === 0 && (
                  <div className="py-16 text-center text-sm text-gray-500">No quotations match the current filters.</div>
                )}
              </CardContent>
            </Card>
          </div>

          <aside className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Approval Queue</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {pendingApprovalRows.length === 0 ? (
                  <div className="rounded border border-gray-100 p-3 text-sm text-gray-500">No pending approvals.</div>
                ) : pendingApprovalRows.map(row => (
                  <button key={row.id} className="w-full rounded border border-gray-100 p-3 text-left transition hover:border-blue-200 hover:bg-blue-50/40 rtl:text-right" onClick={() => setSelectedRow(row)}>
                    <div className="font-semibold">{row.reference}</div>
                    <div className="text-xs text-gray-500">{row.customer}</div>
                    <div className="mt-2 flex items-center justify-between gap-2">
                      <span className={cn('text-xs font-bold', row.margin < 15 ? 'text-rose-600' : 'text-amber-600')}>{row.margin}% margin</span>
                      <span className="text-xs text-gray-500">{formatCurrency(row.totalSelling, { currency: row.version.pricing.currency })}</span>
                    </div>
                  </button>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Revenue Pipeline</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {(['Draft', 'Sent', 'Revised', 'Approved', 'Rejected'] as QuotationStatus[]).map(status => {
                  const statusRows = rows.filter(row => row.version.status === status);
                  const value = statusRows.reduce((sum, row) => sum + row.totalSelling, 0);
                  const width = metrics.totalValue ? Math.max(6, Math.round((value / metrics.totalValue) * 100)) : 0;
                  return (
                    <div key={status}>
                      <div className="mb-1 flex justify-between text-xs">
                        <span>{status} ({statusRows.length})</span>
                        <span className="font-bold">{formatCurrency(value)}</span>
                      </div>
                      <div className="h-2 rounded-full bg-gray-100">
                        <div className="h-2 rounded-full bg-blue-600" style={{ width: `${width}%` }} />
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {rows.slice(0, 4).map(row => (
                  <div key={row.id} className="rounded border border-gray-100 p-3 text-sm">
                    <div className="font-semibold">{row.version.status === 'Approved' ? 'Proposal Approved' : row.version.status === 'Sent' ? 'Proposal Sent' : 'Quotation Updated'}</div>
                    <div className="text-xs text-gray-500">{row.reference} - {formatDate(row.createdAt)}</div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </aside>
        </div>
      </div>

      {selectedRow && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/30" onClick={() => setSelectedRow(null)}>
          <div className="h-full w-full max-w-xl overflow-y-auto bg-white p-6 shadow-2xl dark:bg-gray-900" onClick={(event) => event.stopPropagation()}>
            <div className="mb-6 flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-bold uppercase tracking-widest text-gray-400">Quotation Summary</div>
                <h2 className="mt-1 text-2xl font-bold">{selectedRow.reference}</h2>
                <p className="text-sm text-gray-500">{selectedRow.customer} / {selectedRow.version.programOverview.title}</p>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setSelectedRow(null)}>
                <X className="h-5 w-5" />
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <SummaryBox label="Status" value={<QuotationStatusBadge status={selectedRow.version.status} />} />
              <SummaryBox label="Version" value={`v${selectedRow.version.versionNumber}`} />
              <SummaryBox label="Selling Price" value={formatCurrency(selectedRow.totalSelling, { currency: selectedRow.version.pricing.currency })} />
              <SummaryBox label="Gross Profit" value={`${formatCurrency(selectedRow.profit, { currency: selectedRow.version.pricing.currency })} / ${selectedRow.margin}%`} />
            </div>

            <Card className="mt-4">
              <CardHeader>
                <CardTitle className="text-base">Workflow Validation</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <ValidationRow passed={selectedRow.version.customerInfo.name.length > 0} label="Customer information completed" />
                <ValidationRow passed={(selectedRow.version.serviceLines || []).length > 0 || selectedRow.version.costing.length > 0} label="Costing and services available" />
                <ValidationRow passed={!needsApproval(selectedRow)} label="Approval rules satisfied" />
                <ValidationRow passed={(selectedRow.version.attachments || []).some(item => item.status === 'Verified') || (selectedRow.version.attachments || []).length === 0} label="Documents verified or not required" />
              </CardContent>
            </Card>

            <Card className="mt-4">
              <CardHeader>
                <CardTitle className="text-base">Approval Decisions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {(selectedRow.version.approvalReviews || []).length === 0 ? (
                  <div className="text-sm text-gray-500">No approval decisions logged.</div>
                ) : selectedRow.version.approvalReviews?.map(review => (
                  <div key={review.id} className="rounded border border-gray-100 p-3 text-sm">
                    <div className="flex justify-between gap-2">
                      <span className="font-semibold">{review.reviewer}</span>
                      <span className="font-bold">{review.status}</span>
                    </div>
                    <div className="text-xs text-gray-500">{formatDate(review.date)} - {review.notes}</div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <div className="mt-6 grid grid-cols-2 gap-2">
              <Button variant="outline" onClick={() => navigate(`/sales/cases/${selectedRow.caseId}/quotations/${selectedRow.id}/preview`)}>
                <Eye className="h-4 w-4" />
                Preview
              </Button>
              <Button variant="outline" onClick={() => navigate(`/sales/cases/${selectedRow.caseId}/quotations/${selectedRow.id}/print`)}>
                <Printer className="h-4 w-4" />
                Print
              </Button>
              <Button variant="outline" onClick={() => navigate(`/sales/cases/${selectedRow.caseId}/quotations/${selectedRow.id}/edit`)}>
                <Edit className="h-4 w-4" />
                Edit / New Version
              </Button>
              <Button onClick={() => navigate(`/sales/cases/${selectedRow.caseId}/quotations/${selectedRow.id}/edit`)}>
                <Send className="h-4 w-4" />
                Continue Workflow
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const needsApproval = (row: QuoteRow) => {
  return row.version.status === 'Draft'
    || row.version.status === 'Revised'
    || row.margin < 15
    || Boolean(row.version.pricing.manualOverride)
    || Boolean(row.version.profitAnalysis?.lowMarginWarning);
};

const MetricCard: React.FC<{
  icon: React.ElementType;
  label: string;
  value: string;
  detail: string;
  tone?: 'blue' | 'green' | 'amber' | 'red';
}> = ({ icon: Icon, label, value, detail, tone = 'blue' }) => {
  const tones = {
    blue: 'text-blue-600 bg-blue-50',
    green: 'text-emerald-600 bg-emerald-50',
    amber: 'text-amber-600 bg-amber-50',
    red: 'text-rose-600 bg-rose-50'
  };

  return (
    <Card className="border-none shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate text-[10px] font-bold uppercase tracking-widest text-gray-400">{label}</p>
            <p className="mt-1 truncate text-2xl font-bold text-gray-900 dark:text-white">{value}</p>
            <p className="mt-1 text-xs font-medium text-gray-500">{detail}</p>
          </div>
          <div className={cn('rounded-xl p-2', tones[tone])}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const SummaryBox: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
  <div className="rounded border border-gray-100 p-3">
    <div className="text-xs text-gray-500">{label}</div>
    <div className="mt-1 font-bold">{value}</div>
  </div>
);

const ValidationRow: React.FC<{ passed: boolean; label: string }> = ({ passed, label }) => (
  <div className="flex items-center gap-2">
    {passed ? <CheckCircle className="h-4 w-4 text-emerald-600" /> : <XCircle className="h-4 w-4 text-amber-600" />}
    <span>{label}</span>
  </div>
);

export default QuotationDashboardPage;
