import React, { useState } from 'react';
import { Clock, AlertTriangle, CheckCircle, Plus, Eye, Edit, ArrowLeft, Search, Filter } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Card, CardContent } from '../ui/Card';
import { useNavigate } from 'react-router-dom';
import { formatDate } from '../../utils/format';
import { useToastContext } from '../../contexts/ToastContext';
// removed TaskModal
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

export interface SalesTask {
    id: string;
    title: string;
    customer: string;
    caseId: string;
    dueDate: string;
    priority: string;
    status: string;
    description: string;
}

const mockTasks: SalesTask[] = [
    {
        id: 'TSK-001',
        title: 'Follow up on Luxor Package',
        customer: 'Ahmed Hassan',
        caseId: 'CS-2025-001',
        dueDate: new Date().toISOString().split('T')[0],
        priority: 'High',
        status: 'Due Today',
        description: 'Customer requested more details about hotel views and Nile felucca ride.'
    },
    {
        id: 'TSK-002',
        title: 'Send Finance Report',
        customer: 'Cairo Tours Ltd',
        caseId: 'CS-2025-015',
        dueDate: new Date(Date.now() - 86400000).toISOString().split('T')[0],
        priority: 'Critical',
        status: 'Overdue',
        description: 'Monthly statement for December 2024 is still pending.'
    },
    {
        id: 'TSK-003',
        title: 'Voice Call with Corporate Admin',
        customer: 'Global Travel Co',
        caseId: 'CS-2025-022',
        dueDate: new Date().toISOString().split('T')[0],
        priority: 'Medium',
        status: 'Due Today',
        description: 'Discuss new annual contract terms and group discounts.'
    },
    {
        id: 'TSK-004',
        title: 'Confirm Flight Booking',
        customer: 'Mariam Mahmoud',
        caseId: 'CS-2025-008',
        dueDate: new Date().toISOString().split('T')[0],
        priority: 'High',
        status: 'Completed',
        description: 'Cairo to Luxor flight options confirmed and sent to customer.'
    }
];

export const TodayTasksPage: React.FC = () => {
    const navigate = useNavigate();
    const toast = useToastContext();
    const { t, isRTL } = useLocale();
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('All');
    const [tasks, setTasks] = useState<SalesTask[]>(mockTasks);

    // Modal states
    // removed TaskModal states
    const [selectedTask, setSelectedTask] = useState<SalesTask | null>(null);
    const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
    const [isSaving, setIsSaving] = useState(false);

    const handleAction = (type: 'view' | 'edit' | 'complete', task: SalesTask) => {
        setSelectedTask(task);
        if (type === 'view') {
            navigate('/sales/task', { state: { task, mode: 'view' } });
        } else if (type === 'edit') {
            navigate('/sales/task', { state: { task, mode: 'edit' } });
        } else if (type === 'complete') {
            setIsConfirmModalOpen(true);
        }
    };

    const handleConfirmComplete = async () => {
        if (!selectedTask) return;

        setIsSaving(true);
        try {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 600));

            const updatedTasks = tasks.map(tTask =>
                tTask.id === selectedTask.id ? { ...tTask, status: 'Completed' } : tTask
            );
            setTasks(updatedTasks);
            toast.success(t('sales.toast.taskCompleted'), t('sales.toast.taskCompletedDesc').replace('{title}', selectedTask.title));
            setIsConfirmModalOpen(false);
        } catch {
            toast.error(t('sales.toast.error'), t('sales.toast.errorComplete'));
        } finally {
            setIsSaving(false);
        }
    };

    const handleViewCase = (caseId: string) => {
        navigate(`/sales/cases/${caseId}`);
    };

    // handleSaveTask logic is moved to TaskPage

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'Overdue': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
            case 'Due Today': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
            case 'Completed': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
            default: return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
        }
    };

    const getLocalizedStatus = (status: string) => {
        switch (status) {
            case 'Overdue': return t('sales.tasks.overdue');
            case 'Due Today': return t('sales.tasks.dueToday');
            case 'Completed': return t('sales.tasks.completed');
            case 'Pending': return t('sales.tasks.pending');
            default: return status;
        }
    };

    const getPriorityColor = (priority: string) => {
        switch (priority) {
            case 'Critical': return 'bg-red-500 text-white';
            case 'High': return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300';
            case 'Medium': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
            default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
        }
    };

    const getLocalizedPriority = (priority: string) => {
        switch (priority) {
            case 'Critical': return isRTL ? 'حرجة' : 'Critical';
            case 'High': return isRTL ? 'مرتفعة' : 'High';
            case 'Medium': return isRTL ? 'متوسطة' : 'Medium';
            case 'Low': return isRTL ? 'منخفضة' : 'Low';
            default: return priority;
        }
    };

    const filteredTasks = tasks.filter(task => {
        const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            task.customer.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = statusFilter === 'All' || task.status === statusFilter;
        return matchesSearch && matchesStatus;
    });

    const overdueCount = tasks.filter(tTask => tTask.status === 'Overdue').length;
    const dueTodayCount = tasks.filter(tTask => tTask.status === 'Due Today').length;
    const completedCount = tasks.filter(tTask => tTask.status === 'Completed').length;

    return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
                    <div className={cn("flex items-center gap-2 sm:gap-4 banner-actions", isRTL && "flex-row-reverse")}>
                        <Button variant="outline" onClick={() => navigate('/sales')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                            <ArrowLeft size={20} className={isRTL ? 'rtl-flip' : ''} />
                        </Button>
                        <div className={cn(isRTL ? "text-right" : "text-left")}>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">{t('sales.tasks.title')}</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">{t('sales.tasks.subtitle')}</p>
                        </div>
                    </div>
                    <Button className="bg-white text-blue-600 hover:bg-gray-50 border-transparent shadow-sm" onClick={() => navigate('/sales/task', { state: { mode: 'add' } })}>
                        <Plus className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                        {t('sales.tasks.newTask')}
                    </Button>
                </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10 logical-start">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">{t('sales.tasks.overdue')}</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white bidi-isolate">{overdueCount}</p>
                        </div>
                        <AlertTriangle className="absolute ltr:-right-4 rtl:-left-4 -bottom-4 h-24 w-24 text-red-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>

                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10 logical-start">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">{t('sales.tasks.dueToday')}</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white bidi-isolate">{dueTodayCount}</p>
                        </div>
                        <Clock className="absolute ltr:-right-4 rtl:-left-4 -bottom-4 h-24 w-24 text-amber-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>

                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10 logical-start">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">{t('sales.tasks.completed')}</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white bidi-isolate">{completedCount}</p>
                        </div>
                        <CheckCircle className="absolute ltr:-right-4 rtl:-left-4 -bottom-4 h-24 w-24 text-green-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>
            </div>

            {/* Main Content Area */}
            <Card>
                <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
                        <div className="relative flex-1 max-w-md">
                            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400`} />
                            <Input
                                placeholder={t('sales.tasks.searchPlaceholder')}
                                className={isRTL ? 'pr-10 pl-3' : 'pl-10 pr-3'}
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="flex items-center gap-2">
                                <Filter size={16} className="text-gray-400" />
                                <Select
                                    value={statusFilter}
                                    onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setStatusFilter(e.target.value)}
                                    className="w-40"
                                >
                                    <option value="All">{t('sales.filter.allStatus')}</option>
                                    <option value="Overdue">{t('sales.tasks.overdue')}</option>
                                    <option value="Due Today">{t('sales.tasks.dueToday')}</option>
                                    <option value="Pending">{t('sales.tasks.pending')}</option>
                                    <option value="Completed">{t('sales.tasks.completed')}</option>
                                </Select>
                            </div>
                        </div>
                    </div>

                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead className="bg-gray-50 dark:bg-gray-800">
                                <tr>
                                    <th className={`px-6 py-3 ${isRTL ? 'text-right' : 'text-left'} text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider`}>{t('sales.tasks.colTaskDetails')}</th>
                                    <th className={`px-6 py-3 ${isRTL ? 'text-right' : 'text-left'} text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider`}>{t('sales.tasks.colCustomer')}</th>
                                    <th className={`px-6 py-3 ${isRTL ? 'text-right' : 'text-left'} text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider`}>{t('sales.tasks.colDueDate')}</th>
                                    <th className={`px-6 py-3 ${isRTL ? 'text-right' : 'text-left'} text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider`}>{t('sales.tasks.colPriority')}</th>
                                    <th className={`px-6 py-3 ${isRTL ? 'text-right' : 'text-left'} text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider`}>{t('sales.tasks.colStatus')}</th>
                                    <th className={`px-6 py-3 ${isRTL ? 'text-left' : 'text-right'} text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider`}>{t('sales.tasks.colActions')}</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                                {filteredTasks.map((task) => (
                                    <tr key={task.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                                        <td className="px-6 py-4">
                                            <div className="flex flex-col">
                                                <span className="text-sm font-semibold text-gray-900 dark:text-white">{task.title}</span>
                                                <span className="text-xs text-gray-500 dark:text-gray-400 truncate max-w-[200px]">{task.description}</span>
                                                <span
                                                    onClick={() => handleViewCase(task.caseId)}
                                                    className="text-[10px] text-blue-500 font-medium mt-1 cursor-pointer hover:underline bidi-isolate"
                                                >
                                                    {t('sales.tasks.colCaseId')}: {task.caseId}
                                                </span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                                            {task.customer}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400 font-mono bidi-isolate">
                                            {formatDate(task.dueDate)}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className={`inline-flex px-2 py-1 text-[10px] font-bold rounded uppercase tracking-wider ${getPriorityColor(task.priority)}`}>
                                                {getLocalizedPriority(task.priority)}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(task.status)}`}>
                                                {getLocalizedStatus(task.status)}
                                            </span>
                                        </td>
                                        <td className={`px-6 py-4 whitespace-nowrap ${isRTL ? 'text-left' : 'text-right'} text-sm font-medium`}>
                                            <div className="flex justify-end gap-2">
                                                <button
                                                    type="button"
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        handleAction('view', task);
                                                    }}
                                                    className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors text-blue-600 dark:text-blue-400"
                                                    title={t('sales.tasks.viewDetails')}
                                                >
                                                    <Eye size={18} />
                                                </button>
                                                <button
                                                    type="button"
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        handleAction('edit', task);
                                                    }}
                                                    className="p-1.5 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors text-green-600 dark:text-green-400"
                                                    title={t('sales.tasks.editTask')}
                                                >
                                                    <Edit size={18} />
                                                </button>
                                                <button
                                                    type="button"
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        if (task.status !== 'Completed') {
                                                            handleAction('complete', task);
                                                        }
                                                    }}
                                                    className={`p-1.5 rounded-lg transition-colors ${task.status === 'Completed'
                                                        ? 'text-gray-300 dark:text-gray-600 cursor-not-allowed'
                                                        : 'text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20'
                                                        }`}
                                                    title={task.status === 'Completed' ? t('sales.tasks.alreadyCompleted') : t('sales.tasks.markComplete')}
                                                    disabled={task.status === 'Completed'}
                                                >
                                                    <CheckCircle size={18} />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>

            {/* TaskModal removed in favor of TaskPage */}

            <ConfirmationModal
                isOpen={isConfirmModalOpen}
                onClose={() => setIsConfirmModalOpen(false)}
                onConfirm={handleConfirmComplete}
                title={t('sales.tasks.confirmTitle')}
                message={t('sales.tasks.confirmMessage').replace('{title}', selectedTask?.title || '')}
                confirmText={t('sales.tasks.confirmBtn')}
                variant="success"
                isLoading={isSaving}
            />
            </div>
        </div>
    );
};
