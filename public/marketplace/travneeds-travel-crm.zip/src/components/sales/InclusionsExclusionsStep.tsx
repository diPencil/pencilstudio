import React, { useState } from 'react';
import { Plus, Trash2, GripVertical } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { QuotationVersion } from '../../types/quotation';

interface InclusionsExclusionsStepProps {
    data: QuotationVersion;
    updateData: (data: Partial<QuotationVersion>) => void;
}

export const InclusionsExclusionsStep: React.FC<InclusionsExclusionsStepProps> = ({ data, updateData }) => {
    const [newItem, setNewItem] = useState('');

    const addItem = (type: 'inclusions' | 'exclusions') => {
        if (!newItem.trim()) return;
        const currentList = [...data[type]];
        updateData({ [type]: [...currentList, newItem.trim()] });
        setNewItem('');
    };

    const removeItem = (type: 'inclusions' | 'exclusions', index: number) => {
        const currentList = [...data[type]];
        currentList.splice(index, 1);
        updateData({ [type]: currentList });
    };

    const defaultSuggestions = [
        "Accommodation", "Daily Breakfast", "Airport Transfers", 
        "Licensed English Speaking Guide", "Entrance Fees", "Lunch as per itinerary",
        "Dinner as per itinerary", "Travel Insurance", "Visa Fees", "Tips & Gratuities"
    ];

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Inclusions Section */}
                <div className="space-y-4">
                    <div className="flex items-center justify-between">
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                            Inclusions
                            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full text-[10px]">{data.inclusions.length} items</span>
                        </h3>
                    </div>
                    
                    <div className="flex gap-2">
                        <Input 
                            placeholder="Add inclusion..." 
                            value={newItem}
                            onChange={(e) => setNewItem(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && addItem('inclusions')}
                        />
                        <Button type="button" onClick={() => addItem('inclusions')}>
                            <Plus className="h-4 w-4" />
                        </Button>
                    </div>

                    <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                        {data.inclusions.map((item, index) => (
                            <div key={index} className="flex items-center gap-2 bg-white dark:bg-gray-800 p-2 rounded-lg border border-gray-100 dark:border-gray-700 group">
                                <GripVertical className="h-4 w-4 text-gray-300 cursor-move" />
                                <span className="flex-1 text-sm text-gray-700 dark:text-gray-300">{item}</span>
                                <button 
                                    onClick={() => removeItem('inclusions', index)}
                                    className="opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-rose-500 transition-opacity"
                                >
                                    <Trash2 className="h-4 w-4" />
                                </button>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Exclusions Section */}
                <div className="space-y-4">
                    <div className="flex items-center justify-between">
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                            Exclusions
                            <span className="px-2 py-0.5 bg-rose-100 text-rose-700 rounded-full text-[10px]">{data.exclusions.length} items</span>
                        </h3>
                    </div>

                    <div className="flex gap-2">
                        <Input 
                            placeholder="Add exclusion..." 
                            onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                    const val = (e.target as HTMLInputElement).value;
                                    if (val) {
                                        updateData({ exclusions: [...data.exclusions, val] });
                                        (e.target as HTMLInputElement).value = '';
                                    }
                                }
                            }}
                        />
                    </div>

                    <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                        {data.exclusions.map((item, index) => (
                            <div key={index} className="flex items-center gap-2 bg-white dark:bg-gray-800 p-2 rounded-lg border border-gray-100 dark:border-gray-700 group">
                                <GripVertical className="h-4 w-4 text-gray-300 cursor-move" />
                                <span className="flex-1 text-sm text-gray-700 dark:text-gray-300">{item}</span>
                                <button 
                                    onClick={() => removeItem('exclusions', index)}
                                    className="opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-rose-500 transition-opacity"
                                >
                                    <Trash2 className="h-4 w-4" />
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Suggestions */}
            <div className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-xl">
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-3">Quick Add Suggestions</h4>
                <div className="flex flex-wrap gap-2">
                    {defaultSuggestions.map((s, i) => (
                        <button 
                            key={i} 
                            onClick={() => {
                                if (!data.inclusions.includes(s)) {
                                    updateData({ inclusions: [...data.inclusions, s] });
                                }
                            }}
                            className="px-3 py-1 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-full text-xs hover:border-blue-500 hover:text-blue-600 transition-colors shadow-sm"
                        >
                            + {s}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};
