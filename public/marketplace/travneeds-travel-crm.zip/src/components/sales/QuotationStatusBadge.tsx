import React from 'react';
import { QuotationStatus } from '../../types/quotation';
import { useLocale } from '../../localization/useLocale';

interface QuotationStatusBadgeProps {
  status: QuotationStatus;
  className?: string;
}

export const QuotationStatusBadge: React.FC<QuotationStatusBadgeProps> = ({ status, className = '' }) => {
  const { t } = useLocale();

  const getStatusStyles = () => {
    switch (status) {
      case 'Draft':
        return 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300 border-gray-200 dark:border-gray-700';
      case 'Sent':
        return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 border-blue-200 dark:border-blue-800';
      case 'Revised':
        return 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400 border-purple-200 dark:border-purple-800';
      case 'Approved':
        return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800';
      case 'Rejected':
        return 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400 border-rose-200 dark:border-rose-800';
      case 'Expired':
        return 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border-amber-200 dark:border-amber-800';
      default:
        return 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300 border-gray-200 dark:border-gray-700';
    }
  };

  const getLocalizedStatus = () => {
    switch (status) {
      case 'Draft':
        return t('sales.status.draft');
      case 'Sent':
        return t('sales.status.sent');
      case 'Revised':
        return t('sales.status.revised');
      case 'Approved':
        return t('sales.status.approved');
      case 'Rejected':
        return t('sales.status.rejected');
      case 'Expired':
        return t('sales.status.expired');
      default:
        return status;
    }
  };

  return (
    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase tracking-wider ${getStatusStyles()} ${className}`}>
      {getLocalizedStatus()}
    </span>
  );
};
