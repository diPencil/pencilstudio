import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, Plus, Search, Trash2, Edit, Save, X, Tag } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { mockItems, mockSuppliers } from '../../services/mockData';
import type { ProductServiceItem } from '../../types';
import type { CostCategory, QuotationCostItem, QuotationServiceLine, QuotationVersion, QuotationFixedCost } from '../../types/quotation';
import type { TranslationKey } from '../../localization/messages';
import {
    buildCostSummaryFromServiceLines,
    calculateServiceLineTotals,
    calculateFixedCostItemTotal
} from '../../utils/quotationCalculations';
import { useLocale } from '../../localization/useLocale';
import { formatCurrency } from '../../utils/format';

interface CostingStepProps {
    data: QuotationVersion;
    updateData: (updates: Partial<QuotationVersion>) => void;
}

const toCostCategory = (item: ProductServiceItem): CostCategory => {
    if (item.category === 'Accommodation' || item.type === 'Hotel') return 'Accommodation';
    if (item.category === 'Transfers' || item.type === 'Transfer') return 'Transfers';
    if (item.category === 'Tours' || item.type === 'Sightseeing') return 'Sightseeing';
    if (item.category === 'Flight' || item.type === 'Airline') return 'Services';
    if (item.category === 'Cruise' || item.type === 'Cruise') return 'Services';
    return 'Optional';
};

const supplierRisk = (supplierId?: string) => {
    if (!supplierId) return { label: 'Missing' as const, warning: 'Supplier is missing.' };
    const supplier = mockSuppliers.find(entry => entry.id === supplierId);
    const score = supplier?.performance?.qualityScore || 0;
    if (score < 70) return { label: 'High Risk' as const, warning: 'Supplier performance is high risk.' };
    if (score < 85) return { label: 'Monitor' as const, warning: 'Supplier should be monitored.' };
    return { label: 'Healthy' as const, warning: '' };
};

const badgeClass = (status: string) => {
    if (status === 'Active' || status === 'Healthy') return 'bg-emerald-50 text-emerald-700 border-emerald-100';
    if (status === 'Draft' || status === 'Needs review' || status === 'Monitor') return 'bg-amber-50 text-amber-700 border-amber-100';
    return 'bg-rose-50 text-rose-700 border-rose-100';
};

const buildServiceLine = (item: ProductServiceItem, pax: number): QuotationServiceLine => {
    const risk = supplierRisk(item.supplierId);
    const line = calculateServiceLineTotals({
        id: `QL-${Date.now()}-${item.id}`,
        productId: item.id,
        serviceName: item.name,
        category: toCostCategory(item),
        type: item.type,
        destination: item.destination,
        supplierId: item.supplierId,
        supplierName: item.supplierName,
        supplierStatus: mockSuppliers.find(supplier => supplier.id === item.supplierId)?.status,
        supplierRisk: risk.label,
        productStatus: item.status,
        costPrice: item.costPrice,
        sellingPrice: item.sellingPrice,
        quantity: 1,
        nights: item.type === 'Hotel' || item.type === 'Cruise' ? Math.max(1, item.attributes.duration?.match(/\d+/)?.[0] ? Number(item.attributes.duration.match(/\d+/)?.[0]) : 1) : 1,
        pax: item.type === 'Hotel' || item.type === 'Cruise' ? 1 : Math.max(1, pax || 1),
        units: 1,
        taxes: 0,
        adjustment: 0,
        totalCost: 0,
        totalSelling: 0,
        profit: 0,
        marginPercent: 0,
        day: 1,
        availability: item.availability,
        notes: item.notes,
        warning: item.status !== 'Active' ? `Service status is ${item.status}.` : risk.warning
    });
    return line;
};

const toCostItems = (lines: QuotationServiceLine[]): QuotationCostItem[] => lines.map(line => ({
    id: line.id,
    name: line.serviceName,
    category: line.category,
    city: line.destination,
    description: line.notes,
    rate: line.costPrice,
    currency: 'USD',
    pricingType: line.nights > 1 ? 'Per Night' : 'Per Person',
    quantity: line.quantity * Math.max(1, line.pax || 1) * Math.max(1, line.units || 1),
    nights: line.nights,
    totalCost: line.totalCost,
    notes: line.warning
}));

export const CostingStep: React.FC<CostingStepProps> = ({ data, updateData }) => {
    const { t, isRTL, direction } = useLocale();
    const navigate = useNavigate();
    const serviceLines = data.serviceLines || [];
    const [searchTerm, setSearchTerm] = useState('');
    const [categoryFilter, setCategoryFilter] = useState('All Categories');
    const [supplierFilter, setSupplierFilter] = useState('All Suppliers');
    const [destinationFilter, setDestinationFilter] = useState('All Destinations');

    const categories = Array.from(new Set(mockItems.map(item => item.category)));
    const destinations = Array.from(new Set(mockItems.flatMap(item => item.destinationCoverage.map(destination => destination.destination))));

    const filteredItems = useMemo(() => mockItems.filter(item => {
        const supplier = mockSuppliers.find(entry => entry.id === item.supplierId);
        const searchable = [item.name, item.category, item.type, item.destination, item.supplierName, supplier?.name].join(' ').toLowerCase();
        return searchable.includes(searchTerm.toLowerCase())
            && (categoryFilter === 'All Categories' || item.category === categoryFilter)
            && (supplierFilter === 'All Suppliers' || item.supplierId === supplierFilter || (supplierFilter === 'Without supplier' && !item.supplierId))
            && (destinationFilter === 'All Destinations' || item.destinationCoverage.some(destination => destination.destination === destinationFilter));
    }), [categoryFilter, destinationFilter, searchTerm, supplierFilter]);

    const fixedCostsList = data.fixedCosts || [];
    const [isFixedFormOpen, setIsFixedFormOpen] = useState(false);
    const [editingFixedCost, setEditingFixedCost] = useState<QuotationFixedCost | null>(null);

    const [fixedName, setFixedName] = useState('');
    const [fixedCategory, setFixedCategory] = useState('Tour Guide');
    const [fixedSupplierName, setFixedSupplierName] = useState('');
    const [fixedAmount, setFixedAmount] = useState('0');
    const [fixedCurrency, setFixedCurrency] = useState('USD');
    const [fixedAllocationMethod, setFixedAllocationMethod] = useState<'Split Equally' | 'Per Person' | 'Per Group' | 'Per Day'>('Split Equally');
    const [fixedQuantity, setFixedQuantity] = useState('1');
    const [fixedDays, setFixedDays] = useState('1');
    const [fixedNotes, setFixedNotes] = useState('');
    const [fixedStatus, setFixedStatus] = useState<'Active' | 'Inactive'>('Active');

    const updateFixedCosts = (nextFixedCosts: QuotationFixedCost[]) => {
        updateData({
            fixedCosts: nextFixedCosts,
            costSummary: buildCostSummaryFromServiceLines(serviceLines, data.customerInfo.pax.total, nextFixedCosts)
        });
    };

    const openAddFixedForm = () => {
        setEditingFixedCost(null);
        setFixedName('');
        setFixedCategory('Tour Guide');
        setFixedSupplierName('');
        setFixedAmount('0');
        setFixedCurrency('USD');
        setFixedAllocationMethod('Split Equally');
        setFixedQuantity('1');
        setFixedDays('1');
        setFixedNotes('');
        setFixedStatus('Active');
        setIsFixedFormOpen(true);
    };

    const openEditFixedForm = (item: QuotationFixedCost) => {
        setEditingFixedCost(item);
        setFixedName(item.name);
        setFixedCategory(item.category);
        setFixedSupplierName(item.supplierName || '');
        setFixedAmount(item.amount.toString());
        setFixedCurrency(item.currency);
        setFixedAllocationMethod(item.allocationMethod as 'Split Equally' | 'Per Person' | 'Per Group' | 'Per Day');
        setFixedQuantity(item.quantity.toString());
        setFixedDays((item.days || 1).toString());
        setFixedNotes(item.notes || '');
        setFixedStatus(item.status);
        setIsFixedFormOpen(true);
    };

    const handleSaveFixedCost = () => {
        if (!fixedName.trim()) return;
        const newItem: QuotationFixedCost = {
            id: editingFixedCost ? editingFixedCost.id : `FC-${Date.now()}`,
            name: fixedName.trim(),
            category: fixedCategory,
            supplierName: fixedSupplierName.trim() || undefined,
            amount: Number(fixedAmount) || 0,
            currency: fixedCurrency,
            allocationMethod: fixedAllocationMethod,
            quantity: Number(fixedQuantity) || 1,
            days: Number(fixedDays) || 1,
            notes: fixedNotes.trim() || undefined,
            status: fixedStatus
        };

        const nextList = editingFixedCost 
            ? fixedCostsList.map(item => item.id === editingFixedCost.id ? newItem : item)
            : [...fixedCostsList, newItem];

        updateFixedCosts(nextList);
        setIsFixedFormOpen(false);
        setEditingFixedCost(null);
    };

    const handleDeleteFixedCost = (id: string) => {
        const nextList = fixedCostsList.filter(item => item.id !== id);
        updateFixedCosts(nextList);
    };

    const commitLines = (lines: QuotationServiceLine[]) => {
        const calculated = lines.map(calculateServiceLineTotals);
        updateData({
            serviceLines: calculated,
            costing: toCostItems(calculated),
            costSummary: buildCostSummaryFromServiceLines(calculated, data.customerInfo.pax.total, data.fixedCosts)
        });
    };

    const addService = (item: ProductServiceItem) => {
        commitLines([...serviceLines, buildServiceLine(item, data.customerInfo.pax.total)]);
    };

    const updateLine = (id: string, updates: Partial<QuotationServiceLine>) => {
        commitLines(serviceLines.map(line => line.id === id ? calculateServiceLineTotals({ ...line, ...updates }) : line));
    };

    const removeLine = (id: string) => commitLines(serviceLines.filter(line => line.id !== id));

    const costSummary = buildCostSummaryFromServiceLines(serviceLines, data.customerInfo.pax.total, data.fixedCosts);

    const complimentaryCount = serviceLines.filter(line => line.isComplimentary).length;
    const complimentaryCost = serviceLines.filter(line => line.isComplimentary).reduce((sum, line) => sum + line.totalCost, 0);
    const complimentaryRatio = costSummary.groupTotalCost > 0 ? (complimentaryCost / costSummary.groupTotalCost) * 100 : 0;

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{t('quotation.costing.addServices')}</h3>
                    <p className="text-sm text-gray-500">{t('products.form.subtitle')}</p>
                </div>
                <Button variant="outline" size="sm" onClick={() => navigate('/product-categories')}>{t('products.details.backToProducts')}</Button>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>{t('quotation.costing.addServices')}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 gap-3 lg:grid-cols-[1.4fr_repeat(3,1fr)]">
                        <div className="relative">
                            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400`} />
                            <Input placeholder={t('quotation.costing.searchPlaceholder')} value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} className={isRTL ? 'pr-10 pl-4' : 'pl-10 pr-4'} />
                        </div>
                        <Select value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)}>
                            <option value="All Categories">{t('quotation.costing.filter.category')}</option>
                            {categories.map(category => <option key={category} value={category}>{category}</option>)}
                        </Select>
                        <Select value={supplierFilter} onChange={(event) => setSupplierFilter(event.target.value)}>
                            <option value="All Suppliers">{t('quotation.costing.filter.supplier')}</option>
                            <option value="Without supplier">{t('products.status.withoutSupplier')}</option>
                            {mockSuppliers.map(supplier => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}
                        </Select>
                        <Select value={destinationFilter} onChange={(event) => setDestinationFilter(event.target.value)}>
                            <option value="All Destinations">{t('products.catalog.filter.allDestinations')}</option>
                            {destinations.map(destination => <option key={destination} value={destination}>{destination}</option>)}
                        </Select>
                    </div>

                    <div className="overflow-x-auto">
                        <table style={{ direction }} className="w-full min-w-[920px] text-sm">
                            <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-500">
                                <tr>
                                    <th className="px-4 py-3 logical-start">{t('quotation.costing.table.service')}</th>
                                    <th className="px-4 py-3 logical-start">{t('quotation.costing.table.category')} / {t('quotation.costing.table.type')}</th>
                                    <th className="px-4 py-3 logical-start">{t('quotation.costing.table.city')}</th>
                                    <th className="px-4 py-3 logical-start">{t('quotation.costing.table.supplier')}</th>
                                    <th className="px-4 py-3 logical-start">{t('quotation.costing.table.cost')}</th>
                                    <th className="px-4 py-3 logical-start">{t('products.catalog.table.selling')}</th>
                                    <th className="px-4 py-3 logical-start">{t('quotation.costing.table.status')}</th>
                                    <th className="px-4 py-3 logical-end">{t('quotation.costing.table.actions')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredItems.map(item => {
                                    const supplier = mockSuppliers.find(entry => entry.id === item.supplierId);
                                    const risk = supplierRisk(item.supplierId);
                                    const translatedRisk = risk.label === 'Missing' ? t('quotation.costing.supplierMissing') : risk.label === 'High Risk' ? t('quotation.costing.supplierHighRisk') : risk.label === 'Monitor' ? t('quotation.costing.supplierMonitor') : t('quotation.costing.supplierHealthy');
                                    const translatedWarning = risk.label === 'Missing' ? t('quotation.costing.supplierMissingWarn') : risk.label === 'High Risk' ? t('quotation.costing.supplierHighRiskWarn') : risk.label === 'Monitor' ? t('quotation.costing.supplierMonitorWarn') : '';
                                    return (
                                        <tr key={item.id} className="border-t hover:bg-gray-50">
                                            <td className="px-4 py-3 logical-start">
                                                <div className="font-semibold">{item.name}</div>
                                                {(item.status !== 'Active' || risk.label !== 'Healthy') && (
                                                    <div className="mt-1 flex items-center gap-1 text-xs text-amber-600">
                                                        <AlertTriangle className="h-3 w-3" />
                                                        {item.status !== 'Active' ? `${t('products.catalog.table.status')}: ${t(`products.status.${item.status.toLowerCase()}` as TranslationKey) || item.status}` : translatedWarning}
                                                    </div>
                                                )}
                                            </td>
                                            <td className="px-4 py-3 logical-start">{item.category} / {t(`products.type.${item.type.toLowerCase()}` as TranslationKey) || item.type}</td>
                                            <td className="px-4 py-3 logical-start">{item.destination}</td>
                                            <td className="px-4 py-3 logical-start">
                                                {supplier ? (
                                                    <button className="logical-start text-blue-600 hover:underline flex items-center" onClick={() => navigate(`/reservations/suppliers/${supplier.id}`)}>
                                                        {supplier.name}
                                                        <span className={`mx-2 rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(risk.label)}`}>{translatedRisk}</span>
                                                    </button>
                                                ) : (
                                                    <span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass('Without supplier')}`}>{t('quotation.costing.supplierMissing')}</span>
                                                )}
                                            </td>
                                            <td className="px-4 py-3 logical-start bidi-isolate">{formatCurrency(item.costPrice, { currency: 'USD' })}</td>
                                            <td className="px-4 py-3 logical-start bidi-isolate">{formatCurrency(item.sellingPrice, { currency: 'USD' })}</td>
                                            <td className="px-4 py-3 logical-start">
                                                <span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(item.status)}`}>
                                                    {t(`products.status.${item.status.toLowerCase()}` as TranslationKey) || item.status}
                                                </span>
                                            </td>
                                            <td className="px-4 py-3 logical-end">
                                                <Button size="sm" variant={item.status === 'Archived' || item.status === 'Inactive' ? 'outline' : 'primary'} onClick={() => addService(item)}>
                                                    <Plus className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4`} />
                                                    {t('common.add' as TranslationKey) || 'Add'}
                                                </Button>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>{t('quotation.preview.services.title')}</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                    <div className="overflow-x-auto">
                        <table style={{ direction }} className="w-full min-w-[1180px] text-sm">
                            <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-500">
                                <tr>
                                    <th className="px-4 py-3 logical-start">{t('quotation.costing.table.service')}</th>
                                    <th className="px-4 py-3 logical-start">{t('quotation.steps.itinerary')}</th>
                                    <th className="px-4 py-3 logical-start">{t('quotation.costing.fixedCosts.table.qty')}</th>
                                    <th className="px-4 py-3 logical-start">{t('quotation.costing.fixedCosts.table.nights')}</th>
                                    <th className="px-4 py-3 logical-start">{t('quotation.builder.travelers')}</th>
                                    <th className="px-4 py-3 logical-start">{t('products.form.priceUnit')}</th>
                                    <th className="px-4 py-3 logical-start">{t('products.details.pricing.taxes' as TranslationKey) || 'Taxes'}</th>
                                    <th className="px-4 py-3 logical-start">{t('products.details.pricing.adjustments' as TranslationKey) || 'Adjust'}</th>
                                    <th className="px-4 py-3 text-center">{t('quotation.costing.foc')}</th>
                                    <th className="px-4 py-3 logical-start">{t('quotation.costing.fixedCosts.table.total')}</th>
                                    <th className="px-4 py-3 logical-start">{t('products.catalog.table.selling')}</th>
                                    <th className="px-4 py-3 logical-start">{t('products.details.pricing.profit')}</th>
                                    <th className="px-4 py-3 logical-end">{t('quotation.costing.table.actions')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {serviceLines.map(line => (
                                    <tr key={line.id} className="border-t">
                                        <td className="px-4 py-3 logical-start">
                                            <div className="font-semibold">{line.serviceName}</div>
                                            <div className="text-xs text-gray-500">{line.category} - {line.supplierName || t('products.status.withoutSupplier')}</div>
                                            {line.warning && <div className="mt-1 text-xs text-amber-600">{line.warning}</div>}
                                        </td>
                                        <NumberCell value={line.day || 1} onChange={(value) => updateLine(line.id, { day: value })} />
                                        <NumberCell value={line.quantity} onChange={(value) => updateLine(line.id, { quantity: value })} />
                                        <NumberCell value={line.nights} onChange={(value) => updateLine(line.id, { nights: value })} />
                                        <NumberCell value={line.pax} onChange={(value) => updateLine(line.id, { pax: value })} />
                                        <NumberCell value={line.units} onChange={(value) => updateLine(line.id, { units: value })} />
                                        <MoneyCell value={line.taxes} onChange={(value) => updateLine(line.id, { taxes: value })} />
                                        <MoneyCell value={line.adjustment} onChange={(value) => updateLine(line.id, { adjustment: value })} />
                                        <td className="px-4 py-3 text-center">
                                            <input 
                                                type="checkbox" 
                                                className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                                                checked={Boolean(line.isComplimentary)} 
                                                onChange={(e) => updateLine(line.id, { isComplimentary: e.target.checked })} 
                                            />
                                        </td>
                                        <td className="px-4 py-3 logical-start font-bold bidi-isolate">{formatCurrency(line.totalCost, { currency: 'USD' })}</td>
                                        <td className="px-4 py-3 logical-start font-bold">
                                            {line.isComplimentary ? (
                                                <span className="inline-flex rounded-full bg-blue-100 px-2 py-0.5 text-xs font-semibold text-blue-800 dark:bg-blue-900/30 dark:text-blue-400">
                                                    {t('quotation.costing.includedFree')}
                                                </span>
                                            ) : (
                                                <span className="bidi-isolate">{formatCurrency(line.totalSelling, { currency: 'USD' })}</span>
                                            )}
                                        </td>
                                        <td className="px-4 py-3 logical-start font-bold text-emerald-600 bidi-isolate">{formatCurrency(line.profit, { currency: 'USD' })} / {line.marginPercent}%</td>
                                        <td className="px-4 py-3 logical-end">
                                            <button className="rounded-lg p-1.5 text-rose-600 hover:bg-rose-50" onClick={() => removeLine(line.id)} title="Remove">
                                                <Trash2 className="h-4 w-4" />
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                                {serviceLines.length === 0 && (
                                    <tr><td colSpan={13} className="px-4 py-8 text-center text-gray-500">{t('quotation.costing.noServicesFound')}</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>

            {complimentaryCount > 0 && (
                <Card className="bg-blue-50/50 border border-blue-100 dark:bg-blue-950/10 dark:border-blue-900/30">
                    <CardContent className="p-4">
                        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg text-blue-600 dark:text-blue-400">
                                    <Tag className="h-5 w-5" />
                                </div>
                                <div>
                                    <h4 className="font-semibold text-blue-900 dark:text-blue-300">{t('quotation.costing.focSummary')}</h4>
                                    <p className="text-xs text-blue-700 dark:text-blue-400">
                                        {t('quotation.pricing.profitAnalysis.compNotice').replace('{count}', complimentaryCount.toString()).replace('{cost}', formatCurrency(complimentaryCost, { currency: 'USD' }))}
                                    </p>
                                </div>
                            </div>
                            <div className="grid grid-cols-3 gap-6 text-center divide-x rtl:divide-x-reverse divide-blue-100 dark:divide-blue-900/30 md:text-right rtl:md:text-left md:grid-cols-none md:flex md:items-center">
                                <div className="px-3">
                                    <div className="text-xs text-gray-500 uppercase">{t('quotation.costing.foc')}</div>
                                    <div className="text-lg font-bold text-blue-950 dark:text-blue-100 bidi-isolate">{complimentaryCount}</div>
                                </div>
                                <div className="px-3">
                                    <div className="text-xs text-gray-500 uppercase">{t('quotation.costing.focAbsorbed')}</div>
                                    <div className="text-lg font-bold text-blue-950 dark:text-blue-100 bidi-isolate">{formatCurrency(complimentaryCost, { currency: 'USD' })}</div>
                                </div>
                                <div className="px-3">
                                    <div className="text-xs text-gray-500 uppercase">{t('quotation.costing.focMarginImpact')}</div>
                                    <div className="text-lg font-bold text-blue-950 dark:text-blue-100 bidi-isolate">{complimentaryRatio.toFixed(1)}%</div>
                                </div>
                            </div>
                        </div>
                        {complimentaryRatio > 25 && (
                            <div className="mt-3 flex items-start gap-2 rounded-lg bg-amber-50 border border-amber-100 p-2.5 text-xs text-amber-800 dark:bg-amber-950/20 dark:border-amber-900/30 dark:text-amber-400 animate-pulse">
                                <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400 mt-0.5" />
                                <div>
                                    <span className="font-semibold">{t('quotation.costing.focWarningTitle')}</span> {t('quotation.costing.focWarningDesc')}
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>
            )}

            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>{t('quotation.costing.fixedCosts.title')}</CardTitle>
                    {!isFixedFormOpen && (
                        <Button size="sm" onClick={openAddFixedForm}>
                            <Plus className={`${isRTL ? 'ml-1' : 'mr-1'} h-3.5 w-3.5`} /> {t('quotation.costing.fixedCosts.addItem')}
                        </Button>
                    )}
                </CardHeader>
                <CardContent className="space-y-4">
                    {isFixedFormOpen && (
                        <Card className="bg-gray-50 dark:bg-gray-800/20 border border-gray-200 dark:border-gray-700">
                            <CardContent className="p-4 space-y-4">
                                <div className="flex justify-between items-center pb-2 border-b border-gray-200 dark:border-gray-700">
                                    <h5 className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase">
                                        {editingFixedCost ? t('quotation.details.seasonalRates.edit' as TranslationKey) || 'Edit Fixed Cost' : t('quotation.costing.fixedCosts.addItem')}
                                    </h5>
                                    <button onClick={() => setIsFixedFormOpen(false)} className="text-gray-400 hover:text-gray-600">
                                        <X className="h-4 w-4" />
                                    </button>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                                    <Input label={t('quotation.costing.fixedCosts.form.name') + ' *'} value={fixedName} onChange={(e) => setFixedName(e.target.value)} placeholder="e.g. Tour Guide Cairo" />
                                    <Select label={t('quotation.costing.fixedCosts.table.category')} value={fixedCategory} onChange={(e) => setFixedCategory(e.target.value)}>
                                        <option value="Tour Guide">Tour Guide</option>
                                        <option value="Private Vehicle">Private Vehicle</option>
                                        <option value="Airport Representative">Airport Representative</option>
                                        <option value="Group Handling Fee">Group Handling Fee</option>
                                        <option value="Service Fee">Service Fee</option>
                                        <option value="Miscellaneous">Miscellaneous</option>
                                    </Select>
                                    <Input label={t('quotation.costing.table.supplier')} value={fixedSupplierName} onChange={(e) => setFixedSupplierName(e.target.value)} placeholder="e.g. Local Guide Assoc" />
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                                    <Input label={t('quotation.costing.fixedCosts.form.rate') + ' *'} type="number" value={fixedAmount} onChange={(e) => setFixedAmount(e.target.value)} />
                                    <Select label={t('quotation.builder.currency')} value={fixedCurrency} onChange={(e) => setFixedCurrency(e.target.value)}>
                                        <option value="USD">USD ($)</option>
                                        <option value="EUR">EUR (€)</option>
                                        <option value="EGP">EGP (E£)</option>
                                        <option value="GBP">GBP (£)</option>
                                    </Select>
                                    <Select label={t('quotation.costing.fixedCosts.table.type')} value={fixedAllocationMethod} onChange={(e) => setFixedAllocationMethod(e.target.value as 'Split Equally' | 'Per Person' | 'Per Group' | 'Per Day')}>
                                        <option value="Split Equally">Split Equally</option>
                                        <option value="Per Person">Per Person</option>
                                        <option value="Per Group">Per Group</option>
                                        <option value="Per Day">Per Day</option>
                                    </Select>
                                    <Select label={t('quotation.costing.table.status')} value={fixedStatus} onChange={(e) => setFixedStatus(e.target.value as 'Active' | 'Inactive')}>
                                        <option value="Active">Active</option>
                                        <option value="Inactive">Inactive</option>
                                    </Select>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    <Input label={t('quotation.costing.fixedCosts.form.qty')} type="number" value={fixedQuantity} onChange={(e) => setFixedQuantity(e.target.value)} />
                                    <Input label={t('quotation.costing.fixedCosts.form.nights')} type="number" value={fixedDays} onChange={(e) => setFixedDays(e.target.value)} />
                                </div>
                                <Input label={t('quotation.costing.fixedCosts.form.notes')} value={fixedNotes} onChange={(e) => setFixedNotes(e.target.value)} placeholder="Any specific notes or details..." />
                                <div className="flex justify-end space-x-2 rtl:space-x-reverse pt-2">
                                    <Button size="sm" variant="outline" onClick={() => setIsFixedFormOpen(false)}>{t('quotation.builder.cancel')}</Button>
                                    <Button size="sm" onClick={handleSaveFixedCost} disabled={!fixedName.trim()}>
                                        <Save className={`${isRTL ? 'ml-1' : 'mr-1'} h-3.5 w-3.5`} /> {t('products.details.seasonalRates.save')}
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {fixedCostsList.length > 0 ? (
                        <div className="overflow-x-auto rounded border border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900">
                            <table style={{ direction }} className="w-full min-w-[760px] text-xs text-left rtl:text-right">
                                <thead className="bg-gray-50 dark:bg-gray-800 text-gray-500 dark:text-gray-400 uppercase font-bold tracking-wider border-b border-gray-100 dark:border-gray-800">
                                    <tr>
                                        <th className="px-3 py-2 logical-start">{t('quotation.costing.fixedCosts.table.name')}</th>
                                        <th className="px-3 py-2 logical-start">{t('quotation.costing.fixedCosts.table.category')}</th>
                                        <th className="px-3 py-2 logical-start">{t('quotation.costing.table.supplier')}</th>
                                        <th className="px-3 py-2 logical-start">{t('quotation.costing.fixedCosts.table.type')}</th>
                                        <th className="px-3 py-2 logical-end">{t('quotation.costing.fixedCosts.table.rate')}</th>
                                        <th className="px-3 py-2 text-center">{t('quotation.costing.fixedCosts.table.qty')} / {t('quotation.costing.fixedCosts.table.nights')}</th>
                                        <th className="px-3 py-2 logical-end">{t('quotation.costing.fixedCosts.table.total')}</th>
                                        <th className="px-3 py-2 logical-end">{t('quotation.preview.pricing.perPerson')}</th>
                                        <th className="px-3 py-2 logical-start">{t('quotation.costing.table.status')}</th>
                                        <th className="px-3 py-2 logical-end">{t('quotation.costing.table.actions')}</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                                    {fixedCostsList.map(fc => {
                                        const groupCost = calculateFixedCostItemTotal(fc, data.customerInfo.pax.total);
                                        const perPaxShare = groupCost / Math.max(1, data.customerInfo.pax.total);
                                        return (
                                            <tr key={fc.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                                                <td className="px-3 py-2 font-medium text-gray-900 dark:text-white logical-start">
                                                    <div>{fc.name}</div>
                                                    {fc.notes && <div className="text-[10px] text-gray-400 font-normal">{fc.notes}</div>}
                                                </td>
                                                <td className="px-3 py-2 text-gray-500 dark:text-gray-400 logical-start">{fc.category}</td>
                                                <td className="px-3 py-2 text-gray-500 dark:text-gray-400 logical-start">{fc.supplierName || '-'}</td>
                                                <td className="px-3 py-2 logical-start">
                                                    <span className="inline-flex px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-blue-50 text-blue-700 border border-blue-100 dark:bg-blue-950/20 dark:text-blue-400 dark:border-blue-900/30">
                                                        {fc.allocationMethod}
                                                    </span>
                                                </td>
                                                <td className="px-3 py-2 logical-end font-semibold text-gray-900 dark:text-white bidi-isolate">{formatCurrency(fc.amount, { currency: fc.currency })}</td>
                                                <td className="px-3 py-2 text-center text-gray-500 dark:text-gray-400 bidi-isolate">
                                                    {fc.quantity} / {fc.days || 1}
                                                </td>
                                                <td className="px-3 py-2 logical-end font-bold text-gray-950 dark:text-white bidi-isolate">{formatCurrency(groupCost, { currency: 'USD' })}</td>
                                                <td className="px-3 py-2 logical-end text-gray-500 dark:text-gray-400 bidi-isolate">{formatCurrency(perPaxShare, { currency: 'USD' })}</td>
                                                <td className="px-3 py-2 logical-start">
                                                    <span className={`inline-flex px-1.5 py-0.5 rounded-full text-[9px] font-bold ${
                                                        fc.status === 'Active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100 dark:bg-emerald-950/20 dark:text-emerald-400 dark:border-emerald-900/30' : 'bg-gray-50 text-gray-500 border border-gray-100 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700'
                                                    }`}>
                                                        {t(`products.status.${fc.status.toLowerCase()}` as TranslationKey) || fc.status}
                                                    </span>
                                                </td>
                                                <td className="px-3 py-2 logical-end">
                                                    <div className="flex justify-end space-x-1 rtl:space-x-reverse">
                                                        <button onClick={() => openEditFixedForm(fc)} className="p-1 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded" title="Edit">
                                                            <Edit className="h-3.5 w-3.5" />
                                                        </button>
                                                        <button onClick={() => handleDeleteFixedCost(fc.id)} className="p-1 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded" title="Delete">
                                                            <Trash2 className="h-3.5 w-3.5" />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    ) : (
                        <div className="text-center py-6 text-gray-400 text-xs bg-gray-50 dark:bg-gray-800/10 rounded border border-dashed border-gray-200 dark:border-gray-700">
                            {t('quotation.costing.fixedCosts.sharedFixedNotice')}
                        </div>
                    )}
                </CardContent>
            </Card>

            <div className="grid grid-cols-1 gap-4 lg:grid-cols-4">
                <SummaryCard label={t('quotation.pricing.profitAnalysis.cost')} value={formatCurrency(costSummary.totalDirectCost, { currency: 'USD' })} />
                <SummaryCard label={t('products.details.pricing.taxes' as TranslationKey) || 'Taxes / Fees'} value={formatCurrency(costSummary.taxesAndFees, { currency: 'USD' })} />
                <SummaryCard label={t('quotation.costing.fixedCosts.table.total')} value={formatCurrency(costSummary.groupTotalCost, { currency: 'USD' })} />
                <SummaryCard label={t('quotation.preview.pricing.perPerson')} value={formatCurrency(costSummary.perPersonCost, { currency: 'USD' })} />
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>{t('quotation.preview.pricing.title')}</CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-1 gap-4 lg:grid-cols-3">
                    <AllocationList title={t('quotation.costing.table.category')} values={costSummary.byCategory} />
                    <AllocationList title={t('quotation.costing.table.supplier')} values={costSummary.bySupplier} />
                    <AllocationList title={t('quotation.steps.itinerary')} values={costSummary.byDay} />
                </CardContent>
            </Card>
        </div>
    );
};

const NumberCell: React.FC<{ value: number; onChange: (value: number) => void }> = ({ value, onChange }) => (
    <td className="px-4 py-3">
        <Input type="number" min={0} value={value} onChange={(event) => onChange(Number(event.target.value) || 0)} className="w-20 bidi-isolate" />
    </td>
);

const MoneyCell: React.FC<{ value: number; onChange: (value: number) => void }> = ({ value, onChange }) => (
    <td className="px-4 py-3">
        <Input type="number" value={value} onChange={(event) => onChange(Number(event.target.value) || 0)} className="w-24 bidi-isolate" />
    </td>
);

const SummaryCard: React.FC<{ label: string; value: string }> = ({ label, value }) => (
    <Card>
        <CardContent className="p-4">
            <div className="text-xs font-bold uppercase tracking-wide text-gray-500">{label}</div>
            <div className="mt-1 text-xl font-bold bidi-isolate">{value}</div>
        </CardContent>
    </Card>
);

const AllocationList: React.FC<{ title: string; values: Record<string, number> }> = ({ title, values }) => {
    const { t } = useLocale();
    return (
        <div>
            <h4 className="mb-3 text-sm font-bold">{title}</h4>
            <div className="space-y-2">
                {Object.entries(values).map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between rounded-lg bg-gray-50 p-2 text-sm">
                        <span className="break-words">{key}</span>
                        <span className="font-bold bidi-isolate">{formatCurrency(value, { currency: 'USD' })}</span>
                    </div>
                ))}
                {Object.keys(values).length === 0 && <div className="text-sm text-gray-500">{t('quotation.builder.noActivity')}</div>}
            </div>
        </div>
    );
};
