import React from 'react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { QuotationVersion } from '../../types/quotation';

interface BasicInfoStepProps {
    data: QuotationVersion;
    updateData: (data: Partial<QuotationVersion>) => void;
}

export const QuotationBasicInfoStep: React.FC<BasicInfoStepProps> = ({ data, updateData }) => {
    const handleCustomerChange = (field: string, value: any) => {
        updateData({
            customerInfo: {
                ...data.customerInfo,
                [field]: value
            }
        });
    };

    const handlePaxChange = (field: string, value: string) => {
        const numValue = parseInt(value) || 0;
        const newPax = { ...data.customerInfo.pax, [field]: numValue };
        const total = newPax.adults + newPax.children + newPax.infants;
        
        updateData({
            customerInfo: {
                ...data.customerInfo,
                pax: { ...newPax, total }
            }
        });
    };

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-1">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white">Client Information</h3>
                    <p className="text-xs text-gray-500 mt-1">Basic details about the traveler or company.</p>
                </div>
                <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input 
                        label="Customer / Company Name" 
                        value={data.customerInfo.customerName} 
                        onChange={(e) => handleCustomerChange('customerName', e.target.value)}
                        placeholder="e.g. John Doe / Global Corp"
                    />
                    <Input 
                        label="Contact Person" 
                        value={data.customerInfo.contactPerson || ''} 
                        onChange={(e) => handleCustomerChange('contactPerson', e.target.value)}
                        placeholder="Name of primary contact"
                    />
                    <Input 
                        label="Email Address" 
                        type="email"
                        value={data.customerInfo.email} 
                        onChange={(e) => handleCustomerChange('email', e.target.value)}
                    />
                    <Input 
                        label="Phone / WhatsApp" 
                        value={data.customerInfo.phone} 
                        onChange={(e) => handleCustomerChange('phone', e.target.value)}
                    />
                    <Input 
                        label="Nationality / Market" 
                        value={data.customerInfo.nationality} 
                        onChange={(e) => handleCustomerChange('nationality', e.target.value)}
                    />
                    <Select 
                        label="Group Type" 
                        value={data.customerInfo.groupType} 
                        onChange={(e) => handleCustomerChange('groupType', e.target.value)}
                    >
                        <option value="FIT">FIT (Individual)</option>
                        <option value="Group">Group</option>
                        <option value="Corporate">Corporate</option>
                        <option value="Incentive">Incentive</option>
                    </Select>
                </div>
            </div>

            <hr className="border-gray-100 dark:border-gray-800" />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-1">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white">Travel Configuration</h3>
                    <p className="text-xs text-gray-500 mt-1">Pax count and date range.</p>
                </div>
                <div className="md:col-span-2">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                        <Input label="Adults" type="number" value={data.customerInfo.pax.adults.toString()} onChange={(e) => handlePaxChange('adults', e.target.value)} />
                        <Input label="Children" type="number" value={data.customerInfo.pax.children.toString()} onChange={(e) => handlePaxChange('children', e.target.value)} />
                        <Input label="Infants" type="number" value={data.customerInfo.pax.infants.toString()} onChange={(e) => handlePaxChange('infants', e.target.value)} />
                        <div className="flex flex-col">
                            <label className="text-xs font-bold text-gray-400 uppercase mb-1">Total Pax</label>
                            <div className="h-10 flex items-center px-3 bg-gray-50 dark:bg-gray-800 rounded-lg font-bold text-blue-600">
                                {data.customerInfo.pax.total}
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <Input label="Arrival Date" type="date" value={data.customerInfo.pax.arrival} onChange={(e) => updateData({ customerInfo: { ...data.customerInfo, pax: { ...data.customerInfo.pax, arrival: e.target.value } } })} />
                        <Input label="Departure Date" type="date" value={data.customerInfo.pax.departure} onChange={(e) => updateData({ customerInfo: { ...data.customerInfo, pax: { ...data.customerInfo.pax, departure: e.target.value } } })} />
                        <Input label="Nights" type="number" value={data.customerInfo.pax.nights.toString()} onChange={(e) => updateData({ customerInfo: { ...data.customerInfo, pax: { ...data.customerInfo.pax, nights: parseInt(e.target.value) || 0 } } })} />
                    </div>
                </div>
            </div>

            <hr className="border-gray-100 dark:border-gray-800" />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-1">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white">Admin Details</h3>
                    <p className="text-xs text-gray-500 mt-1">Internal notes and preparation info.</p>
                </div>
                <div className="md:col-span-2 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Input label="Prepared By" value={data.preparedBy} onChange={(e) => updateData({ preparedBy: e.target.value })} />
                        <Input label="Expiry Date" type="date" value={data.expiryDate} onChange={(e) => updateData({ expiryDate: e.target.value })} />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="text-xs font-bold text-gray-400 uppercase mb-1 block">Internal Notes</label>
                            <textarea 
                                className="w-full bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg p-2 text-sm min-h-[100px] focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                                value={data.internalNotes || ''}
                                onChange={(e) => updateData({ internalNotes: e.target.value })}
                                placeholder="Notes for the sales team..."
                            />
                        </div>
                        <div>
                            <label className="text-xs font-bold text-gray-400 uppercase mb-1 block">Client Notes</label>
                            <textarea 
                                className="w-full bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg p-2 text-sm min-h-[100px] focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                                value={data.clientFacingNotes || ''}
                                onChange={(e) => updateData({ clientFacingNotes: e.target.value })}
                                placeholder="Notes that will appear on the PDF..."
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
