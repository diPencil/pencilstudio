import React from 'react';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { QuotationVersion, QuotationItineraryDay } from '../../types/quotation';
import { Plus, Trash2, Copy, MapPin, Coffee, Plane, Hotel, Link2, Calendar } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';

interface ItineraryBuilderStepProps {
    data: QuotationVersion;
    updateData: (updates: Partial<QuotationVersion>) => void;
}

export const ItineraryBuilderStep: React.FC<ItineraryBuilderStepProps> = ({ data, updateData }) => {
    const { t } = useLocale();
    const mealOptions: Array<{ id: 'B' | 'L' | 'D' | 'MOB'; label: string }> = [
        { id: 'B', label: 'B' },
        { id: 'L', label: 'L' },
        { id: 'D', label: 'D' },
        { id: 'MOB', label: 'MOB' }
    ];

    const addDay = () => {
        const newDay: QuotationItineraryDay = {
            day: data.itinerary.length + 1,
            date: data.customerInfo.pax.arrival || '',
            title: '',
            route: '',
            city: '',
            description: '',
            meals: [],
            accommodation: '',
            transport: '',
            serviceLineIds: []
        };
        updateData({ itinerary: [...data.itinerary, newDay] });
    };

    const removeDay = (index: number) => {
        const newList = data.itinerary.filter((_, i) => i !== index).map((day, i) => ({
            ...day,
            day: i + 1
        }));
        updateData({ itinerary: newList });
    };

    const duplicateDay = (index: number) => {
        const dayToDup = data.itinerary[index];
        const newDay = { ...dayToDup, day: data.itinerary.length + 1 };
        updateData({ itinerary: [...data.itinerary, newDay] });
    };

    const updateDay = (index: number, updates: Partial<QuotationItineraryDay>) => {
        const newList = [...data.itinerary];
        newList[index] = { ...newList[index], ...updates };
        updateData({ itinerary: newList });
    };

    const handleMealToggle = (index: number, meal: 'B' | 'L' | 'D' | 'MOB') => {
        const day = data.itinerary[index];
        const meals = day.meals || [];
        const newMeals = meals.includes(meal)
            ? meals.filter(m => m !== meal)
            : [...meals, meal];
        updateDay(index, { meals: newMeals });
    };

    const toggleServiceForDay = (index: number, serviceLineId: string) => {
        const day = data.itinerary[index];
        const existing = day.serviceLineIds || [];
        const next = existing.includes(serviceLineId)
            ? existing.filter(id => id !== serviceLineId)
            : [...existing, serviceLineId];
        updateDay(index, { serviceLineIds: next });
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{t('quotation.itinerary.title')}</h3>
                <Button onClick={addDay} variant="outline" size="sm" className="flex items-center gap-2">
                    <Plus className="w-4 h-4" /> {t('quotation.itinerary.addDay')}
                </Button>
            </div>

            <div className="space-y-4">
                {data.itinerary.map((day, index) => (
                    <Card key={index} className="overflow-hidden border-l-4 border-l-blue-500 rtl:border-l-0 rtl:border-r-4 rtl:border-r-blue-500">
                        <CardContent className="p-5">
                            <div className="flex justify-between items-start mb-4">
                                <div className="flex items-center gap-3 flex-1">
                                    <div className="bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 w-8 h-8 rounded-full flex items-center justify-center font-bold bidi-isolate">
                                        {day.day}
                                    </div>
                                    <Input 
                                        placeholder={t('quotation.itinerary.titlePlaceholder')}
                                        value={day.title}
                                        onChange={(e) => updateDay(index, { title: e.target.value })}
                                        className="font-semibold text-lg border-none focus:ring-0 p-0 h-auto bg-transparent flex-1"
                                    />
                                </div>
                                <div className="flex gap-2">
                                    <Button variant="ghost" size="sm" onClick={() => duplicateDay(index)} title={t('quotation.itinerary.duplicate')}>
                                        <Copy className="w-4 h-4 text-gray-500" />
                                    </Button>
                                    <Button variant="ghost" size="sm" onClick={() => removeDay(index)} title={t('quotation.itinerary.delete')}>
                                        <Trash2 className="w-4 h-4 text-red-500" />
                                    </Button>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                                <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                                    <Calendar className="w-4 h-4 text-gray-400" />
                                    <Input
                                        type="date"
                                        value={day.date || ''}
                                        onChange={(e) => updateDay(index, { date: e.target.value })}
                                        className="border-none focus:ring-0 p-0 h-auto bg-transparent text-sm bidi-isolate"
                                    />
                                </div>
                                <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                                    <MapPin className="w-4 h-4 text-gray-400" />
                                    <Input 
                                        placeholder={t('quotation.itinerary.routePlaceholder')}
                                        value={day.route}
                                        onChange={(e) => updateDay(index, { route: e.target.value })}
                                        className="border-none focus:ring-0 p-0 h-auto bg-transparent text-sm"
                                    />
                                </div>
                                <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                                    <Hotel className="w-4 h-4 text-gray-400" />
                                    <Input 
                                        placeholder={t('quotation.itinerary.cityPlaceholder')}
                                        value={day.city}
                                        onChange={(e) => updateDay(index, { city: e.target.value })}
                                        className="border-none focus:ring-0 p-0 h-auto bg-transparent text-sm"
                                    />
                                </div>
                            </div>

                            <textarea 
                                placeholder={t('quotation.itinerary.descriptionPlaceholder')}
                                value={day.description}
                                onChange={(e) => updateDay(index, { description: e.target.value })}
                                className="w-full min-h-[100px] p-3 text-sm bg-gray-50 dark:bg-gray-800/50 border-none rounded-lg focus:ring-1 focus:ring-blue-500 mb-4 resize-none"
                            />

                            <div className="mb-4 rounded-lg border border-gray-100 bg-gray-50 p-3">
                                <div className="mb-2 flex items-center gap-2 text-sm font-bold">
                                    <Link2 className="h-4 w-4 text-blue-500" />
                                    {t('quotation.itinerary.includedServices')}
                                </div>
                                <div className="flex flex-wrap gap-2">
                                    {(data.serviceLines || []).map(service => {
                                        const checked = (day.serviceLineIds || []).includes(service.id);
                                        return (
                                            <button
                                                key={service.id}
                                                type="button"
                                                onClick={() => toggleServiceForDay(index, service.id)}
                                                className={`rounded-full border px-3 py-1 text-xs font-semibold ${checked ? 'border-blue-200 bg-blue-50 text-blue-700' : 'border-gray-200 bg-white text-gray-600'}`}
                                            >
                                                {service.serviceName}
                                            </button>
                                        );
                                    })}
                                    {(data.serviceLines || []).length === 0 && <span className="text-xs text-gray-500">{t('quotation.itinerary.noServicesNotice')}</span>}
                                </div>
                            </div>

                            <div className="flex flex-wrap items-center gap-6 pt-2 border-t border-gray-100 dark:border-gray-800">
                                <div className="flex items-center gap-2">
                                    <Coffee className="w-4 h-4 text-orange-500" />
                                    <span className="text-sm font-medium">{t('quotation.itinerary.meals')}</span>
                                    <div className="flex gap-3">
                                        {mealOptions.map(meal => (
                                            <label key={meal.id} className="flex items-center space-x-1 rtl:space-x-reverse cursor-pointer">
                                                <input 
                                                    type="checkbox" 
                                                    checked={day.meals?.includes(meal.id)}
                                                    onChange={() => handleMealToggle(index, meal.id)}
                                                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 w-3 h-3"
                                                />
                                                <span className="text-xs text-gray-600 dark:text-gray-400">{meal.label}</span>
                                            </label>
                                        ))}
                                    </div>
                                </div>

                                <div className="flex items-center gap-2">
                                    <Plane className="w-4 h-4 text-blue-500" />
                                    <Input 
                                        placeholder={t('quotation.itinerary.transportPlaceholder')}
                                        value={day.transport}
                                        onChange={(e) => updateDay(index, { transport: e.target.value })}
                                        className="border-none focus:ring-0 p-0 h-auto bg-transparent text-sm w-32"
                                    />
                                </div>

                                <div className="flex items-center gap-2">
                                    <Hotel className="w-4 h-4 text-purple-500" />
                                    <Input 
                                        placeholder={t('quotation.itinerary.accommodationPlaceholder')}
                                        value={day.accommodation}
                                        onChange={(e) => updateDay(index, { accommodation: e.target.value })}
                                        className="border-none focus:ring-0 p-0 h-auto bg-transparent text-sm w-40"
                                    />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {data.itinerary.length === 0 && (
                <div className="text-center py-12 border-2 border-dashed border-gray-200 dark:border-gray-800 rounded-xl">
                    <p className="text-gray-500">{t('quotation.itinerary.noDays')}</p>
                </div>
            )}
        </div>
    );
};
