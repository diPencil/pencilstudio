import React, { useEffect, useMemo } from 'react';
import { AlertTriangle, Calculator, CheckCircle, Users, Tag } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import type { MarkupType, QuotationVersion } from '../../types/quotation';
import {
    buildProfitAnalysis,
    calculatePricingFromServiceLines
} from '../../utils/quotationCalculations';
import { useLocale } from '../../localization/useLocale';
import { formatCurrency } from '../../utils/format';
import type { TranslationKey } from '../../localization/messages';

interface PricingStepProps {
    data: QuotationVersion;
    updateData: (updates: Partial<QuotationVersion>) => void;
}

const PAX_TEMPLATES = [10, 15, 20, 25, 30];

export const PricingStep: React.FC<PricingStepProps> = ({ data, updateData }) => {
    const { t, isRTL, direction } = useLocale();
    const serviceLines = useMemo(() => data.serviceLines || [], [data.serviceLines]);

    useEffect(() => {
        const pricing = (serviceLines.length > 0 || (data.fixedCosts && data.fixedCosts.length > 0))
            ? calculatePricingFromServiceLines(
                serviceLines,
                data.pricing.markupType,
                data.pricing.markupValue,
                data.customerInfo.pax.total,
                data.pricing.currency,
                data.pricing.exchangeRate,
                data.pricing.discountAmount || 0,
                data.pricing.commissionAmount || 0,
                data.pricing.manualOverride || false,
                data.pricing.manualSellingPrice || 0,
                data.fixedCosts,
                data.pricing.appliedScenario
            )
            : data.pricing;
        const profitAnalysis = buildProfitAnalysis(serviceLines, pricing);

        if (JSON.stringify(pricing) !== JSON.stringify(data.pricing) || JSON.stringify(profitAnalysis) !== JSON.stringify(data.profitAnalysis)) {
            updateData({ pricing, profitAnalysis });
        }
    }, [serviceLines, data.pricing, data.profitAnalysis, data.customerInfo.pax.total, data.fixedCosts, updateData]);

    const updatePricing = (updates: Partial<QuotationVersion['pricing']>) => {
        updateData({ pricing: { ...data.pricing, ...updates } });
    };

    const updatePax = (adults: number) => {
        updateData({
            customerInfo: {
                ...data.customerInfo,
                pax: {
                    ...data.customerInfo.pax,
                    adults,
                    total: adults + data.customerInfo.pax.children + data.customerInfo.pax.infants
                }
            }
        });
    };

    const profit = data.profitAnalysis || buildProfitAnalysis(serviceLines, data.pricing);
    const lowMargin = Boolean(profit.lowMarginWarning);
    const hasRisk = profit.highRiskSupplierWarnings.length > 0;

    const complimentaryCount = serviceLines.filter(line => line.isComplimentary).length;
    const complimentaryCost = serviceLines.filter(line => line.isComplimentary).reduce((sum, line) => sum + line.totalCost, 0);
    const complimentaryMarginImpact = data.pricing.totalSellingPrice > 0 ? (complimentaryCost / data.pricing.totalSellingPrice) * 100 : 0;

    const scenarios = useMemo(() => {
        const paxCount = data.customerInfo.pax.total;
        const currency = data.pricing.currency;
        const exchangeRate = data.pricing.exchangeRate;
        const fixedCosts = data.fixedCosts;

        const budgetPricing = calculatePricingFromServiceLines(
            serviceLines,
            'Percentage',
            5,
            paxCount,
            currency,
            exchangeRate,
            0,
            0,
            false,
            0,
            fixedCosts,
            'Budget'
        );
        const budgetProfit = buildProfitAnalysis(serviceLines, budgetPricing);

        const standardPricing = calculatePricingFromServiceLines(
            serviceLines,
            'Percentage',
            15,
            paxCount,
            currency,
            exchangeRate,
            0,
            0,
            false,
            0,
            fixedCosts,
            'Standard'
        );
        const standardProfit = buildProfitAnalysis(serviceLines, standardPricing);

        const premiumPricing = calculatePricingFromServiceLines(
            serviceLines,
            'Percentage',
            25,
            paxCount,
            currency,
            exchangeRate,
            0,
            0,
            false,
            0,
            fixedCosts,
            'Premium'
        );
        const premiumProfit = buildProfitAnalysis(serviceLines, premiumPricing);

        return [
            {
                id: 'Budget' as const,
                name: 'Budget Option',
                markupType: 'Percentage' as const,
                markupValue: 5,
                discount: 0,
                commission: 0,
                pricing: budgetPricing,
                profit: budgetProfit,
                badge: budgetProfit.marginPercent < 15 ? 'Low Margin' : 'Budget',
                badgeStyle: budgetProfit.marginPercent < 15 
                    ? 'bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/20 dark:text-amber-400 dark:border-amber-900/30'
                    : 'bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-900/30',
            },
            {
                id: 'Standard' as const,
                name: 'Standard Option',
                markupType: 'Percentage' as const,
                markupValue: 15,
                discount: 0,
                commission: 0,
                pricing: standardPricing,
                profit: standardProfit,
                badge: 'Recommended',
                badgeStyle: 'bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/20 dark:text-emerald-400 dark:border-emerald-900/30',
            },
            {
                id: 'Premium' as const,
                name: 'Premium Option',
                markupType: 'Percentage' as const,
                markupValue: 25,
                discount: 0,
                commission: 0,
                pricing: premiumPricing,
                profit: premiumProfit,
                badge: 'Premium Option',
                badgeStyle: 'bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-950/20 dark:text-purple-400 dark:border-purple-900/30',
            }
        ];
    }, [serviceLines, data.customerInfo.pax.total, data.pricing.currency, data.pricing.exchangeRate, data.fixedCosts]);

    return (
        <div className="space-y-6">
            <div>
                <h3 className="flex items-center gap-2 text-lg font-semibold text-gray-900 dark:text-white">
                    <Calculator className="h-5 w-5 text-blue-500" />
                    {t('quotation.pricing.controls.title')}
                </h3>
                <p className="text-sm text-gray-500">{t('quotation.pricing.profitAnalysis.title')}</p>
            </div>

            <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
                <div className="space-y-6 xl:col-span-2">
                    <Card>
                        <CardHeader>
                            <CardTitle>{t('quotation.pricing.profitAnalysis.title')}</CardTitle>
                        </CardHeader>
                        <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
                            <Metric label={t('quotation.pricing.profitAnalysis.cost')} value={formatCurrency(data.pricing.grandTotalCost, { currency: 'USD' })} />
                            <Metric label={t('quotation.pricing.profitAnalysis.selling')} value={formatCurrency(data.pricing.totalSellingPrice, { currency: 'USD' })} tone="green" />
                            <Metric label={t('quotation.pricing.profitAnalysis.profit')} value={formatCurrency(data.pricing.profitAmount, { currency: 'USD' })} tone="green" />
                            <Metric label={t('quotation.pricing.profitAnalysis.margin')} value={`${profit.marginPercent}%`} tone={profit.marginPercent < 15 ? 'red' : 'green'} />
                            <Metric label={t('quotation.preview.pricing.perPerson') + ' (' + t('quotation.pricing.profitAnalysis.cost') + ')'} value={formatCurrency(data.pricing.costPerPerson, { currency: 'USD' })} />
                            <Metric label={t('quotation.preview.pricing.perPerson') + ' (' + t('quotation.pricing.profitAnalysis.selling') + ')'} value={formatCurrency(data.pricing.sellingPricePerPerson, { currency: 'USD' })} tone="green" />
                            <Metric label={t('quotation.pricing.profitAnalysis.breakEven')} value={formatCurrency(profit.breakEvenPrice, { currency: 'USD' })} />
                            <Metric label={t('quotation.pricing.profitAnalysis.markup')} value={`${profit.markupPercent}%`} />
                        </CardContent>
                    </Card>

                    {complimentaryCount > 0 && (
                        <Card className="bg-blue-50/30 border border-blue-100 dark:bg-blue-950/10 dark:border-blue-900/30">
                            <CardContent className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                                <div className="flex items-center gap-2">
                                    <div className="p-1.5 bg-blue-100 dark:bg-blue-900/45 rounded text-blue-600 dark:text-blue-400">
                                        <Tag className="h-4 w-4" />
                                    </div>
                                    <div>
                                        <div className="font-bold text-sm text-blue-900 dark:text-blue-300">{t('quotation.costing.focSummary')}</div>
                                        <div className="text-xs text-blue-700 dark:text-blue-450">{t('quotation.pricing.profitAnalysis.compNotice').replace('{count}', complimentaryCount.toString()).replace('{cost}', formatCurrency(complimentaryCost, { currency: 'USD' }))}</div>
                                    </div>
                                </div>
                                <div className="flex flex-wrap gap-4 text-xs">
                                    <div className="rounded bg-white dark:bg-gray-800 px-3 py-1.5 border">
                                        <span className="text-gray-500 uppercase tracking-wider block text-[9px] font-bold">{t('quotation.costing.focItems')}</span>
                                        <span className="font-bold text-sm text-gray-900 dark:text-white bidi-isolate">{complimentaryCount}</span>
                                    </div>
                                    <div className="rounded bg-white dark:bg-gray-800 px-3 py-1.5 border">
                                        <span className="text-gray-500 uppercase tracking-wider block text-[9px] font-bold">{t('quotation.costing.focAbsorbed')}</span>
                                        <span className="font-bold text-sm text-blue-700 dark:text-blue-400 bidi-isolate">{formatCurrency(complimentaryCost, { currency: 'USD' })}</span>
                                    </div>
                                    <div className="rounded bg-white dark:bg-gray-800 px-3 py-1.5 border">
                                        <span className="text-gray-500 uppercase tracking-wider block text-[9px] font-bold">{t('quotation.costing.focMarginImpact')}</span>
                                        <span className="font-bold text-sm text-rose-600 bidi-isolate">-{complimentaryMarginImpact.toFixed(1)}%</span>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {data.fixedCosts && data.fixedCosts.filter(fc => fc.status === 'Active').length > 0 && (
                        <Card>
                            <CardHeader>
                                <CardTitle>{t('quotation.costing.fixedCosts.title')}</CardTitle>
                            </CardHeader>
                            <CardContent className="p-0">
                                <div className="overflow-x-auto">
                                    <table style={{ direction }} className="w-full text-sm text-left rtl:text-right">
                                        <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-500">
                                            <tr>
                                                <th className="px-4 py-3 logical-start">{t('quotation.costing.fixedCosts.table.name')}</th>
                                                <th className="px-4 py-3 logical-start">{t('quotation.costing.fixedCosts.table.category')}</th>
                                                <th className="px-4 py-3 logical-start">{t('quotation.costing.fixedCosts.table.type')}</th>
                                                <th className="px-4 py-3 logical-end">{t('quotation.costing.fixedCosts.table.total')}</th>
                                                <th className="px-4 py-3 logical-end">{t('quotation.preview.pricing.perPerson')}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {data.fixedCosts.filter(fc => fc.status === 'Active').map(fc => {
                                                const totalCost = fc.allocationMethod === 'Per Person' 
                                                    ? fc.amount * (fc.quantity || 1) * (fc.days || 1) * data.customerInfo.pax.total 
                                                    : fc.amount * (fc.quantity || 1) * (fc.days || 1);
                                                const perPerson = totalCost / Math.max(1, data.customerInfo.pax.total);
                                                return (
                                                    <tr key={fc.id} className="border-t">
                                                        <td className="px-4 py-2.5 font-semibold text-gray-900 dark:text-white logical-start">{fc.name}</td>
                                                        <td className="px-4 py-2.5 text-gray-600 dark:text-gray-400 logical-start">{fc.category}</td>
                                                        <td className="px-4 py-2.5 text-gray-600 dark:text-gray-400 logical-start">{fc.allocationMethod}</td>
                                                        <td className="px-4 py-2.5 logical-end font-bold text-gray-950 dark:text-white bidi-isolate">{formatCurrency(totalCost, { currency: 'USD' })}</td>
                                                        <td className="px-4 py-2.5 logical-end text-gray-500 bidi-isolate">{formatCurrency(perPerson, { currency: 'USD' })}</td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    <Card>
                        <CardHeader>
                            <CardTitle>{t('quotation.pricing.profitAnalysis.title')}</CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                            <div className="overflow-x-auto">
                                <table style={{ direction }} className="w-full min-w-[720px] text-sm text-left rtl:text-right">
                                    <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-500">
                                        <tr>
                                            <th className="px-4 py-3 logical-start">{t('quotation.costing.table.service')}</th>
                                            <th className="px-4 py-3 logical-start">{t('quotation.costing.table.cost')}</th>
                                            <th className="px-4 py-3 logical-start">{t('products.catalog.table.selling')}</th>
                                            <th className="px-4 py-3 logical-start">{t('products.details.pricing.profit')}</th>
                                            <th className="px-4 py-3 logical-start">{t('products.catalog.table.margin')}</th>
                                            <th className="px-4 py-3 logical-start">{t('quotation.costing.table.status')}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {serviceLines.map(line => (
                                            <tr key={line.id} className="border-t">
                                                <td className="px-4 py-3 font-semibold logical-start">{line.serviceName}</td>
                                                <td className="px-4 py-3 logical-start bidi-isolate">{formatCurrency(line.totalCost, { currency: 'USD' })}</td>
                                                <td className="px-4 py-3 logical-start bidi-isolate">{formatCurrency(line.totalSelling, { currency: 'USD' })}</td>
                                                <td className="px-4 py-3 logical-start text-emerald-600 bidi-isolate">{formatCurrency(line.profit, { currency: 'USD' })}</td>
                                                <td className="px-4 py-3 logical-start bidi-isolate">{line.marginPercent}%</td>
                                                <td className="px-4 py-3 logical-start text-xs text-amber-600">{line.warning || '-'}</td>
                                            </tr>
                                        ))}
                                        {serviceLines.length === 0 && (
                                            <tr><td className="px-4 py-8 text-center text-gray-500" colSpan={6}>{t('quotation.costing.noServicesFound')}</td></tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="border-t-4 border-t-blue-500">
                        <CardHeader>
                            <CardTitle className="text-base font-bold text-gray-900 dark:text-white">{t('quotation.pricing.scenarios.title')}</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                {scenarios.map(sc => {
                                    const isActive = data.pricing.appliedScenario === sc.id || 
                                        (!data.pricing.manualOverride && 
                                         data.pricing.markupType === sc.markupType && 
                                         data.pricing.markupValue === sc.markupValue && 
                                         (data.pricing.discountAmount || 0) === sc.discount && 
                                         (data.pricing.commissionAmount || 0) === sc.commission);
                                    
                                    const translatedOptionName = sc.id === 'Budget' ? t('quotation.pricing.scenarios.budget') : sc.id === 'Standard' ? t('quotation.pricing.scenarios.standard') : t('quotation.pricing.scenarios.premium');
                                    const translatedBadge = sc.badge === 'Recommended' ? t('quotation.pricing.scenarios.recommended') : sc.badge === 'Low Margin' ? t('quotation.pricing.scenarios.lowMargin') : sc.badge === 'Premium Option' ? t('quotation.pricing.scenarios.premium') : sc.badge;

                                    return (
                                        <div 
                                            key={sc.id} 
                                            className={`rounded-xl border p-4 flex flex-col justify-between transition-all duration-200 ${
                                                isActive 
                                                    ? 'border-blue-500 bg-blue-50/20 shadow-md ring-2 ring-blue-500/10 dark:bg-blue-950/10' 
                                                    : 'border-gray-100 hover:border-gray-200 dark:border-gray-800'
                                            }`}
                                        >
                                            <div className="space-y-3">
                                                <div className="flex items-center justify-between gap-2">
                                                    <h4 className="font-bold text-sm text-gray-900 dark:text-white">{translatedOptionName}</h4>
                                                    <span className={`px-1.5 py-0.5 rounded-full text-[9px] font-bold uppercase border ${sc.badgeStyle}`}>
                                                        {translatedBadge}
                                                    </span>
                                                </div>
                                                
                                                <div className="divide-y divide-gray-100 dark:divide-gray-800 text-xs">
                                                    <div className="py-1.5 flex justify-between">
                                                        <span className="text-gray-500">{t('quotation.pricing.scenarios.markup')}</span>
                                                        <span className="font-semibold text-gray-900 dark:text-white bidi-isolate">{sc.markupValue}%</span>
                                                    </div>
                                                    <div className="py-1.5 flex justify-between">
                                                        <span className="text-gray-500">{t('quotation.pricing.profitAnalysis.cost')}</span>
                                                        <span className="font-semibold text-gray-900 dark:text-white bidi-isolate">{formatCurrency(sc.pricing.grandTotalCost, { currency: 'USD' })}</span>
                                                    </div>
                                                    <div className="py-1.5 flex justify-between">
                                                        <span className="text-gray-500 font-medium">{t('quotation.pricing.scenarios.totalSelling')}</span>
                                                        <span className="font-bold text-gray-950 dark:text-white bidi-isolate">{formatCurrency(sc.pricing.totalSellingPrice, { currency: 'USD' })}</span>
                                                    </div>
                                                    <div className="py-1.5 flex justify-between">
                                                        <span className="text-gray-500">{t('quotation.pricing.scenarios.perPerson')}</span>
                                                        <span className="font-semibold text-blue-600 bidi-isolate">{formatCurrency(sc.pricing.sellingPricePerPerson, { currency: 'USD' })}</span>
                                                    </div>
                                                    <div className="py-1.5 flex justify-between">
                                                        <span className="text-gray-500">{t('quotation.pricing.scenarios.profit')}</span>
                                                        <span className="font-semibold text-emerald-600 bidi-isolate">{formatCurrency(sc.pricing.profitAmount, { currency: 'USD' })}</span>
                                                    </div>
                                                    <div className="py-1.5 flex justify-between">
                                                        <span className="text-gray-500">{t('quotation.pricing.scenarios.margin')}</span>
                                                        <span className={`font-bold bidi-isolate ${sc.profit.marginPercent < 15 ? 'text-rose-600' : 'text-emerald-600'}`}>
                                                            {sc.profit.marginPercent}%
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div className="mt-4 pt-3 border-t border-gray-100 dark:border-gray-800">
                                                {isActive ? (
                                                    <Button variant="outline" size="sm" className="w-full border-blue-500 text-blue-650 cursor-default bg-blue-50/10" disabled>
                                                        {t('quotation.pricing.scenarios.active')}
                                                    </Button>
                                                ) : (
                                                    <Button 
                                                        variant="outline" 
                                                        size="sm" 
                                                        className="w-full hover:bg-blue-50 dark:hover:bg-blue-950/20"
                                                        onClick={() => updatePricing({
                                                            markupType: sc.markupType,
                                                            markupValue: sc.markupValue,
                                                            discountAmount: sc.discount,
                                                            commissionAmount: sc.commission,
                                                            manualOverride: false,
                                                            appliedScenario: sc.id
                                                        })}
                                                    >
                                                        {t('quotation.pricing.scenarios.apply')}
                                                    </Button>
                                                )}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </CardContent>
                    </Card>

                    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                        <Breakdown title={t('quotation.costing.table.category')} values={profit.profitByCategory} />
                        <Breakdown title={t('quotation.costing.table.supplier')} values={profit.profitBySupplier} />
                    </div>
                </div>

                <div className="space-y-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>{t('quotation.pricing.controls.title')}</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <label className="mb-1 block text-xs font-bold uppercase tracking-wide text-gray-500">{t('quotation.pricing.controls.markupType')}</label>
                                <div className="grid grid-cols-2 gap-2">
                                    {(['Percentage', 'Fixed'] as MarkupType[]).map(type => (
                                        <Button key={type} variant={data.pricing.markupType === type ? 'primary' : 'outline'} size="sm" onClick={() => updatePricing({ markupType: type })}>
                                            {t(`products.form.priceUnit` as TranslationKey) || type}
                                        </Button>
                                    ))}
                                </div>
                            </div>
                            <Input label={`${t('quotation.pricing.controls.markupValue')} ${data.pricing.markupType === 'Percentage' ? '(%)' : '($)'}`} type="number" value={data.pricing.markupValue} onChange={(event) => updatePricing({ markupValue: Number(event.target.value) || 0 })} />
                            <Input label={t('quotation.pricing.controls.discount')} type="number" value={data.pricing.discountAmount || 0} onChange={(event) => updatePricing({ discountAmount: Number(event.target.value) || 0 })} />
                            <Input label={t('quotation.pricing.controls.commission')} type="number" value={data.pricing.commissionAmount || 0} onChange={(event) => updatePricing({ commissionAmount: Number(event.target.value) || 0 })} />
                            <Select label={t('quotation.builder.currency')} value={data.pricing.currency} onChange={(event) => updatePricing({ currency: event.target.value })}>
                                <option value="USD">USD ($)</option>
                                <option value="EUR">EUR</option>
                                <option value="EGP">EGP</option>
                                <option value="GBP">GBP</option>
                            </Select>
                            <Input label="Exchange Rate" type="number" value={data.pricing.exchangeRate} onChange={(event) => updatePricing({ exchangeRate: Number(event.target.value) || 1 })} />
                            <label className="flex items-center gap-2 rounded-lg border border-gray-100 p-3 text-sm">
                                <input type="checkbox" checked={Boolean(data.pricing.manualOverride)} onChange={(event) => updatePricing({ manualOverride: event.target.checked })} />
                                {t('quotation.pricing.controls.manualOverride')}
                            </label>
                            {data.pricing.manualOverride && (
                                <Input label={t('quotation.pricing.controls.manualPrice')} type="number" value={data.pricing.manualSellingPrice || 0} onChange={(event) => updatePricing({ manualSellingPrice: Number(event.target.value) || 0 })} />
                            )}
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>{t('quotation.builder.travelers')}</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex flex-wrap gap-2">
                                {PAX_TEMPLATES.map(value => (
                                    <Button key={value} variant={data.customerInfo.pax.adults === value ? 'primary' : 'outline'} size="sm" onClick={() => updatePax(value)}>
                                        {value}+{value >= 30 ? 2 : 1}
                                    </Button>
                                ))}
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                                <Input label={t('products.details.pricing.adults' as TranslationKey) || 'Adults'} type="number" value={data.customerInfo.pax.adults} onChange={(event) => updatePax(Number(event.target.value) || 0)} />
                                <div>
                                    <div className="text-xs font-bold uppercase tracking-wide text-gray-500">{t('quotation.builder.travelers')}</div>
                                    <div className="mt-2 flex h-10 items-center rounded-md bg-blue-50 px-3 text-lg font-bold text-blue-700">
                                        <Users className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4`} />
                                        <span className="bidi-isolate">{data.customerInfo.pax.total}</span>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className={lowMargin || hasRisk ? 'border-amber-200 bg-amber-50' : 'border-emerald-200 bg-emerald-50'}>
                        <CardContent className="p-4">
                            <div className="mb-2 flex items-center gap-2 font-bold">
                                {lowMargin || hasRisk ? <AlertTriangle className="h-5 w-5 text-amber-600" /> : <CheckCircle className="h-5 w-5 text-emerald-600" />}
                                {t('products.status.needsReview' as TranslationKey) || 'Readiness'}
                            </div>
                            <div className="space-y-2 text-sm">
                                {lowMargin && <div>{t('quotation.pricing.profitAnalysis.lowMarginWarn')}</div>}
                                {hasRisk && profit.highRiskSupplierWarnings.map(warning => <div key={warning}>{warning}</div>)}
                                {!lowMargin && !hasRisk && <div>{t('quotation.pricing.profitAnalysis.ready' as TranslationKey) || 'Pricing clears margin and supplier-risk checks.'}</div>}
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
};

const Metric: React.FC<{ label: string; value: string; tone?: 'green' | 'red' | 'default' }> = ({ label, value, tone = 'default' }) => (
    <div className="rounded-lg border border-gray-100 p-3">
        <div className="text-xs font-bold uppercase tracking-wide text-gray-500">{label}</div>
        <div className={`mt-1 text-xl font-bold bidi-isolate ${tone === 'green' ? 'text-emerald-600' : tone === 'red' ? 'text-rose-600' : 'text-gray-900 dark:text-white'}`}>{value}</div>
    </div>
);

const Breakdown: React.FC<{ title: string; values: Record<string, number> }> = ({ title, values }) => {
    const { t } = useLocale();
    return (
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
                {Object.entries(values).map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between rounded-lg bg-gray-50 p-2 text-sm">
                        <span className="break-words">{key}</span>
                        <span className="font-bold text-emerald-600 bidi-isolate">{formatCurrency(value, { currency: 'USD' })}</span>
                    </div>
                ))}
                {Object.keys(values).length === 0 && <div className="text-sm text-gray-500">{t('quotation.builder.noActivity')}</div>}
            </CardContent>
        </Card>
    );
};
