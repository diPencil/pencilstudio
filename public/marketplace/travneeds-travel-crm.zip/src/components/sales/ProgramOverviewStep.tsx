import React from 'react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { QuotationVersion } from '../../types/quotation';
import { X } from 'lucide-react';

import { useLocale } from '../../localization/useLocale';

interface ProgramOverviewStepProps {
    data: QuotationVersion;
    updateData: (data: Partial<QuotationVersion>) => void;
}

export const ProgramOverviewStep: React.FC<ProgramOverviewStepProps> = ({ data, updateData }) => {
    const { isRTL } = useLocale();
    const handleProgramChange = (field: string, value: string) => {
        updateData({
            programOverview: {
                ...data.programOverview,
                [field]: value
            }
        });
    };

    const addListValue = (field: 'citiesCovered' | 'highlights', value: string) => {
        if (!value.trim()) return;
        const currentList = data.programOverview[field] || [];
        if (!currentList.includes(value)) {
            handleProgramChange(field, [...currentList, value]);
        }
    };

    const removeListValue = (field: 'citiesCovered' | 'highlights', index: number) => {
        const currentList = [...(data.programOverview[field] || [])];
        currentList.splice(index, 1);
        handleProgramChange(field, currentList);
    };

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-1">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white">Program Identity</h3>
                    <p className="text-xs text-gray-500 mt-1">Naming and categorizing your travel package.</p>
                </div>
                <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2">
                        <Input 
                            label="Package Title (Main Title)" 
                            value={data.programOverview.title} 
                            onChange={(e) => handleProgramChange('title', e.target.value)}
                            placeholder="e.g. Wonders of Ancient Egypt"
                        />
                    </div>
                    <Input 
                        label="Package Code" 
                        value={data.programOverview.packageCode} 
                        onChange={(e) => handleProgramChange('packageCode', e.target.value)}
                    />
                    <Select 
                        label="Package Type" 
                        value={data.programOverview.packageType} 
                        onChange={(e) => handleProgramChange('packageType', e.target.value)}
                    >
                        <option value="Classic">Classic</option>
                        <option value="Luxury">Luxury</option>
                        <option value="Nile Cruise">Nile Cruise</option>
                        <option value="Adventure">Adventure</option>
                        <option value="Honeymoon">Honeymoon</option>
                    </Select>
                </div>
            </div>

            <hr className="border-gray-100 dark:border-gray-800" />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-1">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white">Route & Destinations</h3>
                    <p className="text-xs text-gray-500 mt-1">Where will they go?</p>
                </div>
                <div className="md:col-span-2 space-y-4">
                    <div>
                        <label className="text-xs font-bold text-gray-400 uppercase mb-1 block">Cities Covered</label>
                        <div className="flex flex-wrap gap-2 mb-2">
                            {data.programOverview.citiesCovered.map((city, i) => (
                                <span key={i} className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                    {city}
                                    <button onClick={() => removeListValue('citiesCovered', i)} className={`${isRTL ? 'mr-1.5' : 'ml-1.5'} inline-flex items-center justify-center text-blue-400 hover:text-blue-600`}>
                                        <X className="h-3 w-3" />
                                    </button>
                                </span>
                            ))}
                        </div>
                        <div className="flex gap-2">
                            <input 
                                className="flex-1 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                placeholder="Add city (e.g. Luxor)"
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                        e.preventDefault();
                                        addListValue('citiesCovered', (e.target as HTMLInputElement).value);
                                        (e.target as HTMLInputElement).value = '';
                                    }
                                }}
                            />
                        </div>
                    </div>
                </div>
            </div>

            <hr className="border-gray-100 dark:border-gray-800" />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-1">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white">Content & Highlights</h3>
                    <p className="text-xs text-gray-500 mt-1">Selling points and description.</p>
                </div>
                <div className="md:col-span-2 space-y-4">
                    <div>
                        <label className="text-xs font-bold text-gray-400 uppercase mb-1 block">Short Description</label>
                        <textarea 
                            className="w-full bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg p-2 text-sm min-h-[100px] focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                            value={data.programOverview.description || ''}
                            onChange={(e) => handleProgramChange('description', e.target.value)}
                        />
                    </div>
                    <div>
                        <label className="text-xs font-bold text-gray-400 uppercase mb-1 block">Highlights</label>
                        <div className="space-y-2">
                            {data.programOverview.highlights.map((h, i) => (
                                <div key={i} className="flex items-center gap-2 bg-gray-50 dark:bg-gray-800 p-2 rounded-lg border border-gray-100 dark:border-gray-700">
                                    <span className="flex-1 text-sm">{h}</span>
                                    <button onClick={() => removeListValue('highlights', i)} className="text-gray-400 hover:text-red-500">
                                        <X className="h-4 w-4" />
                                    </button>
                                </div>
                            ))}
                            <div className="flex gap-2">
                                <input 
                                    className="flex-1 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                    placeholder="Add highlight (e.g. Sunset Felucca Ride)"
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter') {
                                            e.preventDefault();
                                            addListValue('highlights', (e.target as HTMLInputElement).value);
                                            (e.target as HTMLInputElement).value = '';
                                        }
                                    }}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
