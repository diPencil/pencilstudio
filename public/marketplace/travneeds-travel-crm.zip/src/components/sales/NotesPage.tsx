import React, { useState, useEffect } from 'react';
import { Save, FileText, ArrowLeft } from 'lucide-react';
import { Button } from '../ui/Button';
import { formatDate } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';

const mockExistingNotes = [
  {
    id: 1,
    content: 'Customer prefers morning flights and 4-star hotels. Budget is flexible.',
    author: 'Super Admin',
    timestamp: '2025-01-15T10:30:00Z',
    type: 'internal'
  },
  {
    id: 2,
    content: 'Discussed package options. Customer interested in Nile cruise extension.',
    author: 'Mahmoud Khalil',
    timestamp: '2025-01-14T16:45:00Z',
    type: 'internal'
  },
  {
    id: 3,
    content: 'Customer requested vegetarian meal options for all flights.',
    author: 'Super Admin',
    timestamp: '2025-01-13T09:15:00Z',
    type: 'requirement'
  }
];

export const NotesPage: React.FC = () => {
  const { t, isRTL, direction } = useLocale();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToastContext();

  const entity = location.state?.entity || location.state?.caseData || location.state?.lead;
  const entityType = location.state?.entityType || 'Sales Case';

  const [newNote, setNewNote] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!entity) {
      navigate(-1);
    }
  }, [entity, navigate]);

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'New': return t('sales.status.new');
      case 'In Progress': return t('sales.status.inProgress');
      case 'Awaiting Reply': return t('sales.status.awaitingReply');
      case 'Quotation Sent': return t('sales.status.quotationSent');
      case 'Won': return t('sales.status.won');
      case 'Lost': return t('sales.status.lost');
      default: return status;
    }
  };

  const getLocalizedType = (type: string) => {
    if (type === 'B2C') return isRTL ? 'B2C (أفراد)' : 'B2C';
    if (type === 'B2B') return isRTL ? 'B2B (شركات)' : 'B2B';
    return type;
  };

  const getLocalizedAgent = (agent: string) => {
    if (!isRTL) return agent;
    switch (agent) {
      case 'Super Admin': return 'المسؤول العام';
      case 'Mahmoud Khalil': return 'محمود خليل';
      case 'Layla Ramadan': return 'ليلى رمضان';
      case 'Sami Youssef': return 'سامي يوسف';
      case 'Mona Zaki': return 'منى زكي';
      default: return agent;
    }
  };

  const getLocalizedNoteContent = (content: string) => {
    if (!isRTL) return content;
    if (content === 'Customer prefers morning flights and 4-star hotels. Budget is flexible.') return 'يفضل العميل الرحلات الصباحية والفنادق 4 نجوم. الميزانية مرنة.';
    if (content === 'Discussed package options. Customer interested in Nile cruise extension.') return 'تمت مناقشة خيارات البرامج. العميل مهتم بتمديد رحلة النيل.';
    if (content === 'Customer requested vegetarian meal options for all flights.') return 'طلب العميل وجبات نباتية لجميع الرحلات الجوية.';
    return content;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newNote.trim()) {
      return;
    }

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      toast.success(
        isRTL ? 'تم الحفظ' : 'Saved',
        isRTL ? 'تم حفظ الملاحظة بنجاح.' : 'Note saved successfully.'
      );
      setNewNote('');
      // We can stay on the page after saving note, or navigate back.
      // Usually users want to stay and see it added (in a real app, it would append to the list).
      navigate(-1);
    } catch (error) {
      console.error('Error saving note:', error);
      toast.error('Error', 'Failed to save note');
    } finally {
      setIsLoading(false);
    }
  };

  if (!entity) return null;

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate(-1)} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
              <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-xl">
                <FileText className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight bidi-isolate">
                  {t('sales.modal.notesTitle')?.replace('{id}', entity.id) || `Notes for ${entity.id}`}
                </h1>
                <p className="mt-1 text-sm text-blue-100 opacity-90">
                  {isRTL ? 'إدارة ومراجعة الملاحظات الخاصة بالعميل' : 'Manage and review notes for this entity'}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-10 shadow-sm border border-gray-100 dark:border-gray-800">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Sidebar with Info & New Note Form */}
            <div className="lg:col-span-1 space-y-8">
              {/* Entity Info */}
              <div className="bg-blue-50 dark:bg-blue-900/10 rounded-2xl p-6 border border-blue-100 dark:border-blue-900/30">
                <h4 className="text-sm font-bold text-blue-800 dark:text-blue-300 mb-4 uppercase tracking-wider">
                  {t('sales.modal.caseInfoSection') || 'Entity Info'}
                </h4>
                <div className="text-sm text-blue-900 dark:text-blue-100 space-y-3 font-medium">
                  <div className="flex justify-between items-center pb-2 border-b border-blue-200/50 dark:border-blue-800/50">
                    <span className="text-blue-600 dark:text-blue-400">{t('sales.table.customer') || 'Customer'}:</span>
                    <span className="font-bold">{entity.customer || entity.fullName || entity.name}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-blue-200/50 dark:border-blue-800/50">
                    <span className="text-blue-600 dark:text-blue-400">{t('sales.table.status') || 'Status'}:</span>
                    <span className="font-bold">{getStatusLabel(entity.status)}</span>
                  </div>
                  {entity.type && (
                    <div className="flex justify-between items-center">
                      <span className="text-blue-600 dark:text-blue-400">{t('sales.table.type') || 'Type'}:</span>
                      <span className="font-bold">{getLocalizedType(entity.type)}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Add New Note */}
              <form onSubmit={handleSubmit} className="bg-gray-50 dark:bg-gray-800/50 p-6 rounded-2xl border border-gray-100 dark:border-gray-700/50">
                <h4 className="text-sm font-bold text-gray-900 dark:text-white mb-4 uppercase tracking-wider">
                  {t('sales.modal.addNewNote') || 'Add New Note'}
                </h4>
                <textarea
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  rows={5}
                  className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none dark:text-white shadow-sm transition-all mb-4"
                  placeholder={t('sales.modal.enterNotePlaceholder') || 'Type your note here...'}
                  required
                />
                <Button
                  type="submit"
                  disabled={isLoading || !newNote.trim()}
                  loading={isLoading}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  <Save className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                  {t('sales.modal.saveNoteBtn') || 'Save Note'}
                </Button>
              </form>
            </div>

            {/* Existing Notes Feed */}
            <div className="lg:col-span-2">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                  {t('sales.modal.existingNotes') || 'Existing Notes'}
                </h3>
                <span className="px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-xs font-bold rounded-full">
                  {mockExistingNotes.length} Notes
                </span>
              </div>
              
              <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
                {mockExistingNotes.map((note) => (
                  <div key={note.id} className="p-5 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full overflow-hidden shadow-sm flex-shrink-0 border border-gray-200 dark:border-gray-700">
                          <img src={getLocalizedAgent(note.author).toLowerCase().includes('fatma') || getLocalizedAgent(note.author).toLowerCase().includes('nour') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-gray-900 dark:text-white">{getLocalizedAgent(note.author)}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400 bidi-isolate">{formatDate(note.timestamp)}</p>
                        </div>
                      </div>
                      <span className={`inline-flex px-3 py-1 text-xs font-bold rounded-full ${
                        note.type === 'internal' 
                          ? 'bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-900/20 dark:text-blue-300 dark:border-blue-800'
                          : 'bg-purple-50 text-purple-700 border border-purple-200 dark:bg-purple-900/20 dark:text-purple-300 dark:border-purple-800'
                      } uppercase tracking-wider`}>
                        {note.type === 'internal' ? (isRTL ? 'ملاحظة داخلية' : 'Internal') : (isRTL ? 'متطلب عميل' : 'Requirement')}
                      </span>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-900/50 p-4 rounded-xl border border-gray-100 dark:border-gray-800">
                      <p className="text-base text-gray-700 dark:text-gray-300 leading-relaxed">
                        {getLocalizedNoteContent(note.content)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
