import React, { useState, useEffect } from 'react';
import { Save, Plus, Calendar, User, FileText, CheckCircle, Clock, Tag, ExternalLink, ArrowLeft } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { formatDate } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';
import { SalesTask } from './TodayTasksPage';

export const TaskPage: React.FC = () => {
    const { t, isRTL, direction } = useLocale();
    const navigate = useNavigate();
    const location = useLocation();
    const toast = useToastContext();
    
    const task = location.state?.task as SalesTask | undefined;
    const mode = location.state?.mode as 'view' | 'edit' | 'add' || 'add';

    const [formData, setFormData] = useState({
        title: '',
        customer: '',
        caseId: '',
        dueDate: '',
        priority: 'Medium',
        status: 'Due Today',
        description: ''
    });
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        if (task && (mode === 'edit' || mode === 'view')) {
            setFormData({
                title: task.title || '',
                customer: task.customer || '',
                caseId: task.caseId || '',
                dueDate: task.dueDate || '',
                priority: task.priority || 'Medium',
                status: task.status || 'Due Today',
                description: task.description || ''
            });
        } else if (mode === 'add') {
            setFormData({
                title: '',
                customer: '',
                caseId: '',
                dueDate: new Date().toISOString().split('T')[0],
                priority: 'Medium',
                status: 'Due Today',
                description: ''
            });
        }
    }, [task, mode]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (mode === 'view') {
            navigate(-1);
            return;
        }
        setIsLoading(true);
        try {
            await new Promise(resolve => setTimeout(resolve, 500));
            toast.success(
                isRTL ? 'نجاح' : 'Success',
                mode === 'add' ? (isRTL ? 'تم إنشاء المهمة بنجاح.' : 'Task created successfully.') : (isRTL ? 'تم تحديث المهمة بنجاح.' : 'Task updated successfully.')
            );
            navigate(-1);
        } catch (error) {
            console.error('Error saving task:', error);
            toast.error('Error', 'Failed to save task');
        } finally {
            setIsLoading(false);
        }
    };

    const getPriorityColor = (priority: string) => {
        switch (priority) {
            case 'Critical': return 'text-red-600 bg-red-100 dark:bg-red-900/20 dark:text-red-400 border-red-200 dark:border-red-800';
            case 'High': return 'text-orange-600 bg-orange-100 dark:bg-orange-900/20 dark:text-orange-400 border-orange-200 dark:border-orange-800';
            case 'Medium': return 'text-blue-600 bg-blue-100 dark:bg-blue-900/20 dark:text-blue-400 border-blue-200 dark:border-blue-800';
            default: return 'text-gray-600 bg-gray-100 dark:bg-gray-700 dark:text-gray-400 border-gray-200 dark:border-gray-600';
        }
    };

    const getLocalizedPriority = (priority: string) => {
        switch (priority) {
            case 'Critical': return isRTL ? 'حرجة' : 'Critical';
            case 'High': return isRTL ? 'مرتفعة' : 'High';
            case 'Medium': return isRTL ? 'متوسطة' : 'Medium';
            case 'Low': return isRTL ? 'منخفضة' : 'Low';
            default: return priority;
        }
    };

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'Overdue': return 'text-red-600 bg-red-100 dark:bg-red-900/20 dark:text-red-400 border-red-200 dark:border-red-800';
            case 'Due Today': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20 dark:text-yellow-400 border-yellow-200 dark:border-yellow-800';
            case 'Completed': return 'text-green-600 bg-green-100 dark:bg-green-900/20 dark:text-green-400 border-green-200 dark:border-green-800';
            default: return 'text-blue-600 bg-blue-100 dark:bg-blue-900/20 dark:text-blue-400 border-blue-200 dark:border-blue-800';
        }
    };

    const getLocalizedStatus = (status: string) => {
        switch (status) {
            case 'Overdue': return t('sales.tasks.overdue') || 'Overdue';
            case 'Due Today': return t('sales.tasks.dueToday') || 'Due Today';
            case 'Completed': return t('sales.tasks.completed') || 'Completed';
            case 'Pending': return t('sales.tasks.pending') || 'Pending';
            default: return status;
        }
    };

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
                    <div className="flex items-center gap-4">
                        <Button variant="outline" onClick={() => navigate(-1)} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                            <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
                        </Button>
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-white/10 rounded-xl">
                                {mode === 'view' ? <FileText className="h-6 w-6 text-white" /> : <EditIcon size={24} />}
                            </div>
                            <div>
                                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                                    {mode === 'view' ? (t('sales.modal.viewTitle') || 'View Task') : mode === 'add' ? (t('sales.tasks.createTitle') || 'Create Task') : (t('sales.modal.editTitle') || 'Edit Task')}
                                </h1>
                                <p className="mt-1 text-sm text-blue-100 opacity-90">
                                    {mode === 'view' ? (isRTL ? 'عرض تفاصيل المهمة' : 'View task details') : (isRTL ? 'إدارة بيانات المهمة وتحديث حالتها' : 'Manage task details and update status')}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 overflow-hidden max-w-4xl mx-auto">
                    <form onSubmit={handleSubmit} className="p-0">
                        {mode === 'view' ? (
                            /* View Mode Layout */
                            <div className="p-6 sm:p-10 space-y-10">
                                {/* Title Section */}
                                <div className="text-center sm:text-left rtl:sm:text-right border-b border-gray-100 dark:border-gray-800 pb-8">
                                    <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">{formData.title}</h3>
                                    <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3">
                                        <span className={`inline-flex items-center px-4 py-1.5 rounded-full text-xs font-bold border ${getPriorityColor(formData.priority)} uppercase tracking-wider`}>
                                            <Tag size={14} className={isRTL ? 'ml-1.5' : 'mr-1.5'} />
                                            {isRTL ? `أولوية ${getLocalizedPriority(formData.priority)}` : `${formData.priority} Priority`}
                                        </span>
                                        <span className={`inline-flex items-center px-4 py-1.5 rounded-full text-xs font-bold border ${getStatusColor(formData.status)} uppercase tracking-wider`}>
                                            <Clock size={14} className={isRTL ? 'ml-1.5' : 'mr-1.5'} />
                                            {getLocalizedStatus(formData.status)}
                                        </span>
                                    </div>
                                </div>

                                {/* Info Grid */}
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-6 bg-gray-50 dark:bg-gray-800/50 p-6 rounded-2xl border border-gray-100 dark:border-gray-700/50">
                                        <div className="flex items-start gap-4">
                                            <div className="p-2.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl">
                                                <User size={20} />
                                            </div>
                                            <div className={isRTL ? 'text-right' : 'text-left'}>
                                                <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">{t('sales.tasks.colCustomer') || 'Customer'}</p>
                                                <p className="text-base font-bold text-gray-900 dark:text-white">{formData.customer}</p>
                                            </div>
                                        </div>
                                        <div className="flex items-start gap-4">
                                            <div className="p-2.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl">
                                                <Calendar size={20} />
                                            </div>
                                            <div className={isRTL ? 'text-right' : 'text-left'}>
                                                <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">{t('sales.tasks.colDueDate') || 'Due Date'}</p>
                                                <p className="text-base font-bold text-gray-900 dark:text-white bidi-isolate">{formatDate(formData.dueDate)}</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="space-y-6 bg-gray-50 dark:bg-gray-800/50 p-6 rounded-2xl border border-gray-100 dark:border-gray-700/50">
                                        <div className="flex items-start gap-4">
                                            <div className="p-2.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl">
                                                <ExternalLink size={20} />
                                            </div>
                                            <div className={isRTL ? 'text-right' : 'text-left'}>
                                                <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">{t('sales.tasks.colCaseId') || 'Case ID'}</p>
                                                <p className="text-base font-bold text-blue-600 dark:text-blue-400 bidi-isolate">{formData.caseId || (t('sales.tasks.noLinkedCase') || 'No Linked Case')}</p>
                                            </div>
                                        </div>
                                        <div className="flex items-start gap-4">
                                            <div className="p-2.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl">
                                                <CheckCircle size={20} />
                                            </div>
                                            <div className={isRTL ? 'text-right' : 'text-left'}>
                                                <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">{t('sales.tasks.taskId') || 'Task ID'}</p>
                                                <p className="text-base font-bold text-gray-900 dark:text-white bidi-isolate">{task?.id || '-'}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Description */}
                                <div>
                                    <p className="text-sm text-gray-500 uppercase font-bold tracking-wider mb-3">{t('sales.modal.descriptionLabel') || 'Description'}</p>
                                    <div className="bg-gray-50 dark:bg-gray-800/50 p-6 rounded-2xl border border-gray-200 dark:border-gray-700/50">
                                        <p className="text-base text-gray-700 dark:text-gray-300 leading-relaxed">
                                            {formData.description || (t('sales.tasks.noDescription') || 'No description provided.')}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            /* Edit/Add Mode Layout */
                            <div className="p-6 sm:p-10 space-y-6">
                                <Input
                                    label={(t('sales.modal.taskTitleLabel') || 'Task Title').replace(' *', '')}
                                    value={formData.title}
                                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                                    required
                                    placeholder={t('sales.modal.taskTitlePlaceholder') || 'Enter task title'}
                                />

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <Input
                                        label={(t('sales.modal.customerLabel') || 'Customer Name').replace(' *', '')}
                                        value={formData.customer}
                                        onChange={(e) => setFormData(prev => ({ ...prev, customer: e.target.value }))}
                                        required
                                        placeholder={t('sales.modal.customerPlaceholder') || 'Enter customer name'}
                                    />
                                    <Input
                                        label={t('sales.tasks.colCaseId') || 'Case ID (Optional)'}
                                        value={formData.caseId}
                                        onChange={(e) => setFormData(prev => ({ ...prev, caseId: e.target.value }))}
                                        placeholder="CS-2025-..."
                                    />
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <Input
                                        label={(t('sales.modal.dueDateLabel') || 'Due Date').replace(' *', '')}
                                        type="date"
                                        value={formData.dueDate}
                                        onChange={(e) => setFormData(prev => ({ ...prev, dueDate: e.target.value }))}
                                        required
                                    />
                                    <Select
                                        label={t('sales.modal.priorityLabel') || 'Priority'}
                                        value={formData.priority}
                                        onChange={(e) => setFormData(prev => ({ ...prev, priority: e.target.value }))}
                                    >
                                        <option value="Critical">{getLocalizedPriority('Critical')}</option>
                                        <option value="High">{getLocalizedPriority('High')}</option>
                                        <option value="Medium">{getLocalizedPriority('Medium')}</option>
                                        <option value="Low">{getLocalizedPriority('Low')}</option>
                                    </Select>
                                </div>

                                <Select
                                    label={t('sales.tasks.colStatus') || 'Status'}
                                    value={formData.status}
                                    onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value }))}
                                >
                                    <option value="Due Today">{getLocalizedStatus('Due Today')}</option>
                                    <option value="Overdue">{getLocalizedStatus('Overdue')}</option>
                                    <option value="Pending">{getLocalizedStatus('Pending')}</option>
                                    <option value="Completed">{getLocalizedStatus('Completed')}</option>
                                </Select>

                                <div className="space-y-2 pt-2">
                                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300">{t('sales.modal.descriptionLabel') || 'Description'}</label>
                                    <textarea
                                        value={formData.description}
                                        onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                                        rows={5}
                                        className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-base focus:ring-2 focus:ring-blue-500 outline-none dark:text-white shadow-sm transition-all"
                                        placeholder={t('sales.modal.descriptionPlaceholder') || 'Task description...'}
                                    />
                                </div>
                            </div>
                        )}

                        {/* Footer */}
                        <div className="flex justify-end items-center gap-4 p-6 sm:px-10 border-t border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-gray-900/50">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => navigate(-1)}
                                disabled={isLoading}
                                className="px-8"
                            >
                                {mode === 'view' ? (t('sales.modal.gotIt') || 'Back') : (t('sales.modal.cancel') || 'Cancel')}
                            </Button>
                            {mode !== 'view' && (
                                <Button
                                    type="submit"
                                    disabled={isLoading}
                                    loading={isLoading}
                                    className="px-8 bg-blue-600 hover:bg-blue-700"
                                >
                                    {mode === 'add' ? <Plus className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} /> : <Save className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />}
                                    {mode === 'add' ? (t('sales.modal.scheduleTaskBtn') || 'Create Task') : (t('sales.modal.saveChanges') || 'Save Changes')}
                                </Button>
                            )}
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

// Internal Edit icon for the header
const EditIcon = ({ size }: { size: number }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
);
