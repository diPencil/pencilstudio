import React, { useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Edit, Info, Printer, Send } from 'lucide-react';
import { PageHeader } from '../ui/PageHeader';
import { Button } from '../ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { mockCases, mockItems, mockQuotations, mockSuppliers } from '../../services/mockData';
import type { Quotation, QuotationCostItem, QuotationServiceLine, QuotationVersion } from '../../types/quotation';
import { useLocale } from '../../localization/useLocale';
import { formatCurrency, formatDate, formatPercent } from '../../utils/format';

const LAST_DRAFT_KEY = 'travneeds_quote_draft:last';

interface PreviewDraftPayload {
    quotationId: string;
    caseId: string;
    reference: string;
    currentVersion: number;
    version: QuotationVersion;
}

const badgeClass = (status: string) => {
    if (status === 'Approved' || status === 'Active' || status === 'Sent') return 'bg-emerald-50 text-emerald-700 border-emerald-100';
    if (status === 'Draft' || status === 'Revised' || status === 'Needs review') return 'bg-amber-50 text-amber-700 border-amber-100';
    return 'bg-rose-50 text-rose-700 border-rose-100';
};

const serviceLinesFromCosting = (costing: QuotationCostItem[]): QuotationServiceLine[] => costing.map(item => {
    const product = mockItems.find(mockItem => item.name.toLowerCase().includes(mockItem.name.toLowerCase().split(' ')[0]));
    const supplier = mockSuppliers.find(entry => entry.id === product?.supplierId);
    const totalSelling = item.totalCost * 1.15;
    return {
        id: item.id,
        productId: product?.id || item.id,
        serviceName: item.name,
        category: item.category,
        type: product?.type || item.pricingType,
        destination: item.city,
        supplierId: supplier?.id,
        supplierName: supplier?.name || product?.supplierName,
        supplierStatus: supplier?.status,
        supplierRisk: supplier && (supplier.performance?.qualityScore || 0) < 70 ? 'High Risk' : supplier ? 'Healthy' : 'Missing',
        productStatus: product?.status || 'Active',
        costPrice: item.rate,
        sellingPrice: totalSelling,
        quantity: item.quantity,
        nights: item.nights || 1,
        pax: 1,
        units: 1,
        taxes: 0,
        adjustment: 0,
        totalCost: item.totalCost,
        totalSelling,
        profit: totalSelling - item.totalCost,
        marginPercent: totalSelling ? Math.round(((totalSelling - item.totalCost) / totalSelling) * 100) : 0,
        day: 1,
        availability: product?.availability || 'Mock availability',
        notes: item.notes
    };
});

export const QuotationPreviewPage: React.FC = () => {
    const { t, isRTL, direction } = useLocale();
    const { caseId, quotationId } = useParams<{ caseId: string; quotationId: string }>();
    const navigate = useNavigate();
    const location = useLocation();
    const [proposalLogs, setProposalLogs] = useState<Array<{ id: string; action: string; date: string; note: string }>>([]);
    const routeDraft = (location.state as { draft?: PreviewDraftPayload; draftKey?: string } | null)?.draft;
    const routeDraftKey = (location.state as { draftKey?: string } | null)?.draftKey;
    const storedDraft = loadStoredDraft(caseId, quotationId, routeDraftKey);
    const liveDraft = routeDraft || storedDraft;
    const quotation = liveDraft ? quotationFromDraft(liveDraft) : mockQuotations.find(q => q.id === quotationId);
    const salesCase = mockCases.find(c => c.id === caseId);

    const getLocalizedStatus = (status: string) => {
        switch (status) {
            case 'Draft': return t('common.draft');
            case 'Approved': return t('common.approved');
            case 'Rejected': return t('common.rejected');
            case 'Sent': return t('common.sent');
            case 'Revised': return t('products.status.needsReview');
            case 'Needs review': return t('products.status.needsReview');
            default: return status;
        }
    };

    const getLocalizedAllocationMethod = (method: string) => {
        switch (method) {
            case 'Split Equally': return t('quotation.costing.fixedCosts.allocation.splitEqually');
            case 'Per Person': return t('quotation.costing.fixedCosts.allocation.perPerson');
            case 'Per Group': return t('quotation.costing.fixedCosts.allocation.perGroup');
            case 'Per Day': return t('quotation.costing.fixedCosts.allocation.perDay');
            default: return method;
        }
    };

    if (!quotation) {
        return (
            <div className="page-container py-20 text-center">
                <Info className="mx-auto mb-4 h-12 w-12 text-gray-300" />
                <h2 className="text-xl font-bold">{t('quotation.preview.quoteNotFound')}</h2>
                <Button variant="outline" className="mt-4" onClick={() => navigate(`/sales/cases/${caseId}`)}>
                    {t('quotation.preview.backToCase')}
                </Button>
            </div>
        );
    }

    const latestVersion = quotation.versions[quotation.versions.length - 1];
    const pax = latestVersion.customerInfo.pax || {
        adults: 2,
        children: 0,
        infants: 0,
        total: 2,
        arrival: '',
        departure: '',
        nights: latestVersion.programOverview.nights || 0
    };
    const serviceLines = latestVersion.serviceLines?.length ? latestVersion.serviceLines : serviceLinesFromCosting(latestVersion.costing);
    const margin = latestVersion.pricing.totalSellingPrice
        ? Math.round((latestVersion.pricing.profitAmount / latestVersion.pricing.totalSellingPrice) * 100)
        : 0;

    const sendMock = () => {
        setProposalLogs(prev => [
            { 
                id: `PLOG-${Date.now()}`, 
                action: t('quotation.preview.send'), 
                date: new Date().toISOString().slice(0, 10), 
                note: t('quotation.preview.toast.sentDesc') 
            }, 
            ...prev
        ]);
    };

    return (
        <div className="w-full pb-8 overflow-x-hidden">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <PageHeader
                    title={`${t('quotation.preview.title')}: \u2066${quotation.reference}\u2069`}
                    description={`${latestVersion.programOverview.title || t('quotation.builder.untitledPackage')} ${t('quotation.preview.for')} ${latestVersion.customerInfo.customerName}`}
                actions={
                    <div className="flex flex-wrap gap-2">
                        <Button variant="outline" onClick={() => navigate(`/sales/cases/${caseId}`)}>
                            <ArrowLeft className={`${isRTL ? 'ml-2 rotate-180' : 'mr-2'} h-4 w-4`} />
                            {t('common.back')}
                        </Button>
                        <Button variant="outline" onClick={() => navigate(`/sales/cases/${caseId}/quotations/${quotationId}/edit`)}>
                            <Edit className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4`} />
                            {t('common.edit')}
                        </Button>
                        <Button variant="outline" onClick={() => navigate(`/sales/cases/${caseId}/quotations/${quotationId}/print`)}>
                            <Printer className={`${isRTL ? 'ml-2' : 'mr-2'} h-4 w-4`} />
                            {t('quotation.preview.print')}
                        </Button>
                        <Button onClick={sendMock}>
                            <Send className={`${isRTL ? 'ml-2 rotate-180' : 'mr-2'} h-4 w-4`} />
                            {t('quotation.preview.send')}
                        </Button>
                    </div>
                }
            />

            <div className="grid grid-cols-1 gap-6 xl:grid-cols-4">
                <div className="space-y-6 xl:col-span-3">
                    <Card className="card-premium">
                        <CardContent className="space-y-6 p-6">
                            <div className="border-b border-gray-100 pb-6">
                                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                                    <div className="rtl:text-right">
                                        <h1 className="text-3xl font-bold">{latestVersion.programOverview.title}</h1>
                                        <p className="mt-2 text-gray-500">{latestVersion.programOverview.description}</p>
                                    </div>
                                    <div className="text-left sm:text-right rtl:text-right sm:rtl:text-left">
                                        <span className={`inline-flex rounded-full border px-3 py-1 text-xs font-bold ${badgeClass(latestVersion.status)}`}>
                                            {getLocalizedStatus(latestVersion.status)}
                                        </span>
                                        <div className="mt-2 text-sm text-gray-500">
                                            {t('quotation.preview.header.version')} <span className="ltr-value">{latestVersion.versionNumber}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                                <InfoBlock 
                                    label={t('quotation.preview.info.customerCase')} 
                                    value={
                                        <span>
                                            {latestVersion.customerInfo.customerName} - <span className="ltr-value font-mono">{salesCase?.id || caseId}</span>
                                        </span>
                                    } 
                                />
                                <InfoBlock 
                                    label={t('quotation.preview.info.dates')} 
                                    value={
                                        <span className="bidi-isolate">
                                            {pax.arrival ? formatDate(pax.arrival) : 'TBD'} {t('common.to')} {pax.departure ? formatDate(pax.departure) : 'TBD'}
                                        </span>
                                    } 
                                />
                                <InfoBlock 
                                    label={t('quotation.preview.info.pax')} 
                                    value={
                                        <span className="bidi-isolate">
                                            {pax.total} {t('quotation.builder.pax')}
                                        </span>
                                    } 
                                />
                                <InfoBlock 
                                    label={t('quotation.preview.info.packageCode')} 
                                    value={<span className="ltr-value font-mono">{latestVersion.programOverview.packageCode}</span>} 
                                />
                                <InfoBlock 
                                    label={t('quotation.preview.info.destinations')} 
                                    value={latestVersion.programOverview.destinations.join(', ') || latestVersion.programOverview.citiesCovered.join(', ')} 
                                />
                                <InfoBlock 
                                    label={t('quotation.preview.header.preparedBy')} 
                                    value={latestVersion.preparedBy} 
                                />
                            </div>

                            <PreviewSection title={t('quotation.preview.itinerary.title')}>
                                <div className="space-y-3">
                                    {latestVersion.itinerary.map(day => (
                                        <div key={day.day} className="rounded-lg border border-gray-100 p-4 rtl:text-right">
                                            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                                                <div className="font-bold">
                                                    {t('quotation.preview.day')} <span className="bidi-isolate">{day.day}</span>: {day.title}
                                                </div>
                                                <div className="text-sm text-gray-500 bidi-isolate">
                                                    {day.date ? formatDate(day.date) : ''} {day.city}
                                                </div>
                                            </div>
                                            <p className="mt-2 text-sm text-gray-600">{day.description}</p>
                                            <div className="mt-2 text-xs text-gray-500">
                                                {t('quotation.preview.services')}: <span className="bidi-isolate">{(day.serviceLineIds || []).join(', ') || day.accommodation || day.transport || t('quotation.preview.servicesIncluded')}</span>
                                            </div>
                                        </div>
                                    ))}
                                    {latestVersion.itinerary.length === 0 && (
                                        <div className="text-sm text-gray-500 rtl:text-right">
                                            {t('quotation.preview.noDays')}
                                        </div>
                                    )}
                                </div>
                            </PreviewSection>

                            <PreviewSection title={t('quotation.preview.services.title')}>
                                <div className="overflow-x-auto">
                                    <table style={{ direction }} className="w-full min-w-[760px] text-sm text-left rtl:text-right">
                                        <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-500">
                                            <tr>
                                                <th className="px-4 py-3 logical-start">{t('quotation.costing.table.service')}</th>
                                                <th className="px-4 py-3 logical-start">{t('quotation.costing.table.category')}</th>
                                                <th className="px-4 py-3 logical-start">{t('products.catalog.table.destination')}</th>
                                                <th className="px-4 py-3 logical-start">{t('quotation.costing.table.supplier')}</th>
                                                <th className="px-4 py-3 logical-end">{t('quotation.preview.services.table.price')}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {serviceLines.map(line => (
                                                <tr key={line.id} className="border-t">
                                                    <td className="px-4 py-3 font-semibold logical-start">
                                                        {line.serviceName}
                                                        {line.isComplimentary && (
                                                            <span className="mx-2 inline-flex rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-semibold text-blue-800 dark:bg-blue-900/30 dark:text-blue-400">
                                                                {t('quotation.costing.foc')}
                                                            </span>
                                                        )}
                                                    </td>
                                                    <td className="px-4 py-3 logical-start">{line.category}</td>
                                                    <td className="px-4 py-3 logical-start">{line.destination}</td>
                                                    <td className="px-4 py-3 logical-start">{line.supplierName || t('quotation.costing.supplierMissing')}</td>
                                                    <td className="px-4 py-3 logical-end font-semibold bidi-isolate">
                                                        {line.isComplimentary ? (
                                                            <span className="text-blue-600 dark:text-blue-400">
                                                                {formatCurrency(0)} ({t('quotation.costing.foc')})
                                                            </span>
                                                        ) : (
                                                            formatCurrency(line.totalSelling)
                                                        )}
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </PreviewSection>

                            {latestVersion.fixedCosts && latestVersion.fixedCosts.filter(fc => fc.status === 'Active').length > 0 && (
                                <PreviewSection title={t('quotation.preview.fixedSharedCosts')}>
                                    <div className="overflow-x-auto rounded-xl border border-gray-100 bg-white dark:border-gray-800 dark:bg-gray-900 mb-6">
                                        <table style={{ direction }} className="w-full min-w-[500px] text-sm text-left rtl:text-right">
                                            <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-500">
                                                <tr>
                                                    <th className="px-4 py-3 logical-start">{t('quotation.costing.fixedCosts.table.name')}</th>
                                                    <th className="px-4 py-3 logical-start">{t('quotation.costing.fixedCosts.table.category')}</th>
                                                    <th className="px-4 py-3 logical-start">{t('quotation.preview.allocationMethod')}</th>
                                                    <th className="px-4 py-3 logical-end">{t('quotation.costing.fixedCosts.table.total')}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {latestVersion.fixedCosts.filter(fc => fc.status === 'Active').map(fc => (
                                                    <tr key={fc.id} className="border-t">
                                                        <td className="px-4 py-3 font-semibold text-gray-900 dark:text-white logical-start">{fc.name}</td>
                                                        <td className="px-4 py-3 text-gray-600 dark:text-gray-400 logical-start">{fc.category}</td>
                                                        <td className="px-4 py-3 text-gray-600 dark:text-gray-400 logical-start">{getLocalizedAllocationMethod(fc.allocationMethod)}</td>
                                                        <td className="px-4 py-3 logical-end font-semibold text-gray-900 dark:text-white bidi-isolate">{formatCurrency(fc.amount)}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </PreviewSection>
                            )}

                            <PreviewSection title={t('quotation.preview.terms.title')}>
                                <p className="whitespace-pre-wrap text-sm text-gray-600 rtl:text-right">{latestVersion.terms}</p>
                            </PreviewSection>
                        </CardContent>
                    </Card>
                </div>

                <div className="space-y-6">
                    <Card className="card-premium">
                        <CardHeader>
                            <CardTitle className="rtl:text-right">{t('quotation.preview.pricing.title')}</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <InfoBlock 
                                label={t('quotation.preview.pricing.totalCost')} 
                                value={<span className="bidi-isolate">{formatCurrency(latestVersion.pricing.grandTotalCost)}</span>} 
                            />
                            <InfoBlock 
                                label={t('quotation.builder.grossProfit')} 
                                value={<span className="bidi-isolate">{formatCurrency(latestVersion.pricing.profitAmount)}</span>} 
                                tone="green" 
                            />
                            <InfoBlock 
                                label={t('quotation.builder.margin')} 
                                value={<span className="bidi-isolate">{formatPercent(margin / 100)}</span>} 
                                tone={margin < 15 ? 'red' : 'green'} 
                            />
                            <div className="rounded-xl bg-blue-50 p-4 rtl:text-right">
                                <div className="text-xs font-bold uppercase tracking-wide text-blue-600">{t('quotation.preview.clientPrice')}</div>
                                <div className="text-2xl font-bold text-blue-700 bidi-isolate">{formatCurrency(latestVersion.pricing.totalSellingPrice)}</div>
                                <div className="text-xs text-blue-600 bidi-isolate">
                                    {formatCurrency(latestVersion.pricing.sellingPricePerPerson)} / {t('quotation.pricing.scenarios.perPerson')}
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="card-premium">
                        <CardHeader>
                            <CardTitle className="rtl:text-right">{t('quotation.preview.proposalLog')}</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-2">
                            {[...proposalLogs, ...(latestVersion.proposalLogs || []).map(log => ({ id: log.id, action: log.action, date: log.date, note: log.note }))].map(log => (
                                <div key={log.id} className="rounded border border-gray-100 p-2 text-sm rtl:text-right">
                                    <div className="font-semibold">{log.action === 'Send to Client' ? t('quotation.preview.send') : log.action}</div>
                                    <div className="text-xs text-gray-500 bidi-isolate">
                                        {log.note} - {formatDate(log.date)}
                                    </div>
                                </div>
                            ))}
                            {proposalLogs.length === 0 && (latestVersion.proposalLogs || []).length === 0 && (
                                <div className="text-sm text-gray-500 rtl:text-right">
                                    {t('quotation.preview.proposalLog.noLogs')}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
        </div>
    );
};

const loadStoredDraft = (caseId?: string, quotationId?: string, routeDraftKey?: string): PreviewDraftPayload | undefined => {
    try {
        const storageKeys = [
            routeDraftKey,
            caseId && quotationId ? `travneeds_quote_draft:${caseId}:${quotationId}` : undefined,
            sessionStorage.getItem(LAST_DRAFT_KEY) || undefined
        ].filter(Boolean) as string[];

        for (const key of storageKeys) {
            const raw = sessionStorage.getItem(key);
            if (!raw) continue;
            const parsed = JSON.parse(raw) as PreviewDraftPayload;
            if (!quotationId || parsed.quotationId === quotationId) return parsed;
        }
    } catch {
        return undefined;
    }

    return undefined;
};

const quotationFromDraft = (draft: PreviewDraftPayload): Quotation => ({
    id: draft.quotationId,
    caseId: draft.caseId,
    reference: draft.reference,
    currentVersion: draft.currentVersion,
    versions: [draft.version],
    createdAt: draft.version.preparedDate,
    updatedAt: new Date().toISOString().split('T')[0]
});

const PreviewSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <section>
        <h2 className="mb-3 text-lg font-bold">{title}</h2>
        {children}
    </section>
);

const InfoBlock: React.FC<{ label: string; value: React.ReactNode; tone?: 'green' | 'red' | 'default' }> = ({ label, value, tone = 'default' }) => (
    <div>
        <div className="text-xs font-bold uppercase tracking-wide text-gray-500">{label}</div>
        <div className={`break-words text-sm font-semibold ${tone === 'green' ? 'text-emerald-600' : tone === 'red' ? 'text-rose-600' : 'text-gray-900'}`}>{value ?? '-'}</div>
    </div>
);
