import React, { useState, useEffect } from 'react';
import { Plus, Search, Eye, FileText, Calendar, BookOpen, Clock, DollarSign, TrendingUp } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { formatDate, formatCurrency } from '../../utils/format';
// removed modals
// removed ScheduleModal
// removed TodaysTasksModal
import { useToastContext } from '../../contexts/ToastContext';
import { mockCases, mockTasks, mockQuotations } from '../../services/mockData';
import { QuotationStatusBadge } from './QuotationStatusBadge';
import { useNavigate } from 'react-router-dom';
import { useLocale } from '../../localization/useLocale';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { cn } from '../../utils/cn';
export interface SalesCase {
    id: string;
    customer: string;
    customerEmail: string;
    customerPhone: string;
    status: string;
    type: string;
    departments: string[];
    createdAt: string;
    lastActivity: string;
    linkedItems: string[];
    notes: string;
    value: number;
    quotationStatus: string;
    assignedAgent: string;
}

export const SalesPage: React.FC = () => {
    const { t, isRTL } = useLocale();
    const [cases, setCases] = useState(mockCases || []);
    const [tasks, setTasks] = useState(mockTasks || []);
    const [searchTerm, setSearchTerm] = useState('');
    const [typeFilter, setTypeFilter] = useState('All Types');
    const [statusFilter, setStatusFilter] = useState('All Status');

    // removed modal state
    const [selectedCase, setSelectedCase] = useState<SalesCase | null>(null);

    const location = useLocation();
    const navigate = useNavigate();
    const toast = useToastContext();

    useEffect(() => {
        if (location.state && (location.state as { openModal?: string }).openModal === 'add') {
            navigate('/sales/new-case');
            window.history.replaceState({}, document.title);
        }
    }, [location.state, navigate]);

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'New': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
            case 'In Progress': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
            case 'Awaiting Reply': return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300';
            case 'Quotation Sent': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300';
            case 'Won': return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/20 dark:text-emerald-300';
            case 'Lost': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
            default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
        }
    };

    const getStatusLabel = (status: string) => {
        switch (status) {
            case 'New': return t('sales.status.new');
            case 'In Progress': return t('sales.status.inProgress');
            case 'Awaiting Reply': return t('sales.status.awaitingReply');
            case 'Quotation Sent': return t('sales.status.quotationSent');
            case 'Won': return t('sales.status.won');
            case 'Lost': return t('sales.status.lost');
            default: return status;
        }
    };

    const getLocalizedType = (type: string) => {
        if (type === 'B2C') return isRTL ? 'B2C (أفراد)' : 'B2C';
        if (type === 'B2B') return isRTL ? 'B2B (شركات)' : 'B2B';
        return type;
    };

    const filteredCases = cases.filter(c => {
        const matchesSearch = c.customer.toLowerCase().includes(searchTerm.toLowerCase()) || c.id.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesType = typeFilter === 'All Types' || c.type === typeFilter;
        const matchesStatus = statusFilter === 'All Status' || c.status === statusFilter;
        return matchesSearch && matchesType && matchesStatus;
    });



    return (
        <div className="w-full pb-8" dir={isRTL ? 'rtl' : 'ltr'}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                {/* Top Welcome Banner (NeoPay Style) */}
                <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
                <div className={cn(isRTL ? "text-right" : "text-left")}>
                    <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                        {t('sales.title')}
                    </h1>
                    <p className="mt-1 text-sm text-blue-100 opacity-90">
                        {t('sales.subtitle')}
                    </p>
                </div>
                
                <div className={cn("flex items-center gap-2 sm:gap-3 banner-actions", isRTL && "flex-row-reverse")}>
                    <button 
                        onClick={() => navigate('/sales/tasks')}
                        className="flex items-center gap-2 bg-white/10 hover:bg-white text-blue-50 hover:text-blue-600 px-4 py-2.5 rounded-xl font-bold transition-all duration-300"
                    >
                        <Calendar className="h-4 w-4" />
                        <span>{t('sales.action.tasks')}</span>
                    </button>
                    <button 
                        onClick={() => navigate('/sales/new-case')}
                        className="flex items-center gap-2 bg-white text-blue-600 hover:bg-blue-50 px-4 py-2.5 rounded-xl font-bold transition-all duration-300 shadow-sm hover:shadow"
                    >
                        <Plus className="h-4 w-4" />
                        <span>{t('sales.action.newCase')}</span>
                    </button>
                </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="border-none shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_8px_32px_-8px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-300 relative overflow-hidden group">
                    <CardContent className="p-5 relative z-10">
                        <div className={cn('flex items-center justify-between', isRTL && 'flex-row-reverse')}>
                            <div className="flex-1 min-w-0">
                                <DollarSign className={cn("absolute -bottom-4 h-28 w-28 text-blue-500/10 group-hover:scale-110 group-hover:-translate-y-2 group-hover:-translate-x-2 transition-all duration-500", isRTL ? "-left-4" : "-right-4")} />
                                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 truncate">{t('sales.metrics.weightedPipeline')}</p>
                                <p className="text-2xl font-bold mt-1 text-gray-900 dark:text-white truncate bidi-isolate">{formatCurrency(142500)}</p>
                                <p className="text-[10px] text-gray-400 font-bold mt-1">{t('sales.metrics.weightedPipelineDesc')}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-none shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_8px_32px_-8px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-300 relative overflow-hidden group">
                    <CardContent className="p-5 relative z-10">
                        <div className={cn('flex items-center justify-between', isRTL && 'flex-row-reverse')}>
                            <div className="flex-1 min-w-0">
                                <FileText className={cn("absolute -bottom-4 h-28 w-28 text-purple-500/10 group-hover:scale-110 group-hover:-translate-y-2 group-hover:-translate-x-2 transition-all duration-500", isRTL ? "-left-4" : "-right-4")} />
                                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 truncate">{t('sales.metrics.quotationsValue')}</p>
                                <p className="text-2xl font-bold mt-1 text-gray-900 dark:text-white truncate bidi-isolate">{formatCurrency(84200)}</p>
                                <p className="text-[10px] text-purple-500 font-bold mt-1">
                                    {isRTL ? <><span className="bidi-isolate">12</span> قيد انتظار القبول</> : <><span className="bidi-isolate">12</span> Pending Acceptance</>}
                                </p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-none shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_8px_32px_-8px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-300 relative overflow-hidden group">
                    <CardContent className="p-5 relative z-10">
                        <div className={cn('flex items-center justify-between', isRTL && 'flex-row-reverse')}>
                            <div className="flex-1 min-w-0">
                                <TrendingUp className={cn("absolute -bottom-4 h-28 w-28 text-emerald-500/10 group-hover:scale-110 group-hover:-translate-y-2 group-hover:-translate-x-2 transition-all duration-500", isRTL ? "-left-4" : "-right-4")} />
                                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 truncate">{t('sales.metrics.winRate')}</p>
                                <p className="text-2xl font-bold mt-1 text-gray-900 dark:text-white truncate bidi-isolate">64%</p>
                                <p className="text-[10px] text-emerald-500 font-bold mt-1">
                                    <span className="bidi-isolate">↑ 4%</span> {t('sales.metrics.winRateDesc')}
                                </p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-none shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_8px_32px_-8px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-300 relative overflow-hidden group">
                    <CardContent className="p-5 relative z-10">
                        <div className={cn('flex items-center justify-between', isRTL && 'flex-row-reverse')}>
                            <div className="flex-1 min-w-0">
                                <Clock className={cn("absolute -bottom-4 h-28 w-28 text-amber-500/10 group-hover:scale-110 group-hover:-translate-y-2 group-hover:-translate-x-2 transition-all duration-500", isRTL ? "-left-4" : "-right-4")} />
                                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 truncate">{t('sales.metrics.conversionTime')}</p>
                                <p className="text-2xl font-bold mt-1 text-gray-900 dark:text-white truncate bidi-isolate">
                                    <span className="bidi-isolate">4.2</span> {isRTL ? 'أيام' : 'Days'}
                                </p>
                                <p className="text-[10px] text-amber-500 font-bold mt-1">{t('sales.metrics.conversionTimeDesc')}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <div className="flex flex-col gap-6">
                    {/* Filters */}
                    <Card className="border-none shadow-sm">
                        <CardContent className="p-4">
                            <div className="flex flex-col md:flex-row items-center gap-4">
                                <div className="flex-1 w-full relative">
                                    <Search className="absolute left-3 rtl:left-auto rtl:right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                    <Input
                                        placeholder={t('sales.filter.search')}
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                        className="pl-10 rtl:pl-4 rtl:pr-10"
                                    />
                                </div>
                                <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="w-full md:w-32">
                                    <option value="All Types">{t('sales.filter.allTypes')}</option>
                                    <option value="B2C">B2C</option>
                                    <option value="B2B">B2B</option>
                                </Select>
                                <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="w-full md:w-32">
                                    <option value="All Status">{t('sales.filter.allStatus')}</option>
                                    <option value="New">{t('sales.status.new')}</option>
                                    <option value="In Progress">{t('sales.status.inProgress')}</option>
                                    <option value="Quotation Sent">{t('sales.status.quotationSent')}</option>
                                    <option value="Won">{t('sales.status.won')}</option>
                                    <option value="Lost">{t('sales.status.lost')}</option>
                                </Select>
                            </div>
                        </CardContent>
                    </Card>

            {/* Table */}
            <div className="table-container">
                <table className="table-premium">
                    <thead>
                        <tr>
                            <th>{t('sales.table.caseId')}</th>
                            <th>{t('sales.table.customer')}</th>
                            <th>{t('sales.table.type')}</th>
                            <th>{t('sales.table.quotationInfo')}</th>
                            <th>{t('sales.table.status')}</th>
                            <th>{t('sales.table.assigned')}</th>
                            <th className="text-right rtl:text-left">{t('sales.table.actions')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredCases.map((c) => (
                            <tr key={c.id}>
                                <td>
                                    <div className="font-bold text-gray-900 dark:text-white bidi-isolate">{c.id}</div>
                                    <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest bidi-isolate">{formatDate(c.createdAt)}</div>
                                </td>
                                <td>
                                    <div className="text-sm font-medium">{c.customer}</div>
                                    <div className="text-[10px] text-gray-500 bidi-isolate">{c.customerEmail}</div>
                                </td>
                                <td>
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${c.type === 'B2B' ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-900/20' : 'bg-blue-50 text-blue-600 dark:bg-blue-900/20'}`}>
                                        {getLocalizedType(c.type)}
                                    </span>
                                </td>
                                <td>
                                    {(() => {
                                        const quotes = mockQuotations.filter(q => q.caseId === c.id);
                                        if (quotes.length === 0) return <span className="text-[10px] text-gray-400">{t('sales.table.noQuotes')}</span>;
                                        const latestQuote = quotes[quotes.length - 1];
                                        const latestVersion = latestQuote.versions[latestQuote.versions.length - 1];
                                        return (
                                            <div className="space-y-1">
                                                <div className="flex flex-col items-start gap-1">
                                                    <QuotationStatusBadge status={latestVersion.status} />
                                                    <span className="text-[10px] font-bold text-gray-900 dark:text-white bidi-isolate">{formatCurrency(latestVersion.pricing.totalSellingPrice)}</span>
                                                </div>
                                                <div className="text-[9px] text-gray-500">
                                                    {isRTL ? <><span className="bidi-isolate">{quotes.length}</span> {quotes.length > 1 ? t('sales.table.versions') : t('sales.table.version')}</> : <><span className="bidi-isolate">{quotes.length}</span> {quotes.length > 1 ? 'versions' : 'version'}</>}
                                                </div>
                                            </div>
                                        );
                                    })()}
                                </td>
                                <td>
                                    <span className={`badge-standard ${getStatusColor(c.status)}`}>{getStatusLabel(c.status)}</span>
                                </td>
                                <td><div className="text-xs font-bold">{isRTL && c.assignedAgent === 'Super Admin' ? 'المشرف العام' : c.assignedAgent}</div></td>
                                <td className="text-right rtl:text-left">
                                    <TableActionsDropdown
                                        actions={[
                                            { label: t('sales.tooltip.viewCase'), icon: Eye, onClick: () => navigate(`/sales/cases/${c.id}`) },
                                            { label: t('sales.tooltip.newQuotation'), icon: Plus, onClick: () => navigate(`/sales/cases/${c.id}/quotations/new`) },
                                            { label: t('sales.tooltip.internalNotes'), icon: FileText, onClick: () => navigate('/sales/notes', { state: { entity: c, entityType: 'Sales Case' } }) },
                                            { label: t('sales.tooltip.scheduleFollowUp'), icon: Calendar, onClick: () => navigate('/sales/schedule', { state: { entity: c, entityType: 'Sales Case' } }) }
                                        ]}
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        {/* Today's Tasks */}
            <Card className="border-none shadow-sm h-full">
                <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-amber-500" />
                            <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400">{t('sales.tasks.title')}</h3>
                        </div>
                        <Button variant="outline" size="sm" className="text-[10px] font-bold uppercase h-8" onClick={() => navigate('/sales/tasks')}>
                            {t('sales.tasks.manageAll')}
                        </Button>
                    </div>
                    <div className="space-y-4">
                        {tasks.length > 0 ? tasks.map((task, i) => (
                            <div key={i} className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg border border-transparent hover:border-blue-200 dark:hover:border-blue-900 transition-all cursor-pointer">
                                <div className="flex items-center justify-between mb-1">
                                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider ${task.priority === 'High' ? 'bg-rose-100 text-rose-600' : 'bg-blue-100 text-blue-600'}`}>
                                        {(() => {
                                            switch (task.priority) {
                                                case 'Critical': return isRTL ? 'حرجة' : 'Critical';
                                                case 'High': return isRTL ? 'مرتفعة' : 'High';
                                                case 'Medium': return isRTL ? 'متوسطة' : 'Medium';
                                                case 'Low': return isRTL ? 'منخفضة' : 'Low';
                                                default: return task.priority;
                                            }
                                        })()}
                                    </span>
                                    <span className="text-[9px] text-gray-500 font-medium bidi-isolate">{formatDate(task.dueDate)}</span>
                                </div>
                                <p className="text-xs font-bold text-gray-900 dark:text-white leading-tight">{task.title}</p>
                                <p className="text-[10px] text-gray-500 mt-1">{task.customer}</p>
                            </div>
                        )) : (
                            <div className="text-center py-12">
                                <p className="text-xs text-gray-400">{t('sales.tasks.noTasks')}</p>
                            </div>
                        )}
                    </div>
                </CardContent>
            </Card>

            {filteredCases.length === 0 && (
                <Card className="card-premium">
                    <CardContent className="p-12 text-center">
                        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-50 dark:bg-gray-800 mb-4 text-gray-400">
                            <BookOpen className="h-8 w-8" />
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white">{t('sales.empty.title')}</h3>
                        <p className="description-sm">{t('sales.empty.desc')}</p>
                    </CardContent>
                </Card>
            )}
            </div>
        </div>
    </div>
  );
};