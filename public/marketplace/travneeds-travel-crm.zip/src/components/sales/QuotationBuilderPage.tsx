import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
    ArrowLeft,
    ArrowRight,
    CalendarDays,
    Check,
    CheckCircle,
    Copy,
    DollarSign,
    FileText,
    Globe,
    Layout,
    List,
    Calculator,
    Save,
    Send,
    X,
    XCircle,
    RefreshCw,
    FileEdit,
    Paperclip,
    ShieldCheck,
    Trash2,
} from 'lucide-react';
import { Button } from '../ui/Button';
import { Card, CardContent } from '../ui/Card';
import { useToastContext } from '../../contexts/ToastContext';
import { mockCases, mockQuotations } from '../../services/mockData';
import type { QuotationApprovalReview, QuotationAttachment, QuotationStatus, QuotationVersion } from '../../types/quotation';
import {
    buildCostSummaryFromServiceLines,
    buildProfitAnalysis,
    calculatePricingFromServiceLines
} from '../../utils/quotationCalculations';
import { QuotationBasicInfoStep } from './QuotationBasicInfoStep';
import { ProgramOverviewStep } from './ProgramOverviewStep';
import { InclusionsExclusionsStep } from './InclusionsExclusionsStep';
import { ItineraryBuilderStep } from './ItineraryBuilderStep';
import { CostingStep } from './CostingStep';
import { PricingStep } from './PricingStep';
import { useLocale } from '../../localization/useLocale';

const LAST_DRAFT_KEY = 'travneeds_quote_draft:last';

interface PreviewDraftPayload {
    quotationId: string;
    caseId: string;
    reference: string;
    currentVersion: number;
    version: QuotationVersion;
}

export const QuotationBuilderPage: React.FC = () => {
    const { t, isRTL } = useLocale();
    const { caseId, quotationId } = useParams<{ caseId: string; quotationId?: string }>();
    const navigate = useNavigate();
    const toast = useToastContext();
    const [step, setStep] = useState(1);
    const [saveDraftNotice, setSaveDraftNotice] = useState('');
    const salesCase = mockCases.find(c => c.id === caseId);

    const [quoteData, setQuoteData] = useState<QuotationVersion>(() => {
        if (quotationId) {
            const quotation = mockQuotations.find(q => q.id === quotationId);
            if (quotation?.versions.length) {
                const version = JSON.parse(JSON.stringify(quotation.versions[quotation.versions.length - 1])) as QuotationVersion;
                return {
                    ...version,
                    serviceLines: version.serviceLines || [],
                    activity: version.activity || [],
                    proposalLogs: version.proposalLogs || [],
                    attachments: version.attachments || [],
                    approvalReviews: version.approvalReviews || [],
                    pdfTemplate: version.pdfTemplate || 'Classic'
                };
            }
        }

        const today = new Date().toISOString().split('T')[0];
        return {
            id: `QUO-V1-${Date.now()}`,
            versionNumber: 1,
            status: 'Draft',
            preparedBy: 'Current User',
            preparedDate: today,
            expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            customerInfo: {
                customerName: salesCase?.customer || '',
                email: salesCase?.customerEmail || '',
                phone: '',
                nationality: '',
                groupType: 'FIT',
                pax: { adults: 2, children: 0, infants: 0, total: 2, arrival: '', departure: '', nights: 0 }
            },
            programOverview: {
                title: '',
                packageCode: `PKG-${Date.now().toString().slice(-4)}`,
                packageType: 'Classic',
                destinations: [],
                citiesCovered: [],
                nights: 0,
                season: 'Normal',
                description: '',
                highlights: []
            },
            inclusions: [],
            exclusions: [],
            itinerary: [],
            costing: [],
            serviceLines: [],
            costSummary: {
                totalDirectCost: 0,
                taxesAndFees: 0,
                adjustments: 0,
                groupTotalCost: 0,
                perPersonCost: 0,
                byCategory: {},
                bySupplier: {},
                byDay: {}
            },
            pricing: {
                totalAccommodationCost: 0,
                totalSightseeingCost: 0,
                totalTransferCost: 0,
                totalMealsCost: 0,
                totalServiceCost: 0,
                totalOptionalCost: 0,
                grandTotalCost: 0,
                costPerPerson: 0,
                markupType: 'Percentage',
                markupValue: 15,
                profitAmount: 0,
                totalSellingPrice: 0,
                sellingPricePerPerson: 0,
                currency: 'USD',
                exchangeRate: 1,
                discountAmount: 0,
                commissionAmount: 0,
                manualOverride: false,
                manualSellingPrice: 0
            },
            profitAnalysis: {
                totalCost: 0,
                totalSelling: 0,
                grossProfit: 0,
                marginPercent: 0,
                markupPercent: 0,
                breakEvenPrice: 0,
                highRiskSupplierWarnings: [],
                profitByService: [],
                profitByCategory: {},
                profitBySupplier: {}
            },
            activity: [{ id: `QA-${Date.now()}`, type: 'Created', message: 'Quotation draft initialized locally.', date: today, user: 'Current User' }],
            proposalLogs: [],
            attachments: [],
            approvalReviews: [],
            pdfTemplate: 'Classic',
            terms: '1. All prices are subject to change until booking is confirmed.\n2. Payment terms as per contract.'
        };
    });
    const [attachmentDraft, setAttachmentDraft] = useState({ fileName: '', type: 'Supplier Confirmation', visibility: 'Internal', notes: '' });
    const [approvalDraft, setApprovalDraft] = useState({ reviewer: 'Sales Manager', status: 'Pending', comment: '' });

    const updateQuoteData = (updates: Partial<QuotationVersion>) => {
        setQuoteData(prev => ({ ...prev, ...updates }));
    };

    const buildFinalQuoteData = (source: QuotationVersion, statusOverride?: QuotationStatus): QuotationVersion => {
        const paxCount = source.customerInfo.pax.total || 1;
        const serviceLines = source.serviceLines || [];

        if (!serviceLines.length) {
            return {
                ...source,
                status: statusOverride || source.status
            };
        }

        const pricing = calculatePricingFromServiceLines(
            serviceLines,
            source.pricing.markupType,
            source.pricing.markupValue,
            paxCount,
            source.pricing.currency,
            source.pricing.exchangeRate,
            source.pricing.discountAmount || 0,
            source.pricing.commissionAmount || 0,
            source.pricing.manualOverride || false,
            source.pricing.manualSellingPrice || 0,
            source.fixedCosts
        );

        return {
            ...source,
            status: statusOverride || source.status,
            costSummary: buildCostSummaryFromServiceLines(serviceLines, paxCount, source.fixedCosts),
            pricing,
            profitAnalysis: buildProfitAnalysis(serviceLines, pricing)
        };
    };

    const addLocalLog = (source: QuotationVersion, type: string, message: string, status: QuotationStatus = source.status): QuotationVersion => {
        const date = new Date().toISOString().split('T')[0];

        return {
            ...source,
            activity: [{ id: `QA-${Date.now()}`, type, message, date, user: 'Current User' }, ...(source.activity || [])],
            proposalLogs: [{ id: `PL-${Date.now()}`, action: type, status, date, note: message }, ...(source.proposalLogs || [])]
        };
    };

    const getDraftStorageKey = (draftId: string) => `travneeds_quote_draft:${caseId}:${draftId}`;

    const persistDraft = (version: QuotationVersion): PreviewDraftPayload => {
        const draftId = version.id || quotationId || `LOCAL-${caseId}`;
        const payload: PreviewDraftPayload = {
            quotationId: draftId,
            caseId: caseId || salesCase?.id || '',
            reference: quotationId || `LOCAL-${salesCase?.id || caseId || 'CASE'}`,
            currentVersion: version.versionNumber,
            version
        };

        try {
            const storageKey = getDraftStorageKey(draftId);
            sessionStorage.setItem(storageKey, JSON.stringify(payload));
            sessionStorage.setItem(LAST_DRAFT_KEY, storageKey);
        } catch {
            // Preview also receives the payload through route state; storage is a session backup only.
        }

        return payload;
    };

    const finalizeAndPersistDraft = (statusOverride?: QuotationStatus, log?: { type: string; message: string; status?: QuotationStatus }) => {
        const finalized = buildFinalQuoteData(quoteData, statusOverride);
        const withLog = log ? addLocalLog(finalized, log.type, log.message, log.status || finalized.status) : finalized;
        setQuoteData(withLog);
        return persistDraft(withLog);
    };

    const handlePreviewProposal = () => {
        const payload = finalizeAndPersistDraft(undefined, {
            type: 'Preview',
            message: 'Proposal preview opened from current local draft.'
        });
        navigate(`/sales/cases/${caseId}/quotations/${payload.quotationId}/preview`, {
            state: { draft: payload, draftKey: getDraftStorageKey(payload.quotationId) }
        });
    };

    const appendLog = (type: string, message: string, status: QuotationStatus = quoteData.status) => {
        const date = new Date().toISOString().split('T')[0];
        setQuoteData(prev => ({
            ...prev,
            activity: [{ id: `QA-${Date.now()}`, type, message, date, user: 'Current User' }, ...(prev.activity || [])],
            proposalLogs: [{ id: `PL-${Date.now()}`, action: type, status, date, note: message }, ...(prev.proposalLogs || [])]
        }));
    };

    const setQuoteStatus = (status: QuotationStatus) => {
        setQuoteData(prev => addLocalLog(buildFinalQuoteData(prev, status), 'Status', `Quotation marked as ${status}.`, status));
        toast.success(t('quotation.builder.toast.statusUpdated'), t('quotation.builder.toast.statusUpdatedDesc').replace('{status}', status));
    };

    const duplicateVersion = () => {
        const date = new Date().toISOString().split('T')[0];
        setQuoteData(prev => ({
            ...buildFinalQuoteData(prev, 'Revised'),
            id: `QUO-V${prev.versionNumber + 1}-${Date.now()}`,
            versionNumber: prev.versionNumber + 1,
            status: 'Revised',
            activity: [{ id: `QA-${Date.now()}`, type: 'Version', message: `Duplicated to version ${prev.versionNumber + 1}.`, date, user: 'Current User' }, ...(prev.activity || [])],
            proposalLogs: [{ id: `PL-${Date.now()}`, action: 'Duplicate Version', status: 'Revised', date, note: `Created version ${prev.versionNumber + 1} locally.` }, ...(prev.proposalLogs || [])]
        }));
        toast.success(t('quotation.builder.toast.versionDuplicated'), t('quotation.builder.toast.versionDuplicatedDesc'));
    };

    const addAttachment = () => {
        if (!attachmentDraft.fileName.trim()) return;
        const uploadedAt = new Date().toISOString().split('T')[0];
        const attachment: QuotationAttachment = {
            id: `ATT-${Date.now()}`,
            fileName: attachmentDraft.fileName.trim(),
            type: attachmentDraft.type,
            status: 'Attached',
            uploadedAt,
            visibility: attachmentDraft.visibility as QuotationAttachment['visibility'],
            notes: attachmentDraft.notes.trim() || undefined
        };
        setQuoteData(prev => ({
            ...prev,
            attachments: [attachment, ...(prev.attachments || [])],
            activity: [{ id: `QA-${Date.now()}`, type: 'Attachment', message: `${attachment.fileName} attached to quote.`, date: uploadedAt, user: 'Current User' }, ...(prev.activity || [])]
        }));
        setAttachmentDraft({ fileName: '', type: 'Supplier Confirmation', visibility: 'Internal', notes: '' });
    };

    const updateAttachmentStatus = (attachmentId: string, status: QuotationAttachment['status']) => {
        setQuoteData(prev => ({
            ...prev,
            attachments: (prev.attachments || []).map(attachment => attachment.id === attachmentId ? { ...attachment, status } : attachment)
        }));
    };

    const addApprovalReview = () => {
        if (!approvalDraft.comment.trim()) return;
        const date = new Date().toISOString().split('T')[0];
        const review: QuotationApprovalReview = {
            id: `APR-${Date.now()}`,
            reviewer: approvalDraft.reviewer,
            status: approvalDraft.status as QuotationApprovalReview['status'],
            date,
            comment: approvalDraft.comment.trim()
        };
        const nextStatus: QuotationStatus = review.status === 'Approved' ? 'Approved' : review.status === 'Rejected' ? 'Rejected' : quoteData.status;
        setQuoteData(prev => ({
            ...addLocalLog(buildFinalQuoteData(prev, nextStatus), 'Approval Review', `${review.reviewer}: ${review.comment}`, nextStatus),
            approvalReviews: [review, ...(prev.approvalReviews || [])]
        }));
        setApprovalDraft({ reviewer: 'Sales Manager', status: 'Pending', comment: '' });
    };

    const handleSaveDraft = () => {
        finalizeAndPersistDraft('Draft', {
            type: 'Draft Saved',
            message: 'Draft saved in this browser session.',
            status: 'Draft'
        });
        setSaveDraftNotice(t('quotation.builder.draftSavedNotice'));
        toast.success(t('quotation.builder.toast.draftSaved'), t('quotation.builder.toast.draftSavedDesc'));
    };

    const validateStep = (currentStep: number) => {
        if (currentStep === 1 && !quoteData.customerInfo.customerName) {
            toast.error(t('quotation.builder.toast.validationError'), t('quotation.builder.toast.customerNameRequired'));
            return false;
        }
        if (currentStep === 2 && !quoteData.programOverview.title) {
            toast.error(t('quotation.builder.toast.validationError'), t('quotation.builder.toast.packageTitleRequired'));
            return false;
        }
        return true;
    };

    const handleNext = () => {
        if (validateStep(step)) {
            setStep(current => Math.min(current + 1, 7));
            window.scrollTo(0, 0);
        }
    };

    const handlePrev = () => {
        setStep(current => Math.max(current - 1, 1));
        window.scrollTo(0, 0);
    };

    if (!salesCase) {
        return (
            <div className="page-container py-20 text-center">
                <h2 className="text-xl font-bold">{t('quotation.builder.caseNotFound')}</h2>
                <Button variant="outline" className="mt-4" onClick={() => navigate('/sales')}>{t('quotation.builder.backToSales')}</Button>
            </div>
        );
    }

    const steps = [
        { icon: FileText, label: t('quotation.steps.basicInfo') },
        { icon: Globe, label: t('quotation.steps.program') },
        { icon: List, label: t('quotation.steps.inclusions') },
        { icon: CalendarDays, label: t('quotation.steps.itinerary') },
        { icon: Calculator, label: t('quotation.steps.costing') },
        { icon: DollarSign, label: t('quotation.steps.pricing') },
        { icon: Layout, label: t('quotation.steps.preview') }
    ];

    const renderStepContent = () => {
        switch (step) {
            case 1: return <QuotationBasicInfoStep data={quoteData} updateData={updateQuoteData} />;
            case 2: return <ProgramOverviewStep data={quoteData} updateData={updateQuoteData} />;
            case 3: return <InclusionsExclusionsStep data={quoteData} updateData={updateQuoteData} />;
            case 4: return <ItineraryBuilderStep data={quoteData} updateData={updateQuoteData} />;
            case 5: return <CostingStep data={quoteData} updateData={updateQuoteData} />;
            case 6: return <PricingStep data={quoteData} updateData={updateQuoteData} />;
            case 7:
                return (
                    <div className="space-y-6">
                        <div className="space-y-4 py-10 text-center">
                            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20">
                                <Check className="h-10 w-10" />
                            </div>
                            <h2 className="text-2xl font-bold">{t('quotation.builder.readyToReview')}</h2>
                            <p className="mx-auto max-w-md text-gray-500">{t('quotation.builder.readyToReviewDesc')}</p>
                        </div>
                        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                            <LogCard title={t('quotation.builder.activityLog')} rows={(quoteData.activity || []).map(row => ({ id: row.id, title: row.type, body: `${row.message} - ${row.date}` }))} empty={t('quotation.builder.noActivity')} />
                            <LogCard title={t('quotation.builder.proposalLog')} rows={(quoteData.proposalLogs || []).map(row => ({ id: row.id, title: `${row.action} - ${row.status}`, body: `${row.note} - ${row.date}` }))} empty={t('quotation.builder.noProposalLogs')} />
                        </div>
                        <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
                            <Card>
                                <CardContent className="space-y-4 p-4">
                                    <div className="flex items-center gap-2">
                                        <Paperclip className="h-4 w-4 text-blue-600" />
                                        <h3 className="font-bold">Quote Documents & Attachments</h3>
                                    </div>
                                    <div className="grid grid-cols-1 gap-2 lg:grid-cols-4">
                                        <input className="rounded-md border border-gray-300 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-800" placeholder="File name" value={attachmentDraft.fileName} onChange={(event) => setAttachmentDraft(prev => ({ ...prev, fileName: event.target.value }))} />
                                        <select className="rounded-md border border-gray-300 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-800" value={attachmentDraft.type} onChange={(event) => setAttachmentDraft(prev => ({ ...prev, type: event.target.value }))}>
                                            <option>Supplier Confirmation</option>
                                            <option>Passport Copy</option>
                                            <option>Visa Document</option>
                                            <option>Payment Proof</option>
                                            <option>Proposal PDF</option>
                                            <option>Other</option>
                                        </select>
                                        <select className="rounded-md border border-gray-300 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-800" value={attachmentDraft.visibility} onChange={(event) => setAttachmentDraft(prev => ({ ...prev, visibility: event.target.value }))}>
                                            <option>Internal</option>
                                            <option>Client</option>
                                        </select>
                                        <Button onClick={addAttachment}><Paperclip className="h-4 w-4" />Attach</Button>
                                    </div>
                                    <div className="space-y-2">
                                        {(quoteData.attachments || []).map(attachment => (
                                            <div key={attachment.id} className="flex flex-col gap-2 rounded border border-gray-100 p-3 text-sm dark:border-gray-800 sm:flex-row sm:items-center sm:justify-between">
                                                <div>
                                                    <div className="font-semibold">{attachment.fileName}</div>
                                                    <div className="text-xs text-gray-500">{attachment.type} - {attachment.visibility} - {attachment.uploadedAt}</div>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <select className="rounded border border-gray-200 px-2 py-1 text-xs dark:border-gray-700 dark:bg-gray-800" value={attachment.status} onChange={(event) => updateAttachmentStatus(attachment.id, event.target.value as QuotationAttachment['status'])}>
                                                        <option>Draft</option>
                                                        <option>Attached</option>
                                                        <option>Verified</option>
                                                        <option>Rejected</option>
                                                    </select>
                                                    <button className="rounded p-1 text-rose-600 hover:bg-rose-50" onClick={() => updateQuoteData({ attachments: (quoteData.attachments || []).filter(item => item.id !== attachment.id) })}><Trash2 className="h-4 w-4" /></button>
                                                </div>
                                            </div>
                                        ))}
                                        {(quoteData.attachments || []).length === 0 && <div className="text-sm text-gray-500">No quotation documents attached yet.</div>}
                                    </div>
                                </CardContent>
                            </Card>

                            <Card>
                                <CardContent className="space-y-4 p-4">
                                    <div className="flex items-center gap-2">
                                        <ShieldCheck className="h-4 w-4 text-emerald-600" />
                                        <h3 className="font-bold">Approval Workflow & PDF Template</h3>
                                    </div>
                                    <div className="grid grid-cols-1 gap-2 lg:grid-cols-3">
                                        <select className="rounded-md border border-gray-300 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-800" value={quoteData.pdfTemplate || 'Classic'} onChange={(event) => updateQuoteData({ pdfTemplate: event.target.value as QuotationVersion['pdfTemplate'] })}>
                                            <option>Classic</option>
                                            <option>Modern</option>
                                            <option>Corporate</option>
                                        </select>
                                        <select className="rounded-md border border-gray-300 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-800" value={approvalDraft.status} onChange={(event) => setApprovalDraft(prev => ({ ...prev, status: event.target.value }))}>
                                            <option>Pending</option>
                                            <option>Approved</option>
                                            <option>Rejected</option>
                                            <option>Changes Requested</option>
                                        </select>
                                        <input className="rounded-md border border-gray-300 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-800" value={approvalDraft.reviewer} onChange={(event) => setApprovalDraft(prev => ({ ...prev, reviewer: event.target.value }))} />
                                    </div>
                                    <textarea className="min-h-20 w-full rounded-md border border-gray-300 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-800" placeholder="Approval comment" value={approvalDraft.comment} onChange={(event) => setApprovalDraft(prev => ({ ...prev, comment: event.target.value }))} />
                                    <Button onClick={addApprovalReview}><ShieldCheck className="h-4 w-4" />Log Review</Button>
                                    <div className="space-y-2">
                                        {(quoteData.approvalReviews || []).map(review => (
                                            <div key={review.id} className="rounded border border-gray-100 p-3 text-sm dark:border-gray-800">
                                                <div className="font-semibold">{review.reviewer} - {review.status}</div>
                                                <div className="text-xs text-gray-500">{review.comment} - {review.date}</div>
                                            </div>
                                        ))}
                                        {(quoteData.approvalReviews || []).length === 0 && <div className="text-sm text-gray-500">No approval reviews logged yet.</div>}
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </div>
                );
            default: return null;
        }
    };

    const margin = quoteData.profitAnalysis?.marginPercent || 0;
    const travelDates = [quoteData.customerInfo.pax.arrival, quoteData.customerInfo.pax.departure].filter(Boolean).join(` ${t('common.to')} `) || t('quotation.builder.notSet');

    return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="mb-6 flex flex-col gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 xl:flex-row xl:items-center xl:justify-between">
                    <div className="flex min-w-0 items-center gap-4">
                        <div className="rounded-full bg-white/10 p-3 text-white">
                             <FileText className="h-6 w-6" />
                        </div>
                        <div className="min-w-0">
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">{quotationId ? t('quotation.builder.title.edit') : t('quotation.builder.title.new')}</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">{t('quotation.builder.case')}: {salesCase.id} - {salesCase.customer}</p>
                        </div>
                    </div>
                    <div className="flex flex-col gap-2 xl:items-end">
                        <div className="flex flex-wrap gap-2">
                            <Button title={t('quotation.builder.cancel')} variant="outline" size="sm" className="bg-white/10 text-white border-transparent hover:bg-white/20 h-9 w-9 !p-0 shrink-0" onClick={() => navigate(`/sales/cases/${caseId}`)}><X className="h-4 w-4" /></Button>
                            <Button title={t('quotation.builder.preview')} variant="outline" size="sm" className="bg-white/10 text-white border-transparent hover:bg-white/20 h-9 w-9 !p-0 shrink-0" onClick={handlePreviewProposal}>
                                <FileText className="h-4 w-4" />
                            </Button>
                            <Button title={t('quotation.builder.duplicate')} variant="outline" size="sm" className="bg-white/10 text-white border-transparent hover:bg-white/20 h-9 w-9 !p-0 shrink-0" onClick={duplicateVersion}><Copy className="h-4 w-4" /></Button>
                            <Button title={t('quotation.builder.markDraft')} variant="outline" size="sm" className="bg-white/10 text-white border-transparent hover:bg-white/20 h-9 w-9 !p-0 shrink-0" onClick={() => setQuoteStatus('Draft')}><FileEdit className="h-4 w-4" /></Button>
                            <Button title={t('quotation.builder.markSent')} variant="outline" size="sm" className="bg-white/10 text-white border-transparent hover:bg-white/20 h-9 w-9 !p-0 shrink-0" onClick={() => setQuoteStatus('Sent')}><Send className="h-4 w-4" /></Button>
                            <Button title={t('quotation.builder.approve')} variant="outline" size="sm" className="bg-white/10 text-white border-transparent hover:bg-white/20 h-9 w-9 !p-0 shrink-0" onClick={() => setQuoteStatus('Approved')}><CheckCircle className="h-4 w-4" /></Button>
                            <Button title={t('quotation.builder.reject')} variant="outline" size="sm" className="bg-white/10 text-white border-transparent hover:bg-white/20 h-9 w-9 !p-0 shrink-0" onClick={() => setQuoteStatus('Rejected')}><XCircle className="h-4 w-4" /></Button>
                            <Button title={t('quotation.builder.convertMock')} variant="outline" size="sm" className="bg-white/10 text-white border-transparent hover:bg-white/20 h-9 w-9 !p-0 shrink-0" onClick={() => appendLog('Reservation', 'Mock conversion to reservation logged.', quoteData.status)}><RefreshCw className="h-4 w-4" /></Button>
                            <Button title={t('quotation.builder.saveDraft')} size="sm" className="bg-white text-blue-600 hover:bg-gray-50 h-9 w-9 !p-0 shrink-0" onClick={handleSaveDraft}><Save className="h-4 w-4" /></Button>
                        </div>
                    {saveDraftNotice && (
                        <div role="status" aria-live="polite" className="rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-700">
                            {saveDraftNotice}
                        </div>
                    )}
                </div>
            </div>

            <div className="mb-6 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
                <SummaryCard label={t('quotation.builder.statusVersion')} value={`${quoteData.status} - v${quoteData.versionNumber}`} />
                <SummaryCard label={t('quotation.builder.package')} value={quoteData.programOverview.title || t('quotation.builder.untitledPackage')} />
                <SummaryCard label={t('quotation.builder.travelDates')} value={travelDates} />
                <SummaryCard label={t('quotation.builder.travelers')} value={`${quoteData.customerInfo.pax.total} ${t('quotation.builder.pax')}`} />
                <SummaryCard label={t('quotation.builder.currency')} value={quoteData.pricing.currency} />
                <SummaryCard label={t('quotation.builder.assignedSales')} value={quoteData.preparedBy || 'Current User'} />
                <SummaryCard label={t('quotation.builder.grossProfit')} value={`$${quoteData.pricing.profitAmount.toLocaleString()}`} tone="green" />
                <SummaryCard label={t('quotation.builder.margin')} value={`${margin}%`} tone={margin > 0 && margin < 15 ? 'red' : 'green'} />
            </div>

            <div className="mb-8 overflow-x-auto rounded-xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
                <div className="flex min-w-[760px] items-center justify-between">
                    {steps.map((item, index) => {
                        const stepNum = index + 1;
                        const Icon = item.icon;
                        const isActive = step === stepNum;
                        const isCompleted = step > stepNum;
                        return (
                            <React.Fragment key={item.label}>
                                <button type="button" onClick={() => setStep(stepNum)} className="relative z-10 flex flex-col items-center">
                                    <div className={`flex h-10 w-10 items-center justify-center rounded-full border-2 transition-all ${isActive ? 'scale-110 border-blue-500 bg-blue-50 text-blue-600' : isCompleted ? 'border-emerald-500 bg-emerald-50 text-emerald-600' : 'border-gray-200 text-gray-400'}`}>
                                        {isCompleted ? <Check className="h-5 w-5" /> : <Icon className="h-5 w-5" />}
                                    </div>
                                    <span className={`mt-2 whitespace-nowrap text-center text-[10px] font-bold uppercase tracking-wider ${isActive ? 'text-blue-600' : isCompleted ? 'text-emerald-600' : 'text-gray-400'}`}>{item.label}</span>
                                </button>
                                {index < steps.length - 1 && <div className={`mx-4 mb-6 h-0.5 flex-1 ${step > stepNum ? 'bg-emerald-500' : 'bg-gray-200'}`} />}
                            </React.Fragment>
                        );
                    })}
                </div>
            </div>

            <Card className="card-premium">
                <CardContent className="p-4 sm:p-8">{renderStepContent()}</CardContent>
            </Card>

            <div className={`fixed bottom-0 left-0 right-0 z-40 border-t border-gray-200 bg-white/80 p-4 backdrop-blur-md dark:border-gray-800 dark:bg-gray-900/80 ${isRTL ? 'lg:right-64 lg:left-0' : 'lg:left-64'}`}>
                <div className="mx-auto flex max-w-5xl items-center justify-between px-4">
                    <Button variant="outline" onClick={handlePrev} disabled={step === 1} className="min-w-[120px]">
                        {isRTL ? <ArrowRight className="ml-2 h-4 w-4" /> : <ArrowLeft className="mr-2 h-4 w-4" />}{t('quotation.builder.previous')}
                    </Button>
                    <div className="hidden flex-col items-center sm:flex">
                        <div className="text-[10px] font-bold uppercase text-gray-400">
                            {t('quotation.builder.stepOf').replace('{step}', step.toString())}
                        </div>
                        <div className="text-xs font-medium text-gray-700 dark:text-gray-300">{steps[step - 1].label}</div>
                    </div>
                    {step < 7 ? (
                        <Button onClick={handleNext} className="min-w-[120px]">
                            {t('quotation.builder.nextStep')}{isRTL ? <ArrowLeft className="mr-2 h-4 w-4" /> : <ArrowRight className="ml-2 h-4 w-4" />}
                        </Button>
                    ) : (
                        <Button onClick={handlePreviewProposal} className="min-w-[120px]">
                            {t('quotation.builder.reviewQuote')}<Check className={`${isRTL ? 'mr-2' : 'ml-2'} h-4 w-4`} />
                        </Button>
                    )}
                </div>
            </div>
            </div>
        </div>
    );
};

const SummaryCard: React.FC<{ label: string; value: string; tone?: 'green' | 'red' | 'default' }> = ({ label, value, tone = 'default' }) => (
    <Card>
        <CardContent className="p-4">
            <div className="text-xs font-bold uppercase tracking-wide text-gray-500">{label}</div>
            <div className={`mt-1 break-words text-lg font-bold bidi-isolate ${tone === 'green' ? 'text-emerald-600' : tone === 'red' ? 'text-rose-600' : 'text-gray-900 dark:text-white'}`}>{value}</div>
        </CardContent>
    </Card>
);

const LogCard: React.FC<{ title: string; rows: Array<{ id: string; title: string; body: string }>; empty?: string }> = ({ title, rows, empty = 'No activity yet.' }) => (
    <Card>
        <CardContent className="p-4">
            <h3 className="mb-3 font-bold">{title}</h3>
            <div className="space-y-2">
                {rows.map(row => (
                    <div key={row.id} className="rounded border border-gray-100 p-2 text-sm">
                        <div className="font-semibold">{row.title}</div>
                        <div className="text-xs text-gray-500">{row.body}</div>
                    </div>
                ))}
                {rows.length === 0 && <div className="text-sm text-gray-500">{empty}</div>}
            </div>
        </CardContent>
    </Card>
);
