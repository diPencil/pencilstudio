import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Edit, Eye, FileText, LayoutDashboard, MessageSquare, Plus, Printer, Target, Download, CheckCircle, Clock, Info } from 'lucide-react';
import { PageHeader } from '../ui/PageHeader';
import { Button } from '../ui/Button';
import { Card, CardContent } from '../ui/Card';
import { mockCases, mockQuotations } from '../../services/mockData';
import { QuotationStatusBadge } from './QuotationStatusBadge';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { formatDate, formatCurrency } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

export const CaseDetailsPage: React.FC = () => {
    const { caseId } = useParams<{ caseId: string }>();
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState<'info' | 'quotations' | 'activity'>('info');
    const { t, isRTL, direction } = useLocale();

    const salesCase = mockCases.find(c => c.id === caseId);
    const relatedQuotations = mockQuotations.filter(q => q.caseId === caseId);

    const getStatusLabel = (status: string) => {
        switch (status) {
            case 'New': return t('sales.status.new');
            case 'In Progress': return t('sales.status.inProgress');
            case 'Awaiting Reply': return t('sales.status.awaitingReply');
            case 'Quotation Sent': return t('sales.status.quotationSent');
            case 'Won': return t('sales.status.won');
            case 'Lost': return t('sales.status.lost');
            default: return status;
        }
    };

    const getLocalizedType = (type: string) => {
        if (type === 'B2C') return isRTL ? 'B2C (أفراد)' : 'B2C';
        if (type === 'B2B') return isRTL ? 'B2B (شركات)' : 'B2B';
        return type;
    };

    if (!salesCase) {
        return (
            <div className="page-container flex flex-col items-center justify-center py-20">
                <div className="bg-red-50 dark:bg-red-900/20 p-6 rounded-full mb-4">
                    <Info className="h-12 w-12 text-red-500" />
                </div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">{t('sales.case.notFound')}</h2>
                <p className="text-gray-500 mt-2 bidi-isolate">{t('sales.case.notFoundDesc').replace('{caseId}', caseId || '')}</p>
                <Button variant="outline" className="mt-6" onClick={() => navigate('/sales')}>
                    {t('sales.case.backToPipeline')}
                </Button>
            </div>
        );
    }

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
                    <div>
                        <h1 className="text-2xl font-bold text-white mb-1">{t('sales.case.titlePrefix').replace('{id}', salesCase.id)}</h1>
                        <p className="text-blue-100 font-medium">{t('sales.case.description').replace('{customer}', salesCase.customer)}</p>
                    </div>
                    <div className={cn("flex gap-2", isRTL && "flex-row-reverse")}>
                        <Button variant="outline" className="bg-white/10 text-white border-white/20 hover:bg-white/20" onClick={() => navigate('/sales')}>
                            <ArrowLeft className={cn("h-4 w-4", isRTL ? 'ml-2 rotate-180' : 'mr-2')} />
                            {t('sales.case.back')}
                        </Button>
                        <Button className="bg-white text-blue-600 hover:bg-blue-50" onClick={() => navigate(`/sales/cases/${caseId}/quotations/new`)}>
                            <Plus className={cn("h-4 w-4", isRTL ? 'ml-2' : 'mr-2')} />
                            {t('sales.case.newQuotation')}
                        </Button>
                    </div>
                </div>

            {/* Tabs Navigation */}
            <div className="flex border-b border-gray-200 dark:border-gray-700 mb-6">
                <button
                    onClick={() => setActiveTab('info')}
                    className={`px-6 py-3 text-sm font-bold uppercase tracking-widest transition-colors border-b-2 ${activeTab === 'info' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
                >
                    {t('sales.case.tabInfo')}
                </button>
                <button
                    onClick={() => setActiveTab('quotations')}
                    className={`px-6 py-3 text-sm font-bold uppercase tracking-widest transition-colors border-b-2 ${activeTab === 'quotations' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
                >
                    {t('sales.case.tabQuotations')} <span className="bidi-isolate">({relatedQuotations.length})</span>
                </button>
                <button
                    onClick={() => setActiveTab('activity')}
                    className={`px-6 py-3 text-sm font-bold uppercase tracking-widest transition-colors border-b-2 ${activeTab === 'activity' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
                >
                    {t('sales.case.tabActivity')}
                </button>
            </div>

            {/* Tab Content */}
            <div className="space-y-6">
                {activeTab === 'info' && (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <Card className="lg:col-span-2 card-premium">
                            <CardContent className="p-6">
                                <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">{t('sales.case.customerInfo')}</h3>
                                <div className="grid grid-cols-2 gap-6">
                                    <div>
                                        <label className="label-xs text-gray-400 uppercase tracking-widest">{t('sales.case.customerName')}</label>
                                        <p className="font-bold text-gray-900 dark:text-white">{salesCase.customer}</p>
                                    </div>
                                    <div>
                                        <label className="label-xs text-gray-400 uppercase tracking-widest">{t('sales.case.email')}</label>
                                        <p className="text-sm bidi-isolate">{salesCase.customerEmail}</p>
                                    </div>
                                    <div>
                                        <label className="label-xs text-gray-400 uppercase tracking-widest">{t('sales.case.type')}</label>
                                        <p className="text-sm font-bold text-blue-600">{getLocalizedType(salesCase.type)}</p>
                                    </div>
                                    <div>
                                        <label className="label-xs text-gray-400 uppercase tracking-widest">{t('sales.case.estimatedValue')}</label>
                                        <p className="text-sm font-bold text-emerald-600 bidi-isolate">{formatCurrency(salesCase.value)}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                        <Card className="card-premium">
                            <CardContent className="p-6">
                                <h3 className="text-lg font-bold mb-4 text-gray-900 dark:text-white">{t('sales.case.statusAssignment')}</h3>
                                <div className="space-y-4">
                                    <div>
                                        <label className="label-xs text-gray-400 uppercase tracking-widest block mb-1">{t('sales.case.pipelineStatus')}</label>
                                        <span className="badge-standard bg-blue-50 text-blue-600">{getStatusLabel(salesCase.status)}</span>
                                    </div>
                                    <div>
                                        <label className="label-xs text-gray-400 uppercase tracking-widest block mb-1">{t('sales.case.assignedAgent')}</label>
                                        <p className="font-bold">{salesCase.assignedAgent}</p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                )}

                {activeTab === 'quotations' && (
                    <div className="space-y-4">
                        {relatedQuotations.length > 0 ? (
                            <div className="table-container">
                                <table className="table-premium">
                                    <thead>
                                        <tr>
                                            <th>{t('sales.case.colReference')}</th>
                                            <th>{t('sales.case.colProgram')}</th>
                                            <th>{t('sales.case.colPax')}</th>
                                            <th>{t('sales.case.colAmount')}</th>
                                            <th>{t('sales.case.colVersion')}</th>
                                            <th>{t('sales.case.colStatus')}</th>
                                            <th className={isRTL ? "text-left" : "text-right"}>{t('sales.case.colActions')}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {relatedQuotations.map((q) => {
                                            const latestVersion = q.versions[q.versions.length - 1];
                                            return (
                                                <tr key={q.id}>
                                                    <td>
                                                        <div className="font-bold text-gray-900 dark:text-white bidi-isolate">{q.reference}</div>
                                                        <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest bidi-isolate">{formatDate(q.createdAt)}</div>
                                                    </td>
                                                    <td>
                                                        <div className="text-xs font-bold text-gray-900 dark:text-white">{latestVersion.programOverview.title}</div>
                                                        <div className="text-[10px] text-gray-500">{latestVersion.programOverview.nights} {isRTL ? 'ليالي' : 'Nights'} | <span className="bidi-isolate">{latestVersion.programOverview.destinations.join(', ')}</span></div>
                                                    </td>
                                                    <td><div className="text-xs font-bold">{latestVersion.customerInfo.groupType}</div></td>
                                                    <td><div className="text-xs font-bold text-emerald-600 bidi-isolate">{formatCurrency(latestVersion.pricing.totalSellingPrice)}</div></td>
                                                    <td><span className="px-2 py-0.5 bg-gray-100 dark:bg-gray-800 rounded text-[10px] font-bold bidi-isolate">V{q.currentVersion}</span></td>
                                                    <td><QuotationStatusBadge status={latestVersion.status} /></td>
                                                    <td className={isRTL ? "text-left" : "text-right"}>
                                                        <TableActionsDropdown
                                                            actions={[
                                                                { label: isRTL ? 'عرض' : 'Preview', icon: Eye, onClick: () => navigate(`/sales/cases/${caseId}/quotations/${q.id}/preview`) },
                                                                { label: isRTL ? 'تعديل' : 'Edit', icon: Edit, onClick: () => navigate(`/sales/cases/${caseId}/quotations/${q.id}/edit`) },
                                                                { label: isRTL ? 'طباعة' : 'Print', icon: Printer, onClick: () => navigate(`/sales/cases/${caseId}/quotations/${q.id}/print`) }
                                                            ]}
                                                        />
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        ) : (
                            <Card className="card-premium py-12">
                                <div className="text-center">
                                    <FileText className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                                    <h3 className="text-lg font-bold text-gray-900 dark:text-white">{t('sales.case.noQuotations')}</h3>
                                    <p className="text-gray-500 text-sm mb-6">{t('sales.case.noQuotationsDesc')}</p>
                                    <Button onClick={() => navigate(`/sales/cases/${caseId}/quotations/new`)}>
                                        <Plus className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                                        {t('sales.case.createFirstQuote')}
                                    </Button>
                                </div>
                            </Card>
                        )}
                    </div>
                )}

                {activeTab === 'activity' && (
                    <Card className="card-premium">
                        <CardContent className="p-6">
                            <div className="space-y-6">
                                <div className="flex items-start gap-4">
                                    <div className="bg-blue-50 p-2 rounded-full mt-1">
                                        <History className="h-4 w-4 text-blue-500" />
                                    </div>
                                    <div>
                                        <p className="text-sm font-bold text-gray-900 dark:text-white">{t('sales.case.activityInitialized')}</p>
                                        <p className="text-xs text-gray-500"><span className="bidi-isolate">{formatDate(salesCase.createdAt)}</span> {t('sales.case.activityBy')} {salesCase.assignedAgent}</p>
                                    </div>
                                </div>
                                <div className="flex items-start gap-4">
                                    <div className="bg-emerald-50 p-2 rounded-full mt-1">
                                        <Info className="h-4 w-4 text-emerald-500" />
                                    </div>
                                    <div>
                                        <p className="text-sm font-bold text-gray-900 dark:text-white">{t('sales.case.activityStageUpdated').replace('{stage}', getStatusLabel(salesCase.status))}</p>
                                        <p className="text-xs text-gray-500">{t('sales.case.activityAutomatic')}</p>
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                )}
            </div>
            </div>
        </div>
    );
};
