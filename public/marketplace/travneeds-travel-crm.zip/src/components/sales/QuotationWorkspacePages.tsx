import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BarChart3, CheckCircle, Clock, Edit, Eye, FileText, GitBranch, Printer, Search, ShieldCheck, TrendingUp, XCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { mockCases, mockQuotations } from '../../services/mockData';
import { formatCurrency, formatDate } from '../../utils/format';
import { Quotation, QuotationStatus, QuotationVersion } from '../../types/quotation';
import { QuotationStatusBadge } from './QuotationStatusBadge';
import { cn } from '../../utils/cn';

type QuoteRow = {
  id: string;
  reference: string;
  caseId: string;
  customer: string;
  owner: string;
  quotation: Quotation;
  version: QuotationVersion;
  versionCount: number;
  totalCost: number;
  totalSelling: number;
  profit: number;
  margin: number;
};

const useQuoteRows = () => useMemo<QuoteRow[]>(() => mockQuotations.flatMap(quotation => {
  const salesCase = mockCases.find(item => item.id === quotation.caseId);
  const version = quotation.versions[quotation.versions.length - 1];
  if (!version) return [];

  const totalCost = version.costSummary?.groupTotalCost ?? version.pricing.grandTotalCost ?? 0;
  const totalSelling = version.pricing.totalSellingPrice;
  const profit = version.profitAnalysis?.grossProfit ?? version.pricing.profitAmount ?? totalSelling - totalCost;
  const margin = totalSelling > 0 ? Math.round((profit / totalSelling) * 100) : 0;

  return [{
    id: quotation.id,
    reference: quotation.reference,
    caseId: quotation.caseId,
    customer: version.customerInfo.name || salesCase?.customer || 'Unknown Customer',
    owner: version.preparedBy || salesCase?.assignedAgent || salesCase?.agent || 'Current User',
    quotation,
    version,
    versionCount: quotation.versions.length,
    totalCost,
    totalSelling,
    profit,
    margin
  }];
}), []);

const needsApproval = (row: QuoteRow) => row.version.status === 'Draft'
  || row.version.status === 'Revised'
  || row.margin < 15
  || Boolean(row.version.pricing.manualOverride)
  || Boolean(row.version.profitAnalysis?.lowMarginWarning);

export const QuotationAnalyticsPage: React.FC = () => {
  const rows = useQuoteRows();
  const navigate = useNavigate();
  const [statusFilter, setStatusFilter] = useState<'All' | QuotationStatus>('All');
  const filtered = statusFilter === 'All' ? rows : rows.filter(row => row.version.status === statusFilter);
  const totalValue = filtered.reduce((sum, row) => sum + row.totalSelling, 0);
  const totalProfit = filtered.reduce((sum, row) => sum + row.profit, 0);
  const approved = filtered.filter(row => row.version.status === 'Approved');
  const avgMargin = filtered.length ? Math.round(filtered.reduce((sum, row) => sum + row.margin, 0) / filtered.length) : 0;

  return (
    <QuotationShell title="Quotation Analytics" subtitle="Revenue, margin, conversion, and approval health from live quotation data.">
      <div className="flex justify-end">
        <Select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value as typeof statusFilter)} className="w-full sm:w-48">
          <option value="All">All Statuses</option>
          {(['Draft', 'Sent', 'Revised', 'Approved', 'Rejected', 'Expired'] as QuotationStatus[]).map(status => <option key={status} value={status}>{status}</option>)}
        </Select>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Metric icon={FileText} label="Quoted Value" value={formatCurrency(totalValue)} detail={`${filtered.length} quotations`} />
        <Metric icon={TrendingUp} label="Gross Profit" value={formatCurrency(totalProfit)} detail={`${avgMargin}% average margin`} tone={avgMargin < 15 ? 'red' : 'green'} />
        <Metric icon={CheckCircle} label="Conversion" value={`${rows.length ? Math.round((approved.length / rows.length) * 100) : 0}%`} detail={`${approved.length} approved quotes`} tone="green" />
        <Metric icon={ShieldCheck} label="Pending Approvals" value={rows.filter(needsApproval).length.toString()} detail="Margin or override driven" tone="amber" />
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Revenue Pipeline</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {(['Draft', 'Sent', 'Revised', 'Approved', 'Rejected'] as QuotationStatus[]).map(status => {
              const statusRows = rows.filter(row => row.version.status === status);
              const value = statusRows.reduce((sum, row) => sum + row.totalSelling, 0);
              const width = totalValue ? Math.max(4, Math.round((value / totalValue) * 100)) : 0;
              return <PipelineBar key={status} label={`${status} (${statusRows.length})`} value={formatCurrency(value)} width={width} />;
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Profitability Analytics</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {filtered.map(row => (
              <button key={row.id} className="w-full rounded border border-gray-100 p-3 text-left hover:bg-gray-50 rtl:text-right" onClick={() => navigate(`/sales/cases/${row.caseId}/quotations/${row.id}/preview`)}>
                <div className="flex justify-between gap-3">
                  <span className="font-semibold">{row.reference}</span>
                  <span className={cn('font-bold', row.margin < 15 ? 'text-rose-600' : 'text-emerald-600')}>{row.margin}%</span>
                </div>
                <div className="mt-1 text-xs text-gray-500">{row.customer} / {formatCurrency(row.profit, { currency: row.version.pricing.currency })} profit</div>
              </button>
            ))}
          </CardContent>
        </Card>
      </div>
    </QuotationShell>
  );
};

export const QuotationApprovalsPage: React.FC = () => {
  const rows = useQuoteRows();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const approvalRows = rows.filter(row => needsApproval(row) || (row.version.approvalReviews || []).length > 0);
  const filtered = approvalRows.filter(row => {
    const term = searchTerm.toLowerCase();
    return !term || row.reference.toLowerCase().includes(term) || row.customer.toLowerCase().includes(term) || row.owner.toLowerCase().includes(term);
  });

  return (
    <QuotationShell title="Quotation Approvals" subtitle="Approval requests, exception rules, decision history, and workflow validation.">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <Metric icon={Clock} label="Pending Approvals" value={approvalRows.filter(needsApproval).length.toString()} detail="Needs manager action" tone="amber" />
        <Metric icon={CheckCircle} label="Approved Reviews" value={rows.reduce((sum, row) => sum + (row.version.approvalReviews || []).filter(review => review.status === 'Approved').length, 0).toString()} detail="Logged decisions" tone="green" />
        <Metric icon={XCircle} label="Rejected Reviews" value={rows.reduce((sum, row) => sum + (row.version.approvalReviews || []).filter(review => review.status === 'Rejected').length, 0).toString()} detail="Requires revision" tone="red" />
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400 rtl:left-auto rtl:right-3" />
            <Input className="pl-10 rtl:pl-4 rtl:pr-10" placeholder="Search quotation no, customer, approver..." value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Approval Requests</CardTitle></CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] text-sm">
              <thead className="bg-gray-50 text-xs uppercase text-gray-500">
                <tr>
                  <th className="px-3 py-3 text-left rtl:text-right">Quotation</th>
                  <th className="px-3 py-3 text-left rtl:text-right">Reason</th>
                  <th className="px-3 py-3 text-left rtl:text-right">Owner</th>
                  <th className="px-3 py-3 text-left rtl:text-right">Status</th>
                  <th className="px-3 py-3 text-left rtl:text-right">Decision Log</th>
                  <th className="px-3 py-3 text-right rtl:text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(row => (
                  <tr key={row.id} className="border-t border-gray-100">
                    <td className="px-3 py-3"><div className="font-bold">{row.reference}</div><div className="text-xs text-gray-500">{row.customer}</div></td>
                    <td className="px-3 py-3">{approvalReason(row)}</td>
                    <td className="px-3 py-3">{row.owner}</td>
                    <td className="px-3 py-3"><QuotationStatusBadge status={row.version.status} /></td>
                    <td className="px-3 py-3">{(row.version.approvalReviews || []).length} reviews</td>
                    <td className="px-3 py-3 text-right rtl:text-left">
                      <TableActionsDropdown actions={[
                        { label: 'Review in Builder', icon: ShieldCheck, onClick: () => navigate(`/sales/cases/${row.caseId}/quotations/${row.id}/edit`) },
                        { label: 'Preview', icon: Eye, onClick: () => navigate(`/sales/cases/${row.caseId}/quotations/${row.id}/preview`) }
                      ]} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && <div className="py-12 text-center text-sm text-gray-500">No approval requests match the current filters.</div>}
        </CardContent>
      </Card>
    </QuotationShell>
  );
};

export const QuotationVersionHistoryPage: React.FC = () => {
  const rows = useQuoteRows();
  const navigate = useNavigate();

  return (
    <QuotationShell title="Quotation Version History" subtitle="Every quotation version, pricing change, proposal log, and print/preview action in one audit surface.">
      <Card>
        <CardHeader><CardTitle>Version Logs</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          {rows.map(row => (
            <div key={row.id} className="rounded-lg border border-gray-100 p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-bold">{row.reference}</span>
                    <QuotationStatusBadge status={row.version.status} />
                  </div>
                  <div className="mt-1 text-sm text-gray-500">{row.customer} / {row.version.programOverview.title}</div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => navigate(`/sales/cases/${row.caseId}/quotations/${row.id}/preview`)}><Eye className="h-4 w-4" />Preview</Button>
                  <Button variant="outline" size="sm" onClick={() => navigate(`/sales/cases/${row.caseId}/quotations/${row.id}/print`)}><Printer className="h-4 w-4" />Print</Button>
                  <Button size="sm" onClick={() => navigate(`/sales/cases/${row.caseId}/quotations/${row.id}/edit`)}><Edit className="h-4 w-4" />Edit</Button>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
                {row.quotation.versions.map(version => (
                  <div key={version.id} className="rounded border border-gray-100 bg-gray-50 p-3">
                    <div className="flex items-center justify-between gap-3">
                      <div className="font-semibold"><GitBranch className="mr-1 inline h-4 w-4 rtl:ml-1 rtl:mr-0" />v{version.versionNumber}</div>
                      <QuotationStatusBadge status={version.status} />
                    </div>
                    <div className="mt-2 text-xs text-gray-500">{formatDate(version.createdAt)} / {version.preparedBy}</div>
                    <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
                      <span>Selling: <strong>{formatCurrency(version.pricing.totalSellingPrice, { currency: version.pricing.currency })}</strong></span>
                      <span>Profit: <strong>{formatCurrency(version.pricing.profitAmount, { currency: version.pricing.currency })}</strong></span>
                      <span>Template: <strong>{version.pdfTemplate || 'Classic'}</strong></span>
                      <span>Logs: <strong>{(version.proposalLogs || []).length}</strong></span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </QuotationShell>
  );
};

const QuotationShell: React.FC<{ title: string; subtitle: string; children: React.ReactNode }> = ({ title, subtitle, children }) => (
  <div className="w-full pb-8">
    <div className="mx-auto max-w-[1400px] space-y-6">
      <div className="rounded-3xl bg-[#2563EB] p-6 text-white shadow-lg shadow-blue-500/20 sm:p-8">
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{title}</h1>
        <p className="mt-1 text-sm text-blue-100 opacity-90">{subtitle}</p>
      </div>
      {children}
    </div>
  </div>
);

const Metric: React.FC<{ icon: React.ElementType; label: string; value: string; detail: string; tone?: 'blue' | 'green' | 'amber' | 'red' }> = ({ icon: Icon, label, value, detail, tone = 'blue' }) => {
  const tones = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-emerald-50 text-emerald-600',
    amber: 'bg-amber-50 text-amber-600',
    red: 'bg-rose-50 text-rose-600'
  };
  return (
    <Card className="border-none shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate text-[10px] font-bold uppercase tracking-widest text-gray-400">{label}</p>
            <p className="mt-1 truncate text-2xl font-bold text-gray-900 dark:text-white">{value}</p>
            <p className="mt-1 text-xs text-gray-500">{detail}</p>
          </div>
          <div className={cn('rounded-xl p-2', tones[tone])}><Icon className="h-5 w-5" /></div>
        </div>
      </CardContent>
    </Card>
  );
};

const PipelineBar: React.FC<{ label: string; value: string; width: number }> = ({ label, value, width }) => (
  <div>
    <div className="mb-1 flex justify-between text-xs"><span>{label}</span><strong>{value}</strong></div>
    <div className="h-2 rounded-full bg-gray-100"><div className="h-2 rounded-full bg-blue-600" style={{ width: `${width}%` }} /></div>
  </div>
);

const approvalReason = (row: QuoteRow) => {
  if (row.margin < 15) return `Low margin (${row.margin}%)`;
  if (row.version.pricing.manualOverride) return 'Manual pricing override';
  if (row.version.status === 'Draft' || row.version.status === 'Revised') return 'Draft/revised quotation requires approval before send';
  return 'Approval review logged';
};
