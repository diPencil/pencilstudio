import React, { useState, useEffect } from 'react';
import { Save, Calendar, ArrowLeft } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { useLocale } from '../../localization/useLocale';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';

export interface ScheduledTask {
  title: string;
  taskType: string;
  dueDate: string;
  dueTime: string;
  priority: string;
  description: string;
  assignedTo: string;
  status: string;
  createdAt: string;
}

const taskTypes = [
  'Follow-up Call',
  'Send Email',
  'Prepare Quotation',
  'Schedule Meeting',
  'Document Review',
  'Customer Visit',
  'Internal Meeting',
  'Contract Preparation'
];

const priorities = ['Low', 'Medium', 'High', 'Critical'];

export const SchedulePage: React.FC = () => {
  const { t, isRTL, direction } = useLocale();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToastContext();
  
  // Can be used for both Leads and Sales (caseData or entity)
  const entity = location.state?.entity || location.state?.caseData || location.state?.lead;
  const entityType = location.state?.entityType || 'Sales Case';

  const [formData, setFormData] = useState({
    title: '',
    taskType: 'Follow-up Call',
    dueDate: '',
    dueTime: '',
    priority: 'Medium',
    description: '',
    assignedTo: 'Super Admin'
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!entity) {
      navigate(-1); // Go back if no context provided
    }
  }, [entity, navigate]);

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'New': return t('sales.status.new');
      case 'In Progress': return t('sales.status.inProgress');
      case 'Awaiting Reply': return t('sales.status.awaitingReply');
      case 'Quotation Sent': return t('sales.status.quotationSent');
      case 'Won': return t('sales.status.won');
      case 'Lost': return t('sales.status.lost');
      default: return status;
    }
  };

  const getLocalizedType = (type: string) => {
    if (type === 'B2C') return isRTL ? 'B2C (أفراد)' : 'B2C';
    if (type === 'B2B') return isRTL ? 'B2B (شركات)' : 'B2B';
    return type;
  };

  const getLocalizedAgent = (agent: string) => {
    if (!isRTL) return agent;
    switch (agent) {
      case 'Super Admin': return 'المسؤول العام';
      case 'Mahmoud Khalil': return 'محمود خليل';
      case 'Layla Ramadan': return 'ليلى رمضان';
      case 'Sami Youssef': return 'سامي يوسف';
      case 'Mona Zaki': return 'منى زكي';
      default: return agent;
    }
  };

  const getLocalizedTaskType = (type: string) => {
    if (!isRTL) return type;
    switch (type) {
      case 'Follow-up Call': return 'مکالمة متابعة';
      case 'Send Email': return 'إرسال بريد إلكتروني';
      case 'Prepare Quotation': return 'إعداد عرض سعر';
      case 'Schedule Meeting': return 'جدولة اجتماع';
      case 'Document Review': return 'مراجعة المستندات';
      case 'Customer Visit': return 'زيارة العميل';
      case 'Internal Meeting': return 'اجتماع داخلي';
      case 'Contract Preparation': return 'تجهيز العقد';
      default: return type;
    }
  };

  const getLocalizedPriority = (priority: string) => {
    switch (priority) {
      case 'Critical': return isRTL ? 'حرجة' : 'Critical';
      case 'High': return isRTL ? 'مرتفعة' : 'High';
      case 'Medium': return isRTL ? 'متوسطة' : 'Medium';
      case 'Low': return isRTL ? 'منخفضة' : 'Low';
      default: return priority;
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.title.trim()) {
      newErrors.title = t('sales.modal.validation.taskTitle') || 'Task title is required';
    }

    if (!formData.dueDate) {
      newErrors.dueDate = t('sales.modal.validation.dueDate') || 'Due date is required';
    }

    if (!formData.dueTime) {
      newErrors.dueTime = t('sales.modal.validation.dueTime') || 'Due time is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      toast.success(
          isRTL ? 'تم الجدولة' : 'Scheduled', 
          isRTL ? 'تمت جدولة المهمة بنجاح.' : 'Task scheduled successfully.'
      );
      navigate(-1);
    } catch (error) {
      console.error('Error scheduling task:', error);
      toast.error('Error', 'Failed to schedule task');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  if (!entity) return null;

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate(-1)} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
              <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-xl">
                <Calendar className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight bidi-isolate">
                  {t('sales.modal.scheduleTitle')?.replace('{id}', entity.id) || `Schedule Task - ${entity.id}`}
                </h1>
                <p className="mt-1 text-sm text-blue-100 opacity-90">
                  {isRTL ? 'جدولة مهمة جديدة أو موعد' : 'Schedule a new task or appointment'}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-8 shadow-sm">
          {/* Entity Info */}
          <div className="bg-blue-50 dark:bg-blue-900/10 rounded-2xl p-6 mb-8 border border-blue-100 dark:border-blue-900/30">
            <h4 className="text-sm font-bold text-blue-800 dark:text-blue-300 mb-3 uppercase tracking-wider">
              {t('sales.modal.relatedCase') || 'Related Entity'}
            </h4>
            <div className="flex flex-wrap gap-x-8 gap-y-4 text-sm text-blue-900 dark:text-blue-100 font-medium">
              <p><strong>{t('sales.table.customer') || 'Customer'}:</strong> <span className="text-blue-700 dark:text-blue-300 ml-1">{entity.customer || entity.fullName || entity.name}</span></p>
              <p><strong>{t('sales.table.status') || 'Status'}:</strong> <span className="text-blue-700 dark:text-blue-300 ml-1">{getStatusLabel(entity.status)}</span></p>
              {entity.type && <p><strong>{t('sales.table.type') || 'Type'}:</strong> <span className="text-blue-700 dark:text-blue-300 ml-1">{getLocalizedType(entity.type)}</span></p>}
            </div>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <Input
                  label={t('sales.modal.taskTitleLabel') || 'Task Title *'}
                  value={formData.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  error={errors.title}
                  placeholder={t('sales.modal.taskTitlePlaceholder') || 'e.g., Follow up on latest proposal'}
                />
              </div>

              <Select
                label={t('sales.modal.taskTypeLabel') || 'Task Type'}
                value={formData.taskType}
                onChange={(e) => handleInputChange('taskType', e.target.value)}
              >
                {taskTypes.map(type => (
                  <option key={type} value={type}>{getLocalizedTaskType(type)}</option>
                ))}
              </Select>

              <Select
                label={t('sales.modal.priorityLabel') || 'Priority'}
                value={formData.priority}
                onChange={(e) => handleInputChange('priority', e.target.value)}
              >
                {priorities.map(priority => (
                  <option key={priority} value={priority}>{getLocalizedPriority(priority)}</option>
                ))}
              </Select>

              <Input
                label={t('sales.modal.dueDateLabel') || 'Due Date *'}
                type="date"
                value={formData.dueDate}
                onChange={(e) => handleInputChange('dueDate', e.target.value)}
                error={errors.dueDate}
                min={new Date().toISOString().split('T')[0]}
              />

              <Input
                label={t('sales.modal.dueTimeLabel') || 'Due Time *'}
                type="time"
                value={formData.dueTime}
                onChange={(e) => handleInputChange('dueTime', e.target.value)}
                error={errors.dueTime}
              />

              <div className="md:col-span-2">
                <Select
                  label={t('sales.modal.assignedToLabel') || 'Assign To'}
                  value={formData.assignedTo}
                  onChange={(e) => handleInputChange('assignedTo', e.target.value)}
                >
                  <option value="Super Admin">{getLocalizedAgent('Super Admin')}</option>
                  <option value="Mahmoud Khalil">{getLocalizedAgent('Mahmoud Khalil')}</option>
                  <option value="Layla Ramadan">{getLocalizedAgent('Layla Ramadan')}</option>
                  <option value="Sami Youssef">{getLocalizedAgent('Sami Youssef')}</option>
                  <option value="Mona Zaki">{getLocalizedAgent('Mona Zaki')}</option>
                </Select>
              </div>
            </div>

            <div className="mt-8">
              <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">
                {t('sales.modal.descriptionLabel') || 'Description'}
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={5}
                className="block w-full px-4 py-3 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder={t('sales.modal.descriptionPlaceholder') || 'Enter task details...'}
              />
            </div>

            <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-gray-100 dark:border-gray-800">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate(-1)}
                disabled={isLoading}
              >
                {t('sales.modal.cancel') || 'Cancel'}
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                loading={isLoading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Save className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                {t('sales.modal.scheduleTaskBtn') || 'Schedule Task'}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
