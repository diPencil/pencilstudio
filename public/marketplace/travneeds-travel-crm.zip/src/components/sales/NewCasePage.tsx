import React, { useState } from 'react';
import { ArrowLeft, Briefcase, Plus, CheckCircle2, AlertCircle } from 'lucide-react';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { Card, CardContent } from '../ui/Card';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';
import { useLocale } from '../../localization/useLocale';

const mockCustomers = [
    { id: 'CU-001', name: 'Ahmed Hassan', email: 'ahmed@email.com', phone: '+20 123 456 789' },
    { id: 'CU-002', name: 'Cairo Tours Ltd', email: 'info@cairotours.com', phone: '+20 987 654 321' },
    { id: 'CU-003', name: 'Mariam Mahmoud', email: 'mariam@email.com', phone: '+20 123 456 789' },
    { id: 'CU-004', name: 'Global Travel Co', email: 'contact@globaltravel.com', phone: '+1 555 123 4567' }
];

const availableItems = [
    'Hotel: Steigenberger Luxor',
    'Hotel: Hilton Aswan Resort',
    'Flight: CAI-LXR Economy',
    'Tour: Valley of Kings',
    'Activity: Nile Felucca Ride',
    'Package: Full Egypt Tour',
    'Transport: Airport Transfer'
];

const departments = ['Reservation', 'Operations', 'Finance', 'Marketing', 'Customer Service'];
const agents = ['Super Admin', 'Mahmoud Khalil', 'Layla Ramadan', 'Sami Youssef', 'Mona Zaki'];

export const NewCasePage: React.FC = () => {
    const navigate = useNavigate();
    const toast = useToastContext();
    const { t, isRTL } = useLocale();

    const [formData, setFormData] = useState({
        customerId: '',
        caseType: 'B2C',
        quotationStatus: 'Draft',
        linkedItems: [] as string[],
        assignedDepartments: [] as string[],
        initialStatus: 'New',
        assignedAgent: 'Super Admin',
        notes: ''
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(false);

    const validateForm = () => {
        const newErrors: Record<string, string> = {};
        if (!formData.customerId) newErrors.customerId = t('sales.modal.validation.customer');
        if (formData.linkedItems.length === 0) newErrors.linkedItems = t('sales.modal.validation.linkedItems');
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const getLocalizedItem = (item: string) => {
        if (!isRTL) return item;
        const itemMap: Record<string, string> = {
            'Hotel: Steigenberger Luxor': 'فندق: شتايجنبرجر الأقصر',
            'Hotel: Hilton Aswan Resort': 'فندق: منتجع هيلتون أسوان',
            'Flight: CAI-LXR Economy': 'طيران: القاهرة-الأقصر اقتصادي',
            'Tour: Valley of Kings': 'جولة: وادي الملوك',
            'Activity: Nile Felucca Ride': 'نشاط: رحلة فلوكة في النيل',
            'Package: Full Egypt Tour': 'باقة: جولة مصر الكاملة',
            'Package: Nile Cruise 4 Days': 'باقة: كروز النيل 4 أيام',
            'Cruise: Nile Cruise 4 Days': 'باقة: كروز النيل 4 أيام',
            'Transport: Airport Transfer': 'انتقالات: توصيل المطار'
        };
        return itemMap[item] || item;
    };

    const getLocalizedDept = (dept: string) => {
        if (!isRTL) return dept;
        const deptMap: Record<string, string> = {
            'Reservation': 'الحجوزات',
            'Operations': 'العمليات',
            'Finance': 'المالية',
            'Marketing': 'التسويق',
            'Customer Service': 'خدمة العملاء'
        };
        return deptMap[dept] || dept;
    };

    const getLocalizedAgent = (agent: string) => {
        if (!isRTL) return agent;
        const agentMap: Record<string, string> = {
            'Super Admin': 'المشرف العام',
            'Mahmoud Khalil': 'محمود خليل',
            'Layla Ramadan': 'ليلى رمضان',
            'Sami Youssef': 'سامي يوسف',
            'Mona Zaki': 'منى زكي'
        };
        return agentMap[agent] || agent;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!validateForm()) return;

        setIsLoading(true);
        try {
            console.log('Creating Case:', formData);
            toast.success(t('sales.toast.caseCreated'), t('sales.toast.caseCreatedShort'));
            navigate('/sales');
        } catch {
            toast.error(t('sales.toast.error'), t('sales.toast.errorCreate'));
        } finally {
            setIsLoading(false);
        }
    };

    const handleInputChange = (field: string, value: string | string[]) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        if (errors[field]) setErrors(prev => ({ ...prev, [field]: '' }));
    };

    const toggleItem = (item: string) => {
        setFormData(prev => ({
            ...prev,
            linkedItems: prev.linkedItems.includes(item)
                ? prev.linkedItems.filter(i => i !== item)
                : [...prev.linkedItems, item]
        }));
    };

    const toggleDept = (dept: string) => {
        setFormData(prev => ({
            ...prev,
            assignedDepartments: prev.assignedDepartments.includes(dept)
                ? prev.assignedDepartments.filter(d => d !== dept)
                : [...prev.assignedDepartments, dept]
        }));
    };

    const selectedCustomer = mockCustomers.find(c => c.id === formData.customerId);

    return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center gap-4">
                        <Button variant="ghost" size="sm" onClick={() => navigate('/sales')} className="p-2 text-blue-100 hover:text-white hover:bg-white/10">
                            <ArrowLeft size={20} className="rtl:rotate-180" />
                        </Button>
                        <div>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">{t('sales.modal.createTitle')}</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">{t('sales.subtitle')}</p>
                        </div>
                    </div>
                </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Form Section */}
                <div className="lg:col-span-2">
                    <Card>
                        <CardContent className="p-6">
                            <form onSubmit={handleSubmit} className="space-y-8">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <Select
                                        label={t('sales.modal.customerLabel')}
                                        value={formData.customerId}
                                        onChange={(e) => handleInputChange('customerId', e.target.value)}
                                        error={errors.customerId}
                                    >
                                        <option value="">{t('sales.modal.customerPlaceholder')}</option>
                                        {mockCustomers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                    </Select>

                                    <Select
                                        label={t('sales.modal.typeLabel')}
                                        value={formData.caseType}
                                        onChange={(e) => handleInputChange('caseType', e.target.value)}
                                    >
                                        <option value="B2C">{isRTL ? 'B2C (أفراد)' : 'B2C (Individual)'}</option>
                                        <option value="B2B">{isRTL ? 'B2B (شركات)' : 'B2B (Corporate)'}</option>
                                    </Select>

                                    {selectedCustomer && (
                                        <div className="md:col-span-2 p-3 bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30 rounded flex items-center justify-between">
                                            <div className="flex items-center gap-3 text-sm text-blue-700 dark:text-blue-300">
                                                <CheckCircle2 size={16} />
                                                <span>{isRTL ? 'تم التحقق من العميل:' : 'Customer verified:'} <strong className="bidi-isolate">{selectedCustomer.email}</strong> • <span className="bidi-isolate">{selectedCustomer.phone}</span></span>
                                            </div>
                                        </div>
                                    )}

                                    <Select
                                        label={t('sales.modal.initialStatusLabel')}
                                        value={formData.initialStatus}
                                        onChange={(e) => handleInputChange('initialStatus', e.target.value)}
                                    >
                                        <option value="New">{t('sales.status.new')}</option>
                                        <option value="In Progress">{t('sales.status.inProgress')}</option>
                                        <option value="Awaiting Reply">{t('sales.status.awaitingReply')}</option>
                                    </Select>

                                    <Select
                                        label={t('sales.modal.quoteStatusLabel')}
                                        value={formData.quotationStatus}
                                        onChange={(e) => handleInputChange('quotationStatus', e.target.value)}
                                    >
                                        <option value="Draft">{t('sales.status.draft')}</option>
                                        <option value="Sent">{t('sales.status.sent')}</option>
                                        <option value="Accepted">{t('sales.status.approved')}</option>
                                    </Select>

                                    <Select
                                        label={t('sales.modal.assignedAgentLabel')}
                                        value={formData.assignedAgent}
                                        onChange={(e) => handleInputChange('assignedAgent', e.target.value)}
                                    >
                                        {agents.map(agent => <option key={agent} value={agent}>{getLocalizedAgent(agent)}</option>)}
                                    </Select>
                                </div>

                                {/* Linked Items Multi-select */}
                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200 mb-3">{t('sales.modal.linkedItemsLabel')}</label>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50/50 dark:bg-gray-800/50">
                                        {availableItems.map(item => (
                                            <button
                                                key={item}
                                                type="button"
                                                onClick={() => toggleItem(item)}
                                                className={cn(
                                                    "flex items-center px-3 py-2 text-xs rounded transition-all text-left rtl:text-right border",
                                                    formData.linkedItems.includes(item)
                                                        ? "bg-blue-100 border-blue-300 text-blue-700 dark:bg-blue-900/30 dark:border-blue-700 dark:text-blue-300"
                                                        : "bg-white border-gray-200 text-gray-600 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-400 hover:border-blue-400"
                                                )}
                                            >
                                                <Plus size={12} className={cn("flex-shrink-0", formData.linkedItems.includes(item) && "hidden")} />
                                                <CheckCircle2 size={12} className={cn("flex-shrink-0", !formData.linkedItems.includes(item) && "hidden")} />
                                                {getLocalizedItem(item)}
                                            </button>
                                        ))}
                                    </div>
                                    {errors.linkedItems && <p className="text-xs text-red-500 mt-1">{errors.linkedItems}</p>}
                                </div>

                                {/* Assigned Departments */}
                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200 mb-3">{t('sales.modal.assignedDeptsLabel')}</label>
                                    <div className="flex flex-wrap gap-2">
                                        {departments.map(dept => (
                                            <button
                                                key={dept}
                                                type="button"
                                                onClick={() => toggleDept(dept)}
                                                className={cn(
                                                    "px-4 py-1.5 text-xs rounded-full border transition-all",
                                                    formData.assignedDepartments.includes(dept)
                                                        ? "bg-indigo-600 border-indigo-600 text-white shadow-sm"
                                                        : "bg-white border-gray-300 text-gray-600 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-400"
                                                )}
                                            >
                                                {getLocalizedDept(dept)}
                                            </button>
                                        ))}
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200">{t('sales.modal.notesLabel')}</label>
                                    <textarea
                                        value={formData.notes}
                                        onChange={(e) => handleInputChange('notes', e.target.value)}
                                        rows={4}
                                        className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                                        placeholder={t('sales.modal.notesPlaceholder')}
                                    />
                                </div>

                                <div className="flex justify-end gap-3 pt-6 border-t border-gray-200 dark:border-gray-700">
                                    <Button type="button" variant="outline" onClick={() => navigate('/sales')} disabled={isLoading}>
                                        {t('sales.modal.cancel')}
                                    </Button>
                                    <Button type="submit" disabled={isLoading} loading={isLoading}>
                                        <Briefcase className="h-4 w-4" />
                                        {t('sales.modal.createCaseBtn')}
                                    </Button>
                                </div>
                            </form>
                        </CardContent>
                    </Card>
                </div>

                {/* Sidebar Section */}
                <div className="space-y-6">
                    <Card className="bg-white dark:bg-gray-800 border-none shadow-sm">
                        <CardContent className="p-6 text-center">
                            <p className="label-xs mb-1">{isRTL ? 'الحالات النشطة' : 'Active Cases'}</p>
                            <h2 className="stat-value bidi-isolate">32</h2>
                            <div className="h-1 w-12 bg-blue-100 dark:bg-blue-900/30 mx-auto rounded-full mt-4 mb-4"></div>
                            <p className="text-gray-500 dark:text-gray-400 text-xs text-balance">{isRTL ? 'تتبع خدمات متعددة تحت حساب عميل واحد بسهولة.' : 'Track multiple services under one customer account easily.'}</p>
                        </CardContent>
                    </Card>

                    <Card className="border-l-4 border-l-blue-500">
                        <CardContent className="p-4 flex items-start gap-3">
                            <AlertCircle className="text-blue-500 flex-shrink-0 mt-0.5" size={18} />
                            <div className="space-y-1">
                                <h4 className="text-sm font-bold text-gray-900 dark:text-white">{isRTL ? 'نصيحة محترفة' : 'Pro Tip'}</h4>
                                <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed">
                                    {isRTL ? 'يساعد ربط جميع الخدمات (الفنادق، الطيران، إلخ) بحالة واحدة قسمي المالية والعمليات على التنسيق بشكل أفضل.' : 'Linking all services (Hotels, Flights, etc.) to a single case helps the finance and operations departments coordinate better.'}
                                </p>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
            </div>
        </div>
    );
};
