import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Printer } from 'lucide-react';
import { Button } from '../ui/Button';
import { mockQuotations } from '../../services/mockData';
import type { Quotation, QuotationVersion } from '../../types/quotation';
import { formatCurrency, formatDate } from '../../utils/format';

const LAST_DRAFT_KEY = 'travneeds_quote_draft:last';

interface PreviewDraftPayload {
    quotationId: string;
    caseId: string;
    reference: string;
    currentVersion: number;
    version: QuotationVersion;
}

export const QuotationPrintPage: React.FC = () => {
    const { caseId, quotationId } = useParams<{ caseId: string; quotationId: string }>();
    const navigate = useNavigate();
    const storedDraft = loadStoredDraft(caseId, quotationId);
    const quotation = storedDraft ? quotationFromDraft(storedDraft) : mockQuotations.find(q => q.id === quotationId);
    const latestVersion = quotation?.versions[quotation.versions.length - 1];
    const [template, setTemplate] = useState<QuotationVersion['pdfTemplate']>(latestVersion?.pdfTemplate || 'Classic');

    if (!quotation || !latestVersion) {
        return (
            <div className="min-h-screen bg-white p-8 text-center text-gray-900">
                <h1 className="text-xl font-bold">Quotation not found</h1>
                <Button className="mt-4" variant="outline" onClick={() => navigate(-1)}>Back</Button>
            </div>
        );
    }

    const services = latestVersion.serviceLines || [];
    const activeFixedCosts = (latestVersion.fixedCosts || []).filter(cost => cost.status === 'Active');
    const clientAttachments = (latestVersion.attachments || []).filter(file => file.visibility === 'Client' || file.status === 'Verified');
    const templateClass = template === 'Modern'
        ? 'border-t-8 border-blue-600'
        : template === 'Corporate'
            ? 'border-t-8 border-gray-900'
            : 'border-t-8 border-emerald-600';

    return (
        <div className="min-h-screen bg-gray-100 p-6 text-gray-900 print:bg-white print:p-0">
            <div className="mx-auto mb-6 flex max-w-[900px] flex-col gap-3 rounded-lg border border-gray-200 bg-white p-4 print:hidden sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-3">
                    <Button variant="outline" onClick={() => navigate(-1)}>
                        <ArrowLeft className="h-4 w-4" />
                        Back
                    </Button>
                    <select className="rounded-md border border-gray-300 px-3 py-2 text-sm" value={template} onChange={(event) => setTemplate(event.target.value as QuotationVersion['pdfTemplate'])}>
                        <option>Classic</option>
                        <option>Modern</option>
                        <option>Corporate</option>
                    </select>
                    <span className="text-sm font-semibold">PDF Template: {template}</span>
                </div>
                <Button onClick={() => window.print()}>
                    <Printer className="h-4 w-4" />
                    Print / Save as PDF
                </Button>
            </div>

            <article className={`mx-auto max-w-[900px] bg-white p-10 shadow-xl print:max-w-none print:shadow-none ${templateClass}`}>
                <header className="mb-8 flex items-start justify-between border-b border-gray-200 pb-6">
                    <div>
                        <h1 className="text-3xl font-black tracking-tight">{template === 'Corporate' ? 'TRAVNEEDS CORPORATE' : 'TRAVNEEDS'}</h1>
                        <p className="mt-1 text-xs font-bold uppercase tracking-[0.3em] text-gray-500">Travel & Tourism Proposal</p>
                    </div>
                    <div className="text-right">
                        <h2 className="text-xl font-bold">QUOTATION</h2>
                        <p className="text-sm text-gray-600">{quotation.reference}</p>
                        <p className="text-xs text-gray-500">Prepared: {formatDate(latestVersion.preparedDate)}</p>
                        <p className="text-xs text-gray-500">Expires: {formatDate(latestVersion.expiryDate)}</p>
                    </div>
                </header>

                <section className="mb-8 grid grid-cols-2 gap-8">
                    <InfoPanel title="Prepared For">
                        <p className="text-lg font-bold">{latestVersion.customerInfo.customerName}</p>
                        <p>{latestVersion.customerInfo.companyName || latestVersion.customerInfo.email}</p>
                        <p>{latestVersion.customerInfo.phone}</p>
                    </InfoPanel>
                    <InfoPanel title="Package">
                        <p className="text-lg font-bold">{latestVersion.programOverview.title || 'Untitled Package'}</p>
                        <p>{latestVersion.programOverview.packageCode} / {latestVersion.programOverview.packageType}</p>
                        <p>{latestVersion.programOverview.destinations.join(', ') || latestVersion.programOverview.citiesCovered.join(', ')}</p>
                    </InfoPanel>
                </section>

                <section className="mb-8 grid grid-cols-4 gap-3">
                    <Metric label="Pax" value={`${latestVersion.customerInfo.pax.total}`} />
                    <Metric label="Nights" value={`${latestVersion.customerInfo.pax.nights || latestVersion.programOverview.nights}`} />
                    <Metric label="Total Price" value={formatCurrency(latestVersion.pricing.totalSellingPrice, { currency: latestVersion.pricing.currency })} />
                    <Metric label="Per Person" value={formatCurrency(latestVersion.pricing.sellingPricePerPerson, { currency: latestVersion.pricing.currency })} />
                </section>

                <PrintSection title="Itinerary">
                    <div className="space-y-3">
                        {latestVersion.itinerary.map(day => (
                            <div key={day.day} className="rounded-lg border border-gray-200 p-4">
                                <div className="flex items-center justify-between gap-3">
                                    <h3 className="font-bold">Day {day.day}: {day.title}</h3>
                                    <span className="text-xs font-semibold text-gray-500">{day.city} / {day.route}</span>
                                </div>
                                <p className="mt-2 text-sm text-gray-700">{day.description}</p>
                                <p className="mt-2 text-xs text-gray-500">Meals: {day.meals.join(', ') || 'None'} | Transport: {day.transport || '-'}</p>
                            </div>
                        ))}
                        {latestVersion.itinerary.length === 0 && <p className="text-sm text-gray-500">No itinerary days added.</p>}
                    </div>
                </PrintSection>

                <PrintSection title="Services Costing">
                    <table className="w-full text-sm">
                        <thead className="bg-gray-50 text-xs uppercase text-gray-500">
                            <tr>
                                <th className="p-2 text-left">Service</th>
                                <th className="p-2 text-left">Supplier</th>
                                <th className="p-2 text-right">Cost</th>
                                <th className="p-2 text-right">Selling</th>
                                <th className="p-2 text-right">Margin</th>
                            </tr>
                        </thead>
                        <tbody>
                            {services.map(service => (
                                <tr key={service.id} className="border-t border-gray-100">
                                    <td className="p-2 font-semibold">{service.serviceName}{service.isComplimentary ? ' (FOC)' : ''}</td>
                                    <td className="p-2 text-gray-600">{service.supplierName || '-'}</td>
                                    <td className="p-2 text-right">{formatCurrency(service.totalCost, { currency: 'USD' })}</td>
                                    <td className="p-2 text-right">{formatCurrency(service.totalSelling, { currency: 'USD' })}</td>
                                    <td className="p-2 text-right">{service.marginPercent}%</td>
                                </tr>
                            ))}
                            {services.length === 0 && <tr><td className="p-3 text-gray-500" colSpan={5}>No service lines added.</td></tr>}
                        </tbody>
                    </table>
                </PrintSection>

                {activeFixedCosts.length > 0 && (
                    <PrintSection title="Shared Fixed Costs">
                        <table className="w-full text-sm">
                            <tbody>
                                {activeFixedCosts.map(cost => (
                                    <tr key={cost.id} className="border-t border-gray-100">
                                        <td className="p-2 font-semibold">{cost.name}</td>
                                        <td className="p-2 text-gray-600">{cost.category}</td>
                                        <td className="p-2 text-gray-600">{cost.allocationMethod}</td>
                                        <td className="p-2 text-right">{formatCurrency(cost.amount * cost.quantity * (cost.days || 1), { currency: cost.currency })}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </PrintSection>
                )}

                {clientAttachments.length > 0 && (
                    <PrintSection title="Attached Documents">
                        <div className="grid grid-cols-2 gap-3">
                            {clientAttachments.map(file => (
                                <div key={file.id} className="rounded border border-gray-200 p-3 text-sm">
                                    <div className="font-semibold">{file.fileName}</div>
                                    <div className="text-xs text-gray-500">{file.type} / {file.status}</div>
                                </div>
                            ))}
                        </div>
                    </PrintSection>
                )}

                <PrintSection title="Terms & Conditions">
                    <p className="whitespace-pre-wrap text-sm leading-6 text-gray-700">{latestVersion.terms}</p>
                </PrintSection>

                <footer className="mt-10 border-t border-gray-200 pt-5 text-center text-[10px] uppercase tracking-[0.2em] text-gray-400">
                    Travneeds System / Generated proposal
                </footer>
            </article>
        </div>
    );
};

const loadStoredDraft = (caseId?: string, quotationId?: string): PreviewDraftPayload | undefined => {
    try {
        const lastKey = sessionStorage.getItem(LAST_DRAFT_KEY) || '';
        const keys = [
            quotationId && caseId ? `travneeds_quote_draft:${caseId}:${quotationId}` : '',
            lastKey
        ].filter(Boolean);

        for (const key of keys) {
            const raw = sessionStorage.getItem(key);
            if (!raw) continue;
            const parsed = JSON.parse(raw) as PreviewDraftPayload;
            if (!quotationId || parsed.quotationId === quotationId) return parsed;
        }
    } catch {
        return undefined;
    }
    return undefined;
};

const quotationFromDraft = (draft: PreviewDraftPayload): Quotation => ({
    id: draft.quotationId,
    caseId: draft.caseId,
    reference: draft.reference,
    currentVersion: draft.currentVersion,
    versions: [draft.version],
    createdAt: draft.version.preparedDate,
    updatedAt: new Date().toISOString().split('T')[0]
});

const InfoPanel: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div>
        <h3 className="mb-2 text-xs font-bold uppercase tracking-widest text-gray-400">{title}</h3>
        <div className="space-y-1 text-sm text-gray-700">{children}</div>
    </div>
);

const Metric: React.FC<{ label: string; value: string }> = ({ label, value }) => (
    <div className="rounded-lg bg-gray-50 p-3">
        <div className="text-[10px] font-bold uppercase tracking-wide text-gray-500">{label}</div>
        <div className="mt-1 font-bold">{value}</div>
    </div>
);

const PrintSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <section className="mb-8">
        <h2 className="mb-3 border-b border-gray-200 pb-2 text-lg font-bold">{title}</h2>
        {children}
    </section>
);
