import React, { useState } from 'react';
import { Save, ArrowLeft, Star } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { Card, CardContent } from '../ui/Card';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { generateId } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import type { TranslationKey } from '../../localization/messages/en';
import { cn } from '../../utils/cn';

const customerTypes = ['Individual', 'Family/Group', 'Corporate'];
const contactMethods = ['Email', 'Phone', 'WhatsApp'];
const statuses = ['Active', 'Recurring', 'VIP', 'Suspended'];
const staff = ['Super Admin', 'Mahmoud Khalil', 'Layla Ramadan', 'Sami Youssef', 'Mona Zaki'];

const mockRecentCustomers = [
    { name: 'Mona Mohammed', email: 'mona@email.com', type: 'Individual', status: 'Active' },
    { name: 'Al-Masry Global Co', email: 'contact@almasry.com', type: 'Corporate', status: 'VIP' },
    { name: 'Khaled Yassin', email: 'khaled@email.com', type: 'Individual', status: 'Recurring' },
    { name: 'Red Sea Divers Group', email: 'info@redsea.com', type: 'Family/Group', status: 'Active' }
];

export const NewCustomerPage: React.FC = () => {
    const { t, isRTL } = useLocale();
    const navigate = useNavigate();
    const toast = useToastContext();
    const [formData, setFormData] = useState({
        fullName: '',
        email: '',
        phone: '',
        company: '',
        type: 'Individual',
        contactMethod: 'Email',
        status: 'Active',
        assignedStaff: 'Super Admin',
        notes: ''
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(false);

    const getTypeKey = (type: string): TranslationKey => {
        switch (type) {
            case 'Individual': return 'customers.filter.individual';
            case 'Corporate': return 'customers.filter.corporate';
            case 'Family/Group': return 'customers.form.familyGroup';
            default: return 'customers.filter.individual';
        }
    };

    const getContactMethodKey = (method: string): TranslationKey => {
        switch (method) {
            case 'Email': return 'customers.contactMethod.email';
            case 'Phone': return 'customers.contactMethod.phone';
            case 'WhatsApp': return 'customers.contactMethod.whatsapp';
            default: return 'customers.contactMethod.email';
        }
    };

    const getStatusKey = (status: string): TranslationKey => {
        switch (status) {
            case 'Active': return 'customers.status.active';
            case 'VIP': return 'customers.status.vip';
            case 'Recurring': return 'customers.status.recurring';
            case 'Suspended': return 'customers.status.suspended';
            default: return 'customers.status.active';
        }
    };

    const validateForm = () => {
        const newErrors: Record<string, string> = {};
        if (!formData.fullName.trim()) newErrors.fullName = t('customers.form.validation.fullNameRequired');
        if (!formData.email.trim()) {
            newErrors.email = t('customers.form.validation.emailRequired');
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
            newErrors.email = t('customers.form.validation.emailInvalid');
        }
        if (!formData.phone.trim()) newErrors.phone = t('customers.form.validation.phoneRequired');
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!validateForm()) return;

        setIsLoading(true);
        try {
            const customerData = {
                ...formData,
                id: generateId('CU'),
                createdAt: new Date().toISOString()
            };
            console.log('Saving customer:', customerData);
            toast.success(
                isRTL ? 'تم إنشاء العميل' : 'Customer Created',
                isRTL ? 'تمت إضافة العميل الجديد بنجاح.' : 'New customer has been added successfully.'
            );
            navigate('/customers');
        } catch {
            toast.error(
                isRTL ? 'خطأ' : 'Error',
                isRTL ? 'فشل في حفظ العميل' : 'Failed to save customer'
            );
        } finally {
            setIsLoading(false);
        }
    };

    const handleInputChange = (field: string, value: string) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        if (errors[field]) setErrors(prev => ({ ...prev, [field]: '' }));
    };

    return (
        <div className="w-full pb-8" dir={isRTL ? 'rtl' : 'ltr'}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center gap-4">
                        <Button variant="outline" onClick={() => navigate('/customers')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                            <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
                        </Button>
                        <div>
                            <h1 className="text-2xl font-bold">{t('customers.form.addNewCustomer')}</h1>
                            <p className="text-blue-100 opacity-90">{t('customers.form.subtitle')}</p>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Form Section */}
                    <div className="lg:col-span-2">
                        <Card className="border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] rounded-3xl overflow-hidden bg-white dark:bg-gray-900">
                            <CardContent className="p-6 sm:p-8">
                                <form onSubmit={handleSubmit} className="space-y-6">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <Input
                                            label={t('customers.form.fullName') + ' *'}
                                            value={formData.fullName}
                                            onChange={(e) => handleInputChange('fullName', e.target.value)}
                                            error={errors.fullName}
                                            placeholder={t('customers.form.fullNamePlaceholder')}
                                        />
                                        <Input
                                            label={t('customers.form.email') + ' *'}
                                            type="email"
                                            value={formData.email}
                                            onChange={(e) => handleInputChange('email', e.target.value)}
                                            error={errors.email}
                                            placeholder={t('customers.form.emailPlaceholder')}
                                        />
                                        <Input
                                            label={t('customers.form.phone') + ' *'}
                                            value={formData.phone}
                                            onChange={(e) => handleInputChange('phone', e.target.value)}
                                            error={errors.phone}
                                            placeholder={t('customers.form.phonePlaceholder')}
                                        />
                                        <Input
                                            label={t('customers.form.company')}
                                            value={formData.company}
                                            onChange={(e) => handleInputChange('company', e.target.value)}
                                            placeholder={t('customers.form.companyPlaceholder')}
                                        />
                                        <Select
                                            label={t('customers.form.type')}
                                            value={formData.type}
                                            onChange={(e) => handleInputChange('type', e.target.value)}
                                        >
                                            {customerTypes.map(type => (
                                                <option key={type} value={type}>{t(getTypeKey(type))}</option>
                                            ))}
                                        </Select>
                                        <Select
                                            label={t('customers.form.contactMethod')}
                                            value={formData.contactMethod}
                                            onChange={(e) => handleInputChange('contactMethod', e.target.value)}
                                        >
                                            {contactMethods.map(method => (
                                                <option key={method} value={method}>{t(getContactMethodKey(method))}</option>
                                            ))}
                                        </Select>
                                        <Select
                                            label={t('customers.form.assignedStaff')}
                                            value={formData.assignedStaff}
                                            onChange={(e) => handleInputChange('assignedStaff', e.target.value)}
                                        >
                                            {staff.map(member => (
                                                <option key={member} value={member}>{member}</option>
                                            ))}
                                        </Select>
                                        <Select
                                            label={t('customers.form.status')}
                                            value={formData.status}
                                            onChange={(e) => handleInputChange('status', e.target.value)}
                                        >
                                            {statuses.map(status => (
                                                <option key={status} value={status}>{t(getStatusKey(status))}</option>
                                            ))}
                                        </Select>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                            {t('customers.form.notes')}
                                        </label>
                                        <textarea
                                            value={formData.notes}
                                            onChange={(e) => handleInputChange('notes', e.target.value)}
                                            rows={4}
                                            className="block w-full px-4 py-3 border border-gray-100 dark:border-gray-800 rounded-2xl shadow-sm placeholder-gray-400 bg-slate-50 dark:bg-gray-800/50 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                                            placeholder={t('customers.form.notesPlaceholder')}
                                        />
                                    </div>

                                    <div className="flex justify-end gap-3 pt-6">
                                        <Button type="button" variant="outline" onClick={() => navigate('/customers')} disabled={isLoading} className="rounded-xl">
                                            {t('customers.form.cancel')}
                                        </Button>
                                        <Button type="submit" disabled={isLoading} loading={isLoading} className="rounded-xl">
                                            <Save className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                                            {t('customers.form.save')}
                                        </Button>
                                    </div>
                                </form>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Sidebar Section */}
                    <div className="space-y-6">
                        {/* Stats Card */}
                        <Card className="bg-white dark:bg-gray-900 border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] rounded-3xl">
                            <CardContent className="p-6 text-center">
                                <p className="label-xs mb-1">{t('customers.form.totalCustomers')}</p>
                                <h2 className="stat-value text-3xl bidi-isolate text-blue-600">1,280</h2>
                                <div className="h-1 w-12 bg-blue-100 dark:bg-blue-900/30 mx-auto rounded-full mt-4 mb-4"></div>
                                <p className="text-gray-500 dark:text-gray-400 text-xs">{t('customers.form.statsNew')}</p>
                            </CardContent>
                        </Card>

                        {/* Recent Customers */}
                        <Card className="border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] rounded-3xl overflow-hidden bg-white dark:bg-gray-900">
                            <div className="p-5 border-b border-gray-50 dark:border-gray-800">
                                <h2 className="font-semibold text-gray-900 dark:text-white">{t('customers.form.recentlyAdded')}</h2>
                            </div>
                            <CardContent className="p-0">
                                <div className="divide-y divide-gray-50 dark:divide-gray-800">
                                    {mockRecentCustomers.map((customer, index) => (
                                        <div key={index} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                                            <div className="flex justify-between items-start mb-1 gap-2">
                                                <h3 className="font-medium text-sm text-gray-900 dark:text-white bidi-isolate">{customer.name}</h3>
                                                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${customer.status === 'VIP' ? 'bg-purple-50 text-purple-600' :
                                                    customer.status === 'Active' ? 'bg-green-50 text-green-600' :
                                                        'bg-blue-50 text-blue-600'
                                                    }`}>
                                                    {t(getStatusKey(customer.status))}
                                                </span>
                                            </div>
                                            <div className="space-y-1">
                                                <p className="text-xs text-gray-500 dark:text-gray-400">
                                                    {t(getTypeKey(customer.type))} • <span className="bidi-isolate">{customer.email}</span>
                                                </p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                <div className="p-4 border-t border-gray-50 dark:border-gray-800">
                                    <Button variant="outline" className="w-full text-xs py-2 rounded-xl" onClick={() => navigate('/customers')}>
                                        {t('customers.form.viewAll')}
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Quick Info */}
                        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-0 shadow-sm rounded-3xl">
                            <CardContent className="p-6">
                                <div className="flex items-center gap-2 text-blue-700 dark:text-blue-300 mb-3">
                                    <Star size={18} className="fill-blue-700 dark:fill-blue-300" />
                                    <h4 className="text-sm font-bold">{t('customers.form.vipRecognition')}</h4>
                                </div>
                                <p className="text-xs text-blue-800/80 dark:text-blue-200/80 leading-relaxed font-medium">
                                    {t('customers.form.vipDesc')}
                                </p>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>
        </div>
    );
};
