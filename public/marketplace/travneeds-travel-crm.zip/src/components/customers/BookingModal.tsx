import React, { useState } from 'react';
import { X, Calendar, Save } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { generateId } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  type: string;
}

interface BookingData {
  service: string;
  destination: string;
  startDate: string;
  duration: string;
  participants: string;
  specialRequests: string;
  estimatedCost: string;
  amountPaid: string;
  deposit: string;
  balance: string;
  status: string;
  itinerary: { day: string; title: string; description: string; image: File | null }[];
  id: string;
  customerId: string;
  customerName: string;
  createdAt: string;
  updatedAt: string;
}

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (bookingData: BookingData) => Promise<void>;
  customer: Customer;
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, onSave, customer }) => {
  const { t, isRTL } = useLocale();

  const services = React.useMemo(() => [
    { value: 'Premium Tour Package', label: isRTL ? 'باقة جولة مميزة' : 'Premium Tour Package' },
    { value: 'City Walking Tour', label: isRTL ? 'جولة مشي في المدينة' : 'City Walking Tour' },
    { value: 'Adventure Package', label: isRTL ? 'باقة المغامرة' : 'Adventure Package' },
    { value: 'Cultural Experience', label: isRTL ? 'تجربة ثقافية' : 'Cultural Experience' },
    { value: 'Beach Resort Package', label: isRTL ? 'باقة منتجع شاطئي' : 'Beach Resort Package' },
    { value: 'Mountain Trekking', label: isRTL ? 'رحلات تسلق الجبال' : 'Mountain Trekking' },
    { value: 'Food & Wine Tour', label: isRTL ? 'جولة طعام' : 'Food & Wine Tour' },
    { value: 'Photography Tour', label: isRTL ? 'جولة تصوير' : 'Photography Tour' }
  ], [isRTL]);

  const durations = React.useMemo(() => [
    { value: '1', label: isRTL ? 'يوم واحد' : '1 Day' },
    { value: '3', label: isRTL ? '3 أيام' : '3 Days' },
    { value: '7', label: isRTL ? 'أسبوع واحد' : '1 Week' },
    { value: '14', label: isRTL ? 'أسبوعين' : '2 Weeks' },
    { value: '21', label: isRTL ? '3 أسابيع' : '3 Weeks' },
    { value: '30', label: isRTL ? 'شهر واحد' : '1 Month' }
  ], [isRTL]);

  const [formData, setFormData] = useState({
    service: 'Premium Tour Package',
    destination: '',
    startDate: '',
    duration: '7',
    participants: '1',
    specialRequests: '',
    estimatedCost: '',
    amountPaid: '',
    deposit: '',
    balance: '',
    status: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [itinerary, setItinerary] = useState([
    { day: isRTL ? 'اليوم 1' : 'Day 1', title: '', description: '', image: null as File | null }
  ]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.destination.trim()) {
      newErrors.destination = t('customers.booking.validation.destination');
    }

    if (!formData.startDate) {
      newErrors.startDate = t('customers.booking.validation.startDate');
    }

    if (!formData.participants || parseInt(formData.participants) < 1) {
      newErrors.participants = t('customers.booking.validation.participants');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    try {
      const bookingData = {
        ...formData,
        itinerary,
        id: generateId('BK'),
        customerId: customer.id,
        customerName: customer.name,
        status: formData.status || 'Pending',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      await onSave(bookingData);

      setFormData({
        service: 'Premium Tour Package',
        destination: '',
        startDate: '',
        duration: '7',
        participants: '1',
        specialRequests: '',
        estimatedCost: '',
        amountPaid: '',
        deposit: '',
        balance: '',
        status: ''
      });
      setItinerary([{ day: isRTL ? 'اليوم 1' : 'Day 1', title: '', description: '', image: null }]);
      setErrors({});
      onClose();
    } catch (error) {
      console.error('Error creating booking:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleItineraryChange = (index: number, field: 'title' | 'description' | 'image', value: string | File | null) => {
    const updated = [...itinerary];
    if (field === 'image') {
      updated[index].image = value as File | null;
    } else {
      updated[index][field] = value as string;
    }
    setItinerary(updated);
  };

  const handleAddDay = () => {
    const nextDay = isRTL ? `اليوم ${itinerary.length + 1}` : `Day ${itinerary.length + 1}`;
    setItinerary([...itinerary, { day: nextDay, title: '', description: '', image: null }]);
  };

  const handleRemoveDay = (index: number) => {
    const updated = itinerary.filter((_, i) => i !== index)
      .map((item, i) => ({ ...item, day: isRTL ? `اليوم ${i + 1}` : `Day ${i + 1}` }));
    setItinerary(updated);
  };

  if (!isOpen || !customer) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-2xl bg-white dark:bg-gray-800 rounded-lg shadow-xl">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-3">
              <Calendar className="h-6 w-6 text-blue-500" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                {t('customers.booking.createTitle')} {customer.name}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Select label={t('customers.booking.service')} value={formData.service} onChange={(e) => handleInputChange('service', e.target.value)}>
                {services.map(service => (
                  <option key={service.value} value={service.value}>{service.label}</option>
                ))}
              </Select>

              <Input label={`${t('customers.booking.destination')} *`} value={formData.destination} onChange={(e) => handleInputChange('destination', e.target.value)} error={errors.destination} placeholder={isRTL ? 'أدخل الوجهة' : 'Enter destination'} />

              <Input label={`${t('customers.booking.startDate')} *`} type="date" value={formData.startDate} onChange={(e) => handleInputChange('startDate', e.target.value)} error={errors.startDate} min={new Date().toISOString().split('T')[0]} />

              <Select label={t('customers.booking.duration')} value={formData.duration} onChange={(e) => handleInputChange('duration', e.target.value)}>
                {durations.map(duration => (
                  <option key={duration.value} value={duration.value}>{duration.label}</option>
                ))}
              </Select>

              <Input label={`${t('customers.booking.participants')} *`} type="number" value={formData.participants} onChange={(e) => handleInputChange('participants', e.target.value)} error={errors.participants} min="1" placeholder={isRTL ? 'أدخل عدد المشاركين' : 'Enter number of participants'} />

              <Input label={t('customers.booking.estimatedCost')} type="number" value={formData.estimatedCost} onChange={(e) => handleInputChange('estimatedCost', e.target.value)} placeholder={isRTL ? 'أدخل التكلفة التقديرية (اختياري)' : 'Enter estimated cost (optional)'} />
            </div>

            {/* Itinerary Section */}
            <div className="mt-6">
              <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">{t('customers.booking.itinerary')}</h4>
              <div className="space-y-4">
                {itinerary.map((entry, index) => (
                  <div key={index} className="grid md:grid-cols-5 gap-3 bg-gray-100 dark:bg-gray-700 p-3 rounded items-center">
                    <span className="text-xs font-bold text-gray-500 dark:text-gray-400">{entry.day}</span>
                    <Input placeholder={t('customers.booking.itineraryTitle')} value={entry.title} onChange={(e) => handleItineraryChange(index, 'title', e.target.value)} />
                    <div className="md:col-span-2">
                      <Input placeholder={t('customers.booking.itineraryDesc')} value={entry.description} onChange={(e) => handleItineraryChange(index, 'description', e.target.value)} />
                    </div>
                    <div className="flex items-center gap-2">
                      <label className="cursor-pointer">
                        <input type="file" accept="image/*" className="hidden" onChange={(e) => handleItineraryChange(index, 'image', e.target.files?.[0] || null)} />
                        <span className="text-blue-600 hover:underline">🖼️</span>
                      </label>
                      <button type="button" onClick={() => handleRemoveDay(index)} className="text-red-500 hover:text-red-700">✕</button>
                    </div>
                  </div>
                ))}
              </div>
              <Button type="button" onClick={handleAddDay} className="mt-4">{t('customers.booking.addDay')}</Button>
            </div>

            {/* Payment Tracking */}
            <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
              <Input label={t('customers.booking.amountPaid')} type="number" value={formData.amountPaid} onChange={(e) => handleInputChange('amountPaid', e.target.value)} placeholder="e.g. 1000" />
              <Input label={t('customers.booking.deposit')} type="number" value={formData.deposit} onChange={(e) => handleInputChange('deposit', e.target.value)} placeholder="e.g. 200" />
              <Input label={t('customers.booking.remainingBalance')} type="number" value={formData.balance} onChange={(e) => handleInputChange('balance', e.target.value)} placeholder="Auto or manual" />
            </div>

            {/* Status Update */}
            <div className="mt-6">
              <Select label={t('customers.booking.bookingStatus')} value={formData.status} onChange={(e) => handleInputChange('status', e.target.value)}>
                <option value="">{isRTL ? 'اختر الحالة' : 'Select status'}</option>
                <option value="booked">{isRTL ? 'محجوز' : 'Booked'}</option>
                <option value="paid">{isRTL ? 'مدفوع' : 'Paid'}</option>
                <option value="inProgress">{isRTL ? 'قيد التنفيذ' : 'In Progress'}</option>
                <option value="completed">{isRTL ? 'مكتمل' : 'Completed'}</option>
              </Select>
            </div>

            {/* Special Requests */}
            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('customers.booking.specialRequests')}
              </label>
              <textarea
                value={formData.specialRequests}
                onChange={(e) => handleInputChange('specialRequests', e.target.value)}
                rows={4}
                className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder={t('customers.booking.specialRequestsPlaceholder')}
              />
            </div>

            {/* Customer Info */}
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 mt-6">
              <h4 className="text-sm font-semibold text-blue-800 dark:text-blue-300 mb-2">
                {t('customers.booking.customerInfo')}
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-blue-700 dark:text-blue-400">{isRTL ? 'الاسم: ' : 'Name: '}</span>
                  <span className="text-blue-800 dark:text-blue-300">{customer.name}</span>
                </div>
                <div>
                  <span className="text-blue-700 dark:text-blue-400">{isRTL ? 'البريد الإلكتروني: ' : 'Email: '}</span>
                  <span className="text-blue-800 dark:text-blue-300 bidi-isolate">{customer.email}</span>
                </div>
                <div>
                  <span className="text-blue-700 dark:text-blue-400">{isRTL ? 'الهاتف: ' : 'Phone: '}</span>
                  <span className="text-blue-800 dark:text-blue-300 ltr-value">{customer.phone}</span>
                </div>
                <div>
                  <span className="text-blue-700 dark:text-blue-400">{isRTL ? 'النوع: ' : 'Type: '}</span>
                  <span className="text-blue-800 dark:text-blue-300">{customer.type === 'Corporate' ? t('customers.filter.corporate') : t('customers.filter.individual')}</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
              <Button type="button" variant="outline" onClick={onClose} disabled={isLoading}>
                {t('customers.booking.cancel')}
              </Button>
              <Button type="submit" disabled={isLoading} loading={isLoading}>
                <Save className="h-4 w-4 mr-2" />
                {t('customers.booking.create')}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};