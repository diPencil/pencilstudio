import React, { useState } from 'react';
import { X, Save, Settings, Star, Bell } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { useLocale } from '../../localization/useLocale';

interface Preferences {
  contactMethod: string;
  mealPreference: string;
  roomPreference: string;
  newsletter: boolean;
  loyaltyLevel: string;
}

interface Customer {
  contactMethod?: string;
  status?: string;
}

interface UpdatePreferencesModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (preferences: Preferences) => Promise<void>;
    customer: Customer | null;
}

export const UpdatePreferencesModal: React.FC<UpdatePreferencesModalProps> = ({
    isOpen,
    onClose,
    onSave,
    customer
}) => {
    const { t, isRTL } = useLocale();

    const contactMethods = React.useMemo(() => [
        { value: 'Email', label: t('customers.contactMethod.email') },
        { value: 'Phone', label: t('customers.contactMethod.phone') },
        { value: 'WhatsApp', label: t('customers.contactMethod.whatsapp') },
        { value: 'SMS', label: isRTL ? 'رسالة نصية' : 'SMS' }
    ], [t, isRTL]);

    const meals = React.useMemo(() => [
        { value: 'Vegetarian', label: t('customers.preferences.meal.vegetarian') },
        { value: 'Vegan', label: t('customers.preferences.meal.vegan') },
        { value: 'Halal', label: t('customers.preferences.meal.halal') },
        { value: 'No Gluten', label: t('customers.preferences.meal.noGluten') },
        { value: 'Standard', label: t('customers.preferences.meal.standard') }
    ], [t]);

    const rooms = React.useMemo(() => [
        { value: 'High Floor', label: t('customers.preferences.room.highFloor') },
        { value: 'Low Floor', label: t('customers.preferences.room.lowFloor') },
        { value: 'Near Elevator', label: t('customers.preferences.room.nearElevator') },
        { value: 'Quiet Area', label: t('customers.preferences.room.quietArea') }
    ], [t]);

    const [formData, setFormData] = useState({
        contactMethod: customer?.contactMethod || 'Email',
        mealPreference: 'Vegetarian',
        roomPreference: 'High Floor',
        newsletter: true,
        loyaltyLevel: customer?.status === 'VIP' ? 'VIP' : 'Standard'
    });
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        try {
            await onSave(formData);
            onClose();
        } catch (error) {
            console.error('Error updating preferences:', error);
        } finally {
            setIsLoading(false);
        }
    };

    if (!isOpen || !customer) return null;

    return (
        <div className="fixed inset-0 z-[60] overflow-y-auto" dir={isRTL ? 'rtl' : 'ltr'}>
            <div className="flex min-h-screen items-center justify-center p-4">
                <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
                <div className="relative w-full max-w-md bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-100 dark:border-gray-700">
                    <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
                        <div className="flex items-center gap-3">
                            <Settings className="h-6 w-6 text-blue-500" />
                            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                                {t('customers.preferences.title')}
                            </h2>
                        </div>
                        <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                            <X size={24} />
                        </button>
                    </div>

                    <form onSubmit={handleSubmit} className="p-6">
                        <div className="space-y-6">
                            <Select
                                label={t('customers.preferences.contactMethod')}
                                value={formData.contactMethod}
                                onChange={(e) => setFormData(prev => ({ ...prev, contactMethod: e.target.value }))}
                            >
                                {contactMethods.map(item => (
                                    <option key={item.value} value={item.value}>{item.label}</option>
                                ))}
                            </Select>

                            <div className="grid grid-cols-2 gap-4">
                                <Select
                                    label={t('customers.preferences.mealPreference')}
                                    value={formData.mealPreference}
                                    onChange={(e) => setFormData(prev => ({ ...prev, mealPreference: e.target.value }))}
                                >
                                    {meals.map(item => (
                                        <option key={item.value} value={item.value}>{item.label}</option>
                                    ))}
                                </Select>

                                <Select
                                    label={t('customers.preferences.roomPreference')}
                                    value={formData.roomPreference}
                                    onChange={(e) => setFormData(prev => ({ ...prev, roomPreference: e.target.value }))}
                                >
                                    {rooms.map(item => (
                                        <option key={item.value} value={item.value}>{item.label}</option>
                                    ))}
                                </Select>
                            </div>

                            <div className="space-y-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                                <label className="flex items-center gap-3 cursor-pointer group">
                                    <div className={`p-2 rounded-lg transition-colors ${formData.newsletter ? 'bg-blue-50 dark:bg-blue-900/30' : 'bg-gray-50 dark:bg-gray-800'}`}>
                                        <Bell className={`h-5 w-5 ${formData.newsletter ? 'text-blue-600' : 'text-gray-400'}`} />
                                    </div>
                                    <div className="flex-1">
                                        <p className="text-sm font-medium text-gray-900 dark:text-white">{t('customers.preferences.newsletterTitle')}</p>
                                        <p className="text-xs text-gray-500">{t('customers.preferences.newsletterDesc')}</p>
                                    </div>
                                    <input
                                        type="checkbox"
                                        checked={formData.newsletter}
                                        onChange={(e) => setFormData(prev => ({ ...prev, newsletter: e.target.checked }))}
                                        className="h-5 w-5 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                                    />
                                </label>

                                <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-xl border border-purple-100 dark:border-purple-800">
                                    <div className="flex items-center gap-3 mb-3">
                                        <Star className="h-5 w-5 text-purple-600" />
                                        <span className="text-sm font-bold text-purple-900 dark:text-purple-100">{t('customers.preferences.loyaltyStatus')}</span>
                                    </div>
                                    <div className="flex gap-2">
                                        {['Standard', 'Silver', 'Gold', 'VIP'].map(level => {
                                            const levelLabel = level === 'Standard' ? (isRTL ? 'عادي' : 'Standard') :
                                                               level === 'Silver' ? (isRTL ? 'فضي' : 'Silver') :
                                                               level === 'Gold' ? (isRTL ? 'ذهبي' : 'Gold') : 'VIP';
                                            return (
                                                <button
                                                    key={level}
                                                    type="button"
                                                    onClick={() => setFormData(prev => ({ ...prev, loyaltyLevel: level }))}
                                                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg border transition-all ${formData.loyaltyLevel === level
                                                        ? 'bg-purple-600 border-purple-600 text-white shadow-md'
                                                        : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400'
                                                        }`}
                                                >
                                                    {levelLabel}
                                                </button>
                                            );
                                        })}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="flex justify-end gap-3 mt-8">
                            <Button type="button" variant="outline" onClick={onClose} disabled={isLoading}>
                                {t('customers.preferences.cancel')}
                            </Button>
                            <Button type="submit" disabled={isLoading} loading={isLoading}>
                                <Save className="h-4 w-4 mr-2 ml-2" />
                                {t('customers.preferences.updateAction')}
                            </Button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};
