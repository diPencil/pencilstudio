import React, { useState } from 'react';
import { X, Save } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { generateId } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import type { TranslationKey } from '../../localization/messages/en';
import { cn } from '../../utils/cn';
import { Customer } from './CustomersPage';

interface AddCustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (customerData: Customer) => Promise<void>;
}

const customerTypes = ['Individual', 'Family/Group', 'Corporate'];
const contactMethods = ['Email', 'Phone', 'WhatsApp'];
const statuses = ['Active', 'Recurring', 'VIP', 'Suspended'];
const staff = ['Super Admin', 'Mahmoud Khalil', 'Layla Ramadan', 'Sami Youssef', 'Mona Zaki'];

export const AddCustomerModal: React.FC<AddCustomerModalProps> = ({ isOpen, onClose, onSave }) => {
  const { t, isRTL } = useLocale();
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    company: '',
    type: 'Individual',
    contactMethod: 'Email',
    status: 'Active',
    assignedStaff: 'Super Admin',
    notes: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  const getTypeKey = (type: string): TranslationKey => {
    switch (type) {
      case 'Individual': return 'customers.filter.individual';
      case 'Corporate': return 'customers.filter.corporate';
      case 'Family/Group': return 'customers.form.familyGroup';
      default: return 'customers.filter.individual';
    }
  };

  const getContactMethodKey = (method: string): TranslationKey => {
    switch (method) {
      case 'Email': return 'customers.contactMethod.email';
      case 'Phone': return 'customers.contactMethod.phone';
      case 'WhatsApp': return 'customers.contactMethod.whatsapp';
      default: return 'customers.contactMethod.email';
    }
  };

  const getStatusKey = (status: string): TranslationKey => {
    switch (status) {
      case 'Active': return 'customers.status.active';
      case 'VIP': return 'customers.status.vip';
      case 'Recurring': return 'customers.status.recurring';
      case 'Suspended': return 'customers.status.suspended';
      default: return 'customers.status.active';
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = t('customers.form.validation.fullNameRequired');
    }

    if (!formData.email.trim()) {
      newErrors.email = t('customers.form.validation.emailRequired');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = t('customers.form.validation.emailInvalid');
    }

    if (!formData.phone.trim()) {
      newErrors.phone = t('customers.form.validation.phoneRequired');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    try {
      const customerData = {
        name: formData.fullName,
        email: formData.email,
        phone: formData.phone,
        company: formData.company,
        type: formData.type,
        status: formData.status,
        notes: formData.notes,
        assignedStaff: formData.assignedStaff,
        id: generateId('CU'),
        totalBookings: 0,
        totalSpent: 0,
        lastTrip: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      } as Customer;

      await onSave(customerData);
      
      // Reset form
      setFormData({
        fullName: '',
        email: '',
        phone: '',
        company: '',
        type: 'Individual',
        contactMethod: 'Email',
        status: 'Active',
        assignedStaff: 'Super Admin',
        notes: ''
      });
      setErrors({});
      onClose();
    } catch (error) {
      console.error('Error saving customer:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-2xl bg-white dark:bg-gray-800 rounded-lg shadow-xl">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              {t('customers.form.addNewCustomer')}
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label={t('customers.form.fullName') + ' *'}
                value={formData.fullName}
                onChange={(e) => handleInputChange('fullName', e.target.value)}
                error={errors.fullName}
                placeholder={t('customers.form.fullNamePlaceholder')}
              />

              <Input
                label={t('customers.form.email') + ' *'}
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                error={errors.email}
                placeholder={t('customers.form.emailPlaceholder')}
              />

              <Input
                label={t('customers.form.phone') + ' *'}
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                error={errors.phone}
                placeholder={t('customers.form.phonePlaceholder')}
              />

              <Input
                label={t('customers.form.company')}
                value={formData.company}
                onChange={(e) => handleInputChange('company', e.target.value)}
                placeholder={t('customers.form.companyPlaceholder')}
              />

              <Select
                label={t('customers.form.type')}
                value={formData.type}
                onChange={(e) => handleInputChange('type', e.target.value)}
              >
                {customerTypes.map(type => (
                  <option key={type} value={type}>{t(getTypeKey(type))}</option>
                ))}
              </Select>

              <Select
                label={t('customers.form.contactMethod')}
                value={formData.contactMethod}
                onChange={(e) => handleInputChange('contactMethod', e.target.value)}
              >
                {contactMethods.map(method => (
                  <option key={method} value={method}>{t(getContactMethodKey(method))}</option>
                ))}
              </Select>

              <Select
                label={t('customers.form.status')}
                value={formData.status}
                onChange={(e) => handleInputChange('status', e.target.value)}
              >
                {statuses.map(status => (
                  <option key={status} value={status}>{t(getStatusKey(status))}</option>
                ))}
              </Select>

              <Select
                label={t('customers.form.assignedStaff')}
                value={formData.assignedStaff}
                onChange={(e) => handleInputChange('assignedStaff', e.target.value)}
              >
                {staff.map(member => (
                  <option key={member} value={member}>{member}</option>
                ))}
              </Select>
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('customers.form.notes')}
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                rows={4}
                className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder={t('customers.form.notesPlaceholder')}
              />
            </div>

            <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isLoading}
              >
                {t('customers.form.cancel')}
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                loading={isLoading}
              >
                <Save className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                {t('customers.form.save')}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};