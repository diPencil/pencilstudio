import React from 'react';
import { Building, Calendar, Mail, Phone, User, Star, ArrowLeft } from 'lucide-react';
import { formatCurrency, formatDate } from '../../utils/format';
import { useToastContext } from '../../contexts/ToastContext';
// AddCustomerModal and UpdateContractModal removed (not used)
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';
import { useNavigate, useLocation } from 'react-router-dom';
import { CorporateAccount } from './CorporateAccountsPage';
import { Button } from '../ui/Button';

export const ViewCorporateAccountPage: React.FC = () => {
  const { t, isRTL } = useLocale();
  const toast = useToastContext();
  const navigate = useNavigate();
  const location = useLocation();

  const account = location.state?.account as CorporateAccount;

  if (!account) {
    return (
      <div className="w-full pb-8 pt-8 flex justify-center">
        <Button onClick={() => navigate('/customers/corporate')}>{t('common.back') || 'Back to Corporate Accounts'}</Button>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'VIP': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300';
      case 'Active': return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/20 dark:text-emerald-300';
      case 'Suspended': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'VIP': return t('customers.status.vip');
      case 'Active': return t('customers.status.active');
      case 'Suspended': return t('customers.status.suspended');
      default: return status;
    }
  };

  return (
    <div className="w-full pb-8" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate('/customers/corporate')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                    {account.companyName}
                </h1>
                <p className="mt-1 text-sm text-blue-100 opacity-90 flex items-center gap-2">
                    <span className={`inline-flex px-2 py-0.5 text-xs font-semibold rounded-full ${getStatusColor(account.status)} bg-opacity-90`}>
                        {getStatusLabel(account.status)}
                    </span>
                    <span>• {account.industry}</span>
                </p>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <div className="bg-white dark:bg-gray-900 p-6 rounded-3xl shadow-sm space-y-4">
                <h3 className="text-lg font-bold">{t('customers.viewCorp.contactInfo') || 'Contact Information'}</h3>
                <div className="space-y-3">
                    <div className="flex items-center gap-3">
                        <User className="h-5 w-5 text-gray-400" />
                        <div>
                            <p className="text-xs text-gray-500">{t('customers.viewCorp.primaryContact') || 'Primary Contact'}</p>
                            <p className="font-medium">{account.primaryContact}</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-3">
                        <Mail className="h-5 w-5 text-gray-400" />
                        <div>
                            <p className="text-xs text-gray-500">{t('customers.viewCorp.email') || 'Email'}</p>
                            <p className="font-medium">{account.email}</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-3">
                        <Phone className="h-5 w-5 text-gray-400" />
                        <div>
                            <p className="text-xs text-gray-500">{t('customers.viewCorp.phone') || 'Phone'}</p>
                            <p className="font-medium bidi-isolate">{account.phone}</p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="bg-white dark:bg-gray-900 p-6 rounded-3xl shadow-sm space-y-4">
                <h3 className="text-lg font-bold">{t('customers.viewCorp.contractDetails') || 'Contract Details'}</h3>
                <div className="space-y-3">
                    <div className="flex items-center gap-3">
                        <Building className="h-5 w-5 text-gray-400" />
                        <div>
                            <p className="text-xs text-gray-500">{t('customers.viewCorp.creditLimit') || 'Credit Limit'}</p>
                            <p className="font-medium bidi-isolate">{formatCurrency(account.creditLimit)}</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-3">
                        <Calendar className="h-5 w-5 text-gray-400" />
                        <div>
                            <p className="text-xs text-gray-500">{t('customers.viewCorp.contractExpiry') || 'Contract Expiry'}</p>
                            <p className="font-medium bidi-isolate">{formatDate(account.contractExpiry)}</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-3">
                        <Star className="h-5 w-5 text-gray-400" />
                        <div>
                            <p className="text-xs text-gray-500">{t('customers.viewCorp.paymentTerms') || 'Payment Terms'}</p>
                            <p className="font-medium">{account.paymentTerms}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};