import React from 'react';
import { Mail, Phone, Building, Calendar, User, Tag, MessageSquare, Star, ArrowLeft } from 'lucide-react';
import { formatDate, formatCurrency } from '../../utils/format';
import { useToastContext } from '../../contexts/ToastContext';
import { MessageModal } from '../leads/MessageModal';
// removed ScheduleModal
// UpdatePreferencesModal replaced by UpdatePreferencesPage
import { useLocale } from '../../localization/useLocale';
import { Customer } from './CustomersPage';
import { useLocation, useNavigate } from 'react-router-dom';
import { cn } from '../../utils/cn';
import { Button } from '../ui/Button';

export const ViewCustomerPage: React.FC = () => {
  const { t, isRTL } = useLocale();
  const toast = useToastContext();
  const location = useLocation();
  const navigate = useNavigate();

  const customer = location.state?.customer as Customer;

  const [isMessageModalOpen, setIsMessageModalOpen] = React.useState(false);
  // removed ScheduleModal state
  // removed isPreferencesModalOpen - now navigates to page

  const mockBookingHistory = React.useMemo(() => [
    {
      id: 'BK-001',
      service: isRTL ? 'باقة جولة مميزة' : 'Premium Tour Package',
      date: '2024-12-15',
      amount: 2500,
      status: isRTL ? 'مكتمل' : 'Completed',
      destination: isRTL ? 'بالي، إندونيسيا' : 'Bali, Indonesia'
    },
    {
      id: 'BK-002',
      service: isRTL ? 'جولة مشي في المدينة' : 'City Walking Tour',
      date: '2024-11-28',
      amount: 150,
      status: isRTL ? 'مكتمل' : 'Completed',
      destination: isRTL ? 'جولة المدينة المحلية' : 'Local City Tour'
    },
    {
      id: 'BK-003',
      service: isRTL ? 'باقة المغامرة' : 'Adventure Package',
      date: '2024-10-10',
      amount: 1800,
      status: isRTL ? 'مكتمل' : 'Completed',
      destination: isRTL ? 'رحلة نيبال الجبلية' : 'Nepal Trekking'
    }
  ], [isRTL]);

  const mockActivityHistory = React.useMemo(() => [
    {
      id: 1,
      type: 'booking',
      description: isRTL ? 'تم اكتمال باقة الرحلة المميزة' : 'Completed Premium Tour Package',
      user: isRTL ? 'المشرف العام' : 'Super Admin',
      timestamp: '2024-12-15T14:30:00Z',
      details: isRTL ? 'العميل راضٍ جداً عن جودة الخدمة' : 'Customer very satisfied with service quality'
    },
    {
      id: 2,
      type: 'call',
      description: isRTL ? 'تم إجراء مكالمة متابعة' : 'Follow-up call made',
      user: isRTL ? 'المشرف العام' : 'Super Admin',
      timestamp: '2024-12-20T10:15:00Z',
      details: isRTL ? 'تمت مناقشة خطط السفر المستقبلية لعام 2025' : 'Discussed future travel plans for 2025'
    },
    {
      id: 3,
      type: 'status_change',
      description: isRTL ? 'تم ترقية الحالة إلى VIP' : 'Status upgraded to VIP',
      user: isRTL ? 'المسؤول' : 'Admin',
      timestamp: '2024-12-16T09:00:00Z',
      details: isRTL ? 'مؤهل لحالة VIP بناءً على سجل الحجوزات' : 'Qualified for VIP status based on booking history'
    }
  ], [isRTL]);

  const handleAction = (type: string) => {
    switch (type) {
      case 'booking':
        navigate('/reservations/new');
        break;
      case 'email':
        setIsMessageModalOpen(true);
        break;
      case 'call':
        navigate('/sales/schedule', { state: { entity: { id: customer.id, customer: customer.name }, entityType: 'Customer' } });
        break;
      case 'preferences':
        navigate('/customers/preferences', { state: { customer } });
        break;
      default:
        console.log('Action:', type);
    }
  };

  const handleSendMessage = async (message: string, type: string) => {
    toast.success(
      type === 'message' ? (isRTL ? 'تم إرسال الرسالة' : 'Message Sent') : (isRTL ? 'تم إضافة ملاحظة' : 'Note Added'), 
      isRTL ? `تمت العملية بنجاح للعميل ${customer?.name}: "${message.substring(0, 20)}..."` : `Successfully handled for ${customer?.name}: "${message.substring(0, 20)}..."`
    );
  };

  const handleSavePreferences = async (prefs: { loyaltyLevel: string }) => {
    toast.success(
      isRTL ? 'تم تحديث التفضيلات' : 'Preferences Updated', 
      isRTL ? `تم حفظ الإعدادات (مستوى الولاء: ${prefs.loyaltyLevel}) للعميل ${customer?.name}.` : `Settings (Loyalty: ${prefs.loyaltyLevel}) saved for ${customer?.name}.`
    );
  };

  if (!customer) {
      return (
          <div className="w-full pb-8 pt-8 flex justify-center">
              <Button onClick={() => navigate('/customers')}>{t('common.back') || 'Back to Customers'}</Button>
          </div>
      );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'VIP': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300';
      case 'Recurring': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      case 'Inactive': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'Active': return t('customers.status.active');
      case 'VIP': return t('customers.status.vip');
      case 'Recurring': return t('customers.status.recurring');
      case 'Inactive': return t('customers.status.suspended');
      default: return status;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'Individual': return t('customers.filter.individual');
      case 'Corporate': return t('customers.filter.corporate');
      default: return type;
    }
  };

  const getContactMethodLabel = (method: string) => {
    switch (method?.toLowerCase()) {
      case 'email': return t('customers.contactMethod.email');
      case 'phone': return t('customers.contactMethod.phone');
      case 'whatsapp': return t('customers.contactMethod.whatsapp');
      default: return method;
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'booking': return <Calendar className="h-4 w-4 text-blue-500" />;
      case 'call': return <Phone className="h-4 w-4 text-green-500" />;
      case 'email': return <Mail className="h-4 w-4 text-purple-500" />;
      case 'status_change': return <Tag className="h-4 w-4 text-orange-500" />;
      default: return <MessageSquare className="h-4 w-4 text-gray-500" />;
    }
  };

  const totalSpent = mockBookingHistory.reduce((sum, booking) => sum + booking.amount, 0);

  return (
    <div className="w-full pb-8" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate('/customers')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">
                {t('customers.view.profileTitle')} - {customer.name}
              </h1>
              <p className="text-blue-100 opacity-90">{customer.email}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Customer Information */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-8 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] border-0">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">
                {t('customers.view.contactInfo')}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                  <div className="w-12 h-12 rounded-full overflow-hidden shadow-sm flex-shrink-0 border border-gray-200 dark:border-gray-700">
                      <img src={(customer.name || '').toLowerCase().includes('sarah') || (customer.name || '').toLowerCase().includes('layla') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider font-semibold mb-1">{t('customers.view.fullName')}</p>
                    <p className="font-semibold text-gray-900 dark:text-white">{customer.name}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                  <div className="p-3 bg-white dark:bg-gray-800 rounded-full shadow-sm flex-shrink-0">
                      <Mail className="h-5 w-5 text-gray-500" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider font-semibold mb-1">{t('customers.view.email')}</p>
                    <p className="font-semibold text-gray-900 dark:text-white bidi-isolate">{customer.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                  <div className="p-3 bg-white dark:bg-gray-800 rounded-full shadow-sm flex-shrink-0">
                      <Phone className="h-5 w-5 text-gray-500" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider font-semibold mb-1">{t('customers.view.phone')}</p>
                    <p className="font-semibold text-gray-900 dark:text-white ltr-value">{customer.phone}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                  <div className="p-3 bg-white dark:bg-gray-800 rounded-full shadow-sm flex-shrink-0">
                      <Building className="h-5 w-5 text-gray-500" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider font-semibold mb-1">{t('customers.view.company')}</p>
                    <p className="font-semibold text-gray-900 dark:text-white">{customer.company || 'N/A'}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-8 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] border-0">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">
                {t('customers.view.detailsTitle')}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                  <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider font-semibold mb-1">{t('customers.view.customerType')}</p>
                  <p className="font-semibold text-gray-900 dark:text-white">{getTypeLabel(customer.type)}</p>
                </div>
                <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                  <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider font-semibold mb-2">{t('customers.view.status')}</p>
                  <span className={`inline-flex px-3 py-1 text-xs font-bold rounded-full ${getStatusColor(customer.status)}`}>
                    {getStatusLabel(customer.status)}
                  </span>
                </div>
                <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                  <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider font-semibold mb-1">{t('customers.view.preferredContact')}</p>
                  <p className="font-semibold text-gray-900 dark:text-white">{getContactMethodLabel(customer.contactMethod)}</p>
                </div>
                <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                  <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider font-semibold mb-1">{t('customers.view.totalBookings')}</p>
                  <p className="font-semibold text-gray-900 dark:text-white bidi-isolate text-xl text-blue-600">{customer.totalBookings}</p>
                </div>
                <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                  <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider font-semibold mb-1">{t('customers.view.totalSpent')}</p>
                  <p className="font-semibold text-gray-900 dark:text-white bidi-isolate text-xl text-blue-600">{formatCurrency(totalSpent)}</p>
                </div>
                <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                  <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider font-semibold mb-1">{t('customers.view.lastTrip')}</p>
                  <p className="font-semibold text-gray-900 dark:text-white">
                    {customer.lastTrip ? <span className="bidi-isolate">{formatDate(customer.lastTrip)}</span> : t('customers.view.noTripsYet')}
                  </p>
                </div>
              </div>
            </div>

            {/* Booking History */}
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-8 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] border-0">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">
                {t('customers.view.bookingHistoryTitle')}
              </h3>
              <div className="space-y-4">
                {mockBookingHistory.map((booking) => (
                  <div key={booking.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-gray-100 dark:border-gray-800 hover:border-blue-100 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-blue-100/50 dark:bg-blue-900/30 rounded-xl">
                        <Calendar className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <p className="font-bold text-gray-900 dark:text-white">{booking.service}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{booking.destination}</p>
                        <p className="text-xs text-gray-400 bidi-isolate mt-1">{formatDate(booking.date)}</p>
                      </div>
                    </div>
                    <div className={cn(isRTL ? "text-left" : "text-right")}>
                      <p className="font-bold text-gray-900 dark:text-white bidi-isolate mb-2">{formatCurrency(booking.amount)}</p>
                      <span className="inline-flex px-3 py-1 text-xs font-bold rounded-full bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300">
                        {booking.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {customer.notes && (
              <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-8 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] border-0">
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                  {t('customers.view.notesTitle')}
                </h3>
                <div className="p-6 bg-yellow-50 dark:bg-yellow-900/10 rounded-2xl border border-yellow-100 dark:border-yellow-900/20">
                  <p className="text-yellow-800 dark:text-yellow-200/80 leading-relaxed font-medium">{customer.notes}</p>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Customer Stats */}
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] border-0">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">
                {t('customers.view.statsTitle')}
              </h3>
              <div className="space-y-5">
                <div className="flex items-center justify-between pb-4 border-b border-gray-100 dark:border-gray-800">
                  <span className="text-sm font-semibold text-gray-600 dark:text-gray-400">{t('customers.view.customerSince')}</span>
                  <span className="text-sm font-bold text-gray-900 dark:text-white bidi-isolate bg-gray-50 dark:bg-gray-800 px-3 py-1 rounded-lg">
                    {formatDate(customer.createdAt)}
                  </span>
                </div>
                <div className="flex items-center justify-between pb-4 border-b border-gray-100 dark:border-gray-800">
                  <span className="text-sm font-semibold text-gray-600 dark:text-gray-400">{t('customers.view.lifetimeValue')}</span>
                  <span className="text-sm font-bold text-blue-600 dark:text-blue-400 bidi-isolate bg-blue-50 dark:bg-blue-900/20 px-3 py-1 rounded-lg">
                    {formatCurrency(totalSpent)}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-gray-600 dark:text-gray-400">{t('customers.view.avgBookingValue')}</span>
                  <span className="text-sm font-bold text-gray-900 dark:text-white bidi-isolate bg-gray-50 dark:bg-gray-800 px-3 py-1 rounded-lg">
                    {formatCurrency(totalSpent / mockBookingHistory.length)}
                  </span>
                </div>
                {customer.status === 'VIP' && (
                  <div className="flex items-center justify-center gap-2 p-3 bg-gradient-to-r from-purple-100 to-fuchsia-100 dark:from-purple-900/30 dark:to-fuchsia-900/30 rounded-xl border border-purple-200 dark:border-purple-800/50 mt-4">
                    <Star className="h-5 w-5 text-purple-600 fill-purple-600" />
                    <span className="text-sm font-bold text-purple-800 dark:text-purple-300">{t('customers.view.vipBadge')}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] border-0">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">
                {t('customers.view.recentActivityTitle')}
              </h3>
              <div className="space-y-6 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-slate-300 before:to-transparent hidden-before">
                {mockActivityHistory.map((activity, i) => (
                  <div key={activity.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                    <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-100 group-[.is-active]:bg-blue-100 text-slate-500 group-[.is-active]:text-blue-500 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 ml-0">
                      {getActivityIcon(activity.type)}
                    </div>
                    <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded border border-slate-200 bg-white shadow-sm">
                      <div className="flex items-center justify-between space-x-2 mb-1">
                        <div className="font-bold text-slate-900">{activity.description}</div>
                        <time className="text-xs font-medium text-slate-500">{formatDate(activity.timestamp)}</time>
                      </div>
                      <div className="text-sm text-slate-500">{activity.details}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-3xl p-6 border-0">
              <h4 className="text-base font-bold text-blue-900 dark:text-blue-100 mb-4">
                {t('customers.view.quickActionsTitle')}
              </h4>
              <div className="space-y-3">
                <Button
                  onClick={() => handleAction('booking')}
                  className="w-full justify-start bg-white hover:bg-blue-600 text-blue-700 hover:text-white border-transparent shadow-sm transition-colors rounded-xl"
                  variant="outline"
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {t('customers.view.actionCreateBooking')}
                </Button>
                <Button
                  onClick={() => handleAction('email')}
                  className="w-full justify-start bg-white hover:bg-blue-600 text-blue-700 hover:text-white border-transparent shadow-sm transition-colors rounded-xl"
                  variant="outline"
                >
                  <Mail className="mr-2 h-4 w-4" />
                  {t('customers.view.actionSendEmail')}
                </Button>
                <Button
                  onClick={() => handleAction('call')}
                  className="w-full justify-start bg-white hover:bg-blue-600 text-blue-700 hover:text-white border-transparent shadow-sm transition-colors rounded-xl"
                  variant="outline"
                >
                  <Phone className="mr-2 h-4 w-4" />
                  {t('customers.view.actionScheduleCall')}
                </Button>
                <Button
                  onClick={() => handleAction('preferences')}
                  className="w-full justify-start bg-white hover:bg-blue-600 text-blue-700 hover:text-white border-transparent shadow-sm transition-colors rounded-xl"
                  variant="outline"
                >
                  <Star className="mr-2 h-4 w-4" />
                  {t('customers.view.actionUpdatePreferences')}
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Action Modals */}
        <MessageModal
          isOpen={isMessageModalOpen}
          onClose={() => setIsMessageModalOpen(false)}
          onSend={handleSendMessage}
          lead={{ // Reusing MessageModal which expects a 'lead' object
            name: customer.name,
            email: customer.email,
            phone: customer.phone
          }}
        />

        {/* UpdatePreferencesModal converted to UpdatePreferencesPage */}
      </div>
    </div>
  );
};