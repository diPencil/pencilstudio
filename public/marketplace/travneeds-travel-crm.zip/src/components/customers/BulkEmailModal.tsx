import React, { useState } from 'react';
import { X, Mail, Send, Clock, Users } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { Input } from '../ui/Input';
import { useLocale } from '../../localization/useLocale';
import { useToastContext } from '../../contexts/ToastContext';

interface BulkEmailModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BulkEmailModal: React.FC<BulkEmailModalProps> = ({ isOpen, onClose }) => {
  const { t, isRTL } = useLocale();
  const toast = useToastContext();
  const [emailData, setEmailData] = useState({
    subject: '',
    message: '',
    sendOption: 'now',
    scheduleDate: '',
    scheduleTime: ''
  });

  const [targetFilters, setTargetFilters] = useState({
    customerType: 'all',
    status: 'all',
    lastActivity: 'all',
    bookingHistory: 'all'
  });

  const [previewMode, setPreviewMode] = useState(false);

  const getEstimatedRecipients = () => {
    let count = 2847; // Total customers

    if (targetFilters.customerType !== 'all') count = Math.floor(count * 0.6);
    if (targetFilters.status !== 'all') count = Math.floor(count * 0.8);
    if (targetFilters.lastActivity !== 'all') count = Math.floor(count * 0.7);
    if (targetFilters.bookingHistory !== 'all') count = Math.floor(count * 0.5);

    return count;
  };

  const handleSend = () => {
    const campaignData = {
      ...emailData,
      filters: targetFilters,
      estimatedRecipients: getEstimatedRecipients()
    };

    // Simulate API sending
    setTimeout(() => {
      if (emailData.sendOption === 'now') {
        toast.success(
          isRTL ? 'تم إرسال الحملة' : 'Campaign Sent', 
          isRTL 
            ? `جاري معالجة إرسال حملة البريد الجماعي لـ ${campaignData.estimatedRecipients.toLocaleString()} مستلم.` 
            : `Your bulk email campaign is being processed for ${campaignData.estimatedRecipients.toLocaleString()} recipients.`
        );
      } else {
        toast.success(
          isRTL ? 'تم جدولة الحملة' : 'Campaign Scheduled', 
          isRTL 
            ? `تم جدولة حملة البريد الجماعي بنجاح بتاريخ ${emailData.scheduleDate} الساعة ${emailData.scheduleTime}.` 
            : `Your bulk email campaign has been scheduled for ${emailData.scheduleDate} at ${emailData.scheduleTime}.`
        );
      }
    }, 500);

    onClose();
  };

  const emailTemplates = React.useMemo(() => [
    {
      name: t('customers.bulkEmail.template.welcome.name'),
      subject: t('customers.bulkEmail.template.welcome.subject'),
      message: t('customers.bulkEmail.template.welcome.message')
    },
    {
      name: t('customers.bulkEmail.template.promo.name'),
      subject: t('customers.bulkEmail.template.promo.subject'),
      message: t('customers.bulkEmail.template.promo.message')
    },
    {
      name: t('customers.bulkEmail.template.reminder.name'),
      subject: t('customers.bulkEmail.template.reminder.subject'),
      message: t('customers.bulkEmail.template.reminder.message')
    }
  ], [t]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-4xl bg-white dark:bg-gray-800 rounded-lg shadow-xl">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-3">
              <Mail className="h-6 w-6 text-blue-500" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                {t('customers.bulkEmail.title')}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <div className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Email Content */}
              <div className="lg:col-span-2 space-y-6">
                {/* Email Templates */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                    {t('customers.bulkEmail.templates')}
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {emailTemplates.map((template, index) => (
                      <button
                        key={index}
                        onClick={() => setEmailData(prev => ({
                          ...prev,
                          subject: template.subject,
                          message: template.message
                        }))}
                        className="p-3 text-left rtl:text-right border border-gray-200 dark:border-gray-600 rounded-lg hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                      >
                        <div className="font-medium text-sm text-gray-900 dark:text-white">
                          {template.name}
                        </div>
                        <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                          {template.subject}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Email Form */}
                <div className="space-y-4">
                  <Input
                    label={t('customers.bulkEmail.subject')}
                    value={emailData.subject}
                    onChange={(e) => setEmailData(prev => ({ ...prev, subject: e.target.value }))}
                    placeholder={t('customers.bulkEmail.subjectPlaceholder')}
                  />

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      {t('customers.bulkEmail.message')}
                    </label>
                    <textarea
                      value={emailData.message}
                      onChange={(e) => setEmailData(prev => ({ ...prev, message: e.target.value }))}
                      rows={8}
                      className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder={t('customers.bulkEmail.messagePlaceholder')}
                    />
                  </div>

                  {/* Send Options */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                      {t('customers.bulkEmail.sendOptions')}
                    </label>
                    <div className="space-y-3">
                      <label className="flex items-center">
                        <input
                          type="radio"
                          value="now"
                          checked={emailData.sendOption === 'now'}
                          onChange={(e) => setEmailData(prev => ({ ...prev, sendOption: e.target.value }))}
                          className={isRTL ? "ml-3" : "mr-3"}
                        />
                        <span className="text-sm text-gray-700 dark:text-gray-300">{t('customers.bulkEmail.sendNow')}</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          value="schedule"
                          checked={emailData.sendOption === 'schedule'}
                          onChange={(e) => setEmailData(prev => ({ ...prev, sendOption: e.target.value }))}
                          className={isRTL ? "ml-3" : "mr-3"}
                        />
                        <span className="text-sm text-gray-700 dark:text-gray-300">{t('customers.bulkEmail.scheduleLater')}</span>
                      </label>
                    </div>

                    {emailData.sendOption === 'schedule' && (
                      <div className="grid grid-cols-2 gap-3 mt-3">
                        <Input
                          type="date"
                          label={t('customers.bulkEmail.scheduleDate')}
                          value={emailData.scheduleDate}
                          onChange={(e) => setEmailData(prev => ({ ...prev, scheduleDate: e.target.value }))}
                          min={new Date().toISOString().split('T')[0]}
                        />
                        <Input
                          type="time"
                          label={t('customers.bulkEmail.scheduleTime')}
                          value={emailData.scheduleTime}
                          onChange={(e) => setEmailData(prev => ({ ...prev, scheduleTime: e.target.value }))}
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Target Audience */}
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    {t('customers.bulkEmail.targetAudience')}
                  </h3>

                  <div className="space-y-4">
                    <Select
                      label={t('customers.bulkEmail.customerType')}
                      value={targetFilters.customerType}
                      onChange={(e) => setTargetFilters(prev => ({ ...prev, customerType: e.target.value }))}
                    >
                      <option value="all">{t('customers.filter.allTypes')}</option>
                      <option value="Individual">{t('customers.filter.individual')}</option>
                      <option value="Family/Group">{t('customers.form.familyGroup')}</option>
                      <option value="Corporate">{t('customers.filter.corporate')}</option>
                    </Select>

                    <Select
                      label={t('customers.bulkEmail.status')}
                      value={targetFilters.status}
                      onChange={(e) => setTargetFilters(prev => ({ ...prev, status: e.target.value }))}
                    >
                      <option value="all">{t('customers.filter.allStatus')}</option>
                      <option value="Active">{t('customers.status.active')}</option>
                      <option value="VIP">{t('customers.status.vip')}</option>
                      <option value="Recurring">{t('customers.status.recurring')}</option>
                    </Select>

                    <Select
                      label={t('customers.bulkEmail.lastActivity')}
                      value={targetFilters.lastActivity}
                      onChange={(e) => setTargetFilters(prev => ({ ...prev, lastActivity: e.target.value }))}
                    >
                      <option value="all">{t('customers.bulkEmail.lastActivity.any')}</option>
                      <option value="week">{t('customers.bulkEmail.lastActivity.week')}</option>
                      <option value="month">{t('customers.bulkEmail.lastActivity.month')}</option>
                      <option value="quarter">{t('customers.bulkEmail.lastActivity.quarter')}</option>
                    </Select>

                    <Select
                      label={t('customers.bulkEmail.bookingHistory')}
                      value={targetFilters.bookingHistory}
                      onChange={(e) => setTargetFilters(prev => ({ ...prev, bookingHistory: e.target.value }))}
                    >
                      <option value="all">{t('customers.bulkEmail.bookingHistory.all')}</option>
                      <option value="has_bookings">{t('customers.bulkEmail.bookingHistory.has')}</option>
                      <option value="no_bookings">{t('customers.bulkEmail.bookingHistory.none')}</option>
                      <option value="recent_bookings">{t('customers.bulkEmail.bookingHistory.recent')}</option>
                    </Select>
                  </div>
                </div>

                {/* Estimated Recipients */}
                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="h-5 w-5 text-blue-500" />
                    <h4 className="text-sm font-medium text-blue-800 dark:text-blue-300">
                      {t('customers.bulkEmail.estimated')}
                    </h4>
                  </div>
                  <div className="text-2xl font-bold text-blue-800 dark:text-blue-300 bidi-isolate">
                    {getEstimatedRecipients().toLocaleString()}
                  </div>
                  <div className="text-sm text-blue-600 dark:text-blue-400">
                    {t('customers.bulkEmail.estimatedDesc')}
                  </div>
                </div>

                {/* Preview Button */}
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => setPreviewMode(!previewMode)}
                >
                  {previewMode ? t('customers.bulkEmail.hidePreviewBtn') : t('customers.bulkEmail.previewBtn')}
                </Button>

                {previewMode && (
                  <div className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 bg-gray-50 dark:bg-gray-700">
                    <div className="text-sm font-medium text-gray-900 dark:text-white mb-2">
                      {t('customers.bulkEmail.previewSubject')}: {emailData.subject || (isRTL ? 'بدون عنوان' : 'No subject')}
                    </div>
                    <div className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                      {emailData.message || (isRTL ? 'بدون محتوى' : 'No message content')}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700">
            <Button variant="outline" onClick={onClose}>
              {t('customers.bulkEmail.cancel')}
            </Button>
            <Button onClick={handleSend} disabled={!emailData.subject || !emailData.message}>
              {emailData.sendOption === 'now' ? (
                <>
                  <Send className="h-4 w-4 mr-2 ml-2" />
                  {t('customers.bulkEmail.sendAction')}
                </>
              ) : (
                <>
                  <Clock className="h-4 w-4 mr-2 ml-2" />
                  {t('customers.bulkEmail.scheduleAction')}
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};