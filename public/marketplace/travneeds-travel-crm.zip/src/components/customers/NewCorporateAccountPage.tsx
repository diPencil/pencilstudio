import React, { useState } from 'react';
import { Save, Building, ArrowLeft } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { useLocale } from '../../localization/useLocale';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';

export const NewCorporateAccountPage: React.FC = () => {
    const { t, isRTL } = useLocale();
    const navigate = useNavigate();
    const toast = useToastContext();

    const statuses = React.useMemo(() => [
        { value: 'Active', label: t('customers.status.active') },
        { value: 'VIP', label: t('customers.status.vip') },
        { value: 'Suspended', label: t('customers.status.suspended') }
    ], [t]);

    const accountManagers = React.useMemo(() => [
        { value: 'Super Admin', label: isRTL ? 'المشرف العام' : 'Super Admin' },
        { value: 'Mahmoud Khalil', label: isRTL ? 'محمود خليل' : 'Mahmoud Khalil' },
        { value: 'Layla Ramadan', label: isRTL ? 'ليلى رمضان' : 'Layla Ramadan' },
        { value: 'Sami Youssef', label: isRTL ? 'سامي يوسف' : 'Sami Youssef' },
        { value: 'Mona Zaki', label: isRTL ? 'منى زكي' : 'Mona Zaki' }
    ], [isRTL]);

    const [formData, setFormData] = useState({
        companyName: '',
        primaryContactName: '',
        primaryContactEmail: '',
        primaryContactPhone: '',
        accountManager: 'Super Admin',
        status: 'Active',
        contractValue: '',
        contractDate: '',
        renewalDate: '',
        notes: ''
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(false);

    const validateForm = () => {
        const newErrors: Record<string, string> = {};

        if (!formData.companyName.trim()) {
            newErrors.companyName = t('customers.addCorp.validation.companyName');
        }

        if (!formData.primaryContactName.trim()) {
            newErrors.primaryContactName = t('customers.addCorp.validation.contactName');
        }

        if (!formData.primaryContactEmail.trim()) {
            newErrors.primaryContactEmail = t('customers.addCorp.validation.contactEmail');
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.primaryContactEmail)) {
            newErrors.primaryContactEmail = t('customers.addCorp.validation.contactEmailInvalid');
        }

        if (!formData.primaryContactPhone.trim()) {
            newErrors.primaryContactPhone = t('customers.addCorp.validation.contactPhone');
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!validateForm()) {
            return;
        }

        setIsLoading(true);
        try {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 500));
            toast.success(isRTL ? 'تم إنشاء الحساب' : 'Account Created', isRTL ? 'تم إنشاء حساب الشركة بنجاح.' : 'Corporate account created successfully.');
            navigate('/customers/corporate');
        } catch (error) {
            console.error('Error adding corporate account:', error);
            toast.error(isRTL ? 'حدث خطأ' : 'Error', isRTL ? 'فشل إنشاء الحساب.' : 'Failed to create account.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleInputChange = (field: string, value: string) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        if (errors[field]) {
            setErrors(prev => ({ ...prev, [field]: '' }));
        }
    };

    return (
        <div className="w-full pb-8" dir={isRTL ? 'rtl' : 'ltr'}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center gap-4">
                        <Button variant="outline" onClick={() => navigate('/customers/corporate')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                            <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
                        </Button>
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-white/10 rounded-xl">
                                <Building className="h-6 w-6 text-white" />
                            </div>
                            <div>
                                <h1 className="text-2xl font-bold">
                                    {t('customers.addCorp.title')}
                                </h1>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] border-0 overflow-hidden">
                    <form onSubmit={handleSubmit} className="p-6 sm:p-8">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="md:col-span-2">
                                <Input
                                    label={t('customers.addCorp.companyName')}
                                    value={formData.companyName}
                                    onChange={(e) => handleInputChange('companyName', e.target.value)}
                                    error={errors.companyName}
                                    placeholder={t('customers.addCorp.companyNamePlaceholder')}
                                    className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl"
                                />
                            </div>

                            <Input
                                label={t('customers.addCorp.contactName')}
                                value={formData.primaryContactName}
                                onChange={(e) => handleInputChange('primaryContactName', e.target.value)}
                                error={errors.primaryContactName}
                                placeholder={t('customers.addCorp.contactNamePlaceholder')}
                                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl"
                            />

                            <Input
                                label={t('customers.addCorp.contactEmail')}
                                type="email"
                                value={formData.primaryContactEmail}
                                onChange={(e) => handleInputChange('primaryContactEmail', e.target.value)}
                                error={errors.primaryContactEmail}
                                placeholder={t('customers.addCorp.contactEmailPlaceholder')}
                                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl"
                            />

                            <Input
                                label={t('customers.addCorp.contactPhone')}
                                value={formData.primaryContactPhone}
                                onChange={(e) => handleInputChange('primaryContactPhone', e.target.value)}
                                error={errors.primaryContactPhone}
                                placeholder={t('customers.addCorp.contactPhonePlaceholder')}
                                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl"
                            />

                            <Select
                                label={t('customers.addCorp.accountManager')}
                                value={formData.accountManager}
                                onChange={(e) => handleInputChange('accountManager', e.target.value)}
                                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl h-12"
                            >
                                {accountManagers.map(manager => (
                                    <option key={manager.value} value={manager.value}>{manager.label}</option>
                                ))}
                            </Select>

                            <Select
                                label={t('customers.addCorp.status')}
                                value={formData.status}
                                onChange={(e) => handleInputChange('status', e.target.value)}
                                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl h-12"
                            >
                                {statuses.map(st => (
                                    <option key={st.value} value={st.value}>{st.label}</option>
                                ))}
                            </Select>

                            <Input
                                label={t('customers.addCorp.contractValue')}
                                type="number"
                                value={formData.contractValue}
                                onChange={(e) => handleInputChange('contractValue', e.target.value)}
                                placeholder={t('customers.addCorp.contractValuePlaceholder')}
                                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl"
                            />

                            <Input
                                label={t('customers.addCorp.contractDate')}
                                type="date"
                                value={formData.contractDate}
                                onChange={(e) => handleInputChange('contractDate', e.target.value)}
                                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl"
                            />

                            <Input
                                label={t('customers.addCorp.renewalDate')}
                                type="date"
                                value={formData.renewalDate}
                                onChange={(e) => handleInputChange('renewalDate', e.target.value)}
                                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl"
                            />
                        </div>

                        <div className="mt-6">
                            <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                                {t('customers.addCorp.notes')}
                            </label>
                            <textarea
                                value={formData.notes}
                                onChange={(e) => handleInputChange('notes', e.target.value)}
                                rows={4}
                                className="block w-full px-4 py-3 border border-gray-200 dark:border-gray-700 rounded-2xl shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-gray-50 dark:bg-gray-800/50 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                                placeholder={t('customers.addCorp.notesPlaceholder')}
                            />
                        </div>

                        <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-gray-100 dark:border-gray-800">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => navigate('/customers/corporate')}
                                disabled={isLoading}
                                className="rounded-xl border-gray-200 dark:border-gray-700"
                            >
                                {t('customers.addCorp.cancel')}
                            </Button>
                            <Button
                                type="submit"
                                disabled={isLoading}
                                loading={isLoading}
                                className="rounded-xl"
                            >
                                <Save className="h-4 w-4 mr-2 ml-2" />
                                {t('customers.addCorp.addAction')}
                            </Button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};
