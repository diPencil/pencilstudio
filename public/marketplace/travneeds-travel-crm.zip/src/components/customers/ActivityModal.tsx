import React, { useState } from 'react';
import { X, Save, Phone, Mail, MessageSquare, Calendar } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { useLocale } from '../../localization/useLocale';

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  type: string;
  status: string;
}

interface ActivityData {
  type: string;
  subject: string;
  description: string;
  outcome: string;
  followUpRequired: boolean;
  followUpDate: string;
  customerId: string;
  customerName: string;
  timestamp: string;
  user: string;
}

interface ActivityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (activityData: ActivityData) => Promise<void>;
  customer: Customer;
}

export const ActivityModal: React.FC<ActivityModalProps> = ({ isOpen, onClose, onSave, customer }) => {
  const { t, isRTL } = useLocale();

  const activityTypes = React.useMemo(() => [
    { value: 'call', label: t('customers.activity.type.call'), icon: Phone },
    { value: 'email', label: t('customers.activity.type.email'), icon: Mail },
    { value: 'meeting', label: t('customers.activity.type.meeting'), icon: Calendar },
    { value: 'note', label: t('customers.activity.type.note'), icon: MessageSquare }
  ], [t]);

  const [formData, setFormData] = useState({
    type: 'call',
    subject: '',
    description: '',
    outcome: '',
    followUpRequired: false,
    followUpDate: ''
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.subject.trim() || !formData.description.trim()) {
      return;
    }

    setIsLoading(true);
    try {
      const activityData = {
        ...formData,
        customerId: customer.id,
        customerName: customer.name,
        timestamp: new Date().toISOString(),
        user: isRTL ? 'المستخدم الحالي' : 'Current User'
      };

      await onSave(activityData);
      
      // Reset form
      setFormData({
        type: 'call',
        subject: '',
        description: '',
        outcome: '',
        followUpRequired: false,
        followUpDate: ''
      });
      onClose();
    } catch (error) {
      console.error('Error logging activity:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const selectedActivityType = activityTypes.find(type => type.value === formData.type);
  const ActivityIcon = selectedActivityType?.icon || MessageSquare;

  if (!isOpen || !customer) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-lg bg-white dark:bg-gray-800 rounded-lg shadow-xl">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-3">
              <ActivityIcon className="h-6 w-6 text-blue-500" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                {t('customers.activity.logTitle')} - {customer.name}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6">
            <div className="space-y-6">
              <Select
                label={t('customers.activity.type')}
                value={formData.type}
                onChange={(e) => handleInputChange('type', e.target.value)}
              >
                {activityTypes.map(type => (
                  <option key={type.value} value={type.value}>{type.label}</option>
                ))}
              </Select>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('customers.activity.subject')} *
                </label>
                <input
                  type="text"
                  value={formData.subject}
                  onChange={(e) => handleInputChange('subject', e.target.value)}
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder={t('customers.activity.subjectPlaceholder')}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('customers.activity.description')} *
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  rows={4}
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder={t('customers.activity.descriptionPlaceholder')}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('customers.activity.outcome')}
                </label>
                <textarea
                  value={formData.outcome}
                  onChange={(e) => handleInputChange('outcome', e.target.value)}
                  rows={3}
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder={t('customers.activity.outcomePlaceholder')}
                />
              </div>

              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="followUpRequired"
                  checked={formData.followUpRequired}
                  onChange={(e) => handleInputChange('followUpRequired', e.target.checked)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label htmlFor="followUpRequired" className="text-sm text-gray-700 dark:text-gray-300">
                  {t('customers.activity.followUpRequired')}
                </label>
              </div>

              {formData.followUpRequired && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    {t('customers.activity.followUpDate')}
                  </label>
                  <input
                    type="date"
                    value={formData.followUpDate}
                    onChange={(e) => handleInputChange('followUpDate', e.target.value)}
                    className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min={new Date().toISOString().split('T')[0]}
                  />
                </div>
              )}
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 mt-6">
              <div className="flex items-start gap-3">
                <ActivityIcon className="h-5 w-5 text-blue-500 mt-0.5" />
                <div>
                  <h4 className="text-sm font-medium text-blue-800 dark:text-blue-300">
                    {t('customers.activity.customerInfo')}
                  </h4>
                  <p className="text-sm text-blue-700 dark:text-blue-400 mt-1">
                    {customer.name} • <span className="bidi-isolate">{customer.email}</span> • <span className="ltr-value">{customer.phone}</span>
                  </p>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isLoading}
              >
                {t('customers.activity.cancel')}
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                loading={isLoading}
              >
                <Save className="h-4 w-4 mr-2 ml-2" />
                {t('customers.activity.logAction')}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};