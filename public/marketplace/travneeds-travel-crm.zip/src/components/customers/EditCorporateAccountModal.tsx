import React, { useState, useEffect } from 'react';
import { X, Save, Building } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { useLocale } from '../../localization/useLocale';
interface CorporateAccount {
  id: string;
  companyName: string;
  primaryContact: string;
  email: string;
  phone: string;
  customerCount: number;
  totalBookings: number;
  totalRevenue: number;
  lastBooking: string;
  status: string;
  accountManager: string;
  contractValue: number;
  contractDate: string;
  renewalDate: string;
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
}

interface EditCorporateAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (accountData: CorporateAccount) => Promise<void>;
  account: CorporateAccount | null;
}

export const EditCorporateAccountModal: React.FC<EditCorporateAccountModalProps> = ({ isOpen, onClose, onSave, account }) => {
  const { t, isRTL } = useLocale();

  const statuses = React.useMemo(() => [
    { value: 'Active', label: t('customers.status.active') },
    { value: 'VIP', label: t('customers.status.vip') },
    { value: 'Suspended', label: t('customers.status.suspended') }
  ], [t]);

  const accountManagers = React.useMemo(() => [
    { value: 'Super Admin', label: isRTL ? 'المشرف العام' : 'Super Admin' },
    { value: 'Mahmoud Khalil', label: isRTL ? 'محمود خليل' : 'Mahmoud Khalil' },
    { value: 'Layla Ramadan', label: isRTL ? 'ليلى رمضان' : 'Layla Ramadan' },
    { value: 'Sami Youssef', label: isRTL ? 'سامي يوسف' : 'Sami Youssef' },
    { value: 'Mona Zaki', label: isRTL ? 'منى زكي' : 'Mona Zaki' }
  ], [isRTL]);

  const [formData, setFormData] = useState({
    companyName: '',
    primaryContactName: '',
    primaryContactEmail: '',
    primaryContactPhone: '',
    accountManager: 'Super Admin',
    status: 'Active',
    contractValue: '',
    contractDate: '',
    renewalDate: '',
    notes: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (account && isOpen) {
      setFormData({
        companyName: account.companyName || '',
        primaryContactName: account.primaryContact || '',
        primaryContactEmail: account.email || '',
        primaryContactPhone: account.phone || '',
        accountManager: account.accountManager || 'Super Admin',
        status: account.status || 'Active',
        contractValue: account.contractValue || '',
        contractDate: account.contractDate || '',
        renewalDate: account.renewalDate || '',
        notes: account.notes || ''
      });
    }
  }, [account, isOpen]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.companyName.trim()) {
      newErrors.companyName = t('customers.addCorp.validation.companyName');
    }

    if (!formData.primaryContactName.trim()) {
      newErrors.primaryContactName = t('customers.addCorp.validation.contactName');
    }

    if (!formData.primaryContactEmail.trim()) {
      newErrors.primaryContactEmail = t('customers.addCorp.validation.contactEmail');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.primaryContactEmail)) {
      newErrors.primaryContactEmail = t('customers.addCorp.validation.contactEmailInvalid');
    }

    if (!formData.primaryContactPhone.trim()) {
      newErrors.primaryContactPhone = t('customers.addCorp.validation.contactPhone');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    try {
      const updatedAccount = {
        ...account,
        companyName: formData.companyName,
        primaryContact: formData.primaryContactName,
        email: formData.primaryContactEmail,
        phone: formData.primaryContactPhone,
        accountManager: formData.accountManager,
        status: formData.status,
        contractValue: parseFloat(formData.contractValue) || 0,
        contractDate: formData.contractDate,
        renewalDate: formData.renewalDate,
        notes: formData.notes,
        updatedAt: new Date().toISOString()
      };

      await onSave(updatedAccount);
      onClose();
    } catch (error) {
      console.error('Error updating corporate account:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  if (!isOpen || !account) return null;

  return (
    <div className="fixed inset-0 z-[70] overflow-y-auto" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-2xl bg-white dark:bg-gray-800 rounded-lg shadow-xl max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-3">
              <Building className="h-6 w-6 text-blue-500" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                {t('customers.editCorp.title')} - {account.companyName}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <Input
                  label={t('customers.addCorp.companyName')}
                  value={formData.companyName}
                  onChange={(e) => handleInputChange('companyName', e.target.value)}
                  error={errors.companyName}
                  placeholder={t('customers.addCorp.companyNamePlaceholder')}
                />
              </div>

              <Input
                label={t('customers.addCorp.contactName')}
                value={formData.primaryContactName}
                onChange={(e) => handleInputChange('primaryContactName', e.target.value)}
                error={errors.primaryContactName}
                placeholder={t('customers.addCorp.contactNamePlaceholder')}
              />

              <Input
                label={t('customers.addCorp.contactEmail')}
                type="email"
                value={formData.primaryContactEmail}
                onChange={(e) => handleInputChange('primaryContactEmail', e.target.value)}
                error={errors.primaryContactEmail}
                placeholder={t('customers.addCorp.contactEmailPlaceholder')}
              />

              <Input
                label={t('customers.addCorp.contactPhone')}
                value={formData.primaryContactPhone}
                onChange={(e) => handleInputChange('primaryContactPhone', e.target.value)}
                error={errors.primaryContactPhone}
                placeholder={t('customers.addCorp.contactPhonePlaceholder')}
              />

              <Select
                label={t('customers.addCorp.accountManager')}
                value={formData.accountManager}
                onChange={(e) => handleInputChange('accountManager', e.target.value)}
              >
                {accountManagers.map(manager => (
                  <option key={manager.value} value={manager.value}>{manager.label}</option>
                ))}
              </Select>

              <Select
                label={t('customers.addCorp.status')}
                value={formData.status}
                onChange={(e) => handleInputChange('status', e.target.value)}
              >
                {statuses.map(st => (
                  <option key={st.value} value={st.value}>{st.label}</option>
                ))}
              </Select>

              <Input
                label={t('customers.addCorp.contractValue')}
                type="number"
                value={formData.contractValue}
                onChange={(e) => handleInputChange('contractValue', e.target.value)}
                placeholder={t('customers.addCorp.contractValuePlaceholder')}
              />

              <Input
                label={t('customers.addCorp.contractDate')}
                type="date"
                value={formData.contractDate}
                onChange={(e) => handleInputChange('contractDate', e.target.value)}
              />

              <Input
                label={t('customers.addCorp.renewalDate')}
                type="date"
                value={formData.renewalDate}
                onChange={(e) => handleInputChange('renewalDate', e.target.value)}
              />
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('customers.addCorp.notes')}
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                rows={4}
                className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder={t('customers.addCorp.notesPlaceholder')}
              />
            </div>

            <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isLoading}
              >
                {t('customers.addCorp.cancel')}
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                loading={isLoading}
              >
                <Save className="h-4 w-4 mr-2 ml-2" />
                {t('customers.editCorp.saveAction')}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};