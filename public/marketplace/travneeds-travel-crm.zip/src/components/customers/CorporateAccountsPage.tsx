import React, { useState } from 'react';
import { Building, Users, DollarSign, Eye, Edit, Plus, Search, TrendingUp, Calendar } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card, CardContent } from '../ui/Card';
import { Input } from '../ui/Input';
import { formatCurrency } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import type { TranslationKey } from '../../localization/messages/en';
import { cn } from '../../utils/cn';
import { useNavigate } from 'react-router-dom';

export interface CorporateAccount {
    id: string;
    companyName: string;
    primaryContact: string;
    email: string;
    phone: string;
    customerCount: number;
    totalBookings: number;
    totalRevenue: number;
    lastBooking: string;
    status: string;
    accountManager: string;
    contractValue: number;
    contractDate: string;
    renewalDate: string;
}

const mockCorporateAccounts: CorporateAccount[] = [
    {
        id: 'CORP-001',
        companyName: 'TechCorp Solutions',
        primaryContact: 'Youssef Ahmed',
        email: 'youssef@techcorp.com',
        phone: '+1-555-123-4567',
        customerCount: 24,
        totalBookings: 156,
        totalRevenue: 89500,
        lastBooking: '2025-01-10',
        status: 'VIP',
        accountManager: 'Mahmoud Khalil',
        contractValue: 120000,
        contractDate: '2024-01-01',
        renewalDate: '2025-12-31'
    },
    {
        id: 'CORP-002',
        companyName: 'Global Marketing Inc',
        primaryContact: 'Sara Mansour',
        email: 'sara@globalmarketing.com',
        phone: '+1-555-987-6543',
        customerCount: 18,
        totalBookings: 89,
        totalRevenue: 45200,
        lastBooking: '2025-01-08',
        status: 'Active',
        accountManager: 'Layla Ramadan',
        contractValue: 60000,
        contractDate: '2024-05-15',
        renewalDate: '2025-08-15'
    }
];

export const CorporateAccountsPage: React.FC = () => {
    const { t, isRTL } = useLocale();
    const navigate = useNavigate();
    const [searchTerm, setSearchTerm] = useState('');
    const [accounts, setAccounts] = useState<CorporateAccount[]>(mockCorporateAccounts);

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'VIP': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300';
            case 'Active': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
            default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
        }
    };

    const getStatusKey = (status: string): TranslationKey => {
        return status === 'VIP' ? 'customers.status.vip' : 'customers.status.active';
    };

    const handleViewAccount = (account: CorporateAccount) => {
        navigate('/customers/corporate/view', { state: { account } });
    };

    const handleEditAccount = (account: CorporateAccount) => {
        navigate('/customers/corporate/edit', { state: { account } });
    };

    const filteredAccounts = accounts.filter(account =>
        account.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        account.primaryContact.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const metrics = {
        total: accounts.length,
        revenue: accounts.reduce((sum, a) => sum + a.totalRevenue, 0),
        employees: accounts.reduce((sum, a) => sum + a.customerCount, 0),
        bookings: accounts.reduce((sum, a) => sum + a.totalBookings, 0)
    };

    return (
        <div className="w-full pb-8" dir={isRTL ? 'rtl' : 'ltr'}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-white/10 rounded-2xl">
                            <Building className="h-8 w-8 text-white" />
                        </div>
                        <div>
                            <h1 className="text-2xl sm:text-3xl font-bold">
                                {t('customers.corporate.title')}
                            </h1>
                            <p className="text-blue-100 mt-1 text-sm sm:text-base">
                                {t('customers.corporate.subtitle')}
                            </p>
                        </div>
                    </div>
                    <Button onClick={() => navigate('/customers/corporate/new')} className="mt-4 sm:mt-0 bg-white text-blue-600 hover:bg-blue-50 border-transparent shadow-sm">
                        <Plus className={cn("h-5 w-5", isRTL ? "ml-2" : "mr-2")} />
                        {t('customers.corporate.newAccount')}
                    </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                        <CardContent className="p-6">
                            <div className="flex flex-col relative z-10">
                                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">{t('customers.corporate.activeAccounts')}</p>
                                <p className="text-3xl font-bold text-gray-900 dark:text-white bidi-isolate">{metrics.total}</p>
                            </div>
                            <Building className="absolute -right-4 -bottom-4 h-24 w-24 text-blue-500/10 group-hover:scale-110 transition-transform duration-300" />
                        </CardContent>
                    </Card>

                    <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                        <CardContent className="p-6">
                            <div className="flex flex-col relative z-10">
                                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">{t('customers.corporate.totalRevenue')}</p>
                                <p className="text-3xl font-bold text-gray-900 dark:text-white bidi-isolate">{formatCurrency(metrics.revenue)}</p>
                            </div>
                            <DollarSign className="absolute -right-4 -bottom-4 h-24 w-24 text-emerald-500/10 group-hover:scale-110 transition-transform duration-300" />
                        </CardContent>
                    </Card>

                    <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                        <CardContent className="p-6">
                            <div className="flex flex-col relative z-10">
                                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">{t('customers.corporate.linkedEmployees')}</p>
                                <p className="text-3xl font-bold text-gray-900 dark:text-white bidi-isolate">{metrics.employees}</p>
                            </div>
                            <Users className="absolute -right-4 -bottom-4 h-24 w-24 text-purple-500/10 group-hover:scale-110 transition-transform duration-300" />
                        </CardContent>
                    </Card>

                    <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                        <CardContent className="p-6">
                            <div className="flex flex-col relative z-10">
                                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">{t('customers.corporate.volume')}</p>
                                <p className="text-3xl font-bold text-gray-900 dark:text-white bidi-isolate">
                                    {metrics.bookings} <span className="text-sm font-normal text-gray-500">{t('customers.corporate.bookings')}</span>
                                </p>
                            </div>
                            <Calendar className="absolute -right-4 -bottom-4 h-24 w-24 text-amber-500/10 group-hover:scale-110 transition-transform duration-300" />
                        </CardContent>
                    </Card>
                </div>

                <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] border-0 p-6">
                    <div className="relative max-w-md mb-6">
                        <Search className={cn("absolute top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400", isRTL ? "right-4" : "left-4")} />
                        <Input
                            placeholder={t('customers.corporate.searchPlaceholder')}
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className={cn(
                                "bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl h-12 text-base",
                                isRTL ? "pr-12" : "pl-12"
                            )}
                        />
                    </div>

                    <div className="overflow-x-auto rounded-2xl border border-gray-100 dark:border-gray-800">
                        <table className="w-full text-left rtl:text-right border-collapse">
                            <thead>
                                <tr className="bg-gray-50 dark:bg-gray-800/50 border-b border-gray-100 dark:border-gray-800">
                                    <th className="p-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('customers.corporate.company')}</th>
                                    <th className="p-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('customers.corporate.contact')}</th>
                                    <th className="p-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('customers.corporate.employees')}</th>
                                    <th className="p-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('customers.corporate.volume')}</th>
                                    <th className="p-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('customers.corporate.revenue')}</th>
                                    <th className="p-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('customers.table.status')}</th>
                                    <th className="p-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider text-right">{t('customers.table.actions')}</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                                {filteredAccounts.map((account) => (
                                    <tr key={account.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-800/50 transition-colors">
                                        <td className="p-4">
                                            <div className="font-bold text-gray-900 dark:text-white">{account.companyName}</div>
                                            <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest bidi-isolate">{account.id}</div>
                                        </td>
                                        <td className="p-4">
                                            <div className="text-sm font-semibold">{account.primaryContact}</div>
                                            <div className="text-xs text-gray-500 bidi-isolate">{account.email}</div>
                                        </td>
                                        <td className="p-4"><div className="text-sm font-bold bidi-isolate bg-gray-50 dark:bg-gray-800 inline-block px-3 py-1 rounded-lg">{account.customerCount}</div></td>
                                        <td className="p-4"><div className="text-sm font-bold bidi-isolate bg-gray-50 dark:bg-gray-800 inline-block px-3 py-1 rounded-lg">{account.totalBookings}</div></td>
                                        <td className="p-4">
                                            <div className="text-sm font-bold text-emerald-600 bidi-isolate">{formatCurrency(account.totalRevenue)}</div>
                                            <div className="text-[10px] font-semibold text-gray-400 bidi-isolate mt-1">{t('customers.corporate.limit')}: {formatCurrency(account.contractValue)}</div>
                                        </td>
                                        <td className="p-4">
                                            <span className={`inline-flex px-3 py-1 text-xs font-bold rounded-full ${getStatusColor(account.status)}`}>
                                                {t(getStatusKey(account.status))}
                                            </span>
                                        </td>
                                        <td className="p-4 text-right">
                                            <TableActionsDropdown
                                                actions={[
                                                    { label: t('common.view'), icon: Eye, onClick: () => handleViewAccount(account) },
                                                    { label: t('common.edit'), icon: Edit, onClick: () => handleEditAccount(account) }
                                                ]}
                                            />
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};
