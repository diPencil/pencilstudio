import React, { useState, useEffect } from 'react';
import { Plus, Search, Eye, Edit, Calendar, Users, TrendingUp, Activity, Star, Download, Mail, Phone, ListChecks, Building2, FileText } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { PageHeader } from '../ui/PageHeader';
import { StatCard } from '../ui/StatCard';
import { StatusBadge } from '../ui/StatusBadge';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
// BookingModal, ActivityModal, ExportModal replaced
// BulkEmailModal replaced by BulkEmailPage
import { useToastContext } from '../../contexts/ToastContext';
import { mockCustomers } from '../../services/mockData';
import { useLocale } from '../../localization/useLocale';
import type { TranslationKey } from '../../localization/messages/en';
import { cn } from '../../utils/cn';

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  type: string;
  status: string;
  totalBookings: number;
  totalSpent: number;
  nationality?: string;
  assignedStaff?: string;
  notes?: string;
}

export const CustomersPage: React.FC = () => {
    const { t, isRTL } = useLocale();
    const toast = useToastContext();
    const location = useLocation();
    const navigate = useNavigate();
    const [customers, setCustomers] = useState<Customer[]>(mockCustomers as Customer[]);
    const [searchTerm, setSearchTerm] = useState('');
    const [typeFilter, setTypeFilter] = useState('All Types');
    const [statusFilter, setStatusFilter] = useState('All Status');

    // All modal states replaced by navigation/toast
    const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

    useEffect(() => {
        if (location.state && (location.state as { openModal?: string }).openModal === 'add') {
            navigate('/customers/new');
        }
    }, [location.state, navigate]);

    const getStatusVariant = (status: string): "emerald" | "purple" | "blue" | "rose" | "gray" => {
        switch (status) {
            case 'Active': return 'emerald';
            case 'VIP': return 'purple';
            case 'Recurring': return 'blue';
            case 'Suspended': return 'rose';
            default: return 'gray';
        }
    };

    const getStatusKey = (status: string): TranslationKey => {
        switch (status) {
            case 'Active': return 'customers.status.active';
            case 'VIP': return 'customers.status.vip';
            case 'Recurring': return 'customers.status.recurring';
            case 'Suspended': return 'customers.status.suspended';
            default: return 'customers.status.active';
        }
    };

    const getTypeKey = (type: string): TranslationKey => {
        return type === 'Corporate' ? 'customers.filter.corporate' : 'customers.filter.individual';
    };

    const filteredCustomers = customers.filter(customer => {
        const matchesSearch = customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            customer.email.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesType = typeFilter === 'All Types' || customer.type === typeFilter;
        const matchesStatus = statusFilter === 'All Status' || customer.status === statusFilter;
        return matchesSearch && matchesType && matchesStatus;
    });

    const metrics = {
        total: customers.length,
        active: customers.filter(c => c.status === 'Active').length,
        corporate: customers.filter(c => c.type === 'Corporate').length,
        vips: customers.filter(c => c.status === 'VIP').length,
        value: '$142k'
    };

    return (
        <div className="w-full pb-8" dir={isRTL ? 'rtl' : 'ltr'}>
            <div className="mx-auto max-w-[1400px]">
                {/* Top Welcome Banner (NeoPay Style) */}
                <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "flex-row-reverse")}>
                    <div className={cn(isRTL ? "text-right" : "text-left")}>
                        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                            {t('customers.title')}
                        </h1>
                        <p className="mt-1 text-sm text-blue-100 opacity-90">
                            {t('customers.subtitle')}
                        </p>
                    </div>
                    
                    <div className={cn("flex items-center gap-2 sm:gap-3 banner-actions", isRTL && "flex-row-reverse")}>
                        <Button variant="outline" className="bg-white/10 text-white border-transparent hover:bg-white/20" onClick={() => navigate('/customers/corporate')}>
                            <Building2 className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                            {t('customers.corporate')}
                        </Button>
                        <Button variant="outline" className="bg-white/10 text-white border-transparent hover:bg-white/20" onClick={() => toast.success(isRTL ? 'تصدير' : 'Export', isRTL ? 'تم تصدير البيانات بنجاح.' : 'Customer data exported successfully.')}>
                            <Download className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                            {t('customers.actions.export')}
                        </Button>
                        <Button className="bg-white text-blue-600 hover:bg-gray-50" onClick={() => navigate('/customers/new')}>
                            <Plus className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                            {t('customers.actions.addCustomer')}
                        </Button>
                    </div>
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <StatCard label={t('customers.stats.total')} value={metrics.total} icon={Users} iconColor="text-blue-500" iconBg="bg-blue-50 dark:bg-blue-900/20" />
                    <StatCard label={t('customers.stats.active')} value={metrics.active} icon={Activity} iconColor="text-emerald-500" iconBg="bg-emerald-50 dark:bg-emerald-900/20" trend={t('customers.stats.trendActive')} trendType="up" />
                    <StatCard label={t('customers.stats.vips')} value={metrics.vips} icon={Star} iconColor="text-purple-500" iconBg="bg-purple-50 dark:bg-purple-900/20" />
                    <StatCard label={t('customers.stats.value')} value={metrics.value} icon={TrendingUp} iconColor="text-indigo-500" iconBg="bg-indigo-50 dark:bg-indigo-900/20" trend={t('customers.stats.trendValue')} trendType="up" />
                </div>

                {/* Filters */}
                <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900 mb-8">
                    <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row items-center gap-4">
                            <div className="flex-1 w-full relative">
                                <Search className={cn("absolute top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400", isRTL ? "right-4" : "left-4")} />
                                <Input
                                    placeholder={t('customers.filter.searchPlaceholder')}
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className={cn("h-12 bg-slate-50 border-0 rounded-2xl font-medium", isRTL ? "pr-12" : "pl-12")}
                                />
                            </div>
                            <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="w-full md:w-48 h-12 bg-slate-50 border-0 rounded-2xl font-medium">
                                <option value="All Types">{t('customers.filter.allTypes')}</option>
                                <option value="Individual">{t('customers.filter.individual')}</option>
                                <option value="Corporate">{t('customers.filter.corporate')}</option>
                            </Select>
                            <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="w-full md:w-48 h-12 bg-slate-50 border-0 rounded-2xl font-medium">
                                <option value="All Status">{t('customers.filter.allStatus')}</option>
                                <option value="Active">{t('customers.status.active')}</option>
                                <option value="VIP">{t('customers.status.vip')}</option>
                                <option value="Suspended">{t('customers.status.suspended')}</option>
                            </Select>
                            <Button className="w-full md:w-auto h-12 rounded-2xl bg-blue-50 text-blue-600 hover:bg-blue-100 font-bold" onClick={() => navigate('/customers/bulk-email')}>
                                <Mail className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                                {t('customers.actions.campaign')}
                            </Button>
                        </div>
                    </CardContent>
                </Card>

            {/* Table */}
            <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900 overflow-hidden mb-8">
                <div className="overflow-x-auto">
                    <table className="table-premium w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-slate-50/50 dark:bg-gray-800/50">
                            <th>{t('customers.table.name')}</th>
                            <th>{t('customers.table.contact')}</th>
                            <th>{t('customers.table.category')}</th>
                            <th>{t('customers.table.nationality')}</th>
                            <th>{t('customers.table.status')}</th>
                            <th>{t('customers.table.bookings')}</th>
                            <th>{t('customers.table.spent')}</th>
                            <th className="text-right">{t('customers.table.actions')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredCustomers.map((customer) => (
                            <tr key={customer.id}>
                                <td>
                                    <div className="font-bold text-gray-900 dark:text-white">{customer.name}</div>
                                    <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest bidi-isolate">{customer.id}</div>
                                </td>
                                <td>
                                    <div className="text-xs font-medium bidi-isolate">{customer.email}</div>
                                    <div className="text-[10px] text-gray-500 bidi-isolate">{customer.phone}</div>
                                </td>
                                <td>
                                    <StatusBadge variant={customer.type === 'Corporate' ? 'indigo' : 'blue'}>{t(getTypeKey(customer.type))}</StatusBadge>
                                </td>
                                <td>
                                    <div className="text-xs font-medium">{t('customers.table.nationalityValue')}</div>
                                </td>
                                <td>
                                    <StatusBadge variant={getStatusVariant(customer.status)}>{t(getStatusKey(customer.status))}</StatusBadge>
                                </td>
                                <td>
                                    <div className="text-xs font-bold bidi-isolate">{customer.totalBookings}</div>
                                </td>
                                <td>
                                    <div className="text-xs font-bold text-emerald-600 bidi-isolate">${customer.totalSpent?.toLocaleString()}</div>
                                </td>
                                <td className="text-right">
                                    <TableActionsDropdown
                                        actions={[
                                            { label: 'Profile Details', icon: Eye, onClick: () => navigate('/customers/view', { state: { customer } }) },
                                            { label: 'Edit Profile', icon: Edit, onClick: () => navigate('/customers/edit', { state: { customer } }) },
                                            { label: 'New Booking', icon: Calendar, onClick: () => { setSelectedCustomer(customer); navigate('/reservations/new', { state: { customer } }); } },
                                            { label: 'Log Activity', icon: FileText, onClick: () => { setSelectedCustomer(customer); toast.success(isRTL ? 'تم تسجيل النشاط' : 'Activity Logged', isRTL ? 'تم تسجيل النشاط بنجاح.' : 'The activity has been recorded.'); } },
                                            { label: 'Contact (Call)', icon: Phone, onClick: () => toast.info(isRTL ? 'جاري بدء الاتصال' : 'Initiating Call', isRTL ? `جاري الاتصال بـ ${customer.phone}...` : `Connecting to ${customer.phone}...`) }
                                        ]}
                                    />
                                </td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div>
            </Card>

            {filteredCustomers.length === 0 && (
                <Card className="card-premium mt-6">
                    <CardContent className="p-12 text-center">
                        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-50 dark:bg-gray-800 mb-4 text-gray-400">
                            <Users className="h-8 w-8" />
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white">{t('customers.empty.title')}</h3>
                        <p className="description-sm">{t('customers.empty.desc')}</p>
                    </CardContent>
                </Card>
            )}

            {/* All modals converted to pages or toast */}
        </div>
        </div>
    );
};