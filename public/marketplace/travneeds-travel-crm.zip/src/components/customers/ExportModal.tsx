import React, { useState } from 'react';
import { X, Download } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { Input } from '../ui/Input';
import { useLocale } from '../../localization/useLocale';
import { useToastContext } from '../../contexts/ToastContext';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const { t, isRTL } = useLocale();
  const toast = useToastContext();
  const [exportFormat, setExportFormat] = useState('csv');
  const [dateRange, setDateRange] = useState('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [customerType, setCustomerType] = useState('all');
  const [status, setStatus] = useState('all');
  const [includeFields, setIncludeFields] = useState({
    basicInfo: true,
    contactDetails: true,
    bookingHistory: true,
    notes: false,
    activityLog: false
  });

  const dateRanges = React.useMemo(() => [
    { value: 'all', label: t('customers.export.range.all') },
    { value: 'today', label: t('customers.export.range.today') },
    { value: 'week', label: t('customers.export.range.week') },
    { value: 'month', label: t('customers.export.range.month') },
    { value: 'quarter', label: t('customers.export.range.quarter') },
    { value: 'year', label: t('customers.export.range.year') },
    { value: 'custom', label: t('customers.export.range.custom') }
  ], [t]);

  const customerTypes = React.useMemo(() => [
    { value: 'all', label: t('customers.filter.allTypes') },
    { value: 'Individual', label: t('customers.filter.individual') },
    { value: 'Family/Group', label: t('customers.form.familyGroup') },
    { value: 'Corporate', label: t('customers.filter.corporate') }
  ], [t]);

  const statuses = React.useMemo(() => [
    { value: 'all', label: t('customers.filter.allStatus') },
    { value: 'Active', label: t('customers.status.active') },
    { value: 'VIP', label: t('customers.status.vip') },
    { value: 'Recurring', label: t('customers.status.recurring') },
    { value: 'Inactive', label: t('customers.status.suspended') }
  ], [t]);

  const fields = React.useMemo(() => [
    { key: 'basicInfo', label: t('customers.export.field.basicInfo'), desc: t('customers.export.field.basicInfoDesc') },
    { key: 'contactDetails', label: t('customers.export.field.contactDetails'), desc: t('customers.export.field.contactDetailsDesc') },
    { key: 'bookingHistory', label: t('customers.export.field.bookingHistory'), desc: t('customers.export.field.bookingHistoryDesc') },
    { key: 'notes', label: t('customers.export.field.notes'), desc: t('customers.export.field.notesDesc') },
    { key: 'activityLog', label: t('customers.export.field.activityLog'), desc: t('customers.export.field.activityLogDesc') }
  ], [t]);

  const handleExport = () => {
    // Simulate API export
    setTimeout(() => {
      toast.success(
        isRTL ? 'بدء التصدير' : 'Export Started', 
        isRTL ? `جاري تجهيز ملف التصدير بصيغة ${exportFormat.toUpperCase()} وسيبدأ التحميل قريباً.` : `Your ${exportFormat.toUpperCase()} export is preparing and will download shortly.`
      );
    }, 500);

    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-lg bg-white dark:bg-gray-800 rounded-lg shadow-xl">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-3">
              <Download className="h-6 w-6 text-blue-500" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                {t('customers.export.title')}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <div className="p-6 space-y-6">
            {/* Export Format */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                {t('customers.export.format')}
              </label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { value: 'csv', label: 'CSV', desc: t('customers.export.format.csvDesc') },
                  { value: 'excel', label: 'Excel', desc: t('customers.export.format.excelDesc') },
                  { value: 'pdf', label: 'PDF', desc: t('customers.export.format.pdfDesc') }
                ].map((format) => (
                  <button
                    key={format.value}
                    onClick={() => setExportFormat(format.value)}
                    className={`p-3 text-left rtl:text-right border rounded-lg transition-colors ${exportFormat === format.value
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                      : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                      }`}
                  >
                    <div className="font-medium text-gray-900 dark:text-white">{format.label}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">{format.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Date Range */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                {t('customers.export.dateRange')}
              </label>
              <Select value={dateRange} onChange={(e) => setDateRange(e.target.value)}>
                {dateRanges.map(range => (
                  <option key={range.value} value={range.value}>{range.label}</option>
                ))}
              </Select>

              {dateRange === 'custom' && (
                <div className="grid grid-cols-2 gap-3 mt-3">
                  <Input
                    type="date"
                    label={t('customers.export.startDate')}
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                  <Input
                    type="date"
                    label={t('customers.export.endDate')}
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                  />
                </div>
              )}
            </div>

            {/* Filters */}
            <div className="grid grid-cols-2 gap-4">
              <Select
                label={t('customers.export.customerType')}
                value={customerType}
                onChange={(e) => setCustomerType(e.target.value)}
              >
                {customerTypes.map(type => (
                  <option key={type.value} value={type.value}>{type.label}</option>
                ))}
              </Select>

              <Select
                label={t('customers.export.status')}
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              >
                {statuses.map(st => (
                  <option key={st.value} value={st.value}>{st.label}</option>
                ))}
              </Select>
            </div>

            {/* Include Fields */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                {t('customers.export.includeFields')}
              </label>
              <div className="space-y-2">
                {fields.map((field) => (
                  <label key={field.key} className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      checked={includeFields[field.key as keyof typeof includeFields]}
                      onChange={(e) => setIncludeFields(prev => ({
                        ...prev,
                        [field.key]: e.target.checked
                      }))}
                      className="mt-1 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <div>
                      <div className="text-sm font-medium text-gray-900 dark:text-white">
                        {field.label}
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        {field.desc}
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Export Summary */}
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
              <h4 className="text-sm font-medium text-blue-800 dark:text-blue-300 mb-2">
                {t('customers.export.summary')}
              </h4>
              <div className="text-sm text-blue-700 dark:text-blue-400 space-y-1">
                <div>{t('customers.export.summaryFormat')}: {exportFormat.toUpperCase()}</div>
                <div>{t('customers.export.summaryRange')}: {dateRange === 'custom' ? `${startDate} to ${endDate}` : dateRanges.find(r => r.value === dateRange)?.label}</div>
                <div className="bidi-isolate">{t('customers.export.summaryRecords')}</div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700">
            <Button variant="outline" onClick={onClose}>
              {t('customers.export.cancel')}
            </Button>
            <Button onClick={handleExport}>
              <Download className="h-4 w-4 mr-2 ml-2" />
              {t('customers.export.action')}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};