import React, { useState } from 'react';
import { Mail, Send, Clock, Users, ArrowLeft, Eye } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { Input } from '../ui/Input';
import { useLocale } from '../../localization/useLocale';
import { useToastContext } from '../../contexts/ToastContext';
import { useNavigate } from 'react-router-dom';
import { cn } from '../../utils/cn';

export const BulkEmailPage: React.FC = () => {
  const { t, direction, isRTL } = useLocale();
  const toast = useToastContext();
  const navigate = useNavigate();

  const [emailData, setEmailData] = useState({
    subject: '',
    message: '',
    sendOption: 'now',
    scheduleDate: '',
    scheduleTime: ''
  });

  const [targetFilters, setTargetFilters] = useState({
    customerType: 'all',
    status: 'all',
    lastActivity: 'all',
    bookingHistory: 'all'
  });

  const [previewMode, setPreviewMode] = useState(false);
  const [isSending, setIsSending] = useState(false);

  const getEstimatedRecipients = () => {
    let count = 2847;
    if (targetFilters.customerType !== 'all') count = Math.floor(count * 0.6);
    if (targetFilters.status !== 'all') count = Math.floor(count * 0.8);
    if (targetFilters.lastActivity !== 'all') count = Math.floor(count * 0.7);
    if (targetFilters.bookingHistory !== 'all') count = Math.floor(count * 0.5);
    return count;
  };

  const handleSend = async () => {
    setIsSending(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    setIsSending(false);
    if (emailData.sendOption === 'now') {
      toast.success(
        isRTL ? 'تم إرسال الحملة' : 'Campaign Sent',
        isRTL
          ? `جاري معالجة إرسال حملة البريد الجماعي لـ ${getEstimatedRecipients().toLocaleString()} مستلم.`
          : `Your bulk email campaign is being processed for ${getEstimatedRecipients().toLocaleString()} recipients.`
      );
    } else {
      toast.success(
        isRTL ? 'تم جدولة الحملة' : 'Campaign Scheduled',
        isRTL
          ? `تم جدولة الحملة لـ ${getEstimatedRecipients().toLocaleString()} مستلم.`
          : `Campaign scheduled for ${getEstimatedRecipients().toLocaleString()} recipients.`
      );
    }
    navigate(-1);
  };

  const recipients = getEstimatedRecipients();

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        {/* Header Banner */}
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate(-1)} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
              <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-xl">
                <Mail className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                  {isRTL ? 'حملة البريد الجماعي' : 'Bulk Email Campaign'}
                </h1>
                <p className="mt-1 text-sm text-blue-100 opacity-90">
                  {isRTL ? 'إرسال رسائل مخصصة لعملاء محددين' : 'Send targeted messages to selected customer segments'}
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-white/10 rounded-2xl px-5 py-3 text-center">
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-blue-200" />
                <span className="text-2xl font-black">{recipients.toLocaleString()}</span>
              </div>
              <p className="text-xs text-blue-200 mt-0.5">{isRTL ? 'مستلم متوقع' : 'Est. Recipients'}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Targeting Filters */}
          <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 p-8">
            <h3 className="text-base font-bold text-gray-900 dark:text-white mb-6 uppercase tracking-wider flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-blue-500"></div>
              {isRTL ? 'استهداف الجمهور' : 'Target Audience'}
            </h3>
            <div className="space-y-5">
              <Select label={isRTL ? 'نوع العميل' : 'Customer Type'} value={targetFilters.customerType} onChange={e => setTargetFilters(p => ({ ...p, customerType: e.target.value }))}>
                <option value="all">{isRTL ? 'جميع العملاء' : 'All Customers'}</option>
                <option value="individual">{isRTL ? 'أفراد' : 'Individual'}</option>
                <option value="corporate">{isRTL ? 'شركات' : 'Corporate'}</option>
                <option value="vip">{isRTL ? 'VIP' : 'VIP'}</option>
              </Select>
              <Select label={isRTL ? 'الحالة' : 'Status'} value={targetFilters.status} onChange={e => setTargetFilters(p => ({ ...p, status: e.target.value }))}>
                <option value="all">{isRTL ? 'الكل' : 'All'}</option>
                <option value="active">{isRTL ? 'نشط' : 'Active'}</option>
                <option value="inactive">{isRTL ? 'غير نشط' : 'Inactive'}</option>
              </Select>
              <Select label={isRTL ? 'آخر نشاط' : 'Last Activity'} value={targetFilters.lastActivity} onChange={e => setTargetFilters(p => ({ ...p, lastActivity: e.target.value }))}>
                <option value="all">{isRTL ? 'في أي وقت' : 'Any Time'}</option>
                <option value="30days">{isRTL ? 'آخر 30 يوم' : 'Last 30 Days'}</option>
                <option value="90days">{isRTL ? 'آخر 90 يوم' : 'Last 90 Days'}</option>
                <option value="1year">{isRTL ? 'آخر سنة' : 'Last Year'}</option>
              </Select>
              <Select label={isRTL ? 'سجل الحجوزات' : 'Booking History'} value={targetFilters.bookingHistory} onChange={e => setTargetFilters(p => ({ ...p, bookingHistory: e.target.value }))}>
                <option value="all">{isRTL ? 'الكل' : 'All'}</option>
                <option value="hasBookings">{isRTL ? 'لديه حجوزات' : 'Has Bookings'}</option>
                <option value="noBookings">{isRTL ? 'لا يوجد حجوزات' : 'No Bookings'}</option>
              </Select>
              <div className="pt-4 border-t border-gray-100 dark:border-gray-800">
                <div className="bg-blue-50 dark:bg-blue-900/10 rounded-2xl p-4 text-center">
                  <p className="text-3xl font-black text-blue-600 dark:text-blue-400">{recipients.toLocaleString()}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 font-medium mt-1">{isRTL ? 'مستلم متوقع' : 'Estimated Recipients'}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Email Composer */}
          <div className="lg:col-span-2 bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-base font-bold text-gray-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                {isRTL ? 'إنشاء الرسالة' : 'Compose Email'}
              </h3>
              <Button variant="outline" onClick={() => setPreviewMode(!previewMode)} className="gap-2 text-sm">
                <Eye className="h-4 w-4" />
                {previewMode ? (isRTL ? 'تحرير' : 'Edit') : (isRTL ? 'معاينة' : 'Preview')}
              </Button>
            </div>

            {previewMode ? (
              <div className="bg-gray-50 dark:bg-gray-800/50 rounded-2xl p-8 border border-gray-100 dark:border-gray-700">
                <div className="max-w-xl mx-auto">
                  <div className="bg-blue-600 p-6 rounded-t-2xl text-center">
                    <h2 className="text-white text-xl font-bold">{emailData.subject || (isRTL ? 'موضوع الرسالة' : 'Email Subject')}</h2>
                  </div>
                  <div className="bg-white dark:bg-gray-800 p-6 rounded-b-2xl border border-t-0 border-gray-200 dark:border-gray-700">
                    <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap leading-relaxed">
                      {emailData.message || (isRTL ? 'محتوى الرسالة سيظهر هنا...' : 'Email content will appear here...')}
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-5">
                <Input
                  label={isRTL ? 'موضوع الرسالة' : 'Email Subject'}
                  value={emailData.subject}
                  onChange={e => setEmailData(p => ({ ...p, subject: e.target.value }))}
                  placeholder={isRTL ? 'أدخل موضوع الرسالة' : 'Enter email subject'}
                />
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    {isRTL ? 'محتوى الرسالة' : 'Email Content'}
                  </label>
                  <textarea
                    rows={8}
                    value={emailData.message}
                    onChange={e => setEmailData(p => ({ ...p, message: e.target.value }))}
                    className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none dark:text-white resize-none"
                    placeholder={isRTL ? 'اكتب محتوى الرسالة هنا...' : 'Write your email content here...'}
                  />
                </div>

                {/* Send Options */}
                <div className="bg-gray-50 dark:bg-gray-800/50 rounded-2xl p-6 border border-gray-100 dark:border-gray-700">
                  <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-4">{isRTL ? 'خيارات الإرسال' : 'Send Options'}</label>
                  <div className="flex gap-4 mb-4">
                    {[
                      { value: 'now', label: isRTL ? 'إرسال الآن' : 'Send Now', icon: Send },
                      { value: 'scheduled', label: isRTL ? 'جدولة الإرسال' : 'Schedule', icon: Clock }
                    ].map(opt => (
                      <label key={opt.value} className={cn("flex-1 flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all", emailData.sendOption === opt.value ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800')}>
                        <input type="radio" value={opt.value} checked={emailData.sendOption === opt.value} onChange={e => setEmailData(p => ({ ...p, sendOption: e.target.value }))} className="text-blue-600" />
                        <opt.icon className={`h-4 w-4 ${emailData.sendOption === opt.value ? 'text-blue-600' : 'text-gray-400'}`} />
                        <span className={`text-sm font-semibold ${emailData.sendOption === opt.value ? 'text-blue-700 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400'}`}>{opt.label}</span>
                      </label>
                    ))}
                  </div>
                  {emailData.sendOption === 'scheduled' && (
                    <div className="grid grid-cols-2 gap-4">
                      <Input type="date" label={isRTL ? 'التاريخ' : 'Date'} value={emailData.scheduleDate} onChange={e => setEmailData(p => ({ ...p, scheduleDate: e.target.value }))} />
                      <Input type="time" label={isRTL ? 'الوقت' : 'Time'} value={emailData.scheduleTime} onChange={e => setEmailData(p => ({ ...p, scheduleTime: e.target.value }))} />
                    </div>
                  )}
                </div>

                <div className="flex justify-end gap-3 pt-2">
                  <Button variant="outline" onClick={() => navigate(-1)}>{isRTL ? 'إلغاء' : 'Cancel'}</Button>
                  <Button onClick={handleSend} disabled={isSending || !emailData.subject || !emailData.message} loading={isSending} className="bg-blue-600 hover:bg-blue-700 px-8">
                    {emailData.sendOption === 'now' ? <><Send className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />{isRTL ? 'إرسال الحملة' : 'Send Campaign'}</> : <><Clock className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />{isRTL ? 'جدولة الإرسال' : 'Schedule Send'}</>}
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
