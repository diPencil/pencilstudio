import React, { useState, useEffect } from 'react';
import { Save, Settings, Star, Bell, ArrowLeft } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { useLocale } from '../../localization/useLocale';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';

interface Customer {
  id?: string;
  name?: string;
  fullName?: string;
  contactMethod?: string;
  status?: string;
}

export const UpdatePreferencesPage: React.FC = () => {
  const { t, direction, isRTL } = useLocale();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToastContext();

  const customer = location.state?.customer as Customer;

  useEffect(() => {
    if (!customer) navigate('/customers');
  }, [customer, navigate]);

  if (!customer) return null;

  const contactMethods = [
    { value: 'Email', label: t('customers.contactMethod.email') },
    { value: 'Phone', label: t('customers.contactMethod.phone') },
    { value: 'WhatsApp', label: t('customers.contactMethod.whatsapp') },
    { value: 'SMS', label: isRTL ? 'رسالة نصية' : 'SMS' }
  ];

  const meals = [
    { value: 'Vegetarian', label: t('customers.preferences.meal.vegetarian') },
    { value: 'Vegan', label: t('customers.preferences.meal.vegan') },
    { value: 'Halal', label: t('customers.preferences.meal.halal') },
    { value: 'No Gluten', label: t('customers.preferences.meal.noGluten') },
    { value: 'Standard', label: t('customers.preferences.meal.standard') }
  ];

  const rooms = [
    { value: 'High Floor', label: t('customers.preferences.room.highFloor') },
    { value: 'Low Floor', label: t('customers.preferences.room.lowFloor') },
    { value: 'Near Elevator', label: t('customers.preferences.room.nearElevator') },
    { value: 'Quiet Area', label: t('customers.preferences.room.quietArea') }
  ];

  const [formData, setFormData] = useState({
    contactMethod: customer?.contactMethod || 'Email',
    mealPreference: 'Standard',
    roomPreference: 'High Floor',
    newsletter: true,
    loyaltyLevel: customer?.status === 'VIP' ? 'VIP' : 'Standard'
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      toast.success(
        isRTL ? 'تم تحديث التفضيلات' : 'Preferences Updated',
        isRTL ? 'تم حفظ تفضيلات العميل بنجاح.' : 'Customer preferences saved successfully.'
      );
      navigate(-1);
    } catch (error) {
      toast.error('Error', 'Failed to update preferences.');
    } finally {
      setIsLoading(false);
    }
  };

  const loyaltyLevels = [
    { value: 'Standard', label: isRTL ? 'عادي' : 'Standard', color: 'bg-gray-500' },
    { value: 'Silver', label: isRTL ? 'فضي' : 'Silver', color: 'bg-gray-400' },
    { value: 'Gold', label: isRTL ? 'ذهبي' : 'Gold', color: 'bg-yellow-500' },
    { value: 'VIP', label: 'VIP', color: 'bg-purple-600' }
  ];

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        {/* Header Banner */}
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate(-1)} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
              <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-xl">
                <Settings className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                  {t('customers.preferences.title')}
                </h1>
                <p className="mt-1 text-sm text-blue-100 opacity-90">
                  {isRTL ? `تحديث تفضيلات العميل: ${customer.name || customer.fullName}` : `Update preferences for: ${customer.name || customer.fullName}`}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 p-8 sm:p-10">
          <form onSubmit={handleSubmit}>
            <div className="max-w-2xl mx-auto space-y-8">
              {/* Contact Method */}
              <div>
                <h3 className="text-sm font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4">{isRTL ? 'طريقة التواصل' : 'Contact Preferences'}</h3>
                <Select
                  label={t('customers.preferences.contactMethod')}
                  value={formData.contactMethod}
                  onChange={e => setFormData(p => ({ ...p, contactMethod: e.target.value }))}
                >
                  {contactMethods.map(item => (
                    <option key={item.value} value={item.value}>{item.label}</option>
                  ))}
                </Select>
              </div>

              {/* Travel Preferences */}
              <div>
                <h3 className="text-sm font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4">{isRTL ? 'تفضيلات السفر' : 'Travel Preferences'}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <Select
                    label={t('customers.preferences.mealPreference')}
                    value={formData.mealPreference}
                    onChange={e => setFormData(p => ({ ...p, mealPreference: e.target.value }))}
                  >
                    {meals.map(item => (
                      <option key={item.value} value={item.value}>{item.label}</option>
                    ))}
                  </Select>
                  <Select
                    label={t('customers.preferences.roomPreference')}
                    value={formData.roomPreference}
                    onChange={e => setFormData(p => ({ ...p, roomPreference: e.target.value }))}
                  >
                    {rooms.map(item => (
                      <option key={item.value} value={item.value}>{item.label}</option>
                    ))}
                  </Select>
                </div>
              </div>

              {/* Loyalty & Newsletter */}
              <div>
                <h3 className="text-sm font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4">{isRTL ? 'الولاء والاتصالات' : 'Loyalty & Communications'}</h3>
                <div className="space-y-5">
                  {/* Newsletter Toggle */}
                  <div className="bg-gray-50 dark:bg-gray-800/50 rounded-2xl p-5 border border-gray-100 dark:border-gray-700">
                    <label className="flex items-center gap-4 cursor-pointer">
                      <div className={cn("p-3 rounded-xl transition-colors", formData.newsletter ? 'bg-blue-50 dark:bg-blue-900/30' : 'bg-gray-100 dark:bg-gray-800')}>
                        <Bell className={cn("h-5 w-5 transition-colors", formData.newsletter ? 'text-blue-600' : 'text-gray-400')} />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-bold text-gray-900 dark:text-white">{t('customers.preferences.newsletterTitle')}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{t('customers.preferences.newsletterDesc')}</p>
                      </div>
                      <div className="relative">
                        <input
                          type="checkbox"
                          checked={formData.newsletter}
                          onChange={e => setFormData(p => ({ ...p, newsletter: e.target.checked }))}
                          className="sr-only"
                        />
                        <div
                          onClick={() => setFormData(p => ({ ...p, newsletter: !p.newsletter }))}
                          className={cn("w-12 h-6 rounded-full transition-colors cursor-pointer", formData.newsletter ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600')}
                        >
                          <div className={cn("w-5 h-5 bg-white rounded-full shadow-sm transition-transform mt-0.5", formData.newsletter ? (isRTL ? 'translate-x-1' : 'translate-x-6') : (isRTL ? 'translate-x-6' : 'translate-x-1'))} />
                        </div>
                      </div>
                    </label>
                  </div>

                  {/* Loyalty Level */}
                  <div className="bg-purple-50 dark:bg-purple-900/10 rounded-2xl p-6 border border-purple-100 dark:border-purple-900/30">
                    <div className="flex items-center gap-3 mb-5">
                      <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-xl">
                        <Star className="h-5 w-5 text-purple-600" />
                      </div>
                      <span className="text-sm font-bold text-purple-900 dark:text-purple-200">{t('customers.preferences.loyaltyStatus')}</span>
                    </div>
                    <div className="grid grid-cols-4 gap-3">
                      {loyaltyLevels.map(level => (
                        <button
                          key={level.value}
                          type="button"
                          onClick={() => setFormData(p => ({ ...p, loyaltyLevel: level.value }))}
                          className={cn("py-3 text-sm font-bold rounded-xl border-2 transition-all", formData.loyaltyLevel === level.value
                            ? 'bg-purple-600 border-purple-600 text-white shadow-lg shadow-purple-200 dark:shadow-purple-900/30'
                            : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:border-purple-300'
                          )}
                        >
                          {level.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex justify-end gap-3 pt-6 border-t border-gray-100 dark:border-gray-800">
                <Button type="button" variant="outline" onClick={() => navigate(-1)} disabled={isLoading}>
                  {t('customers.preferences.cancel')}
                </Button>
                <Button type="submit" disabled={isLoading} loading={isLoading} className="bg-blue-600 hover:bg-blue-700 px-8">
                  <Save className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                  {t('customers.preferences.updateAction')}
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
