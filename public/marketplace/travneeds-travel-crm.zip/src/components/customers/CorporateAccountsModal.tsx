import React, { useState } from 'react';
import { X, Building, Users, DollarSign, Calendar, Eye, Edit, Plus } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { formatCurrency } from '../../utils/format';
import { AddCorporateAccountModal } from './AddCorporateAccountModal';
import { ViewCorporateAccountModal } from './ViewCorporateAccountModal';
import { EditCorporateAccountModal } from './EditCorporateAccountModal';
import { StatusBadge } from '../ui/StatusBadge';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

interface CorporateAccount {
  id: string;
  companyName: string;
  primaryContact: string;
  email: string;
  phone: string;
  customerCount: number;
  totalBookings: number;
  totalRevenue: number;
  lastBooking: string;
  status: string;
  accountManager: string;
  contractValue: number;
  renewalDate: string;
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
}

interface CorporateAccountsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CorporateAccountsModal: React.FC<CorporateAccountsModalProps> = ({ isOpen, onClose }) => {
  const { t, isRTL } = useLocale();

  const mockCorporateAccounts = React.useMemo(() => [
    {
      id: 'CORP-001',
      companyName: 'TechCorp Solutions',
      primaryContact: isRTL ? 'يوسف أحمد' : 'Youssef Ahmed',
      email: 'youssef@techcorp.com',
      phone: '+1-555-123-4567',
      customerCount: 24,
      totalBookings: 156,
      totalRevenue: 89500,
      lastBooking: '2025-01-10',
      status: 'VIP',
      accountManager: isRTL ? 'محمود خليل' : 'Mahmoud Khalil',
      contractValue: 120000,
      renewalDate: '2025-12-31'
    },
    {
      id: 'CORP-002',
      companyName: 'Global Marketing Inc',
      primaryContact: isRTL ? 'سارة منصور' : 'Sara Mansour',
      email: 'sara@globalmarketing.com',
      phone: '+1-555-987-6543',
      customerCount: 18,
      totalBookings: 89,
      totalRevenue: 45200,
      lastBooking: '2025-01-08',
      status: 'Active',
      accountManager: isRTL ? 'ليلى رمضان' : 'Layla Ramadan',
      contractValue: 60000,
      renewalDate: '2025-08-15'
    },
    {
      id: 'CORP-003',
      companyName: 'Innovation Labs',
      primaryContact: isRTL ? 'داود إبراهيم' : 'Daoud Ibrahim',
      email: 'daoud@innovationlabs.com',
      phone: '+1-555-456-7890',
      customerCount: 12,
      totalBookings: 34,
      totalRevenue: 28900,
      lastBooking: '2024-12-20',
      status: 'Active',
      accountManager: isRTL ? 'المشرف العام' : 'Super Admin',
      contractValue: 40000,
      renewalDate: '2025-06-30'
    }
  ], [isRTL]);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAccount, setSelectedAccount] = useState<CorporateAccount | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [accounts, setAccounts] = useState<CorporateAccount[]>(mockCorporateAccounts);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'VIP': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300';
      case 'Active': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'Inactive': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'VIP': return t('customers.status.vip');
      case 'Active': return t('customers.status.active');
      case 'Suspended': return t('customers.status.suspended');
      default: return status;
    }
  };

  const filteredAccounts = accounts.filter(account =>
    account.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    account.primaryContact.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalRevenue = accounts.reduce((sum, account) => sum + account.totalRevenue, 0);
  const totalCustomers = accounts.reduce((sum, account) => sum + account.customerCount, 0);
  const totalBookings = accounts.reduce((sum, account) => sum + account.totalBookings, 0);

  const handleViewAccount = (account: CorporateAccount) => {
    setSelectedAccount(account);
    setIsViewModalOpen(true);
  };

  const handleEditAccount = (account: CorporateAccount) => {
    setSelectedAccount(account);
    setIsEditModalOpen(true);
  };

  const handleAddAccount = async (accountData: CorporateAccount) => {
    setAccounts(prev => [accountData, ...prev]);
  };

  const handleUpdateAccount = async (updatedAccount: CorporateAccount) => {
    setAccounts(prev => prev.map(account => account.id === updatedAccount.id ? updatedAccount : account));
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-[60] overflow-y-auto" dir={isRTL ? 'rtl' : 'ltr'}>
        <div className="flex min-h-screen items-center justify-center p-4">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
          <div className="relative w-full max-w-7xl bg-white dark:bg-gray-800 rounded-lg shadow-xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center gap-3">
                <Building className="h-6 w-6 text-blue-500" />
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  {t('customers.corpModal.title')}
                </h2>
              </div>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X size={24} />
              </button>
            </div>

            <div className="p-6">
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-blue-600 dark:text-blue-400">{t('customers.corpModal.metric.totalAccounts')}</p>
                      <p className="text-2xl font-bold text-blue-800 dark:text-blue-300 bidi-isolate">
                        {accounts.length}
                      </p>
                    </div>
                    <Building className="h-8 w-8 text-blue-500" />
                  </div>
                </div>

                <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-green-600 dark:text-green-400">{t('customers.corpModal.metric.totalRevenue')}</p>
                      <p className="text-2xl font-bold text-green-800 dark:text-green-300 bidi-isolate">
                        {formatCurrency(totalRevenue)}
                      </p>
                    </div>
                    <DollarSign className="h-8 w-8 text-green-500" />
                  </div>
                </div>

                <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-purple-600 dark:text-purple-400">{t('customers.corpModal.metric.totalCustomers')}</p>
                      <p className="text-2xl font-bold text-purple-800 dark:text-purple-300 bidi-isolate">
                        {totalCustomers}
                      </p>
                    </div>
                    <Users className="h-8 w-8 text-purple-500" />
                  </div>
                </div>

                <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-orange-600 dark:text-orange-400">{t('customers.corpModal.metric.totalBookings')}</p>
                      <p className="text-2xl font-bold text-orange-800 dark:text-orange-300 bidi-isolate">
                        {totalBookings}
                      </p>
                    </div>
                    <Calendar className="h-8 w-8 text-orange-500" />
                  </div>
                </div>
              </div>

              {/* Search and Actions */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
                <div className="relative flex-1 max-w-md">
                  <Input
                    placeholder={t('customers.corpModal.searchPlaceholder')}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Button className="mt-4 sm:mt-0" onClick={() => setIsAddModalOpen(true)}>
                  <Plus className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                  {t('customers.corpModal.addAccount')}
                </Button>
              </div>

              {/* Corporate Accounts Table */}
              <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                      <tr>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('customers.corpModal.table.company')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('customers.corpModal.table.contact')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('customers.corpModal.table.customers')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('customers.corpModal.table.bookings')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('customers.corpModal.table.revenue')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('customers.corpModal.table.status')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('customers.corpModal.table.manager')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('customers.corpModal.table.actions')}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                      {filteredAccounts.map((account) => (
                        <tr key={account.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-gray-900 dark:text-white">
                                {account.companyName}
                              </div>
                              <div className="text-sm text-gray-500 dark:text-gray-400 bidi-isolate">
                                {account.id}
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm text-gray-900 dark:text-white">
                                {account.primaryContact}
                              </div>
                              <div className="text-sm text-gray-500 dark:text-gray-400 bidi-isolate">
                                {account.email}
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white bidi-isolate">
                            {account.customerCount}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400 bidi-isolate">
                            {account.totalBookings}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white bidi-isolate">
                            {formatCurrency(account.totalRevenue)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(account.status)}`}>
                              {getStatusLabel(account.status)}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            {account.accountManager}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            <TableActionsDropdown
                                actions={[
                                    { label: t('customers.viewCorp.titleSuffix'), icon: Eye, onClick: () => handleViewAccount(account) },
                                    { label: t('customers.editCorp.title'), icon: Edit, onClick: () => handleEditAccount(account) }
                                ]}
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="flex justify-end mt-6">
                <Button variant="outline" onClick={onClose}>
                  {t('customers.corpModal.close')}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Corporate Account Modal */}
      <AddCorporateAccountModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAdd={handleAddAccount}
      />

      {/* View Corporate Account Modal */}
      <ViewCorporateAccountModal
        isOpen={isViewModalOpen}
        onClose={() => setIsViewModalOpen(false)}
        account={selectedAccount}
      />

      {/* Edit Corporate Account Modal */}
      <EditCorporateAccountModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSave={handleUpdateAccount}
        account={selectedAccount}
      />
    </>
  );
};