import React, { useState } from 'react';
import { X, Save, FileText } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { useLocale } from '../../localization/useLocale';

interface ContractData {
  contractValue: number;
  contractDate: string;
  renewalDate: string;
  status: string;
  notes: string;
}

interface CorporateAccount {
  companyName: string;
  contractValue?: number;
  contractDate?: string;
  renewalDate?: string;
  status?: string;
}

interface UpdateContractModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (contractData: ContractData) => Promise<void>;
    account: CorporateAccount | null;
}

export const UpdateContractModal: React.FC<UpdateContractModalProps> = ({ isOpen, onClose, onSave, account }) => {
    const { t, isRTL } = useLocale();

    const contractStatuses = React.useMemo(() => [
        { value: 'Active', label: t('customers.status.active') },
        { value: 'VIP', label: t('customers.status.vip') },
        { value: 'Pending Renewal', label: isRTL ? 'قيد تجديد العقد' : 'Pending Renewal' },
        { value: 'Suspended', label: t('customers.status.suspended') }
    ], [t, isRTL]);

    const [formData, setFormData] = useState({
        contractValue: account?.contractValue || 0,
        contractDate: account?.contractDate || '',
        renewalDate: account?.renewalDate || '',
        status: account?.status || 'Active',
        notes: ''
    });
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        try {
            await onSave(formData);
            onClose();
        } catch (error) {
            console.error('Error updating contract:', error);
        } finally {
            setIsLoading(false);
        }
    };

    if (!isOpen || !account) return null;

    return (
        <div className="fixed inset-0 z-[80] overflow-y-auto" dir={isRTL ? 'rtl' : 'ltr'}>
            <div className="flex min-h-screen items-center justify-center p-4">
                <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
                <div className="relative w-full max-w-md bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-100 dark:border-gray-700">
                    <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
                        <div className="flex items-center gap-3">
                            <FileText className="h-6 w-6 text-orange-500" />
                            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                                {t('customers.contract.title')}
                            </h2>
                        </div>
                        <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                            <X size={24} />
                        </button>
                    </div>

                    <form onSubmit={handleSubmit} className="p-6">
                        <div className="space-y-4">
                            <div className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg mb-4">
                                <p className="text-xs text-orange-800 dark:text-orange-300 font-bold uppercase tracking-wider mb-1">{t('customers.contract.companyLabel')}</p>
                                <p className="text-sm font-bold text-gray-900 dark:text-white uppercase">{account.companyName}</p>
                            </div>

                            <Input
                                label={t('customers.contract.newValue')}
                                type="number"
                                value={formData.contractValue}
                                onChange={(e) => setFormData(prev => ({ ...prev, contractValue: e.target.value }))}
                            />

                            <Input
                                label={t('customers.contract.date')}
                                type="date"
                                value={formData.contractDate}
                                onChange={(e) => setFormData(prev => ({ ...prev, contractDate: e.target.value }))}
                            />

                            <Input
                                label={t('customers.contract.renewalDate')}
                                type="date"
                                value={formData.renewalDate}
                                onChange={(e) => setFormData(prev => ({ ...prev, renewalDate: e.target.value }))}
                            />

                            <Select
                                label={t('customers.contract.status')}
                                value={formData.status}
                                onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value }))}
                            >
                                {contractStatuses.map(item => (
                                    <option key={item.value} value={item.value}>{item.label}</option>
                                ))}
                            </Select>

                            <div className="space-y-1">
                                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('customers.contract.notes')}</label>
                                <textarea
                                    value={formData.notes}
                                    onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                                    rows={3}
                                    className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md text-sm focus:ring-2 focus:ring-blue-500 outline-none dark:text-white"
                                    placeholder={t('customers.contract.notesPlaceholder')}
                                />
                            </div>
                        </div>

                        <div className="flex justify-end gap-3 mt-8">
                            <Button type="button" variant="outline" onClick={onClose} disabled={isLoading}>
                                {t('customers.contract.cancel')}
                            </Button>
                            <Button type="submit" disabled={isLoading} loading={isLoading} className="bg-orange-600 hover:bg-orange-700 text-white border-orange-600">
                                <Save className="h-4 w-4 mr-2 ml-2" />
                                {t('customers.contract.save')}
                            </Button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};
