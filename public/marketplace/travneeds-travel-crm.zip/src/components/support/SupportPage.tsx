import React, { useState } from 'react';
import { Plus, Search, Eye, Edit, MessageSquare, Download, UserPlus, ShieldAlert as EscalateIcon, LifeBuoy, Zap, CheckCircle, Clock, TrendingUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { PageHeader } from '../ui/PageHeader';
import { StatCard } from '../ui/StatCard';
import { StatusBadge } from '../ui/StatusBadge';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
// CommentModal and ExportModal replaced by toast/inline
import { useToastContext } from '../../contexts/ToastContext';
import { useLocale } from '../../localization/useLocale';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { cn } from '../../utils/cn';
import { mockTickets } from '../../services/mockData';

export const SupportPage: React.FC = () => {
    const [tickets] = useState(mockTickets || []);
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('All Status');
    const [priorityFilter, setPriorityFilter] = useState('All Priority');

    // comment and export modals replaced
    const [selectedTicket, setSelectedTicket] = useState<any>(null);

    const toast = useToastContext();
    const navigate = useNavigate();
    const { direction, isRTL } = useLocale();

    const getStatusVariant = (status: string): any => {
        switch (status) {
            case 'Open': return 'blue';
            case 'In Progress': return 'amber';
            case 'Escalated': return 'rose';
            case 'Closed': return 'emerald';
            default: return 'gray';
        }
    };

    const getPriorityColor = (priority: string) => {
        switch (priority) {
            case 'Urgent': return 'text-rose-600 font-bold';
            case 'High': return 'text-amber-600 font-bold';
            default: return 'text-gray-500';
        }
    };

    const filteredTickets = tickets.filter(t => {
        const matchesSearch = t.subject.toLowerCase().includes(searchTerm.toLowerCase()) || t.id.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = statusFilter === 'All Status' || t.status === statusFilter;
        const matchesPriority = priorityFilter === 'All Priority' || t.priority === priorityFilter;
        return matchesSearch && matchesStatus && matchesPriority;
    });

    const metrics = {
        open: tickets.filter(t => t.status === 'Open').length,
        urgent: tickets.filter(t => t.priority === 'Urgent').length,
        closed: tickets.filter(t => t.status === 'Closed').length,
        avgTime: '2.4 Hours',
        sla: '94.2%',
        satisfaction: '4.8/5'
    };

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px]">
            {/* Top Welcome Banner (NeoPay Style) */}
            <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
                <div className={cn(isRTL ? "text-right" : "text-left")}>
                    <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Support Desk</h1>
                    <p className="mt-1 text-sm text-blue-100 opacity-90">Manage customer inquiries and internal support tickets</p>
                </div>
                <div className={cn("flex items-center gap-2 sm:gap-3 banner-actions", isRTL && "flex-row-reverse")}>
                    <Button variant="outline" onClick={() => navigate('/help-center')} className="bg-white/10 text-white border-transparent hover:bg-white/20">
                        <LifeBuoy className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                        Help Center
                    </Button>
                    <Button onClick={() => navigate('/help-center/new')} className="bg-white text-blue-600 hover:bg-blue-50 border-transparent">
                        <Plus className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                        New Ticket
                    </Button>
                </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6">
                <StatCard label="Open Tickets" value={metrics.open} icon={LifeBuoy} iconColor="text-blue-500" iconBg="bg-blue-50 dark:bg-blue-900/20" />
                <StatCard label="Urgent" value={metrics.urgent} icon={EscalateIcon} iconColor="text-rose-500" iconBg="bg-rose-50 dark:bg-rose-900/20" />
                <StatCard label="Resolved Today" value={metrics.closed} icon={CheckCircle} iconColor="text-emerald-500" iconBg="bg-emerald-50 dark:bg-emerald-900/20" />
                <StatCard label="Avg Response" value={metrics.avgTime} icon={Clock} iconColor="text-purple-500" iconBg="bg-purple-50 dark:bg-purple-900/20" />
                <StatCard label="SLA Adherence" value={metrics.sla} icon={Zap} iconColor="text-emerald-500" iconBg="bg-emerald-50 dark:bg-emerald-900/20" />
                <StatCard label="CSAT Score" value={metrics.satisfaction} icon={TrendingUp} iconColor="text-amber-500" iconBg="bg-amber-50 dark:bg-amber-900/20" />
            </div>

            <div className="space-y-6 mt-6">
                    {/* Filters */}
                    <Card className="card-premium">
                        <CardContent className="p-4">
                            <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-4">
                                <div className="flex-1 w-full relative">
                                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                                    <Input
                                        placeholder="Search by ticket ID or subject..."
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                        className="pl-10"
                                    />
                                </div>
                                <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="w-full md:w-32">
                                    <option>All Status</option>
                                    <option>Open</option>
                                    <option>In Progress</option>
                                    <option>Escalated</option>
                                    <option>Closed</option>
                                </Select>
                                <Select value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)} className="w-full md:w-32">
                                    <option>All Priority</option>
                                    <option>Urgent</option>
                                    <option>High</option>
                                    <option>Normal</option>
                                </Select>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Table */}
                    <div className="table-container">
                        <table className="table-premium">
                            <thead>
                                <tr>
                                    <th>Ticket ID</th>
                                    <th>Customer & Reference</th>
                                    <th>Subject & Description</th>
                                    <th>Priority</th>
                                    <th>Department</th>
                                    <th>Status</th>
                                    <th className="text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredTickets.map((t) => (
                                    <tr key={t.id} className={t.priority === 'Urgent' ? 'bg-rose-50/30 dark:bg-rose-900/5' : ''}>
                                        <td>
                                            <div className="font-bold text-gray-900 dark:text-white">{t.id}</div>
                                            <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{t.source}</div>
                                        </td>
                                        <td>
                                            <div className="text-sm font-medium">{t.customer}</div>
                                            <div className="text-[10px] text-gray-500 font-bold">{t.bookingRef}</div>
                                        </td>
                                        <td>
                                            <div className="text-xs font-bold text-gray-900 dark:text-white truncate max-w-xs">{t.subject}</div>
                                            <div className="text-[10px] text-gray-500 truncate max-w-xs">{t.description}</div>
                                        </td>
                                        <td>
                                            <span className={`text-[10px] font-bold uppercase tracking-wider ${getPriorityColor(t.priority)}`}>{t.priority}</span>
                                        </td>
                                        <td><div className="text-[10px] font-bold text-gray-600">{t.department}</div></td>
                                        <td>
                                            <StatusBadge variant={getStatusVariant(t.status)}>{t.status}</StatusBadge>
                                        </td>
                                        <td className="text-right">
                                            <TableActionsDropdown
                                                actions={[
                                                    { label: 'View Ticket', icon: Eye, onClick: () => navigate('/help-center/tickets/view', { state: { ticket: t } }) },
                                                    { label: 'Edit Details', icon: Edit, onClick: () => navigate('/help-center/tickets/edit', { state: { ticket: t } }) },
                                                    { label: 'Add Comment/Reply', icon: MessageSquare, onClick: () => { setSelectedTicket(t); toast.success('Comment Added', 'Reply logged.'); } },
                                                    { label: 'Assign Support Agent', icon: UserPlus, onClick: () => toast.success('Ticket Assigned', 'Support specialist has been notified.') },
                                                    { label: 'Escalate Ticket', icon: EscalateIcon, onClick: () => toast.warning('Ticket Escalated', 'Management has been alerted to this issue.') }
                                                ]}
                                            />
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Real-time Issue Log */}
                    <div className="space-y-6">
                        <Card className="card-premium h-full">
                            <CardContent className="p-6">
                                <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-6">Real-time Issue Log</h3>
                                <div className="space-y-4">
                                    {tickets.slice(0, 5).map((t, i) => (
                                        <div key={i} className="flex space-x-3 items-start border-l-2 border-l-gray-100 dark:border-l-gray-800 pl-3 py-1">
                                            <div className={`w-2 h-2 rounded-full mt-1.5 ${t.priority === 'Urgent' ? 'bg-rose-500 animate-pulse' : 'bg-blue-400'}`} />
                                            <div>
                                                <p className="text-[10px] font-bold text-gray-900 dark:text-white leading-tight">{t.subject}</p>
                                                <p className="text-[9px] text-gray-500 mt-0.5">{t.customer} • {t.source}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                <Button variant="outline" className="w-full mt-6 text-[10px] font-bold uppercase" onClick={() => navigate('/help-center')}>
                                    View Support Center
                                </Button>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Support Performance */}
                    <div className="space-y-6">
                        <Card className="card-premium h-full">
                            <CardContent className="p-6">
                                <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-6">Department Resolution Rate</h3>
                                <div className="space-y-6 mt-2">
                                    <div>
                                        <div className="flex justify-between items-center mb-2">
                                            <span className="text-xs font-bold text-gray-700 dark:text-gray-300">Reservations</span>
                                            <span className="text-xs font-bold text-blue-600">85%</span>
                                        </div>
                                        <div className="w-full bg-gray-100 dark:bg-gray-800 rounded-full h-2.5">
                                            <div className="bg-blue-500 h-2.5 rounded-full" style={{ width: '85%' }}></div>
                                        </div>
                                    </div>
                                    <div>
                                        <div className="flex justify-between items-center mb-2">
                                            <span className="text-xs font-bold text-gray-700 dark:text-gray-300">Finance</span>
                                            <span className="text-xs font-bold text-purple-600">62%</span>
                                        </div>
                                        <div className="w-full bg-gray-100 dark:bg-gray-800 rounded-full h-2.5">
                                            <div className="bg-purple-500 h-2.5 rounded-full" style={{ width: '62%' }}></div>
                                        </div>
                                    </div>
                                    <div>
                                        <div className="flex justify-between items-center mb-2">
                                            <span className="text-xs font-bold text-gray-700 dark:text-gray-300">Technical Support</span>
                                            <span className="text-xs font-bold text-emerald-600">94%</span>
                                        </div>
                                        <div className="w-full bg-gray-100 dark:bg-gray-800 rounded-full h-2.5">
                                            <div className="bg-emerald-500 h-2.5 rounded-full" style={{ width: '94%' }}></div>
                                        </div>
                                    </div>
                                </div>
                                <Button variant="outline" className="w-full mt-8 text-[10px] font-bold uppercase" onClick={() => navigate('/reports')}>
                                    View Detailed Report
                                </Button>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>

            {/* CommentModal and ExportModal replaced by toast/inline */}
            </div>
        </div>
    );
};