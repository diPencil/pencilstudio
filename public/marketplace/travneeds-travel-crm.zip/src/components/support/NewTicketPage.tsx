import React, { useState } from 'react';
import { Save, Upload, ArrowLeft, LifeBuoy, ShieldCheck } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { Card, CardContent } from '../ui/Card';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';

const sources = ['Email', 'WhatsApp', 'Phone', 'Internal', 'Website', 'Walk-in'];
const departments = ['Sales', 'Reservation', 'Operations', 'Finance', 'Support'];
const priorities = ['Low', 'Normal', 'High', 'Urgent'];
const staff = ['Super Admin', 'Mahmoud Khalil', 'Layla Ramadan', 'Sami Youssef', 'Mona Zaki'];

export const NewTicketPage: React.FC = () => {
    const navigate = useNavigate();
    const toast = useToastContext();
    const [formData, setFormData] = useState({
        customer: '',
        bookingRef: '',
        subject: '',
        description: '',
        source: 'Email',
        department: 'Support',
        priority: 'Normal',
        assignedTo: 'Super Admin',
        tags: ''
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(false);

    const validateForm = () => {
        const newErrors: Record<string, string> = {};
        if (!formData.customer.trim()) newErrors.customer = 'Customer name is required';
        if (!formData.subject.trim()) newErrors.subject = 'Subject is required';
        if (!formData.description.trim()) newErrors.description = 'Description is required';
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!validateForm()) return;

        setIsLoading(true);
        try {
            console.log('Creating ticket:', formData);
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 1000));

            toast.success('Ticket Created', `Support ticket for ${formData.customer} has been registered.`);
            navigate('/help-center/tickets');
        } catch (error) {
            toast.error('Error', 'Failed to create ticket. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleInputChange = (field: string, value: string) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        if (errors[field]) setErrors(prev => ({ ...prev, [field]: '' }));
    };


  return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => navigate('/help-center/tickets')}
                            className="inline-flex items-center gap-2 text-blue-100 hover:text-white transition-colors group p-2 hover:bg-white/10 rounded-lg"
                        >
                            <ArrowLeft className="w-5 h-5 rtl-flip" />
                        </button>
                        <div>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Create New Ticket</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">Open a new support request for transformation assistance</p>
                        </div>
                    </div>
                </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <Card>
                        <CardContent className="p-8">
                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <Input
                                        label="Customer Name *"
                                        value={formData.customer}
                                        onChange={(e) => handleInputChange('customer', e.target.value)}
                                        error={errors.customer}
                                        placeholder="Enter customer name"
                                    />

                                    <Input
                                        label="Booking Reference"
                                        value={formData.bookingRef}
                                        onChange={(e) => handleInputChange('bookingRef', e.target.value)}
                                        placeholder="e.g., BK-2025-001"
                                    />

                                    <div className="md:col-span-2">
                                        <Input
                                            label="Subject *"
                                            value={formData.subject}
                                            onChange={(e) => handleInputChange('subject', e.target.value)}
                                            error={errors.subject}
                                            placeholder="Brief description of the issue"
                                        />
                                    </div>

                                    <Select
                                        label="Source"
                                        value={formData.source}
                                        onChange={(e) => handleInputChange('source', e.target.value)}
                                    >
                                        {sources.map(source => (
                                            <option key={source} value={source}>{source}</option>
                                        ))}
                                    </Select>

                                    <Select
                                        label="Department"
                                        value={formData.department}
                                        onChange={(e) => handleInputChange('department', e.target.value)}
                                    >
                                        {departments.map(dept => (
                                            <option key={dept} value={dept}>{dept}</option>
                                        ))}
                                    </Select>

                                    <Select
                                        label="Priority"
                                        value={formData.priority}
                                        onChange={(e) => handleInputChange('priority', e.target.value)}
                                    >
                                        {priorities.map(priority => (
                                            <option key={priority} value={priority}>{priority}</option>
                                        ))}
                                    </Select>

                                    <Select
                                        label="Assign To"
                                        value={formData.assignedTo}
                                        onChange={(e) => handleInputChange('assignedTo', e.target.value)}
                                    >
                                        {staff.map(member => (
                                            <option key={member} value={member}>{member}</option>
                                        ))}
                                    </Select>
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                        Description *
                                    </label>
                                    <textarea
                                        value={formData.description}
                                        onChange={(e) => handleInputChange('description', e.target.value)}
                                        rows={4}
                                        className={`block w-full px-3 py-2 border rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${errors.description ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'}`}
                                        placeholder="Detailed description of the issue..."
                                    />
                                    {errors.description && (
                                        <p className="text-sm text-red-600 dark:text-red-400 mt-1">{errors.description}</p>
                                    )}
                                </div>

                                <Input
                                    label="Tags (comma separated)"
                                    value={formData.tags}
                                    onChange={(e) => handleInputChange('tags', e.target.value)}
                                    placeholder="e.g., refund, urgent, visa"
                                />

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                        Attachments
                                    </label>
                                    <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-md hover:border-gray-400 dark:hover:border-gray-500 transition-colors">
                                        <div className="space-y-1 text-center">
                                            <Upload className="mx-auto h-8 w-8 text-gray-400" />
                                            <div className="flex text-sm text-gray-600 dark:text-gray-400">
                                                <label htmlFor="file-upload" className="relative cursor-pointer bg-white dark:bg-gray-800 rounded-md font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500">
                                                    <span>Upload files</span>
                                                    <input id="file-upload" name="file-upload" type="file" className="sr-only" multiple />
                                                </label>
                                                <p className="pl-1">or drag and drop</p>
                                            </div>
                                            <p className="text-xs text-gray-500 dark:text-gray-400">PNG, JPG, PDF up to 10MB each</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200 dark:border-gray-700">
                                    <Button type="button" variant="outline" onClick={() => navigate('/help-center/tickets')} disabled={isLoading}>
                                        Cancel
                                    </Button>
                                    <Button type="submit" disabled={isLoading} loading={isLoading}>
                                        <Save className="h-4 w-4 mr-2" />
                                        Create Ticket
                                    </Button>
                                </div>
                            </form>
                        </CardContent>
                    </Card>
                </div>

                <div className="space-y-6">
                    <Card className="bg-white dark:bg-gray-800 border-none shadow-md">
                        <CardContent className="p-6">
                            <div className="flex items-center space-x-3 mb-4">
                                <div className="p-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                                    <ShieldCheck className="h-5 w-5 text-blue-500" />
                                </div>
                                <h3 className="text-lg font-bold text-gray-900 dark:text-white">Response Guarantee</h3>
                            </div>
                            <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
                                Our transformation specialists aim to respond to all tickets within 2 hours. Urgent tickets are prioritized for immediate technical sync.
                            </p>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center space-x-3 mb-4">
                                <LifeBuoy className="h-5 w-5 text-gray-400" />
                                <h3 className="font-semibold text-gray-900 dark:text-white">Ticket Guidelines</h3>
                            </div>
                            <ul className="space-y-3 text-sm text-gray-600 dark:text-gray-400">
                                <li className="flex items-start">
                                    <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5 mr-2 shrink-0"></span>
                                    Provide specific booking references for faster lookup.
                                </li>
                                <li className="flex items-start">
                                    <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5 mr-2 shrink-0"></span>
                                    Attach screenshots of absolute technical errors.
                                </li>
                                <li className="flex items-start">
                                    <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-1.5 mr-2 shrink-0"></span>
                                    Clearly state the expected vs actual system behavior.
                                </li>
                            </ul>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
        </div>
    );
};
