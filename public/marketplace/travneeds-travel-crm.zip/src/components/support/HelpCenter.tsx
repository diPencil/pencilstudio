import React from 'react';
import { MessageSquare, BookOpen, Zap, Search, ArrowRight, LifeBuoy, PlayCircle, ShieldCheck } from 'lucide-react';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

export const HelpCenter: React.FC = () => {
    const { isRTL, direction } = useLocale();
    const navigate = useNavigate();
    const toast = useToastContext();

    const handleQuickAction = (action: string) => {
        switch (action) {
            case 'docs': navigate('/help-center/docs'); break;
            case 'tickets': navigate('/help-center/tickets'); break;
            case 'chat': toast.info('Support Live Chat', 'Agent connection established. Opening secure tunnel...', 3000); break;
            default: break;
        }
    };

    const [searchQuery, setSearchQuery] = React.useState('');

    const handleSearch = (e?: React.FormEvent) => {
        if (e) e.preventDefault();
        if (!searchQuery.trim()) return;

        toast.success('Analyzing Inquiry', `Searching for: "${searchQuery}" in Knowledge Hub...`);
        navigate(`/help-center/docs?q=${encodeURIComponent(searchQuery)}`);
    };

    const quickSearches = ['Booking Refund', 'Visa Requirements', 'System Access', 'New User'];

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                {/* Massive Hero Section */}
                <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
                    <div className="text-left space-y-4 flex-1">
                        <div className="inline-flex items-center px-4 py-1.5 bg-white/20 text-white rounded-full text-[10px] font-bold uppercase tracking-[0.2em] backdrop-blur-sm">
                            <ShieldCheck className={cn("h-3.5 w-3.5", isRTL ? "ml-2" : "mr-2")} />
                            Premium Support Active
                        </div>
                        <h1 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-[1.1]">
                            Excellence in <span className="text-blue-200">Assistance</span>
                        </h1>
                        <p className="text-blue-100 text-base font-medium max-w-xl leading-relaxed">
                            Access our global intelligence hub for instant solutions and specialized support.
                        </p>
                    </div>

                    <div className="flex-1 w-full mt-6 sm:mt-0">
                        <form onSubmit={handleSearch} className="relative group max-w-xl mx-auto sm:mx-0 sm:ml-auto">
                            <div className="relative flex items-center bg-white rounded-[2rem] p-2 pr-2.5 shadow-lg border-none focus-within:ring-4 focus-within:ring-white/30 transition-all duration-300">
                                <div className="flex items-center flex-1">
                                    <Search className={cn("h-5 w-5 text-gray-400 group-focus-within:text-blue-500 transition-colors", isRTL ? "mr-5" : "ml-5")} />
                                    <input
                                        type="text"
                                        value={searchQuery}
                                        onChange={(e) => setSearchQuery(e.target.value)}
                                        placeholder="How can we help you today?"
                                        className="w-full bg-transparent border-none focus:ring-0 focus:outline-none text-gray-900 px-4 py-3 text-[15px] font-medium placeholder-gray-400/80"
                                    />
                                </div>
                                <Button
                                    type="submit"
                                    className="bg-blue-600 hover:bg-blue-700 text-white px-8 h-12 rounded-[1.4rem] font-bold text-[11px] uppercase tracking-[0.1em] shadow-lg shadow-blue-500/25"
                                >
                                    Search
                                </Button>
                            </div>
                        </form>
                        <div className="flex flex-wrap items-center justify-start gap-2.5 mt-4 sm:ml-auto">
                            <span className="text-[10px] font-bold text-blue-200 uppercase tracking-widest mr-1.5">Quick Help:</span>
                            {quickSearches.map(term => (
                                <button
                                    key={term}
                                    onClick={() => {
                                        setSearchQuery(term);
                                        navigate(`/help-center/docs?q=${encodeURIComponent(term)}`);
                                    }}
                                    className="px-3 py-1 rounded-full bg-white/10 text-[10px] font-semibold text-white hover:bg-white/20 transition-all"
                                >
                                    {term}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>

            {/* Core Action Hub */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group cursor-pointer" onClick={() => handleQuickAction('docs')}>
                    <CardContent className="p-6 h-full flex flex-col justify-center text-center space-y-6">
                        <BookOpen className={cn("absolute -bottom-4 h-24 w-24 text-blue-500/10 group-hover:scale-110 transition-transform duration-300", isRTL ? "rtl:-left-4" : "ltr:-right-4")} />
                        <div className="relative z-10">
                            <div className="inline-flex p-5 bg-blue-50 dark:bg-blue-900/20 rounded-3xl text-blue-600 group-hover:rotate-12 transition-transform shadow-sm">
                                <BookOpen className="h-10 w-10" />
                            </div>
                            <div className="space-y-2 mt-4">
                                <h3 className="text-xl font-bold text-gray-900 dark:text-white tracking-tight">Knowledge Hub</h3>
                                <p className="text-sm font-medium text-gray-500 dark:text-gray-400 leading-relaxed">400+ technical articles and operational guides</p>
                            </div>
                            <Button variant="ghost" className="text-blue-600 font-bold uppercase tracking-wider text-[10px] group-hover:translate-x-2 transition-transform mt-2">
                                Browse Intelligence <ArrowRight className="ml-2 h-4 w-4" />
                            </Button>
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group cursor-pointer" onClick={() => handleQuickAction('tickets')}>
                    <CardContent className="p-6 h-full flex flex-col justify-center text-center space-y-6">
                        <MessageSquare className={cn("absolute -bottom-4 h-24 w-24 text-blue-500/10 group-hover:scale-110 transition-transform duration-300", isRTL ? "rtl:-left-4" : "ltr:-right-4")} />
                        <div className="relative z-10">
                            <div className="inline-flex p-5 bg-blue-50 dark:bg-blue-900/20 rounded-3xl text-blue-600 group-hover:scale-110 transition-transform shadow-sm">
                                <MessageSquare className="h-10 w-10" />
                            </div>
                            <div className="space-y-2 mt-4">
                                <h3 className="text-xl font-bold text-gray-900 dark:text-white tracking-tight">Global Ticketing</h3>
                                <p className="text-sm font-medium text-gray-500 dark:text-gray-400 leading-relaxed">Direct tunnel to our resolution specialist dashboard</p>
                            </div>
                            <Button variant="outline" className="text-blue-600 border-blue-100 font-bold uppercase tracking-wider text-[10px] hover:bg-blue-50 mt-2">
                                Submit Request <Zap className="ml-2 h-4 w-4 fill-current" />
                            </Button>
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group cursor-pointer" onClick={() => handleQuickAction('chat')}>
                    <CardContent className="p-6 h-full flex flex-col justify-center text-center space-y-6">
                        <LifeBuoy className={cn("absolute -bottom-4 h-24 w-24 text-indigo-500/10 group-hover:scale-110 transition-transform duration-300", isRTL ? "rtl:-left-4" : "ltr:-right-4")} />
                        <div className="relative z-10">
                            <div className="inline-flex p-5 bg-indigo-50 dark:bg-indigo-900/20 rounded-3xl text-indigo-600 group-hover:-rotate-12 transition-transform shadow-sm">
                                <LifeBuoy className="h-10 w-10" />
                            </div>
                            <div className="space-y-2 mt-4">
                                <h3 className="text-xl font-bold text-gray-900 dark:text-white tracking-tight">Real-time Sync</h3>
                                <p className="text-sm font-medium text-gray-500 dark:text-gray-400 leading-relaxed">Instant session with live support agents (24/7)</p>
                            </div>
                            <Button variant="ghost" className="text-indigo-600 font-bold uppercase tracking-wider text-[10px] group-hover:translate-x-2 transition-transform mt-2">
                                Initiate Chat <ArrowRight className="ml-2 h-4 w-4" />
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <div className="bg-gray-900 rounded-[3rem] p-12 md:p-20 text-white relative overflow-hidden shadow-2xl">
                <div className="relative z-10 flex flex-col md:flex-row items-center gap-16">
                    <div className="flex-1 space-y-8">
                        <div className="flex items-center space-x-3 text-blue-400 text-xs font-bold uppercase tracking-widest">
                            <PlayCircle className="h-5 w-5" />
                            Visual Training
                        </div>
                        <h2 className="text-4xl md:text-5xl font-bold tracking-tight leading-tight">
                            Master the System in <span className="text-blue-500">Minutes</span>
                        </h2>
                        <p className="text-gray-400 text-lg font-medium leading-relaxed">
                            Watch our training videos designed to help your team become power users.
                            From lead automation to financial reconciliation.
                        </p>
                        <div className="flex space-x-4">
                            <Button className="h-14 px-10 bg-blue-600 font-black uppercase tracking-widest text-xs rounded-2xl shadow-xl shadow-blue-500/20 hover:scale-105 transition-transform" onClick={() => toast.success('Video Loading', 'Accessing masterclass archives...')}>
                                Watch Tutorials
                            </Button>
                            <Button variant="outline" className="h-14 px-8 border-gray-700 font-black uppercase tracking-widest text-[10px] bg-white/5 hover:bg-white/10">
                                View Curriculum
                            </Button>
                        </div>
                    </div>
                    <div className="flex-1 relative">
                        <div className="aspect-video bg-gray-50 dark:bg-gray-900 rounded-[2rem] border border-gray-100 dark:border-gray-800 flex items-center justify-center relative group cursor-pointer shadow-sm overflow-hidden" onClick={() => toast.success('Video Loading', 'Accessing masterclass archives...')}>
                            <PlayCircle className="h-20 w-20 text-blue-600 group-hover:scale-110 transition-transform duration-500" />
                        </div>
                    </div>
                </div>
                {/* Background numbers */}
                <div className="absolute bottom-0 left-0 text-[15rem] font-black text-white/5 tracking-tighter -mb-20 -ml-10 select-none">HUB</div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 px-4">
                {[
                    { label: 'Satisfaction', value: '4.9/5' },
                    { label: 'Response Time', value: '< 2m' },
                    { label: 'Accuracy', value: '99.9%' },
                    { label: 'Live Agents', value: '24' }
                ].map((stat, i) => (
                    <div key={i} className="text-center space-y-1 py-8 rounded-2xl bg-gray-50 dark:bg-gray-800/50 hover:bg-white dark:hover:bg-gray-800 transition-all shadow-sm border border-transparent hover:border-gray-100 dark:hover:border-gray-700">
                        <p className="text-xl font-bold text-gray-900 dark:text-white tracking-tight">{stat.value}</p>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none">{stat.label}</p>
                    </div>
                ))}
            </div>
        </div>
        </div>
    );
};
