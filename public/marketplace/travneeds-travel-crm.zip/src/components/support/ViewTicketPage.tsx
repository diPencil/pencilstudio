import React from 'react';
import { User, Calendar, Tag, MessageSquare, Phone, Mail, ArrowLeft } from 'lucide-react';
import { formatDate, formatDateTime } from '../../utils/format';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '../ui/Button';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

const mockComments = [
  {
    id: 1,
    author: 'Super Admin',
    content: 'I have contacted the customer via email to clarify the refund request details.',
    timestamp: '2025-01-07T11:30:00Z',
    type: 'internal'
  },
  {
    id: 2,
    author: 'Finance Team',
    content: 'Refund policy allows full refund for visa-related cancellations. Processing refund.',
    timestamp: '2025-01-07T14:15:00Z',
    type: 'internal'
  },
  {
    id: 3,
    author: 'Super Admin',
    content: 'Customer confirmed bank details. Refund will be processed within 3-5 business days.',
    timestamp: '2025-01-07T16:45:00Z',
    type: 'update'
  }
];

export const ViewTicketPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { t, direction, isRTL } = useLocale();

  const ticket = location.state?.ticket;

  if (!ticket) {
      return (
          <div className="w-full pb-8 pt-8 flex justify-center">
             <Button onClick={() => navigate('/help-center/tickets')}>{t('common.back') || 'Back to Support'}</Button>
          </div>
      );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Open': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      case 'In Progress': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'Awaiting Client': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300';
      case 'Escalated': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      case 'Closed': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Urgent': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      case 'High': return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300';
      case 'Normal': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      case 'Low': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate('/help-center/tickets')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                Ticket Details - {ticket.id}
              </h1>
              <p className="mt-1 text-sm text-blue-100 opacity-90">
                 View support ticket details and progress
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
            {/* Ticket Information */}
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 md:p-8 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">
                Ticket Information
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex items-center space-x-3">
                    <User className="h-5 w-5 text-blue-500" />
                    <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Customer</p>
                    <p className="font-medium text-gray-900 dark:text-white">{ticket.customer}</p>
                    </div>
                </div>
                <div className="flex items-center space-x-3">
                    <Calendar className="h-5 w-5 text-blue-500" />
                    <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Booking Reference</p>
                    <p className="font-medium text-gray-900 dark:text-white">{ticket.bookingRef}</p>
                    </div>
                </div>
                <div className="flex items-center space-x-3">
                    <MessageSquare className="h-5 w-5 text-blue-500" />
                    <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Source</p>
                    <p className="font-medium text-gray-900 dark:text-white">{ticket.source}</p>
                    </div>
                </div>
                <div className="flex items-center space-x-3">
                    <User className="h-5 w-5 text-blue-500" />
                    <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Assigned To</p>
                    <p className="font-medium text-gray-900 dark:text-white">{ticket.assignedTo}</p>
                    </div>
                </div>
                </div>
            </div>

            {/* Subject & Description */}
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 md:p-8 shadow-sm">
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                {ticket.subject}
                </h3>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed bg-gray-50 dark:bg-gray-800 p-4 rounded-xl">
                {ticket.description}
                </p>
            </div>

            {/* Comments */}
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 md:p-8 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">
                Comments & Updates
                </h3>
                <div className="space-y-4">
                {mockComments.map((comment) => (
                    <div key={comment.id} className="p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700">
                    <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center space-x-3">
                        <div className="h-8 w-8 rounded-full overflow-hidden shadow-sm flex-shrink-0 border border-gray-200 dark:border-gray-700">
                            <img src={comment.author.toLowerCase().includes('fatma') || comment.author.toLowerCase().includes('nour') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
                        </div>
                        <div>
                            <span className="font-bold text-gray-900 dark:text-white text-sm">{comment.author}</span>
                            <div className="mt-1">
                                <span className={`inline-flex px-2 py-0.5 text-[10px] font-bold uppercase rounded ${comment.type === 'internal' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300' :
                                'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300'
                                }`}>
                                {comment.type}
                                </span>
                            </div>
                        </div>
                        </div>
                        <span className="text-xs font-bold text-gray-400">
                        {formatDateTime(comment.timestamp)}
                        </span>
                    </div>
                    <p className="text-gray-700 dark:text-gray-300 text-sm mt-2 ml-11 leading-relaxed">{comment.content}</p>
                    </div>
                ))}
                </div>
            </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
            {/* Status & Priority */}
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 md:p-8 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">
                Status & Priority
                </h3>
                <div className="space-y-6">
                <div>
                    <p className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">Status</p>
                    <span className={`inline-flex px-3 py-1 text-sm font-bold rounded-lg ${getStatusColor(ticket.status)}`}>
                    {ticket.status}
                    </span>
                </div>
                <div>
                    <p className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">Priority</p>
                    <span className={`inline-flex px-3 py-1 text-sm font-bold rounded-lg ${getPriorityColor(ticket.priority)}`}>
                    {ticket.priority}
                    </span>
                </div>
                <div>
                    <p className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-1">Department</p>
                    <p className="font-bold text-gray-900 dark:text-white">{ticket.department}</p>
                </div>
                <div>
                    <p className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-1">Due Date</p>
                    <p className="font-bold text-gray-900 dark:text-white">{formatDate(ticket.dueDate)}</p>
                </div>
                </div>
            </div>

            {/* Tags */}
            {ticket.tags && ticket.tags.length > 0 && (
                <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 md:p-8 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    Tags
                </h3>
                <div className="flex flex-wrap gap-2">
                    {ticket.tags.map((tag: string, index: number) => (
                    <span key={index} className="inline-flex px-3 py-1 text-xs font-bold rounded-lg bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300">
                        <Tag className="h-3 w-3 mr-2" />
                        {tag}
                    </span>
                    ))}
                </div>
                </div>
            )}

            {/* Quick Actions */}
            <div className="bg-blue-50 dark:bg-blue-900/10 rounded-3xl p-6 border border-blue-100 dark:border-blue-900/30">
                <h4 className="text-sm font-bold text-blue-800 dark:text-blue-300 uppercase tracking-wider mb-4">
                Quick Actions
                </h4>
                <div className="space-y-2">
                <button className="w-full text-left text-sm font-bold text-blue-700 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 flex items-center space-x-3 p-3 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-900/20 transition-colors">
                    <Phone className="h-4 w-4" />
                    <span>Call customer</span>
                </button>
                <button className="w-full text-left text-sm font-bold text-blue-700 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 flex items-center space-x-3 p-3 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-900/20 transition-colors">
                    <Mail className="h-4 w-4" />
                    <span>Send email</span>
                </button>
                <button className="w-full text-left text-sm font-bold text-blue-700 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 flex items-center space-x-3 p-3 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-900/20 transition-colors">
                    <MessageSquare className="h-4 w-4" />
                    <span>Add comment</span>
                </button>
                <button className="w-full text-left text-sm font-bold text-blue-700 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 flex items-center space-x-3 p-3 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-900/20 transition-colors">
                    <User className="h-4 w-4" />
                    <span>Reassign ticket</span>
                </button>
                </div>
            </div>
            </div>
        </div>
      </div>
    </div>
  );
};
