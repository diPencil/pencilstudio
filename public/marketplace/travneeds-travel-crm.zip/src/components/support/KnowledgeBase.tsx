import React, { useState } from 'react';
import { Search, Book, FileText, ExternalLink, Zap, HelpCircle, Shield, Settings, Users, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
// ArticleModal replaced by inline toast
import { useToastContext } from '../../contexts/ToastContext';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

const categories = [
    {
        id: 'getting-started',
        title: 'Getting Started',
        icon: Zap,
        count: 12,
        color: 'text-yellow-600 bg-yellow-100',
        description: 'Learn the basics of using the platform'
    },
    {
        id: 'user-management',
        title: 'User Management',
        icon: Users,
        count: 8,
        color: 'text-blue-600 bg-blue-100',
        description: 'Manage team members and their roles'
    },
    {
        id: 'booking-system',
        title: 'Booking & Reservations',
        icon: FileText,
        count: 15,
        color: 'text-green-600 bg-green-100',
        description: 'Handle customer bookings and vouchers'
    },
    {
        id: 'security',
        title: 'Security & Privacy',
        icon: Shield,
        count: 6,
        color: 'text-red-600 bg-red-100',
        description: 'Keep your data safe and compliant'
    },
    {
        id: 'finance',
        title: 'Finance & Payments',
        icon: Book,
        count: 10,
        color: 'text-purple-600 bg-purple-100',
        description: 'Manage invoices and payment records'
    },
    {
        id: 'settings',
        title: 'System Settings',
        icon: Settings,
        count: 5,
        color: 'text-gray-600 bg-gray-100',
        description: 'Configure global system parameters'
    }
];

const popularArticles = [
    { title: 'How to create a new reservation', category: 'Booking System', views: '1.2k' },
    { title: 'Managing user roles and permissions', category: 'User Management', views: '850' },
    { title: 'Processing refunds and cancellations', category: 'Finance', views: '1k' },
    { title: 'Setting up multi-factor authentication', category: 'Security', views: '600' }
];

export const KnowledgeBase: React.FC = () => {
    const { isRTL, direction } = useLocale();
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedArticle, setSelectedArticle] = useState<any>(null);
    // article modal replaced by toast
    const toast = useToastContext();

    const handleOpenArticle = (article: any) => {
        setSelectedArticle(article);
        toast.info(article.title, 'Opening article...');
    };

    const handleCategoryClick = (category: string) => {
        toast.info('Category Selected', `Browsing articles in ${category}.`);
    };

    const filteredArticles = popularArticles.filter(art =>
        art.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        art.category.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
                    <div className="flex-1 space-y-4">
                        <div className="inline-flex p-3 bg-white/20 rounded-2xl mb-2">
                            <HelpCircle className="h-8 w-8 text-white" />
                        </div>
                        <h1 className="text-3xl md:text-4xl font-black tracking-tight text-white">How can we help you?</h1>
                        <p className="text-blue-100 text-lg font-medium opacity-90">Search our refined knowledge base for quick answers and expert guides.</p>
                    </div>
                    <div className="relative flex-1 max-w-xl w-full">
                        <Search className={cn("absolute top-1/2 transform -translate-y-1/2 h-6 w-6 text-gray-400", isRTL ? "right-5" : "left-5")} />
                        <Input
                            type="text"
                            placeholder="Search guides, tutorials, and FAQs..."
                            className={cn("w-full h-16 bg-white text-gray-900 border-none shadow-sm rounded-2xl text-lg focus:ring-4 focus:ring-blue-400 transition-all font-medium", isRTL ? "pr-14" : "pl-14")}
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>

            {/* Categories Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {categories.map((category) => (
                    <Card
                        key={category.id}
                        className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group cursor-pointer"
                        onClick={() => handleCategoryClick(category.title)}
                    >
                        <CardContent className="p-6">
                            <category.icon className={cn("absolute -bottom-4 h-24 w-24 group-hover:scale-110 transition-transform duration-300", isRTL ? "rtl:-left-4" : "ltr:-right-4", category.color.split(' ')[0].replace('text-', 'text-').replace('600', '500/10'))} />
                            <div className={cn("flex items-start relative z-10", isRTL ? "space-x-reverse space-x-6" : "space-x-6")}>
                                <div className={`p-4 rounded-2xl ${category.color} group-hover:rotate-6 transition-transform shadow-sm`}>
                                    <category.icon className="h-8 w-8" />
                                </div>
                                <div className="flex-1">
                                    <h3 className="text-xl font-extrabold text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                                        {category.title}
                                    </h3>
                                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-2 leading-relaxed">{category.description}</p>
                                    <div className="flex items-center mt-6 text-blue-600 dark:text-blue-400 font-bold text-sm">
                                        {category.count} Articles <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-2 transition-transform" />
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Popular Articles */}
                <Card className="border-none shadow-sm overflow-hidden">
                    <CardHeader className="bg-gray-50/50 dark:bg-gray-900/50 border-b border-gray-100 dark:border-gray-800">
                        <CardTitle className="text-xl flex items-center font-black uppercase tracking-tight">
                            <Zap className="h-5 w-5 mr-3 text-yellow-500" />
                            Popular Articles
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                        <div className="divide-y divide-gray-100 dark:divide-gray-800">
                            {(searchTerm ? filteredArticles : popularArticles).map((article, index) => (
                                <div
                                    key={index}
                                    className="p-5 hover:bg-blue-50/50 dark:hover:bg-blue-900/10 cursor-pointer flex items-center justify-between group transition-colors"
                                    onClick={() => handleOpenArticle(article)}
                                >
                                    <div className="flex items-center space-x-4">
                                        <div className="w-10 h-10 rounded-xl bg-gray-100 dark:bg-gray-700 flex items-center justify-center group-hover:bg-white dark:group-hover:bg-gray-600 shadow-sm transition-colors">
                                            <FileText className="h-5 w-5 text-gray-400 group-hover:text-blue-500" />
                                        </div>
                                        <div>
                                            <p className="text-sm font-bold text-gray-900 dark:text-white group-hover:text-blue-600 transition-colors">{article.title}</p>
                                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 uppercase tracking-wider font-medium">{article.category}</p>
                                        </div>
                                    </div>
                                    <div className="text-xs text-gray-400 flex items-center">
                                        <span className="mr-4 font-medium">{article.views} views</span>
                                        <ExternalLink className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0" />
                                    </div>
                                </div>
                            ))}
                            {(searchTerm && filteredArticles.length === 0) && (
                                <div className="p-12 text-center">
                                    <Search className="h-12 w-12 text-gray-200 mx-auto mb-4" />
                                    <p className="text-gray-500 font-medium">No articles found matching "{searchTerm}"</p>
                                </div>
                            )}
                        </div>
                        <div className="p-4 bg-gray-50/50 dark:bg-gray-800 mt-2 rounded-b-xl border-t border-gray-100 dark:border-gray-800 text-center">
                            <Button variant="ghost" size="sm" className="text-blue-600 dark:text-blue-400 font-bold uppercase tracking-widest text-[10px]">View All 48 Articles</Button>
                        </div>
                    </CardContent>
                </Card>

                {/* Need more help? */}
                <div className="flex flex-col justify-center space-y-8 bg-white dark:bg-gray-800 p-10 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-sm relative overflow-hidden group">
                    <div className="relative z-10 space-y-4">
                        <h2 className="text-3xl font-black text-gray-900 dark:text-white tracking-tight">Still stuck?</h2>
                        <p className="description-sm text-lg leading-relaxed">Our support heroes are available 24/7 to assist you. Average response time is usually under 10 minutes.</p>
                    </div>
                    <div className="relative z-10 flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
                        <Button className="flex-1 h-14 text-base font-black shadow-sm bg-blue-600 hover:scale-105 transition-transform" onClick={() => toast.success('Agent Alerted', 'A support specialist will join you in a moment.')}>
                            <HelpCircle className="h-5 w-5 mr-2" />
                            Contact Support
                        </Button>
                        <Button variant="outline" className="flex-1 h-14 text-base font-black bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 shadow-sm hover:bg-gray-50" onClick={() => toast.info('Community Access', 'Redirecting to community forums...')}>
                            <Users className="h-5 w-5 mr-2 text-blue-600" />
                            Join Community
                        </Button>
                    </div>
                    <div className="relative z-10 grid grid-cols-2 gap-4 mt-4">
                        <div className="bg-gray-50 dark:bg-gray-900/50 backdrop-blur-sm p-5 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 text-center group-hover:scale-105 transition-transform duration-300">
                            <p className="text-3xl font-black text-blue-600">99.8%</p>
                            <p className="label-xs mt-1">Resolution Rate</p>
                        </div>
                        <div className="bg-gray-50 dark:bg-gray-900/50 backdrop-blur-sm p-5 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 text-center group-hover:scale-105 transition-transform duration-300 delay-75">
                            <p className="text-3xl font-black text-indigo-600">6m</p>
                            <p className="label-xs mt-1">Avg. Response</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* ArticleModal replaced by inline toast */}
            </div>
        </div>
    );
};
