import React, { useState, useEffect } from 'react';
import { Save, ArrowLeft } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

const sources = ['Email', 'WhatsApp', 'Phone', 'Internal', 'Website', 'Walk-in'];
const departments = ['Sales', 'Reservation', 'Operations', 'Finance', 'Support'];
const priorities = ['Low', 'Normal', 'High', 'Urgent'];
const statuses = ['Open', 'In Progress', 'Awaiting Client', 'Escalated', 'Closed'];
const staff = ['Super Admin', 'Mahmoud Khalil', 'Layla Ramadan', 'Sami Youssef', 'Mona Zaki'];

export const EditTicketPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToastContext();
  const { t, direction, isRTL } = useLocale();

  const ticket = location.state?.ticket;

  const [formData, setFormData] = useState({
    customer: '',
    bookingRef: '',
    subject: '',
    description: '',
    source: 'Email',
    department: 'Support',
    priority: 'Normal',
    status: 'Open',
    assignedTo: 'Super Admin',
    tags: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (ticket) {
      setFormData({
        customer: ticket.customer || '',
        bookingRef: ticket.bookingRef || '',
        subject: ticket.subject || '',
        description: ticket.description || '',
        source: ticket.source || 'Email',
        department: ticket.department || 'Support',
        priority: ticket.priority || 'Normal',
        status: ticket.status || 'Open',
        assignedTo: ticket.assignedTo || 'Super Admin',
        tags: ticket.tags ? ticket.tags.join(', ') : ''
      });
    } else {
        navigate('/help-center/tickets');
    }
  }, [ticket, navigate]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.customer.trim()) {
      newErrors.customer = 'Customer name is required';
    }

    if (!formData.subject.trim()) {
      newErrors.subject = 'Subject is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      toast.success(isRTL ? 'تم تحديث التذكرة' : 'Ticket Updated', isRTL ? 'تم حفظ التغييرات.' : 'Changes saved.');
      navigate('/help-center/tickets');
    } catch (error) {
      console.error('Error updating ticket:', error);
      toast.error('Error', 'Failed to update ticket');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  if (!ticket) return null;

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate('/help-center/tickets')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                Edit Ticket - {ticket.id}
              </h1>
              <p className="mt-1 text-sm text-blue-100 opacity-90">
                 Update support ticket details
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-8 shadow-sm">
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="Customer Name *"
                value={formData.customer}
                onChange={(e) => handleInputChange('customer', e.target.value)}
                error={errors.customer}
                placeholder="Enter customer name"
              />

              <Input
                label="Booking Reference"
                value={formData.bookingRef}
                onChange={(e) => handleInputChange('bookingRef', e.target.value)}
                placeholder="e.g., BK-2025-001"
              />

              <div className="md:col-span-2">
                <Input
                  label="Subject *"
                  value={formData.subject}
                  onChange={(e) => handleInputChange('subject', e.target.value)}
                  error={errors.subject}
                  placeholder="Brief description of the issue"
                />
              </div>

              <Select
                label="Source"
                value={formData.source}
                onChange={(e) => handleInputChange('source', e.target.value)}
              >
                {sources.map(source => (
                  <option key={source} value={source}>{source}</option>
                ))}
              </Select>

              <Select
                label="Department"
                value={formData.department}
                onChange={(e) => handleInputChange('department', e.target.value)}
              >
                {departments.map(dept => (
                  <option key={dept} value={dept}>{dept}</option>
                ))}
              </Select>

              <Select
                label="Priority"
                value={formData.priority}
                onChange={(e) => handleInputChange('priority', e.target.value)}
              >
                {priorities.map(priority => (
                  <option key={priority} value={priority}>{priority}</option>
                ))}
              </Select>

              <Select
                label="Status"
                value={formData.status}
                onChange={(e) => handleInputChange('status', e.target.value)}
              >
                {statuses.map(status => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </Select>

              <Select
                label="Assign To"
                value={formData.assignedTo}
                onChange={(e) => handleInputChange('assignedTo', e.target.value)}
              >
                {staff.map(member => (
                  <option key={member} value={member}>{member}</option>
                ))}
              </Select>

              <Input
                label="Tags (comma separated)"
                value={formData.tags}
                onChange={(e) => handleInputChange('tags', e.target.value)}
                placeholder="e.g., refund, urgent, visa"
              />
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Description *
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={4}
                className={`block w-full px-4 py-3 border rounded-xl shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all ${errors.description ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'
                  }`}
                placeholder="Detailed description of the issue..."
              />
              {errors.description && (
                <p className="text-sm text-red-600 dark:text-red-400 mt-1">{errors.description}</p>
              )}
            </div>

            <div className="flex justify-end space-x-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate('/help-center/tickets')}
                disabled={isLoading}
              >
                {t('common.cancel') || 'Cancel'}
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                loading={isLoading}
              >
                <Save className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                Update Ticket
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
