import React from 'react';
import { X, FileText, Globe, Clock, ThumbsUp, ThumbsDown, MessageSquare } from 'lucide-react';
import { Button } from '../ui/Button';

interface ArticleModalProps {
    isOpen: boolean;
    onClose: () => void;
    article: any;
}

export const ArticleModal: React.FC<ArticleModalProps> = ({ isOpen, onClose, article }) => {
    if (!isOpen || !article) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-white dark:bg-gray-800 rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden shadow-2xl flex flex-col scale-in-center">
                {/* Header */}
                <div className="p-6 border-b border-gray-100 dark:border-gray-700 flex items-start justify-between bg-gray-50 dark:bg-gray-900/50">
                    <div className="space-y-1">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                            {article.category}
                        </span>
                        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{article.title}</h2>
                        <div className="flex items-center space-x-4 text-sm text-gray-500 mt-2">
                            <span className="flex items-center"><Clock className="h-4 w-4 mr-1" /> 5 min read</span>
                            <span className="flex items-center"><Globe className="h-4 w-4 mr-1" /> Public Access</span>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full transition-colors">
                        <X className="h-6 w-6 text-gray-400" />
                    </button>
                </div>

                {/* Content */}
                <div className="p-8 overflow-y-auto flex-1 prose dark:prose-invert max-w-none">
                    <div className="space-y-6 text-gray-600 dark:text-gray-300 leading-relaxed">
                        <p className="text-lg font-medium text-gray-900 dark:text-white">
                            In this guide, we will walk you through the essential steps to {article.title.toLowerCase()}.
                            Efficiency and accuracy are key to providing top-tier service.
                        </p>

                        <h3 className="text-xl font-bold text-gray-900 dark:text-white mt-8">1. Pre-requisites</h3>
                        <p>Before beginning the process, ensure you have the following permissions and data ready:</p>
                        <ul className="list-disc pl-5 space-y-2">
                            <li>Active system account with Management or Admin role</li>
                            <li>Verified customer profiles for any associated accounts</li>
                            <li>Documentation for relevant transactions or requests</li>
                        </ul>

                        <h3 className="text-xl font-bold text-gray-900 dark:text-white mt-8">2. Step-by-Step Instructions</h3>
                        <p>Follow these steps carefully to ensure system synchronization:</p>
                        <ol className="list-decimal pl-5 space-y-4">
                            <li>
                                <strong>Access the Module:</strong> Navigate to the relevant department module from the sidebar.
                                The system will load the dashboard associated with your permissions.
                            </li>
                            <li>
                                <strong>Locate the Create Action:</strong> Usually found in the top-right corner of the page.
                                Click the "New" or "Add" button to open the workspace.
                            </li>
                            <li>
                                <strong>Input Required Fields:</strong> Fill in all mandatory fields (marked with *).
                                Our system uses real-time validation to catch errors before submission.
                            </li>
                            <li>
                                <strong>Save and Review:</strong> Click the primary action button to save.
                                Review the confirmation toast to ensure the action was successful.
                            </li>
                        </ol>

                        <div className="bg-blue-50 dark:bg-blue-900/10 p-4 rounded-xl border border-blue-100 dark:border-blue-900/30 flex items-start space-x-3 mt-8">
                            <FileText className="h-5 w-5 text-blue-600 mt-1" />
                            <p className="text-sm text-blue-800 dark:text-blue-300">
                                <strong>Note:</strong> If you encounter any "Permission Denied" errors,
                                please contact your System Administrator to review your role configuration.
                            </p>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="p-6 border-t border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="flex items-center space-x-4">
                        <span className="text-sm font-medium text-gray-500">Was this article helpful?</span>
                        <div className="flex space-x-2">
                            <Button variant="outline" size="sm" className="h-9 px-4">
                                <ThumbsUp className="h-4 w-4 mr-2 text-green-600" /> Yes
                            </Button>
                            <Button variant="outline" size="sm" className="h-9 px-4">
                                <ThumbsDown className="h-4 w-4 mr-2 text-red-600" /> No
                            </Button>
                        </div>
                    </div>
                    <div className="flex items-center space-x-3">
                        <Button variant="ghost" size="sm" className="text-gray-500">
                            <MessageSquare className="h-4 w-4 mr-2" /> Suggest Edit
                        </Button>
                        <Button onClick={onClose}>Done</Button>
                    </div>
                </div>
            </div>
        </div>
    );
};
