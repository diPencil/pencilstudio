import React, { useState } from 'react';
import { Download, Search, Users, CalendarOff, Clock, Zap, Calendar, Edit2 } from 'lucide-react';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { useToastContext } from '../../contexts/ToastContext';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { useNavigate } from 'react-router-dom';
import { CalendarViewModal } from './CalendarViewModal';

const mockAttendance = [
    { id: 'ATT-001', employee: 'Ahmed Hassan', department: 'Sales', shift: '09:00 - 17:00', checkIn: '08:55', checkOut: '17:15', status: 'On Time', totalHours: '8h 20m' },
    { id: 'ATT-002', employee: 'Fatma Ahmed', department: 'Operations', shift: '08:00 - 16:00', checkIn: '08:15', checkOut: '16:00', status: 'Late', totalHours: '7h 45m' },
    { id: 'ATT-003', employee: 'Mohamed Ali', department: 'Accounts', shift: '09:00 - 17:00', checkIn: '-', checkOut: '-', status: 'On Leave', totalHours: '-' },
    { id: 'ATT-004', employee: 'Nour Ibrahim', department: 'Reservations', shift: '10:00 - 18:00', checkIn: '09:45', checkOut: '-', status: 'Working', totalHours: '6h 30m' }
];

export const AttendancePage: React.FC = () => {
    const [attendance] = useState(mockAttendance);
    const [searchTerm, setSearchTerm] = useState('');
    const [departmentFilter, setDepartmentFilter] = useState('All Departments');
    const [currentTime, setCurrentTime] = useState(new Date());
    const [isCalendarOpen, setIsCalendarOpen] = useState(false);

    const toast = useToastContext();
    const navigate = useNavigate();

    React.useEffect(() => {
        const timer = setInterval(() => setCurrentTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'On Time': return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/20';
            case 'Late': return 'bg-amber-100 text-amber-800 dark:bg-amber-900/20';
            case 'Working': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20';
            case 'On Leave': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20';
            case 'Absent': return 'bg-rose-100 text-rose-800 dark:bg-rose-900/20';
            default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20';
        }
    };

    const filteredAttendance = attendance.filter(a => {
        const matchesSearch = a.employee.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesDept = departmentFilter === 'All Departments' || a.department === departmentFilter;
        return matchesSearch && matchesDept;
    });

    return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div>
                        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Time & Attendance</h1>
                        <p className="mt-1 text-sm text-blue-100 opacity-90">Shift management, workforce clock-in, and leave tracking</p>
                    </div>
                    <div className="flex items-center space-x-4 mt-4 sm:mt-0">
                        <div className="flex items-center bg-white/10 rounded-xl p-2 px-4 space-x-4 border border-white/10">
                            <div>
                                <p className="text-[10px] font-bold uppercase tracking-widest text-blue-100">System Time</p>
                                <p className="text-sm font-bold">{currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                            </div>
                            <Button variant="outline" size="sm" className="bg-white/10 border-white/20 text-white hover:bg-white/20 px-3" onClick={() => toast.success('Punch recorded', 'Check-out successful.')}>
                                Punch Out
                            </Button>
                        </div>
                        <Button variant="outline" className="bg-white/10 text-white border-transparent hover:bg-white/20" onClick={() => setIsCalendarOpen(true)}>
                            <Calendar className="h-4 w-4 mr-2" />
                            Calendar
                        </Button>
                        <Button className="bg-white text-blue-600 hover:bg-gray-50" onClick={() => navigate('/attendance/leave-requests')}>
                            <CalendarOff className="h-4 w-4 mr-2" />
                            Leave Request
                        </Button>
                    </div>
                </div>

            {/* Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Active Today</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white">124</p>
                        </div>
                        <Users className="absolute -right-4 -bottom-4 h-24 w-24 text-emerald-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>

                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Late Arrivals</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white">8</p>
                        </div>
                        <Clock className="absolute -right-4 -bottom-4 h-24 w-24 text-amber-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>

                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Avg Efficiency</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white">94.2%</p>
                        </div>
                        <Zap className="absolute -right-4 -bottom-4 h-24 w-24 text-blue-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>

                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Pending Leaves</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white">4</p>
                        </div>
                        <CalendarOff className="absolute -right-4 -bottom-4 h-24 w-24 text-purple-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>
            </div>

            {/* Filters */}
            <Card className="card-premium">
                <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-4">
                        <div className="flex-1 w-full relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                            <Input
                                placeholder="Search by employee name..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="pl-10"
                            />
                        </div>
                        <Select value={departmentFilter} onChange={(e) => setDepartmentFilter(e.target.value)} className="w-full md:w-64">
                            <option>All Departments</option>
                            <option>Sales</option>
                            <option>Operations</option>
                            <option>Finance</option>
                            <option>Reservations</option>
                        </Select>
                        <Button variant="outline" onClick={() => toast.success('Export', 'Attendance data exported successfully.')}>
                            <Download className="h-4 w-4 mr-2" />
                            Export
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Table */}
            <div className="table-container">
                <table className="table-premium">
                    <thead>
                        <tr>
                            <th>Employee</th>
                            <th>Shift Schedule</th>
                            <th>Clock In/Out</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th className="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredAttendance.map((a) => (
                            <tr key={a.id}>
                                <td>
                                    <div className="flex items-center">
                                        <div className="h-8 w-8 rounded-full overflow-hidden mr-3 border border-gray-200 dark:border-gray-700 shadow-sm flex-shrink-0">
                                            <img src={a.employee.toLowerCase().includes('fatma') || a.employee.toLowerCase().includes('nour') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
                                        </div>
                                        <div>
                                            <div className="text-sm font-bold text-gray-900 dark:text-white">{a.employee}</div>
                                            <div className="text-[10px] text-gray-500">{a.department}</div>
                                        </div>
                                    </div>
                                </td>
                                <td><div className="text-xs font-medium">{a.shift}</div></td>
                                <td>
                                    <div className="flex items-center space-x-2">
                                        <div className="text-xs font-bold text-gray-900 dark:text-white">{a.checkIn}</div>
                                        <div className="text-gray-300">|</div>
                                        <div className="text-xs text-gray-500">{a.checkOut}</div>
                                    </div>
                                </td>
                                <td><div className="text-xs font-bold text-blue-600">{a.totalHours}</div></td>
                                <td>
                                    <span className={`badge-standard ${getStatusColor(a.status)}`}>{a.status}</span>
                                </td>
                                <td className="text-right">
                                    <TableActionsDropdown
                                        actions={[
                                            { label: 'Update Reason', icon: Edit2, onClick: () => toast.success('Log Updated', 'Reason recorded.') }
                                        ]}
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Attendance modals replaced by page navigation or toast */}
            <CalendarViewModal 
                isOpen={isCalendarOpen} 
                onClose={() => setIsCalendarOpen(false)} 
                attendance={attendance} 
            />
            </div>
        </div>
    );
};
