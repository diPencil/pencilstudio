import React from 'react';
import { createPortal } from 'react-dom';
import { X, Clock, CheckCircle, XCircle, AlertCircle, FileText } from 'lucide-react';
import { Button } from '../ui/Button';

interface ReviewOvertimeModalProps {
    isOpen: boolean;
    onClose: () => void;
    onApprove: (id: string) => void;
    onReject: (id: string) => void;
    log: any;
}

export const ReviewOvertimeModal: React.FC<ReviewOvertimeModalProps> = ({ isOpen, onClose, onApprove, onReject, log }) => {
    if (!isOpen || !log) return null;

    return createPortal(
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
            <div className="bg-white dark:bg-gray-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col scale-in-center border border-gray-100 dark:border-gray-700">
                <div className="p-6 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between bg-gray-50/50 dark:bg-gray-900/50">
                    <div className="flex items-center space-x-3">
                        <div className="p-2.5 bg-orange-100 text-orange-600 rounded-xl">
                            <Clock className="h-5 w-5" />
                        </div>
                        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Review Request</h2>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-full transition-colors text-gray-400">
                        <X className="h-5 w-5" />
                    </button>
                </div>

                <div className="p-8 space-y-7">
                    <div className="flex items-center space-x-5">
                        <div className="w-16 h-16 rounded-full overflow-hidden shadow-sm flex-shrink-0 border border-gray-200 dark:border-gray-700">
                            <img src={log.employee.toLowerCase().includes('fatma') || log.employee.toLowerCase().includes('nour') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
                        </div>
                        <div>
                            <h3 className="text-xl font-bold text-gray-900 dark:text-white leading-tight">{log.employee}</h3>
                            <p className="text-sm text-gray-500 font-medium mt-1">Request ID: {log.id} • {log.date}</p>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="bg-gray-50/50 dark:bg-gray-900/30 p-5 rounded-2xl border border-gray-100 dark:border-gray-800">
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1.5 opacity-80">Hours Claimed</p>
                            <p className="text-2xl font-bold text-gray-900 dark:text-white">{log.hours}h</p>
                        </div>
                        <div className="bg-gray-50/50 dark:bg-gray-900/30 p-5 rounded-2xl border border-gray-100 dark:border-gray-800">
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1.5 opacity-80">Total Compensation</p>
                            <p className="text-2xl font-bold text-emerald-600">${log.amount}</p>
                        </div>
                    </div>

                    <div className="space-y-3">
                        <div className="flex items-center text-[11px] font-bold text-gray-400 uppercase tracking-widest">
                            <FileText className="h-4 w-4 mr-2 text-indigo-500 opacity-70" />
                            Activity Description
                        </div>
                        <div className="text-[13px] text-gray-600 dark:text-gray-400 bg-gray-50/30 dark:bg-gray-900/20 p-5 rounded-2xl italic leading-relaxed border border-gray-100/50 dark:border-gray-700/30">
                            "{log.reason}"
                        </div>
                    </div>

                    <div className="bg-amber-50/50 dark:bg-amber-900/10 p-4 rounded-2xl border border-amber-100 dark:border-amber-900/30 flex items-start space-x-3">
                        <AlertCircle className="h-4 w-4 text-amber-600 mt-0.5" />
                        <p className="text-[11px] text-amber-800 dark:text-amber-400 font-medium leading-relaxed">
                            Reviewing this request will mark it as verified for payroll processing. This action is recorded and cannot be undone after approval.
                        </p>
                    </div>
                </div>

                <div className="p-6 border-t border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50 flex space-x-4">
                    <Button
                        variant="outline"
                        className="flex-1 border-gray-200 dark:border-gray-700 shadow-sm h-12 font-bold text-rose-600 hover:bg-rose-50 rounded-xl"
                        onClick={() => onReject(log.id)}
                    >
                        <XCircle className="h-4 w-4 mr-2" />
                        Reject Request
                    </Button>
                    <Button
                        className="flex-1 bg-emerald-600 hover:bg-emerald-700 shadow-lg shadow-emerald-500/20 h-12 font-bold rounded-xl"
                        onClick={() => onApprove(log.id)}
                    >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Approve
                    </Button>
                </div>
            </div>
        </div>,
        document.body
    );
};
