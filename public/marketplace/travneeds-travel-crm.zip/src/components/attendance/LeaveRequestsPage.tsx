import React, { useState } from 'react';
import { Calendar, Clock, Plus, User, ChevronRight, FileText, CheckCircle, XCircle, ArrowRight } from 'lucide-react';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
// LeaveRequestModal replaced by inline handling
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { useToastContext } from '../../contexts/ToastContext';

const initialLeaveRequests = [
    {
        id: 'LR-2025-001',
        employee: 'Ahmed Hassan',
        type: 'Annual Leave',
        duration: '5 Days',
        startDate: '2025-01-15',
        endDate: '2025-01-19',
        reason: 'Family vacation to Sharm El Sheikh',
        status: 'Pending',
        appliedOn: '2025-01-05'
    },
    {
        id: 'LR-2025-002',
        employee: 'Fatma Ali',
        type: 'Sick Leave',
        duration: '2 Days',
        startDate: '2025-01-08',
        endDate: '2025-01-09',
        reason: 'Medical procedure and recovery',
        status: 'Approved',
        appliedOn: '2025-01-07'
    },
    {
        id: 'LR-2025-003',
        employee: 'Omar Mahmoud',
        type: 'Emergency Leave',
        duration: '1 Day',
        startDate: '2025-01-12',
        endDate: '2025-01-12',
        reason: 'Personal family emergency',
        status: 'Rejected',
        appliedOn: '2025-01-10'
    },
    {
        id: 'LR-2025-004',
        employee: 'Nour Ibrahim',
        type: 'Unpaid Leave',
        duration: '3 Days',
        startDate: '2025-02-01',
        endDate: '2025-02-03',
        reason: 'Training course and certification',
        status: 'Pending',
        appliedOn: '2025-01-10'
    }
];

export const LeaveRequestsPage: React.FC = () => {
    const [requests, setRequests] = useState(initialLeaveRequests);
    const [filter, setFilter] = useState('All Status');
    // leave request handled inline
    const [confirmConfig, setConfirmConfig] = useState<{
        isOpen: boolean;
        type: 'approve' | 'reject' | null;
        requestId: string | null;
    }>({
        isOpen: false,
        type: null,
        requestId: null
    });
    const toast = useToastContext();

    const getStatusStyle = (status: string) => {
        switch (status) {
            case 'Approved': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
            case 'Rejected': return 'bg-rose-100 text-rose-700 border-rose-200';
            case 'Pending': return 'bg-amber-100 text-amber-700 border-amber-200';
            default: return 'bg-gray-100 text-gray-700 border-gray-200';
        }
    };

    const handleConfirmAction = () => {
        if (!confirmConfig.requestId || !confirmConfig.type) return;

        const id = confirmConfig.requestId;
        if (confirmConfig.type === 'approve') {
            setRequests(prev => prev.map(r => r.id === id ? { ...r, status: 'Approved' } : r));
            toast.success('Request Approved', 'The leave request has been successfully approved.');
        } else {
            setRequests(prev => prev.map(r => r.id === id ? { ...r, status: 'Rejected' } : r));
            toast.info('Request Rejected', 'The leave request has been rejected.');
        }

        setConfirmConfig({ isOpen: false, type: null, requestId: null });
    };

    const handleApprove = (id: string) => {
        setConfirmConfig({
            isOpen: true,
            type: 'approve',
            requestId: id
        });
    };

    const handleReject = (id: string) => {
        setConfirmConfig({
            isOpen: true,
            type: 'reject',
            requestId: id
        });
    };

    const filteredRequests = requests.filter(r =>
        filter === 'All Status' || r.status === filter
    );

    return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6 animate-in fade-in duration-700">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div>
                        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Leave Requests</h1>
                        <p className="mt-1 text-sm text-blue-100 opacity-90">Coordinate team availability and vacation calendars</p>
                    </div>
                    <div className="flex items-center space-x-3 mt-4 sm:mt-0">
                        <Select value={filter} onChange={(e) => setFilter(e.target.value)} className="w-[160px] bg-white/10 text-white border-transparent">
                            <option className="text-gray-900" value="All Status">All Status</option>
                            <option className="text-gray-900" value="Pending">Pending</option>
                            <option className="text-gray-900" value="Approved">Approved</option>
                            <option className="text-gray-900" value="Rejected">Rejected</option>
                        </Select>
                        <Button className="bg-white text-blue-600 hover:bg-gray-50 font-semibold" onClick={() => toast.info('New Request', 'Use the form below or contact HR to submit a new leave request.')}>
                            <Plus className="h-4 w-4 mr-2" />
                            New Request
                        </Button>
                    </div>
                </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Pending Approvals</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white">02</p>
                            <p className="text-xs font-semibold text-amber-500 mt-2 flex items-center">
                                <span className="w-1.5 h-1.5 bg-yellow-400 rounded-full mr-2 animate-pulse"></span>
                                Action required within 24h
                            </p>
                        </div>
                        <Clock className="absolute -right-4 -bottom-4 h-24 w-24 text-blue-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>

                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Annual Usage</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white">78%</p>
                            <div className="w-full bg-gray-100 dark:bg-gray-700 h-1.5 rounded-full mt-3 overflow-hidden">
                                <div className="bg-emerald-500 h-full rounded-full transition-all duration-1000" style={{ width: '78%' }}></div>
                            </div>
                        </div>
                        <Calendar className="absolute -right-4 -bottom-4 h-24 w-24 text-emerald-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>

                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Active Leave</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white">04</p>
                            <p className="text-xs font-semibold text-gray-500 mt-2 flex items-center">
                                <FileText className="w-3 h-3 mr-1" />
                                5 requests starting next week
                            </p>
                        </div>
                        <User className="absolute -right-4 -bottom-4 h-24 w-24 text-indigo-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>
            </div>

            <div className="space-y-5">
                <h2 className="text-sm font-bold text-gray-500 dark:text-gray-400 uppercase tracking-widest flex items-center">
                    <div className="w-4 h-[2px] bg-indigo-500 rounded-full mr-3"></div>
                    Recent Applications
                </h2>
                {filteredRequests.map((request) => (
                    <Card key={request.id} className="group hover:shadow-xl transition-all duration-300 border border-gray-100 dark:border-gray-800 dark:bg-gray-800 shadow-sm overflow-hidden bg-white">
                        <CardContent className="p-0">
                            <div className="flex items-stretch min-h-[100px]">
                                <div className={`w-1.5 ${request.status === 'Approved' ? 'bg-emerald-500' : request.status === 'Rejected' ? 'bg-rose-500' : 'bg-amber-500'}`}></div>
                                <div className="flex-1 p-5 flex flex-col lg:flex-row lg:items-center gap-6">
                                    <div className="flex-1 min-w-[200px]">
                                        <div className="flex items-center space-x-4">
                                            <div className="w-12 h-12 rounded-full bg-gray-50 overflow-hidden border border-gray-200 dark:border-gray-700 shadow-sm flex-shrink-0">
                                                <img src={request.employee.toLowerCase().includes('layla') || request.employee.toLowerCase().includes('fatma') || request.employee.toLowerCase().includes('nour') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
                                            </div>
                                            <div>
                                                <h3 className="font-bold text-gray-900 dark:text-white text-base leading-tight">{request.employee}</h3>
                                                <p className="text-[11px] font-semibold text-gray-400 mt-1 uppercase tracking-wider">{request.id}</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="flex-[3] grid grid-cols-2 lg:grid-cols-4 gap-6 lg:border-l lg:border-gray-100 lg:dark:border-gray-700/50 lg:pl-8">
                                        <div>
                                            <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest mb-1 opacity-70">Leave Type</p>
                                            <p className="text-sm font-semibold text-gray-700 dark:text-gray-300">{request.type}</p>
                                        </div>
                                        <div>
                                            <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest mb-1 opacity-70">Duration</p>
                                            <p className="text-sm font-semibold text-gray-700 dark:text-gray-300">{request.duration}</p>
                                        </div>
                                        <div className="col-span-2">
                                            <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest mb-1 opacity-70">Date Schedule</p>
                                            <div className="flex items-center space-x-2">
                                                <span className="text-[12px] font-medium text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-900/50 px-2 py-0.5 rounded-lg border border-gray-100/50 dark:border-gray-700/50">{request.startDate}</span>
                                                <ArrowRight className="h-3 w-3 text-gray-300" />
                                                <span className="text-[12px] font-medium text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-900/50 px-2 py-0.5 rounded-lg border border-gray-100/50 dark:border-gray-700/50">{request.endDate}</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="flex-1 flex flex-row lg:flex-col items-center justify-between lg:justify-center gap-3 min-w-[140px]">
                                        <span className={`px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider border ${getStatusStyle(request.status)}`}>
                                            {request.status}
                                        </span>
                                        {request.status === 'Pending' ? (
                                            <div className="flex space-x-2">
                                                <button onClick={() => handleApprove(request.id)} className="p-2 bg-emerald-50 text-emerald-600 rounded-lg hover:bg-emerald-600 hover:text-white transition-all shadow-sm active:scale-90" title="Approve">
                                                    <CheckCircle className="h-4 w-4" />
                                                </button>
                                                <button onClick={() => handleReject(request.id)} className="p-2 bg-rose-50 text-rose-600 rounded-lg hover:bg-rose-600 hover:text-white transition-all shadow-sm active:scale-90" title="Reject">
                                                    <XCircle className="h-4 w-4" />
                                                </button>
                                            </div>
                                        ) : (
                                            <button className="text-[11px] font-bold text-indigo-600 hover:text-indigo-700 flex items-center transition-colors">
                                                Details <ChevronRight className="ml-0.5 h-3 w-3" />
                                            </button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* LeaveRequestModal replaced by inline handling */}

            <ConfirmationModal
                isOpen={confirmConfig.isOpen}
                onClose={() => setConfirmConfig({ isOpen: false, type: null, requestId: null })}
                onConfirm={handleConfirmAction}
                title={confirmConfig.type === 'approve' ? 'Approve Leave Request' : 'Reject Leave Request'}
                message={confirmConfig.type === 'approve'
                    ? 'Are you sure you want to approve this leave request? This action will notify the employee.'
                    : 'Are you sure you want to reject this leave request? Please ensure you have valid reasons.'}
                confirmText={confirmConfig.type === 'approve' ? 'Approve' : 'Reject'}
                variant={confirmConfig.type === 'approve' ? 'success' : 'danger'}
            />
            </div>
        </div>
    );
};
