import React, { useState } from 'react';
import { Clock, Download, Search, TrendingUp, AlertCircle, Eye, FileText, ArrowUpRight, DollarSign, Activity, Check, X } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { formatCurrency } from '../../utils/format';
import { useToastContext } from '../../contexts/ToastContext';
import { ConfirmationModal } from '../ui/ConfirmationModal';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { ReviewOvertimeModal } from './ReviewOvertimeModal';

const initialOvertime = [
    {
        id: 'OT-001',
        employee: 'Ahmed Hassan',
        date: '2025-01-07',
        hours: '2.5',
        reason: 'Processing urgent visa requests for the GCC delegation',
        status: 'Approved',
        amount: 250
    },
    {
        id: 'OT-002',
        employee: 'Fatma Ali',
        date: '2025-01-06',
        hours: '1.5',
        reason: 'Hotel booking reconciliation and manual supplier voucher mapping',
        status: 'Pending',
        amount: 150
    },
    {
        id: 'OT-003',
        employee: 'Nour Ibrahim',
        date: '2025-01-05',
        hours: '3.0',
        reason: 'Late flight arrival support and VIP transfer coordination',
        status: 'Approved',
        amount: 300
    }
];

export const OvertimeLogs: React.FC = () => {
    const [overtime, setOvertime] = useState(initialOvertime);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedLog, setSelectedLog] = useState<any>(null);
    const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
    const [confirmConfig, setConfirmConfig] = useState<{
        isOpen: boolean;
        type: 'approve' | 'reject' | null;
        requestId: string | null;
    }>({
        isOpen: false,
        type: null,
        requestId: null
    });
    const toast = useToastContext();

    const handleConfirmAction = () => {
        if (!confirmConfig.requestId || !confirmConfig.type) return;

        const id = confirmConfig.requestId;
        if (confirmConfig.type === 'approve') {
            setOvertime(prev => prev.map(o => o.id === id ? { ...o, status: 'Approved' } : o));
            toast.success('Overtime Approved', 'The request has been verified and added to the next payroll cycle.');
        } else {
            setOvertime(prev => prev.map(o => o.id === id ? { ...o, status: 'Rejected' } : o));
            toast.info('Overtime Rejected', 'The request has been rejected.');
        }

        setConfirmConfig({ isOpen: false, type: null, requestId: null });
        setIsReviewModalOpen(false);
    };

    const handleApprove = (id: string) => {
        setConfirmConfig({
            isOpen: true,
            type: 'approve',
            requestId: id
        });
    };

    const handleReject = (id: string) => {
        setConfirmConfig({
            isOpen: true,
            type: 'reject',
            requestId: id
        });
    };

    const filteredOvertime = overtime.filter(o =>
        o.employee.toLowerCase().includes(searchTerm.toLowerCase()) ||
        o.reason.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const openReview = (log: any) => {
        setSelectedLog(log);
        setIsReviewModalOpen(true);
    };

  return (
        <div className="w-full pb-8 animate-in fade-in duration-700">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center space-x-5 rtl:space-x-reverse">
                        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3 flex-shrink-0">
                            <Clock className="h-7 w-7 text-white" />
                        </div>
                        <div>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Overtime Intelligence</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">Monitoring and financial reconciliation of additional hours</p>
                        </div>
                    </div>
                    <Button className="mt-4 sm:mt-0 bg-white text-blue-600 hover:bg-gray-50 h-11 px-6 font-semibold rounded-xl transition-all" onClick={() => toast.info('Data Export', 'Generating financial overtime report...')}>
                        <Download className="h-4 w-4 mr-3 rtl:mr-0 rtl:ml-3" />
                        Export for HR
                    </Button>
                </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Pending Review</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white">1.5h</p>
                            <p className="text-xs font-semibold text-orange-500 mt-2 flex items-center">
                                <AlertCircle className="w-3 h-3 mr-1 animate-pulse" />
                                1 critical request waiting
                            </p>
                        </div>
                        <AlertCircle className="absolute -right-4 -bottom-4 h-24 w-24 text-orange-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>

                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Total Approved (MTD)</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white">42.0h</p>
                            <p className="text-xs font-semibold text-emerald-500 mt-2 flex items-center">
                                <TrendingUp className="w-3 h-3 mr-1" />
                                +12.4% vs last month
                            </p>
                        </div>
                        <Clock className="absolute -right-4 -bottom-4 h-24 w-24 text-emerald-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>

                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Expense Forecast</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white">${(4200).toLocaleString()}</p>
                            <p className="text-xs font-semibold text-gray-500 mt-2 flex items-center">
                                <FileText className="w-3 h-3 mr-1" />
                                Base Rate (Tier 1)
                            </p>
                        </div>
                        <DollarSign className="absolute -right-4 -bottom-4 h-24 w-24 text-blue-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>

                <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
                    <CardContent className="p-6">
                        <div className="flex flex-col relative z-10">
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Intensity Rate</p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white">3.4h</p>
                            <p className="text-xs font-semibold text-indigo-500 mt-2 flex items-center">
                                <ArrowUpRight className="w-3 h-3 mr-1" />
                                Avg per active session
                            </p>
                        </div>
                        <Activity className="absolute -right-4 -bottom-4 h-24 w-24 text-indigo-500/10 group-hover:scale-110 transition-transform duration-300" />
                    </CardContent>
                </Card>
            </div>

            <Card className="border border-gray-100 dark:border-gray-800 shadow-xl bg-white dark:bg-gray-800 overflow-hidden rounded-2xl">
                <CardHeader className="p-7 bg-gray-50/30 dark:bg-gray-900/30 border-b border-gray-100 dark:border-gray-800 flex flex-row items-center justify-between">
                    <CardTitle className="text-lg font-bold tracking-tight">Tracking Log</CardTitle>
                    <div className="flex items-center space-x-3">
                        <div className="relative">
                            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                            <Input
                                placeholder="Search activity..."
                                className="pl-11 w-64 h-10 bg-white dark:bg-gray-800 border-gray-100 dark:border-gray-700 shadow-sm rounded-xl font-medium text-sm"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <Select className="h-10 w-36 border-gray-100 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-sm rounded-xl font-semibold text-[11px] uppercase tracking-wider text-gray-500">
                            <option>Fiscal Month</option>
                            <option>Quarterly</option>
                        </Select>
                    </div>
                </CardHeader>
                <CardContent className="p-0">
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead>
                                <tr className="border-b border-gray-50 dark:border-gray-800">
                                    <th className="px-7 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest">Resource</th>
                                    <th className="px-7 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest">Timestamp</th>
                                    <th className="px-7 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest">Capacity</th>
                                    <th className="px-7 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest">Detail</th>
                                    <th className="px-7 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest">Comp.</th>
                                    <th className="px-7 py-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-widest">Status</th>
                                    <th className="px-7 py-4 text-right text-[10px] font-bold text-gray-400 uppercase tracking-widest">Action</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                                {filteredOvertime.map((log) => (
                                    <tr key={log.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-900/20 transition-colors group">
                                        <td className="px-7 py-5 whitespace-nowrap">
                                            <div className="flex items-center space-x-4">
                                                <div className="w-10 h-10 rounded-full overflow-hidden shadow-sm flex-shrink-0 border border-gray-200 dark:border-gray-700">
                                                    <img src={log.employee.toLowerCase().includes('fatma') || log.employee.toLowerCase().includes('nour') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
                                                </div>
                                                <span className="text-sm font-bold text-gray-900 dark:text-white">{log.employee}</span>
                                            </div>
                                        </td>
                                        <td className="px-7 py-5 whitespace-nowrap text-[13px] font-medium text-gray-500">
                                            {log.date}
                                        </td>
                                        <td className="px-7 py-5 whitespace-nowrap">
                                            <div className="flex items-baseline space-x-1">
                                                <span className="text-base font-bold text-gray-900 dark:text-white">{log.hours}</span>
                                                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">hrs</span>
                                            </div>
                                        </td>
                                        <td className="px-7 py-5 max-w-[200px]">
                                            <p className="text-[12px] text-gray-500 font-medium line-clamp-1 italic">"{log.reason}"</p>
                                        </td>
                                        <td className="px-7 py-5 whitespace-nowrap text-sm font-bold text-emerald-600">
                                            {formatCurrency(log.amount)}
                                        </td>
                                        <td className="px-7 py-5 whitespace-nowrap">
                                            <span className={`px-2.5 py-1 text-[10px] font-bold rounded-lg uppercase tracking-wider border ${log.status === 'Approved' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'
                                                }`}>
                                                {log.status}
                                            </span>
                                        </td>
                                        <td className="px-7 py-5 whitespace-nowrap text-right rtl:text-left">
                                            <TableActionsDropdown
                                                actions={[
                                                    { label: log.status === 'Approved' ? 'Details' : 'Review', icon: Eye, onClick: () => openReview(log) },
                                                    ...(log.status !== 'Approved' ? [{ label: 'Approve', icon: Check, onClick: () => handleApprove(log.id) }] : []),
                                                    ...(log.status !== 'Rejected' ? [{ label: 'Cancel', icon: X, onClick: () => handleReject(log.id) }] : [])
                                                ]}
                                            />
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>

            <ReviewOvertimeModal
                isOpen={isReviewModalOpen}
                onClose={() => setIsReviewModalOpen(false)}
                onApprove={handleApprove}
                onReject={handleReject}
                log={selectedLog}
            />

            <ConfirmationModal
                isOpen={confirmConfig.isOpen}
                onClose={() => setConfirmConfig({ ...confirmConfig, isOpen: false })}
                onConfirm={handleConfirmAction}
                title={confirmConfig.type === 'approve' ? 'Approve Overtime' : 'Reject Overtime'}
                message={confirmConfig.type === 'approve'
                    ? 'Are you sure you want to approve this overtime request? This will be added to the employee compensation.'
                    : 'Are you sure you want to reject this overtime request? This decision will be notified to the employee.'}
                confirmText={confirmConfig.type === 'approve' ? 'Approve' : 'Reject'}
                variant={confirmConfig.type === 'approve' ? 'success' : 'danger'}
            />
        </div>
        </div>
    );
};
