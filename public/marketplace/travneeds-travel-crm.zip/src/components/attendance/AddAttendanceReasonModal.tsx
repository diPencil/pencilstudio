import React, { useState } from 'react';
import { X, Save, Clock } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';

interface AddAttendanceReasonModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (data: any) => void;
}

const reasonTypes = [
    'Early Leave',
    'Client Visit',
    'Remote Work',
    'Medical Appointment',
    'Personal Emergency',
    'Training',
    'Meeting',
    'Other'
];

export const AddAttendanceReasonModal: React.FC<AddAttendanceReasonModalProps> = ({
    isOpen,
    onClose,
    onSave
}) => {
    const [formData, setFormData] = useState({
        date: new Date().toISOString().split('T')[0],
        reasonType: 'Early Leave',
        startTime: '',
        endTime: '',
        description: ''
    });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData);
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 overflow-y-auto">
            <div className="flex min-h-screen items-center justify-center p-4">
                <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
                <div className="relative w-full max-w-lg bg-white dark:bg-gray-800 rounded-lg shadow-xl">
                    {/* Header */}
                    <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
                        <div className="flex items-center space-x-3">
                            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-50 dark:bg-blue-900/30">
                                <Clock className="h-5 w-5 text-blue-500" />
                            </div>
                            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                                Add Attendance Reason
                            </h2>
                        </div>
                        <button
                            onClick={onClose}
                            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                        >
                            <X size={24} />
                        </button>
                    </div>

                    <form onSubmit={handleSubmit} className="p-6">
                        <div className="space-y-6">
                            {/* Date */}
                            <Input
                                label="Date"
                                type="date"
                                value={formData.date}
                                onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                            />

                            {/* Reason Type */}
                            <Select
                                label="Reason Type"
                                value={formData.reasonType}
                                onChange={(e) => setFormData(prev => ({ ...prev, reasonType: e.target.value }))}
                            >
                                {reasonTypes.map(type => (
                                    <option key={type} value={type}>{type}</option>
                                ))}
                            </Select>

                            {/* Times */}
                            <div className="grid grid-cols-2 gap-4">
                                <Input
                                    label="Start Time"
                                    type="time"
                                    value={formData.startTime}
                                    onChange={(e) => setFormData(prev => ({ ...prev, startTime: e.target.value }))}
                                />
                                <Input
                                    label="End Time"
                                    type="time"
                                    value={formData.endTime}
                                    onChange={(e) => setFormData(prev => ({ ...prev, endTime: e.target.value }))}
                                />
                            </div>

                            {/* Description */}
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                    Description *
                                </label>
                                <textarea
                                    value={formData.description}
                                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                                    rows={4}
                                    className="block w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all placeholder:text-gray-400"
                                    placeholder="Explain the reason for this attendance entry..."
                                    required
                                />
                            </div>
                        </div>

                        {/* Footer Buttons */}
                        <div className="flex justify-end space-x-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                            <Button type="button" variant="outline" onClick={onClose} className="px-6">
                                Cancel
                            </Button>
                            <Button type="submit" className="px-6 flex items-center space-x-2">
                                <Save className="h-4 w-4" />
                                <span>Add Reason</span>
                            </Button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};
