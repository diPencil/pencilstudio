import React from 'react';
import { Toast } from './Toast';
import { useToast } from '../../hooks/useToast';
import { useLocale } from '../../localization/useLocale';
import { pickDirectionalValue } from '../../localization/direction';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useToast();
  const { direction } = useLocale();

  return (
    <div className={pickDirectionalValue(direction, 'fixed top-4 right-4 z-[100] space-y-2', 'fixed top-4 left-4 z-[100] space-y-2')}>
      {toasts.map((toast) => (
        <Toast
          key={toast.id}
          {...toast}
          onClose={removeToast}
        />
      ))}
    </div>
  );
};
