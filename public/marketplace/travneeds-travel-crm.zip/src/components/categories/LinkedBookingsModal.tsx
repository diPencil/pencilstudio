import React from 'react';
import { X, Calendar, User, DollarSign, MapPin } from 'lucide-react';
import { formatCurrency, formatDate } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';

import { CatalogItem } from './EditItemModal';

interface LinkedBookingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: CatalogItem | null;
}

const mockLinkedBookings = [
  {
    id: 'BK-001',
    customerName: 'Youssef Ahmed',
    customerEmail: 'youssef@email.com',
    bookingDate: '2025-01-10',
    checkIn: '2025-02-15',
    checkOut: '2025-02-18',
    amount: 540,
    status: 'Confirmed',
    guests: 2,
    specialRequests: 'Late check-in requested'
  },
  {
    id: 'BK-002',
    customerName: 'Sara Mansour',
    customerEmail: 'sara@email.com',
    bookingDate: '2025-01-08',
    checkIn: '2025-03-10',
    checkOut: '2025-03-12',
    amount: 360,
    status: 'Confirmed',
    guests: 1,
    specialRequests: 'Vegetarian meals'
  },
  {
    id: 'BK-003',
    customerName: 'Mahmoud Hassan',
    customerEmail: 'mahmoud@email.com',
    bookingDate: '2025-01-05',
    checkIn: '2025-01-20',
    checkOut: '2025-01-22',
    amount: 360,
    status: 'Completed',
    guests: 2,
    specialRequests: 'Airport transfer needed'
  },
  {
    id: 'BK-004',
    customerName: 'Mona Zaki',
    customerEmail: 'mona@email.com',
    bookingDate: '2025-01-03',
    checkIn: '2025-04-05',
    checkOut: '2025-04-08',
    amount: 540,
    status: 'Pending',
    guests: 3,
    specialRequests: 'Family room required'
  },
  {
    id: 'BK-005',
    customerName: 'Rafiq Ibrahim',
    customerEmail: 'rafiq@email.com',
    bookingDate: '2024-12-28',
    checkIn: '2025-01-15',
    checkOut: '2025-01-17',
    amount: 360,
    status: 'Completed',
    guests: 1,
    specialRequests: 'Business traveler'
  }
];

export const LinkedBookingsModal: React.FC<LinkedBookingsModalProps> = ({ isOpen, onClose, item }) => {
  const { isRTL } = useLocale();
  if (!isOpen || !item) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Confirmed': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'Pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'Completed': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      case 'Cancelled': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const totalRevenue = mockLinkedBookings.reduce((sum, booking) => sum + booking.amount, 0);
  const totalGuests = mockLinkedBookings.reduce((sum, booking) => sum + booking.guests, 0);
  const confirmedBookings = mockLinkedBookings.filter(b => b.status === 'Confirmed').length;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" dir={isRTL ? "rtl" : "ltr"}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-6xl bg-white dark:bg-gray-800 rounded-lg shadow-xl max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Linked Bookings - {item.name}
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <div className="p-6">
            {/* Summary Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-blue-600 dark:text-blue-400">Total Bookings</p>
                    <p className="text-2xl font-bold text-blue-800 dark:text-blue-300">
                      {mockLinkedBookings.length}
                    </p>
                  </div>
                  <Calendar className="h-8 w-8 text-blue-500" />
                </div>
              </div>

              <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-green-600 dark:text-green-400">Total Revenue</p>
                    <p className="text-2xl font-bold text-green-800 dark:text-green-300">
                      {formatCurrency(totalRevenue)}
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-500" />
                </div>
              </div>

              <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-purple-600 dark:text-purple-400">Total Guests</p>
                    <p className="text-2xl font-bold text-purple-800 dark:text-purple-300">
                      {totalGuests}
                    </p>
                  </div>
                  <User className="h-8 w-8 text-purple-500" />
                </div>
              </div>

              <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-orange-600 dark:text-orange-400">Confirmed</p>
                    <p className="text-2xl font-bold text-orange-800 dark:text-orange-300">
                      {confirmedBookings}
                    </p>
                  </div>
                  <MapPin className="h-8 w-8 text-orange-500" />
                </div>
              </div>
            </div>

            {/* Bookings Table */}
            <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Booking ID
                      </th>
                      <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Customer
                      </th>
                      <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Booking Date
                      </th>
                      <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Check-in / Check-out
                      </th>
                      <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Guests
                      </th>
                      <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Amount
                      </th>
                      <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Special Requests
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    {mockLinkedBookings.map((booking) => (
                      <tr key={booking.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white bidi-isolate ltr-value">
                          {booking.id}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="text-sm font-medium text-gray-900 dark:text-white">
                              {booking.customerName}
                            </div>
                            <div className="text-sm text-gray-500 dark:text-gray-400 bidi-isolate ltr-value">
                              {booking.customerEmail}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400 bidi-isolate ltr-value">
                          {formatDate(booking.bookingDate)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900 dark:text-white bidi-isolate ltr-value">
                            {formatDate(booking.checkIn)}
                          </div>
                          <div className="text-sm text-gray-500 dark:text-gray-400 bidi-isolate ltr-value">
                            {formatDate(booking.checkOut)}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                          {booking.guests}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white bidi-isolate ltr-value">
                          {formatCurrency(booking.amount)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(booking.status)}`}>
                            {booking.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 max-w-xs truncate">
                          {booking.specialRequests}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex justify-end mt-6">
              <button
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};