import React from 'react';
import { X, Package, MapPin, DollarSign, Calendar, User, Phone, Mail, Star } from 'lucide-react';
import { formatCurrency, formatDate } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';

import { CatalogItem } from './EditItemModal';

interface ViewItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: CatalogItem | null;
}

const mockBookingHistory = [
  {
    id: 'BK-001',
    customerName: 'Youssef Ahmed',
    bookingDate: '2025-01-10',
    checkIn: '2025-02-15',
    checkOut: '2025-02-18',
    amount: 540,
    status: 'Confirmed'
  },
  {
    id: 'BK-002',
    customerName: 'Sara Mansour',
    bookingDate: '2025-01-08',
    checkIn: '2025-03-10',
    checkOut: '2025-03-12',
    amount: 360,
    status: 'Confirmed'
  },
  {
    id: 'BK-003',
    customerName: 'Mahmoud Hassan',
    bookingDate: '2025-01-05',
    checkIn: '2025-01-20',
    checkOut: '2025-01-22',
    amount: 360,
    status: 'Completed'
  }
];

export const ViewItemModal: React.FC<ViewItemModalProps> = ({ isOpen, onClose, item }) => {
  const { isRTL } = useLocale();
  if (!isOpen || !item) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Available': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'Booked': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      case 'Inactive': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const totalRevenue = mockBookingHistory.reduce((sum, booking) => sum + booking.amount, 0);
  const avgBookingValue = totalRevenue / mockBookingHistory.length;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" dir={isRTL ? "rtl" : "ltr"}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-4xl bg-white dark:bg-gray-800 rounded-lg shadow-xl max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Item Details - {item.name}
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <div className="p-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Item Information */}
              <div className="lg:col-span-2 space-y-6">
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    Item Information
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center gap-3">
                      <Package className="h-5 w-5 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Category</p>
                        <p className="font-medium text-gray-900 dark:text-white">{item.categoryType}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <DollarSign className="h-5 w-5 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Price</p>
                        <p className="font-medium text-gray-900 dark:text-white bidi-isolate ltr-value">
                          ${item.price}/{item.priceUnit.replace('per ', '')}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <User className="h-5 w-5 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Supplier</p>
                        <p className="font-medium text-gray-900 dark:text-white">{item.supplierName}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Calendar className="h-5 w-5 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Status</p>
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(item.status)}`}>
                          {item.status}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    Description
                  </h3>
                  <p className="text-gray-700 dark:text-gray-300">{item.description}</p>
                  {item.notes && (
                    <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                      <h4 className="font-medium text-gray-900 dark:text-white mb-2">Notes</h4>
                      <p className="text-gray-700 dark:text-gray-300">{item.notes}</p>
                    </div>
                  )}
                </div>

                {/* Booking History */}
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    Recent Bookings
                  </h3>
                  <div className="space-y-3">
                    {mockBookingHistory.map((booking) => (
                      <div key={booking.id} className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">{booking.customerName}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400 bidi-isolate ltr-value">
                            {formatDate(booking.checkIn)} - {formatDate(booking.checkOut)}
                          </p>
                          <p className="text-xs text-gray-400 bidi-isolate ltr-value">Booked: {formatDate(booking.bookingDate)}</p>
                        </div>
                        <div className="text-right rtl:text-left">
                          <p className="font-medium text-gray-900 dark:text-white bidi-isolate ltr-value">{formatCurrency(booking.amount)}</p>
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${booking.status === 'Confirmed' ? 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300' :
                              booking.status === 'Completed' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300' :
                                'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300'
                            }`}>
                            {booking.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Performance Stats */}
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    Performance Stats
                  </h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Total Bookings</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white">{item.linkedBookings}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Total Revenue</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white bidi-isolate ltr-value">{formatCurrency(totalRevenue)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Avg. Booking Value</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white bidi-isolate ltr-value">{formatCurrency(avgBookingValue)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Created</span>
                      <span className="text-sm font-medium text-gray-900 dark:text-white bidi-isolate ltr-value">{formatDate(item.createdAt)}</span>
                    </div>
                  </div>
                </div>

                {/* Supplier Information */}
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    Supplier Information
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <User className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-900 dark:text-white">{item.supplierName}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Mail className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600 dark:text-gray-400 bidi-isolate ltr-value">contact@supplier.com</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Phone className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600 dark:text-gray-400 bidi-isolate ltr-value">+20-123-456-789</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <MapPin className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600 dark:text-gray-400">Location, Egypt</span>
                    </div>
                  </div>
                </div>

                {/* Rating */}
                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                  <h4 className="text-sm font-semibold text-blue-800 dark:text-blue-300 mb-3">
                    Customer Rating
                  </h4>
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star key={star} className="h-4 w-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <span className="text-sm font-medium text-blue-800 dark:text-blue-300">4.8/5</span>
                  </div>
                  <p className="text-xs text-blue-600 dark:text-blue-400 mt-2">Based on {item.linkedBookings} reviews</p>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};