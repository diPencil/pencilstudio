import React, { useState } from 'react';
import { Save, Plus, ArrowLeft, Info, Package, DollarSign, Database } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

const categoryTypes = [
    'Hotel', 'Hostel', 'Apartment', 'Trip Package', 'Tour', 'Activities',
    'Car Rental', 'Transportation', 'Events', 'Cruise', 'Boat', 'Diving',
    'Aqua Park', 'Day Trip'
];

const priceUnits = {
    'Hotel': ['per night', 'per week', 'per month'],
    'Tour': ['per person', 'per group'],
    'Transportation': ['per person', 'per trip', 'per km'],
    'Activities': ['per person', 'per group', 'per hour']
};

const mockSuppliers = [
    { id: 'S1', name: 'Cairo Marriott Hotel' },
    { id: 'S2', name: 'Nile Tours Agency' },
    { id: 'S3', name: 'Red Sea Divers' }
];

export const AddNewItemPage: React.FC = () => {
    const navigate = useNavigate();
    const toast = useToastContext();
    const { isRTL } = useLocale();
    const [formData, setFormData] = useState({
        categoryType: 'Hotel',
        name: '',
        description: '',
        price: '',
        priceUnit: 'per night',
        supplierId: '',
        status: 'Available',
        notes: ''
    });
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setTimeout(() => {
            toast.success('Item Added', `${formData.name} has been successfully registered in the catalog.`);
            navigate('/product-categories');
        }, 800);
    };

    const handleCategoryChange = (val: string) => {
        const units = priceUnits[val as keyof typeof priceUnits] || ['per unit'];
        setFormData(prev => ({ ...prev, categoryType: val, priceUnit: units[0] }));
    };

    return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
                    <div className={cn("flex items-center gap-2 sm:gap-4 banner-actions", isRTL && "flex-row-reverse")}>
                        <Button variant="outline" onClick={() => navigate('/product-categories')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                            <ArrowLeft size={20} className={isRTL ? 'rtl-flip' : ''} />
                        </Button>
                        <div className={cn(isRTL ? "text-right" : "text-left")}>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Create New Catalog Item</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">Add a recurring product, service, or travel package to your system</p>
                        </div>
                    </div>
                </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    <Card>
                        <CardContent className="p-6">
                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <Select
                                        label="Item Type *"
                                        value={formData.categoryType}
                                        onChange={(e) => handleCategoryChange(e.target.value)}
                                        required
                                    >
                                        {categoryTypes.map(t => <option key={t} value={t}>{t}</option>)}
                                    </Select>

                                    <Input
                                        label="Item Display Name *"
                                        value={formData.name}
                                        onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                                        required
                                        placeholder="e.g. Standard Double Room - Cairo"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200 mb-2">Detailed Description *</label>
                                    <textarea
                                        value={formData.description}
                                        onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                                        rows={3}
                                        required
                                        className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"
                                        placeholder="Features, amenities, or itinerary summarized..."
                                    />
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <Input
                                        label="Base Booking Price *"
                                        type="number"
                                        value={formData.price}
                                        onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                                        required
                                        placeholder="0.00"
                                    />

                                    <Select
                                        label="Pricing Unit"
                                        value={formData.priceUnit}
                                        onChange={(e) => setFormData(prev => ({ ...prev, priceUnit: e.target.value }))}
                                    >
                                        {(priceUnits[formData.categoryType as keyof typeof priceUnits] || ['per unit']).map(u => (
                                            <option key={u} value={u}>{u}</option>
                                        ))}
                                    </Select>

                                    <div className="md:col-span-2">
                                        <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200 mb-2">Associated Supplier *</label>
                                        <div className="flex gap-2">
                                            <Select
                                                value={formData.supplierId}
                                                onChange={(e) => setFormData(prev => ({ ...prev, supplierId: e.target.value }))}
                                                required
                                                className="flex-1"
                                            >
                                                <option value="">Choose a verified supplier...</option>
                                                {mockSuppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                                            </Select>
                                            <Button type="button" variant="outline" className="px-3" onClick={() => navigate('/reservations/new-supplier')}>
                                                <Plus size={16} />
                                            </Button>
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200">Inventory Notes</label>
                                    <textarea
                                        value={formData.notes}
                                        onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                                        rows={2}
                                        className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"
                                        placeholder="Internal notes about availability or special terms..."
                                    />
                                </div>

                                <div className="flex justify-end gap-3 pt-6 border-t border-gray-100 dark:border-gray-800">
                                    <Button variant="outline" type="button" onClick={() => navigate('/product-categories')}>Cancel</Button>
                                    <Button type="submit" loading={isLoading} className="bg-indigo-600 hover:bg-indigo-700">
                                        <Save className="h-4 w-4" />
                                        Initialize Item
                                    </Button>
                                </div>
                            </form>
                        </CardContent>
                    </Card>
                </div>

                <div className="space-y-6">
                    <Card className="bg-white dark:bg-gray-800 border-none shadow-sm">
                        <CardHeader className="pb-0 border-none">
                            <CardTitle className="label-xs">Item Intelligence</CardTitle>
                        </CardHeader>
                        <CardContent className="p-6 space-y-6">
                            <div className="flex items-center gap-4">
                                <div className="p-3 bg-indigo-100/50 dark:bg-white/10 rounded-2xl">
                                    <Package className="text-indigo-600 dark:text-indigo-400" size={24} />
                                </div>
                                <div className="flex-1">
                                    <p className="text-[10px] font-bold text-gray-500 dark:text-white/60 uppercase mb-0.5">Category Match</p>
                                    <p className="font-bold text-lg text-gray-900 dark:text-white">{formData.categoryType}</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-4">
                                <div className="p-3 bg-green-100/50 dark:bg-white/10 rounded-2xl">
                                    <DollarSign className="text-green-600 dark:text-green-400" size={24} />
                                </div>
                                <div className="flex-1">
                                    <p className="text-[10px] font-bold text-gray-500 dark:text-white/60 uppercase mb-0.5">Price Point</p>
                                    <p className="font-bold text-lg text-gray-900 dark:text-white">
                                        <span className="bidi-isolate ltr-value">{formData.price ? `$${formData.price}` : '--.--'}</span>
                                    </p>
                                </div>
                            </div>
                            <div className="pt-4 border-t border-indigo-100 dark:border-white/10">
                                <div className="flex items-center gap-2 text-[10px] font-bold text-indigo-600 dark:text-indigo-300">
                                    <Database size={12} />
                                    <span>AUTO-INDEXING ENABLED</span>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardContent className="p-4 flex items-start gap-3">
                            <Info className="text-blue-500 mt-0.5 flex-shrink-0" size={18} />
                            <div className="space-y-1">
                                <h4 className="text-sm font-bold">Catalog Rules</h4>
                                <p className="text-xs text-gray-500 leading-relaxed">Once an item is added, it becomes available for all sales agents across quotes and bookings.</p>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
            </div>
        </div>
    );
};
