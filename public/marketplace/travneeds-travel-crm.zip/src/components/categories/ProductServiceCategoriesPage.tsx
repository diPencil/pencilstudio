import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Archive,
  ClipboardList,
  Copy,
  Edit,
  Eye,
  FileUp,
  Link2,
  Package,
  Plus,
  Search,
  Trash2,
  Unlink,
  X,
  AlertTriangle,
  BarChart3,
  CalendarDays,
  Calculator,
  Layers,
  Percent,
  Save
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Button } from '../ui/Button';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { formatCurrency, formatDate } from '../../utils/format';
import {
  mockItems,
  mockProductAvailabilityRules,
  mockProductCategories,
  mockProductCostTemplates,
  mockProductPackageTemplates,
  mockProductPricingRules,
  mockSuppliers
} from '../../services/mockData';
import type {
  ProductAvailabilityRule,
  ProductCategory,
  ProductCostTemplate,
  ProductPackageTemplate,
  ProductPricingRule,
  ProductServiceItem,
  ProductServiceStatus,
  ProductSeasonalRate
} from '../../types';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

type ProductFormMode = 'add' | 'edit';

const statusOptions: ProductServiceStatus[] = ['Active', 'Draft', 'Inactive', 'Archived', 'Needs review', 'Without supplier'];
const typeOptions = ['Hotel', 'Cruise', 'Airline', 'Sightseeing', 'Transfer', 'Activity'];

const badgeClass = (status: string) => {
  if (status === 'Active' || status === 'Linked') return 'bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-950/20 dark:text-emerald-400 dark:border-emerald-900/30';
  if (status === 'Draft' || status === 'Needs review') return 'bg-amber-50 text-amber-700 border-amber-100 dark:bg-amber-950/20 dark:text-amber-400 dark:border-amber-900/30';
  if (status === 'Archived' || status === 'Inactive' || status === 'Without supplier' || status === 'Unlinked') return 'bg-rose-50 text-rose-700 border-rose-100 dark:bg-rose-950/20 dark:text-rose-400 dark:border-rose-900/30';
  return 'bg-gray-50 text-gray-700 border-gray-100 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700';
};

const emptyForm = (categoryId = mockProductCategories[0]?.id || ''): ProductFormState => ({
  name: '',
  description: '',
  categoryId,
  type: 'Hotel',
  destination: '',
  location: '',
  supplierId: '',
  costPrice: '0',
  sellingPrice: '0',
  priceUnit: 'per night',
  status: 'Draft',
  availability: '',
  duration: '',
  capacity: '',
  serviceClass: '',
  inclusions: '',
  exclusions: '',
  cancellationPolicy: '',
  bookingNotes: '',
  internalNotes: '',
  mediaFileName: 'main-image-placeholder.jpg',
  seasonalRates: []
});

interface ProductFormState {
  name: string;
  description: string;
  categoryId: string;
  type: string;
  destination: string;
  location: string;
  supplierId: string;
  costPrice: string;
  sellingPrice: string;
  priceUnit: string;
  status: ProductServiceStatus;
  availability: string;
  duration: string;
  capacity: string;
  serviceClass: string;
  inclusions: string;
  exclusions: string;
  cancellationPolicy: string;
  bookingNotes: string;
  internalNotes: string;
  mediaFileName: string;
  seasonalRates?: ProductSeasonalRate[];
}

export const ProductServiceCategoriesPage: React.FC = () => {
  const navigate = useNavigate();
  const { isRTL, t, direction } = useLocale();

  const [items, setItems] = useState<ProductServiceItem[]>(mockItems);
  const [categories, setCategories] = useState<ProductCategory[]>(mockProductCategories);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All Categories');
  const [supplierFilter, setSupplierFilter] = useState('All Suppliers');
  const [destinationFilter, setDestinationFilter] = useState('All Destinations');
  const [statusFilter, setStatusFilter] = useState('All Status');
  const [typeFilter, setTypeFilter] = useState('All Types');
  const [formMode, setFormMode] = useState<ProductFormMode>('add');
  const [editingItem, setEditingItem] = useState<ProductServiceItem | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [categoryDraft, setCategoryDraft] = useState({ name: '', type: 'Hotel' });
  const [mappingItemId, setMappingItemId] = useState<string | null>(null);
  const [mappingSupplierId, setMappingSupplierId] = useState('');
  const [mockNotice, setMockNotice] = useState('');
  const [costTemplates, setCostTemplates] = useState<ProductCostTemplate[]>(mockProductCostTemplates);
  const [pricingRules, setPricingRules] = useState<ProductPricingRule[]>(mockProductPricingRules);
  const [availabilityRules, setAvailabilityRules] = useState<ProductAvailabilityRule[]>(mockProductAvailabilityRules);
  const [packageTemplates, setPackageTemplates] = useState<ProductPackageTemplate[]>(mockProductPackageTemplates);
  const [pricingRuleDraft, setPricingRuleDraft] = useState({
    name: '',
    categoryId: mockProductCategories[0]?.id || '',
    destination: '',
    value: '20',
    minMarginPercent: '15'
  });
  const [costTemplateDraft, setCostTemplateDraft] = useState({
    name: '',
    categoryId: mockProductCategories[0]?.id || '',
    appliesToType: 'Hotel',
    componentName: '',
    costType: 'Fixed',
    amount: '0'
  });
  const [availabilityDraft, setAvailabilityDraft] = useState({
    itemId: mockItems[0]?.id || '',
    name: '',
    ruleType: 'Allocation',
    startDate: new Date().toISOString().slice(0, 10),
    endDate: new Date().toISOString().slice(0, 10),
    quantity: '1',
    releaseDays: '7',
    status: 'Open'
  });
  const [packageDraft, setPackageDraft] = useState({
    name: '',
    packageType: 'Package',
    destination: '',
    itemIds: [] as string[],
    basePax: '2'
  });

  const supplierById = (supplierId?: string) => mockSuppliers.find(supplier => supplier.id === supplierId);

  const destinations = useMemo(() => Array.from(new Set(items.flatMap(item => item.destinationCoverage.map(destination => destination.destination)))), [items]);
  const suppliers = mockSuppliers;

  const filteredItems = items.filter(item => {
    const supplier = supplierById(item.supplierId);
    const searchable = [
      item.name,
      item.category,
      item.categoryType,
      item.type,
      item.destination,
      item.location,
      item.supplierName,
      supplier?.name,
      item.description
    ].join(' ').toLowerCase();

    return searchable.includes(searchTerm.toLowerCase())
      && (categoryFilter === 'All Categories' || item.categoryId === categoryFilter)
      && (supplierFilter === 'All Suppliers' || item.supplierId === supplierFilter || (supplierFilter === 'Without supplier' && !item.supplierId))
      && (destinationFilter === 'All Destinations' || item.destinationCoverage.some(destination => destination.destination === destinationFilter))
      && (statusFilter === 'All Status' || item.status === statusFilter)
      && (typeFilter === 'All Types' || item.type === typeFilter);
  });

  const activeItems = items.filter(item => item.status === 'Active').length;
  const draftInactiveItems = items.filter(item => item.status === 'Draft' || item.status === 'Inactive').length;
  const archivedItems = items.filter(item => item.status === 'Archived').length;
  const linkedSuppliersCount = new Set(items.filter(item => item.supplierId).map(item => item.supplierId)).size;
  const withoutSupplier = items.filter(item => !item.supplierId || item.status === 'Without supplier').length;
  const avgMargin = Math.round(items.reduce((sum, item) => sum + marginPercent(item), 0) / (items.length || 1));

  const topCategories = categories
    .map(category => ({ ...category, count: items.filter(item => item.categoryId === category.id).length }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 4);

  const statusDistribution = statusOptions
    .map(status => ({ status, count: items.filter(item => item.status === status).length }))
    .filter(item => item.count > 0);

  const destinationRows = destinations.map(destination => {
    const destinationItems = items.filter(item => item.destinationCoverage.some(coverage => coverage.destination === destination));
    return {
      destination,
      country: destinationItems[0]?.destinationCoverage.find(coverage => coverage.destination === destination)?.country || 'Egypt',
      services: destinationItems.length,
      suppliers: new Set(destinationItems.filter(item => item.supplierId).map(item => item.supplierId)).size,
      active: destinationItems.filter(item => item.status === 'Active').length,
      status: destinationItems.some(item => item.destinationCoverage.some(coverage => coverage.destination === destination && coverage.status === 'Inactive')) ? 'Inactive' : 'Active'
    };
  });

  const categoryRows = categories.map(category => {
    const categoryItems = items.filter(item => item.categoryId === category.id);
    return {
      ...category,
      itemsCount: categoryItems.length,
      activeItems: categoryItems.filter(item => item.status === 'Active').length,
      linkedSuppliers: new Set(categoryItems.filter(item => item.supplierId).map(item => item.supplierId)).size,
      revenue: categoryItems.reduce((sum, item) => sum + item.sellingPrice * Math.max(1, item.linkedBookings), 0)
    };
  });

  const pricingWarnings = items.flatMap(item => {
    const matchedRule = findPricingRule(item, pricingRules);
    const itemMargin = marginPercent(item);
    if (!matchedRule || itemMargin >= matchedRule.minMarginPercent) return [];
    return [`${item.name}: ${itemMargin}% margin is below ${matchedRule.minMarginPercent}% (${matchedRule.name})`];
  });

  const analyticsRows = categories.map(category => {
    const categoryItems = items.filter(item => item.categoryId === category.id);
    const revenue = categoryItems.reduce((sum, item) => sum + item.sellingPrice * Math.max(1, item.linkedBookings), 0);
    const cost = categoryItems.reduce((sum, item) => sum + item.costPrice * Math.max(1, item.linkedBookings), 0);
    const bookings = categoryItems.reduce((sum, item) => sum + item.linkedBookings, 0);
    return {
      ...category,
      revenue,
      cost,
      bookings,
      margin: revenue ? Math.round(((revenue - cost) / revenue) * 100) : 0
    };
  });

  const packageRows = packageTemplates.map(template => {
    const packageItems = items.filter(item => template.itemIds.includes(item.id));
    const cost = packageItems.reduce((sum, item) => sum + item.costPrice, 0);
    const selling = packageItems.reduce((sum, item) => sum + item.sellingPrice, 0);
    return { ...template, itemCount: packageItems.length, cost, selling, margin: selling ? Math.round(((selling - cost) / selling) * 100) : 0 };
  });

  const resetFilters = () => {
    setSearchTerm('');
    setCategoryFilter('All Categories');
    setSupplierFilter('All Suppliers');
    setDestinationFilter('All Destinations');
    setStatusFilter('All Status');
    setTypeFilter('All Types');
  };

  const openAddForm = () => {
    setFormMode('add');
    setEditingItem(null);
    setIsFormOpen(true);
  };

  const openEditForm = (item: ProductServiceItem) => {
    setFormMode('edit');
    setEditingItem(item);
    setIsFormOpen(true);
  };

  const handleSaveItem = (form: ProductFormState) => {
    const category = categories.find(entry => entry.id === form.categoryId) || categories[0];
    const supplier = suppliers.find(entry => entry.id === form.supplierId);
    const costPrice = Number(form.costPrice) || 0;
    const sellingPrice = Number(form.sellingPrice) || 0;
    const item: ProductServiceItem = {
      ...(editingItem || mockItems[0]),
      id: editingItem?.id || `ITEM-${String(items.length + 1).padStart(3, '0')}`,
      name: form.name.trim(),
      description: form.description.trim(),
      categoryId: category.id,
      category: category.name,
      categoryType: category.name,
      type: form.type,
      destination: form.destination.trim(),
      location: form.location.trim(),
      costPrice,
      sellingPrice,
      price: sellingPrice,
      priceUnit: form.priceUnit,
      supplierId: supplier?.id,
      supplierName: supplier?.name,
      status: supplier ? form.status : 'Without supplier',
      availability: form.availability.trim(),
      linkedBookings: editingItem?.linkedBookings || 0,
      lastUpdated: new Date().toISOString().slice(0, 10),
      createdAt: editingItem?.createdAt || new Date().toISOString().slice(0, 10),
      attributes: {
        duration: form.duration,
        capacity: form.capacity,
        serviceClass: form.serviceClass,
        roomType: form.type === 'Hotel' ? form.serviceClass : undefined,
        vehicleType: form.type === 'Transfer' ? form.serviceClass : undefined,
        inclusions: splitList(form.inclusions),
        exclusions: splitList(form.exclusions),
        cancellationPolicy: form.cancellationPolicy,
        bookingNotes: form.bookingNotes,
        internalNotes: form.internalNotes
      },
      media: [{ id: `MED-${Date.now()}`, fileName: form.mediaFileName || 'main-image-placeholder.jpg', type: 'Main image', status: 'Placeholder' }],
      destinationCoverage: [{ country: 'Egypt', city: form.destination.trim(), destination: form.destination.trim(), status: form.status === 'Inactive' ? 'Inactive' : 'Active' }],
      supplierMapping: supplier ? { supplierId: supplier.id, supplierName: supplier.name, status: 'Linked', lastChecked: new Date().toISOString().slice(0, 10) } : { status: 'Unlinked' },
      activity: [
        ...(editingItem?.activity || []),
        { id: `PACT-${Date.now()}`, type: formMode === 'add' ? 'Created' : 'Edited', message: `${form.name} ${formMode === 'add' ? 'created' : 'updated'} locally.`, date: new Date().toISOString().slice(0, 10), user: 'Super Admin' }
      ],
      notes: form.internalNotes,
      seasonalRates: form.seasonalRates || []
    };

    setItems(prev => formMode === 'add' ? [item, ...prev] : prev.map(entry => entry.id === item.id ? item : entry));
    setIsFormOpen(false);
    setEditingItem(null);
  };

  const duplicateItem = (item: ProductServiceItem) => {
    const duplicate: ProductServiceItem = {
      ...item,
      id: `ITEM-${String(items.length + 1).padStart(3, '0')}`,
      name: `${item.name} Copy`,
      status: 'Draft',
      lastUpdated: new Date().toISOString().slice(0, 10),
      activity: [{ id: `PACT-${Date.now()}`, type: 'Duplicate', message: `Duplicated from ${item.id}.`, date: new Date().toISOString().slice(0, 10), user: 'Super Admin' }, ...item.activity]
    };
    setItems(prev => [duplicate, ...prev]);
  };

  const archiveItem = (itemId: string) => setItems(prev => prev.map(item => item.id === itemId ? { ...item, status: 'Archived', lastUpdated: new Date().toISOString().slice(0, 10) } : item));

  const viewItem = (item: ProductServiceItem) => {
    if (mockItems.some(mockItem => mockItem.id === item.id)) {
      navigate(`/product-categories/items/${item.id}`);
      return;
    }
    openEditForm(item);
    setMockNotice(t('products.catalog.notice.route'));
  };

  const addCategory = () => {
    if (!categoryDraft.name.trim()) return;
    setCategories(prev => [
      { id: `CAT-${String(prev.length + 1).padStart(3, '0')}`, name: categoryDraft.name.trim(), type: categoryDraft.type, status: 'Draft', usageCount: 0 },
      ...prev
    ]);
    setCategoryDraft({ name: '', type: 'Hotel' });
  };

  const deleteCategory = (categoryId: string) => {
    if (items.some(item => item.categoryId === categoryId)) {
      setCategories(prev => prev.map(category => category.id === categoryId ? { ...category, status: 'Inactive' } : category));
      return;
    }
    setCategories(prev => prev.filter(category => category.id !== categoryId));
  };

  const linkSupplier = () => {
    const supplier = suppliers.find(entry => entry.id === mappingSupplierId);
    if (!mappingItemId || !supplier) return;
    setItems(prev => prev.map(item => item.id === mappingItemId ? {
      ...item,
      supplierId: supplier.id,
      supplierName: supplier.name,
      status: item.status === 'Without supplier' ? 'Needs review' : item.status,
      supplierMapping: { supplierId: supplier.id, supplierName: supplier.name, status: 'Linked', lastChecked: new Date().toISOString().slice(0, 10) },
      lastUpdated: new Date().toISOString().slice(0, 10)
    } : item));
    setMappingItemId(null);
    setMappingSupplierId('');
  };

  const unlinkSupplier = (itemId: string) => setItems(prev => prev.map(item => item.id === itemId ? {
    ...item,
    supplierId: undefined,
    supplierName: undefined,
    status: 'Without supplier',
    supplierMapping: { status: 'Unlinked' },
    lastUpdated: new Date().toISOString().slice(0, 10)
  } : item));

  const applyCostTemplate = (template: ProductCostTemplate) => {
    const templateCost = calculateTemplateCost(template);
    setItems(prev => prev.map(item => {
      const matchesCategory = !template.categoryId || item.categoryId === template.categoryId;
      const matchesType = template.appliesToType === 'All' || item.type === template.appliesToType || item.category === template.appliesToType;
      if (!matchesCategory && !matchesType) return item;
      const nextSelling = Math.max(item.sellingPrice, Math.round(templateCost * 1.22));
      return {
        ...item,
        costPrice: templateCost,
        sellingPrice: nextSelling,
        price: nextSelling,
        lastUpdated: new Date().toISOString().slice(0, 10),
        activity: [{ id: `PACT-${Date.now()}-${item.id}`, type: 'Cost Template', message: `Applied ${template.name}.`, date: new Date().toISOString().slice(0, 10), user: 'Super Admin' }, ...item.activity]
      };
    }));
    setMockNotice(`${template.name} applied to matching catalog items.`);
  };

  const addCostTemplate = () => {
    if (!costTemplateDraft.name.trim() || !costTemplateDraft.componentName.trim()) return;
    const amount = Number(costTemplateDraft.amount) || 0;
    setCostTemplates(prev => [{
      id: `CT-${Date.now()}`,
      name: costTemplateDraft.name.trim(),
      categoryId: costTemplateDraft.categoryId,
      appliesToType: costTemplateDraft.appliesToType,
      status: 'Draft',
      lastUpdated: new Date().toISOString().slice(0, 10),
      components: [{
        id: `CC-${Date.now()}`,
        name: costTemplateDraft.componentName.trim(),
        costType: costTemplateDraft.costType,
        amount,
        currency: 'USD',
        taxable: costTemplateDraft.costType !== 'Percentage'
      }]
    }, ...prev]);
    setCostTemplateDraft({ name: '', categoryId: categories[0]?.id || '', appliesToType: 'Hotel', componentName: '', costType: 'Fixed', amount: '0' });
  };

  const applyPricingRule = (rule: ProductPricingRule) => {
    setItems(prev => prev.map(item => {
      if (!pricingRuleMatchesItem(rule, item)) return item;
      const sellingPrice = rule.ruleType === 'Fixed Markup'
        ? item.costPrice + rule.value
        : Math.round(item.costPrice * (1 + rule.value / 100));
      return {
        ...item,
        sellingPrice,
        price: sellingPrice,
        lastUpdated: new Date().toISOString().slice(0, 10),
        activity: [{ id: `PACT-${Date.now()}-${item.id}`, type: 'Pricing', message: `Applied rule ${rule.name}.`, date: new Date().toISOString().slice(0, 10), user: 'Super Admin' }, ...item.activity]
      };
    }));
    setMockNotice(`${rule.name} applied to matching catalog items.`);
  };

  const addPricingRule = () => {
    if (!pricingRuleDraft.name.trim()) return;
    setPricingRules(prev => [{
      id: `PR-${Date.now()}`,
      name: pricingRuleDraft.name.trim(),
      categoryId: pricingRuleDraft.categoryId,
      destination: pricingRuleDraft.destination.trim() || undefined,
      ruleType: 'Markup %',
      value: Number(pricingRuleDraft.value) || 0,
      minMarginPercent: Number(pricingRuleDraft.minMarginPercent) || 0,
      priority: prev.length + 1,
      status: 'Active'
    }, ...prev]);
    setPricingRuleDraft({ name: '', categoryId: categories[0]?.id || '', destination: '', value: '20', minMarginPercent: '15' });
  };

  const addAvailabilityRule = () => {
    if (!availabilityDraft.name.trim() || !availabilityDraft.itemId || !availabilityDraft.startDate || !availabilityDraft.endDate) return;
    setAvailabilityRules(prev => [{
      id: `AR-${Date.now()}`,
      itemId: availabilityDraft.itemId,
      name: availabilityDraft.name.trim(),
      ruleType: availabilityDraft.ruleType,
      startDate: availabilityDraft.startDate,
      endDate: availabilityDraft.endDate,
      quantity: Number(availabilityDraft.quantity) || 0,
      releaseDays: Number(availabilityDraft.releaseDays) || 0,
      status: availabilityDraft.status as ProductAvailabilityRule['status'],
      supplierId: items.find(item => item.id === availabilityDraft.itemId)?.supplierId
    }, ...prev]);
    setAvailabilityDraft(prev => ({ ...prev, name: '', quantity: '1' }));
  };

  const addPackageTemplate = () => {
    if (!packageDraft.name.trim() || packageDraft.itemIds.length === 0) return;
    setPackageTemplates(prev => [{
      id: `PKT-${Date.now()}`,
      name: packageDraft.name.trim(),
      packageType: packageDraft.packageType,
      destination: packageDraft.destination.trim() || 'Multiple',
      itemIds: packageDraft.itemIds,
      basePax: Number(packageDraft.basePax) || 1,
      status: 'Draft',
      lastUpdated: new Date().toISOString().slice(0, 10)
    }, ...prev]);
    setPackageDraft({ name: '', packageType: 'Package', destination: '', itemIds: [], basePax: '2' });
  };

  const getTranslatedStatus = (status: string) => {
    if (status === 'Active') return t('products.status.active');
    if (status === 'Draft') return t('products.status.draft');
    if (status === 'Inactive') return t('products.status.inactive');
    if (status === 'Archived') return t('products.status.archived');
    if (status === 'Needs review') return t('products.status.needsReview');
    if (status === 'Without supplier') return t('products.status.withoutSupplier');
    return status;
  };

  const getTranslatedType = (type: string) => {
    if (type === 'Hotel') return t('products.type.hotel');
    if (type === 'Cruise') return t('products.type.cruise');
    if (type === 'Airline') return t('products.type.airline');
    if (type === 'Sightseeing') return t('products.type.sightseeing');
    if (type === 'Transfer') return t('products.type.transfer');
    if (type === 'Activity') return t('products.type.activity');
    return type;
  };

  return (
    <div className="w-full pb-8 overflow-x-hidden">
      <div className="mx-auto max-w-[1400px] space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
            <div className="min-w-0 logical-start">
              <h1 className="break-words text-2xl sm:text-3xl font-bold tracking-tight">{t('products.catalog.title')}</h1>
              <p className="mt-1 text-sm text-blue-100 opacity-90">{t('products.catalog.subtitle')}</p>
            </div>
            <div className={cn("flex items-center gap-2 sm:gap-3 banner-actions", isRTL && "flex-row-reverse")}>
            <Button className="bg-white text-blue-600 hover:bg-gray-50" onClick={openAddForm}><Plus className="h-4 w-4" />{t('products.catalog.addProduct')}</Button>
            <Button variant="outline" className="bg-white/10 text-white border-transparent hover:bg-white/20" onClick={addCategory}><Package className="h-4 w-4" />{t('products.catalog.addCategory')}</Button>
            <Button variant="outline" className="bg-white/10 text-white border-transparent hover:bg-white/20" onClick={() => setMockNotice(t('products.catalog.notice.importExport'))}><FileUp className="h-4 w-4" />{t('products.catalog.importExport')}</Button>
            <Button variant="outline" className="bg-white/10 text-white border-transparent hover:bg-white/20" onClick={() => setMockNotice(t('products.catalog.notice.mapping'))}><Link2 className="h-4 w-4" />{t('products.catalog.viewSupplierMapping')}</Button>
          </div>
        </div>

      {mockNotice && (
        <div className="rounded-lg border border-blue-100 bg-blue-50 p-3 text-sm font-medium text-blue-700 logical-start">
          {mockNotice}
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label={t('products.catalog.stats.total')} value={items.length.toString()} />
        <StatCard label={t('products.catalog.stats.active')} value={activeItems.toString()} tone="green" />
        <StatCard label={t('products.catalog.stats.draftInactive')} value={draftInactiveItems.toString()} tone="amber" />
        <StatCard label={t('products.catalog.stats.archived')} value={archivedItems.toString()} tone="gray" />
        <StatCard label={t('products.catalog.stats.linkedSuppliers')} value={linkedSuppliersCount.toString()} tone="blue" />
        <StatCard label={t('products.catalog.stats.withoutSupplier')} value={withoutSupplier.toString()} tone="red" />
        <StatCard label={t('products.catalog.stats.avgMargin')} value={`${avgMargin}%`} tone="green" />
        <StatCard label={t('products.catalog.stats.destinations')} value={destinations.length.toString()} tone="blue" />
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader>
            <CardTitle className="logical-start">{t('products.catalog.topCategories')}</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {topCategories.map(category => (
              <button key={category.id} onClick={() => setCategoryFilter(category.id)} className="rounded-lg border border-gray-100 p-3 logical-start hover:bg-gray-50">
                <div className="flex w-full items-center justify-between gap-3">
                  <div className="logical-start">
                    <div className="font-semibold">{category.name}</div>
                    <div className="text-xs text-gray-500 bidi-isolate">{getTranslatedType(category.type)} - {category.count}</div>
                  </div>
                  <span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(category.status)}`}>{getTranslatedStatus(category.status)}</span>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="logical-start">{t('products.catalog.statusDistribution')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {statusDistribution.map(entry => (
              <button key={entry.status} onClick={() => setStatusFilter(entry.status)} className="flex w-full items-center justify-between rounded-lg border border-gray-100 p-3 logical-start hover:bg-gray-50">
                <span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(entry.status)}`}>{getTranslatedStatus(entry.status)}</span>
                <span className="font-bold bidi-isolate">{entry.count}</span>
              </button>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-[1.4fr_repeat(5,1fr)_auto]">
            <div className="relative">
              <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400`} />
              <Input
                placeholder={t('products.catalog.searchPlaceholder')}
                value={searchTerm}
                onChange={(event) => setSearchTerm(event.target.value)}
                className={isRTL ? 'pr-10 pl-4' : 'pl-10 pr-4'}
              />
            </div>
            <Select value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)}>
              <option value="All Categories">{t('products.catalog.filter.allCategories')}</option>
              {categories.map(category => <option key={category.id} value={category.id}>{category.name}</option>)}
            </Select>
            <Select value={supplierFilter} onChange={(event) => setSupplierFilter(event.target.value)}>
              <option value="All Suppliers">{t('products.catalog.filter.allSuppliers')}</option>
              <option value="Without supplier">{t('products.status.withoutSupplier')}</option>
              {suppliers.map(supplier => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}
            </Select>
            <Select value={destinationFilter} onChange={(event) => setDestinationFilter(event.target.value)}>
              <option value="All Destinations">{t('products.catalog.filter.allDestinations')}</option>
              {destinations.map(destination => <option key={destination} value={destination}>{destination}</option>)}
            </Select>
            <Select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
              <option value="All Status">{t('products.catalog.filter.allStatus')}</option>
              {statusOptions.map(status => <option key={status} value={status}>{getTranslatedStatus(status)}</option>)}
            </Select>
            <Select value={typeFilter} onChange={(event) => setTypeFilter(event.target.value)}>
              <option value="All Types">{t('products.catalog.filter.allTypes')}</option>
              {typeOptions.map(type => <option key={type} value={type}>{getTranslatedType(type)}</option>)}
            </Select>
            <Button variant="outline" onClick={resetFilters}>{t('products.catalog.clear')}</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="logical-start">{t('products.catalog.table.title')}</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table style={{ direction }} className="w-full min-w-[1120px] text-sm">
              <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-500">
                <tr>
                  <th className="px-4 py-3 logical-start">{t('products.catalog.table.product')}</th>
                  <th className="px-4 py-3 logical-start">{t('products.catalog.table.category')}</th>
                  <th className="px-4 py-3 logical-start">{t('products.catalog.table.type')}</th>
                  <th className="px-4 py-3 logical-start">{t('products.catalog.table.destination')}</th>
                  <th className="px-4 py-3 logical-start">{t('products.catalog.table.supplier')}</th>
                  <th className="px-4 py-3 logical-start">{t('products.catalog.table.cost')}</th>
                  <th className="px-4 py-3 logical-start">{t('products.catalog.table.selling')}</th>
                  <th className="px-4 py-3 logical-start">{t('products.catalog.table.margin')}</th>
                  <th className="px-4 py-3 logical-start">{t('products.catalog.table.status')}</th>
                  <th className="px-4 py-3 logical-start">{t('products.catalog.table.updated')}</th>
                  <th className="px-4 py-3 logical-end">{t('products.catalog.table.actions')}</th>
                </tr>
              </thead>
              <tbody>
                {filteredItems.map(item => {
                  const supplier = supplierById(item.supplierId);
                  return (
                    <tr key={item.id} className="border-t border-gray-100 hover:bg-gray-50">
                      <td className="px-4 py-3 logical-start">
                        <div className="font-semibold text-gray-900 dark:text-white">{item.name}</div>
                        <div className="max-w-[240px] truncate text-xs text-gray-500">{item.description}</div>
                      </td>
                      <td className="px-4 py-3 logical-start">{item.category}</td>
                      <td className="px-4 py-3 logical-start">{getTranslatedType(item.type)}</td>
                      <td className="px-4 py-3 logical-start">{item.destination}</td>
                      <td className="px-4 py-3 logical-start">
                        {supplier ? (
                          <button className="logical-start text-blue-600 hover:underline" onClick={() => navigate(`/reservations/suppliers/${supplier.id}`)}>
                            {supplier.name}
                            <span className={`ml-2 rtl:ml-0 rtl:mr-2 rounded-full border px-1.5 py-0.5 text-[9px] font-bold ${badgeClass(supplier.status || 'Active')}`}>{getStatusLabel(supplier.status || 'Active')}</span>
                          </button>
                        ) : (
                          <span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass('Without supplier')}`}>{t('products.status.withoutSupplier')}</span>
                        )}
                      </td>
                      <td className="px-4 py-3 logical-start font-medium bidi-isolate">{formatCurrency(item.costPrice, { currency: 'USD' })}</td>
                      <td className="px-4 py-3 logical-start font-medium bidi-isolate">{formatCurrency(item.sellingPrice, { currency: 'USD' })}</td>
                      <td className="px-4 py-3 logical-start font-bold bidi-isolate">{formatCurrency(item.sellingPrice - item.costPrice, { currency: 'USD' })} / {marginPercent(item)}%</td>
                      <td className="px-4 py-3 logical-start"><span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(item.status)}`}>{getTranslatedStatus(item.status)}</span></td>
                      <td className="px-4 py-3 logical-start bidi-isolate">{formatDate(item.lastUpdated)}</td>
                      <td className="px-4 py-3 logical-end">
                        <TableActionsDropdown
                          actions={[
                            { label: t('common.view'), icon: Eye, onClick: () => viewItem(item) },
                            { label: t('common.edit'), icon: Edit, onClick: () => openEditForm(item) },
                            { label: t('products.catalog.actions.duplicate'), icon: Copy, onClick: () => duplicateItem(item) },
                            { label: t('products.catalog.actions.archive'), icon: Archive, onClick: () => archiveItem(item.id), variant: 'danger' }
                          ]}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="logical-start">{t('products.catalog.categoriesManagement')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-[1fr_180px_auto] logical-start">
              <Input placeholder={t('products.catalog.categoryName')} value={categoryDraft.name} onChange={(event) => setCategoryDraft(prev => ({ ...prev, name: event.target.value }))} />
              <Select value={categoryDraft.type} onChange={(event) => setCategoryDraft(prev => ({ ...prev, type: event.target.value }))}>
                {typeOptions.map(type => <option key={type} value={type}>{getTranslatedType(type)}</option>)}
              </Select>
              <Button onClick={addCategory}>{t('common.add')}</Button>
            </div>
            <div className="overflow-x-auto">
              <table style={{ direction }} className="w-full min-w-[680px] text-sm">
                <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-500">
                  <tr>
                    <th className="px-3 py-2 logical-start">{t('products.catalog.table.category')}</th>
                    <th className="px-3 py-2 logical-start">{t('products.catalog.table.type')}</th>
                    <th className="px-3 py-2 logical-start">{t('products.catalog.categoryItems')}</th>
                    <th className="px-3 py-2 logical-start">{t('products.catalog.stats.active')}</th>
                    <th className="px-3 py-2 logical-start">{t('products.catalog.destinationSuppliers')}</th>
                    <th className="px-3 py-2 logical-start">{t('products.catalog.categoryRevenue')}</th>
                    <th className="px-3 py-2 logical-start">{t('products.catalog.table.status')}</th>
                    <th className="px-3 py-2 logical-end">{t('products.catalog.table.actions')}</th>
                  </tr>
                </thead>
                <tbody>
                  {categoryRows.map(category => (
                    <tr key={category.id} className="border-t">
                      <td className="px-3 py-2 font-semibold logical-start">{category.name}</td>
                      <td className="px-3 py-2 logical-start">{getTranslatedType(category.type)}</td>
                      <td className="px-3 py-2 logical-start bidi-isolate">{category.itemsCount}</td>
                      <td className="px-3 py-2 logical-start bidi-isolate">{category.activeItems}</td>
                      <td className="px-3 py-2 logical-start bidi-isolate">{category.linkedSuppliers}</td>
                      <td className="px-3 py-2 logical-start font-medium bidi-isolate">{formatCurrency(category.revenue, { currency: 'USD' })}</td>
                      <td className="px-3 py-2 logical-start"><span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(category.status)}`}>{getTranslatedStatus(category.status)}</span></td>
                      <td className="px-3 py-2 logical-end">
                        <TableActionsDropdown
                          actions={[
                            { label: t('common.edit'), icon: Edit, onClick: () => setCategories(prev => prev.map(entry => entry.id === category.id ? { ...entry, status: entry.status === 'Active' ? 'Draft' : 'Active' } : entry)) },
                            { label: t('common.delete'), icon: Trash2, onClick: () => deleteCategory(category.id), variant: 'danger' }
                          ]}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="logical-start">{t('products.catalog.destinationsCovered')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {destinationRows.map(row => (
              <button key={row.destination} onClick={() => setDestinationFilter(row.destination)} className="flex w-full flex-col gap-2 rounded-lg border border-gray-100 p-3 logical-start hover:bg-gray-50 sm:flex-row sm:items-center sm:justify-between">
                <div className="logical-start">
                  <div className="font-semibold">{row.destination}</div>
                  <div className="text-xs text-gray-500 bidi-isolate">{row.country} - {row.services} {t('products.catalog.destinationServices').toLowerCase()} - {row.suppliers} {t('products.catalog.destinationSuppliers').toLowerCase()}</div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold bidi-isolate">{row.active} {t('products.catalog.stats.active').toLowerCase()}</span>
                  <span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(row.status)}`}>{getTranslatedStatus(row.status)}</span>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="logical-start"><Calculator className="h-4 w-4" /> Cost Components & Templates</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-2 lg:grid-cols-3 logical-start">
              <Input placeholder="Template name" value={costTemplateDraft.name} onChange={(event) => setCostTemplateDraft(prev => ({ ...prev, name: event.target.value }))} />
              <Select value={costTemplateDraft.categoryId} onChange={(event) => setCostTemplateDraft(prev => ({ ...prev, categoryId: event.target.value }))}>
                {categories.map(category => <option key={category.id} value={category.id}>{category.name}</option>)}
              </Select>
              <Select value={costTemplateDraft.appliesToType} onChange={(event) => setCostTemplateDraft(prev => ({ ...prev, appliesToType: event.target.value }))}>
                <option value="All">All</option>
                {typeOptions.map(type => <option key={type} value={type}>{getTranslatedType(type)}</option>)}
              </Select>
              <Input placeholder="Component name" value={costTemplateDraft.componentName} onChange={(event) => setCostTemplateDraft(prev => ({ ...prev, componentName: event.target.value }))} />
              <Select value={costTemplateDraft.costType} onChange={(event) => setCostTemplateDraft(prev => ({ ...prev, costType: event.target.value }))}>
                <option value="Fixed">Fixed</option>
                <option value="Per Person">Per Person</option>
                <option value="Per Night">Per Night</option>
                <option value="Percentage">Percentage</option>
              </Select>
              <div className="grid grid-cols-[1fr_auto] gap-2">
                <Input type="number" placeholder="Amount" value={costTemplateDraft.amount} onChange={(event) => setCostTemplateDraft(prev => ({ ...prev, amount: event.target.value }))} />
                <Button onClick={addCostTemplate}>{t('common.add')}</Button>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table style={{ direction }} className="w-full min-w-[760px] text-sm">
                <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-500">
                  <tr>
                    <th className="px-3 py-2 logical-start">Template</th>
                    <th className="px-3 py-2 logical-start">Applies To</th>
                    <th className="px-3 py-2 logical-start">Components</th>
                    <th className="px-3 py-2 logical-start">Calculated Cost</th>
                    <th className="px-3 py-2 logical-start">Status</th>
                    <th className="px-3 py-2 logical-end">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {costTemplates.map(template => (
                    <tr key={template.id} className="border-t">
                      <td className="px-3 py-2 font-semibold logical-start">{template.name}</td>
                      <td className="px-3 py-2 logical-start">{categories.find(category => category.id === template.categoryId)?.name || 'All'} / {template.appliesToType}</td>
                      <td className="px-3 py-2 logical-start">{template.components.map(component => `${component.name}: ${component.costType} ${component.amount}`).join(', ')}</td>
                      <td className="px-3 py-2 font-semibold logical-start bidi-isolate">{formatCurrency(calculateTemplateCost(template), { currency: 'USD' })}</td>
                      <td className="px-3 py-2 logical-start"><span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(template.status)}`}>{template.status}</span></td>
                      <td className="px-3 py-2 logical-end">
                        <TableActionsDropdown actions={[
                          { label: 'Apply template', icon: Save, onClick: () => applyCostTemplate(template) },
                          { label: t('common.delete'), icon: Trash2, onClick: () => setCostTemplates(prev => prev.filter(entry => entry.id !== template.id)), variant: 'danger' }
                        ]} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="logical-start"><Percent className="h-4 w-4" /> Pricing Rules Management</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-2 lg:grid-cols-5 logical-start">
              <Input placeholder="Rule name" value={pricingRuleDraft.name} onChange={(event) => setPricingRuleDraft(prev => ({ ...prev, name: event.target.value }))} />
              <Select value={pricingRuleDraft.categoryId} onChange={(event) => setPricingRuleDraft(prev => ({ ...prev, categoryId: event.target.value }))}>
                {categories.map(category => <option key={category.id} value={category.id}>{category.name}</option>)}
              </Select>
              <Input placeholder="Destination optional" value={pricingRuleDraft.destination} onChange={(event) => setPricingRuleDraft(prev => ({ ...prev, destination: event.target.value }))} />
              <Input type="number" placeholder="Markup %" value={pricingRuleDraft.value} onChange={(event) => setPricingRuleDraft(prev => ({ ...prev, value: event.target.value }))} />
              <Button onClick={addPricingRule}>{t('common.add')}</Button>
            </div>
            {pricingWarnings.length > 0 && (
              <div className="rounded-lg border border-amber-100 bg-amber-50 p-3 text-xs font-semibold text-amber-700 logical-start">
                {pricingWarnings.slice(0, 4).map(warning => <div key={warning}>{warning}</div>)}
              </div>
            )}
            <div className="overflow-x-auto">
              <table style={{ direction }} className="w-full min-w-[760px] text-sm">
                <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-500">
                  <tr>
                    <th className="px-3 py-2 logical-start">Rule</th>
                    <th className="px-3 py-2 logical-start">Scope</th>
                    <th className="px-3 py-2 logical-start">Markup</th>
                    <th className="px-3 py-2 logical-start">Min Margin</th>
                    <th className="px-3 py-2 logical-start">Impact</th>
                    <th className="px-3 py-2 logical-end">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {pricingRules.map(rule => {
                    const impacted = items.filter(item => pricingRuleMatchesItem(rule, item));
                    return (
                      <tr key={rule.id} className="border-t">
                        <td className="px-3 py-2 font-semibold logical-start">{rule.name}</td>
                        <td className="px-3 py-2 logical-start">{categories.find(category => category.id === rule.categoryId)?.name || 'All'}{rule.destination ? ` / ${rule.destination}` : ''}</td>
                        <td className="px-3 py-2 logical-start bidi-isolate">{rule.value}{rule.ruleType === 'Fixed Markup' ? ' USD' : '%'}</td>
                        <td className="px-3 py-2 logical-start bidi-isolate">{rule.minMarginPercent}%</td>
                        <td className="px-3 py-2 logical-start bidi-isolate">{impacted.length} items</td>
                        <td className="px-3 py-2 logical-end">
                          <TableActionsDropdown actions={[
                            { label: 'Apply rule', icon: Save, onClick: () => applyPricingRule(rule) },
                            { label: rule.status === 'Active' ? 'Deactivate' : 'Activate', icon: Edit, onClick: () => setPricingRules(prev => prev.map(entry => entry.id === rule.id ? { ...entry, status: entry.status === 'Active' ? 'Inactive' : 'Active' } : entry)) },
                            { label: t('common.delete'), icon: Trash2, onClick: () => setPricingRules(prev => prev.filter(entry => entry.id !== rule.id)), variant: 'danger' }
                          ]} />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="logical-start"><CalendarDays className="h-4 w-4" /> Availability Rules & Calendar</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-2 lg:grid-cols-4 logical-start">
              <Select value={availabilityDraft.itemId} onChange={(event) => setAvailabilityDraft(prev => ({ ...prev, itemId: event.target.value }))}>
                {items.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
              </Select>
              <Input placeholder="Rule name" value={availabilityDraft.name} onChange={(event) => setAvailabilityDraft(prev => ({ ...prev, name: event.target.value }))} />
              <Select value={availabilityDraft.ruleType} onChange={(event) => setAvailabilityDraft(prev => ({ ...prev, ruleType: event.target.value }))}>
                <option value="Allocation">Allocation</option>
                <option value="Blackout">Blackout</option>
                <option value="Release Period">Release Period</option>
                <option value="On Request">On Request</option>
              </Select>
              <Select value={availabilityDraft.status} onChange={(event) => setAvailabilityDraft(prev => ({ ...prev, status: event.target.value }))}>
                <option value="Open">Open</option>
                <option value="Limited">Limited</option>
                <option value="Closed">Closed</option>
              </Select>
              <Input type="date" value={availabilityDraft.startDate} onChange={(event) => setAvailabilityDraft(prev => ({ ...prev, startDate: event.target.value }))} />
              <Input type="date" value={availabilityDraft.endDate} onChange={(event) => setAvailabilityDraft(prev => ({ ...prev, endDate: event.target.value }))} />
              <Input type="number" placeholder="Qty" value={availabilityDraft.quantity} onChange={(event) => setAvailabilityDraft(prev => ({ ...prev, quantity: event.target.value }))} />
              <Button onClick={addAvailabilityRule}>{t('common.add')}</Button>
            </div>
            <div className="grid grid-cols-7 gap-1">
              {availabilityRules.slice(0, 28).map(rule => (
                <button
                  key={rule.id}
                  onClick={() => setAvailabilityDraft(prev => ({ ...prev, itemId: rule.itemId }))}
                  className={cn(
                    'min-h-14 rounded border p-1 text-[10px] font-semibold logical-start',
                    rule.status === 'Open' && 'border-emerald-100 bg-emerald-50 text-emerald-700',
                    rule.status === 'Limited' && 'border-amber-100 bg-amber-50 text-amber-700',
                    rule.status === 'Closed' && 'border-rose-100 bg-rose-50 text-rose-700'
                  )}
                >
                  <div className="truncate">{rule.name}</div>
                  <div className="bidi-isolate">{rule.quantity} / {rule.releaseDays}d</div>
                </button>
              ))}
            </div>
            <div className="overflow-x-auto">
              <table style={{ direction }} className="w-full min-w-[760px] text-sm">
                <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-500">
                  <tr>
                    <th className="px-3 py-2 logical-start">Item</th>
                    <th className="px-3 py-2 logical-start">Rule</th>
                    <th className="px-3 py-2 logical-start">Period</th>
                    <th className="px-3 py-2 logical-start">Qty</th>
                    <th className="px-3 py-2 logical-start">Status</th>
                    <th className="px-3 py-2 logical-end">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {availabilityRules.map(rule => (
                    <tr key={rule.id} className="border-t">
                      <td className="px-3 py-2 logical-start">{items.find(item => item.id === rule.itemId)?.name || rule.itemId}</td>
                      <td className="px-3 py-2 font-semibold logical-start">{rule.name}</td>
                      <td className="px-3 py-2 logical-start bidi-isolate">{formatDate(rule.startDate)} {t('common.to')} {formatDate(rule.endDate)}</td>
                      <td className="px-3 py-2 logical-start bidi-isolate">{rule.quantity}</td>
                      <td className="px-3 py-2 logical-start"><span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(rule.status === 'Open' ? 'Active' : rule.status === 'Closed' ? 'Inactive' : 'Needs review')}`}>{rule.status}</span></td>
                      <td className="px-3 py-2 logical-end">
                        <TableActionsDropdown actions={[
                          { label: 'Close rule', icon: Archive, onClick: () => setAvailabilityRules(prev => prev.map(entry => entry.id === rule.id ? { ...entry, status: 'Closed' } : entry)) },
                          { label: t('common.delete'), icon: Trash2, onClick: () => setAvailabilityRules(prev => prev.filter(entry => entry.id !== rule.id)), variant: 'danger' }
                        ]} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="logical-start"><Layers className="h-4 w-4" /> Package Builder Templates</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-2 lg:grid-cols-4 logical-start">
              <Input placeholder="Package name" value={packageDraft.name} onChange={(event) => setPackageDraft(prev => ({ ...prev, name: event.target.value }))} />
              <Input placeholder="Type" value={packageDraft.packageType} onChange={(event) => setPackageDraft(prev => ({ ...prev, packageType: event.target.value }))} />
              <Input placeholder="Destination" value={packageDraft.destination} onChange={(event) => setPackageDraft(prev => ({ ...prev, destination: event.target.value }))} />
              <Button onClick={addPackageTemplate}>{t('common.add')}</Button>
            </div>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {items.map(item => (
                <label key={item.id} className="flex items-start gap-2 rounded border border-gray-100 p-2 text-sm logical-start">
                  <input
                    type="checkbox"
                    className="mt-1"
                    checked={packageDraft.itemIds.includes(item.id)}
                    onChange={(event) => setPackageDraft(prev => ({
                      ...prev,
                      itemIds: event.target.checked ? [...prev.itemIds, item.id] : prev.itemIds.filter(id => id !== item.id)
                    }))}
                  />
                  <span>
                    <span className="block font-semibold">{item.name}</span>
                    <span className="text-xs text-gray-500 bidi-isolate">{formatCurrency(item.sellingPrice, { currency: 'USD' })}</span>
                  </span>
                </label>
              ))}
            </div>
            <div className="overflow-x-auto">
              <table style={{ direction }} className="w-full min-w-[760px] text-sm">
                <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-500">
                  <tr>
                    <th className="px-3 py-2 logical-start">Package</th>
                    <th className="px-3 py-2 logical-start">Destination</th>
                    <th className="px-3 py-2 logical-start">Items</th>
                    <th className="px-3 py-2 logical-start">Cost</th>
                    <th className="px-3 py-2 logical-start">Selling</th>
                    <th className="px-3 py-2 logical-start">Margin</th>
                    <th className="px-3 py-2 logical-end">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {packageRows.map(row => (
                    <tr key={row.id} className="border-t">
                      <td className="px-3 py-2 font-semibold logical-start">{row.name}</td>
                      <td className="px-3 py-2 logical-start">{row.destination}</td>
                      <td className="px-3 py-2 logical-start bidi-isolate">{row.itemCount}</td>
                      <td className="px-3 py-2 logical-start bidi-isolate">{formatCurrency(row.cost, { currency: 'USD' })}</td>
                      <td className="px-3 py-2 logical-start bidi-isolate">{formatCurrency(row.selling, { currency: 'USD' })}</td>
                      <td className="px-3 py-2 font-bold logical-start bidi-isolate">{row.margin}%</td>
                      <td className="px-3 py-2 logical-end">
                        <TableActionsDropdown actions={[
                          { label: row.status === 'Active' ? 'Draft' : 'Activate', icon: Edit, onClick: () => setPackageTemplates(prev => prev.map(entry => entry.id === row.id ? { ...entry, status: entry.status === 'Active' ? 'Draft' : 'Active' } : entry)) },
                          { label: t('common.delete'), icon: Trash2, onClick: () => setPackageTemplates(prev => prev.filter(entry => entry.id !== row.id)), variant: 'danger' }
                        ]} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="logical-start"><BarChart3 className="h-4 w-4" /> Products & Services Analytics</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
            <StatCard label="Catalog Revenue" value={formatCurrency(analyticsRows.reduce((sum, row) => sum + row.revenue, 0), { currency: 'USD' })} tone="green" />
            <StatCard label="Catalog Cost" value={formatCurrency(analyticsRows.reduce((sum, row) => sum + row.cost, 0), { currency: 'USD' })} tone="amber" />
            <StatCard label="Usage Volume" value={analyticsRows.reduce((sum, row) => sum + row.bookings, 0).toString()} tone="blue" />
            <StatCard label="Low Margin Alerts" value={pricingWarnings.length.toString()} tone={pricingWarnings.length ? 'red' : 'green'} />
          </div>
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            {analyticsRows.map(row => (
              <button key={row.id} onClick={() => setCategoryFilter(row.id)} className="rounded-lg border border-gray-100 p-3 logical-start hover:bg-gray-50">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold">{row.name}</div>
                    <div className="text-xs text-gray-500 bidi-isolate">{row.bookings} bookings / {formatCurrency(row.revenue, { currency: 'USD' })}</div>
                  </div>
                  <span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${row.margin < 15 ? badgeClass('Needs review') : badgeClass('Active')}`}>{row.margin}%</span>
                </div>
                <div className="mt-3 h-2 overflow-hidden rounded-full bg-gray-100">
                  <div className={cn('h-full rounded-full', row.margin < 15 ? 'bg-amber-500' : 'bg-emerald-500')} style={{ width: `${Math.min(100, Math.max(4, row.margin))}%` }} />
                </div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="logical-start">{t('products.catalog.supplierMapping')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
            {items.map(item => {
              const supplier = supplierById(item.supplierId);
              return (
                <div key={item.id} className="rounded-lg border border-gray-100 p-3 logical-start">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 logical-start">
                      <div className="break-words font-semibold">{item.name}</div>
                      <div className="text-xs text-gray-500">{item.category} - {item.destination}</div>
                      <div className="mt-2">
                        {supplier ? (
                          <button className="text-sm font-medium text-blue-600 hover:underline logical-start" onClick={() => navigate(`/reservations/suppliers/${supplier.id}`)}>
                            {supplier.name} ({getStatusLabel(supplier.status || 'Active')})
                          </button>
                        ) : (
                          <span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass('Without supplier')}`}>{t('products.catalog.supplierMissing')}</span>
                        )}
                      </div>
                    </div>
                    {supplier ? (
                      <IconButton title={t('products.catalog.unlinkSupplier')} onClick={() => unlinkSupplier(item.id)}><Unlink className="h-4 w-4" /></IconButton>
                    ) : (
                      <IconButton title={t('products.catalog.linkSupplier')} onClick={() => { setMappingItemId(item.id); setMappingSupplierId(suppliers[0]?.id || ''); }}><Link2 className="h-4 w-4" /></IconButton>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          {mappingItemId && (
            <div className="grid grid-cols-1 gap-2 rounded-lg border border-blue-100 bg-blue-50 p-3 sm:grid-cols-[1fr_auto_auto] logical-start">
              <Select value={mappingSupplierId} onChange={(event) => setMappingSupplierId(event.target.value)}>
                {suppliers.map(supplier => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}
              </Select>
              <Button onClick={linkSupplier}>{t('products.catalog.linkSupplier')}</Button>
              <Button variant="outline" onClick={() => setMappingItemId(null)}>{t('common.cancel')}</Button>
            </div>
          )}
        </CardContent>
      </Card>

      {isFormOpen && (
        <ProductFormModal
          mode={formMode}
          item={editingItem}
          categories={categories}
          suppliers={suppliers}
          onClose={() => setIsFormOpen(false)}
          onSave={handleSaveItem}
        />
      )}
      </div>
    </div>
  );
};

const splitList = (value: string) => value.split(',').map(entry => entry.trim()).filter(Boolean);

const marginPercent = (item: ProductServiceItem) => {
  if (!item.sellingPrice) return 0;
  return Math.round(((item.sellingPrice - item.costPrice) / item.sellingPrice) * 100);
};

const calculateTemplateCost = (template: ProductCostTemplate) => {
  const fixedBase = template.components
    .filter(component => component.costType !== 'Percentage')
    .reduce((sum, component) => sum + component.amount, 0);
  const percentage = template.components
    .filter(component => component.costType === 'Percentage')
    .reduce((sum, component) => sum + component.amount, 0);
  return Math.round(fixedBase * (1 + percentage / 100));
};

const pricingRuleMatchesItem = (rule: ProductPricingRule, item: ProductServiceItem) => {
  if (rule.status !== 'Active') return false;
  const categoryMatch = !rule.categoryId || rule.categoryId === item.categoryId;
  const destinationMatch = !rule.destination || rule.destination === item.destination;
  const today = new Date().toISOString().slice(0, 10);
  const dateMatch = (!rule.startDate || today >= rule.startDate) && (!rule.endDate || today <= rule.endDate);
  return categoryMatch && destinationMatch && dateMatch;
};

const findPricingRule = (item: ProductServiceItem, rules: ProductPricingRule[]) => {
  return rules
    .filter(rule => pricingRuleMatchesItem(rule, item))
    .sort((a, b) => b.priority - a.priority)[0];
};

const getStatusLabel = (val: string) => {
  if (val === 'Active') return 'Active';
  if (val === 'Inactive') return 'Inactive';
  if (val === 'Valid') return 'Valid';
  if (val === 'Draft') return 'Draft';
  if (val === 'Onboarding') return 'Onboarding';
  if (val === 'Suspended') return 'Suspended';
  if (val === 'Overdue') return 'Overdue';
  return val;
};

const StatCard: React.FC<{ label: string; value: string; tone?: 'green' | 'amber' | 'red' | 'blue' | 'gray' }> = ({ label, value, tone = 'blue' }) => {
  const tones = {
    green: 'text-emerald-500',
    amber: 'text-amber-500',
    red: 'text-rose-500',
    blue: 'text-blue-500',
    gray: 'text-gray-500'
  };
  const iconTones = {
    green: 'text-emerald-500/10',
    amber: 'text-amber-500/10',
    red: 'text-rose-500/10',
    blue: 'text-blue-500/10',
    gray: 'text-gray-500/10'
  };
  return (
    <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
      <CardContent className="p-6">
        <div className="flex flex-col relative z-10 logical-start">
          <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">{label}</p>
          <p className="text-3xl font-bold text-gray-900 dark:text-white bidi-isolate">{value}</p>
          <p className={`text-xs font-semibold mt-2 flex items-center ${tones[tone]}`}>
             <ClipboardList className="w-3 h-3 ltr:mr-1 rtl:ml-1" />
             {tone === 'green' ? 'Active' : 'Tracker'}
          </p>
        </div>
        <ClipboardList className={`absolute ltr:-right-4 rtl:-left-4 -bottom-4 h-24 w-24 group-hover:scale-110 transition-transform duration-300 ${iconTones[tone]}`} />
      </CardContent>
    </Card>
  );
};

const IconButton: React.FC<{ title: string; onClick: () => void; children: React.ReactNode }> = ({ title, onClick, children }) => (
  <button type="button" title={title} onClick={onClick} className="rounded-lg p-1.5 text-gray-600 transition-colors hover:bg-gray-100 hover:text-blue-600 dark:text-gray-400 dark:hover:bg-gray-800">
    {children}
  </button>
);

const ProductFormModal: React.FC<{
  mode: ProductFormMode;
  item: ProductServiceItem | null;
  categories: ProductCategory[];
  suppliers: typeof mockSuppliers;
  onClose: () => void;
  onSave: (form: ProductFormState) => void;
}> = ({ mode, item, categories, suppliers, onClose, onSave }) => {
  const { t, direction } = useLocale();

  const [form, setForm] = useState<ProductFormState>(() => item ? {
    name: item.name,
    description: item.description,
    categoryId: item.categoryId,
    type: item.type,
    destination: item.destination,
    location: item.location,
    supplierId: item.supplierId || '',
    costPrice: item.costPrice.toString(),
    sellingPrice: item.sellingPrice.toString(),
    priceUnit: item.priceUnit,
    status: item.status,
    availability: item.availability,
    duration: item.attributes.duration || '',
    capacity: item.attributes.capacity || '',
    serviceClass: item.attributes.serviceClass || item.attributes.roomType || item.attributes.vehicleType || '',
    inclusions: item.attributes.inclusions.join(', '),
    exclusions: item.attributes.exclusions.join(', '),
    cancellationPolicy: item.attributes.cancellationPolicy,
    bookingNotes: item.attributes.bookingNotes || '',
    internalNotes: item.attributes.internalNotes || '',
    mediaFileName: item.media[0]?.fileName || 'main-image-placeholder.jpg',
    seasonalRates: item.seasonalRates || []
  } : emptyForm(categories[0]?.id));
  const [submitted, setSubmitted] = useState(false);

  const [isRateFormOpen, setIsRateFormOpen] = useState(false);
  const [rateSeasonName, setRateSeasonName] = useState('');
  const [rateStartDate, setRateStartDate] = useState('');
  const [rateEndDate, setRateEndDate] = useState('');
  const [rateCostPrice, setRateCostPrice] = useState('0');
  const [rateSellingPrice, setRateSellingPrice] = useState('0');
  const [rateCurrency, setRateCurrency] = useState('USD');
  const [rateStatus, setRateStatus] = useState<'Active' | 'Inactive'>('Active');
  const [rateNotes, setRateNotes] = useState('');

  const getTranslatedStatus = (status: string) => {
    if (status === 'Active') return t('products.status.active');
    if (status === 'Draft') return t('products.status.draft');
    if (status === 'Inactive') return t('products.status.inactive');
    if (status === 'Archived') return t('products.status.archived');
    if (status === 'Needs review') return t('products.status.needsReview');
    if (status === 'Without supplier') return t('products.status.withoutSupplier');
    return status;
  };

  const getTranslatedType = (type: string) => {
    if (type === 'Hotel') return t('products.type.hotel');
    if (type === 'Cruise') return t('products.type.cruise');
    if (type === 'Airline') return t('products.type.airline');
    if (type === 'Sightseeing') return t('products.type.sightseeing');
    if (type === 'Transfer') return t('products.type.transfer');
    if (type === 'Activity') return t('products.type.activity');
    return type;
  };

  const addRateRow = () => {
    if (!rateSeasonName.trim() || !rateStartDate || !rateEndDate) return;
    const newRate: ProductSeasonalRate = {
      id: `SR-${Date.now()}`,
      seasonName: rateSeasonName.trim(),
      startDate: rateStartDate,
      endDate: rateEndDate,
      costPrice: Number(rateCostPrice) || 0,
      sellingPrice: Number(rateSellingPrice) || 0,
      currency: rateCurrency,
      status: rateStatus,
      notes: rateNotes.trim() || undefined
    };
    setForm(prev => ({
      ...prev,
      seasonalRates: [...(prev.seasonalRates || []), newRate]
    }));
    setRateSeasonName('');
    setRateStartDate('');
    setRateEndDate('');
    setRateCostPrice('0');
    setRateSellingPrice('0');
    setRateNotes('');
    setIsRateFormOpen(false);
  };

  const deleteRateRow = (rateId: string) => {
    setForm(prev => ({
      ...prev,
      seasonalRates: (prev.seasonalRates || []).filter(r => r.id !== rateId)
    }));
  };

  const selectedCategory = categories.find(category => category.id === form.categoryId);
  const selectedSupplier = suppliers.find(supplier => supplier.id === form.supplierId);
  const canSave = form.name.trim() && form.categoryId && form.destination.trim() && Number(form.sellingPrice) >= 0;

  const update = (key: keyof ProductFormState, value: string) => setForm(prev => ({ ...prev, [key]: value }));

  const submit = () => {
    setSubmitted(true);
    if (!canSave) return;
    onSave(form);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-screen items-start justify-center p-4 sm:items-center">
        <div className="fixed inset-0 bg-black/50" onClick={onClose} />
        <div className="relative max-h-[92vh] w-full max-w-5xl overflow-y-auto rounded-lg bg-white dark:bg-gray-900 shadow-xl">
          <div className="flex items-center justify-between border-b border-gray-200 dark:border-gray-800 p-5 logical-start">
            <div className="logical-start">
              <h2 className="text-xl font-bold">{mode === 'add' ? t('products.form.titleAdd') : t('products.form.titleEdit')}</h2>
              <p className="text-sm text-gray-500">{t('products.form.subtitle')}</p>
            </div>
            <button type="button" onClick={onClose} className="rounded-lg p-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800"><X className="h-5 w-5" /></button>
          </div>
          <div className="grid grid-cols-1 gap-5 p-5 lg:grid-cols-3">
            <div className="space-y-5 lg:col-span-2">
              <FormSection title={t('products.form.basicInfo')}>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 logical-start">
                  <Input label={t('products.form.name') + ' *'} value={form.name} onChange={(event) => update('name', event.target.value)} error={submitted && !form.name.trim() ? t('products.form.nameError') : ''} />
                  <Select label={t('products.catalog.table.status')} value={form.status} onChange={(event) => update('status', event.target.value)}>
                    {statusOptions.map(status => <option key={status} value={status}>{getTranslatedStatus(status)}</option>)}
                  </Select>
                  <div className="sm:col-span-2 logical-start">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">{t('products.form.description')}</label>
                    <textarea value={form.description} onChange={(event) => update('description', event.target.value)} rows={3} className="mt-1 block w-full rounded-md border border-gray-300 dark:border-gray-700 dark:bg-gray-800 px-3 py-2 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                  </div>
                </div>
              </FormSection>

              <FormSection title={t('products.form.categoryTypeLocation')}>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 logical-start">
                  <Select label={t('products.form.category') + ' *'} value={form.categoryId} onChange={(event) => update('categoryId', event.target.value)}>
                    {categories.map(category => <option key={category.id} value={category.id}>{category.name}</option>)}
                  </Select>
                  <Select label={t('products.form.type')} value={form.type} onChange={(event) => update('type', event.target.value)}>
                    {typeOptions.map(type => <option key={type} value={type}>{getTranslatedType(type)}</option>)}
                  </Select>
                  <Input label={t('products.form.destination') + ' *'} value={form.destination} onChange={(event) => update('destination', event.target.value)} error={submitted && !form.destination.trim() ? t('products.form.destinationError') : ''} />
                  <Input label={t('products.form.location')} value={form.location} onChange={(event) => update('location', event.target.value)} />
                </div>
              </FormSection>

              <FormSection title={t('products.form.supplierPricingAvailability')}>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 logical-start">
                  <Select label={t('products.form.supplier')} value={form.supplierId} onChange={(event) => update('supplierId', event.target.value)}>
                    <option value="">{t('products.status.withoutSupplier')}</option>
                    {suppliers.map(supplier => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}
                  </Select>
                  <Input label={t('products.details.overview.availability')} value={form.availability} onChange={(event) => update('availability', event.target.value)} />
                  <Input label={t('products.form.costPrice')} type="number" value={form.costPrice} onChange={(event) => update('costPrice', event.target.value)} />
                  <Input label={t('products.form.sellingPrice') + ' *'} type="number" value={form.sellingPrice} onChange={(event) => update('sellingPrice', event.target.value)} />
                  <Input label={t('products.form.priceUnit')} value={form.priceUnit} onChange={(event) => update('priceUnit', event.target.value)} />
                </div>
              </FormSection>

              <FormSection title={t('products.form.attributes')}>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 logical-start">
                  <Input label={t('products.details.attributes.duration')} value={form.duration} onChange={(event) => update('duration', event.target.value)} />
                  <Input label={t('products.details.attributes.capacity')} value={form.capacity} onChange={(event) => update('capacity', event.target.value)} />
                  <Input label={t('products.form.roomClassVehicle')} value={form.serviceClass} onChange={(event) => update('serviceClass', event.target.value)} />
                  <Input label={t('products.details.attributes.cancellation')} value={form.cancellationPolicy} onChange={(event) => update('cancellationPolicy', event.target.value)} />
                  <Input label={t('products.form.inclusionsPlaceholder')} value={form.inclusions} onChange={(event) => update('inclusions', event.target.value)} />
                  <Input label={t('products.form.exclusionsPlaceholder')} value={form.exclusions} onChange={(event) => update('exclusions', event.target.value)} />
                  <Input label={t('products.details.attributes.bookingNotes')} value={form.bookingNotes} onChange={(event) => update('bookingNotes', event.target.value)} />
                  <Input label={t('products.details.attributes.internalNotes')} value={form.internalNotes} onChange={(event) => update('internalNotes', event.target.value)} />
                </div>
              </FormSection>

              <FormSection title={t('products.form.seasonalRatesSection')}>
                <div className="space-y-4 logical-start">
                  {form.seasonalRates && form.seasonalRates.length > 0 ? (
                    <div className="overflow-x-auto rounded border border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900">
                      <table style={{ direction }} className="w-full min-w-[600px] text-xs">
                        <thead className="bg-gray-50 dark:bg-gray-800 text-gray-500 dark:text-gray-400 uppercase font-bold tracking-wider border-b border-gray-100 dark:border-gray-800">
                          <tr>
                            <th className="px-3 py-2 logical-start">{t('products.details.seasonalRates.seasonName')}</th>
                            <th className="px-3 py-2 logical-start">{t('supplier.profile.contracts.period')}</th>
                            <th className="px-3 py-2 logical-start text-right">{t('products.catalog.table.cost')}</th>
                            <th className="px-3 py-2 logical-start text-right">{t('products.catalog.table.selling')}</th>
                            <th className="px-3 py-2 logical-start text-right">{t('products.catalog.table.margin')}</th>
                            <th className="px-3 py-2 logical-start">{t('products.catalog.table.status')}</th>
                            <th className="px-3 py-2 logical-end">{t('products.catalog.table.actions')}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                          {form.seasonalRates.map(rate => {
                            const marginAmt = rate.sellingPrice - rate.costPrice;
                            const marginPct = rate.sellingPrice ? Math.round((marginAmt / rate.sellingPrice) * 100) : 0;
                            const belowCost = rate.sellingPrice < rate.costPrice;
                            return (
                              <tr key={rate.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                                <td className="px-3 py-2 font-medium text-gray-900 dark:text-white logical-start">
                                  <div>{rate.seasonName}</div>
                                  {rate.notes && <div className="text-[10px] text-gray-400 dark:text-gray-500">{rate.notes}</div>}
                                </td>
                                <td className="px-3 py-2 text-gray-500 dark:text-gray-400 logical-start bidi-isolate">{formatDate(rate.startDate)} {t('common.to')} {formatDate(rate.endDate)}</td>
                                <td className="px-3 py-2 text-gray-900 dark:text-white logical-start font-medium bidi-isolate">{formatCurrency(rate.costPrice, { currency: rate.currency })}</td>
                                <td className={`px-3 py-2 logical-start font-semibold bidi-isolate ${belowCost ? 'text-rose-600 font-bold' : 'text-gray-900 dark:text-white'}`}>
                                  <div className="flex justify-end rtl:justify-start items-center gap-1">
                                    {belowCost && <AlertTriangle className="h-3.5 w-3.5 text-rose-500" title={t('products.form.sellingPriceBelowCostTitle')} />}
                                    {formatCurrency(rate.sellingPrice, { currency: rate.currency })}
                                  </div>
                                </td>
                                <td className={`px-3 py-2 logical-start font-bold bidi-isolate ${belowCost ? 'text-rose-600' : 'text-emerald-600'}`}>
                                  {formatCurrency(marginAmt, { currency: rate.currency })} / {marginPct}%
                                </td>
                                <td className="px-3 py-2 logical-start">
                                  <span className={`inline-flex px-1.5 py-0.5 rounded-full text-[9px] font-bold ${
                                    rate.status === 'Active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100 dark:bg-emerald-950/20 dark:text-emerald-400 dark:border-emerald-900/30' : 'bg-gray-50 text-gray-500 border border-gray-100 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700'
                                  }`}>
                                    {getTranslatedStatus(rate.status)}
                                  </span>
                                </td>
                                <td className="px-3 py-2 logical-end">
                                  <button type="button" onClick={() => deleteRateRow(rate.id)} className="p-1 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded" title={t('common.delete')}>
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-4 text-gray-400 text-xs bg-gray-50 dark:bg-gray-800/20 rounded logical-start">
                      {t('products.form.noRates')}
                    </div>
                  )}

                  {!isRateFormOpen ? (
                    <Button type="button" size="sm" variant="outline" onClick={() => setIsRateFormOpen(true)}>
                      <Plus className="h-3.5 w-3.5" /> {t('products.form.addRateRow')}
                    </Button>
                  ) : (
                    <Card className="bg-gray-50 dark:bg-gray-800/20 border border-gray-200 dark:border-gray-700 logical-start">
                      <CardContent className="p-4 space-y-4 logical-start">
                        <div className="flex justify-between items-center pb-2 border-b border-gray-200 dark:border-gray-800">
                          <h5 className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase">{t('products.details.seasonalRates.add')}</h5>
                          <button type="button" onClick={() => setIsRateFormOpen(false)} className="text-gray-400 hover:text-gray-600">
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 logical-start">
                          <Input label={t('products.details.seasonalRates.seasonName') + ' *'} value={rateSeasonName} onChange={(e) => setRateSeasonName(e.target.value)} placeholder="e.g. Peak Summer" />
                          <Input label={t('products.details.seasonalRates.startDate') + ' *'} type="date" value={rateStartDate} onChange={(e) => setRateStartDate(e.target.value)} />
                          <Input label={t('products.details.seasonalRates.endDate') + ' *'} type="date" value={rateEndDate} onChange={(e) => setRateEndDate(e.target.value)} />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 logical-start">
                          <Input label={t('products.details.seasonalRates.cost') + ' *'} type="number" value={rateCostPrice} onChange={(e) => setRateCostPrice(e.target.value)} />
                          <Input label={t('products.details.seasonalRates.selling') + ' *'} type="number" value={rateSellingPrice} onChange={(e) => setRateSellingPrice(e.target.value)} />
                          <Select label={t('products.details.seasonalRates.currency')} value={rateCurrency} onChange={(e) => setRateCurrency(e.target.value)}>
                            <option value="USD">USD ($)</option>
                            <option value="EUR">EUR (€)</option>
                            <option value="EGP">EGP (E£)</option>
                            <option value="GBP">GBP (£)</option>
                          </Select>
                          <Select label={t('common.status')} value={rateStatus} onChange={(e) => setRateStatus(e.target.value as 'Active' | 'Inactive')}>
                            <option value="Active">{getTranslatedStatus('Active')}</option>
                            <option value="Inactive">{getTranslatedStatus('Inactive')}</option>
                          </Select>
                        </div>
                        <Input label={t('products.details.seasonalRates.notes')} value={rateNotes} onChange={(e) => setRateNotes(e.target.value)} placeholder={t('products.form.notesPlaceholder')} />
                        
                        {Number(rateSellingPrice) < Number(rateCostPrice) && (
                          <div className="flex items-center gap-2 text-xs text-rose-600 font-bold bg-rose-50 dark:bg-rose-950/20 p-2.5 rounded border border-rose-100 dark:border-rose-900/30">
                            <AlertTriangle className="h-4 w-4" />
                            {t('products.details.seasonalRates.warningBelowCost')}
                          </div>
                        )}

                        <div className="flex justify-end rtl:justify-start gap-2 pt-2">
                          <Button type="button" size="sm" variant="outline" onClick={() => setIsRateFormOpen(false)}>{t('common.cancel')}</Button>
                          <Button type="button" size="sm" onClick={addRateRow} disabled={!rateSeasonName.trim() || !rateStartDate || !rateEndDate}>
                            <Save className="h-3.5 w-3.5" /> {t('products.details.seasonalRates.add')}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </FormSection>

              <FormSection title={t('products.form.mediaPlaceholder')}>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-[1fr_auto] logical-start">
                  <Input label={t('products.details.media.mainPlaceholder')} value={form.mediaFileName} onChange={(event) => update('mediaFileName', event.target.value)} />
                  <Button type="button" variant="outline" onClick={() => update('mediaFileName', `mock-upload-${Date.now()}.jpg`)}>{t('products.details.media.mockUpload')}</Button>
                </div>
              </FormSection>
            </div>

            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="logical-start">{t('products.form.reviewSummary')}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm logical-start">
                  <SummaryLine label={t('products.form.name')} value={form.name || 'Untitled'} />
                  <SummaryLine label={t('products.form.category')} value={selectedCategory?.name || '-'} />
                  <SummaryLine label={t('products.form.supplier')} value={selectedSupplier?.name || t('products.status.withoutSupplier')} />
                  <SummaryLine label={t('products.form.destination')} value={form.destination || '-'} />
                  <SummaryLine label={t('products.details.pricing.margin')} value={formatCurrency((Number(form.sellingPrice) || 0) - (Number(form.costPrice) || 0), { currency: 'USD' })} />
                  <span className={`inline-flex rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(selectedSupplier ? form.status : 'Without supplier')}`}>{getTranslatedStatus(selectedSupplier ? form.status : 'Without supplier')}</span>
                </CardContent>
              </Card>
              <div className="flex flex-col gap-2">
                <Button onClick={submit}>{mode === 'add' ? t('products.form.createProduct') : t('products.form.saveChanges')}</Button>
                <Button variant="outline" onClick={onClose}>{t('common.cancel')}</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const FormSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <Card>
    <CardHeader>
      <CardTitle className="logical-start">{title}</CardTitle>
    </CardHeader>
    <CardContent className="logical-start">{children}</CardContent>
  </Card>
);

const SummaryLine: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="flex items-start justify-between gap-3 w-full logical-start">
    <span className="text-gray-500 logical-start">{label}</span>
    <span className="break-words text-right rtl:text-left font-semibold bidi-isolate">{value}</span>
  </div>
);
