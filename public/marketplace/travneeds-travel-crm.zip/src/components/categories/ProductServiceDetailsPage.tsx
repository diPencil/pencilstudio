import React, { useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Link2, MapPin, Package, Unlink, AlertTriangle, Plus, Trash2, Edit, Save, X } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { formatCurrency, formatDate } from '../../utils/format';
import { mockItems, mockProductAvailabilityRules, mockReservations, mockSuppliers } from '../../services/mockData';
import type { ProductAvailabilityRule, ProductServiceItem, ProductSeasonalRate } from '../../types';
import { StatusBadge } from '../ui/StatusBadge';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

const badgeClass = (status: string) => {
  if (status === 'Active' || status === 'Linked' || status === 'Valid' || status === 'Confirmed') return 'bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-950/20 dark:text-emerald-400 dark:border-emerald-900/30';
  if (status === 'Draft' || status === 'Needs review' || status === 'Pending') return 'bg-amber-50 text-amber-700 border-amber-100 dark:bg-amber-950/20 dark:text-amber-400 dark:border-amber-900/30';
  if (status === 'Archived' || status === 'Inactive' || status === 'Without supplier' || status === 'Unlinked') return 'bg-rose-50 text-rose-700 border-rose-100 dark:bg-rose-950/20 dark:text-rose-400 dark:border-rose-900/30';
  return 'bg-gray-50 text-gray-700 border-gray-100 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700';
};

export const ProductServiceDetailsPage: React.FC = () => {
  const { itemId } = useParams<{ itemId: string }>();
  const navigate = useNavigate();
  const { t, direction } = useLocale();

  const initialItem = useMemo(() => mockItems.find(item => item.id === itemId), [itemId]);
  const [item, setItem] = useState<ProductServiceItem | undefined>(initialItem);
  const [supplierId, setSupplierId] = useState(mockSuppliers[0]?.id || '');
  const [availabilityRules, setAvailabilityRules] = useState<ProductAvailabilityRule[]>(() => mockProductAvailabilityRules.filter(rule => rule.itemId === itemId));
  const [availabilityDraft, setAvailabilityDraft] = useState({
    name: '',
    ruleType: 'Allocation',
    startDate: new Date().toISOString().slice(0, 10),
    endDate: new Date().toISOString().slice(0, 10),
    quantity: '1',
    releaseDays: '7',
    status: 'Open'
  });
  const handleUpdateRates = (updatedRates: ProductSeasonalRate[]) => {
    setItem(prev => prev ? { ...prev, seasonalRates: updatedRates } : prev);
  };

  const getTranslatedStatus = (status: string) => {
    if (status === 'Active') return t('products.status.active');
    if (status === 'Draft') return t('products.status.draft');
    if (status === 'Inactive') return t('products.status.inactive');
    if (status === 'Archived') return t('products.status.archived');
    if (status === 'Needs review') return t('products.status.needsReview');
    if (status === 'Without supplier') return t('products.status.withoutSupplier');
    return status;
  };

  const getTranslatedType = (type: string) => {
    if (type === 'Hotel') return t('products.type.hotel');
    if (type === 'Cruise') return t('products.type.cruise');
    if (type === 'Airline') return t('products.type.airline');
    if (type === 'Sightseeing') return t('products.type.sightseeing');
    if (type === 'Transfer') return t('products.type.transfer');
    if (type === 'Activity') return t('products.type.activity');
    return type;
  };

  const getActivityTypeLabel = (type: string) => {
    if (type === 'Created') return t('supplier.profile.activity.type.created');
    if (type === 'Supplier') return t('supplier.tracker.table.supplier');
    if (type === 'Review') return t('supplier.profile.activity.type.review');
    if (type === 'Pricing') return t('supplier.profile.activity.type.pricing');
    if (type === 'Usage') return t('supplier.profile.activity.type.usage');
    if (type === 'Draft') return t('common.draft');
    return type;
  };

  if (!item) {
    return (
      <div className="page-container py-20 text-center">
        <h1 className="text-xl font-bold">{t('products.details.notFound')}</h1>
        <Button className="mt-4" variant="outline" onClick={() => navigate('/product-categories')}>{t('products.details.backToProducts')}</Button>
      </div>
    );
  }

  const supplier = mockSuppliers.find(entry => entry.id === item.supplierId);
  const relatedBookings = mockReservations.filter(reservation =>
    reservation.tripItem?.toLowerCase().includes(item.name.toLowerCase().split(' ')[0])
    || reservation.supplier === item.supplierName
    || reservation.destination?.includes(item.destination)
  );
  const margin = item.sellingPrice - item.costPrice;
  const marginPercent = item.sellingPrice ? Math.round((margin / item.sellingPrice) * 100) : 0;

  const linkSupplier = () => {
    const nextSupplier = mockSuppliers.find(entry => entry.id === supplierId);
    if (!nextSupplier) return;
    setItem(prev => prev ? {
      ...prev,
      supplierId: nextSupplier.id,
      supplierName: nextSupplier.name,
      status: prev.status === 'Without supplier' ? 'Needs review' : prev.status,
      supplierMapping: { supplierId: nextSupplier.id, supplierName: nextSupplier.name, status: 'Linked', lastChecked: new Date().toISOString().slice(0, 10) }
    } : prev);
  };

  const unlinkSupplier = () => {
    setItem(prev => prev ? {
      ...prev,
      supplierId: undefined,
      supplierName: undefined,
      status: 'Without supplier',
      supplierMapping: { status: 'Unlinked' }
    } : prev);
  };

  const addAvailabilityRule = () => {
    if (!item || !availabilityDraft.name.trim() || !availabilityDraft.startDate || !availabilityDraft.endDate) return;
    setAvailabilityRules(prev => [{
      id: `AR-${Date.now()}`,
      itemId: item.id,
      name: availabilityDraft.name.trim(),
      ruleType: availabilityDraft.ruleType,
      startDate: availabilityDraft.startDate,
      endDate: availabilityDraft.endDate,
      quantity: Number(availabilityDraft.quantity) || 0,
      releaseDays: Number(availabilityDraft.releaseDays) || 0,
      status: availabilityDraft.status as ProductAvailabilityRule['status'],
      supplierId: item.supplierId,
      notes: item.availability
    }, ...prev]);
    setAvailabilityDraft(prev => ({ ...prev, name: '', quantity: '1' }));
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
      <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", direction === 'rtl' && "sm:flex-row-reverse")}>
        <div className="min-w-0 logical-start">
          <Button variant="ghost" size="sm" className="mb-3 px-2 text-white hover:bg-white/20 hover:text-white" onClick={() => navigate('/product-categories')}>
            <ArrowLeft className="h-4 w-4 rtl-flip" />
            {t('products.details.backToProducts')}
          </Button>
          <h1 className="break-words text-2xl font-bold">{item.name}</h1>
          <p className="break-words text-sm text-blue-100 opacity-90">{item.category} - {getTranslatedType(item.type)} - {item.destination}</p>
        </div>
        <span className={`w-fit rounded-full border px-3 py-1 text-xs font-bold bg-white/20 text-white border-white/30`}>{getTranslatedStatus(item.status)}</span>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="logical-start">{t('products.details.tabs.overview')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 logical-start">
              <p className="break-words text-sm text-gray-600 dark:text-gray-400">{item.description}</p>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 w-full logical-start">
                <Metric label={t('products.details.overview.availability')} value={item.availability} />
                <Metric label={t('products.details.overview.location')} value={item.location} />
                <Metric label={t('products.details.overview.lastUpdated')} value={formatDate(item.lastUpdated)} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="logical-start">{t('products.details.tabs.pricing')}</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 gap-3 sm:grid-cols-4 logical-start">
              <Metric label={t('products.details.pricing.costPrice')} value={formatCurrency(item.costPrice, { currency: 'USD' })} />
              <Metric label={t('products.details.pricing.sellingPrice')} value={formatCurrency(item.sellingPrice, { currency: 'USD' })} />
              <Metric label={t('products.details.pricing.profit')} value={formatCurrency(margin, { currency: 'USD' })} />
              <Metric label={t('products.details.pricing.margin')} value={`${marginPercent}%`} />
            </CardContent>
          </Card>

          <ProductSeasonalRateMatrix
            itemId={item.id}
            rates={item.seasonalRates || []}
            onUpdateRates={handleUpdateRates}
          />

          <Card>
            <CardHeader>
              <CardTitle className="logical-start">{t('products.details.tabs.attributes')}</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-2 logical-start">
              <Metric label={t('products.details.attributes.duration')} value={item.attributes.duration || '-'} />
              <Metric label={t('products.details.attributes.capacity')} value={item.attributes.capacity || '-'} />
              <Metric label={t('products.details.attributes.roomType')} value={item.attributes.roomType || item.attributes.serviceClass || item.attributes.vehicleType || '-'} />
              <Metric label={t('products.details.attributes.cancellation')} value={item.attributes.cancellationPolicy} />
              <ListBlock title={t('products.details.attributes.inclusions')} values={item.attributes.inclusions} />
              <ListBlock title={t('products.details.attributes.exclusions')} values={item.attributes.exclusions} />
              <Metric label={t('products.details.attributes.bookingNotes')} value={item.attributes.bookingNotes || '-'} />
              <Metric label={t('products.details.attributes.internalNotes')} value={item.attributes.internalNotes || '-'} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="logical-start">{t('products.details.tabs.media')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 logical-start">
              <div className="flex min-h-40 items-center justify-center rounded-lg border border-dashed border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/20 w-full">
                <div className="text-center">
                  <Package className="mx-auto h-8 w-8 text-gray-400" />
                  <div className="mt-2 text-sm font-semibold text-gray-700 dark:text-gray-300">{t('products.details.media.mainPlaceholder')}</div>
                  <div className="text-xs text-gray-500">{t('products.details.media.mockNotice')}</div>
                </div>
              </div>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 w-full logical-start">
                {item.media.map(media => (
                  <div key={media.id} className="rounded border border-gray-100 dark:border-gray-800 p-3 logical-start">
                    <div className="break-words font-medium">{media.fileName}</div>
                    <div className="text-xs text-gray-500">{media.type}</div>
                    <span className={`mt-2 inline-flex rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(media.status)}`}>{getStatusLabel(media.status)}</span>
                  </div>
                ))}
              </div>
              <Button variant="outline" onClick={() => setItem(prev => prev ? {
                ...prev,
                media: [{ id: `MED-${Date.now()}`, fileName: `mock-gallery-${Date.now()}.jpg`, type: 'Gallery image', status: 'Placeholder' }, ...prev.media]
              } : prev)}>{t('products.details.media.mockUpload')}</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="logical-start">{t('products.details.tabs.usage')}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table style={{ direction }} className="w-full min-w-[620px] text-sm">
                  <thead className="bg-gray-50 dark:bg-gray-800 text-[10px] font-bold uppercase tracking-widest text-gray-500 dark:text-gray-400">
                    <tr>
                      <th className="px-3 py-2 logical-start">{t('products.details.usage.booking')}</th>
                      <th className="px-3 py-2 logical-start">{t('products.details.usage.customer')}</th>
                      <th className="px-3 py-2 logical-start">{t('products.details.usage.destination')}</th>
                      <th className="px-3 py-2 logical-start">{t('products.details.usage.supplier')}</th>
                      <th className="px-3 py-2 logical-start">{t('products.details.usage.status')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {relatedBookings.length > 0 ? relatedBookings.map(booking => (
                      <tr key={booking.id} className="border-t border-gray-100 dark:border-gray-800">
                        <td className="px-3 py-2 font-semibold logical-start ltr-value inline-block">{booking.id}</td>
                        <td className="px-3 py-2 logical-start">{booking.customer}</td>
                        <td className="px-3 py-2 logical-start">{booking.destination}</td>
                        <td className="px-3 py-2 logical-start">{booking.supplier}</td>
                        <td className="px-3 py-2 logical-start"><span className={`rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(booking.status)}`}>{getStatusLabel(booking.status)}</span></td>
                      </tr>
                    )) : (
                      <tr><td className="px-3 py-4 text-gray-500 logical-start" colSpan={5}>{t('products.details.usage.noUsage')}</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="logical-start">{t('products.details.tabs.supplierMapping')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 logical-start">
              {supplier ? (
                <div className="logical-start w-full">
                  <button className="font-semibold text-blue-600 hover:underline logical-start" onClick={() => navigate(`/reservations/suppliers/${supplier.id}`)}>
                    {supplier.name}
                  </button>
                  <div className="mt-2 text-sm text-gray-500 logical-start">{supplier.type} - {supplier.location}</div>
                  <span className={`mt-2 inline-flex rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(supplier.status || 'Active')}`}>{getStatusLabel(supplier.status || 'Active')}</span>
                  <Button className="mt-4 w-full" variant="outline" onClick={unlinkSupplier}><Unlink className="h-4 w-4" />{t('products.catalog.unlinkSupplier')}</Button>
                </div>
              ) : (
                <div className="space-y-3 logical-start w-full">
                  <div className={`rounded-lg border p-3 text-sm font-semibold logical-start ${badgeClass('Without supplier')}`}>{t('products.catalog.supplierMissingNotice')}</div>
                  <Select value={supplierId} onChange={(event) => setSupplierId(event.target.value)}>
                    {mockSuppliers.map(entry => <option key={entry.id} value={entry.id}>{entry.name}</option>)}
                  </Select>
                  <Button className="w-full" onClick={linkSupplier}><Link2 className="h-4 w-4" />{t('products.catalog.linkSupplier')}</Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="logical-start">{t('products.details.tabs.availability')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 logical-start">
              <Metric label={t('products.catalog.table.status')} value={getTranslatedStatus(item.status)} />
              <Metric label={t('products.details.availability.rule')} value={item.availability} />
              <Metric label={t('products.details.availability.linkedBookings')} value={item.linkedBookings.toString()} />
              <div className="grid grid-cols-1 gap-2 pt-3">
                <Input label="Rule name" value={availabilityDraft.name} onChange={(event) => setAvailabilityDraft(prev => ({ ...prev, name: event.target.value }))} />
                <Select label="Rule type" value={availabilityDraft.ruleType} onChange={(event) => setAvailabilityDraft(prev => ({ ...prev, ruleType: event.target.value }))}>
                  <option value="Allocation">Allocation</option>
                  <option value="Blackout">Blackout</option>
                  <option value="Release Period">Release Period</option>
                  <option value="On Request">On Request</option>
                </Select>
                <div className="grid grid-cols-2 gap-2">
                  <Input label="Start" type="date" value={availabilityDraft.startDate} onChange={(event) => setAvailabilityDraft(prev => ({ ...prev, startDate: event.target.value }))} />
                  <Input label="End" type="date" value={availabilityDraft.endDate} onChange={(event) => setAvailabilityDraft(prev => ({ ...prev, endDate: event.target.value }))} />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Input label="Quantity" type="number" value={availabilityDraft.quantity} onChange={(event) => setAvailabilityDraft(prev => ({ ...prev, quantity: event.target.value }))} />
                  <Input label="Release days" type="number" value={availabilityDraft.releaseDays} onChange={(event) => setAvailabilityDraft(prev => ({ ...prev, releaseDays: event.target.value }))} />
                </div>
                <Button size="sm" onClick={addAvailabilityRule}><Plus className="h-3.5 w-3.5" /> Add Availability Rule</Button>
              </div>
              <div className="grid grid-cols-2 gap-1 pt-2 sm:grid-cols-3">
                {availabilityRules.map(rule => (
                  <button
                    key={rule.id}
                    onClick={() => setAvailabilityDraft(prev => ({ ...prev, name: rule.name, ruleType: rule.ruleType, startDate: rule.startDate, endDate: rule.endDate, quantity: rule.quantity.toString(), releaseDays: rule.releaseDays.toString(), status: rule.status }))}
                    className={`rounded border p-2 text-xs font-semibold logical-start ${rule.status === 'Open' ? 'border-emerald-100 bg-emerald-50 text-emerald-700' : rule.status === 'Closed' ? 'border-rose-100 bg-rose-50 text-rose-700' : 'border-amber-100 bg-amber-50 text-amber-700'}`}
                  >
                    <div className="truncate">{rule.name}</div>
                    <div className="bidi-isolate">{rule.quantity} / {rule.releaseDays}d</div>
                  </button>
                ))}
              </div>
              <div className="space-y-2 pt-2">
                {availabilityRules.map(rule => (
                  <div key={rule.id} className="rounded border border-gray-100 p-2 text-xs logical-start">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-bold">{rule.name}</div>
                        <div className="text-gray-500 bidi-isolate">{formatDate(rule.startDate)} - {formatDate(rule.endDate)} / {rule.ruleType}</div>
                      </div>
                      <button onClick={() => setAvailabilityRules(prev => prev.filter(entry => entry.id !== rule.id))} className="text-rose-600 hover:underline">{t('common.delete')}</button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="logical-start">{t('products.details.tabs.destinations')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 logical-start">
              {item.destinationCoverage.map(destination => (
                <div key={`${destination.country}-${destination.city}-${destination.destination}`} className="rounded border border-gray-100 dark:border-gray-800 p-3 logical-start">
                  <div className="flex items-center gap-2 font-semibold logical-start"><MapPin className="h-4 w-4" />{destination.destination}</div>
                  <div className="text-xs text-gray-500 logical-start">{destination.city}, {destination.country}</div>
                  <span className={`mt-2 inline-flex rounded-full border px-2 py-0.5 text-[10px] font-bold ${badgeClass(destination.status)}`}>{getTranslatedStatus(destination.status)}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="logical-start">{t('products.details.tabs.activity')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 logical-start">
              {item.activity.map(activity => (
                <div key={activity.id} className="rounded border border-gray-100 dark:border-gray-800 p-3 text-sm logical-start">
                  <div className="font-semibold">{getActivityTypeLabel(activity.type)}</div>
                  <div className="break-words text-xs text-gray-500 logical-start">{activity.message} - <span className="bidi-isolate">{formatDate(activity.date)}</span>{activity.user ? ` - ${activity.user}` : ''}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
      </div>
    </div>
  );
};

const getStatusLabel = (val: string) => {
  if (val === 'Active') return 'Active';
  if (val === 'Inactive') return 'Inactive';
  if (val === 'Valid') return 'Valid';
  if (val === 'Draft') return 'Draft';
  if (val === 'Onboarding') return 'Onboarding';
  if (val === 'Suspended') return 'Suspended';
  if (val === 'Overdue') return 'Overdue';
  return val;
};

interface ProductSeasonalRateMatrixProps {
  itemId: string;
  rates: ProductSeasonalRate[];
  onUpdateRates: (updated: ProductSeasonalRate[]) => void;
}

export const ProductSeasonalRateMatrix: React.FC<ProductSeasonalRateMatrixProps> = ({
  rates,
  onUpdateRates
}) => {
  const { t, direction } = useLocale();
  const [editingRate, setEditingRate] = useState<ProductSeasonalRate | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);

  // Form states
  const [seasonName, setSeasonName] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [costPrice, setCostPrice] = useState('0');
  const [sellingPrice, setSellingPrice] = useState('0');
  const [currency, setCurrency] = useState('USD');
  const [status, setStatus] = useState<'Active' | 'Inactive'>('Active');
  const [notes, setNotes] = useState('');

  const openAddForm = () => {
    setEditingRate(null);
    setSeasonName('');
    setStartDate('');
    setEndDate('');
    setCostPrice('0');
    setSellingPrice('0');
    setCurrency('USD');
    setStatus('Active');
    setNotes('');
    setIsFormOpen(true);
  };

  const openEditForm = (rate: ProductSeasonalRate) => {
    setEditingRate(rate);
    setSeasonName(rate.seasonName);
    setStartDate(rate.startDate);
    setEndDate(rate.endDate);
    setCostPrice(rate.costPrice.toString());
    setSellingPrice(rate.sellingPrice.toString());
    setCurrency(rate.currency);
    setStatus(rate.status);
    setNotes(rate.notes || '');
    setIsFormOpen(true);
  };

  const handleSave = () => {
    if (!seasonName.trim() || !startDate || !endDate) return;

    const newRate: ProductSeasonalRate = {
      id: editingRate ? editingRate.id : `SR-${Date.now()}`,
      seasonName: seasonName.trim(),
      startDate,
      endDate,
      costPrice: Number(costPrice) || 0,
      sellingPrice: Number(sellingPrice) || 0,
      currency,
      status,
      notes: notes.trim() || undefined
    };

    onUpdateRates(editingRate ? rates.map(r => r.id === editingRate.id ? newRate : r) : [...rates, newRate]);
    setIsFormOpen(false);
    setEditingRate(null);
  };

  const handleDelete = (rateId: string) => {
    onUpdateRates(rates.filter(r => r.id !== rateId));
  };

  const isSeasonActive = (start: string, end: string) => {
    const today = new Date().toISOString().split('T')[0];
    return today >= start && today <= end;
  };

  const getTranslatedStatus = (status: string) => {
    if (status === 'Active') return t('products.status.active');
    if (status === 'Inactive') return t('products.status.inactive');
    return status;
  };

  return (
    <Card className="mt-6">
      <CardHeader className="flex flex-row items-center justify-between logical-start">
        <CardTitle>{t('products.details.seasonalRates.title')}</CardTitle>
        {!isFormOpen && (
          <Button size="sm" onClick={openAddForm}>
            <Plus className="h-3.5 w-3.5" /> {t('products.details.seasonalRates.add')}
          </Button>
        )}
      </CardHeader>
      <CardContent className="space-y-4 logical-start">
        {isFormOpen && (
          <Card className="bg-gray-50 dark:bg-gray-800/20 border border-gray-200 dark:border-gray-700 logical-start w-full">
            <CardContent className="p-4 space-y-4 logical-start">
              <div className="flex justify-between items-center pb-2 border-b border-gray-200 dark:border-gray-800 w-full">
                <h5 className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase">{editingRate ? t('products.details.seasonalRates.edit') : t('products.details.seasonalRates.add')}</h5>
                <button onClick={() => setIsFormOpen(false)} className="text-gray-400 hover:text-gray-600">
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 logical-start w-full">
                <Input label={t('products.details.seasonalRates.seasonName') + ' *'} value={seasonName} onChange={(e) => setSeasonName(e.target.value)} placeholder="e.g. Winter High Peak" />
                <Input label={t('products.details.seasonalRates.startDate') + ' *'} type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
                <Input label={t('products.details.seasonalRates.endDate') + ' *'} type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-3 logical-start w-full">
                <Input label={t('products.details.seasonalRates.cost') + ' *'} type="number" value={costPrice} onChange={(e) => setCostPrice(e.target.value)} />
                <Input label={t('products.details.seasonalRates.selling') + ' *'} type="number" value={sellingPrice} onChange={(e) => setSellingPrice(e.target.value)} />
                <Select label={t('products.details.seasonalRates.currency')} value={currency} onChange={(e) => setCurrency(e.target.value)}>
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="EGP">EGP (E£)</option>
                  <option value="GBP">GBP (£)</option>
                </Select>
                <Select label={t('common.status')} value={status} onChange={(e) => setStatus(e.target.value as 'Active' | 'Inactive')}>
                  <option value="Active">{getTranslatedStatus('Active')}</option>
                  <option value="Inactive">{getTranslatedStatus('Inactive')}</option>
                </Select>
              </div>

              <Input label={t('products.details.seasonalRates.notes')} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Surcharges, inclusions, notes..." />

              {Number(sellingPrice) < Number(costPrice) && (
                <div className="flex items-center gap-2 text-xs text-rose-600 font-bold bg-rose-50 dark:bg-rose-950/20 p-2.5 rounded border border-rose-100 dark:border-rose-900/30 w-full logical-start">
                  <AlertTriangle className="h-4 w-4" />
                  {t('products.details.seasonalRates.warningBelowCost')}
                </div>
              )}

              <div className="flex justify-end rtl:justify-start gap-2 pt-2">
                <Button size="sm" variant="outline" onClick={() => setIsFormOpen(false)}>{t('common.cancel')}</Button>
                <Button size="sm" onClick={handleSave} disabled={!seasonName.trim() || !startDate || !endDate}>
                  <Save className="h-3.5 w-3.5" /> {t('products.details.seasonalRates.save')}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {rates.length > 0 ? (
          <div className="overflow-x-auto rounded border border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900 w-full">
            <table style={{ direction }} className="w-full min-w-[840px] text-xs">
              <thead className="bg-gray-50 dark:bg-gray-800 text-gray-500 dark:text-gray-400 uppercase font-bold tracking-wider border-b border-gray-100 dark:border-gray-800">
                <tr>
                  <th className="px-3 py-2 logical-start">{t('products.details.seasonalRates.table.season')}</th>
                  <th className="px-3 py-2 logical-start">{t('products.details.seasonalRates.startDate')}</th>
                  <th className="px-3 py-2 logical-start">{t('products.details.seasonalRates.endDate')}</th>
                  <th className="px-3 py-2 logical-start text-right">{t('products.details.seasonalRates.table.cost')}</th>
                  <th className="px-3 py-2 logical-start text-right">{t('products.details.seasonalRates.table.selling')}</th>
                  <th className="px-3 py-2 logical-start text-right">{t('products.details.seasonalRates.table.margin')}</th>
                  <th className="px-3 py-2 logical-start">{t('products.details.seasonalRates.table.status')}</th>
                  <th className="px-3 py-2 logical-end">{t('products.details.seasonalRates.table.actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {rates.map(rate => {
                  const active = isSeasonActive(rate.startDate, rate.endDate) && rate.status === 'Active';
                  const marginAmt = rate.sellingPrice - rate.costPrice;
                  const marginPct = rate.sellingPrice ? Math.round((marginAmt / rate.sellingPrice) * 100) : 0;
                  const belowCost = rate.sellingPrice < rate.costPrice;

                  return (
                    <tr key={rate.id} className={`hover:bg-gray-50 dark:hover:bg-gray-800/50 ${active ? 'bg-blue-50/30 dark:bg-blue-950/10' : ''}`}>
                      <td className="px-3 py-2 font-medium text-gray-900 dark:text-white logical-start">
                        <div className="flex items-center gap-1.5 logical-start">
                          {rate.seasonName}
                          {active && (
                            <span className="bg-blue-100 text-blue-800 text-[8px] font-bold px-1.5 py-0.5 rounded-full uppercase dark:bg-blue-900/30 dark:text-blue-400">
                              {getTranslatedStatus('Active')}
                            </span>
                          )}
                        </div>
                        {rate.notes && <div className="text-[10px] text-gray-400 dark:text-gray-500 font-normal">{rate.notes}</div>}
                      </td>
                      <td className="px-3 py-2 text-gray-500 dark:text-gray-400 logical-start bidi-isolate">{formatDate(rate.startDate)}</td>
                      <td className="px-3 py-2 text-gray-500 dark:text-gray-400 logical-start bidi-isolate">{formatDate(rate.endDate)}</td>
                      <td className="px-3 py-2 text-gray-900 dark:text-white logical-start font-medium bidi-isolate">{formatCurrency(rate.costPrice, { currency: rate.currency })}</td>
                      <td className={`px-3 py-2 logical-start font-semibold bidi-isolate ${belowCost ? 'text-rose-600 font-bold' : 'text-gray-900 dark:text-white'}`}>
                        <div className="flex justify-end rtl:justify-start items-center gap-1">
                          {belowCost && <AlertTriangle className="h-3 w-3 text-rose-500" title={t('products.details.seasonalRates.warningBelowCost')} />}
                          {formatCurrency(rate.sellingPrice, { currency: rate.currency })}
                        </div>
                      </td>
                      <td className={`px-3 py-2 logical-start font-bold bidi-isolate ${belowCost ? 'text-rose-600' : 'text-emerald-600'}`}>
                        {formatCurrency(marginAmt, { currency: rate.currency })} / {marginPct}%
                      </td>
                      <td className="px-3 py-2 logical-start">
                        <span className={`inline-flex px-1.5 py-0.5 rounded-full text-[9px] font-bold ${
                          rate.status === 'Active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100 dark:bg-emerald-950/20 dark:text-emerald-400 dark:border-emerald-900/30' : 'bg-gray-50 text-gray-500 border border-gray-100 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700'
                        }`}>
                          {getTranslatedStatus(rate.status)}
                        </span>
                      </td>
                      <td className="px-3 py-2 logical-end">
                        <TableActionsDropdown
                          actions={[
                            { label: t('common.edit'), icon: Edit, onClick: () => openEditForm(rate) },
                            { label: t('common.delete'), icon: Trash2, onClick: () => handleDelete(rate.id), variant: 'danger' }
                          ]}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-6 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded text-gray-400 text-xs w-full logical-start">
            {t('products.details.seasonalRates.noRates')}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

const Metric: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="min-w-0 logical-start">
    <div className="text-xs font-bold uppercase tracking-wide text-gray-500">{label}</div>
    <div className="break-words text-sm font-semibold text-gray-900 dark:text-white bidi-isolate">{value}</div>
  </div>
);

const ListBlock: React.FC<{ title: string; values: string[] }> = ({ title, values }) => (
  <div className="logical-start">
    <div className="text-xs font-bold uppercase tracking-wide text-gray-500">{title}</div>
    <ul className="mt-1 space-y-1 text-sm text-gray-700 dark:text-gray-300 logical-start">
      {values.map(value => <li key={value} className="break-words">{value}</li>)}
    </ul>
  </div>
);

export default ProductServiceDetailsPage;
