import React, { useState } from 'react';
import { Save, BarChart3, Trash2, ArrowLeft, Eye, Download } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { Input } from '../ui/Input';
import { Card, CardContent } from '../ui/Card';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { useLocale } from '../../localization/useLocale';

const availableMetrics = [
    'Total Revenue', 'Total Bookings', 'Conversion Rate', 'Average Booking Value',
    'Customer Satisfaction', 'Profit Margin', 'Outstanding Balance', 'Staff Performance',
    'Supplier Performance', 'Payment Status'
];

const availableFilters = [
    'Date Range', 'Category', 'Agent', 'Source', 'Destination',
    'Customer Type', 'Booking Status', 'Payment Status'
];

const chartTypes = ['Bar Chart', 'Line Chart', 'Pie Chart', 'Table', 'Summary Cards'];

const mockSavedReports = [
    { id: 1, name: 'Monthly Sales Deep Dive', criteria: 'Revenue, Bookings', lastRun: '2 days ago' },
    { id: 2, name: 'Agent Performance Q1', criteria: 'Staff, Conversion', lastRun: '1 week ago' },
    { id: 3, name: 'Supplier Cost Analysis', criteria: 'Supplier, Profit', lastRun: '5 mins ago' }
];

export const CustomReportsPage: React.FC = () => {
    const navigate = useNavigate();
    const toast = useToastContext();
    const { isRTL } = useLocale();
    const [reportName, setReportName] = useState('');
    const [selectedMetrics, setSelectedMetrics] = useState<string[]>(['Total Revenue']);
    const [selectedFilters, setSelectedFilters] = useState<string[]>(['Date Range']);
    const [chartType, setChartType] = useState('Bar Chart');
    const [schedule, setSchedule] = useState('manual');

    const handleMetricToggle = (metric: string) => {
        setSelectedMetrics(prev =>
            prev.includes(metric) ? prev.filter(m => m !== metric) : [...prev, metric]
        );
    };

    const handleFilterToggle = (filter: string) => {
        setSelectedFilters(prev =>
            prev.includes(filter) ? prev.filter(f => f !== filter) : [...prev, filter]
        );
    };

    const handleGenerate = () => {
        toast.success('Report Generated', 'Your custom report is being compiled and will be ready shortly.');
    };

  return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => navigate('/reports')}
                            className="inline-flex items-center gap-2 text-blue-100 hover:text-white transition-colors group p-2 hover:bg-white/10 rounded-lg"
                        >
                            <ArrowLeft className={`w-5 h-5 ${isRTL ? "rtl-flip" : ""}`} />
                        </button>
                        <div>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Custom Report Builder</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">Design and generate specialized reports tailored to your data needs</p>
                        </div>
                    </div>
                </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    <Card>
                        <CardContent className="p-6">
                            <div className="space-y-8">
                                <div>
                                    <Input
                                        label="Report Title"
                                        value={reportName}
                                        onChange={(e) => setReportName(e.target.value)}
                                        placeholder="e.g. Quarterly Revenue by Agent"
                                    />
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div>
                                        <label className="block text-sm font-bold text-gray-700 dark:text-gray-200 mb-4">Choose Metrics</label>
                                        <div className={`grid grid-cols-1 gap-2 max-h-60 overflow-y-auto ${isRTL ? 'pl-2' : 'pr-2'} custom-scrollbar`}>
                                            {availableMetrics.map(m => (
                                                <div key={m} className={`flex items-center p-3 rounded-lg border cursor-pointer transition-all ${selectedMetrics.includes(m) ? 'bg-blue-50 border-blue-200 dark:bg-blue-900/20' : 'bg-white border-gray-100 dark:bg-gray-800 dark:border-gray-700'
                                                    }`} onClick={() => handleMetricToggle(m)}>
                                                    <input type="checkbox" checked={selectedMetrics.includes(m)} readOnly className={`${isRTL ? 'ml-3' : 'mr-3'} h-4 w-4 text-blue-600 rounded`} />
                                                    <span className="text-sm font-medium">{m}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-bold text-gray-700 dark:text-gray-200 mb-4">Active Filters</label>
                                        <div className={`grid grid-cols-1 gap-2 max-h-60 overflow-y-auto ${isRTL ? 'pl-2' : 'pr-2'} custom-scrollbar`}>
                                            {availableFilters.map(f => (
                                                <div key={f} className={`flex items-center p-3 rounded-lg border cursor-pointer transition-all ${selectedFilters.includes(f) ? 'bg-purple-50 border-purple-200 dark:bg-purple-900/20' : 'bg-white border-gray-100 dark:bg-gray-800 dark:border-gray-700'
                                                    }`} onClick={() => handleFilterToggle(f)}>
                                                    <input type="checkbox" checked={selectedFilters.includes(f)} readOnly className={`${isRTL ? 'ml-3' : 'mr-3'} h-4 w-4 text-purple-600 rounded`} />
                                                    <span className="text-sm font-medium">{f}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                                    <Select label="Visualization Type" value={chartType} onChange={(e) => setChartType(e.target.value)}>
                                        {chartTypes.map(t => <option key={t} value={t}>{t}</option>)}
                                    </Select>
                                    <Select label="Frequency / Scheduling" value={schedule} onChange={(e) => setSchedule(e.target.value)}>
                                        <option value="manual">Manual Run Only</option>
                                        <option value="daily">Auto: Every Morning</option>
                                        <option value="weekly">Auto: Every Monday</option>
                                        <option value="monthly">Auto: 1st of Month</option>
                                    </Select>
                                </div>

                                <div className="flex justify-end gap-3 pt-8 border-t border-gray-100 dark:border-gray-800">
                                    <Button variant="outline" onClick={() => toast.success('Template Saved', 'Your report template has been saved successfully.')}>
                                        <Save className="h-4 w-4" />
                                        Save Template
                                    </Button>
                                    <Button onClick={handleGenerate}>
                                        <BarChart3 className="h-4 w-4" />
                                        Generate Report
                                    </Button>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <div className="space-y-6">
                    <Card className="bg-purple-50 dark:bg-purple-900/10 border-purple-100 dark:border-purple-900/30 overflow-hidden">
                        <div className="p-4 bg-purple-600 text-white flex items-center justify-between">
                            <h4 className="text-sm font-bold uppercase tracking-wider">Preview Logic</h4>
                            <Eye size={16} />
                        </div>
                        <CardContent className="p-4 space-y-4">
                            <div className="flex items-start justify-between">
                                <span className="text-xs text-purple-700 dark:text-purple-300">Target Metrics:</span>
                                <div className="flex flex-wrap justify-end gap-1">
                                    {selectedMetrics.map(m => <span key={m} className="bg-purple-100 dark:bg-purple-800 text-[9px] px-1.5 py-0.5 rounded font-bold">{m}</span>)}
                                </div>
                            </div>
                            <div className="flex items-start justify-between">
                                <span className="text-xs text-purple-700 dark:text-purple-300">Format:</span>
                                <span className="text-xs font-bold text-purple-900 dark:text-purple-100">{chartType}</span>
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <div className="p-4 border-b border-gray-100 dark:border-gray-700">
                            <h3 className="font-bold text-gray-900 dark:text-white">Recent Templates</h3>
                        </div>
                        <CardContent className="p-0">
                            <div className="divide-y divide-gray-100 dark:divide-gray-700">
                                {mockSavedReports.map(r => (
                                    <div key={r.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center justify-between group">
                                        <div>
                                            <p className="text-sm font-bold text-gray-900 dark:text-white">{r.name}</p>
                                            <p className="text-[10px] text-gray-500 uppercase tracking-tighter">Last run: {r.lastRun}</p>
                                        </div>
                                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                            <button
                                                onClick={() => toast.success('Download Started', `Downloading template: ${r.name}`)}
                                                className="p-1.5 hover:bg-blue-100 dark:hover:bg-blue-900/30 rounded text-blue-600 dark:text-blue-400">
                                                <Download size={14} />
                                            </button>
                                            <button
                                                onClick={() => toast.success('Template Deleted', `${r.name} has been removed.`)}
                                                className="p-1.5 hover:bg-red-100 dark:hover:bg-red-900/30 rounded text-red-600 dark:text-red-400">
                                                <Trash2 size={14} />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
        </div>
    );
};
