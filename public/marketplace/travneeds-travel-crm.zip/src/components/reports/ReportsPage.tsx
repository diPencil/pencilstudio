import React, { useState } from 'react';
import { Download, TrendingUp, Users, DollarSign, Target, Calendar, BarChart3 } from 'lucide-react';
import { PageHeader } from '../ui/PageHeader';
import { Card, CardContent } from '../ui/Card';
import { StatCard } from '../ui/StatCard';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { formatCurrency } from '../../utils/format';
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { useLocale } from '../../localization/useLocale';
import type { TranslationKey } from '../../localization/messages/en';
import { cn } from '../../utils/cn';

interface FunnelStage {
    stageKey: TranslationKey;
    count: number;
    color: string;
    width: string;
}

interface StaffMember {
    nameKey: TranslationKey;
    bookings: number;
    rev: number;
    color: string;
}

interface InventoryItem {
    nameKey: TranslationKey;
    typeKey: TranslationKey;
    perf: number;
    status: string;
}

interface KPIAlert {
    titleKey: TranslationKey;
    descKey: TranslationKey;
    level: string;
}

const revenueData = [
    { month: 'Aug', revenue: 245000, bookings: 156, profit: 61250 },
    { month: 'Sep', revenue: 268000, bookings: 172, profit: 67000 },
    { month: 'Oct', revenue: 252000, bookings: 164, profit: 63000 },
    { month: 'Nov', revenue: 289000, bookings: 185, profit: 72250 },
    { month: 'Dec', revenue: 312000, bookings: 198, profit: 78000 },
    { month: 'Jan', revenue: 284500, bookings: 182, profit: 71125 },
];

const bookingSourceData = [
    { name: 'Website', value: 45, count: 324, color: '#3B82F6' },
    { name: 'Social Media', value: 25, count: 180, color: '#10B981' },
    { name: 'Agent', value: 20, count: 144, color: '#F59E0B' },
    { name: 'Walk-in', value: 10, count: 72, color: '#EF4444' },
];


export const ReportsPage: React.FC = () => {
    const { t, isRTL, direction } = useLocale();
    const [dateRange, setDateRange] = useState('thisMonth');

    const navigate = useNavigate();
    const toast = useToastContext();

    // Map month names in data
    const localizedRevenueData = revenueData.map(item => ({
        ...item,
        month: t(`dashboard.charts.months.${item.month.toLowerCase()}` as TranslationKey)
    }));

    const funnelStages: FunnelStage[] = [
        { stageKey: 'reports.funnel.inquiries', count: 1240, color: 'bg-blue-500', width: '100%' },
        { stageKey: 'reports.funnel.qualified', count: 840, color: 'bg-blue-600', width: '85%' },
        { stageKey: 'reports.funnel.proposals', count: 420, color: 'bg-indigo-600', width: '65%' },
        { stageKey: 'reports.funnel.booked', count: 182, color: 'bg-emerald-600', width: '45%' }
    ];

    const staffMembers: StaffMember[] = [
        { nameKey: 'reports.leaderboard.staff.ahmed', bookings: 42, rev: 124000, color: 'bg-blue-500' },
        { nameKey: 'reports.leaderboard.staff.layla', bookings: 38, rev: 108000, color: 'bg-emerald-500' },
        { nameKey: 'reports.leaderboard.staff.sami', bookings: 31, rev: 92000, color: 'bg-purple-500' }
    ];

    const inventoryItems: InventoryItem[] = [
        { nameKey: 'reports.inventory.item.luxor', typeKey: 'reports.inventory.type.hotel', perf: 92, status: 'Top Performer' },
        { nameKey: 'reports.inventory.item.cairo', typeKey: 'reports.inventory.type.flight', perf: 85, status: 'Stable' },
        { nameKey: 'reports.inventory.item.hurghada', typeKey: 'reports.inventory.type.activity', perf: 78, status: 'Growing' }
    ];

    const kpiAlerts: KPIAlert[] = [
        { titleKey: 'reports.alerts.marginDrop.title', descKey: 'reports.alerts.marginDrop.desc', level: 'Critical' },
        { titleKey: 'reports.alerts.responseTime.title', descKey: 'reports.alerts.responseTime.desc', level: 'Warning' },
        { titleKey: 'reports.alerts.leadLeakage.title', descKey: 'reports.alerts.leadLeakage.desc', level: 'Warning' }
    ];

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
                    <div className={cn(isRTL ? "text-right" : "text-left")}>
                        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                            {t('reports.title')}
                        </h1>
                        <p className="mt-1 text-sm text-blue-100 opacity-90">
                            {t('reports.subtitle')}
                        </p>
                    </div>
                    
                    <div className={cn("flex items-center gap-2 sm:gap-3 banner-actions", isRTL && "flex-row-reverse")}>
                        <Select value={dateRange} onChange={(e) => setDateRange(e.target.value)} className="w-40 text-black !h-11 py-0">
                            <option value="thisMonth">{t('reports.filter.thisMonth')}</option>
                            <option value="lastQuarter">{t('reports.filter.lastQuarter')}</option>
                            <option value="thisYear">{t('reports.filter.thisYear')}</option>
                        </Select>
                        <Button className="bg-white/20 text-white hover:bg-white/30 font-semibold border-none !h-11" onClick={() => toast.success('Export', 'Report data exported successfully.')}>
                            <Download className={cn(isRTL ? "ml-2" : "mr-2", "h-4 w-4")} />
                            {t('reports.actions.export')}
                        </Button>
                        <Button className="bg-white text-blue-600 hover:bg-gray-100 font-semibold border-none !h-11" onClick={() => navigate('/reports/custom')}>
                            <BarChart3 className={cn(isRTL ? "ml-2" : "mr-2", "h-4 w-4")} />
                            {t('reports.actions.newReport')}
                        </Button>
                    </div>
                </div>

            {/* Top Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <StatCard
                    label={t('reports.metrics.monthlyRevenue')}
                    value={formatCurrency(284500)}
                    icon={DollarSign}
                    trend={t('reports.metrics.trend.revenue')}
                    trendType="up"
                    iconColor="text-emerald-500"
                    iconBg="bg-emerald-50 dark:bg-emerald-900/20"
                />

                <StatCard
                    label={t('reports.metrics.activeBookings')}
                    value={182}
                    icon={Calendar}
                    trend={t('reports.metrics.trend.bookings')}
                    trendType="up"
                    iconColor="text-blue-500"
                    iconBg="bg-blue-50 dark:bg-blue-900/20"
                />

                <StatCard
                    label={t('reports.metrics.newCustomers')}
                    value={48}
                    icon={Users}
                    trend={t('reports.metrics.trend.customers')}
                    trendType="up"
                    iconColor="text-purple-500"
                    iconBg="bg-purple-50 dark:bg-purple-900/20"
                />

                <StatCard
                    label={t('reports.metrics.netProfitMargin')}
                    value="24.8%"
                    icon={TrendingUp}
                    trend={t('reports.metrics.trend.margin')}
                    trendType="neutral"
                    iconColor="text-amber-500"
                    iconBg="bg-amber-50 dark:bg-amber-900/20"
                />
            </div>

            {/* Charts & Funnel Row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="card-premium lg:col-span-2">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-6">
                            <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400">{t('reports.charts.revenueProfitTrend')}</h3>
                            <div className="flex items-center gap-4 text-[10px] font-bold">
                                <div className="flex items-center">
                                    <div className={`w-2 h-2 bg-blue-500 rounded-full ${isRTL ? "ml-1" : "mr-1"}`} />
                                    {t('reports.charts.revenue')}
                                </div>
                                <div className="flex items-center">
                                    <div className={`w-2 h-2 bg-emerald-500 rounded-full ${isRTL ? "ml-1" : "mr-1"}`} />
                                    {t('reports.charts.profit')}
                                </div>
                            </div>
                        </div>
                        <div className="h-[300px]">
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={localizedRevenueData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                                    <defs>
                                        <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                                            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                                        </linearGradient>
                                        <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                                            <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                                        </linearGradient>
                                    </defs>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" dark:stroke="#1e293b" />
                                    <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8', fontWeight: 600 }} dy={10} />
                                    <YAxis hide />
                                    <Tooltip
                                        contentStyle={{ 
                                            backgroundColor: 'rgba(255, 255, 255, 0.9)', 
                                            backdropFilter: 'blur(8px)',
                                            borderRadius: '16px', 
                                            border: '1px solid rgba(255,255,255,0.5)', 
                                            boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)' 
                                        }}
                                        labelStyle={{ fontWeight: 800, color: '#1e293b', marginBottom: '8px' }}
                                        itemStyle={{ fontWeight: 600, padding: '4px 0' }}
                                        cursor={{ stroke: '#cbd5e1', strokeWidth: 1, strokeDasharray: '4 4' }}
                                    />
                                    <Area type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={4} fillOpacity={1} fill="url(#colorRevenue)" activeDot={{ r: 6, strokeWidth: 0, fill: '#3b82f6', className: 'drop-shadow-md' }} />
                                    <Area type="monotone" dataKey="profit" stroke="#10b981" strokeWidth={4} fillOpacity={1} fill="url(#colorProfit)" activeDot={{ r: 6, strokeWidth: 0, fill: '#10b981', className: 'drop-shadow-md' }} />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </CardContent>
                </Card>

                <Card className="card-premium">
                    <CardContent className="p-6 text-center">
                        <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-8">{t('reports.funnel.title')}</h3>
                        <div className="space-y-2">
                            {funnelStages.map((s, i) => (
                                <div key={i} className="flex flex-col items-center">
                                    <div className={`h-8 ${s.color} rounded-sm flex items-center justify-center text-white text-[10px] font-bold shadow-sm transition-all hover:brightness-110 bidi-isolate`} style={{ width: s.width }}>
                                        {s.count}
                                    </div>
                                    <p className="text-[9px] font-bold text-gray-500 mt-1 uppercase tracking-tighter">{t(s.stageKey)}</p>
                                </div>
                            ))}
                        </div>
                        <div className="mt-8 pt-4 border-t border-gray-50 dark:border-gray-800">
                            <p className="text-xs font-bold text-gray-900 dark:text-white bidi-isolate">{t('reports.funnel.totalConversion')}</p>
                            <p className="text-[10px] text-emerald-500 font-bold bidi-isolate">{t('reports.funnel.fromLastPeriod')}</p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Bottom Row */}
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                <Card className="card-premium lg:col-span-1">
                    <CardContent className="p-6">
                        <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-6">{t('reports.leaderboard.title')}</h3>
                        <div className="space-y-4">
                            {staffMembers.map((staff, i) => (
                                <div key={i} className="flex items-center justify-between">
                                    <div className="flex items-center">
                                        <div className={`w-8 h-8 rounded-full overflow-hidden flex-shrink-0 border border-gray-200 dark:border-gray-700 ${isRTL ? 'ml-3' : 'mr-3'} shadow-sm`}>
                                            <img src={t(staff.nameKey).toLowerCase().includes('sarah') || t(staff.nameKey).toLowerCase().includes('layla') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
                                        </div>
                                        <div>
                                            <p className="text-xs font-bold text-gray-900 dark:text-white">{t(staff.nameKey)}</p>
                                            <p className="text-[10px] text-gray-500 bidi-isolate">
                                                {t('reports.leaderboard.bookingsCount').replace('{count}', staff.bookings.toString())}
                                            </p>
                                        </div>
                                    </div>
                                    <div className="text-right rtl:text-left">
                                        <p className="text-xs font-bold text-blue-600 bidi-isolate">{formatCurrency(staff.rev, { maximumFractionDigits: 0 })}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                <Card className="card-premium lg:col-span-2">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-6">
                            <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400">{t('reports.inventory.title')}</h3>
                            <Button variant="ghost" size="sm" className="text-[10px] h-auto py-1">{t('reports.inventory.viewDetails')}</Button>
                        </div>
                        <div className="space-y-5">
                            {inventoryItems.map((item, i) => (
                                <div key={i}>
                                    <div className="flex items-center justify-between mb-1">
                                        <div className="flex items-center">
                                            <span className={`text-xs font-bold text-gray-900 dark:text-white ${isRTL ? 'ml-2' : 'mr-2'}`}>{t(item.nameKey)}</span>
                                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-100 text-gray-500 font-bold uppercase">{t(item.typeKey)}</span>
                                        </div>
                                        <span className="text-[10px] font-bold text-blue-600 bidi-isolate">
                                            {t('reports.inventory.demand').replace('{rate}', item.perf.toString())}
                                        </span>
                                    </div>
                                    <div className="w-full bg-gray-100 dark:bg-gray-800 h-1.5 rounded-full overflow-hidden">
                                        <div className="bg-blue-500 h-full rounded-full transition-all" style={{ width: `${item.perf}%` }} />
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                <Card className="card-premium lg:col-span-1">
                    <CardContent className="p-6">
                        <h3 className="text-sm font-bold uppercase tracking-widest mb-6 text-rose-500 flex items-center">
                            <Target className={isRTL ? "h-4 w-4 ml-2" : "h-4 w-4 mr-2"} /> {t('reports.alerts.title')}
                        </h3>
                        <div className="space-y-4">
                            {kpiAlerts.map((alert, i) => (
                                <div key={i} className="p-3 bg-rose-50 dark:bg-rose-900/10 rounded-lg border border-rose-100 dark:border-rose-900/30">
                                    <p className="text-xs font-bold text-rose-600">{t(alert.titleKey)}</p>
                                    <p className="text-[10px] text-gray-600 dark:text-gray-400 mt-1 bidi-isolate">{t(alert.descKey)}</p>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* All report modals replaced by page navigation */}
            </div>
        </div>
    );
};