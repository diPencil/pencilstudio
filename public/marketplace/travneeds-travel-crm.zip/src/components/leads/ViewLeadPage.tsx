import React, { useState } from 'react';
import { Mail, Phone, Building, User, Tag, MessageSquare, ArrowLeft, Edit } from 'lucide-react';
import { useToastContext } from '../../contexts/ToastContext';
import { formatDate } from '../../utils/format';
// removed ScheduleModal
// removed MessageModal - replaced by toast
// removed SendMessageModal
// removed AssignLeadModal
// removed ConvertLeadModal - replaced by page navigation
import { useLocale } from '../../localization/useLocale';
import type { TranslationKey } from '../../localization/messages/en';
import { cn } from '../../utils/cn';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '../ui/Button';
import { Lead } from './LeadsPage';

const mockInteractionHistory = [
  {
    id: 1,
    type: 'status_change',
    description: 'Status changed from "New" to "Contacted"',
    user: 'Super Admin',
    timestamp: '2025-01-15T10:30:00Z',
    details: 'Initial contact made via phone call'
  },
  {
    id: 2,
    type: 'note',
    description: 'Added follow-up note',
    user: 'Super Admin',
    timestamp: '2025-01-15T14:15:00Z',
    details: 'Customer interested in premium package. Scheduled demo for next week.'
  },
  {
    id: 3,
    type: 'staff_change',
    description: 'Assigned to Mahmoud Khalil',
    user: 'Admin',
    timestamp: '2025-01-14T09:00:00Z',
    details: 'Reassigned due to workload balancing'
  }
];

export const ViewLeadPage: React.FC = () => {
  const { t, isRTL } = useLocale();
  const toast = useToastContext();
  const navigate = useNavigate();
  const location = useLocation();

  const lead = location.state?.lead as Lead;

  // all modals replaced by toast/navigation
  const [taskType, setTaskType] = useState<string>('Follow-up Call');

  const getStatusKey = (status: string): TranslationKey => {
    switch (status) {
      case 'New': return 'leads.status.new';
      case 'Contacted': return 'leads.status.contacted';
      case 'Qualified': return 'leads.status.qualified';
      case 'Proposal': return 'leads.status.proposal';
      case 'Negotiation': return 'leads.status.negotiation';
      case 'Closed Won': return 'leads.status.closedWon';
      case 'Closed Lost': return 'leads.status.closedLost';
      default: return 'leads.status.new';
    }
  };

  const getSourceKey = (src: string): TranslationKey => {
    switch (src) {
      case 'Website': return 'leads.source.website';
      case 'Social Media': return 'leads.source.socialMedia';
      case 'Referral': return 'leads.source.referral';
      case 'Email': return 'leads.source.email';
      case 'Walk-in': return 'leads.source.walkIn';
      case 'Cold Call': return 'leads.source.coldCall';
      default: return 'leads.source.website';
    }
  };

  const getTypeKey = (type: string): TranslationKey => {
    return type === 'B2B' ? 'leads.type.b2b' : 'leads.type.b2c';
  };

  const translateInteractionDescription = (desc: string): string => {
    if (isRTL) {
      if (desc.includes('Status changed from')) {
        const matches = desc.match(/Status changed from "([^"]+)" to "([^"]+)"/);
        if (matches) {
          const fromKey = t(getStatusKey(matches[1]));
          const toKey = t(getStatusKey(matches[2]));
          return `تم تغيير الحالة من "${fromKey}" إلى "${toKey}"`;
        }
      }
      if (desc.includes('Added follow-up note')) {
        return 'تم إضافة ملاحظة متابعة';
      }
      if (desc.includes('Assigned to')) {
        const agent = desc.replace('Assigned to ', '');
        return `تم التعيين إلى ${agent}`;
      }
    }
    return desc;
  };

  const translateInteractionDetails = (details: string): string => {
    if (isRTL) {
      if (details === 'Initial contact made via phone call') {
        return 'تم الاتصال الأولي عبر مكالمة هاتفية';
      }
      if (details === 'Customer interested in premium package. Scheduled demo for next week.') {
        return 'العميل مهتم بالباقة المميزة. تم تحديد موعد العرض للأسبوع القادم.';
      }
      if (details === 'Reassigned due to workload balancing') {
        return 'إعادة التعيين بسبب توازن حجم العمل';
      }
    }
    return details;
  };

  const handleAction = (type: string) => {
    switch (type) {
      case 'call':
        setTaskType('Follow-up Call');
        navigate('/sales/schedule', { state: { entity: { id: lead.id, customer: lead.fullName }, entityType: 'Lead' } });
        break;
      case 'schedule':
        navigate('/sales/schedule', { state: { entity: { id: lead.id, customer: lead.fullName }, entityType: 'Lead' } });
        break;
      case 'message':
        toast.success(isRTL ? 'تم إرسال الرسالة' : 'Message Sent', isRTL ? 'تمت العملية بنجاح.' : 'Message sent successfully.');
        break;
      case 'quote':
        navigate('/sales/new-case');
        break;
      case 'reservation':
        navigate('/reservations/new');
        break;
      case 'convert':
        navigate('/leads/convert', { state: { lead } });
        break;
      case 'assign':
        navigate('/leads/assign', { state: { lead } });
        break;
      default:
        console.log('Action:', type);
    }
  };

  const handleSaveTask = async (taskData: { title: string }) => {
    toast.success(
      isRTL ? 'تم جدولة المهمة' : 'Task Scheduled',
      isRTL ? `تم إنشاء المهمة "${taskData.title}" للعميل ${lead?.fullName || lead?.name}.` : `Task "${taskData.title}" has been created for ${lead?.fullName || lead?.name}.`
    );
  };

  const handleSendMessage = async (message: string, type: 'message' | 'note') => {
    toast.success(
      type === 'message' ? (isRTL ? 'تم إرسال الرسالة' : 'Message Sent') : (isRTL ? 'تم إضافة الملاحظة' : 'Note Added'),
      isRTL ? `تم إرسال الإجراء بنجاح للعميل ${lead?.fullName || lead?.name}.` : `Action successfully sent for ${lead?.fullName || lead?.name}.`
    );
  };

  const handleAssign = async (agent: string) => {
    toast.success(
      isRTL ? 'تم تعيين الوكيل' : 'Agent Assigned',
      isRTL ? `تم تعيين العميل المحتمل ${lead?.fullName || lead?.name} إلى ${agent}.` : `${lead?.fullName || lead?.name} is now assigned to ${agent}.`
    );
  };

  const handleSaveQuotation = async (caseData: Record<string, unknown>) => {
    toast.success(
      isRTL ? 'تم إنشاء عرض السعر' : 'Quotation Created',
      isRTL ? `تم إنشاء المعاملة للعميل ${lead?.fullName || lead?.name}.` : `New case created for ${lead?.fullName || lead?.name}.`
    );
    console.log('Quotation details:', caseData);
  };

  const handleSaveReservation = async (reservationData: Record<string, unknown>) => {
    toast.success(
      isRTL ? 'تم إنشاء الحجز' : 'Reservation Created',
      isRTL ? `تم حفظ الحجز للعميل ${lead?.fullName || lead?.name} بنجاح.` : `Reservation for ${lead?.fullName || lead?.name} saved successfully.`
    );
    console.log('Reservation details:', reservationData);
  };

  const handleConvert = async (data: { customerType: string }) => {
    toast.success(
      isRTL ? 'تم تحويل العميل' : 'Lead Converted',
      isRTL ? `تم تحويل ${lead?.fullName || lead?.name} بنجاح إلى ملف عميل (${data.customerType}).` : `${lead?.fullName || lead?.name} has been successfully promoted to a ${data.customerType} Customer File.`
    );
  };

  if (!lead) {
    return (
      <div className="w-full pb-8 pt-8 flex justify-center">
        <Button onClick={() => navigate('/leads')}>{t('common.back') || 'Back to Leads'}</Button>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'New': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      case 'Contacted': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'Qualified': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300';
      case 'Proposal': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'Negotiation': return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300';
      case 'Closed Won': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'Closed Lost': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const getInteractionIcon = (type: string) => {
    switch (type) {
      case 'status_change': return <Tag className="h-4 w-4 text-blue-500" />;
      case 'note': return <MessageSquare className="h-4 w-4 text-green-500" />;
      case 'staff_change': return <User className="h-4 w-4 text-purple-500" />;
      default: return <MessageSquare className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="w-full pb-8" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate('/leads')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-full bg-white/20 overflow-hidden border-2 border-white/20 shadow-inner flex-shrink-0">
                  <img src={(lead.fullName || lead.name || '').toLowerCase().includes('sarah') || (lead.fullName || lead.name || '').toLowerCase().includes('layla') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold">
                  {t('leads.view.title')} - <span className="bidi-isolate">{lead.fullName || lead.name}</span>
                </h1>
              </div>
            </div>
          </div>
          <div className="flex gap-2 mt-4 sm:mt-0">
             <Button
                variant="outline"
                onClick={() => navigate('/leads/edit', { state: { lead } })}
                className="bg-white/10 text-white border-transparent hover:bg-white/20"
              >
                <Edit className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                {t('leads.form.editLead')}
              </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Lead Information */}
            <div className="lg:col-span-2 space-y-6">
            <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] border-0 p-6 sm:p-8">
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">
                {t('leads.view.contactInfo')}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                    <div className="w-12 h-12 rounded-full overflow-hidden shadow-sm flex-shrink-0 border border-gray-200 dark:border-gray-700">
                      <img src={(lead.fullName || lead.name || '').toLowerCase().includes('sarah') || (lead.fullName || lead.name || '').toLowerCase().includes('layla') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
                    </div>
                    <div>
                    <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('leads.form.fullName')}</p>
                    <p className="font-bold text-gray-900 dark:text-white mt-1 bidi-isolate">{lead.fullName || lead.name}</p>
                    </div>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                    <div className="p-3 bg-blue-100 dark:bg-blue-900/20 rounded-full text-blue-600 flex-shrink-0">
                      <Mail className="h-6 w-6" />
                    </div>
                    <div>
                    <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('leads.form.email')}</p>
                    <p className="font-bold text-gray-900 dark:text-white mt-1 bidi-isolate">{lead.email}</p>
                    </div>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                    <div className="p-3 bg-blue-100 dark:bg-blue-900/20 rounded-full text-blue-600 flex-shrink-0">
                       <Phone className="h-6 w-6" />
                    </div>
                    <div>
                    <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('leads.form.phone')}</p>
                    <p className="font-bold text-gray-900 dark:text-white mt-1 bidi-isolate">{lead.phone}</p>
                    </div>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                    <div className="p-3 bg-blue-100 dark:bg-blue-900/20 rounded-full text-blue-600 flex-shrink-0">
                       <Building className="h-6 w-6" />
                    </div>
                    <div>
                    <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('leads.form.company')}</p>
                    <p className="font-bold text-gray-900 dark:text-white mt-1 bidi-isolate">{lead.company || (isRTL ? 'غير متوفر' : 'N/A')}</p>
                    </div>
                </div>
                </div>
            </div>

            <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] border-0 p-6 sm:p-8">
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">
                {t('leads.view.leadDetails')}
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                <div>
                    <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('leads.table.source')}</p>
                    <p className="font-bold text-gray-900 dark:text-white mt-1">{t(getSourceKey(lead.source))}</p>
                </div>
                <div>
                    <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('leads.table.type')}</p>
                    <p className="font-bold text-gray-900 dark:text-white mt-1">{t(getTypeKey(lead.type))}</p>
                </div>
                <div>
                    <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t('leads.form.assignedStaff')}</p>
                    <p className="font-bold text-gray-900 dark:text-white mt-1 bidi-isolate">{lead.agent || lead.staff}</p>
                </div>
                <div>
                    <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">{t('leads.table.status')}</p>
                    <span className={`inline-flex px-3 py-1 text-xs font-bold rounded-full ${getStatusColor(lead.status)}`}>
                    {t(getStatusKey(lead.status))}
                    </span>
                </div>
                <div>
                    <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{isRTL ? 'تاريخ الإضافة' : 'Date Added'}</p>
                    <p className="font-bold text-gray-900 dark:text-white mt-1 bidi-isolate">{formatDate(lead.dateAdded)}</p>
                </div>
                <div>
                    <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{isRTL ? 'آخر متابعة' : 'Last Follow-up'}</p>
                    <p className="font-bold text-gray-900 dark:text-white mt-1">
                    {lead.lastFollowUp ? <span className="bidi-isolate">{formatDate(lead.lastFollowUp)}</span> : t('leads.view.noFollowUp')}
                    </p>
                </div>
                </div>
            </div>

            {lead.notes && (
                <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] border-0 p-6 sm:p-8">
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                    {t('leads.form.notes')}
                </h3>
                <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-2xl">
                    <p className="text-gray-700 dark:text-gray-300 bidi-isolate whitespace-pre-wrap">{lead.notes}</p>
                </div>
                </div>
            )}
            </div>

            {/* Interaction History & Actions */}
            <div className="space-y-6">
            <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] border-0 p-6">
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">
                {t('leads.view.timeline')}
                </h3>
                <div className="space-y-6">
                {mockInteractionHistory.map((interaction, index) => (
                    <div key={interaction.id} className="relative pl-6 rtl:pl-0 rtl:pr-6">
                    {index !== mockInteractionHistory.length - 1 && (
                        <div className="absolute left-[11px] rtl:left-auto rtl:right-[11px] top-6 bottom-[-24px] w-px bg-gray-200 dark:bg-gray-700" />
                    )}
                    <div className="absolute left-0 rtl:left-auto rtl:right-0 top-1">
                        <div className="w-6 h-6 rounded-full bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center">
                           {getInteractionIcon(interaction.type)}
                        </div>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-2xl">
                        <p className="text-sm font-bold text-gray-900 dark:text-white">
                        {translateInteractionDescription(interaction.description)}
                        </p>
                        <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mt-1">
                        {isRTL ? 'بواسطة' : 'by'} <span className="bidi-isolate">{interaction.user}</span> • <span className="bidi-isolate">{formatDate(interaction.timestamp)}</span>
                        </p>
                        {interaction.details && (
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                            {translateInteractionDetails(interaction.details)}
                        </p>
                        )}
                    </div>
                    </div>
                ))}
                </div>
            </div>

            <div className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 rounded-3xl p-6 border border-amber-100/50 dark:border-amber-700/50">
                <h4 className="text-lg font-bold text-amber-900 dark:text-amber-300 mb-4 flex items-center gap-2">
                   {t('leads.view.nextActions')}
                </h4>
                <div className="grid grid-cols-1 gap-2">
                <Button onClick={() => handleAction('call')} variant="outline" className="justify-start border-amber-200 hover:bg-amber-100 hover:text-amber-900 bg-white dark:bg-gray-800">
                    {t('leads.view.scheduleCall')}
                </Button>
                <Button onClick={() => handleAction('message')} variant="outline" className="justify-start border-amber-200 hover:bg-amber-100 hover:text-amber-900 bg-white dark:bg-gray-800">
                    {t('leads.view.sendEmailAction')}
                </Button>
                <Button onClick={() => handleAction('quote')} variant="outline" className="justify-start border-amber-200 hover:bg-amber-100 hover:text-amber-900 bg-white dark:bg-gray-800">
                    {t('leads.view.sendQuotation')}
                </Button>
                <Button onClick={() => handleAction('reservation')} variant="outline" className="justify-start border-amber-200 hover:bg-amber-100 hover:text-amber-900 bg-white dark:bg-gray-800">
                    {t('leads.view.makeReservation')}
                </Button>
                <Button onClick={() => handleAction('convert')} className="justify-start bg-amber-500 hover:bg-amber-600 text-white">
                    {t('leads.view.promoteToCustomer')}
                </Button>
                <Button onClick={() => handleAction('assign')} variant="outline" className="justify-start border-amber-200 hover:bg-amber-100 hover:text-amber-900 bg-white dark:bg-gray-800">
                    {t('leads.view.assignAgentAction')}
                </Button>
                </div>
            </div>
            </div>
        </div>

        {/* All action modals replaced by toast/navigation */}
      </div>
    </div>
  );
};