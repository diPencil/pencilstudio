import React, { useState } from 'react';
import { Save, ArrowLeft, Clock } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { Card, CardContent } from '../ui/Card';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { generateId } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import type { TranslationKey } from '../../localization/messages/en';
import { cn } from '../../utils/cn';

const sources = ['Website', 'Social Media', 'Email', 'Walk-in', 'Referral', 'Cold Call'];
const types = ['B2B', 'B2C'];
const statuses = ['New', 'Contacted', 'Qualified', 'Proposal', 'Negotiation', 'Closed Won', 'Closed Lost'];
const staff = ['Super Admin', 'Mahmoud Khalil', 'Layla Ramadan', 'Sami Youssef', 'Mona Zaki'];

const mockRecentLeads = [
    { name: 'Sarah Ahmed', source: 'Website', type: 'B2C', status: 'New' },
    { name: 'Business Solutions Co', source: 'Referral', type: 'B2B', status: 'Qualified' },
    { name: 'Omar Khaled', source: 'Social Media', type: 'B2C', status: 'Contacted' },
    { name: 'Luxury Travel Ltd', source: 'Email', type: 'B2B', status: 'Proposal' }
];

export const NewLeadPage: React.FC = () => {
    const { t, isRTL } = useLocale();
    const navigate = useNavigate();
    const toast = useToastContext();
    const [formData, setFormData] = useState({
        fullName: '',
        email: '',
        phone: '',
        company: '',
        source: 'Website',
        type: 'B2C',
        staff: 'Super Admin',
        status: 'New',
        notes: ''
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(false);

    const getStatusKey = (status: string): TranslationKey => {
        switch (status) {
            case 'New': return 'leads.status.new';
            case 'Contacted': return 'leads.status.contacted';
            case 'Qualified': return 'leads.status.qualified';
            case 'Proposal': return 'leads.status.proposal';
            case 'Negotiation': return 'leads.status.negotiation';
            case 'Closed Won': return 'leads.status.closedWon';
            case 'Closed Lost': return 'leads.status.closedLost';
            default: return 'leads.status.new';
        }
    };

    const getSourceKey = (src: string): TranslationKey => {
        switch (src) {
            case 'Website': return 'leads.source.website';
            case 'Social Media': return 'leads.source.socialMedia';
            case 'Referral': return 'leads.source.referral';
            case 'Email': return 'leads.source.email';
            case 'Walk-in': return 'leads.source.walkIn';
            case 'Cold Call': return 'leads.source.coldCall';
            default: return 'leads.source.website';
        }
    };

    const getTypeKey = (type: string): TranslationKey => {
        return type === 'B2B' ? 'leads.type.b2b' : 'leads.type.b2c';
    };

    const validateForm = () => {
        const newErrors: Record<string, string> = {};
        if (!formData.fullName.trim()) newErrors.fullName = t('leads.form.validation.fullNameRequired');
        if (!formData.email.trim()) {
            newErrors.email = t('leads.form.validation.emailRequired');
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
            newErrors.email = t('leads.form.validation.emailInvalid');
        }
        if (!formData.phone.trim()) newErrors.phone = t('leads.form.validation.phoneRequired');
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!validateForm()) return;

        setIsLoading(true);
        try {
            // Mock dynamic ID generation
            const leadData = {
                ...formData,
                id: generateId('LD'),
                dateAdded: new Date().toISOString()
            };
            console.log('Saving lead:', leadData);
            toast.success(
                isRTL ? 'تم إنشاء العميل المحتمل' : 'Lead Created',
                isRTL ? 'تمت إضافة العميل المحتمل الجديد بنجاح.' : 'New lead has been added successfully.'
            );
            navigate('/leads');
        } catch {
            toast.error(
                isRTL ? 'خطأ' : 'Error',
                isRTL ? 'فشل في حفظ العميل المحتمل' : 'Failed to save lead'
            );
        } finally {
            setIsLoading(false);
        }
    };

    const handleInputChange = (field: string, value: string) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        if (errors[field]) setErrors(prev => ({ ...prev, [field]: '' }));
    };

  return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => navigate('/leads')}
                            className="inline-flex items-center gap-2 text-blue-100 hover:text-white transition-colors group p-2 hover:bg-white/10 rounded-lg"
                        >
                            <ArrowLeft className={cn("w-5 h-5", isRTL && "rotate-180")} />
                        </button>
                        <div>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">{t('leads.form.addNewLead')}</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">{t('leads.form.subtitle')}</p>
                        </div>
                    </div>
                </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Form Section */}
                <div className="lg:col-span-2">
                    <Card>
                        <CardContent className="p-6">
                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <Input
                                        label={t('leads.form.fullName') + ' *'}
                                        value={formData.fullName}
                                        onChange={(e) => handleInputChange('fullName', e.target.value)}
                                        error={errors.fullName}
                                        placeholder={t('leads.form.fullNamePlaceholder')}
                                    />
                                    <Input
                                        label={t('leads.form.email') + ' *'}
                                        type="email"
                                        value={formData.email}
                                        onChange={(e) => handleInputChange('email', e.target.value)}
                                        error={errors.email}
                                        placeholder={t('leads.form.emailPlaceholder')}
                                    />
                                    <Input
                                        label={t('leads.form.phone') + ' *'}
                                        value={formData.phone}
                                        onChange={(e) => handleInputChange('phone', e.target.value)}
                                        error={errors.phone}
                                        placeholder={t('leads.form.phonePlaceholder')}
                                    />
                                    <Input
                                        label={t('leads.form.company')}
                                        value={formData.company}
                                        onChange={(e) => handleInputChange('company', e.target.value)}
                                        placeholder={t('leads.form.companyPlaceholder')}
                                    />
                                    <Select
                                        label={t('leads.form.source')}
                                        value={formData.source}
                                        onChange={(e) => handleInputChange('source', e.target.value)}
                                    >
                                        {sources.map(source => (
                                            <option key={source} value={source}>{t(getSourceKey(source))}</option>
                                        ))}
                                    </Select>
                                    <Select
                                        label={t('leads.form.type')}
                                        value={formData.type}
                                        onChange={(e) => handleInputChange('type', e.target.value)}
                                    >
                                        {types.map(type => (
                                            <option key={type} value={type}>{t(getTypeKey(type))}</option>
                                        ))}
                                    </Select>
                                    <Select
                                        label={t('leads.form.assignedStaff')}
                                        value={formData.staff}
                                        onChange={(e) => handleInputChange('staff', e.target.value)}
                                    >
                                        {staff.map(member => (
                                            <option key={member} value={member}>{member}</option>
                                        ))}
                                    </Select>
                                    <Select
                                        label={t('leads.form.status')}
                                        value={formData.status}
                                        onChange={(e) => handleInputChange('status', e.target.value)}
                                    >
                                        {statuses.map(status => (
                                            <option key={status} value={status}>{t(getStatusKey(status))}</option>
                                        ))}
                                    </Select>
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                        {t('leads.form.notes')}
                                    </label>
                                    <textarea
                                        value={formData.notes}
                                        onChange={(e) => handleInputChange('notes', e.target.value)}
                                        rows={4}
                                        className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                        placeholder={t('leads.form.notesPlaceholder')}
                                    />
                                </div>

                                <div className="flex justify-end gap-3 pt-6 border-t border-gray-200 dark:border-gray-700">
                                    <Button type="button" variant="outline" onClick={() => navigate('/leads')} disabled={isLoading}>
                                        {t('leads.form.cancel')}
                                    </Button>
                                    <Button type="submit" disabled={isLoading} loading={isLoading}>
                                        <Save className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                                        {t('leads.form.save')}
                                    </Button>
                                </div>
                            </form>
                        </CardContent>
                    </Card>
                </div>

                {/* Sidebar Section */}
                <div className="space-y-6">
                    {/* Stats Card */}
                    <Card className="bg-white dark:bg-gray-800 border-none shadow-sm">
                        <CardContent className="p-6 text-center">
                            <p className="label-xs mb-1">{t('leads.form.totalLeadsToday')}</p>
                            <h2 className="stat-value">24</h2>
                            <div className="h-1 w-12 bg-blue-100 dark:bg-blue-900/30 mx-auto rounded-full mt-4 mb-4"></div>
                            <p className="text-gray-500 dark:text-gray-400 text-xs">{t('leads.form.todayStats')}</p>
                        </CardContent>
                    </Card>

                    {/* Recent Leads */}
                    <Card>
                        <div className="p-4 border-b border-gray-100 dark:border-gray-700">
                            <h2 className="font-semibold text-gray-900 dark:text-white">{t('leads.form.recentLeads')}</h2>
                        </div>
                        <CardContent className="p-0">
                            <div className="divide-y divide-gray-100 dark:divide-gray-700">
                                {mockRecentLeads.map((lead, index) => (
                                    <div key={index} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                                        <div className="flex justify-between items-start mb-1 gap-2">
                                            <h3 className="font-medium text-sm text-gray-900 dark:text-white bidi-isolate">{lead.name}</h3>
                                            <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${lead.status === 'New' ? 'bg-blue-50 text-blue-600' :
                                                lead.status === 'Qualified' ? 'bg-green-50 text-green-600' :
                                                    'bg-yellow-50 text-yellow-600'
                                                }`}>
                                                {t(getStatusKey(lead.status))}
                                            </span>
                                        </div>
                                        <div className="space-y-1">
                                            <p className="text-xs text-gray-500 dark:text-gray-400">
                                                {t(getTypeKey(lead.type))} • {isRTL ? 'المصدر' : 'Source'}: {t(getSourceKey(lead.source))}
                                            </p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="p-2 border-t border-gray-100 dark:border-gray-700">
                                <Button variant="outline" className="w-full text-xs py-1.5 h-auto" onClick={() => navigate('/leads')}>
                                    {t('leads.form.viewAll')}
                                </Button>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Quick Help */}
                    <Card className="bg-indigo-50 dark:bg-indigo-900/10 border-indigo-100 dark:border-indigo-900/30">
                        <CardContent className="p-4">
                            <div className="flex items-center gap-2 text-indigo-900 dark:text-indigo-300 mb-2">
                                <Clock size={16} />
                                <h4 className="text-sm font-semibold">{t('leads.form.fastResponse')}</h4>
                            </div>
                            <p className="text-xs text-indigo-800/80 dark:text-indigo-400/80 leading-relaxed">
                                {t('leads.form.fastResponseDesc')}
                            </p>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
        </div>
    );
};
