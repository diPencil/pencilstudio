import React, { useState, useEffect } from 'react';
import { Save, UserPlus, ArrowLeft } from 'lucide-react';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';

const agents = ['Super Admin', 'Mahmoud Khalil', 'Layla Ramadan', 'Sami Youssef', 'Mona Zaki'];

export const AssignLeadPage: React.FC = () => {
    const { t, isRTL, direction } = useLocale();
    const navigate = useNavigate();
    const location = useLocation();
    const toast = useToastContext();
    const lead = location.state?.lead;

    const [selectedAgent, setSelectedAgent] = useState(lead?.agent || lead?.staff || agents[0]);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        if (!lead) {
            navigate('/leads');
        }
    }, [lead, navigate]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        try {
            await new Promise(resolve => setTimeout(resolve, 500));
            toast.success(
                isRTL ? 'تم التعيين بنجاح' : 'Lead Assigned',
                isRTL ? `تم تحويل العميل إلى ${selectedAgent}` : `Lead routed to ${selectedAgent}`
            );
            navigate('/leads');
        } catch (error) {
            console.error('Error assigning lead:', error);
            toast.error('Error', 'Failed to assign lead');
        } finally {
            setIsLoading(false);
        }
    };

    if (!lead) return null;

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
                    <div className="flex items-center gap-4">
                        <Button variant="outline" onClick={() => navigate('/leads')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                            <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
                        </Button>
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-white/10 rounded-xl">
                                <UserPlus className="h-6 w-6 text-white" />
                            </div>
                            <div>
                                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                                    {t('leads.assign.title')}
                                </h1>
                                <p className="mt-1 text-sm text-blue-100 opacity-90">
                                    {isRTL ? 'توجيه العميل المحتمل لوكيل مبيعات' : 'Route lead to sales agent'}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-8 shadow-sm max-w-2xl mx-auto border border-gray-100 dark:border-gray-800">
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="bg-blue-50 dark:bg-blue-900/10 p-6 rounded-2xl border border-blue-100 dark:border-blue-900/30">
                            <p className="text-sm text-blue-800 dark:text-blue-300 leading-relaxed">
                                {isRTL ? (
                                    <>تغيير تعيين العميل المحتمل <span className="font-bold text-blue-900 dark:text-white bidi-isolate text-base mx-1">{lead.fullName || lead.name}</span> إلى وكيل مبيعات آخر للمتابعة.</>
                                ) : (
                                    <>Assign <span className="font-bold text-blue-900 dark:text-white bidi-isolate text-base mx-1">{lead.fullName || lead.name}</span> to a different agent for follow up.</>
                                )}
                            </p>
                        </div>
                        
                        <div className="space-y-4">
                            <Select
                                label={t('leads.assign.selectAgent')}
                                value={selectedAgent}
                                onChange={(e) => setSelectedAgent(e.target.value)}
                            >
                                {agents.map(agent => (
                                    <option key={agent} value={agent}>{agent}</option>
                                ))}
                            </Select>
                        </div>

                        <div className="flex justify-end gap-3 pt-6 border-t border-gray-100 dark:border-gray-800">
                            <Button type="button" variant="outline" onClick={() => navigate('/leads')} disabled={isLoading}>
                                {t('leads.form.cancel')}
                            </Button>
                            <Button type="submit" disabled={isLoading} loading={isLoading} className="bg-blue-600 hover:bg-blue-700">
                                <Save className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                                {t('leads.assign.route')}
                            </Button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};
