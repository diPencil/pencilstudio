import React, { useState, useEffect } from 'react';
import { Plus, Search, Download, Mail, Eye, Users, TrendingUp, Edit, UserPlus, Target, Zap, AlertTriangle, ArrowRight } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { StatCard } from '../ui/StatCard';
import { StatusBadge } from '../ui/StatusBadge';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
// AddLeadModal replaced by /leads/new navigation
// MessageModal replaced by toast
import { useToastContext } from '../../contexts/ToastContext';
import { mockLeads } from '../../services/mockData';
import { useLocale } from '../../localization/useLocale';
import type { TranslationKey } from '../../localization/messages/en';
import { cn } from '../../utils/cn';
import { formatCurrency } from '../../utils/format';

export interface Lead {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  company: string;
  source: string;
  type: string;
  status: string;
  priority: string;
  staff: string;
  notes: string;
  dateAdded: string;
  lastFollowUp?: string | null;
  agent?: string;
  name?: string;
}

export const LeadsPage: React.FC = () => {
    const { t, isRTL } = useLocale();
    const navigate = useNavigate();
    const [leads, setLeads] = useState<Lead[]>(mockLeads as Lead[]);
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('All Status');
    const [sourceFilter, setSourceFilter] = useState('All Sources');
    const [agentFilter, setAgentFilter] = useState('All Agents');
    const [typeFilter, setTypeFilter] = useState('All Types');
    // modals replaced by navigation
    const [selectedLead, setSelectedLead] = useState<Lead | null>(null);

    const location = useLocation();
    const toast = useToastContext();

    useEffect(() => {
        if (location.state && (location.state as { openModal?: string }).openModal === 'add') {
            navigate('/leads/new');
            window.history.replaceState({}, document.title);
        }
    }, [location.state]);

    const handleAddLead = async (newLead: Omit<Lead, 'id' | 'dateAdded'>) => {
        const leadWithId = {
            ...newLead,
            id: `LD-2025-${(leads.length + 1).toString().padStart(3, '0')}`,
            dateAdded: new Date().toISOString()
        } as Lead;
        setLeads([leadWithId, ...leads]);
        toast.success(
            isRTL ? 'تم إضافة العميل المحتمل' : 'Lead Added',
            isRTL ? 'تمت إضافة عميل محتمل جديد بنجاح إلى القمع.' : 'New lead has been successfully added to the funnel.'
        );
    };

    const getStatusVariant = (status: string): "blue" | "amber" | "emerald" | "purple" | "indigo" | "rose" | "gray" => {
        switch (status) {
            case 'New': return 'blue';
            case 'Contacted': return 'amber';
            case 'Qualified': return 'emerald';
            case 'Proposal': return 'purple';
            case 'Negotiation': return 'indigo';
            case 'Closed Won': return 'emerald';
            case 'Closed Lost': return 'rose';
            default: return 'gray';
        }
    };

    const getStatusKey = (status: string): TranslationKey => {
        switch (status) {
            case 'New': return 'leads.status.new';
            case 'Contacted': return 'leads.status.contacted';
            case 'Qualified': return 'leads.status.qualified';
            case 'Proposal': return 'leads.status.proposal';
            case 'Negotiation': return 'leads.status.negotiation';
            case 'Closed Won': return 'leads.status.closedWon';
            case 'Closed Lost': return 'leads.status.closedLost';
            default: return 'leads.status.new';
        }
    };

    const getPriorityKey = (priority: string): TranslationKey => {
        switch (priority) {
            case 'High': return 'leads.priority.high';
            case 'Medium': return 'leads.priority.medium';
            case 'Low': return 'leads.priority.low';
            default: return 'leads.priority.medium';
        }
    };

    const getSourceKey = (src: string): TranslationKey => {
        switch (src) {
            case 'Website': return 'leads.source.website';
            case 'Social Media': return 'leads.source.socialMedia';
            case 'Referral': return 'leads.source.referral';
            case 'Email': return 'leads.source.email';
            case 'Walk-in': return 'leads.source.walkIn';
            case 'Cold Call': return 'leads.source.coldCall';
            default: return 'leads.source.website';
        }
    };

    const filteredLeads = leads.filter(lead => {
        const matchesSearch = lead.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            lead.email.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = statusFilter === 'All Status' || lead.status === statusFilter;
        const matchesSource = sourceFilter === 'All Sources' || lead.source === sourceFilter;
        const matchesAgent = agentFilter === 'All Agents' || lead.staff === agentFilter;
        const matchesType = typeFilter === 'All Types' || lead.type === typeFilter;
        return matchesSearch && matchesStatus && matchesSource && matchesAgent && matchesType;
    });

    const stats = {
        total: leads.length,
        new: leads.filter(l => l.status === 'New').length,
        qualified: leads.filter(l => l.status === 'Qualified').length,
        conversion: '12.5%'
    };

    return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px]">
                {/* Top Welcome Banner (NeoPay Style) */}
                <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "flex-row-reverse")}>
                    <div className={cn(isRTL ? "text-right" : "text-left")}>
                        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                            {t('leads.title')}
                        </h1>
                        <p className="mt-1 text-sm text-blue-100 opacity-90">
                            {t('leads.subtitle')}
                        </p>
                    </div>
                    
                    <div className={cn("flex items-center gap-2 sm:gap-3 banner-actions", isRTL && "flex-row-reverse")}>
                        <Button variant="outline" className="bg-white/10 text-white border-transparent hover:bg-white/20" onClick={() => navigate('/leads/overdue')}>
                            <AlertTriangle className={isRTL ? "h-4 w-4 ml-2" : "h-4 w-4 mr-2"} />
                            {isRTL ? 'متابعات متأخرة' : 'Overdue'}
                        </Button>
                        <Button variant="outline" className="bg-white/10 text-white border-transparent hover:bg-white/20">
                            <Download className={isRTL ? "h-4 w-4 ml-2" : "h-4 w-4 mr-2"} />
                            {t('leads.export')}
                        </Button>
                        <Button className="bg-white text-blue-600 hover:bg-gray-50" onClick={() => navigate('/leads/new')}>
                            <Plus className={isRTL ? "h-4 w-4 ml-2" : "h-4 w-4 mr-2"} />
                            {t('leads.newLead')}
                        </Button>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <StatCard label={t('leads.stats.total')} value={stats.total} icon={Users} iconColor="text-blue-500" iconBg="bg-blue-50 dark:bg-blue-900/20" />
                    <StatCard label={t('leads.stats.newToday')} value={stats.new} icon={Zap} iconColor="text-emerald-500" iconBg="bg-emerald-50 dark:bg-emerald-900/20" trend={t('leads.stats.trendNew')} trendType="up" />
                    <StatCard label={t('leads.stats.qualified')} value={stats.qualified} icon={Target} iconColor="text-amber-500" iconBg="bg-amber-50 dark:bg-amber-900/20" />
                    <StatCard label={t('leads.stats.conversion')} value={stats.conversion} icon={TrendingUp} iconColor="text-purple-500" iconBg="bg-purple-50 dark:bg-purple-900/20" trend={t('leads.stats.trendStable')} />
                </div>

                <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900 mb-8">
                    <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row items-center gap-4">
                            <div className="flex-1 w-full relative">
                                <Search className={cn("absolute top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400", isRTL ? "right-4" : "left-4")} />
                                <Input
                                    placeholder={t('leads.searchPlaceholder')}
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className={cn("h-12 bg-slate-50 border-0 rounded-2xl font-medium", isRTL ? "pr-12" : "pl-12")}
                                />
                            </div>
                            <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="w-full md:w-40 h-12 bg-slate-50 border-0 rounded-2xl font-medium">
                                <option value="All Status">{t('leads.filter.status')}</option>
                                <option value="New">{t('leads.status.new')}</option>
                                <option value="Contacted">{t('leads.status.contacted')}</option>
                                <option value="Qualified">{t('leads.status.qualified')}</option>
                                <option value="Proposal">{t('leads.status.proposal')}</option>
                                <option value="Negotiation">{t('leads.status.negotiation')}</option>
                                <option value="Closed Won">{t('leads.status.closedWon')}</option>
                                <option value="Closed Lost">{t('leads.status.closedLost')}</option>
                            </Select>
                            <Select value={sourceFilter} onChange={(e) => setSourceFilter(e.target.value)} className="w-full md:w-40 h-12 bg-slate-50 border-0 rounded-2xl font-medium">
                                <option value="All Sources">{t('leads.filter.source')}</option>
                                <option value="Website">{t('leads.source.website')}</option>
                                <option value="Social Media">{t('leads.source.socialMedia')}</option>
                                <option value="Referral">{t('leads.source.referral')}</option>
                                <option value="Email">{t('leads.source.email')}</option>
                                <option value="Walk-in">{t('leads.source.walkIn')}</option>
                                <option value="Cold Call">{t('leads.source.coldCall')}</option>
                            </Select>
                            <Select value={agentFilter} onChange={(e) => setAgentFilter(e.target.value)} className="w-full md:w-40 h-12 bg-slate-50 border-0 rounded-2xl font-medium">
                                <option value="All Agents">{t('leads.filter.agent')}</option>
                                <option value="Super Admin">{t('app.superAdmin')}</option>
                                <option value="Mahmoud Khalil">{isRTL ? 'محمود خليل' : 'Mahmoud Khalil'}</option>
                                <option value="Layla Ramadan">{isRTL ? 'ليلى رمضان' : 'Layla Ramadan'}</option>
                            </Select>
                            <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="w-full md:w-32 h-12 bg-slate-50 border-0 rounded-2xl font-medium">
                                <option value="All Types">{t('leads.filter.type')}</option>
                                <option value="B2B">B2B</option>
                                <option value="B2C">B2C</option>
                            </Select>
                        </div>
                    </CardContent>
                </Card>

                <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900 overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="table-premium w-full text-left border-collapse">
                            <thead>
                                <tr className="bg-slate-50/50 dark:bg-gray-800/50">
                            <th>{t('leads.table.name')}</th>
                            <th>{t('leads.table.contact')}</th>
                            <th>{t('leads.table.source')}</th>
                            <th>{t('leads.table.type')}</th>
                            <th>{t('leads.table.priority')}</th>
                            <th>{t('leads.table.value')}</th>
                            <th>{t('leads.table.status')}</th>
                            <th>{t('leads.table.assigned')}</th>
                            <th className="text-end">{t('leads.table.actions')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredLeads.map((lead) => (
                            <tr key={lead.id}>
                                <td>
                                    <div className="font-bold text-gray-900 dark:text-white">{lead.fullName}</div>
                                    <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest bidi-isolate">{lead.id}</div>
                                </td>
                                <td>
                                    <div className="text-xs font-medium bidi-isolate">{lead.email}</div>
                                    <div className="text-[10px] text-gray-500 bidi-isolate">{lead.phone}</div>
                                </td>
                                <td>
                                    <span className="text-xs font-semibold text-gray-600 dark:text-gray-400">{t(getSourceKey(lead.source))}</span>
                                </td>
                                <td>
                                    <StatusBadge variant={lead.type === 'B2B' ? 'purple' : 'blue'}>{lead.type}</StatusBadge>
                                </td>
                                <td>
                                    <StatusBadge variant={lead.priority === 'High' ? 'rose' : 'blue'}>{t(getPriorityKey(lead.priority || 'Medium'))}</StatusBadge>
                                </td>
                                <td>
                                    <div className="text-xs font-bold text-gray-900 dark:text-white bidi-isolate">{formatCurrency(1200, { maximumFractionDigits: 0 })}</div>
                                </td>
                                <td>
                                    <StatusBadge variant={getStatusVariant(lead.status)}>{t(getStatusKey(lead.status))}</StatusBadge>
                                </td>
                                <td>
                                    <div className="text-xs font-bold text-gray-700 dark:text-gray-300">{lead.staff === 'Super Admin' ? t('app.superAdmin') : lead.staff}</div>
                                </td>
                                <td className="text-end">
                                        <TableActionsDropdown
                                            actions={[
                                                { label: isRTL ? 'عرض التفاصيل' : 'View Details', icon: Eye, onClick: () => navigate('/leads/view', { state: { lead } }) },
                                                { label: isRTL ? 'تعديل' : 'Edit Lead', icon: Edit, onClick: () => navigate('/leads/edit', { state: { lead } }) },
                                                { label: isRTL ? 'إرسال رسالة' : 'Send Message', icon: Mail, onClick: () => { setSelectedLead(lead); toast.success(isRTL ? 'تم إرسال الرسالة' : 'Message Sent', isRTL ? 'تمت العملية بنجاح.' : 'Message sent successfully.'); } },
                                                { label: isRTL ? 'تعيين وكيل' : 'Assign Agent', icon: UserPlus, onClick: () => navigate('/leads/assign', { state: { lead } }) },
                                                { label: isRTL ? 'تحويل لعميل' : 'Convert to Customer', icon: ArrowRight, onClick: () => navigate('/leads/convert', { state: { lead } }) }
                                            ]}
                                        />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                        </table>
                    </div>
                </Card>

            {/* AddLeadModal and MessageModal replaced by navigation/toast */}
        </div>
        </div>
    );
};