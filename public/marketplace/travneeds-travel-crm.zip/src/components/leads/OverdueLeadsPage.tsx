import React, { useState } from 'react';
import { AlertTriangle, Eye, Check, MessageSquare, Calendar, ChevronDown, User, Phone, Mail, Save, Send, ArrowLeft } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { LeadItem } from '../../types';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';

export interface LeadItem {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string | null;
  source: string;
  type: string;
  agent: string;
  status: string;
  dateAdded: string;
  lastFollowUp: string;
  daysSinceLastContact: number;
  priority: string;
  notes: string;
}

const mockOverdueLeads: LeadItem[] = [
  {
    id: 'LD-2025-004',
    name: 'Ahmed Khalil',
    email: 'ahmed.khalil@email.com',
    phone: '+20 123 456 789',
    company: 'Khalil Industries',
    source: 'Website',
    type: 'B2B',
    agent: 'Super Admin',
    status: 'Contacted',
    dateAdded: '2025-01-08',
    lastFollowUp: '2025-01-10',
    daysSinceLastContact: 5,
    priority: 'High',
    notes: 'Interested in premium package, waiting for budget approval'
  },
  {
    id: 'LD-2025-005',
    name: 'Al-Fursan Tech Solutions',
    email: 'contact@alfursan.com',
    phone: '+20 987 654 321',
    company: 'Al-Fursan Tech Solutions',
    source: 'Email',
    type: 'B2B',
    agent: 'Mahmoud Khalil',
    status: 'Qualified',
    dateAdded: '2025-01-05',
    lastFollowUp: '2025-01-07',
    daysSinceLastContact: 8,
    priority: 'Critical',
    notes: 'Hot lead, decision maker confirmed interest'
  },
  {
    id: 'LD-2025-006',
    name: 'Omneya Hussein',
    email: 'omneya@email.com',
    phone: '+20 123 456 789',
    company: null,
    source: 'Social Media',
    type: 'B2C',
    agent: 'Layla Ramadan',
    status: 'Proposal',
    dateAdded: '2025-01-03',
    lastFollowUp: '2025-01-06',
    daysSinceLastContact: 9,
    priority: 'Critical',
    notes: 'Proposal sent, awaiting response'
  },
  {
    id: 'LD-2025-007',
    name: 'Sameh Mahmoud',
    email: 'sameh.mahmoud@email.com',
    phone: '+20 123 456 789',
    company: 'Mahmoud Consulting',
    source: 'Referral',
    type: 'B2B',
    agent: 'Super Admin',
    status: 'Negotiation',
    dateAdded: '2025-01-02',
    lastFollowUp: '2025-01-05',
    daysSinceLastContact: 10,
    priority: 'High',
    notes: 'Price negotiation in progress'
  }
];

const statusOptions = ['New', 'Contacted', 'Qualified', 'Proposal', 'Negotiation', 'Closed Won', 'Closed Lost'];
const priorityOptions = ['Low', 'Medium', 'High', 'Critical'];

export const OverdueLeadsPage: React.FC = () => {
  const { isRTL, direction } = useLocale();
  const navigate = useNavigate();
  const toast = useToastContext();

  const [priorityFilter, setPriorityFilter] = useState('All');
  const [agentFilter, setAgentFilter] = useState('All');
  const [editingStatus, setEditingStatus] = useState<string | null>(null);
  const [editingPriority, setEditingPriority] = useState<string | null>(null);
  const [showActivityLog, setShowActivityLog] = useState<string | null>(null);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'New': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      case 'Contacted': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'Qualified': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300';
      case 'Proposal': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'Negotiation': return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Critical': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      case 'High': return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'Low': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const filteredLeads = mockOverdueLeads.filter(lead => {
    if (priorityFilter !== 'All' && lead.priority !== priorityFilter) return false;
    if (agentFilter !== 'All' && lead.agent !== agentFilter) return false;
    return true;
  });

  const handleStatusUpdate = (leadId: string, newStatus: string) => {
    console.log(`Updating lead ${leadId} status to ${newStatus}`);
    toast.success('Status Updated', 'Lead status changed successfully.');
    setEditingStatus(null);
  };

  const handlePriorityUpdate = (leadId: string, newPriority: string) => {
    console.log(`Updating lead ${leadId} priority to ${newPriority}`);
    toast.success('Priority Updated', 'Lead priority changed successfully.');
    setEditingPriority(null);
  };

  const handleMarkFollowedUp = (leadId: string) => {
    toast.success('Follow-up Logged', 'Lead marked as followed up today.');
  };

  const handleViewLead = (lead: LeadItem) => {
    navigate('/leads/view', { state: { lead: { ...lead, fullName: lead.name } } });
  };

  const handleAddNote = (lead: LeadItem) => {
    navigate('/sales/notes', { state: { entity: lead, entityType: 'Lead' } });
  };

  const handleScheduleReminder = (lead: LeadItem) => {
    navigate('/sales/schedule', { state: { entity: lead, entityType: 'Lead' } });
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate('/leads')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
              <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-xl">
                <AlertTriangle className="h-6 w-6 text-red-200 animate-pulse" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                  Overdue Follow-ups ({filteredLeads.length})
                </h1>
                <p className="mt-1 text-sm text-blue-100 opacity-90">
                  Leads requiring urgent attention
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-8 shadow-sm">
          {/* Alert Banner */}
          <div className="bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/30 rounded-2xl p-6 mb-8">
            <div className="flex items-start sm:items-center gap-4">
              <div className="p-3 bg-red-100 dark:bg-red-900/50 rounded-full flex-shrink-0">
                <AlertTriangle className="h-6 w-6 text-red-600 dark:text-red-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-red-800 dark:text-red-300">
                  Urgent Attention Required
                </h3>
                <p className="text-sm text-red-700 dark:text-red-400 mt-1 leading-relaxed">
                  These leads haven't been contacted for 5+ days and need immediate follow-up to prevent loss. Act quickly to re-engage these prospects.
                </p>
              </div>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-8 bg-gray-50 dark:bg-gray-800/50 p-4 rounded-2xl">
            <Select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
            >
              <option>All Priorities</option>
              <option>Critical</option>
              <option>High</option>
              <option>Medium</option>
              <option>Low</option>
            </Select>
            <Select
              value={agentFilter}
              onChange={(e) => setAgentFilter(e.target.value)}
            >
              <option>All Staff</option>
              <option>Super Admin</option>
              <option>Mahmoud Khalil</option>
              <option>Layla Ramadan</option>
            </Select>
            <div className="text-sm font-bold text-gray-500 dark:text-gray-400 px-2">
              Showing leads not contacted for 5+ days
            </div>
          </div>

          {/* Overdue Leads Table */}
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 dark:bg-gray-800/50">
                  <tr>
                    <th className="px-6 py-4 text-left rtl:text-right text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Lead Info
                    </th>
                    <th className="px-6 py-4 text-left rtl:text-right text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Contact Details
                    </th>
                    <th className="px-6 py-4 text-left rtl:text-right text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Assigned Staff
                    </th>
                    <th className="px-6 py-4 text-left rtl:text-right text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-4 text-left rtl:text-right text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Last Contact
                    </th>
                    <th className="px-6 py-4 text-left rtl:text-right text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Days Overdue
                    </th>
                    <th className="px-6 py-4 text-left rtl:text-right text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Priority
                    </th>
                    <th className="px-6 py-4 text-left rtl:text-right text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                  {filteredLeads.map((lead) => (
                    <tr key={lead.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-800/50 transition-colors">
                      <td className="px-6 py-5 whitespace-nowrap">
                        <div>
                          <button
                            onClick={() => handleViewLead(lead)}
                            className="text-sm font-bold text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
                          >
                            {lead.name}
                          </button>
                          <div className="text-xs text-gray-500 dark:text-gray-400 mt-1 font-medium">
                            {lead.id}
                          </div>
                          {lead.company && (
                            <div className="text-xs font-semibold text-gray-400 mt-1">
                              {lead.company}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm font-medium text-gray-900 dark:text-white">
                            <Mail className="h-3.5 w-3.5 text-gray-400 flex-shrink-0" />
                            <span className="bidi-isolate ltr-value">{lead.email}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm font-medium text-gray-500 dark:text-gray-400">
                            <Phone className="h-3.5 w-3.5 text-gray-400 flex-shrink-0" />
                            <span className="bidi-isolate ltr-value">{lead.phone}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full overflow-hidden shadow-sm flex-shrink-0 border border-gray-200 dark:border-gray-700">
                             <img src={lead.agent.toLowerCase().includes('fatma') || lead.agent.toLowerCase().includes('nour') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
                          </div>
                          <span className="text-sm font-bold text-gray-900 dark:text-white">
                            {lead.agent}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap">
                        {editingStatus === lead.id ? (
                          <select
                            className="text-xs px-3 py-1.5 font-bold rounded-full border border-blue-300 dark:border-blue-600 bg-white dark:bg-gray-800 text-blue-800 dark:text-blue-300 focus:ring-2 focus:ring-blue-500 outline-none"
                            defaultValue={lead.status}
                            onChange={(e) => handleStatusUpdate(lead.id, e.target.value)}
                            onBlur={() => setEditingStatus(null)}
                            autoFocus
                          >
                            {statusOptions.map(status => (
                              <option key={status} value={status}>{status}</option>
                            ))}
                          </select>
                        ) : (
                          <button
                            onClick={() => setEditingStatus(lead.id)}
                            className={`inline-flex items-center px-3 py-1.5 text-xs font-bold rounded-full ${getStatusColor(lead.status)} hover:opacity-80 transition-opacity`}
                          >
                            {lead.status}
                            <ChevronDown className="h-3.5 w-3.5 ml-1.5 opacity-70" />
                          </button>
                        )}
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap text-sm font-bold text-gray-500 dark:text-gray-400">
                        {formatDate(lead.lastFollowUp)}
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap relative">
                        <button
                          onClick={() => setShowActivityLog(showActivityLog === lead.id ? null : lead.id)}
                          className="flex items-center gap-1.5 text-sm font-bold text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300 bg-red-50 dark:bg-red-900/10 px-3 py-1.5 rounded-lg transition-colors"
                        >
                          <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                          <span className="ltr-value bidi-isolate">{lead.daysSinceLastContact}</span> days
                        </button>
                        {showActivityLog === lead.id && (
                          <div className="absolute z-10 mt-3 w-72 bg-white dark:bg-gray-800 rounded-2xl shadow-xl shadow-black/10 border border-gray-100 dark:border-gray-700 p-5 right-0">
                            <h4 className="text-sm font-bold text-gray-900 dark:text-white mb-3 uppercase tracking-wider">Recent Activity</h4>
                            <div className="space-y-3 text-sm text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-900/50 p-3 rounded-xl border border-gray-100 dark:border-gray-800">
                              <div className="flex justify-between"><span className="font-medium">Last contact:</span> <span className="font-bold">{formatDate(lead.lastFollowUp)}</span></div>
                              <div className="flex justify-between"><span className="font-medium">Status:</span> <span className="font-bold">{lead.status}</span></div>
                              <div className="pt-2 border-t border-gray-200 dark:border-gray-700">
                                <span className="font-medium block mb-1">Notes:</span> 
                                <span className="leading-relaxed">{lead.notes}</span>
                              </div>
                            </div>
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap">
                        {editingPriority === lead.id ? (
                          <select
                            className="text-xs px-3 py-1.5 font-bold rounded-full border border-blue-300 dark:border-blue-600 bg-white dark:bg-gray-800 text-blue-800 dark:text-blue-300 focus:ring-2 focus:ring-blue-500 outline-none"
                            defaultValue={lead.priority}
                            onChange={(e) => handlePriorityUpdate(lead.id, e.target.value)}
                            onBlur={() => setEditingPriority(null)}
                            autoFocus
                          >
                            {priorityOptions.map(priority => (
                              <option key={priority} value={priority}>{priority}</option>
                            ))}
                          </select>
                        ) : (
                          <button
                            onClick={() => setEditingPriority(lead.id)}
                            className={`inline-flex items-center px-3 py-1.5 text-xs font-bold rounded-full ${getPriorityColor(lead.priority)} hover:opacity-80 transition-opacity`}
                          >
                            {lead.priority}
                            <ChevronDown className="h-3.5 w-3.5 ml-1.5 opacity-70" />
                          </button>
                        )}
                      </td>
                      <td className="px-6 py-5 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                        <TableActionsDropdown
                          actions={[
                            { label: isRTL ? 'عرض التفاصيل' : 'View Details', icon: Eye, onClick: () => handleViewLead(lead) },
                            { label: isRTL ? 'تمت المتابعة' : 'Mark as Followed-up', icon: Check, onClick: () => handleMarkFollowedUp(lead.id) },
                            { label: isRTL ? 'إضافة ملاحظة' : 'Add Note', icon: MessageSquare, onClick: () => handleAddNote(lead) },
                            { label: isRTL ? 'جدولة تذكير' : 'Schedule Reminder', icon: Calendar, onClick: () => handleScheduleReminder(lead) }
                          ]}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {filteredLeads.length === 0 && (
            <div className="text-center py-16 bg-gray-50 dark:bg-gray-800/30 rounded-2xl border border-dashed border-gray-200 dark:border-gray-700 mt-6">
              <div className="w-20 h-20 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
                <AlertTriangle className="h-10 w-10 text-gray-400" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                No overdue leads found
              </h3>
              <p className="text-gray-500 dark:text-gray-400">
                All leads are up to date with recent follow-ups. Great job!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
