import React, { useState, useEffect } from 'react';
import { Save, UserCheck, ArrowRight, ShieldCheck, ArrowLeft } from 'lucide-react';
import { Button } from '../ui/Button';
import { useLocale } from '../../localization/useLocale';
import type { TranslationKey } from '../../localization/messages/en';
import { cn } from '../../utils/cn';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';

export const ConvertLeadPage: React.FC = () => {
    const { t, isRTL, direction } = useLocale();
    const navigate = useNavigate();
    const location = useLocation();
    const toast = useToastContext();
    const lead = location.state?.lead;

    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        if (!lead) {
            navigate('/leads');
        }
    }, [lead, navigate]);

    const getTypeKey = (type: string): TranslationKey => {
        return type === 'B2B' ? 'leads.type.b2b' : 'leads.type.b2c';
    };

    const handleConvert = async () => {
        setIsLoading(true);
        try {
            await new Promise(resolve => setTimeout(resolve, 500));
            toast.success(
                isRTL ? 'نجاح' : 'Success',
                isRTL ? 'تم تحويل العميل المحتمل بنجاح.' : 'Lead converted successfully.'
            );
            navigate('/customers'); // usually redirects to customers after convert
        } catch (error) {
            console.error('Error converting lead:', error);
            toast.error('Error', 'Failed to convert lead');
        } finally {
            setIsLoading(false);
        }
    };

    if (!lead) return null;

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
                    <div className="flex items-center gap-4">
                        <Button variant="outline" onClick={() => navigate('/leads')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                            <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
                        </Button>
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-white/10 rounded-xl">
                                <UserCheck className="h-6 w-6 text-white" />
                            </div>
                            <div>
                                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                                    {t('leads.convert.title')}
                                </h1>
                                <p className="mt-1 text-sm text-blue-100 opacity-90">
                                    {isRTL ? 'تحويل عميل محتمل إلى دائم' : 'Convert Lead to Customer'}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-10 shadow-sm max-w-3xl mx-auto border border-gray-100 dark:border-gray-800">
                    <div className="flex flex-col items-center justify-center gap-8 mb-10 mt-4 sm:flex-row">
                        <div className="text-center w-full sm:w-1/3">
                            <div className="w-20 h-20 bg-blue-100 dark:bg-blue-900/30 rounded-2xl flex items-center justify-center mx-auto mb-4 border-2 border-blue-500 shadow-sm">
                                <span className="text-blue-600 dark:text-blue-400 font-bold text-3xl">{isRTL ? 'م' : 'L'}</span>
                            </div>
                            <p className="text-lg font-bold text-gray-900 dark:text-white">{isRTL ? 'عميل محتمل' : 'Lead'}</p>
                        </div>

                        <ArrowRight className={cn("h-10 w-10 text-gray-300 animate-pulse hidden sm:block", isRTL && "rotate-180")} />

                        <div className="text-center w-full sm:w-1/3">
                            <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-2xl flex items-center justify-center mx-auto mb-4 border-2 border-green-500 shadow-sm">
                                <ShieldCheck className="h-10 w-10 text-green-600 dark:text-green-400" />
                            </div>
                            <p className="text-lg font-bold text-gray-900 dark:text-white">{isRTL ? 'عميل دائم' : 'Customer'}</p>
                        </div>
                    </div>

                    <div className="bg-gray-50 dark:bg-gray-800/50 rounded-2xl p-6 mb-8 border border-gray-100 dark:border-gray-700">
                        <h3 className="text-md font-bold text-gray-900 dark:text-white mb-4 uppercase tracking-wider">{isRTL ? 'ملخص التحويل' : 'Conversion Summary'}</h3>
                        <ul className="space-y-4 text-sm text-gray-600 dark:text-gray-400">
                            <li className="flex justify-between items-center gap-4 bg-white dark:bg-gray-900 p-3 rounded-lg border border-gray-100 dark:border-gray-800">
                                <span className="font-medium">{t('leads.table.name')}:</span>
                                <span className="font-bold text-gray-900 dark:text-white bidi-isolate text-base">{lead.fullName || lead.name}</span>
                            </li>
                            <li className="flex justify-between items-center gap-4 bg-white dark:bg-gray-900 p-3 rounded-lg border border-gray-100 dark:border-gray-800">
                                <span className="font-medium">{isRTL ? 'الاتصال' : 'Contact'}:</span>
                                <span className="font-bold text-gray-900 dark:text-white bidi-isolate">{lead.email}</span>
                            </li>
                            <li className="flex justify-between items-center gap-4 bg-white dark:bg-gray-900 p-3 rounded-lg border border-gray-100 dark:border-gray-800">
                                <span className="font-medium">{t('leads.table.type')}:</span>
                                <span className="font-bold px-3 py-1 bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 rounded-full text-xs uppercase tracking-wider">
                                    {t(getTypeKey(lead.type))} {isRTL ? '(أفراد/شركات)' : 'Individual/Corp'}
                                </span>
                            </li>
                        </ul>
                    </div>

                    <p className="text-sm text-gray-500 dark:text-gray-400 text-center mb-10 max-w-lg mx-auto leading-relaxed">
                        {isRTL ? 'سيتم نقل جميع السجلات والمستندات الخاصة بهذا العميل المحتمل إلى ملف تعريف عميل دائم جديد. لا يمكن التراجع عن هذه الخطوة.' : 'All history and documents for this lead will be transferred to a new permanent customer profile. This action cannot be undone.'}
                    </p>

                    <div className="flex justify-end gap-4 pt-6 border-t border-gray-100 dark:border-gray-800">
                        <Button type="button" variant="outline" onClick={() => navigate('/leads')} disabled={isLoading} className="px-6">
                            {t('leads.form.cancel')}
                        </Button>
                        <Button onClick={handleConvert} disabled={isLoading} loading={isLoading} className="bg-green-600 hover:bg-green-700 px-8">
                            <Save className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                            {isRTL ? 'إتمام التحويل' : 'Finish Conversion'}
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
};
