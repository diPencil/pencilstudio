import React, { useState } from 'react';
import { X, Send, MessageSquare } from 'lucide-react';
import { Button } from '../ui/Button';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

import { Lead } from './LeadsPage';

interface MessageModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSend: (message: string, type: 'message' | 'note') => Promise<void>;
  lead: Lead;
}

export const MessageModal: React.FC<MessageModalProps> = ({ isOpen, onClose, onSend, lead }) => {
  const { t, isRTL } = useLocale();
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'message' | 'note'>('message');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!message.trim()) {
      return;
    }

    setIsLoading(true);
    try {
      await onSend(message, messageType);
      setMessage('');
      onClose();
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen || !lead) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-lg bg-white dark:bg-gray-800 rounded-lg shadow-xl">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              {t('leads.message.title')} - <span className="bidi-isolate">{lead.fullName || lead.name}</span>
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6">
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {isRTL ? 'نوع الرسالة' : 'Message Type'}
              </label>
              <div className="flex gap-4">
                <label className="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    value="message"
                    checked={messageType === 'message'}
                    onChange={(e) => setMessageType(e.target.value as 'message' | 'note')}
                    className={isRTL ? "ml-2" : "mr-2"}
                  />
                  <span className="text-sm text-gray-700 dark:text-gray-300">{t('leads.message.tabMessage')}</span>
                </label>
                <label className="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    value="note"
                    checked={messageType === 'note'}
                    onChange={(e) => setMessageType(e.target.value as 'message' | 'note')}
                    className={isRTL ? "ml-2" : "mr-2"}
                  />
                  <span className="text-sm text-gray-700 dark:text-gray-300">{t('leads.message.tabNote')}</span>
                </label>
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {messageType === 'message' ? t('leads.message.tabMessage') : t('leads.message.tabNote')}
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={6}
                className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder={messageType === 'message' ? (isRTL ? 'اكتب رسالتك هنا...' : 'Type your message here...') : (isRTL ? 'أضف ملاحظة داخلية...' : 'Add an internal note...')}
                required
              />
            </div>

            {messageType === 'message' && (
              <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <div className="flex items-start gap-3">
                  <MessageSquare className="h-5 w-5 text-blue-500 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-medium text-blue-800 dark:text-blue-300">
                      {t('leads.view.contactInfo')}
                    </h4>
                    <p className="text-sm text-blue-700 dark:text-blue-400 mt-1">
                      {isRTL ? 'البريد الإلكتروني' : 'Email'}: <span className="bidi-isolate">{lead.email}</span>
                    </p>
                    <p className="text-sm text-blue-700 dark:text-blue-400">
                      {isRTL ? 'الهاتف' : 'Phone'}: <span className="bidi-isolate">{lead.phone}</span>
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isLoading}
              >
                {t('leads.form.cancel')}
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                loading={isLoading}
              >
                <Send className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                {messageType === 'message' ? t('leads.message.send') : t('leads.message.log')}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};