import React, { useState, useEffect } from 'react';
import { Save, User, ArrowLeft } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { useLocale } from '../../localization/useLocale';
import type { TranslationKey } from '../../localization/messages/en';
import { cn } from '../../utils/cn';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { Lead } from './LeadsPage';

const sources = ['Website', 'Social Media', 'Email', 'Walk-in', 'Referral', 'Cold Call'];
const types = ['B2B', 'B2C'];
const statuses = ['New', 'Contacted', 'Qualified', 'Proposal', 'Negotiation', 'Closed Won', 'Closed Lost'];
const staff = ['Super Admin', 'Mahmoud Khalil', 'Layla Ramadan', 'Sami Youssef', 'Mona Zaki'];

export const EditLeadPage: React.FC = () => {
  const { t, isRTL } = useLocale();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToastContext();

  const lead = location.state?.lead as Lead;

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    company: '',
    source: 'Website',
    type: 'B2C',
    staff: 'Super Admin',
    status: 'New',
    notes: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (lead) {
      setFormData({
        fullName: lead.fullName || lead.name || '',
        email: lead.email || '',
        phone: lead.phone || '',
        company: lead.company || '',
        source: lead.source || 'Website',
        type: lead.type || 'B2C',
        staff: lead.staff || 'Super Admin',
        status: lead.status || 'New',
        notes: lead.notes || ''
      });
    }
  }, [lead]);

  const getStatusKey = (status: string): TranslationKey => {
    switch (status) {
      case 'New': return 'leads.status.new';
      case 'Contacted': return 'leads.status.contacted';
      case 'Qualified': return 'leads.status.qualified';
      case 'Proposal': return 'leads.status.proposal';
      case 'Negotiation': return 'leads.status.negotiation';
      case 'Closed Won': return 'leads.status.closedWon';
      case 'Closed Lost': return 'leads.status.closedLost';
      default: return 'leads.status.new';
    }
  };

  const getSourceKey = (src: string): TranslationKey => {
    switch (src) {
      case 'Website': return 'leads.source.website';
      case 'Social Media': return 'leads.source.socialMedia';
      case 'Referral': return 'leads.source.referral';
      case 'Email': return 'leads.source.email';
      case 'Walk-in': return 'leads.source.walkIn';
      case 'Cold Call': return 'leads.source.coldCall';
      default: return 'leads.source.website';
    }
  };

  const getTypeKey = (type: string): TranslationKey => {
    return type === 'B2B' ? 'leads.type.b2b' : 'leads.type.b2c';
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = t('leads.form.validation.fullNameRequired');
    }

    if (!formData.email.trim()) {
      newErrors.email = t('leads.form.validation.emailRequired');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = t('leads.form.validation.emailInvalid');
    }

    if (!formData.phone.trim()) {
      newErrors.phone = t('leads.form.validation.phoneRequired');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      toast.success(isRTL ? 'تم التحديث بنجاح' : 'Updated Successfully', isRTL ? 'تم حفظ بيانات العميل المحتمل.' : 'Lead data saved.');
      navigate('/leads');
    } catch (error) {
      console.error('Error updating lead:', error);
      toast.error(isRTL ? 'حدث خطأ' : 'Error', isRTL ? 'فشل تحديث العميل المحتمل.' : 'Failed to update lead.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  if (!lead) {
    return (
      <div className="w-full pb-8 pt-8 flex justify-center">
        <Button onClick={() => navigate('/leads')}>{t('common.back') || 'Back to Leads'}</Button>
      </div>
    );
  }

  return (
    <div className="w-full pb-8" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate('/leads')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-xl">
                  <User className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">
                  {t('leads.form.editLead')} - <span className="bidi-isolate">{lead.fullName || lead.name}</span>
                </h1>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] border-0 overflow-hidden">
          <form onSubmit={handleSubmit} className="p-6 sm:p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label={t('leads.form.fullName') + ' *'}
                value={formData.fullName}
                onChange={(e) => handleInputChange('fullName', e.target.value)}
                error={errors.fullName}
                placeholder={t('leads.form.fullNamePlaceholder')}
                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl"
              />

              <Input
                label={t('leads.form.email') + ' *'}
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                error={errors.email}
                placeholder={t('leads.form.emailPlaceholder')}
                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl"
              />

              <Input
                label={t('leads.form.phone') + ' *'}
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                error={errors.phone}
                placeholder={t('leads.form.phonePlaceholder')}
                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl"
              />

              <Input
                label={t('leads.form.company')}
                value={formData.company}
                onChange={(e) => handleInputChange('company', e.target.value)}
                placeholder={t('leads.form.companyPlaceholder')}
                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl"
              />

              <Select
                label={t('leads.form.source')}
                value={formData.source}
                onChange={(e) => handleInputChange('source', e.target.value)}
                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl h-12"
              >
                {sources.map(source => (
                  <option key={source} value={source}>{t(getSourceKey(source))}</option>
                ))}
              </Select>

              <Select
                label={t('leads.form.type')}
                value={formData.type}
                onChange={(e) => handleInputChange('type', e.target.value)}
                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl h-12"
              >
                {types.map(type => (
                  <option key={type} value={type}>{t(getTypeKey(type))}</option>
                ))}
              </Select>

              <Select
                label={t('leads.form.assignedStaff')}
                value={formData.staff}
                onChange={(e) => handleInputChange('staff', e.target.value)}
                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl h-12"
              >
                {staff.map(member => (
                  <option key={member} value={member}>{member}</option>
                ))}
              </Select>

              <Select
                label={t('leads.form.status')}
                value={formData.status}
                onChange={(e) => handleInputChange('status', e.target.value)}
                className="bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 rounded-2xl h-12"
              >
                {statuses.map(status => (
                  <option key={status} value={status}>{t(getStatusKey(status))}</option>
                ))}
              </Select>
            </div>

            <div className="mt-6">
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                {t('leads.form.notes')}
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                rows={4}
                className="block w-full px-4 py-3 border border-gray-200 dark:border-gray-700 rounded-2xl shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-gray-50 dark:bg-gray-800/50 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                placeholder={t('leads.form.notesPlaceholder')}
              />
            </div>

            <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-gray-100 dark:border-gray-800">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate('/leads')}
                disabled={isLoading}
                className="rounded-xl border-gray-200 dark:border-gray-700"
              >
                {t('leads.form.cancel')}
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                loading={isLoading}
                className="rounded-xl"
              >
                <Save className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                {t('leads.form.save')}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};