import React, { useState } from 'react';
import { X, Save } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { generateId } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import type { TranslationKey } from '../../localization/messages/en';
import { cn } from '../../utils/cn';

import { Lead } from './LeadsPage';

interface AddLeadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (leadData: Lead) => Promise<void>;
}

const sources = ['Website', 'Social Media', 'Email', 'Walk-in', 'Referral', 'Cold Call'];
const types = ['B2B', 'B2C'];
const statuses = ['New', 'Contacted', 'Qualified', 'Proposal', 'Negotiation', 'Closed Won', 'Closed Lost'];
const staff = ['Super Admin', 'Mahmoud Khalil', 'Layla Ramadan', 'Sami Youssef', 'Mona Zaki'];

export const AddLeadModal: React.FC<AddLeadModalProps> = ({ isOpen, onClose, onSave }) => {
  const { t, isRTL } = useLocale();
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    company: '',
    source: 'Website',
    type: 'B2C',
    staff: 'Super Admin',
    status: 'New',
    notes: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  const getStatusKey = (status: string): TranslationKey => {
    switch (status) {
      case 'New': return 'leads.status.new';
      case 'Contacted': return 'leads.status.contacted';
      case 'Qualified': return 'leads.status.qualified';
      case 'Proposal': return 'leads.status.proposal';
      case 'Negotiation': return 'leads.status.negotiation';
      case 'Closed Won': return 'leads.status.closedWon';
      case 'Closed Lost': return 'leads.status.closedLost';
      default: return 'leads.status.new';
    }
  };

  const getSourceKey = (src: string): TranslationKey => {
    switch (src) {
      case 'Website': return 'leads.source.website';
      case 'Social Media': return 'leads.source.socialMedia';
      case 'Referral': return 'leads.source.referral';
      case 'Email': return 'leads.source.email';
      case 'Walk-in': return 'leads.source.walkIn';
      case 'Cold Call': return 'leads.source.coldCall';
      default: return 'leads.source.website';
    }
  };

  const getTypeKey = (type: string): TranslationKey => {
    return type === 'B2B' ? 'leads.type.b2b' : 'leads.type.b2c';
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = t('leads.form.validation.fullNameRequired');
    }

    if (!formData.email.trim()) {
      newErrors.email = t('leads.form.validation.emailRequired');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = t('leads.form.validation.emailInvalid');
    }

    if (!formData.phone.trim()) {
      newErrors.phone = t('leads.form.validation.phoneRequired');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    try {
      const leadData = {
        ...formData,
        id: generateId('LD'),
        dateAdded: new Date().toISOString(),
        lastFollowUp: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      } as Lead;

      await onSave(leadData);

      // Reset form
      setFormData({
        fullName: '',
        email: '',
        phone: '',
        company: '',
        source: 'Website',
        type: 'B2C',
        staff: 'Super Admin',
        status: 'New',
        notes: ''
      });
      setErrors({});
      onClose();
    } catch (error) {
      console.error('Error saving lead:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-2xl bg-white dark:bg-gray-800 rounded-lg shadow-xl">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              {t('leads.form.addNewLead')}
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label={t('leads.form.fullName') + ' *'}
                value={formData.fullName}
                onChange={(e) => handleInputChange('fullName', e.target.value)}
                error={errors.fullName}
                placeholder={t('leads.form.fullNamePlaceholder')}
              />

              <Input
                label={t('leads.form.email') + ' *'}
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                error={errors.email}
                placeholder={t('leads.form.emailPlaceholder')}
              />

              <Input
                label={t('leads.form.phone') + ' *'}
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                error={errors.phone}
                placeholder={t('leads.form.phonePlaceholder')}
              />

              <Input
                label={t('leads.form.company')}
                value={formData.company}
                onChange={(e) => handleInputChange('company', e.target.value)}
                placeholder={t('leads.form.companyPlaceholder')}
              />

              <Select
                label={t('leads.form.source')}
                value={formData.source}
                onChange={(e) => handleInputChange('source', e.target.value)}
              >
                {sources.map(source => (
                  <option key={source} value={source}>{t(getSourceKey(source))}</option>
                ))}
              </Select>

              <Select
                label={t('leads.form.type')}
                value={formData.type}
                onChange={(e) => handleInputChange('type', e.target.value)}
              >
                {types.map(type => (
                  <option key={type} value={type}>{t(getTypeKey(type))}</option>
                ))}
              </Select>

              <Select
                label={t('leads.form.assignedStaff')}
                value={formData.staff}
                onChange={(e) => handleInputChange('staff', e.target.value)}
              >
                {staff.map(member => (
                  <option key={member} value={member}>{member}</option>
                ))}
              </Select>

              <Select
                label={t('leads.form.status')}
                value={formData.status}
                onChange={(e) => handleInputChange('status', e.target.value)}
              >
                {statuses.map(status => (
                  <option key={status} value={status}>{t(getStatusKey(status))}</option>
                ))}
              </Select>
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('leads.form.notes')}
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                rows={4}
                className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder={t('leads.form.notesPlaceholder')}
              />
            </div>

            <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isLoading}
              >
                {t('leads.form.cancel')}
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                loading={isLoading}
              >
                <Save className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                {t('leads.form.save')}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};