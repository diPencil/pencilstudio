import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowRightLeft,
  BarChart3,
  CheckCircle2,
  Clock3,
  Download,
  FolderKanban,
  MessageCircleMore,
  RefreshCcw,
  ShieldAlert,
  Users,
  Zap,
} from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import {
  mockOmnichannelAnalytics,
  mockOmnichannelChannels,
  mockOmnichannelConversations,
  mockOmnichannelDashboardSnapshot,
  mockOmnichannelQueues,
  mockOmnichannelTeamWorkload,
  mockOmnichannelTicketRecords,
} from '../../services/omnichannelMockData';
import { calculateChannelHealth, calculateOmnichannelMetrics } from '../../utils/omnichannelMetrics';
import { getChannelLabel } from '../../utils/omnichannelLinks';
import {
  deriveAgentSnapshots,
  deriveChannelVolume,
  deriveConversionSummary,
  deriveQueueOverview,
  deriveSlaRisks,
} from '../../utils/omnichannelIntegration';
import { OmnichannelModuleShell } from './OmnichannelModuleShell';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import {
  OmnichannelMiniBarList,
  OmnichannelSectionCard,
  OmnichannelStatsGrid,
  type OmnichannelStatItem,
} from './OmnichannelUi';
import {
  OmnichannelDrawer,
  OmnichannelEmptyStateCard,
  OmnichannelErrorBlock,
  OmnichannelLoadingBlock,
  OmnichannelStateNotice,
} from './OmnichannelInteractions';
import { Button } from '../ui/Button';
import { StatusBadge } from '../ui/StatusBadge';
import { onlineStatusLabelKeys } from './inbox/omnichannelInboxLabels';
import type { OmnichannelEscalationAlert, OmnichannelPendingHandoff } from '../../types/omnichannel';
import { cn } from '../../utils/cn';
import { Card, CardContent } from '../ui/Card';

type DashboardDrawerKey =
  | 'open_conversations'
  | 'sla_risks'
  | 'channel_health'
  | 'workload'
  | 'conversion'
  | 'alerts';

type DashboardStateMode = 'ready' | 'loading' | 'empty' | 'error';
type DashboardRange = '7d' | '30d' | '90d';

export const OmnichannelDashboardPage: React.FC = () => {
  const { t, locale, direction } = useLocale();
  const isRTL = direction === 'rtl';
  const navigate = useNavigate();
  const {
    conversations,
    channels,
    metrics,
    queueOverview,
    slaRisks,
    channelVolume,
    agentSnapshots,
    conversionSummary,
  } = useOmnichannelMockStore();
  const [stateMode, setStateMode] = useState<DashboardStateMode>('ready');
  const [range, setRange] = useState<DashboardRange>('30d');
  const [drawer, setDrawer] = useState<DashboardDrawerKey | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [escalations, setEscalations] = useState(mockOmnichannelDashboardSnapshot.escalations);
  const [handoffs, setHandoffs] = useState(mockOmnichannelDashboardSnapshot.pendingHandoffs);

  const localized = (value: { en: string; ar: string }) => (locale === 'ar' ? value.ar : value.en);
  const averageHealthScore = Math.round(
    channels.reduce((sum, channel) => sum + calculateChannelHealth(channel).healthScore, 0) /
      channels.length
  );

  const rangeMultiplier = range === '7d' ? 0.72 : range === '90d' ? 1.24 : 1;

  const scaledValue = (value: number) => Math.max(0, Math.round(value * rangeMultiplier));
  const stats: OmnichannelStatItem[] = [
    {
      id: 'total',
      label: t('omnichannel.dashboard.totalConversations'),
      value: scaledValue(metrics.total),
      icon: MessageCircleMore,
      trend: range === '7d' ? '+4%' : range === '90d' ? '+18%' : '+12%',
      trendType: 'up',
      onClick: () => setDrawer('open_conversations'),
    },
    {
      id: 'open',
      label: t('omnichannel.dashboard.openConversations'),
      value: scaledValue(metrics.open),
      icon: FolderKanban,
      trend: '+4%',
      trendType: 'up',
      onClick: () => navigate('/omnichannel/conversations'),
    },
    {
      id: 'waiting-customer',
      label: t('omnichannel.dashboard.waitingCustomerReplies'),
      value: scaledValue(queueOverview.reduce((sum, item) => sum + item.waitingCustomerCount, 0)),
      icon: ArrowRightLeft,
      trend: '-2%',
      trendType: 'down',
      onClick: () => navigate('/omnichannel/conversations?status=waiting_customer'),
    },
    {
      id: 'waiting-agent',
      label: t('omnichannel.dashboard.waitingAgentReplies'),
      value: scaledValue(queueOverview.reduce((sum, item) => sum + item.waitingAgentCount, 0)),
      icon: Users,
      trend: '+1%',
      trendType: 'up',
      onClick: () => setDrawer('workload'),
    },
    {
      id: 'sla',
      label: t('omnichannel.dashboard.slaBreached'),
      value: scaledValue(metrics.slaBreaches),
      icon: ShieldAlert,
      trend: '-1%',
      trendType: 'down',
      onClick: () => setDrawer('sla_risks'),
    },
    {
      id: 'response',
      label: t('omnichannel.dashboard.averageFirstResponse'),
      value: `${Math.max(6, Math.round(mockOmnichannelAnalytics.averageFirstResponseMinutes * rangeMultiplier))}m`,
      icon: Clock3,
      trend: '-6%',
      trendType: 'down',
    },
    {
      id: 'resolution',
      label: t('omnichannel.dashboard.averageResolution'),
      value: `${(6.4 * rangeMultiplier).toFixed(1)}h`,
      icon: Clock3,
      trend: '-3%',
      trendType: 'down',
    },
    {
      id: 'csat',
      label: t('omnichannel.dashboard.customerSatisfaction'),
      value: `${Math.min(98, Math.round(91 + (range === '90d' ? 2 : 0)))}%`,
      icon: BarChart3,
      trend: '+2%',
      trendType: 'up',
    },
    {
      id: 'health',
      label: t('omnichannel.dashboard.channelHealthScore'),
      value: averageHealthScore,
      icon: AlertTriangle,
      trend: '+5%',
      trendType: 'up',
      onClick: () => setDrawer('channel_health'),
    },
  ];

  const activeDrawerTitle = drawer
    ? t(
        drawer === 'open_conversations'
          ? 'omnichannel.dashboard.drawerOpenConversations'
          : drawer === 'sla_risks'
            ? 'omnichannel.dashboard.drawerSlaRisks'
            : drawer === 'channel_health'
              ? 'omnichannel.dashboard.drawerChannelHealth'
              : drawer === 'workload'
                ? 'omnichannel.dashboard.drawerWorkload'
                : drawer === 'conversion'
                  ? 'omnichannel.dashboard.drawerConversion'
                  : 'omnichannel.dashboard.drawerAlerts'
      )
    : '';

  const activeDrawerDescription = drawer
    ? t(
        drawer === 'open_conversations'
          ? 'omnichannel.dashboard.drawerOpenConversationsDescription'
          : drawer === 'sla_risks'
            ? 'omnichannel.dashboard.drawerSlaRisksDescription'
            : drawer === 'channel_health'
              ? 'omnichannel.dashboard.drawerChannelHealthDescription'
              : drawer === 'workload'
                ? 'omnichannel.dashboard.drawerWorkloadDescription'
                : drawer === 'conversion'
                  ? 'omnichannel.dashboard.drawerConversionDescription'
                  : 'omnichannel.dashboard.drawerAlertsDescription'
      )
    : '';

  const refreshDashboard = async () => {
    setIsRefreshing(true);
    setStateMode('loading');
    await new Promise((resolve) => window.setTimeout(resolve, 650));
    setStateMode('ready');
    setIsRefreshing(false);
  };

  const exportSnapshot = async () => {
    setIsRefreshing(true);
    await new Promise((resolve) => window.setTimeout(resolve, 450));
    setIsRefreshing(false);
  };

  const resolveEscalation = (id: string) => {
    setEscalations((current) => current.filter((item) => item.id !== id));
  };

  const assignEscalation = (id: string) => {
    setEscalations((current) =>
      current.map((item) => (item.id === id ? { ...item, ownerName: t('omnichannel.dashboard.assignedSupervisor') } : item))
    );
  };

  const recentAlertsCount = escalations.length + handoffs.length;

  const renderBody = () => {
    if (stateMode === 'loading') {
      return <OmnichannelLoadingBlock label={t('omnichannel.dashboard.loadingState')} />;
    }

    if (stateMode === 'error') {
      return (
        <OmnichannelErrorBlock
          title={t('omnichannel.dashboard.errorStateTitle')}
          description={t('omnichannel.dashboard.errorStateDescription')}
          action={
            <Button size="sm" onClick={() => setStateMode('ready')}>
              {t('omnichannel.actions.retryMock')}
            </Button>
          }
        />
      );
    }

    if (stateMode === 'empty') {
      return (
        <OmnichannelEmptyStateCard
          title={t('omnichannel.dashboard.emptyStateTitle')}
          description={t('omnichannel.dashboard.emptyStateDescription')}
          action={
            <Button size="sm" onClick={() => setStateMode('ready')}>
              {t('omnichannel.actions.restoreMockData')}
            </Button>
          }
        />
      );
    }

    return (
      <>
        <OmnichannelStatsGrid items={stats} />

        <div className="grid gap-4 xl:grid-cols-[1.5fr_1fr]">
          <OmnichannelSectionCard
            title={t('omnichannel.dashboard.liveQueueOverview')}
            description={t('omnichannel.dashboard.liveQueueOverviewDescription')}
          >
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="text-xs uppercase tracking-wide text-gray-500">
                  <tr>
                    <th className="px-3 py-2 text-start">{t('omnichannel.dashboard.queue')}</th>
                    <th className="px-3 py-2 text-start">{t('omnichannel.dashboard.openConversations')}</th>
                    <th className="px-3 py-2 text-start">{t('omnichannel.dashboard.waitingCustomerReplies')}</th>
                    <th className="px-3 py-2 text-start">{t('omnichannel.dashboard.waitingAgentReplies')}</th>
                    <th className="px-3 py-2 text-start">{t('omnichannel.dashboard.slaBreached')}</th>
                  </tr>
                </thead>
                <tbody>
                  {queueOverview.map((item) => (
                    <tr key={item.queueId} className="border-t border-gray-100 dark:border-gray-800">
                      <td className="px-3 py-3 font-medium text-gray-900 dark:text-white">{item.assignedTeam}</td>
                      <td className="px-3 py-3 bidi-isolate">{scaledValue(item.openCount)}</td>
                      <td className="px-3 py-3 bidi-isolate">{scaledValue(item.waitingCustomerCount)}</td>
                      <td className="px-3 py-3 bidi-isolate">{scaledValue(item.waitingAgentCount)}</td>
                      <td className="px-3 py-3">
                        <button type="button" onClick={() => setDrawer('sla_risks')}>
                          <StatusBadge variant={item.breachedCount > 0 ? 'rose' : 'emerald'}>{scaledValue(item.breachedCount)}</StatusBadge>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </OmnichannelSectionCard>

          <OmnichannelSectionCard
            title={t('omnichannel.dashboard.slaRiskPanel')}
            action={
              <Button size="sm" variant="outline" onClick={() => setDrawer('sla_risks')}>
                {t('omnichannel.actions.viewAll')}
              </Button>
            }
          >
            <div className="space-y-3">
              {slaRisks.map((risk) => (
                <button
                  key={risk.conversationId}
                  type="button"
                  onClick={() => navigate(`/omnichannel/inbox/${risk.conversationId}`)}
                  className="w-full rounded-lg border border-gray-100 p-3 text-start hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-800"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="font-semibold text-gray-900 dark:text-white">{risk.customerName}</div>
                      <div className="mt-1 text-xs text-gray-500">{getChannelLabel(risk.channelType)}</div>
                    </div>
                    <StatusBadge variant={risk.remainingMinutes < 10 ? 'rose' : 'amber'}>{`${risk.remainingMinutes}m`}</StatusBadge>
                  </div>
                </button>
              ))}
            </div>
          </OmnichannelSectionCard>
        </div>

        <div className="grid gap-4 xl:grid-cols-3">
          <OmnichannelSectionCard
            title={t('omnichannel.dashboard.channelVolumeBreakdown')}
            action={
              <Button size="sm" variant="outline" onClick={() => navigate('/omnichannel/channels')}>
                {t('omnichannel.actions.openChannels')}
              </Button>
            }
          >
            <OmnichannelMiniBarList
              items={channelVolume.map((item) => ({
                id: item.channelType,
                label: getChannelLabel(item.channelType),
                value: scaledValue(item.conversations),
                hint: `${scaledValue(item.replies)} ${t('omnichannel.dashboard.replies')}`,
              }))}
            />
          </OmnichannelSectionCard>

          <OmnichannelSectionCard
            title={t('omnichannel.dashboard.agentWorkloadSnapshot')}
            action={
              <Button size="sm" variant="outline" onClick={() => setDrawer('workload')}>
                {t('omnichannel.actions.openWorkload')}
              </Button>
            }
          >
            <div className="space-y-3">
              {agentSnapshots.map((agent) => (
                <button
                  key={agent.staffId}
                  type="button"
                  onClick={() => setDrawer('workload')}
                  className="w-full rounded-lg border border-gray-100 p-3 text-start dark:border-gray-800"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="font-semibold text-gray-900 dark:text-white">{agent.staffName}</div>
                      <div className="text-xs text-gray-500">{agent.teamName}</div>
                    </div>
                    <StatusBadge variant={agent.onlineStatus === 'busy' ? 'amber' : agent.onlineStatus === 'online' ? 'emerald' : 'gray'}>
                      {t(onlineStatusLabelKeys[agent.onlineStatus])}
                    </StatusBadge>
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-gray-500">
                    <div>
                      {t('omnichannel.dashboard.assignedConversations')}:{' '}
                      <span className="bidi-isolate font-semibold text-gray-900 dark:text-white">{agent.assignedConversations}</span>
                    </div>
                    <div>
                      {t('omnichannel.dashboard.activeTickets')}:{' '}
                      <span className="bidi-isolate font-semibold text-gray-900 dark:text-white">{agent.activeTickets}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </OmnichannelSectionCard>

          <OmnichannelSectionCard
            title={t('omnichannel.dashboard.conversionSummary')}
            action={
              <Button size="sm" variant="outline" onClick={() => setDrawer('conversion')}>
                {t('omnichannel.actions.viewBreakdown')}
              </Button>
            }
          >
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-1">
              <SummaryMetric label={t('omnichannel.dashboard.conversationsConvertedToLeads')} value={scaledValue(conversionSummary.leadConversions)} />
              <SummaryMetric label={t('omnichannel.dashboard.customersLinked')} value={scaledValue(conversionSummary.customerLinks)} />
              <SummaryMetric label={t('omnichannel.dashboard.ticketsCreated')} value={scaledValue(conversionSummary.ticketCreations)} />
              <SummaryMetric label={t('omnichannel.dashboard.casesOpened')} value={scaledValue(conversionSummary.caseCreations)} />
            </div>
          </OmnichannelSectionCard>
        </div>

        <div className="grid gap-4 xl:grid-cols-2">
          <OmnichannelSectionCard title={t('omnichannel.dashboard.recentEscalations')}>
            <div className="space-y-3">
              {escalations.map((item) => (
                <EscalationCard
                  key={item.id}
                  item={item}
                  onAssign={() => assignEscalation(item.id)}
                  onResolve={() => resolveEscalation(item.id)}
                  onView={() => navigate(`/omnichannel/inbox/${item.conversationId}`)}
                />
              ))}
              {escalations.length === 0 ? (
                <OmnichannelEmptyStateCard
                  title={t('omnichannel.dashboard.allEscalationsResolved')}
                  description={t('omnichannel.dashboard.allEscalationsResolvedDescription')}
                />
              ) : null}
            </div>
          </OmnichannelSectionCard>

          <OmnichannelSectionCard title={t('omnichannel.dashboard.pendingHandoffs')}>
            <div className="space-y-3">
              {handoffs.map((item) => (
                <div key={item.id} className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                  <div className="font-semibold text-gray-900 dark:text-white ltr-value">{item.conversationId}</div>
                  <div className="mt-1 text-sm text-gray-600 dark:text-gray-300">{`${item.fromTeam} -> ${item.toTeam}`}</div>
                  <div className="mt-1 text-xs text-gray-500">{item.reason}</div>
                </div>
              ))}
            </div>
          </OmnichannelSectionCard>
        </div>
      </>
    );
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "lg:flex-row-reverse")}>
          <div className="flex-1 min-w-0 pr-4 rtl:pr-0 rtl:pl-4">
            <h1 className="text-2xl font-bold">{t('omnichannel.dashboard.title')}</h1>
            <p className="mt-1 text-white/80 truncate">{t('omnichannel.dashboard.subtitle')}</p>
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-1 -mb-1 hide-scrollbar shrink-0">
            <select
              value={range}
              onChange={(event) => setRange(event.target.value as DashboardRange)}
              className="rounded-lg border-0 bg-white/10 px-3 py-2 text-sm text-white focus:ring-2 focus:ring-white/20 [&>option]:text-gray-900"
            >
              <option value="7d">{t('omnichannel.analytics.range7d')}</option>
              <option value="30d">{t('omnichannel.analytics.range30d')}</option>
              <option value="90d">{t('omnichannel.analytics.range90d')}</option>
            </select>
            <Button variant="ghost" loading={isRefreshing} onClick={refreshDashboard} className="bg-white/10 text-white hover:bg-white/20 hover:text-white border-0">
              <RefreshCcw className="h-4 w-4" />
              {t('omnichannel.actions.refreshDashboard')}
            </Button>
            <Button variant="ghost" loading={isRefreshing} onClick={exportSnapshot} className="bg-white/10 text-white hover:bg-white/20 hover:text-white border-0">
              <Download className="h-4 w-4" />
              {t('omnichannel.actions.exportSnapshot')}
            </Button>
            <Button variant="ghost" onClick={() => navigate('/omnichannel/inbox')} className="bg-white text-blue-600 hover:bg-white/90 hover:text-blue-700 border-0">
              {t('omnichannel.dashboard.openInbox')}
            </Button>
          </div>
        </div>
      <div className="space-y-4">
        <OmnichannelStateNotice
          title={t('omnichannel.dashboard.alertSummaryTitle')}
          description={t('omnichannel.dashboard.alertSummaryDescription', { count: recentAlertsCount.toString() })}
          action={
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="ghost" onClick={() => setStateMode('empty')}>
                {t('omnichannel.actions.showEmptyState')}
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setStateMode('error')}>
                {t('omnichannel.actions.showErrorState')}
              </Button>
            </div>
          }
        />
        {renderBody()}
      </div>

      <OmnichannelDrawer
        isOpen={drawer !== null}
        title={activeDrawerTitle}
        description={activeDrawerDescription}
        onClose={() => setDrawer(null)}
        footer={
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setDrawer(null)}>
              {t('common.close')}
            </Button>
            {drawer === 'open_conversations' ? (
              <Button onClick={() => navigate('/omnichannel/conversations')}>{t('omnichannel.actions.openConversationsPage')}</Button>
            ) : null}
          </div>
        }
      >
        {drawer === 'open_conversations' ? (
          <div className="space-y-3">
            {mockOmnichannelConversations
              .filter((item) => item.status !== 'closed')
              .map((conversation) => (
                <button
                  key={conversation.id}
                  type="button"
                  onClick={() => navigate(`/omnichannel/inbox/${conversation.id}`)}
                  className="w-full rounded-lg border border-gray-100 p-3 text-start hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-800"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="font-semibold text-gray-900 dark:text-white">{conversation.customer.name}</div>
                      <div className="mt-1 text-xs text-gray-500 ltr-value">{conversation.id}</div>
                    </div>
                    <StatusBadge variant={conversation.priority === 'urgent' ? 'rose' : conversation.priority === 'high' ? 'amber' : 'blue'}>
                      {t(`omnichannel.priority.${conversation.priority}`)}
                    </StatusBadge>
                  </div>
                </button>
              ))}
          </div>
        ) : null}

        {drawer === 'sla_risks' ? (
          <div className="space-y-3">
            {slaRisks.map((risk) => (
              <div key={risk.conversationId} className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold text-gray-900 dark:text-white">{risk.customerName}</div>
                    <div className="mt-1 text-xs text-gray-500">{getChannelLabel(risk.channelType)}</div>
                  </div>
                  <StatusBadge variant={risk.remainingMinutes < 0 ? 'rose' : 'amber'}>{`${risk.remainingMinutes}m`}</StatusBadge>
                </div>
              </div>
            ))}
          </div>
        ) : null}

        {drawer === 'channel_health' ? (
          <div className="space-y-3">
            {mockOmnichannelChannels.map((channel) => (
              <div key={channel.id} className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold text-gray-900 dark:text-white">{channel.name}</div>
                    <div className="mt-1 text-xs text-gray-500">{channel.health.notes}</div>
                  </div>
                  <StatusBadge variant={channel.health.status === 'critical' ? 'rose' : channel.health.status === 'degraded' ? 'amber' : 'emerald'}>
                    {channel.health.healthScore}
                  </StatusBadge>
                </div>
              </div>
            ))}
          </div>
        ) : null}

        {drawer === 'workload' ? (
          <div className="space-y-3">
            {agentSnapshots.map((agent) => (
              <div key={agent.staffId} className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold text-gray-900 dark:text-white">{agent.staffName}</div>
                    <div className="mt-1 text-xs text-gray-500">{agent.teamName}</div>
                  </div>
                  <StatusBadge variant={agent.workloadPercent >= 80 ? 'amber' : 'emerald'}>{`${agent.workloadPercent}%`}</StatusBadge>
                </div>
              </div>
            ))}
          </div>
        ) : null}

        {drawer === 'conversion' ? (
          <div className="grid gap-3 sm:grid-cols-2">
            <SummaryMetric label={t('omnichannel.dashboard.conversationsConvertedToLeads')} value={conversionSummary.leadConversions} />
            <SummaryMetric label={t('omnichannel.dashboard.customersLinked')} value={conversionSummary.customerLinks} />
            <SummaryMetric label={t('omnichannel.dashboard.ticketsCreated')} value={conversionSummary.ticketCreations} />
            <SummaryMetric label={t('omnichannel.dashboard.casesOpened')} value={conversionSummary.caseCreations} />
          </div>
        ) : null}

        {drawer === 'alerts' ? (
          <div className="space-y-3">
            {escalations.map((item) => (
              <EscalationCard
                key={item.id}
                item={item}
                onAssign={() => assignEscalation(item.id)}
                onResolve={() => resolveEscalation(item.id)}
                onView={() => navigate(`/omnichannel/inbox/${item.conversationId}`)}
              />
            ))}
          </div>
        ) : null}
      </OmnichannelDrawer>
      </div>
    </div>
  );
};

const SummaryMetric: React.FC<{ label: string; value: number }> = ({ label, value }) => (
  <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
    <CardContent className="p-6">
      <div className="relative z-10">
        <div className="text-xs font-bold uppercase tracking-wide text-slate-500 transition-colors group-hover:text-blue-600">{label}</div>
        <div className="mt-3 text-3xl font-bold tracking-tight text-slate-800 dark:text-white bidi-isolate">{value}</div>
      </div>
      <BarChart3 className="absolute ltr:-right-4 rtl:-left-4 -bottom-4 h-24 w-24 text-blue-500/10 group-hover:scale-110 transition-transform duration-300" />
    </CardContent>
  </Card>
);

const EscalationCard: React.FC<{
  item: OmnichannelEscalationAlert;
  onView: () => void;
  onAssign: () => void;
  onResolve: () => void;
}> = ({ item, onView, onAssign, onResolve }) => {
  const { t } = useLocale();

  return (
    <div className="rounded-3xl border-0 bg-white p-5 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_8px_32px_-8px_rgba(37,99,235,0.1)] dark:bg-gray-900">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="font-bold tracking-tight text-slate-800 dark:text-white">{item.title}</div>
          <div className="mt-1 text-xs font-medium text-slate-500">{item.ownerName}</div>
        </div>
        <StatusBadge variant={item.severity === 'critical' ? 'rose' : 'amber'}>{item.severity}</StatusBadge>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <Button size="sm" variant="outline" className="rounded-xl border-slate-200" onClick={onView}>
          {t('omnichannel.actions.view')}
        </Button>
        <Button size="sm" variant="ghost" className="rounded-xl" onClick={onAssign}>
          {t('omnichannel.actions.assign')}
        </Button>
        <Button size="sm" variant="ghost" className="rounded-xl text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50" onClick={onResolve}>
          <CheckCircle2 className="mr-1.5 h-4 w-4" />
          {t('omnichannel.actions.resolve')}
        </Button>
      </div>
    </div>
  );
};
