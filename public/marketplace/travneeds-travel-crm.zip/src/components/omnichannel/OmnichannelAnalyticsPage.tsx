import React, { useMemo, useState } from 'react';
import { BarChart3, Download, Plus } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { OmnichannelDrawer, OmnichannelEmptyStateCard, OmnichannelLoadingBlock } from './OmnichannelInteractions';
import { OmnichannelSectionCard, OmnichannelMiniBarList } from './OmnichannelUi';
import {
  mockOmnichannelAnalytics,
  mockOmnichannelConversations,
  mockOmnichannelReportSchedules,
  mockOmnichannelTeamWorkload,
} from '../../services/omnichannelMockData';
import { Button } from '../ui/Button';
import { getChannelLabel } from '../../utils/omnichannelLinks';
import { useToastContext } from '../../contexts/ToastContext';
import { deriveChannelVolume, deriveConversionSummary } from '../../utils/omnichannelIntegration';
import { cn } from '../../utils/cn';

type AnalyticsDrawer = 'channel' | 'agent' | 'sla' | 'conversion' | 'topics' | null;

export const OmnichannelAnalyticsPage: React.FC = () => {
  const { t, direction } = useLocale();
  const isRTL = direction === 'rtl';
  const toast = useToastContext();
  const {
    channelVolume,
    conversionSummary,
    teamMembers,
  } = useOmnichannelMockStore();
  const [range, setRange] = useState('30d');
  const [channelFilter, setChannelFilter] = useState('');
  const [teamFilter, setTeamFilter] = useState('');
  const [drawer, setDrawer] = useState<AnalyticsDrawer>(null);
  const [loading, setLoading] = useState(false);
  const [schedules, setSchedules] = useState(mockOmnichannelReportSchedules);

  const filteredChannels = useMemo(
    () => channelVolume.filter((summary) => !channelFilter || summary.channelType === channelFilter),
    [channelFilter, channelVolume]
  );

  const filteredAgents = useMemo(
    () => teamMembers.filter((member) => !teamFilter || member.teamName === teamFilter),
    [teamFilter, teamMembers]
  );

  const applyFilterChange = async (updater: () => void) => {
    setLoading(true);
    updater();
    await new Promise((resolve) => window.setTimeout(resolve, 350));
    setLoading(false);
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
          <div>
            <h1 className="text-2xl font-bold">{t('omnichannel.analytics.title')}</h1>
            <p className="text-blue-100 mt-1">{t('omnichannel.analytics.subtitle')}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <select value={range} onChange={(event) => void applyFilterChange(() => setRange(event.target.value))} className="rounded-lg border-0 bg-white/10 text-white px-3 py-2 text-sm [&>option]:text-gray-900 focus:ring-2 focus:ring-white/20 outline-none">
              <option value="7d">{t('omnichannel.analytics.range7d')}</option>
              <option value="30d">{t('omnichannel.analytics.range30d')}</option>
              <option value="90d">{t('omnichannel.analytics.range90d')}</option>
            </select>
            <Button className="bg-white/10 text-white hover:bg-white/20 border-0" onClick={() => toast.info(t('omnichannel.analytics.exportTitle'), t('omnichannel.analytics.exportDescription'))}>
              <Download className="h-4 w-4" />
              {t('omnichannel.actions.exportMock')}
            </Button>
          </div>
        </div>
      {loading ? <OmnichannelLoadingBlock label={t('omnichannel.analytics.loadingState')} /> : null}

      <div className="grid gap-4 xl:grid-cols-2">
        <OmnichannelSectionCard
          title={t('omnichannel.analytics.channelPerformance')}
          action={
            <select value={channelFilter} onChange={(event) => void applyFilterChange(() => setChannelFilter(event.target.value))} className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
              <option value="">{t('common.all')}</option>
              {mockOmnichannelAnalytics.channelSummaries.map((summary) => (
                <option key={summary.channelType} value={summary.channelType}>
                  {getChannelLabel(summary.channelType)}
                </option>
              ))}
            </select>
          }
        >
          <button type="button" className="w-full text-start" onClick={() => setDrawer('channel')}>
            <OmnichannelMiniBarList
              items={filteredChannels.map((summary) => ({
                id: summary.channelType,
                label: getChannelLabel(summary.channelType),
                value: summary.conversations,
                hint: `${summary.replies} ${t('omnichannel.dashboard.replies')}`,
              }))}
            />
          </button>
        </OmnichannelSectionCard>

        <OmnichannelSectionCard
          title={t('omnichannel.analytics.agentPerformance')}
          action={
            <select value={teamFilter} onChange={(event) => void applyFilterChange(() => setTeamFilter(event.target.value))} className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
              <option value="">{t('common.all')}</option>
              <option value="Sales">Sales</option>
              <option value="Reservations">Reservations</option>
              <option value="Support">Support</option>
            </select>
          }
        >
          <div className="space-y-3">
            {filteredAgents.map((member) => (
              <button key={member.id} type="button" className="w-full rounded-lg border border-gray-100 p-3 text-start dark:border-gray-800" onClick={() => setDrawer('agent')}>
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold text-gray-900 dark:text-white">{member.name}</div>
                    <div className="text-xs text-gray-500">{member.teamName}</div>
                  </div>
                  <div className="text-sm font-semibold text-gray-900 dark:text-white">{`${member.averageResponseMinutes}m`}</div>
                </div>
              </button>
            ))}
          </div>
        </OmnichannelSectionCard>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <OmnichannelSectionCard title={t('omnichannel.analytics.slaPerformance')} action={<Button size="sm" variant="outline" onClick={() => setDrawer('sla')}>{t('omnichannel.actions.view')}</Button>}>
          <Metric label={t('omnichannel.dashboard.slaBreached')} value={String(mockOmnichannelAnalytics.slaBreaches)} />
          <Metric label={t('omnichannel.analytics.averageResponse')} value={`${mockOmnichannelAnalytics.averageFirstResponseMinutes}m`} />
        </OmnichannelSectionCard>
        <OmnichannelSectionCard title={t('omnichannel.analytics.conversionPerformance')} action={<Button size="sm" variant="outline" onClick={() => setDrawer('conversion')}>{t('omnichannel.actions.viewBreakdown')}</Button>}>
          <Metric label={t('omnichannel.dashboard.conversationsConvertedToLeads')} value={String(conversionSummary.leadConversions)} />
          <Metric label={t('omnichannel.dashboard.casesOpened')} value={String(conversionSummary.caseCreations)} />
        </OmnichannelSectionCard>
        <OmnichannelSectionCard
          title={t('omnichannel.analytics.scheduledReports')}
          action={<Button size="sm" onClick={() => setSchedules((current) => [...current, { id: `REP-MOCK-${current.length + 1}`, name: `Mock ${current.length + 1}`, frequency: 'weekly', nextRunAt: new Date().toISOString(), recipients: ['ops@travneeds.com'] }])}><Plus className="h-4 w-4" />{t('omnichannel.actions.createSchedule')}</Button>}
        >
          <div className="space-y-3">
            {schedules.map((schedule) => (
              <div key={schedule.id} className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                <div className="font-semibold text-gray-900 dark:text-white">{schedule.name}</div>
                <div className="mt-1 text-xs text-gray-500">{`${schedule.frequency} | ${schedule.nextRunAt}`}</div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button size="sm" variant="ghost" onClick={() => toast.info(t('omnichannel.analytics.editScheduleTitle'), schedule.name)}>{t('common.edit')}</Button>
                  <Button size="sm" variant="ghost" onClick={() => setSchedules((current) => current.filter((item) => item.id !== schedule.id))}>{t('common.delete')}</Button>
                </div>
              </div>
            ))}
          </div>
        </OmnichannelSectionCard>
      </div>

      <OmnichannelSectionCard title={t('omnichannel.analytics.topTopics')} action={<Button size="sm" variant="outline" onClick={() => setDrawer('topics')}>{t('omnichannel.actions.view')}</Button>}>
        {filteredChannels.length === 0 ? (
          <OmnichannelEmptyStateCard title={t('omnichannel.analytics.emptyTitle')} description={t('omnichannel.analytics.emptyDescription')} />
        ) : (
          <div className="rounded-lg border border-dashed border-gray-200 p-5 text-sm text-gray-600 dark:border-gray-800 dark:text-gray-300">
            <div className="mb-2 flex items-center gap-2 font-semibold text-gray-900 dark:text-white">
              <BarChart3 className="h-4 w-4 text-blue-600" />
              {t('omnichannel.analytics.topTopics')}
            </div>
            {t('omnichannel.analytics.topTopicsDescription')}
          </div>
        )}
      </OmnichannelSectionCard>

      <OmnichannelDrawer
        isOpen={drawer !== null}
        title={
          drawer === 'channel'
            ? t('omnichannel.analytics.channelPerformance')
            : drawer === 'agent'
              ? t('omnichannel.analytics.agentPerformance')
              : drawer === 'sla'
                ? t('omnichannel.analytics.slaPerformance')
                : drawer === 'conversion'
                  ? t('omnichannel.analytics.conversionPerformance')
                  : t('omnichannel.analytics.topTopics')
        }
        onClose={() => setDrawer(null)}
      >
        <div className="space-y-3">
          {drawer === 'channel'
            ? filteredChannels.map((summary) => (
                <div key={summary.channelType} className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
                    <div className="font-semibold text-gray-900 dark:text-white">{getChannelLabel(summary.channelType)}</div>
                  <div className="mt-1 text-sm text-gray-500">{`${summary.conversations} / ${summary.replies}`}</div>
                </div>
              ))
            : null}
          {drawer === 'agent'
            ? filteredAgents.map((member) => (
                <div key={member.id} className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
                  <div className="font-semibold text-gray-900 dark:text-white">{member.name}</div>
                  <div className="mt-1 text-sm text-gray-500">{`${member.teamName} / ${member.workloadPercent}%`}</div>
                </div>
              ))
            : null}
          {drawer === 'sla' ? <Metric label={t('omnichannel.dashboard.slaBreached')} value={String(mockOmnichannelAnalytics.slaBreaches)} /> : null}
          {drawer === 'conversion' ? <Metric label={t('omnichannel.dashboard.conversationsConvertedToLeads')} value={String(conversionSummary.leadConversions)} /> : null}
          {drawer === 'topics' ? <div className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">{t('omnichannel.analytics.topTopicsDescription')}</div> : null}
        </div>
      </OmnichannelDrawer>
    </div>
  </div>
  );
};

const Metric: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
    <div className="text-xs font-semibold text-gray-500">{label}</div>
    <div className="mt-1 text-xl font-bold text-gray-900 dark:text-white bidi-isolate">{value}</div>
  </div>
);
