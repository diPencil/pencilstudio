import React, { useMemo, useState } from 'react';
import { Activity, Copy, Download, ListFilter } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { OmnichannelDrawer, OmnichannelEmptyStateCard } from './OmnichannelInteractions';
import { OmnichannelSectionCard } from './OmnichannelUi';
import { mockOmnichannelActivityLogs } from '../../services/omnichannelMockData';
import { Button } from '../ui/Button';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';

export const OmnichannelActivityPage: React.FC = () => {
  const { t, direction } = useLocale();
  const isRTL = direction === 'rtl';
  const toast = useToastContext();
  const { activityLogs } = useOmnichannelMockStore();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('');
  const [channel, setChannel] = useState('');
  const [actor, setActor] = useState('');
  const [viewMode, setViewMode] = useState<'timeline' | 'table'>('timeline');
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const filtered = useMemo(
    () =>
      activityLogs.filter((entry) => {
        const matchesQuery = !query || entry.summary.toLowerCase().includes(query.toLowerCase()) || entry.actorName.toLowerCase().includes(query.toLowerCase());
        const matchesCategory = !category || entry.category === category;
        const matchesChannel = !channel || entry.channelType === channel;
        const matchesActor = !actor || entry.actorName.toLowerCase().includes(actor.toLowerCase());
        return matchesQuery && matchesCategory && matchesChannel && matchesActor;
      }),
    [actor, category, channel, query, activityLogs]
  );

  const selectedEntry = filtered.find((entry) => entry.id === selectedId) ?? null;

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
          <div>
            <h1 className="text-2xl font-bold">{t('omnichannel.activity.title')}</h1>
            <p className="text-blue-100 mt-1">{t('omnichannel.activity.subtitle')}</p>
          </div>
          <div className="flex gap-2">
            <Button className="bg-white/10 text-white hover:bg-white/20 border-0" onClick={() => toast.info(t('omnichannel.activity.exportTitle'), t('omnichannel.activity.exportDescription'))}>
              <Download className="h-4 w-4" />
              {t('omnichannel.actions.exportMock')}
            </Button>
            <Button className="bg-white/10 text-white hover:bg-white/20 border-0" onClick={() => setViewMode((current) => (current === 'timeline' ? 'table' : 'timeline'))}>
              <ListFilter className="h-4 w-4" />
              {t('omnichannel.activity.toggleView')}
            </Button>
          </div>
        </div>
      <OmnichannelSectionCard title={t('omnichannel.activity.logTitle')}>
        <div className="mb-4 grid gap-3 md:grid-cols-5">
          <input value={query} onChange={(event) => setQuery(event.target.value)} className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900" placeholder={t('omnichannel.activity.searchPlaceholder')} />
          <input value={actor} onChange={(event) => setActor(event.target.value)} className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900" placeholder={t('omnichannel.activity.actorPlaceholder')} />
          <select value={category} onChange={(event) => setCategory(event.target.value)} className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
            <option value="">{t('common.all')}</option>
            <option value="channel_connection">{t('omnichannel.activity.category.channelConnection')}</option>
            <option value="conversation_action">{t('omnichannel.activity.category.conversationAction')}</option>
            <option value="assignment_action">{t('omnichannel.activity.category.assignmentAction')}</option>
            <option value="template_change">{t('omnichannel.activity.category.templateChange')}</option>
            <option value="automation_event">{t('omnichannel.activity.category.automationEvent')}</option>
          </select>
          <select value={channel} onChange={(event) => setChannel(event.target.value)} className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
            <option value="">{t('common.all')}</option>
            <option value="whatsapp">WhatsApp</option>
            <option value="email">{t('omnichannel.channel.email')}</option>
            <option value="website_chat">{t('omnichannel.channel.website_chat')}</option>
          </select>
          <Button variant="outline" onClick={() => {
            setQuery('');
            setActor('');
            setCategory('');
            setChannel('');
          }}>
            {t('omnichannel.actions.clearFilters')}
          </Button>
        </div>

        {filtered.length === 0 ? (
          <OmnichannelEmptyStateCard title={t('omnichannel.activity.emptyTitle')} description={t('omnichannel.activity.emptyDescription')} />
        ) : viewMode === 'timeline' ? (
          <div className="space-y-3">
            {filtered.map((entry) => (
              <button key={entry.id} type="button" className="w-full rounded-lg border border-gray-100 p-4 text-start dark:border-gray-800" onClick={() => setSelectedId(entry.id)}>
                <div className="flex items-start gap-3">
                  <Activity className="mt-0.5 h-4 w-4 text-blue-600" />
                  <div className="min-w-0">
                    <div className="font-semibold text-gray-900 dark:text-white">{entry.summary}</div>
                    <div className="mt-1 text-xs text-gray-500">{`${entry.actorName} | ${entry.createdAt}`}</div>
                    {entry.conversationId ? <div className="mt-1 text-xs text-gray-500 ltr-value">{entry.conversationId}</div> : null}
                  </div>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="text-xs uppercase tracking-wide text-gray-500">
                <tr>
                  <th className="px-3 py-2 text-start">{t('omnichannel.activity.actorColumn')}</th>
                  <th className="px-3 py-2 text-start">{t('omnichannel.activity.summaryColumn')}</th>
                  <th className="px-3 py-2 text-start">{t('omnichannel.activity.channelColumn')}</th>
                  <th className="px-3 py-2 text-start">{t('omnichannel.activity.dateColumn')}</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((entry) => (
                  <tr key={entry.id} className="border-t border-gray-100 dark:border-gray-800" onClick={() => setSelectedId(entry.id)}>
                    <td className="px-3 py-3">{entry.actorName}</td>
                    <td className="px-3 py-3">{entry.summary}</td>
                    <td className="px-3 py-3">{entry.channelType ?? t('common.notAvailable')}</td>
                    <td className="px-3 py-3 ltr-value">{entry.createdAt}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </OmnichannelSectionCard>

      <OmnichannelDrawer
        isOpen={Boolean(selectedEntry)}
        title={t('omnichannel.activity.detailsTitle')}
        description={selectedEntry?.id ?? ''}
        onClose={() => setSelectedId(null)}
      >
        {selectedEntry ? (
          <div className="space-y-3">
            <div className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
              <div className="font-semibold text-gray-900 dark:text-white">{selectedEntry.summary}</div>
              <div className="mt-1 text-sm text-gray-500">{selectedEntry.actorName}</div>
            </div>
            <Button variant="outline" onClick={() => toast.success(t('omnichannel.activity.copyEventTitle'), selectedEntry.id)}>
              <Copy className="h-4 w-4" />
              {t('omnichannel.actions.copyEventId')}
            </Button>
          </div>
        ) : null}
      </OmnichannelDrawer>
    </div>
  </div>
  );
};
