import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useLocale } from '../../localization/useLocale';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { PageHeader } from '../ui/PageHeader';
import {
  mockOmnichannelAssignableStaff,
  mockOmnichannelCaseRecords,
  mockOmnichannelConversionActivities,
  mockOmnichannelConversations,
  mockOmnichannelCustomerRecords,
  mockOmnichannelInternalNotes,
  mockOmnichannelLeadRecords,
  mockOmnichannelMessages,
  mockOmnichannelQueues,
  mockOmnichannelTags,
  mockOmnichannelTicketRecords,
} from '../../services/omnichannelMockData';
import { useToastContext } from '../../contexts/ToastContext';
import { calculateOmnichannelMetrics } from '../../utils/omnichannelMetrics';
import { filterOmnichannelConversations } from '../../utils/omnichannelFilters';
import type {
  OmnichannelCaseRecordMock,
  OmnichannelAttachment,
  OmnichannelConversation,
  OmnichannelConversionActivityEvent,
  OmnichannelConversionMode,
  OmnichannelConversionSubmitPayload,
  OmnichannelCustomerRecordMock,
  OmnichannelConversationFilters,
  OmnichannelConversationStatus,
  OmnichannelInternalNote,
  OmnichannelLeadRecordMock,
  OmnichannelLinkedRecord,
  OmnichannelMessage,
  OmnichannelPriority,
  OmnichannelTicketRecordMock,
} from '../../types/omnichannel';
import { OmnichannelInboxFilters } from './inbox/OmnichannelInboxFilters';
import { OmnichannelConversationList } from './inbox/OmnichannelConversationList';
import { OmnichannelConversationWorkspace } from './inbox/OmnichannelConversationWorkspace';
import { OmnichannelCustomerContextPanel } from './inbox/OmnichannelCustomerContextPanel';
import { OmnichannelConversionModal } from './inbox/OmnichannelConversionModal';
import { cn } from '../../utils/cn';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { StatusBadge } from '../ui/StatusBadge';
import { AlertTriangle, ArrowLeft, CornerUpLeft, MailOpen, MailPlus, MessageCircleMore, ShieldAlert, Tag, X } from 'lucide-react';
import { channelLabelKeys, priorityLabelKeys, priorityVariants, statusLabelKeys, statusVariants } from './inbox/omnichannelInboxLabels';

const createInternalNoteMessage = (note: OmnichannelInternalNote): OmnichannelMessage => ({
  id: `MSG-${note.id}`,
  conversationId: note.conversationId,
  direction: 'internal',
  kind: 'text',
  authorName: note.authorName,
  body: note.body,
  createdAt: note.updatedAt ?? note.createdAt,
  attachments: [],
});

interface OmnichannelInboxPageProps {
  standaloneChat?: boolean;
}

export const OmnichannelInboxPage: React.FC<OmnichannelInboxPageProps> = ({ standaloneChat = false }) => {
  const { conversationId } = useParams();
  const navigate = useNavigate();
  const { t, direction, locale } = useLocale();
  const isRTL = direction === 'rtl';
  const toast = useToastContext();
  const [filters, setFilters] = useState<OmnichannelConversationFilters>({ assignedState: 'all' });
  const {
    conversations,
    messages,
    internalNotes,
    leadRecords,
    customerRecords,
    ticketRecords,
    caseRecords,
    activityEvents,
    updateConversationStatus,
    updateConversationPriority,
    assignConversation,
    transferConversation: storeTransferConversation,
    addConversationTag,
    removeConversationTag,
    sendMessage: storeSendMessage,
    updateMessageDelivery: storeUpdateMessageDelivery,
    addInternalNote: storeAddInternalNote,
    deleteInternalNote: storeDeleteInternalNote,
    updateInternalNote: storeUpdateInternalNote,
    archiveInternalNote: storeArchiveInternalNote,
    convertConversation: storeConvertConversation,
    unlinkRecord: storeUnlinkRecord,
    restoreLinkedRecord: storeRestoreLinkedRecord,
    markConversationRead,
  } = useOmnichannelMockStore();
  const [composerValue, setComposerValue] = useState('');
  const [composerAttachments, setComposerAttachments] = useState<OmnichannelAttachment[]>([]);
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  const [messageFailureState, setMessageFailureState] = useState<{ messageId: string; reason: string } | null>(null);
  const [removedRecords, setRemovedRecords] = useState<Record<string, OmnichannelLinkedRecord[]>>({});
  const [activeConversionMode, setActiveConversionMode] = useState<OmnichannelConversionMode>('convert_lead');
  const [isConversionModalOpen, setIsConversionModalOpen] = useState(false);
  const [mobileView, setMobileView] = useState<'list' | 'chat' | 'details'>('list');
  const [standaloneTagsOpen, setStandaloneTagsOpen] = useState(false);
  const messageTimeoutsRef = useRef<number[]>([]);

  useEffect(() => {
    return () => {
      messageTimeoutsRef.current.forEach((timeoutId) => window.clearTimeout(timeoutId));
      messageTimeoutsRef.current = [];
    };
  }, []);

  useEffect(() => {
    setComposerValue('');
    setComposerAttachments([]);
    setMessageFailureState(null);
  }, [conversationId]);

  const filteredConversations = useMemo(
    () => filterOmnichannelConversations(conversations, filters),
    [conversations, filters]
  );

  const selectedConversation = conversations.find((conversation) => conversation.id === conversationId) ?? filteredConversations[0] ?? conversations[0];
  const activeStandaloneTags = selectedConversation ? mockOmnichannelTags.filter((tag) => selectedConversation.tagIds.includes(tag.id)) : [];
  const availableStandaloneTags = selectedConversation ? mockOmnichannelTags.filter((tag) => !selectedConversation.tagIds.includes(tag.id)) : [];
  const metrics = calculateOmnichannelMetrics(conversations);
  const teamOptions = useMemo(
    () => mockOmnichannelQueues.map((queue) => ({
      id: queue.id,
      label: direction === 'rtl' ? queue.name.ar : queue.name.en,
    })),
    [direction]
  );

  const selectedMessages = useMemo(() => {
    if (!selectedConversation) {
      return [];
    }

    const noteMessages = internalNotes
      .filter((note) => note.conversationId === selectedConversation.id && note.status !== 'archived')
      .map(createInternalNoteMessage);

    return [...messages.filter((message) => message.conversationId === selectedConversation.id), ...noteMessages]
      .sort((first, second) => new Date(first.createdAt).getTime() - new Date(second.createdAt).getTime());
  }, [internalNotes, messages, selectedConversation]);

  const updateSelectedConversation = (updater: (conversation: OmnichannelConversation) => OmnichannelConversation) => {
    // Left as stub for backward compat if any code uses it, but store handles updates.
  };

  const selectConversation = (nextConversationId: string) => {
    navigate(`/omnichannel/inbox/${nextConversationId}`);
  };

  const changeStatus = (status: OmnichannelConversationStatus) => {
    if (selectedConversation) {
      updateConversationStatus(selectedConversation.id, status);
      toast.info(t('omnichannel.inbox.statusUpdatedTitle'), t('omnichannel.inbox.statusUpdatedDescription'));
    }
  };

  const assignStaff = (staffId: string) => {
    if (selectedConversation) {
      assignConversation(selectedConversation.id, staffId || null);
      const staff = mockOmnichannelAssignableStaff.find((item) => item.id === staffId);
      toast.success(t('omnichannel.inbox.assignmentUpdatedTitle'), staff ? t('omnichannel.inbox.assignmentUpdatedDescription') : t('omnichannel.inbox.assignmentClearedDescription'));
    }
  };

  const addTag = (tagId: string) => {
    if (selectedConversation) {
      addConversationTag(selectedConversation.id, tagId);
      toast.success(t('omnichannel.inbox.tagAddedTitle'), t('omnichannel.inbox.tagAddedDescription'));
    }
  };

  const removeTag = (tagId: string) => {
    if (selectedConversation) {
      removeConversationTag(selectedConversation.id, tagId);
      toast.info(t('omnichannel.inbox.tagRemovedTitle'), t('omnichannel.inbox.tagRemovedDescription'));
    }
  };

  const addInternalNote = (body: string) => {
    if (!selectedConversation) {
      return;
    }
    storeAddInternalNote(selectedConversation.id, body, 'USR-001', 'Super Admin');
    toast.success(t('omnichannel.inbox.noteAddedTitle'), t('omnichannel.inbox.noteAddedDescription'));
  };

  const updateInternalNote = (noteId: string, body: string) => {
    storeUpdateInternalNote(noteId, body);
    toast.success(t('omnichannel.inbox.noteUpdatedTitle'), t('omnichannel.inbox.noteUpdatedDescription'));
  };

  const archiveInternalNote = (noteId: string) => {
    storeArchiveInternalNote(noteId, true);
    toast.info(t('omnichannel.inbox.noteArchivedTitle'), t('omnichannel.inbox.noteArchivedDescription'));
  };

  const restoreInternalNote = (noteId: string) => {
    storeArchiveInternalNote(noteId, false);
    toast.success(t('omnichannel.inbox.noteRestoredTitle'), t('omnichannel.inbox.noteRestoredDescription'));
  };

  const deleteInternalNote = (noteId: string) => {
    storeDeleteInternalNote(noteId);
    toast.warning(t('omnichannel.inbox.noteDeletedTitle'), t('omnichannel.inbox.noteDeletedDescription'));
  };

  const updateMessageDelivery = (messageId: string, deliveryStatus: OmnichannelMessage['deliveryStatus'], failureReason?: string) => {
    storeUpdateMessageDelivery(messageId, deliveryStatus, failureReason);
  };

  const scheduleDeliveryProgress = (messageId: string, shouldFail: boolean) => {
    const sentTimeout = window.setTimeout(() => {
      updateMessageDelivery(messageId, 'sent');
    }, 350);
    const secondTimeout = window.setTimeout(() => {
      if (shouldFail) {
        updateMessageDelivery(messageId, 'failed', t('omnichannel.inbox.messageFailureReason'));
        setMessageFailureState({ messageId, reason: t('omnichannel.inbox.messageFailureReason') });
        toast.error(t('omnichannel.inbox.messageFailedTitle'), t('omnichannel.inbox.messageFailedDescription'));
        return;
      }

      updateMessageDelivery(messageId, 'delivered');
    }, 950);
    const readTimeout = window.setTimeout(() => {
      if (!shouldFail) {
        updateMessageDelivery(messageId, 'read');
      }
    }, 1650);

    messageTimeoutsRef.current.push(sentTimeout, secondTimeout, readTimeout);
  };

  const sendMockMessage = (override?: { retryMessageId?: string; body?: string; attachments?: OmnichannelAttachment[] }) => {
    const sourceBody = override?.body ?? composerValue;
    const sourceAttachments = override?.attachments ?? composerAttachments;

    if (!selectedConversation || (!sourceBody.trim() && !sourceAttachments.length) || isSendingMessage) {
      return;
    }

    const body = sourceBody.trim();
    const createdAt = new Date().toISOString();
    const outboundCount = messages.filter((message) => message.direction === 'outbound').length;
    const shouldFail = !override?.retryMessageId && ((outboundCount + 1) % 4 === 0);
    const messageId = override?.retryMessageId ?? `MSG-MOCK-${messages.length + 1}`;
    const attachments = sourceAttachments.map((attachment, index) => ({
      ...attachment,
      id: `${attachment.id}-${index + 1}`,
    }));

    setIsSendingMessage(true);
    setMessageFailureState(null);

    setMessages((current) => {
      const nextMessage: OmnichannelMessage = {
        id: messageId,
        conversationId: selectedConversation.id,
        direction: 'outbound',
        kind: attachments.length > 0 ? 'attachment' : 'text',
        authorName: 'Super Admin',
        body,
        createdAt,
        deliveryStatus: 'sending',
        attachments,
        retryCount: override?.retryMessageId ? (current.find((message) => message.id === messageId)?.retryCount ?? 0) + 1 : 0,
      };

      if (override?.retryMessageId) {
        return current.map((message) => (message.id === messageId ? nextMessage : message));
      }

      return [...current, nextMessage];
    });

    setComposerValue('');
    setComposerAttachments([]);
    updateSelectedConversation((conversation) => ({
      ...conversation,
      lastMessagePreview: body || t('omnichannel.inbox.attachmentOnlyPreview'),
      lastMessageAt: createdAt,
      unreadCount: 0,
    }));
    toast.info(
      override?.retryMessageId ? t('omnichannel.inbox.messageRetryingTitle') : t('omnichannel.inbox.messageSendingTitle'),
      override?.retryMessageId ? t('omnichannel.inbox.messageRetryingDescription') : t('omnichannel.inbox.messageSendingDescription')
    );
    const sendingTimeout = window.setTimeout(() => {
      setIsSendingMessage(false);
      scheduleDeliveryProgress(messageId, shouldFail);
    }, 250);
    messageTimeoutsRef.current.push(sendingTimeout);
  };

  const addMockAttachment = () => {
    setComposerAttachments((current) => [
      ...current,
      {
        id: `ATT-MOCK-${current.length + 1}`,
        fileName: current.length % 2 === 0 ? 'itinerary-preview.pdf' : 'passport-copy.jpg',
        fileType: current.length % 2 === 0 ? 'pdf' : 'image',
        sizeKb: current.length % 2 === 0 ? 248 : 164,
        mockUrlLabel: 'local-mock',
      },
    ]);
    toast.info(t('omnichannel.inbox.attachmentQueuedTitle'), t('omnichannel.inbox.attachmentQueuedDescription'));
  };

  const removeComposerAttachment = (attachmentId: string) => {
    setComposerAttachments((current) => current.filter((attachment) => attachment.id !== attachmentId));
  };

  const clearComposerDraft = () => {
    setComposerValue('');
    setComposerAttachments([]);
    setMessageFailureState(null);
    toast.info(t('omnichannel.inbox.draftClearedTitle'), t('omnichannel.inbox.draftClearedDescription'));
  };

  const retryMessage = (messageId: string) => {
    const failedMessage = messages.find((message) => message.id === messageId);
    if (!failedMessage) {
      return;
    }

    setComposerValue(failedMessage.body);
    setComposerAttachments(failedMessage.attachments);
    sendMockMessage({ retryMessageId: messageId, body: failedMessage.body, attachments: failedMessage.attachments });
  };

  const addActivityEvent = (event: Omit<OmnichannelConversionActivityEvent, 'id' | 'createdAt'>) => {
    const createdAt = new Date().toISOString();
    setActivityEvents((current) => [
      {
        ...event,
        id: `ACT-MOCK-${current.length + 1}`,
        createdAt,
      },
      ...current,
    ]);
    setMessages((current) => [
      ...current,
      {
        id: `MSG-SYS-${current.length + 1}`,
        conversationId: event.conversationId,
        direction: 'system',
        kind: 'system_event',
        authorName: 'Travneeds Omnichannel',
        body: event.note ?? event.recordLabel,
        createdAt,
        attachments: [],
      },
    ]);
  };

  const unlinkRecord = (record: OmnichannelLinkedRecord) => {
    if (!selectedConversation) {
      return;
    }
    storeUnlinkRecord(selectedConversation.id, record.type, record.id);
    toast.info(t('omnichannel.inbox.tagRemovedTitle'), t('omnichannel.inbox.tagRemovedDescription'));
  };

  const restoreRecord = (recordToRestore: OmnichannelLinkedRecord) => {
    if (!selectedConversation) {
      return;
    }
    storeRestoreLinkedRecord(selectedConversation.id, recordToRestore.type, recordToRestore.id);
    toast.success(t('omnichannel.inbox.tagAddedTitle'), t('omnichannel.inbox.tagAddedDescription'));
  };

  const changePriority = (priority: OmnichannelPriority) => {
    if (selectedConversation) {
      updateConversationPriority(selectedConversation.id, priority);
      toast.success(t('omnichannel.inbox.priorityUpdatedTitle'), t('omnichannel.inbox.priorityUpdatedDescription'));
    }
  };

  const toggleReadState = () => {
    if (!selectedConversation) {
      return;
    }

    const nextRead = selectedConversation.unreadCount > 0;
    markConversationRead(selectedConversation.id, nextRead);
    toast.info(
      !nextRead ? t('omnichannel.inbox.markedUnreadTitle') : t('omnichannel.inbox.markedReadTitle'),
      !nextRead ? t('omnichannel.inbox.markedUnreadDescription') : t('omnichannel.inbox.markedReadDescription')
    );
  };

  const escalateConversation = () => {
    if (selectedConversation) {
      updateConversationStatus(selectedConversation.id, 'escalated');
      updateConversationPriority(selectedConversation.id, 'urgent');
      toast.warning(t('omnichannel.inbox.escalatedTitle'), t('omnichannel.inbox.escalatedDescription'));
    }
  };

  const transferConversation = () => {
    if (!selectedConversation) {
      return;
    }
    const targetQueue = selectedConversation.queueId === 'queue-sales' ? 'queue-support' : 'queue-sales';
    storeTransferConversation(selectedConversation.id, targetQueue);
    toast.success(t('omnichannel.inbox.transferTitle'), t('omnichannel.inbox.transferDescription'));
  };

  const mapLeadToLinkedRecord = (record: OmnichannelLeadRecordMock): OmnichannelLinkedRecord => ({
    type: 'lead',
    id: record.id,
    label: record.name,
    href: '/leads',
    status: record.stage,
    ownerName: record.ownerName,
    createdAt: record.createdAt,
    stage: record.stage,
  });

  const mapCustomerToLinkedRecord = (record: OmnichannelCustomerRecordMock): OmnichannelLinkedRecord => ({
    type: 'customer',
    id: record.id,
    label: record.name,
    href: '/customers',
    status: record.tier,
    ownerName: record.ownerName,
    createdAt: record.createdAt,
    stage: record.tier,
  });

  const mapTicketToLinkedRecord = (record: OmnichannelTicketRecordMock): OmnichannelLinkedRecord => ({
    type: 'support_ticket',
    id: record.id,
    label: record.subject,
    href: '/help-center/tickets',
    status: record.status,
    ownerName: record.ownerName,
    createdAt: record.createdAt,
    priority: record.priority,
    teamName: record.teamName,
  });

  const mapCaseToLinkedRecord = (record: OmnichannelCaseRecordMock): OmnichannelLinkedRecord => ({
    type: 'sales_case',
    id: record.id,
    label: record.subject,
    href: `/sales/cases/${record.id}`,
    status: record.status,
    ownerName: record.ownerName,
    createdAt: record.createdAt,
    stage: record.caseType,
    teamName: record.teamName,
  });

  const existingLinkOptions = useMemo(() => {
    if (!selectedConversation) {
      return [];
    }

    const linkedKeys = new Set(selectedConversation.linkedRecords.map((record) => `${record.type}:${record.id}`));

    return [
      ...leadRecords.map(mapLeadToLinkedRecord),
      ...customerRecords.map(mapCustomerToLinkedRecord),
      ...ticketRecords.map(mapTicketToLinkedRecord),
      ...caseRecords.map(mapCaseToLinkedRecord),
    ].filter((record) => !linkedKeys.has(`${record.type}:${record.id}`));
  }, [caseRecords, customerRecords, leadRecords, selectedConversation, ticketRecords]);

  const currentActivityEvents = useMemo(
    () => selectedConversation
      ? activityEvents
        .filter((event) => event.conversationId === selectedConversation.id)
        .sort((first, second) => new Date(second.createdAt).getTime() - new Date(first.createdAt).getTime())
      : [],
    [activityEvents, selectedConversation]
  );

  const openConversionModal = (mode: OmnichannelConversionMode) => {
    setActiveConversionMode(mode);
    setIsConversionModalOpen(true);
  };

  const handleConversionSubmit = async (payload: OmnichannelConversionSubmitPayload) => {
    if (!selectedConversation) {
      return;
    }

    await new Promise((resolve) => window.setTimeout(resolve, 350));

    const hasRecordType = (type: OmnichannelLinkedRecord['type']) => selectedConversation.linkedRecords.some((record) => record.type === type);

    if (payload.mode === 'convert_lead' && hasRecordType('lead')) {
      toast.warning(t('omnichannel.conversion.duplicateTitle'), t('omnichannel.conversion.duplicateLead'));
      return;
    }

    if (payload.mode === 'convert_customer' && hasRecordType('customer')) {
      toast.warning(t('omnichannel.conversion.duplicateTitle'), t('omnichannel.conversion.duplicateCustomer'));
      return;
    }

    if (payload.mode === 'create_ticket' && hasRecordType('support_ticket')) {
      toast.warning(t('omnichannel.conversion.duplicateTitle'), t('omnichannel.conversion.duplicateTicket'));
      return;
    }

    if (payload.mode === 'create_case' && hasRecordType('sales_case')) {
      toast.warning(t('omnichannel.conversion.duplicateTitle'), t('omnichannel.conversion.duplicateCase'));
      return;
    }

    if (payload.mode === 'link_existing') {
      const selectedRecord = existingLinkOptions.find((record) => `${record.type}:${record.id}` === payload.existingRecordKey);
      if (!selectedRecord) {
        toast.error(t('omnichannel.conversion.errorTitle'), t('omnichannel.conversion.missingExistingRecord'));
        return;
      }

      storeConvertConversation(selectedConversation.id, 'link_existing', {
        existingRecordId: selectedRecord.id,
        existingRecordType: selectedRecord.type,
        existingRecordLabel: selectedRecord.label,
        notes: payload.notes,
      });
      toast.success(t('omnichannel.conversion.successTitle'), t('omnichannel.conversion.linkSuccess'));
      return;
    }

    const staff = mockOmnichannelAssignableStaff.find((item) => item.id === payload.assignedStaffId);
    const assignedStaffName = staff?.name ?? selectedConversation.assignedStaffName ?? 'Super Admin';
    const teamLabel = teamOptions.find((team) => team.id === payload.assignedTeamId)?.label;

    storeConvertConversation(selectedConversation.id, payload.mode, {
      name: payload.customerName,
      phone: payload.phone,
      email: payload.email,
      companyName: payload.companyName,
      subject: selectedConversation.subject,
      priority: payload.ticketPriority,
      category: payload.ticketCategory,
      teamName: teamLabel,
      caseType: payload.caseType,
      notes: payload.notes,
    });

    if (payload.mode === 'convert_lead') {
      toast.success(t('omnichannel.conversion.successTitle'), t('omnichannel.conversion.convertLeadSuccess'));
    } else if (payload.mode === 'convert_customer') {
      toast.success(t('omnichannel.conversion.successTitle'), t('omnichannel.conversion.convertCustomerSuccess'));
    } else if (payload.mode === 'create_ticket') {
      toast.success(t('omnichannel.conversion.successTitle'), t('omnichannel.conversion.ticketSuccess'));
    } else if (payload.mode === 'create_case') {
      toast.success(t('omnichannel.conversion.successTitle'), t('omnichannel.conversion.caseSuccess'));
    }
  };

  return (
    <div className="h-[calc(100vh-5rem)] w-full overflow-hidden pb-0" dir={direction}>
      <div className="mx-auto flex h-full max-w-[1400px] flex-col gap-4 overflow-hidden">
        {standaloneChat ? (
          <div className="flex shrink-0 gap-4 rounded-3xl bg-[#2563EB] p-4 text-white shadow-lg shadow-blue-500/20 sm:p-6">
            <button
              type="button"
              className="flex h-9 w-9 shrink-0 self-center items-center justify-center rounded-full text-blue-100 transition hover:bg-white/10 hover:text-white"
              onClick={() => navigate('/omnichannel/inbox')}
              title="Back to Unified Inbox"
            >
              <ArrowLeft className="h-5 w-5 rtl:rotate-180" />
            </button>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                <h1 className="truncate text-2xl font-bold sm:text-3xl">{selectedConversation?.subject || t('omnichannel.inbox.title')}</h1>
              </div>

              {selectedConversation && (
                <div className="flex shrink-0 flex-wrap items-center justify-end gap-2">
                  <StatusBadge variant="gray">{t(channelLabelKeys[selectedConversation.channelType])}</StatusBadge>
                  <StatusBadge variant={statusVariants[selectedConversation.status]}>{t(statusLabelKeys[selectedConversation.status])}</StatusBadge>
                  <StatusBadge variant={priorityVariants[selectedConversation.priority]}>{t(priorityLabelKeys[selectedConversation.priority])}</StatusBadge>
                  <div className="rounded-full bg-white/15 px-3 py-1 text-xs font-bold uppercase tracking-wide text-white">
                    SLA <span className="ltr-value normal-case">{selectedConversation.sla.firstResponseRemainingMinutes}m</span>
                  </div>
                  <div className="relative">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="relative h-8 w-9 rounded-full border-transparent bg-white/10 !p-0 text-white hover:bg-white/20"
                      onClick={() => setStandaloneTagsOpen((current) => !current)}
                      title="Tags"
                    >
                      <Tag className="h-4 w-4" />
                      {activeStandaloneTags.length > 0 && (
                        <span className="absolute -right-1.5 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-white px-1 text-[9px] font-bold leading-none text-blue-700">
                          {activeStandaloneTags.length}
                        </span>
                      )}
                    </Button>
                    {standaloneTagsOpen && (
                      <div className="absolute right-0 z-30 mt-2 w-72 rounded-xl border border-gray-200 bg-white p-2 text-gray-900 shadow-xl dark:border-gray-800 dark:bg-gray-900 dark:text-white rtl:left-0 rtl:right-auto">
                        <div className="mb-2 px-2 text-[10px] font-bold uppercase tracking-widest text-gray-400">Conversation tags</div>
                        <div className="max-h-72 space-y-1 overflow-y-auto">
                          {activeStandaloneTags.length > 0 ? activeStandaloneTags.map((tag) => (
                            <div key={tag.id} className="flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 hover:bg-gray-50 dark:hover:bg-gray-800">
                              <span className={`inline-flex min-w-0 items-center gap-1 rounded-full border px-2 py-1 text-xs font-semibold ${tag.colorClass}`}>
                                <span className="truncate">{tag.label[locale]}</span>
                              </span>
                              <button
                                type="button"
                                className="rounded-md p-1 text-gray-400 hover:bg-rose-50 hover:text-rose-600"
                                onClick={() => removeTag(tag.id)}
                                title={t('omnichannel.actions.removeTag')}
                              >
                                <X className="h-4 w-4" />
                              </button>
                            </div>
                          )) : <div className="px-2 py-3 text-sm text-gray-500">No tags selected.</div>}
                        </div>
                        {availableStandaloneTags.length > 0 && (
                          <div className="mt-2 border-t border-gray-100 pt-2 dark:border-gray-800">
                            <div className="mb-2 px-2 text-[10px] font-bold uppercase tracking-widest text-gray-400">Add tag</div>
                            <div className="flex flex-wrap gap-2 px-2">
                              {availableStandaloneTags.slice(0, 6).map((tag) => (
                                <button
                                  key={tag.id}
                                  type="button"
                                  className={`inline-flex rounded-full border px-2 py-1 text-xs font-semibold ${tag.colorClass}`}
                                  onClick={() => addTag(tag.id)}
                                >
                                  {tag.label[locale]}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  <TableActionsDropdown
                    triggerClassName="h-8 w-9 rounded-full border border-transparent bg-white/10 !p-0 text-white hover:bg-white/20 hover:text-white"
                    triggerIconClassName="h-4 w-4"
                    actions={[
                      {
                        label: selectedConversation.status === 'closed' ? t('omnichannel.actions.reopenConversation') : t('omnichannel.actions.closeConversation'),
                        icon: CornerUpLeft,
                        onClick: selectedConversation.status === 'closed' ? () => changeStatus('open') : () => changeStatus('closed')
                      },
                      {
                        label: selectedConversation.unreadCount > 0 ? t('omnichannel.actions.markRead') : t('omnichannel.actions.markUnread'),
                        icon: selectedConversation.unreadCount > 0 ? MailOpen : MailPlus,
                        onClick: toggleReadState
                      },
                      {
                        label: t('omnichannel.actions.transferConversation'),
                        icon: CornerUpLeft,
                        onClick: transferConversation
                      },
                      {
                        label: t('omnichannel.actions.changePriority'),
                        icon: AlertTriangle,
                        onClick: () => changePriority(selectedConversation.priority === 'urgent' ? 'high' : 'urgent')
                      },
                      {
                        label: t('omnichannel.actions.escalateConversation'),
                        icon: ShieldAlert,
                        onClick: escalateConversation
                      }
                    ]}
                  />
                </div>
              )}
              </div>
              <p className="mt-2 text-sm text-blue-100">
                {selectedConversation?.customer.name} <span className="opacity-70">·</span> <span className="ltr-value">{selectedConversation?.id}</span> <span className="opacity-70">·</span> {selectedConversation?.assignedStaffName ?? t('omnichannel.inbox.unassigned')}
              </p>
            </div>
          </div>
        ) : (
          <div className={cn("flex shrink-0 flex-col lg:flex-row lg:items-center justify-between gap-4 bg-[#2563EB] text-white p-4 sm:p-5 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "lg:flex-row-reverse")}>
            <div>
              <h1 className="text-xl font-bold sm:text-2xl">{t('omnichannel.inbox.title')}</h1>
              <p className="mt-1 text-white/80">{t('omnichannel.inbox.subtitle')}</p>
            </div>
            <div className="flex-shrink-0">
              <OmnichannelInboxFilters filters={filters} tags={mockOmnichannelTags} onFiltersChange={setFilters} />
            </div>
          </div>
        )}

      {!standaloneChat && <div className="grid shrink-0 gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <SummaryCard label={t('omnichannel.metric.conversations')} value={metrics.total.toString()} />
        <SummaryCard label={t('omnichannel.metric.unassigned')} value={metrics.unassigned.toString()} />
        <SummaryCard label={t('omnichannel.metric.slaBreaches')} value={metrics.slaBreaches.toString()} />
        <SummaryCard label={t('omnichannel.inbox.unread')} value={metrics.unread.toString()} />
        <SummaryCard label={t('omnichannel.inbox.filtered')} value={filteredConversations.length.toString()} />
      </div>}


      {selectedConversation && (
        <div className={cn(
          "flex min-h-0 flex-1 gap-4",
          standaloneChat ? "w-full" : "xl:grid xl:grid-cols-[minmax(280px,360px)_minmax(0,1fr)_minmax(280px,360px)]"
        )}>
          {/* List Column */}
          {!standaloneChat && <div className={cn(
            "min-h-0 w-full shrink-0 overflow-hidden xl:w-auto",
            mobileView !== 'list' ? "hidden xl:block" : "block",
            direction === 'rtl' ? 'xl:order-3' : 'xl:order-1'
          )}>
            <OmnichannelConversationList
              conversations={filteredConversations}
              selectedConversationId={selectedConversation.id}
              onSelect={(id) => { selectConversation(id); setMobileView('chat'); }}
            />
          </div>}
          
          {/* Workspace Column */}
          <div className={cn(
            "min-h-0 w-full overflow-hidden",
            !standaloneChat && "shrink-0 xl:w-auto",
            mobileView !== 'chat' ? "hidden xl:block" : "block flex-1",
            "xl:order-2"
          )}>
            <div className="xl:hidden flex items-center justify-between mb-4 bg-white dark:bg-gray-900 p-3 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">
               <Button variant="ghost" size="sm" onClick={() => setMobileView('list')} className="text-gray-600 dark:text-gray-300">
                  {isRTL ? '← رجوع للقائمة' : '← Back to List'}
               </Button>
               <Button variant="ghost" size="sm" onClick={() => setMobileView('details')} className="text-blue-600 bg-blue-50 dark:bg-blue-900/20">
                  {isRTL ? 'التفاصيل' : 'Details'}
               </Button>
            </div>
            <OmnichannelConversationWorkspace
              conversation={selectedConversation}
              messages={selectedMessages}
              tags={mockOmnichannelTags}
              composerValue={composerValue}
              composerAttachments={composerAttachments}
              isSending={isSendingMessage}
              messageFailureState={messageFailureState}
              onComposerChange={setComposerValue}
              onSend={sendMockMessage}
              onMockAttach={addMockAttachment}
              onRemoveAttachment={removeComposerAttachment}
              onRetryMessage={retryMessage}
              onClearDraft={clearComposerDraft}
              onChangePriority={changePriority}
              onToggleReadState={toggleReadState}
              onEscalate={escalateConversation}
              onTransfer={transferConversation}
              onCloseConversation={() => changeStatus('closed')}
              onReopenConversation={() => changeStatus('open')}
              onOpenStandalone={standaloneChat ? undefined : () => navigate(`/omnichannel/inbox/${selectedConversation.id}/chat`)}
              hideHeader={standaloneChat}
              onRemoveTag={removeTag}
              onAddTag={addTag}
            />
          </div>
          
          {/* Details Column */}
          {!standaloneChat && <div className={cn(
             "min-h-0 w-full shrink-0 overflow-y-auto xl:w-auto",
             mobileView !== 'details' ? "hidden xl:block" : "block",
             direction === 'rtl' ? 'xl:order-1' : 'xl:order-3'
          )}>
            <div className="xl:hidden mb-4">
               <Button variant="ghost" size="sm" onClick={() => setMobileView('chat')} className="bg-white dark:bg-gray-900 shadow-sm border border-gray-100 dark:border-gray-800">
                  {isRTL ? '← رجوع للمحادثة' : '← Back to Chat'}
               </Button>
            </div>
            <OmnichannelCustomerContextPanel
              conversation={selectedConversation}
              notes={internalNotes.filter((note) => note.conversationId === selectedConversation.id)}
              removedRecords={removedRecords[selectedConversation.id] ?? []}
              activityEvents={currentActivityEvents}
              hasLinkableRecords={existingLinkOptions.length > 0}
              onInsertReply={(body) => setComposerValue((current) => current ? `${current}\n${body}` : body)}
              onAddNote={addInternalNote}
              onUpdateNote={updateInternalNote}
              onArchiveNote={archiveInternalNote}
              onRestoreNote={restoreInternalNote}
              onDeleteNote={deleteInternalNote}
              onUnlinkRecord={unlinkRecord}
              onRestoreRecord={restoreRecord}
              onStatusChange={changeStatus}
              onPriorityChange={changePriority}
              onAssignStaff={assignStaff}
              onToggleReadState={toggleReadState}
              onEscalate={escalateConversation}
              onTransferConversation={transferConversation}
              onOpenConversion={openConversionModal}
            />
          </div>}
        </div>
      )}

      {selectedConversation && (
        <OmnichannelConversionModal
          isOpen={isConversionModalOpen}
          mode={activeConversionMode}
          conversation={selectedConversation}
          staffOptions={mockOmnichannelAssignableStaff}
          teamOptions={teamOptions}
          existingRecords={existingLinkOptions}
          onClose={() => setIsConversionModalOpen(false)}
          onSubmit={handleConversionSubmit}
        />
      )}
      </div>
    </div>
  );
};

const SummaryCard: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <Card className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
    <CardContent className="p-3 sm:p-4">
      <div className="relative z-10">
        <div className="text-xs font-semibold text-gray-500">{label}</div>
        <div className="mt-1 text-xl font-bold text-gray-950 dark:text-white bidi-isolate">{value}</div>
      </div>
      <MessageCircleMore className="absolute ltr:-right-4 rtl:-left-4 -bottom-4 h-20 w-20 text-blue-500/10 group-hover:scale-110 transition-transform duration-300" />
    </CardContent>
  </Card>
);
