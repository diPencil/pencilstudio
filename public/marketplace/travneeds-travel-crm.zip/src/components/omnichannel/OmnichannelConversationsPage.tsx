import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, FolderKanban, History, MessageCircle, Search, Tag, UserRoundCheck, XCircle } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { mockOmnichannelConversations, mockOmnichannelTags } from '../../services/omnichannelMockData';
import { filterOmnichannelConversations } from '../../utils/omnichannelFilters';
import {
  linkedRecordLabelKeys,
  priorityLabelKeys,
  slaLabelKeys,
  statusLabelKeys,
} from './inbox/omnichannelInboxLabels';
import { OmnichannelModuleShell } from './OmnichannelModuleShell';
import { OmnichannelSectionCard, OmnichannelStatsGrid, type OmnichannelStatItem } from './OmnichannelUi';
import { calculateOmnichannelMetrics } from '../../utils/omnichannelMetrics';
import { StatusBadge } from '../ui/StatusBadge';
import { getChannelLabel } from '../../utils/omnichannelLinks';
import type { OmnichannelConversation, OmnichannelConversationFilters, OmnichannelPriority } from '../../types/omnichannel';
import { cn } from '../../utils/cn';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { Modal } from '../ui/Modal';
import { useToastContext } from '../../contexts/ToastContext';
import { OmnichannelEmptyStateCard, OmnichannelStateNotice } from './OmnichannelInteractions';

type BulkAction = 'assign' | 'status' | 'tag' | null;

export const OmnichannelConversationsPage: React.FC = () => {
  const { t, direction } = useLocale();
  const isRTL = direction === 'rtl';
  const navigate = useNavigate();
  const toast = useToastContext();
  const [filters, setFilters] = useState<OmnichannelConversationFilters>({});
  const {
    conversations,
    updateConversationStatus,
    updateConversationPriority,
    assignConversation,
    addConversationTag,
    removeConversationTag,
    transferConversation: storeTransferConversation,
  } = useOmnichannelMockStore();
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [staffFilter, setStaffFilter] = useState('');
  const [channelFilter, setChannelFilter] = useState('');
  const [slaFilter, setSlaFilter] = useState('');
  const [bulkAction, setBulkAction] = useState<BulkAction>(null);
  const [bulkValue, setBulkValue] = useState('');
  const [activeConversation, setActiveConversation] = useState<OmnichannelConversation | null>(null);

  const filtered = useMemo(() => {
    const result = filterOmnichannelConversations(conversations, {
      ...filters,
      channelTypes: channelFilter ? [channelFilter as typeof mockOmnichannelConversations[number]['channelType']] : undefined,
      statuses: statusFilter ? [statusFilter as typeof mockOmnichannelConversations[number]['status']] : undefined,
      priorities: priorityFilter ? [priorityFilter as typeof mockOmnichannelConversations[number]['priority']] : undefined,
      slaStatuses: slaFilter ? [slaFilter as typeof mockOmnichannelConversations[number]['sla']['status']] : undefined,
    });

    return staffFilter
      ? result.filter((conversation) => (conversation.assignedStaffName ?? '').toLowerCase().includes(staffFilter.toLowerCase()))
      : result;
  }, [channelFilter, conversations, filters, priorityFilter, slaFilter, staffFilter, statusFilter]);

  const metrics = calculateOmnichannelMetrics(conversations);
  const stats: OmnichannelStatItem[] = [
    { id: 'total', label: t('omnichannel.conversations.totalRows'), value: filtered.length, icon: FolderKanban },
    { id: 'unassigned', label: t('omnichannel.metric.unassigned'), value: metrics.unassigned, icon: FolderKanban },
    { id: 'highPriority', label: t('omnichannel.conversations.highPriority'), value: conversations.filter((item) => item.priority === 'high' || item.priority === 'urgent').length, icon: FolderKanban },
  ];

  const applyBulkAction = () => {
    if (!bulkAction || !selectedIds.length) {
      return;
    }

    if (bulkAction === 'assign' && bulkValue) {
      selectedIds.forEach((id) => assignConversation(id, bulkValue));
      toast.success(t('omnichannel.conversations.bulkAssignSuccess'), t('omnichannel.conversations.bulkAssignDescription'));
    }

    if (bulkAction === 'status' && bulkValue) {
      selectedIds.forEach((id) => updateConversationStatus(id, bulkValue as any));
      toast.success(t('omnichannel.conversations.bulkStatusSuccess'), t('omnichannel.conversations.bulkStatusDescription'));
    }

    if (bulkAction === 'tag' && bulkValue) {
      selectedIds.forEach((id) => addConversationTag(id, bulkValue));
      toast.success(t('omnichannel.conversations.bulkTagSuccess'), t('omnichannel.conversations.bulkTagDescription'));
    }

    setBulkAction(null);
    setBulkValue('');
  };

  const toggleSelection = (conversationId: string) => {
    setSelectedIds((current) =>
      current.includes(conversationId) ? current.filter((id) => id !== conversationId) : [...current, conversationId]
    );
  };

  const cyclePriority = (conversationId: string) => {
    const target = conversations.find((c) => c.id === conversationId);
    if (target) {
      const order: OmnichannelPriority[] = ['low', 'normal', 'high', 'urgent'];
      const nextPriority = order[(order.indexOf(target.priority) + 1) % order.length];
      updateConversationPriority(conversationId, nextPriority);
    }
  };

  const toggleStatus = (conversationId: string) => {
    const target = conversations.find((conversation) => conversation.id === conversationId);
    if (!target) return;
    updateConversationStatus(conversationId, target.status === 'closed' ? 'open' : 'closed');
  };

  const transferConversation = (conversationId: string) => {
    storeTransferConversation(conversationId, 'queue-support');
    toast.info(t('omnichannel.conversations.transferTitle'), t('omnichannel.conversations.transferDescription'));
  };

  const toggleVipTag = (conversationId: string) => {
    const target = conversations.find((conversation) => conversation.id === conversationId);
    if (!target) return;
    if (target.tagIds.includes('tag-vip')) {
      removeConversationTag(conversationId, 'tag-vip');
    } else {
      addConversationTag(conversationId, 'tag-vip');
    }
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
          <div>
            <h1 className="text-2xl font-bold">{t('omnichannel.conversations.title')}</h1>
            <p className="mt-1 text-white/80">{t('omnichannel.conversations.subtitle')}</p>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {stats.map((item) => {
            const Icon = item.icon;
            return (
              <Card key={item.id} className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group cursor-pointer" onClick={item.onClick}>
                <CardContent className="p-6">
                  <div className="relative z-10 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-semibold text-gray-500">{item.label}</div>
                      <div className="mt-1 text-2xl font-bold text-gray-950 dark:text-white bidi-isolate">{item.value}</div>
                    </div>
                  </div>
                  <Icon className="absolute ltr:-right-4 rtl:-left-4 -bottom-4 h-24 w-24 text-blue-500/10 group-hover:scale-110 transition-transform duration-300" />
                </CardContent>
              </Card>
            );
          })}
        </div>

      <OmnichannelSectionCard title={t('omnichannel.conversations.tableTitle')} description={t('omnichannel.conversations.tableDescription')}>
        <div className="mb-4 grid gap-3 lg:grid-cols-6">
          <label className="rounded-lg border border-gray-200 px-3 py-2 dark:border-gray-800">
            <div className="mb-1 text-xs font-semibold text-gray-500">{t('omnichannel.inbox.search')}</div>
            <div className="flex items-center gap-2">
              <Search className="h-4 w-4 text-gray-400" />
              <input
                value={filters.query ?? ''}
                onChange={(event) => setFilters((current) => ({ ...current, query: event.target.value }))}
                className="w-full bg-transparent text-sm outline-none"
                placeholder={t('omnichannel.inbox.searchPlaceholder')}
              />
            </div>
          </label>
          <FilterSelect
            label={t('omnichannel.inbox.channel')}
            value={channelFilter}
            onChange={setChannelFilter}
            options={[
              { value: '', label: t('common.all') },
              { value: 'whatsapp', label: getChannelLabel('whatsapp') },
              { value: 'website_chat', label: getChannelLabel('website_chat') },
              { value: 'email', label: getChannelLabel('email') },
              { value: 'instagram_dm', label: getChannelLabel('instagram_dm') },
            ]}
          />
          <FilterSelect
            label={t('common.status')}
            value={statusFilter}
            onChange={setStatusFilter}
            options={[
              { value: '', label: t('common.all') },
              { value: 'open', label: t(statusLabelKeys.open) },
              { value: 'pending', label: t(statusLabelKeys.pending) },
              { value: 'waiting_customer', label: t(statusLabelKeys.waiting_customer) },
              { value: 'waiting_agent', label: t(statusLabelKeys.waiting_agent) },
              { value: 'closed', label: t(statusLabelKeys.closed) },
            ]}
          />
          <FilterSelect
            label={t('omnichannel.inbox.priority')}
            value={priorityFilter}
            onChange={setPriorityFilter}
            options={[
              { value: '', label: t('common.all') },
              { value: 'low', label: t(priorityLabelKeys.low) },
              { value: 'normal', label: t(priorityLabelKeys.normal) },
              { value: 'high', label: t(priorityLabelKeys.high) },
              { value: 'urgent', label: t(priorityLabelKeys.urgent) },
            ]}
          />
          <FilterSelect
            label={t('omnichannel.inbox.sla')}
            value={slaFilter}
            onChange={setSlaFilter}
            options={[
              { value: '', label: t('common.all') },
              { value: 'ok', label: t(slaLabelKeys.ok) },
              { value: 'at_risk', label: t(slaLabelKeys.at_risk) },
              { value: 'breached', label: t(slaLabelKeys.breached) },
              { value: 'paused', label: t(slaLabelKeys.paused) },
            ]}
          />
          <FilterSelect
            label={t('omnichannel.inbox.assignedStaff')}
            value={staffFilter}
            onChange={setStaffFilter}
            options={[
              { value: '', label: t('common.all') },
              { value: 'Mahmoud', label: 'Mahmoud Khalil' },
              { value: 'Layla', label: 'Layla Ramadan' },
              { value: 'Super', label: 'Super Admin' },
            ]}
          />
        </div>

        <OmnichannelStateNotice
          title={t('omnichannel.conversations.bulkActionBar')}
          description={`${selectedIds.length} ${t('omnichannel.conversations.selectedRows')}`}
          action={
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="ghost" onClick={() => setSelectedIds([])}>
                {t('omnichannel.actions.clearSelection')}
              </Button>
              <Button size="sm" variant="ghost" disabled={!selectedIds.length} onClick={() => setBulkAction('assign')}>
                {t('omnichannel.actions.bulkAssign')}
              </Button>
              <Button size="sm" variant="ghost" disabled={!selectedIds.length} onClick={() => setBulkAction('status')}>
                {t('omnichannel.actions.bulkChangeStatus')}
              </Button>
              <Button size="sm" variant="ghost" disabled={!selectedIds.length} onClick={() => setBulkAction('tag')}>
                {t('omnichannel.actions.bulkTag')}
              </Button>
              <Button size="sm" variant="outline" onClick={() => setSelectedIds(filtered.map((item) => item.id))}>
                {t('omnichannel.conversations.selectFiltered')}
              </Button>
            </div>
          }
        />

        {filtered.length === 0 ? (
          <div className="mt-4">
            <OmnichannelEmptyStateCard
              title={t('omnichannel.conversations.emptyTitle')}
              description={t('omnichannel.conversations.emptyDescription')}
              action={
                <Button size="sm" onClick={() => {
                  setFilters({});
                  setStatusFilter('');
                  setPriorityFilter('');
                  setStaffFilter('');
                  setChannelFilter('');
                  setSlaFilter('');
                }}>
                  {t('omnichannel.actions.clearFilters')}
                </Button>
              }
            />
          </div>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="text-xs uppercase tracking-wide text-gray-500">
                <tr>
                  <th className="px-3 py-2 text-start"></th>
                  <th className="px-3 py-2 text-start">{t('omnichannel.conversations.conversation')}</th>
                  <th className="px-3 py-2 text-start">{t('omnichannel.inbox.channel')}</th>
                  <th className="px-3 py-2 text-start">{t('common.status')}</th>
                  <th className="px-3 py-2 text-start">{t('omnichannel.inbox.priority')}</th>
                  <th className="px-3 py-2 text-start">{t('omnichannel.inbox.sla')}</th>
                  <th className="px-3 py-2 text-start">{t('omnichannel.inbox.assignedStaff')}</th>
                  <th className="px-3 py-2 text-start">{t('omnichannel.conversations.linkedRecordColumn')}</th>
                  <th className="px-3 py-2 text-start">{t('omnichannel.conversations.actionsColumn')}</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((conversation) => {
                  const linkedRecord = conversation.linkedRecords[0];
                  const selected = selectedIds.includes(conversation.id);
                  const hasVipTag = conversation.tagIds.includes('tag-vip');

                  return (
                    <tr key={conversation.id} className="border-t border-gray-100 align-top dark:border-gray-800">
                      <td className="px-3 py-3">
                        <input
                          type="checkbox"
                          checked={selected}
                          onChange={() => toggleSelection(conversation.id)}
                          className="h-4 w-4 rounded border-gray-300"
                        />
                      </td>
                      <td className="px-3 py-3">
                        <div className="font-semibold text-gray-900 dark:text-white ltr-value">{conversation.id}</div>
                        <div className="text-xs text-gray-500">{conversation.customer.name}</div>
                        <div className="mt-1 text-xs text-gray-500">{conversation.subject}</div>
                      </td>
                      <td className="px-3 py-3">{getChannelLabel(conversation.channelType)}</td>
                      <td className="px-3 py-3">
                        <StatusBadge variant="blue">{t(statusLabelKeys[conversation.status])}</StatusBadge>
                      </td>
                      <td className="px-3 py-3">
                        <button type="button" onClick={() => cyclePriority(conversation.id)}>
                          <StatusBadge variant={conversation.priority === 'urgent' ? 'rose' : conversation.priority === 'high' ? 'amber' : 'gray'}>
                            {t(priorityLabelKeys[conversation.priority])}
                          </StatusBadge>
                        </button>
                      </td>
                      <td className="px-3 py-3">
                        <StatusBadge variant={conversation.sla.status === 'breached' ? 'rose' : conversation.sla.status === 'at_risk' ? 'amber' : 'emerald'}>
                          {t(slaLabelKeys[conversation.sla.status])}
                        </StatusBadge>
                      </td>
                      <td className="px-3 py-3">{conversation.assignedStaffName ?? t('omnichannel.inbox.unassigned')}</td>
                      <td className="px-3 py-3">
                        {linkedRecord ? (
                          <div>
                            <div className="font-medium text-gray-900 dark:text-white">{linkedRecord.label}</div>
                            <div className="text-xs text-gray-500">{t(linkedRecordLabelKeys[linkedRecord.type])}</div>
                          </div>
                        ) : (
                          t('omnichannel.conversation.noLinkedRecords')
                        )}
                      </td>
                      <td className="px-3 py-3">
                        <TableActionsDropdown
                          actions={[
                            {
                              label: t('omnichannel.actions.openConversation'),
                              icon: MessageCircle,
                              onClick: () => navigate(`/omnichannel/inbox/${conversation.id}`)
                            },
                            {
                              label: 'Open chat screen',
                              icon: Eye,
                              onClick: () => navigate(`/omnichannel/inbox/${conversation.id}/chat`)
                            },
                            {
                              label: conversation.status === 'closed' ? t('omnichannel.actions.reopenConversation') : t('omnichannel.actions.closeConversation'),
                              icon: XCircle,
                              onClick: () => toggleStatus(conversation.id)
                            },
                            {
                              label: t('omnichannel.actions.transferConversation'),
                              icon: UserRoundCheck,
                              onClick: () => transferConversation(conversation.id)
                            },
                            {
                              label: hasVipTag ? t('omnichannel.actions.removeTag') : t('omnichannel.actions.addTag'),
                              icon: Tag,
                              onClick: () => toggleVipTag(conversation.id)
                            },
                            {
                              label: t('omnichannel.actions.viewAudit'),
                              icon: History,
                              onClick: () => setActiveConversation(conversation)
                            }
                          ]}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        <div className="mt-4 rounded-lg border border-dashed border-gray-200 p-4 text-sm text-gray-500 dark:border-gray-800">
          {t('omnichannel.conversations.auditSummary')}:{' '}
          <span className="font-semibold">{filtered.filter((item) => item.status === 'escalated').length}</span>
        </div>
      </OmnichannelSectionCard>

      <Modal isOpen={bulkAction !== null} onClose={() => setBulkAction(null)} title={t('omnichannel.conversations.bulkEditorTitle')} size="md">
        <div className="space-y-4">
          {bulkAction === 'assign' ? (
            <FilterSelect
              label={t('omnichannel.inbox.assignedStaff')}
              value={bulkValue}
              onChange={setBulkValue}
              options={[
                { value: '', label: t('omnichannel.common.selectOption') },
                { value: 'Mahmoud Khalil', label: 'Mahmoud Khalil' },
                { value: 'Layla Ramadan', label: 'Layla Ramadan' },
                { value: 'Super Admin', label: 'Super Admin' },
              ]}
            />
          ) : null}
          {bulkAction === 'status' ? (
            <FilterSelect
              label={t('common.status')}
              value={bulkValue}
              onChange={setBulkValue}
              options={[
                { value: '', label: t('omnichannel.common.selectOption') },
                { value: 'open', label: t(statusLabelKeys.open) },
                { value: 'pending', label: t(statusLabelKeys.pending) },
                { value: 'closed', label: t(statusLabelKeys.closed) },
              ]}
            />
          ) : null}
          {bulkAction === 'tag' ? (
            <FilterSelect
              label={t('omnichannel.tags.title')}
              value={bulkValue}
              onChange={setBulkValue}
              options={[
                { value: '', label: t('omnichannel.common.selectOption') },
                ...mockOmnichannelTags.map((tag) => ({ value: tag.id, label: tag.label.en })),
              ]}
            />
          ) : null}
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setBulkAction(null)}>
              {t('common.cancel')}
            </Button>
            <Button disabled={!bulkValue} onClick={applyBulkAction}>
              {t('omnichannel.actions.apply')}
            </Button>
          </div>
        </div>
      </Modal>

      <Modal isOpen={Boolean(activeConversation)} onClose={() => setActiveConversation(null)} title={t('omnichannel.conversations.auditDrawerTitle')} size="lg">
        {activeConversation ? (
          <div className="space-y-4">
            <div className="rounded-lg border border-gray-200 p-4 dark:border-gray-800">
              <div className="font-semibold text-gray-900 dark:text-white">{activeConversation.subject}</div>
              <div className="mt-1 text-sm text-gray-500 ltr-value">{activeConversation.id}</div>
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              <div className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                <div className="text-xs font-semibold text-gray-500">{t('omnichannel.conversations.currentOwner')}</div>
                <div className="mt-1 text-sm text-gray-900 dark:text-white">{activeConversation.assignedStaffName ?? t('omnichannel.inbox.unassigned')}</div>
              </div>
              <div className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                <div className="text-xs font-semibold text-gray-500">{t('omnichannel.conversations.currentTags')}</div>
                <div className="mt-1 text-sm text-gray-900 dark:text-white">{activeConversation.tagIds.length}</div>
              </div>
            </div>
            <div className="flex justify-end">
              <Button variant="outline" onClick={() => setActiveConversation(null)}>
                {t('common.close')}
              </Button>
            </div>
          </div>
        ) : null}
      </Modal>
      </div>
    </div>
  );
};

const FilterSelect: React.FC<{
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: Array<{ value: string; label: string }>;
}> = ({ label, value, onChange, options }) => (
  <label className="rounded-lg border border-gray-200 px-3 py-2 dark:border-gray-800">
    <div className="mb-1 text-xs font-semibold text-gray-500">{label}</div>
    <select value={value} onChange={(event) => onChange(event.target.value)} className="w-full bg-transparent text-sm outline-none">
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  </label>
);
