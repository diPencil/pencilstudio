import React, { useState } from 'react';
import { Megaphone, Plus } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { OmnichannelDrawer, OmnichannelStateNotice } from './OmnichannelInteractions';
import { OmnichannelSectionCard } from './OmnichannelUi';
import {
  mockOmnichannelBroadcasts,
  mockOmnichannelLabels,
  mockOmnichannelTemplates,
} from '../../services/omnichannelMockData';
import { Button } from '../ui/Button';
import { getChannelLabel } from '../../utils/omnichannelLinks';
import { useToastContext } from '../../contexts/ToastContext';
import type { OmnichannelBroadcastCampaign } from '../../types/omnichannel';
import { validateBroadcastDraft } from '../../utils/omnichannelIntegration';
import { cn } from '../../utils/cn';

interface BroadcastDraft {
  audienceSegmentId: string;
  channelType: string;
  templateId: string;
  scheduledAt: string;
}

const emptyDraft: BroadcastDraft = {
  audienceSegmentId: '',
  channelType: '',
  templateId: '',
  scheduledAt: '',
};

export const OmnichannelBroadcastsPage: React.FC = () => {
  const { t, locale, direction } = useLocale();
  const isRTL = direction === 'rtl';
  const toast = useToastContext();
  const {
    broadcasts: campaigns,
    templates,
    addBroadcast,
    updateBroadcast,
    cancelBroadcast,
    duplicateBroadcast: storeDuplicateBroadcast,
  } = useOmnichannelMockStore();
  const [draft, setDraft] = useState<BroadcastDraft>(emptyDraft);
  const [selectedCampaign, setSelectedCampaign] = useState<OmnichannelBroadcastCampaign | null>(null);
  const eligibleTemplates = templates.filter((template) =>
    !draft.channelType || template.channelTypes.includes(draft.channelType as OmnichannelBroadcastCampaign['channelType'])
  );

  const createCampaign = () => {
    const validation = validateBroadcastDraft(
      {
        audienceSegmentId: draft.audienceSegmentId,
        channelType: draft.channelType as OmnichannelBroadcastCampaign['channelType'],
        templateId: draft.templateId,
        scheduledAt: draft.scheduledAt,
      },
      mockOmnichannelTemplates
    );

    if (!validation.valid) {
      toast.warning(t('omnichannel.broadcasts.validationTitle'), t('omnichannel.broadcasts.validationDescription'));
      return;
    }
    addBroadcast({
      name: `Broadcast ${campaigns.length + 1}`,
      audienceSegmentId: draft.audienceSegmentId,
      channelType: draft.channelType as OmnichannelBroadcastCampaign['channelType'],
      templateId: draft.templateId,
      scheduledAt: draft.scheduledAt,
      optInWarning: t('omnichannel.broadcasts.optInWarning'),
    });
    setDraft(emptyDraft);
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
          <div>
            <h1 className="text-2xl font-bold">{t('omnichannel.broadcasts.title')}</h1>
            <p className="text-blue-100 mt-1">{t('omnichannel.broadcasts.subtitle')}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button className="bg-white/10 text-white hover:bg-white/20 border-0" onClick={createCampaign}>
              <Plus className="h-4 w-4" />
              {t('omnichannel.actions.createCampaign')}
            </Button>
          </div>
        </div>
      <OmnichannelStateNotice
        tone="warning"
        title={t('omnichannel.broadcasts.optInWarningTitle')}
        description={t('omnichannel.broadcasts.optInWarning')}
      />

      <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <OmnichannelSectionCard title={t('omnichannel.broadcasts.campaignsTitle')}>
          <div className="space-y-3">
            {campaigns.map((campaign) => (
              <div key={campaign.id} className="rounded-lg border border-gray-100 p-4 dark:border-gray-800">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold text-gray-900 dark:text-white">{campaign.name}</div>
                    <div className="mt-1 text-xs text-gray-500">{`${getChannelLabel(campaign.channelType)} | ${campaign.scheduledAt}`}</div>
                  </div>
                  <span className="rounded-full bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 dark:bg-blue-900/30 dark:text-blue-200">{campaign.deliveryStatus}</span>
                </div>
                <div className="mt-2 text-sm text-amber-700 dark:text-amber-200">{campaign.optInWarning}</div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => setSelectedCampaign(campaign)}>{t('omnichannel.actions.viewDeliveryStatus')}</Button>
                  <Button size="sm" variant="ghost" onClick={() => {
                    storeDuplicateBroadcast(campaign.id);
                    toast.success(t('omnichannel.routing.ruleDuplicatedTitle'), t('omnichannel.routing.ruleDuplicatedDescription'));
                  }}>{t('omnichannel.actions.duplicateCampaign')}</Button>
                  <Button size="sm" variant="ghost" onClick={() => updateBroadcast(campaign.id, { deliveryStatus: 'scheduled' })}>{t('omnichannel.actions.scheduleMockCampaign')}</Button>
                  <Button size="sm" variant="ghost" onClick={() => cancelBroadcast(campaign.id)}>{t('omnichannel.actions.cancelCampaign')}</Button>
                </div>
              </div>
            ))}
          </div>
        </OmnichannelSectionCard>

        <OmnichannelSectionCard title={t('omnichannel.broadcasts.builderTitle')}>
          <div className="space-y-3">
            <FieldSelect label={t('omnichannel.broadcasts.audienceSegment')} value={draft.audienceSegmentId} onChange={(value) => setDraft((current) => ({ ...current, audienceSegmentId: value }))}>
              <option value="">{t('omnichannel.common.selectOption')}</option>
              {mockOmnichannelLabels.map((label) => (
                <option key={label.id} value={label.id}>
                  {locale === 'ar' ? label.name.ar : label.name.en}
                </option>
              ))}
            </FieldSelect>
            <FieldSelect label={t('omnichannel.broadcasts.channel')} value={draft.channelType} onChange={(value) => setDraft((current) => ({ ...current, channelType: value }))}>
              <option value="">{t('omnichannel.common.selectOption')}</option>
              <option value="whatsapp_business">{getChannelLabel('whatsapp_business')}</option>
              <option value="sms">{getChannelLabel('sms')}</option>
              <option value="email">{getChannelLabel('email')}</option>
            </FieldSelect>
            <FieldSelect label={t('omnichannel.broadcasts.template')} value={draft.templateId} onChange={(value) => setDraft((current) => ({ ...current, templateId: value }))}>
              <option value="">{t('omnichannel.common.selectOption')}</option>
              {eligibleTemplates.map((template) => (
                <option key={template.id} value={template.id}>
                  {locale === 'ar' ? template.title.ar : template.title.en}
                </option>
              ))}
            </FieldSelect>
            {draft.channelType && eligibleTemplates.length === 0 ? (
              <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-100">
                {t('omnichannel.broadcasts.noEligibleTemplates')}
              </div>
            ) : null}
            <label className="block">
              <div className="mb-1 text-xs font-semibold text-gray-500">{t('omnichannel.broadcasts.scheduledTime')}</div>
              <input value={draft.scheduledAt} onChange={(event) => setDraft((current) => ({ ...current, scheduledAt: event.target.value }))} type="datetime-local" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900" />
            </label>
            <Button variant="outline" className="w-full" onClick={createCampaign}>
              <Megaphone className="h-4 w-4" />
              {t('omnichannel.actions.scheduleMockCampaign')}
            </Button>
          </div>
        </OmnichannelSectionCard>
      </div>

      <OmnichannelDrawer
        isOpen={Boolean(selectedCampaign)}
        title={selectedCampaign?.name ?? ''}
        description={t('omnichannel.broadcasts.deliveryStatusTitle')}
        onClose={() => setSelectedCampaign(null)}
      >
        {selectedCampaign ? (
          <div className="space-y-3">
            <Metric label={t('omnichannel.broadcasts.sentCount')} value="0" />
            <Metric label={t('omnichannel.broadcasts.deliveredCount')} value="0" />
            <Metric label={t('omnichannel.broadcasts.failedCount')} value="0" />
            <Metric label={t('omnichannel.broadcasts.optedOutCount')} value="0" />
          </div>
        ) : null}
      </OmnichannelDrawer>
    </div>
  </div>
  );
};

const FieldSelect: React.FC<{
  label: string;
  value: string;
  onChange: (value: string) => void;
  children: React.ReactNode;
}> = ({ label, value, onChange, children }) => (
  <label className="block">
    <div className="mb-1 text-xs font-semibold text-gray-500">{label}</div>
    <select value={value} onChange={(event) => onChange(event.target.value)} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
      {children}
    </select>
  </label>
);

const Metric: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
    <div className="text-xs font-semibold text-gray-500">{label}</div>
    <div className="mt-1 text-sm text-gray-900 dark:text-white bidi-isolate">{value}</div>
  </div>
);
