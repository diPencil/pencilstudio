import React, { useMemo, useState } from 'react';
import { Plus, ShieldAlert, Trash2 } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { cn } from '../../utils/cn';
import { OmnichannelConfirmationModal, OmnichannelStateNotice } from './OmnichannelInteractions';
import { OmnichannelSectionCard } from './OmnichannelUi';
import {
  mockOmnichannelBusinessHours,
  mockOmnichannelEscalationSteps,
  mockOmnichannelHolidays,
  mockOmnichannelQueues,
  mockOmnichannelSlaPolicies,
} from '../../services/omnichannelMockData';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { useToastContext } from '../../contexts/ToastContext';
import type { OmnichannelChannelType, OmnichannelSlaPolicy } from '../../types/omnichannel';
import { simulateSlaPolicy } from '../../utils/omnichannelIntegration';
import { getChannelLabel } from '../../utils/omnichannelLinks';

interface SlaDraft {
  id?: string;
  name: string;
  queueId: string;
  firstResponseMinutes: string;
  resolutionMinutes: string;
}

const emptyDraft: SlaDraft = {
  name: '',
  queueId: '',
  firstResponseMinutes: '15',
  resolutionMinutes: '240',
};

export const OmnichannelSlaPage: React.FC = () => {
  const { t, locale, direction } = useLocale();
  const isRTL = direction === 'rtl' || locale === 'ar';
  const toast = useToastContext();
  const {
    slaPolicies: policies,
    addSlaPolicy,
    updateSlaPolicy,
    deleteSlaPolicy,
    enableSlaPolicy,
  } = useOmnichannelMockStore();
  const [businessHours, setBusinessHours] = useState(mockOmnichannelBusinessHours);
  const [holidays, setHolidays] = useState(mockOmnichannelHolidays);
  const [draft, setDraft] = useState<SlaDraft>(emptyDraft);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingPolicyId, setEditingPolicyId] = useState<string | null>(null);
  const [deletePolicyId, setDeletePolicyId] = useState<string | null>(null);
  const [simulatedChannel, setSimulatedChannel] = useState('whatsapp');
  const [simulatedPriority, setSimulatedPriority] = useState('high');
  const [incomingTime, setIncomingTime] = useState('09:30');
  const [simulatorResult, setSimulatorResult] = useState<string | null>(null);

  const localized = (value: { en: string; ar: string }) => (locale === 'ar' ? value.ar : value.en);

  const selectedQueueName = useMemo(
    () => mockOmnichannelQueues.find((queue) => queue.id === draft.queueId)?.name,
    [draft.queueId]
  );

  const openEditor = (policy?: OmnichannelSlaPolicy) => {
    if (!policy) {
      setDraft(emptyDraft);
      setEditingPolicyId(null);
      setEditorOpen(true);
      return;
    }

    setDraft({
      id: policy.id,
      name: localized(policy.name),
      queueId: policy.queueId,
      firstResponseMinutes: String(policy.firstResponseMinutes),
      resolutionMinutes: String(policy.resolutionMinutes),
    });
    setEditingPolicyId(policy.id);
    setEditorOpen(true);
  };

  const savePolicy = () => {
    const firstResponseMinutes = Number(draft.firstResponseMinutes);
    const resolutionMinutes = Number(draft.resolutionMinutes);
    if (!draft.name.trim() || !draft.queueId) {
      toast.warning(t('omnichannel.sla.validationTitle'), t('omnichannel.sla.validationRequired'));
      return;
    }
    if (firstResponseMinutes <= 0 || resolutionMinutes <= firstResponseMinutes) {
      toast.warning(t('omnichannel.sla.validationTitle'), t('omnichannel.sla.validationImpossibleTimes'));
      return;
    }

    const nextPolicy = {
      name: { en: draft.name, ar: draft.name },
      queueId: draft.queueId,
      priority: 'high' as const,
      firstResponseMinutes,
      resolutionMinutes,
      businessHoursId: businessHours[0]?.id ?? 'bh-sales-weekday',
      status: 'active' as const,
    };

    if (editingPolicyId) {
      updateSlaPolicy(editingPolicyId, nextPolicy);
    } else {
      addSlaPolicy(nextPolicy);
    }
    setEditorOpen(false);
    setDraft(emptyDraft);
  };

  const simulateSla = () => {
    const matchedPolicy = policies.find((policy) => policy.priority === simulatedPriority) ?? policies[0];
    if (!matchedPolicy) {
      setSimulatorResult(t('omnichannel.sla.simulatorNoPolicy'));
      return;
    }
    const incomingAt = new Date(`2026-06-29T${incomingTime}:00`);
    const result = simulateSlaPolicy(matchedPolicy, incomingAt, businessHours, holidays);
    setSimulatorResult(
      `${localized(matchedPolicy.name)} | ${getChannelLabel(simulatedChannel as OmnichannelChannelType)} | ${result.firstResponseDueAt} | ${result.breachRisk}`
    );
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
          <div>
            <h1 className="text-2xl font-bold">{t('omnichannel.sla.title')}</h1>
            <p className="mt-2 text-blue-100 opacity-90">{t('omnichannel.sla.subtitle')}</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => openEditor()} className="bg-white/10 text-white hover:bg-white/20 border-transparent">
              <Plus className="h-4 w-4" />
              {t('omnichannel.actions.createPolicy')}
            </Button>
          </div>
        </div>
      <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <OmnichannelSectionCard title={t('omnichannel.sla.policiesTitle')}>
          <div className="space-y-3">
            {policies.map((policy) => (
              <div key={policy.id} className="rounded-lg border border-gray-100 p-4 dark:border-gray-800">
                <div className="flex items-center justify-between gap-3">
                  <div className="font-semibold text-gray-900 dark:text-white">{localized(policy.name)}</div>
                  <Button size="sm" variant="ghost" onClick={() => enableSlaPolicy(policy.id, policy.status !== 'active')}>
                    {policy.status === 'active' ? t('omnichannel.actions.disable') : t('omnichannel.actions.enable')}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => {
                    addSlaPolicy({
                      name: { en: `${policy.name.en} Copy`, ar: `${policy.name.ar} نسخة` },
                      queueId: policy.queueId,
                      priority: policy.priority,
                      firstResponseMinutes: policy.firstResponseMinutes,
                      resolutionMinutes: policy.resolutionMinutes,
                      businessHoursId: policy.businessHoursId,
                      status: 'draft',
                    });
                    toast.success(t('omnichannel.routing.ruleDuplicatedTitle'), t('omnichannel.routing.ruleDuplicatedDescription'));
                  }}>{t('omnichannel.actions.duplicatePolicy')}</Button>
                </div>
                <div className="mt-3 grid gap-3 md:grid-cols-3">
                  <Metric label={t('omnichannel.sla.firstResponse')} value={`${policy.firstResponseMinutes}m`} />
                  <Metric label={t('omnichannel.sla.resolution')} value={`${policy.resolutionMinutes}m`} />
                  <Metric label={t('omnichannel.sla.assignedTeam')} value={mockOmnichannelQueues.find((queue) => queue.id === policy.queueId)?.id ?? policy.queueId} />
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => openEditor(policy)}>{t('common.edit')}</Button>
                  <Button size="sm" variant="ghost" onClick={() => setDeletePolicyId(policy.id)}>
                    <Trash2 className="h-4 w-4" />
                    {t('common.delete')}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </OmnichannelSectionCard>

        <OmnichannelSectionCard title={t('omnichannel.sla.simulatorTitle')}>
          <div className="space-y-3">
            <select value={simulatedPriority} onChange={(event) => setSimulatedPriority(event.target.value)} className="w-full rounded-lg border border-gray-200 px-3 py-2 dark:border-gray-800 dark:bg-gray-900">
              <option value="low">{t('omnichannel.priority.low')}</option>
              <option value="normal">{t('omnichannel.priority.normal')}</option>
              <option value="high">{t('omnichannel.priority.high')}</option>
              <option value="urgent">{t('omnichannel.priority.urgent')}</option>
            </select>
            <select value={simulatedChannel} onChange={(event) => setSimulatedChannel(event.target.value)} className="w-full rounded-lg border border-gray-200 px-3 py-2 dark:border-gray-800 dark:bg-gray-900">
              <option value="whatsapp">WhatsApp</option>
              <option value="website_chat">{getChannelLabel('website_chat')}</option>
              <option value="email">{getChannelLabel('email')}</option>
            </select>
            <input value={incomingTime} onChange={(event) => setIncomingTime(event.target.value)} type="time" className="w-full rounded-lg border border-gray-200 px-3 py-2 dark:border-gray-800 dark:bg-gray-900" />
            <Button variant="outline" onClick={simulateSla}>{t('omnichannel.actions.runSimulator')}</Button>
            <div className="rounded-lg border border-dashed border-gray-200 p-4 text-sm text-gray-600 dark:border-gray-800 dark:text-gray-300">
              {simulatorResult ?? t('omnichannel.sla.simulatorResult')}
            </div>
          </div>
        </OmnichannelSectionCard>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <OmnichannelSectionCard title={t('omnichannel.sla.businessHoursTitle')}>
          <div className="space-y-3">
            {businessHours.map((hours) => (
              <div key={hours.id} className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                <div className="font-semibold text-gray-900 dark:text-white">{localized(hours.name)}</div>
                <div className="mt-1 text-sm text-gray-500 ltr-value">{`${hours.startTime} - ${hours.endTime}`}</div>
              </div>
            ))}
          </div>
        </OmnichannelSectionCard>

        <OmnichannelSectionCard title={t('omnichannel.sla.holidaysTitle')}>
          <div className="space-y-3">
            {holidays.map((holiday) => (
              <div key={holiday.id} className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                <div className="font-semibold text-gray-900 dark:text-white">{localized(holiday.name)}</div>
                <div className="mt-1 text-sm text-gray-500 ltr-value">{holiday.date}</div>
              </div>
            ))}
          </div>
        </OmnichannelSectionCard>

        <OmnichannelSectionCard title={t('omnichannel.sla.escalationLadder')}>
          <div className="space-y-3">
            {mockOmnichannelEscalationSteps.map((step) => (
              <div key={step.id} className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                <div className="flex items-center justify-between gap-3">
                  <div className="font-semibold text-gray-900 dark:text-white">{`${t('omnichannel.sla.level')} ${step.level}`}</div>
                  <ShieldAlert className="h-4 w-4 text-blue-600" />
                </div>
                <div className="mt-1 text-sm text-gray-500">{step.roleName}</div>
                <div className="mt-1 text-xs text-gray-500 bidi-isolate">{`${step.responseMinutes}m`}</div>
              </div>
            ))}
          </div>
        </OmnichannelSectionCard>
      </div>

      <OmnichannelStateNotice
        tone="info"
        title={t('omnichannel.sla.businessRulesTitle')}
        description={t('omnichannel.sla.businessRulesDescription')}
      />

      <Modal isOpen={editorOpen} onClose={() => setEditorOpen(false)} title={t('omnichannel.sla.policyEditorTitle')} size="lg">
        <div className="space-y-4">
          <label className="block">
            <div className="mb-1 text-xs font-semibold text-gray-500">{t('common.title')}</div>
            <input value={draft.name} onChange={(event) => setDraft((current) => ({ ...current, name: event.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900" />
          </label>
          <select value={draft.queueId} onChange={(event) => setDraft((current) => ({ ...current, queueId: event.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
            <option value="">{t('omnichannel.common.selectOption')}</option>
            {mockOmnichannelQueues.map((queue) => (
              <option key={queue.id} value={queue.id}>
                {localized(queue.name)}
              </option>
            ))}
          </select>
          <div className="grid gap-4 md:grid-cols-2">
            <input value={draft.firstResponseMinutes} onChange={(event) => setDraft((current) => ({ ...current, firstResponseMinutes: event.target.value }))} type="number" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900" />
            <input value={draft.resolutionMinutes} onChange={(event) => setDraft((current) => ({ ...current, resolutionMinutes: event.target.value }))} type="number" className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900" />
          </div>
          {selectedQueueName ? (
            <div className="rounded-lg border border-gray-200 p-3 text-sm text-gray-600 dark:border-gray-800 dark:text-gray-300">
              {localized(selectedQueueName)}
            </div>
          ) : null}
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setEditorOpen(false)}>{t('common.cancel')}</Button>
            <Button onClick={savePolicy}>{t('common.save')}</Button>
          </div>
        </div>
      </Modal>

      <OmnichannelConfirmationModal
        isOpen={Boolean(deletePolicyId)}
        title={t('omnichannel.sla.deleteTitle')}
        description={t('omnichannel.sla.deleteDescription')}
        confirmLabel={t('common.delete')}
        tone="danger"
        onClose={() => setDeletePolicyId(null)}
        onConfirm={() => {
          if (deletePolicyId) {
            deleteSlaPolicy(deletePolicyId);
            toast.success(t('omnichannel.routing.ruleDeletedTitle'), t('omnichannel.routing.ruleDeletedDescription'));
          }
          setDeletePolicyId(null);
        }}
      />
      </div>
    </div>
  );
};

const Metric: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
    <div className="text-xs font-semibold text-gray-500">{label}</div>
    <div className="mt-1 text-xl font-bold text-gray-900 dark:text-white bidi-isolate">{value}</div>
  </div>
);
