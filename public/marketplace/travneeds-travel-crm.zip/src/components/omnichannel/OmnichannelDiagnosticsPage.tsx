import React, { useState } from 'react';
import {
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Info,
  Activity,
  FileText,
} from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';
import { OmnichannelModuleShell } from './OmnichannelModuleShell';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { runOmnichannelSelfTests, type SelfTestResult } from '../../utils/omnichannelSelfTests';

export const OmnichannelDiagnosticsPage: React.FC = () => {
  const { t, locale, direction } = useLocale();
  const store = useOmnichannelMockStore();
  const [isRunning, setIsRunning] = useState(false);
  const [tests, setTests] = useState<SelfTestResult[]>([]);

  const runAllTests = async () => {
    if (isRunning) return;
    setIsRunning(true);
    setTests([]);

    const resultsList: SelfTestResult[] = [];
    const collectResult = (res: SelfTestResult) => {
      resultsList.push(res);
      setTests([...resultsList]);
    };

    try {
      await runOmnichannelSelfTests(store, collectResult);
    } catch (err: unknown) {
      console.error('Test execution crash:', err);
    } finally {
      setIsRunning(false);
    }
  };

  const resetMockData = () => {
    store.resetAllMockStore();
    setTests([]);
  };

  const total = tests.length;
  const passed = tests.filter((t) => t.status === 'passed').length;
  const failed = tests.filter((t) => t.status === 'failed').length;
  const partial = tests.filter((t) => t.status === 'partial').length;
  const snapshotOnly = tests.filter((t) => t.status === 'snapshot_only').length;

  return (
      <div className="w-full pb-8" dir={direction}>
        <div className="mx-auto max-w-[1400px] space-y-6">
        {/* Header Summary */}
        <div className={cn("flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", direction === 'rtl' && "md:flex-row-reverse")}>
          <div className={cn("space-y-1", direction === 'rtl' ? "text-right" : "text-left")}>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
              {t('omnichannel.diagnostics.title')}
            </h2>
            <p className="mt-1 text-sm text-blue-100 opacity-90">
              {t('omnichannel.diagnostics.subtitle')}
            </p>
          </div>
          <div className={cn("flex items-center gap-2 sm:gap-3 banner-actions", direction === 'rtl' && "flex-row-reverse")}>
            <button
              onClick={runAllTests}
              disabled={isRunning}
              className={`px-4 py-2 rounded-xl font-medium text-sm flex items-center gap-2 transition ${
                isRunning
                  ? 'bg-blue-700 text-blue-300 cursor-not-allowed'
                  : 'bg-white text-blue-600 hover:bg-gray-100'
              }`}
            >
              <Play className="w-4 h-4" />
              {isRunning ? t('omnichannel.diagnostics.running') : t('omnichannel.diagnostics.runAll')}
            </button>
            <button
              onClick={resetMockData}
              disabled={isRunning}
              className="px-4 py-2 border border-white/30 hover:bg-white/20 rounded-xl font-medium text-sm text-white flex items-center gap-2 transition"
            >
              <RotateCcw className="w-4 h-4" />
              {t('omnichannel.diagnostics.resetStore')}
            </button>
          </div>
        </div>

        {/* Notices */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <div className="space-y-1 text-sm text-amber-800">
              <span className="font-semibold">{t('omnichannel.diagnostics.status')}</span>
              <p>{t('omnichannel.diagnostics.warning')}</p>
            </div>
          </div>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex gap-3">
            <Info className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
            <div className="space-y-1 text-sm text-blue-800">
              <span className="font-semibold">Visual Handoff Notice</span>
              <p>{t('omnichannel.diagnostics.manualQAPrompt')}</p>
            </div>
          </div>
        </div>

        {/* Counts Panels */}
        {total > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
            <div className="bg-white p-4 border border-gray-100 rounded-lg text-center shadow-xs">
              <span className="text-2xl font-bold text-gray-800">{total}</span>
              <div className="text-xs text-gray-500 mt-1">{t('omnichannel.diagnostics.totalTests')}</div>
            </div>
            <div className="bg-green-50 p-4 border border-green-100 rounded-lg text-center shadow-xs">
              <span className="text-2xl font-bold text-green-700">{passed}</span>
              <div className="text-xs text-green-600 mt-1">{t('omnichannel.diagnostics.passed')}</div>
            </div>
            <div className="bg-red-50 p-4 border border-red-100 rounded-lg text-center shadow-xs">
              <span className="text-2xl font-bold text-red-700">{failed}</span>
              <div className="text-xs text-red-600 mt-1">{t('omnichannel.diagnostics.failed')}</div>
            </div>
            <div className="bg-amber-50 p-4 border border-amber-100 rounded-lg text-center shadow-xs">
              <span className="text-2xl font-bold text-amber-700">{partial}</span>
              <div className="text-xs text-amber-600 mt-1">{t('omnichannel.diagnostics.partial')}</div>
            </div>
            <div className="bg-blue-50 p-4 border border-blue-100 rounded-lg text-center shadow-xs">
              <span className="text-2xl font-bold text-blue-700">{snapshotOnly}</span>
              <div className="text-xs text-blue-600 mt-1">{t('omnichannel.diagnostics.snapshotOnly')}</div>
            </div>
          </div>
        )}

        {/* Results List */}
        <div className="bg-white rounded-lg border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 flex items-center gap-2 bg-gray-50">
            <FileText className="w-4 h-4 text-gray-600" />
            <h3 className="font-semibold text-gray-700">Test Cases Execution</h3>
          </div>
          {tests.length === 0 ? (
            <div className="p-8 text-center text-gray-400 text-sm">
              Click &quot;{t('omnichannel.diagnostics.runAll')}&quot; to start programmatic validation.
            </div>
          ) : (
            <div className="divide-y divide-gray-100 overflow-x-auto">
              <table className="min-w-full text-left border-collapse">
                <thead className="bg-gray-50/50 text-xs font-semibold text-gray-500 uppercase">
                  <tr>
                    <th className="px-6 py-3">{t('omnichannel.diagnostics.group')}</th>
                    <th className="px-6 py-3">{t('omnichannel.diagnostics.test')}</th>
                    <th className="px-6 py-3">{t('omnichannel.diagnostics.status')}</th>
                    <th className="px-6 py-3">{t('omnichannel.diagnostics.expected')}</th>
                    <th className="px-6 py-3">{t('omnichannel.diagnostics.actual')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-sm">
                  {tests.map((test) => (
                    <tr key={test.id} className="hover:bg-gray-50/50">
                      <td className="px-6 py-4 font-medium text-gray-600">{test.groupName}</td>
                      <td className="px-6 py-4 font-semibold text-gray-800">{test.name}</td>
                      <td className="px-6 py-4">
                        <span
                          className={`px-2 py-1 text-xs rounded-full font-medium ${
                            test.status === 'passed'
                              ? 'bg-green-100 text-green-800'
                              : test.status === 'failed'
                              ? 'bg-red-100 text-red-800'
                              : test.status === 'partial'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          {test.status === 'passed'
                            ? t('omnichannel.diagnostics.passed')
                            : test.status === 'failed'
                            ? t('omnichannel.diagnostics.failed')
                            : test.status === 'partial'
                            ? t('omnichannel.diagnostics.partial')
                            : t('omnichannel.diagnostics.snapshotOnly')}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-xs text-gray-500">{test.expected}</td>
                      <td className="px-6 py-4 text-xs text-gray-800">
                        <div>{test.actual}</div>
                        {test.errorMessage && (
                          <div className="text-red-600 mt-1 font-mono text-[11px] bg-red-50 p-2 rounded border border-red-100">
                            {t('omnichannel.diagnostics.error')}: {test.errorMessage}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Activity Logs Preview */}
        <div className="bg-white rounded-lg border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-gray-600" />
              <h3 className="font-semibold text-gray-700">Audit Logs (Activity Center Stream)</h3>
            </div>
            <span className="text-xs text-gray-400 font-mono">Live Logs: {store.activityLogs.length}</span>
          </div>
          <div className="p-4 max-h-60 overflow-y-auto space-y-2 font-mono text-xs text-gray-600">
            {store.activityLogs.length === 0 ? (
              <div className="text-center py-4 text-gray-400">No logs captured. Run tests to see stream.</div>
            ) : (
              [...store.activityLogs].reverse().map((log) => (
                <div key={log.id} className="border-b border-gray-50 pb-2 last:border-0">
                  <span className="text-gray-400">[{log.timestamp}]</span>{' '}
                  <span className="text-indigo-600 font-semibold">{log.actorName}</span>{' '}
                  <span className="bg-gray-100 px-1 py-0.5 rounded text-[10px] uppercase">{log.category}</span>{' '}
                  <span className="text-gray-800">{log.summary}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
