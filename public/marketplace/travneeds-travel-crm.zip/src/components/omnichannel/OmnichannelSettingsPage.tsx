import React, { useEffect, useMemo, useState } from 'react';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { useLocale } from '../../localization/useLocale';
import { OmnichannelConfirmationModal, OmnichannelStateNotice } from './OmnichannelInteractions';
import { OmnichannelSectionCard } from './OmnichannelUi';
import { mockOmnichannelSettings } from '../../services/omnichannelMockData';
import { Button } from '../ui/Button';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';

export const OmnichannelSettingsPage: React.FC = () => {
  const { t, direction } = useLocale();
  const isRTL = direction === 'rtl';
  const toast = useToastContext();
  const {
    settings: storeSettings,
    saveSettings,
    resetSettings: storeResetSettings,
  } = useOmnichannelMockStore();
  const [settings, setSettings] = useState(storeSettings);

  useEffect(() => {
    setSettings(storeSettings);
  }, [storeSettings]);
  const [draftClosingReason, setDraftClosingReason] = useState('');
  const [deleteReason, setDeleteReason] = useState<string | null>(null);

  const dirty = useMemo(
    () => JSON.stringify(settings) !== JSON.stringify(mockOmnichannelSettings),
    [settings]
  );

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
          <div>
            <h1 className="text-2xl font-bold">{t('omnichannel.settings.title')}</h1>
            <p className="text-blue-100 mt-1">{t('omnichannel.settings.subtitle')}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button className="bg-white/10 text-white hover:bg-white/20 border-0" onClick={() => storeResetSettings()}>
              {t('omnichannel.actions.resetMock')}
            </Button>
            <Button className="bg-white/10 text-white hover:bg-white/20 border-0" onClick={() => {
              saveSettings(settings);
              toast.success(t('omnichannel.settings.savedTitle'), t('omnichannel.settings.savedDescription'));
            }}>
              {t('common.save')}
            </Button>
          </div>
        </div>
      {dirty ? (
        <OmnichannelStateNotice
          tone="warning"
          title={t('omnichannel.settings.dirtyTitle')}
          description={t('omnichannel.settings.dirtyDescription')}
        />
      ) : null}

      <div className="grid gap-4 xl:grid-cols-2">
        <OmnichannelSectionCard title={t('omnichannel.settings.generalSettings')}>
          <FormRow label={t('omnichannel.settings.defaultAssignmentPolicy')} value={settings.defaultAssignmentPolicy} onChange={(value) => setSettings((current) => ({ ...current, defaultAssignmentPolicy: value }))} />
          <FormRow label={t('omnichannel.settings.defaultSla')} value={settings.defaultSlaPolicyId} onChange={(value) => setSettings((current) => ({ ...current, defaultSlaPolicyId: value }))} />
          <FormRow label={t('omnichannel.settings.languageFallback')} value={settings.languageFallback} onChange={(value) => setSettings((current) => ({ ...current, languageFallback: value as typeof settings.languageFallback }))} />
          <FormRow label={t('omnichannel.settings.identityMergeRule')} value={settings.identityMergeRule} onChange={(value) => setSettings((current) => ({ ...current, identityMergeRule: value as typeof settings.identityMergeRule }))} />
        </OmnichannelSectionCard>

        <OmnichannelSectionCard title={t('omnichannel.settings.notificationPreferences')}>
          <ToggleRow label={t('omnichannel.settings.emailNotifications')} checked={settings.notificationEmail} onChange={(checked) => setSettings((current) => ({ ...current, notificationEmail: checked }))} />
          <ToggleRow label={t('omnichannel.settings.browserNotifications')} checked={settings.notificationBrowser} onChange={(checked) => setSettings((current) => ({ ...current, notificationBrowser: checked }))} />
          <ToggleRow label={t('omnichannel.settings.consentOptIn')} checked={settings.consentOptInRequired} onChange={(checked) => setSettings((current) => ({ ...current, consentOptInRequired: checked }))} />
        </OmnichannelSectionCard>

        <OmnichannelSectionCard title={t('omnichannel.settings.retentionAndIdentity')}>
          <FormRow label={t('omnichannel.settings.dataRetention')} value={String(settings.dataRetentionDays)} onChange={(value) => setSettings((current) => ({ ...current, dataRetentionDays: Number(value) || current.dataRetentionDays }))} />
          <FormRow label={t('omnichannel.settings.internalNoteVisibility')} value={settings.internalNoteVisibility} onChange={(value) => setSettings((current) => ({ ...current, internalNoteVisibility: value as typeof settings.internalNoteVisibility }))} />
          <FormRow label={t('omnichannel.settings.defaultSla')} value={settings.defaultSlaPolicyId} onChange={(value) => setSettings((current) => ({ ...current, defaultSlaPolicyId: value }))} />
        </OmnichannelSectionCard>

        <OmnichannelSectionCard title={t('omnichannel.settings.closingReasons')}>
          <div className="space-y-2">
            {settings.closeReasons.map((reason) => (
              <div key={reason} className="flex items-center justify-between gap-3 rounded-lg border border-gray-100 px-3 py-2 text-sm dark:border-gray-800">
                <span>{reason}</span>
                <Button size="sm" variant="ghost" onClick={() => setDeleteReason(reason)}>{t('common.delete')}</Button>
              </div>
            ))}
          </div>
          <div className="mt-4 flex gap-2">
            <input value={draftClosingReason} onChange={(event) => setDraftClosingReason(event.target.value)} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900" placeholder={t('omnichannel.settings.closingReasonPlaceholder')} />
            <Button
              onClick={() => {
                if (!draftClosingReason.trim()) {
                  return;
                }
                setSettings((current) => ({ ...current, closeReasons: [...current.closeReasons, draftClosingReason.trim()] }));
                setDraftClosingReason('');
              }}
            >
              {t('omnichannel.actions.addClosingReason')}
            </Button>
          </div>
        </OmnichannelSectionCard>
      </div>

      <OmnichannelConfirmationModal
        isOpen={Boolean(deleteReason)}
        title={t('omnichannel.settings.deleteReasonTitle')}
        description={t('omnichannel.settings.deleteReasonDescription')}
        confirmLabel={t('common.delete')}
        tone="danger"
        onClose={() => setDeleteReason(null)}
        onConfirm={() => {
          setSettings((current) => ({ ...current, closeReasons: current.closeReasons.filter((reason) => reason !== deleteReason) }));
          setDeleteReason(null);
        }}
      />
      </div>
    </div>
  );
};

const FormRow: React.FC<{ label: string; value: string; onChange: (value: string) => void }> = ({ label, value, onChange }) => (
  <label className="mb-3 block">
    <div className="mb-1 text-xs font-semibold text-gray-500">{label}</div>
    <input value={value} onChange={(event) => onChange(event.target.value)} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900" />
  </label>
);

const ToggleRow: React.FC<{ label: string; checked: boolean; onChange: (checked: boolean) => void }> = ({ label, checked, onChange }) => (
  <label className="mb-3 flex items-center justify-between gap-3 rounded-lg border border-gray-100 px-3 py-2 dark:border-gray-800">
    <span className="text-sm text-gray-700 dark:text-gray-200">{label}</span>
    <input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} className="h-4 w-4 rounded border-gray-300" />
  </label>
);
