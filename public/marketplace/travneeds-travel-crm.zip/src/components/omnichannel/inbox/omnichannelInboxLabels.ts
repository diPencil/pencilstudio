import type { TranslationKey } from '../../../localization/messages';
import type {
  OmnichannelChannelType,
  OmnichannelConnectionStatus,
  OmnichannelConversationStatus,
  OmnichannelHealthStatus,
  OmnichannelLinkedRecordType,
  OmnichannelMessage,
  OmnichannelPriority,
  OmnichannelRuleStatus,
  OmnichannelSlaStatus,
} from '../../../types/omnichannel';
import type { BadgeVariant } from '../../ui/StatusBadge';

export const channelLabelKeys: Record<OmnichannelChannelType, TranslationKey> = {
  whatsapp: 'omnichannel.channel.whatsapp',
  whatsapp_business: 'omnichannel.channel.whatsappBusiness',
  facebook_messenger: 'omnichannel.channel.facebookMessenger',
  instagram_dm: 'omnichannel.channel.instagramDm',
  instagram_comment: 'omnichannel.channel.instagramComment',
  website_chat: 'omnichannel.channel.websiteChat',
  email: 'omnichannel.channel.email',
  sms: 'omnichannel.channel.sms',
  phone: 'omnichannel.channel.phone',
  future: 'omnichannel.channel.future',
};

export const statusLabelKeys: Record<OmnichannelConversationStatus, TranslationKey> = {
  open: 'omnichannel.status.open',
  pending: 'omnichannel.status.pending',
  waiting_agent: 'omnichannel.status.waitingAgent',
  waiting_customer: 'omnichannel.status.waitingCustomer',
  closed: 'omnichannel.status.closed',
  escalated: 'omnichannel.status.escalated',
};

export const priorityLabelKeys: Record<OmnichannelPriority, TranslationKey> = {
  low: 'omnichannel.priority.low',
  normal: 'omnichannel.priority.normal',
  high: 'omnichannel.priority.high',
  urgent: 'omnichannel.priority.urgent',
};

export const slaLabelKeys: Record<OmnichannelSlaStatus, TranslationKey> = {
  ok: 'omnichannel.sla.ok',
  at_risk: 'omnichannel.sla.atRisk',
  breached: 'omnichannel.sla.breached',
  paused: 'omnichannel.sla.paused',
  none: 'omnichannel.sla.none',
};

export const linkedRecordLabelKeys: Record<OmnichannelLinkedRecordType, TranslationKey> = {
  lead: 'omnichannel.record.lead',
  customer: 'omnichannel.record.customer',
  reservation: 'omnichannel.record.reservation',
  sales_case: 'omnichannel.record.salesCase',
  quotation: 'omnichannel.record.quotation',
  support_ticket: 'omnichannel.record.supportTicket',
};

export const deliveryLabelKeys: Record<NonNullable<OmnichannelMessage['deliveryStatus']>, TranslationKey> = {
  sending: 'omnichannel.delivery.sending',
  sent: 'omnichannel.delivery.sent',
  delivered: 'omnichannel.delivery.delivered',
  read: 'omnichannel.delivery.read',
  failed: 'omnichannel.delivery.failed',
};

export const connectionStatusLabelKeys: Record<OmnichannelConnectionStatus, TranslationKey> = {
  connected: 'omnichannel.channels.connection.connected',
  sync_warning: 'omnichannel.channels.connection.syncWarning',
  disconnected: 'omnichannel.channels.connection.disconnected',
  pending_setup: 'omnichannel.channels.connection.pendingSetup',
  planned: 'omnichannel.channels.connection.planned',
};

export const healthStatusLabelKeys: Record<OmnichannelHealthStatus, TranslationKey> = {
  healthy: 'omnichannel.channels.health.healthy',
  degraded: 'omnichannel.channels.health.degraded',
  critical: 'omnichannel.channels.health.critical',
  offline: 'omnichannel.channels.health.offline',
  planned: 'omnichannel.channels.health.planned',
};

export const routingStatusLabelKeys: Record<OmnichannelRuleStatus, TranslationKey> = {
  active: 'omnichannel.routing.status.active',
  paused: 'omnichannel.routing.status.paused',
  draft: 'omnichannel.routing.status.draft',
};

export const onlineStatusLabelKeys: Record<'online' | 'offline' | 'busy', TranslationKey> = {
  online: 'omnichannel.common.online',
  offline: 'common.inactive',
  busy: 'omnichannel.common.busy',
};

export const tagGroupLabelKeys: Record<'tag' | 'segment' | 'priority_label' | 'sla_label', TranslationKey> = {
  tag: 'omnichannel.tags.group.tag',
  segment: 'omnichannel.tags.group.segment',
  priority_label: 'omnichannel.tags.group.priority',
  sla_label: 'omnichannel.tags.group.sla',
};

export const statusVariants: Record<OmnichannelConversationStatus, BadgeVariant> = {
  open: 'blue',
  pending: 'amber',
  waiting_agent: 'rose',
  waiting_customer: 'purple',
  closed: 'emerald',
  escalated: 'rose',
};

export const priorityVariants: Record<OmnichannelPriority, BadgeVariant> = {
  low: 'gray',
  normal: 'blue',
  high: 'amber',
  urgent: 'rose',
};

export const slaVariants: Record<OmnichannelSlaStatus, BadgeVariant> = {
  ok: 'emerald',
  at_risk: 'amber',
  breached: 'rose',
  paused: 'purple',
  none: 'gray',
};
