import React from 'react';
import { ExternalLink, Link2, RotateCcw } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLocale } from '../../../localization/useLocale';
import type { OmnichannelLinkedRecord } from '../../../types/omnichannel';
import { getLinkedRecordUrl } from '../../../utils/omnichannelLinks';
import { linkedRecordLabelKeys, priorityLabelKeys } from './omnichannelInboxLabels';
import { Button } from '../../ui/Button';
import { StatusBadge } from '../../ui/StatusBadge';

interface OmnichannelLinkedRecordsPanelProps {
  records: OmnichannelLinkedRecord[];
  removedRecords: OmnichannelLinkedRecord[];
  onUnlinkRecord: (record: OmnichannelLinkedRecord) => void;
  onRestoreRecord: (record: OmnichannelLinkedRecord) => void;
}

export const OmnichannelLinkedRecordsPanel: React.FC<OmnichannelLinkedRecordsPanelProps> = ({
  records,
  removedRecords,
  onUnlinkRecord,
  onRestoreRecord,
}) => {
  const { t } = useLocale();

  return (
    <section className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
      <div className="mb-3 flex items-center gap-2">
        <Link2 className="h-4 w-4 text-blue-600" />
        <h3 className="text-sm font-bold text-gray-900 dark:text-white">{t('omnichannel.conversation.linkedRecords')}</h3>
      </div>
      <div className="space-y-2">
        {records.length > 0 ? records.map((record) => (
          <div key={`${record.type}-${record.id}`} className="rounded-lg border border-gray-100 p-3 text-sm dark:border-gray-800">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 space-y-2">
                <div>
                  <div className="text-xs font-semibold text-gray-500">{t(linkedRecordLabelKeys[record.type])}</div>
                  <div className="truncate font-bold text-gray-900 dark:text-white">{record.label}</div>
                  <div className="mt-0.5 text-xs text-gray-500 ltr-value">{record.id}</div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {record.status && <StatusBadge variant="blue">{record.status}</StatusBadge>}
                  {record.priority && <StatusBadge variant={record.priority === 'urgent' ? 'rose' : record.priority === 'high' ? 'amber' : 'gray'}>{t(priorityLabelKeys[record.priority])}</StatusBadge>}
                  {record.stage && <StatusBadge variant="purple">{record.stage}</StatusBadge>}
                </div>
                <div className="grid gap-1 text-xs text-gray-500">
                  {record.ownerName && <div>{t('omnichannel.conversion.owner')}: <span className="bidi-isolate">{record.ownerName}</span></div>}
                  {record.teamName && <div>{t('omnichannel.conversion.team')}: <span className="bidi-isolate">{record.teamName}</span></div>}
                  {record.createdAt && <div>{t('omnichannel.conversion.createdAt')}: <span className="ltr-value">{new Date(record.createdAt).toLocaleDateString()}</span></div>}
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <Link to={getLinkedRecordUrl(record)} className="inline-flex rounded-md p-1.5 text-blue-600 hover:bg-blue-50" title={t('omnichannel.actions.viewMockRecord')}>
                  <ExternalLink className="h-4 w-4" />
                </Link>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link
                to={getLinkedRecordUrl(record)}
                className="inline-flex items-center justify-center rounded-lg px-3 py-1.5 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-800"
              >
                {t('omnichannel.actions.viewMockRecord')}
              </Link>
              <Button type="button" size="sm" variant="ghost" onClick={() => onUnlinkRecord(record)} className="text-rose-600 hover:bg-rose-50 hover:text-rose-700">
                {t('omnichannel.actions.unlinkRecord')}
              </Button>
            </div>
          </div>
        )) : (
          <div className="rounded-lg border border-dashed border-gray-200 p-4 text-sm text-gray-500 dark:border-gray-800">
            {t('omnichannel.conversation.noLinkedRecords')}
          </div>
        )}

        {removedRecords.length > 0 && (
          <div className="space-y-2 pt-2">
            <div className="text-xs font-semibold uppercase tracking-wide text-gray-500">{t('omnichannel.conversion.recentlyRemoved')}</div>
            {removedRecords.map((record) => (
              <div key={`removed-${record.type}-${record.id}`} className="rounded-lg border border-dashed border-gray-200 p-3 text-sm dark:border-gray-800">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-gray-500">{t(linkedRecordLabelKeys[record.type])}</div>
                    <div className="truncate font-bold text-gray-900 dark:text-white">{record.label}</div>
                    <div className="mt-0.5 text-xs text-gray-500 ltr-value">{record.id}</div>
                  </div>
                  <RotateCcw className="mt-0.5 h-4 w-4 text-blue-600" />
                </div>
                <Button type="button" size="sm" variant="outline" className="mt-3" onClick={() => onRestoreRecord(record)}>
                  {t('omnichannel.actions.restoreLink')}
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
