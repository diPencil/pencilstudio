import React from 'react';
import { Mail, MessageCircle, Phone, Radio, Send, Wifi } from 'lucide-react';
import { StatusBadge } from '../../ui/StatusBadge';
import { cn } from '../../../utils/cn';
import { useLocale } from '../../../localization/useLocale';
import type { OmnichannelChannelType, OmnichannelConversation } from '../../../types/omnichannel';
import { channelLabelKeys, priorityLabelKeys, priorityVariants, slaLabelKeys, slaVariants, statusLabelKeys, statusVariants } from './omnichannelInboxLabels';

interface OmnichannelConversationCardProps {
  conversation: OmnichannelConversation;
  isSelected: boolean;
  onSelect: (conversationId: string) => void;
}

const channelIcons: Record<OmnichannelChannelType, React.ElementType> = {
  whatsapp: MessageCircle,
  whatsapp_business: MessageCircle,
  facebook_messenger: Send,
  instagram_dm: Send,
  instagram_comment: MessageCircle,
  website_chat: Wifi,
  email: Mail,
  sms: MessageCircle,
  phone: Phone,
  future: Radio,
};

const formatSlaTimer = (minutes: number) => {
  if (minutes <= 0) {
    return '00:00';
  }

  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  return `${hours.toString().padStart(2, '0')}:${remainingMinutes.toString().padStart(2, '0')}`;
};

export const OmnichannelConversationCard: React.FC<OmnichannelConversationCardProps> = ({ conversation, isSelected, onSelect }) => {
  const { t, direction } = useLocale();
  const Icon = channelIcons[conversation.channelType];
  const linkedRecord = conversation.linkedRecords[0];

  return (
    <button
      type="button"
      onClick={() => onSelect(conversation.id)}
      className={cn(
        'w-full rounded-lg border bg-white p-3 text-start transition-colors dark:bg-gray-900',
        isSelected
          ? 'border-blue-300 bg-blue-50/70 shadow-sm dark:border-blue-700 dark:bg-blue-950/20'
          : 'border-gray-200 hover:border-blue-200 hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-800/60'
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 items-start gap-3">
          <div className="mt-0.5 rounded-lg bg-gray-100 p-2 text-gray-600 dark:bg-gray-800 dark:text-gray-300">
            <Icon className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <span className="truncate text-sm font-bold text-gray-900 dark:text-white">{conversation.customer.name}</span>
              <StatusBadge variant="gray">{t(channelLabelKeys[conversation.channelType])}</StatusBadge>
            </div>
            <p className="mt-1 line-clamp-2 text-xs text-gray-500 dark:text-gray-400">{conversation.lastMessagePreview}</p>
          </div>
        </div>
        {conversation.unreadCount > 0 && (
          <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-blue-600 px-1.5 text-[10px] font-bold text-white bidi-isolate">
            {conversation.unreadCount}
          </span>
        )}
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        <StatusBadge variant={statusVariants[conversation.status]}>{t(statusLabelKeys[conversation.status])}</StatusBadge>
        <StatusBadge variant={priorityVariants[conversation.priority]}>{t(priorityLabelKeys[conversation.priority])}</StatusBadge>
        <StatusBadge variant={slaVariants[conversation.sla.status]}>{t(slaLabelKeys[conversation.sla.status])}</StatusBadge>
      </div>

      <div className="mt-3 grid gap-1 text-xs text-gray-500">
        <div className="flex items-center justify-between gap-2">
          <span>{t('omnichannel.inbox.assignedStaff')}</span>
          <span className="truncate font-medium text-gray-700 dark:text-gray-300">{conversation.assignedStaffName ?? t('omnichannel.inbox.unassigned')}</span>
        </div>
        <div className="flex items-center justify-between gap-2">
          <span>{t('omnichannel.inbox.slaTimer')}</span>
          <span className="ltr-value">{formatSlaTimer(conversation.sla.firstResponseRemainingMinutes || conversation.sla.resolutionRemainingMinutes)}</span>
        </div>
        {linkedRecord && (
          <div className="flex items-center justify-between gap-2">
            <span>{t('omnichannel.inbox.linkedRecord')}</span>
            <span className="truncate ltr-value">{linkedRecord.id}</span>
          </div>
        )}
        <div className="flex items-center justify-between gap-2">
          <span>{t('omnichannel.inbox.lastActivity')}</span>
          <span className={cn('ltr-value', direction === 'rtl' && 'text-left')}>{new Date(conversation.lastMessageAt).toLocaleString()}</span>
        </div>
      </div>
    </button>
  );
};
