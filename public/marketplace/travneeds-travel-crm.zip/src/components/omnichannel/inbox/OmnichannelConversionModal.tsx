import React, { useEffect, useMemo, useState } from 'react';
import { Input } from '../../ui/Input';
import { Select } from '../../ui/Select';
import { Modal } from '../../ui/Modal';
import { Button } from '../../ui/Button';
import { useLocale } from '../../../localization/useLocale';
import type {
  OmnichannelConversation,
  OmnichannelConversionDraft,
  OmnichannelConversionMode,
  OmnichannelConversionSubmitPayload,
  OmnichannelLinkedRecord,
} from '../../../types/omnichannel';
import { linkedRecordLabelKeys, statusLabelKeys } from './omnichannelInboxLabels';

interface OmnichannelConversionModalProps {
  isOpen: boolean;
  mode: OmnichannelConversionMode;
  conversation: OmnichannelConversation;
  staffOptions: ReadonlyArray<{ id: string; name: string; department: string }>;
  teamOptions: Array<{ id: string; label: string }>;
  existingRecords: OmnichannelLinkedRecord[];
  onClose: () => void;
  onSubmit: (payload: OmnichannelConversionSubmitPayload) => Promise<void>;
}

type ValidationErrors = Partial<Record<keyof OmnichannelConversionDraft, string>>;

const buildInitialDraft = (conversation: OmnichannelConversation, mode: OmnichannelConversionMode): OmnichannelConversionDraft => ({
  mode,
  customerName: conversation.customer.name,
  phone: conversation.customer.phone ?? '',
  email: conversation.customer.email ?? '',
  channelIdentity: conversation.customer.phone ?? conversation.customer.email ?? conversation.customer.name,
  companyName: conversation.customer.name.includes('Co') || conversation.customer.name.includes('Inc') ? conversation.customer.name : '',
  leadSource: '',
  leadStage: '',
  ticketPriority: conversation.priority,
  ticketCategory: '',
  caseType: '',
  assignedStaffId: conversation.assignedStaffId ?? '',
  assignedTeamId: conversation.queueId,
  notes: '',
  existingRecordKey: '',
});

export const OmnichannelConversionModal: React.FC<OmnichannelConversionModalProps> = ({
  isOpen,
  mode,
  conversation,
  staffOptions,
  teamOptions,
  existingRecords,
  onClose,
  onSubmit,
}) => {
  const { t, direction, isRTL } = useLocale();
  const [draft, setDraft] = useState<OmnichannelConversionDraft>(buildInitialDraft(conversation, mode));
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setDraft(buildInitialDraft(conversation, mode));
      setErrors({});
    }
  }, [conversation, isOpen, mode]);

  const existingRecordOptions = useMemo(
    () => existingRecords.map((record) => ({ key: `${record.type}:${record.id}`, record })),
    [existingRecords]
  );

  const setField = <K extends keyof OmnichannelConversionDraft>(field: K, value: OmnichannelConversionDraft[K]) => {
    setDraft((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
  };

  const validate = (): boolean => {
    const nextErrors: ValidationErrors = {};

    if (!draft.customerName.trim()) {
      nextErrors.customerName = t('omnichannel.conversion.validation.customerName');
    }

    if (mode === 'convert_lead') {
      if (!draft.leadSource.trim()) {
        nextErrors.leadSource = t('omnichannel.conversion.validation.leadSource');
      }
      if (!draft.leadStage.trim()) {
        nextErrors.leadStage = t('omnichannel.conversion.validation.leadStage');
      }
    }

    if (mode === 'create_ticket') {
      if (!draft.ticketCategory.trim()) {
        nextErrors.ticketCategory = t('omnichannel.conversion.validation.ticketCategory');
      }
      if (!draft.assignedStaffId) {
        nextErrors.assignedStaffId = t('omnichannel.conversion.validation.assignedStaff');
      }
    }

    if (mode === 'create_case') {
      if (!draft.caseType.trim()) {
        nextErrors.caseType = t('omnichannel.conversion.validation.caseType');
      }
      if (!draft.assignedStaffId) {
        nextErrors.assignedStaffId = t('omnichannel.conversion.validation.assignedStaff');
      }
    }

    if (mode === 'link_existing' && !draft.existingRecordKey) {
      nextErrors.existingRecordKey = t('omnichannel.conversion.validation.existingRecord');
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!validate()) {
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit({
        ...draft,
        conversationId: conversation.id,
      });
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  const titleKeyByMode: Record<OmnichannelConversionMode, string> = {
    convert_lead: 'omnichannel.conversion.mode.convertLead',
    convert_customer: 'omnichannel.conversion.mode.convertCustomer',
    create_ticket: 'omnichannel.conversion.mode.createTicket',
    create_case: 'omnichannel.conversion.mode.createCase',
    link_existing: 'omnichannel.conversion.mode.linkExisting',
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={t(titleKeyByMode[mode])} size="xl">
      <form className="space-y-6" onSubmit={handleSubmit}>
        <section className="rounded-lg border border-gray-200 bg-gray-50 p-4 dark:border-gray-700 dark:bg-gray-900/60">
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-xs font-semibold text-gray-500">{t('omnichannel.conversion.sourceConversation')}</div>
              <div className="mt-1 font-semibold text-gray-900 dark:text-white ltr-value">{conversation.id}</div>
            </div>
            <div>
              <div className="text-xs font-semibold text-gray-500">{t('omnichannel.conversion.channelIdentity')}</div>
              <div className="mt-1 text-sm text-gray-900 dark:text-white bidi-isolate">{draft.channelIdentity || t('omnichannel.common.notAvailable')}</div>
            </div>
            <div>
              <div className="text-xs font-semibold text-gray-500">{t('omnichannel.conversion.subject')}</div>
              <div className="mt-1 text-sm text-gray-900 dark:text-white">{conversation.subject}</div>
            </div>
            <div>
              <div className="text-xs font-semibold text-gray-500">{t('omnichannel.conversion.currentStatus')}</div>
              <div className="mt-1 text-sm text-gray-900 dark:text-white">{t(statusLabelKeys[conversation.status])}</div>
            </div>
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-2">
          <Input
            label={t('omnichannel.conversion.customerName')}
            value={draft.customerName}
            onChange={(event) => setField('customerName', event.target.value)}
            error={errors.customerName}
          />
          <Input
            label={t('omnichannel.conversion.companyName')}
            value={draft.companyName}
            onChange={(event) => setField('companyName', event.target.value)}
          />
          <Input
            label={t('omnichannel.conversion.phone')}
            type="tel"
            value={draft.phone}
            onChange={(event) => setField('phone', event.target.value)}
          />
          <Input
            label={t('omnichannel.conversion.email')}
            type="email"
            value={draft.email}
            onChange={(event) => setField('email', event.target.value)}
          />
        </section>

        {mode === 'convert_lead' && (
          <section className="grid gap-4 md:grid-cols-2">
            <Input
              label={t('omnichannel.conversion.leadSource')}
              value={draft.leadSource}
              onChange={(event) => setField('leadSource', event.target.value)}
              error={errors.leadSource}
              placeholder={t('omnichannel.conversion.leadSourcePlaceholder')}
            />
            <Select
              label={t('omnichannel.conversion.leadStage')}
              value={draft.leadStage}
              onChange={(event) => setField('leadStage', event.target.value)}
              error={errors.leadStage}
            >
              <option value="">{t('omnichannel.common.selectOption')}</option>
              <option value="New">{t('omnichannel.conversion.stage.new')}</option>
              <option value="Qualified">{t('omnichannel.conversion.stage.qualified')}</option>
              <option value="Proposal Sent">{t('omnichannel.conversion.stage.proposalSent')}</option>
              <option value="Negotiation">{t('omnichannel.conversion.stage.negotiation')}</option>
            </Select>
          </section>
        )}

        {mode === 'create_ticket' && (
          <section className="grid gap-4 md:grid-cols-2">
            <Select
              label={t('omnichannel.conversion.ticketPriority')}
              value={draft.ticketPriority}
              onChange={(event) => setField('ticketPriority', event.target.value as OmnichannelConversionDraft['ticketPriority'])}
            >
              <option value="low">{t('omnichannel.priority.low')}</option>
              <option value="normal">{t('omnichannel.priority.normal')}</option>
              <option value="high">{t('omnichannel.priority.high')}</option>
              <option value="urgent">{t('omnichannel.priority.urgent')}</option>
            </Select>
            <Select
              label={t('omnichannel.conversion.ticketCategory')}
              value={draft.ticketCategory}
              onChange={(event) => setField('ticketCategory', event.target.value)}
              error={errors.ticketCategory}
            >
              <option value="">{t('omnichannel.common.selectOption')}</option>
              <option value="Reservation Support">{t('omnichannel.conversion.ticketCategoryReservation')}</option>
              <option value="Billing">{t('omnichannel.conversion.ticketCategoryBilling')}</option>
              <option value="Visa & Documents">{t('omnichannel.conversion.ticketCategoryVisa')}</option>
              <option value="Complaint">{t('omnichannel.conversion.ticketCategoryComplaint')}</option>
            </Select>
          </section>
        )}

        {mode === 'create_case' && (
          <section className="grid gap-4 md:grid-cols-2">
            <Select
              label={t('omnichannel.conversion.caseType')}
              value={draft.caseType}
              onChange={(event) => setField('caseType', event.target.value)}
              error={errors.caseType}
            >
              <option value="">{t('omnichannel.common.selectOption')}</option>
              <option value="Leisure Package">{t('omnichannel.conversion.caseTypeLeisure')}</option>
              <option value="Corporate Group">{t('omnichannel.conversion.caseTypeCorporate')}</option>
              <option value="Ticketing Request">{t('omnichannel.conversion.caseTypeTicketing')}</option>
              <option value="Custom Itinerary">{t('omnichannel.conversion.caseTypeCustom')}</option>
            </Select>
            <Select
              label={t('omnichannel.conversion.assignedTeam')}
              value={draft.assignedTeamId}
              onChange={(event) => setField('assignedTeamId', event.target.value)}
            >
              {teamOptions.map((team) => (
                <option key={team.id} value={team.id}>{team.label}</option>
              ))}
            </Select>
          </section>
        )}

        {mode === 'link_existing' && (
          <section>
            <Select
              label={t('omnichannel.conversion.existingRecord')}
              value={draft.existingRecordKey}
              onChange={(event) => setField('existingRecordKey', event.target.value)}
              error={errors.existingRecordKey}
            >
              <option value="">{t('omnichannel.common.selectOption')}</option>
              {existingRecordOptions.map((option) => (
                <option key={option.key} value={option.key}>
                  {`${t(linkedRecordLabelKeys[option.record.type])} - ${option.record.label}`}
                </option>
              ))}
            </Select>
          </section>
        )}

        {(mode === 'create_ticket' || mode === 'create_case' || mode === 'convert_customer') && (
          <section className="grid gap-4 md:grid-cols-2">
            <Select
              label={t('omnichannel.conversion.assignedStaff')}
              value={draft.assignedStaffId}
              onChange={(event) => setField('assignedStaffId', event.target.value)}
              error={errors.assignedStaffId}
            >
              <option value="">{t('omnichannel.common.selectOption')}</option>
              {staffOptions.map((staff) => (
                <option key={staff.id} value={staff.id}>{staff.name}</option>
              ))}
            </Select>
            <Select
              label={t('omnichannel.conversion.assignedTeam')}
              value={draft.assignedTeamId}
              onChange={(event) => setField('assignedTeamId', event.target.value)}
            >
              {teamOptions.map((team) => (
                <option key={team.id} value={team.id}>{team.label}</option>
              ))}
            </Select>
          </section>
        )}

        <section>
          <label className={`mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300 ${isRTL ? 'text-right' : ''}`}>
            {t('omnichannel.conversion.notes')}
          </label>
          <textarea
            dir={direction}
            rows={4}
            value={draft.notes}
            onChange={(event) => setField('notes', event.target.value)}
            className={`block w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-gray-900 shadow-sm focus:border-transparent focus:outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-white ${isRTL ? 'text-right' : ''}`}
            placeholder={t('omnichannel.conversion.notesPlaceholder')}
          />
        </section>

        <div className={`flex gap-3 border-t border-gray-200 pt-6 dark:border-gray-700 ${isRTL ? 'justify-start md:flex-row-reverse' : 'justify-end'}`}>
          <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
            {t('common.cancel')}
          </Button>
          <Button type="submit" loading={isSubmitting}>
            {t('omnichannel.actions.submitConversion')}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
