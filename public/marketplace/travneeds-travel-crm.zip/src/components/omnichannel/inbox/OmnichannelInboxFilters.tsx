import React, { useState, useRef, useEffect } from 'react';
import { Search, Filter, X } from 'lucide-react';
import { Select } from '../../ui/Select';
import { cn } from '../../../utils/cn';
import { useLocale } from '../../../localization/useLocale';
import type {
  OmnichannelChannelType,
  OmnichannelConversationFilters,
  OmnichannelConversationStatus,
  OmnichannelPriority,
  OmnichannelSlaStatus,
  OmnichannelTag,
} from '../../../types/omnichannel';
import { channelLabelKeys, priorityLabelKeys, slaLabelKeys, statusLabelKeys } from './omnichannelInboxLabels';

interface OmnichannelInboxFiltersProps {
  filters: OmnichannelConversationFilters;
  tags: OmnichannelTag[];
  onFiltersChange: (filters: OmnichannelConversationFilters) => void;
}

const channelOptions: OmnichannelChannelType[] = ['whatsapp', 'whatsapp_business', 'facebook_messenger', 'instagram_dm', 'instagram_comment', 'website_chat', 'email', 'sms', 'phone'];
const statusOptions: OmnichannelConversationStatus[] = ['open', 'pending', 'waiting_agent', 'waiting_customer', 'closed', 'escalated'];
const priorityOptions: OmnichannelPriority[] = ['low', 'normal', 'high', 'urgent'];
const slaOptions: OmnichannelSlaStatus[] = ['ok', 'at_risk', 'breached', 'paused', 'none'];

const firstValue = <T extends string,>(values: T[] | undefined) => values?.[0] ?? 'all';

export const OmnichannelInboxFilters: React.FC<OmnichannelInboxFiltersProps> = ({ filters, tags, onFiltersChange }) => {
  const { t, direction, locale, isRTL } = useLocale();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  return (
    <div className="flex items-center gap-3">
      {/* Search Input */}
      <div className="relative group">
         <Search className={cn("absolute top-1/2 -translate-y-1/2 h-4 w-4 text-white/70", isRTL ? "right-3" : "left-3")} />
         <input
           type="text"
           value={filters.query ?? ''}
           onChange={(e) => onFiltersChange({ ...filters, query: e.target.value })}
           placeholder={t('omnichannel.inbox.searchPlaceholder')}
           className={cn(
             "h-11 bg-white/10 border border-white/20 text-white placeholder:text-white/70 rounded-xl focus:outline-none focus:ring-2 focus:ring-white/50 transition-all w-full sm:w-64 backdrop-blur-sm",
             isRTL ? "pr-10 pl-4" : "pl-10 pr-4"
           )}
         />
      </div>

      {/* Filter Button */}
      <div className="relative" ref={dropdownRef}>
        <button
          onClick={() => setIsOpen(!isOpen)}
          title={t('common.filters')}
          className={cn(
            "h-11 w-11 flex items-center justify-center rounded-xl transition-all border tooltip-trigger backdrop-blur-sm",
            isOpen ? "bg-white text-blue-600 border-white shadow-md" : "bg-white/10 text-white border-white/20 hover:bg-white/20"
          )}
        >
          <Filter className="h-5 w-5" />
        </button>

        {/* Filter Dropdown */}
        {isOpen && (
          <div className={cn(
            "absolute top-full mt-3 w-[320px] sm:w-[500px] bg-white dark:bg-gray-900 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-800 p-6 z-[100] animate-in fade-in slide-in-from-top-4 duration-200",
            isRTL ? "left-0 sm:-left-2" : "right-0 sm:-right-2"
          )}>
            <div className="flex items-center justify-between mb-5 pb-4 border-b border-gray-100 dark:border-gray-800">
               <h3 className="font-bold text-gray-900 dark:text-white flex items-center gap-2">
                 <div className="bg-blue-50 dark:bg-blue-900/20 text-blue-600 p-2 rounded-lg">
                    <Filter className="h-4 w-4" />
                 </div>
                 {t('common.filters')}
               </h3>
               <button onClick={() => setIsOpen(false)} className="h-8 w-8 flex items-center justify-center rounded-full bg-gray-50 dark:bg-gray-800 text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
                 <X className="h-4 w-4" />
               </button>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5" dir={direction}>
              <Select
                label={t('omnichannel.inbox.channel')}
                value={firstValue(filters.channelTypes)}
                onChange={(event) => onFiltersChange({ ...filters, channelTypes: event.target.value === 'all' ? [] : [event.target.value as OmnichannelChannelType] })}
              >
                <option value="all">{t('common.all')}</option>
                {channelOptions.map((channel) => <option key={channel} value={channel}>{t(channelLabelKeys[channel])}</option>)}
              </Select>
              <Select
                label={t('common.status')}
                value={firstValue(filters.statuses)}
                onChange={(event) => onFiltersChange({ ...filters, statuses: event.target.value === 'all' ? [] : [event.target.value as OmnichannelConversationStatus] })}
              >
                <option value="all">{t('common.all')}</option>
                {statusOptions.map((status) => <option key={status} value={status}>{t(statusLabelKeys[status])}</option>)}
              </Select>
              <Select
                label={t('omnichannel.inbox.assignment')}
                value={filters.assignedState ?? 'all'}
                onChange={(event) => onFiltersChange({ ...filters, assignedState: event.target.value as OmnichannelConversationFilters['assignedState'] })}
              >
                <option value="all">{t('common.all')}</option>
                <option value="assigned">{t('omnichannel.inbox.assigned')}</option>
                <option value="unassigned">{t('omnichannel.inbox.unassigned')}</option>
              </Select>
              <Select
                label={t('omnichannel.inbox.priority')}
                value={firstValue(filters.priorities)}
                onChange={(event) => onFiltersChange({ ...filters, priorities: event.target.value === 'all' ? [] : [event.target.value as OmnichannelPriority] })}
              >
                <option value="all">{t('common.all')}</option>
                {priorityOptions.map((priority) => <option key={priority} value={priority}>{t(priorityLabelKeys[priority])}</option>)}
              </Select>
              <Select
                label={t('omnichannel.inbox.sla')}
                value={firstValue(filters.slaStatuses)}
                onChange={(event) => onFiltersChange({ ...filters, slaStatuses: event.target.value === 'all' ? [] : [event.target.value as OmnichannelSlaStatus] })}
              >
                <option value="all">{t('common.all')}</option>
                {slaOptions.map((sla) => <option key={sla} value={sla}>{t(slaLabelKeys[sla])}</option>)}
              </Select>
              <Select
                label={t('omnichannel.inbox.tags')}
                value={firstValue(filters.tagIds)}
                onChange={(event) => onFiltersChange({ ...filters, tagIds: event.target.value === 'all' ? [] : [event.target.value] })}
              >
                <option value="all">{t('common.all')}</option>
                {tags.map((tag) => <option key={tag.id} value={tag.id}>{tag.label[locale]}</option>)}
              </Select>
              
              <div className="sm:col-span-2 pt-2">
                <label className="inline-flex items-center gap-3 cursor-pointer group/toggle">
                  <div className="relative">
                    <input
                      type="checkbox"
                      checked={Boolean(filters.unreadOnly)}
                      onChange={(event) => onFiltersChange({ ...filters, unreadOnly: event.target.checked })}
                      className="peer sr-only"
                    />
                    <div className="h-6 w-11 rounded-full bg-gray-200 dark:bg-gray-700 peer-checked:bg-blue-600 transition-colors duration-300"></div>
                    <div className="absolute left-[2px] top-[2px] h-5 w-5 rounded-full bg-white transition-transform duration-300 peer-checked:translate-x-[20px] rtl:peer-checked:-translate-x-[20px] shadow-sm"></div>
                  </div>
                  <span className="text-sm font-bold text-gray-700 dark:text-gray-300 select-none group-hover/toggle:text-gray-900 dark:group-hover/toggle:text-white transition-colors">
                    {t('omnichannel.inbox.unread')}
                  </span>
                </label>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
