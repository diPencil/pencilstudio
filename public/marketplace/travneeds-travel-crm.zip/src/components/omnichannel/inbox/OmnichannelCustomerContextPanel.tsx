import React from 'react';
import { UserRound } from 'lucide-react';
import { StatusBadge } from '../../ui/StatusBadge';
import { useLocale } from '../../../localization/useLocale';
import type {
  OmnichannelConversation,
  OmnichannelConversionActivityEvent,
  OmnichannelConversionMode,
  OmnichannelInternalNote,
  OmnichannelConversationStatus,
  OmnichannelLinkedRecord,
} from '../../../types/omnichannel';
import { OmnichannelLinkedRecordsPanel } from './OmnichannelLinkedRecordsPanel';
import { OmnichannelQuickRepliesPanel } from './OmnichannelQuickRepliesPanel';
import { OmnichannelInternalNotesPanel } from './OmnichannelInternalNotesPanel';
import { OmnichannelAssignmentPanel } from './OmnichannelAssignmentPanel';
import { OmnichannelConversionPanel } from './OmnichannelConversionPanel';
import { OmnichannelConversionActivityPanel } from './OmnichannelConversionActivityPanel';
import { mockOmnichannelTemplates } from '../../../services/omnichannelMockData';

interface OmnichannelCustomerContextPanelProps {
  conversation: OmnichannelConversation;
  notes: OmnichannelInternalNote[];
  removedRecords: OmnichannelLinkedRecord[];
  activityEvents: OmnichannelConversionActivityEvent[];
  hasLinkableRecords: boolean;
  onInsertReply: (body: string) => void;
  onAddNote: (body: string) => void;
  onUpdateNote: (noteId: string, body: string) => void;
  onArchiveNote: (noteId: string) => void;
  onRestoreNote: (noteId: string) => void;
  onDeleteNote: (noteId: string) => void;
  onUnlinkRecord: (record: OmnichannelLinkedRecord) => void;
  onRestoreRecord: (record: OmnichannelLinkedRecord) => void;
  onStatusChange: (status: OmnichannelConversationStatus) => void;
  onPriorityChange: (priority: OmnichannelConversation['priority']) => void;
  onAssignStaff: (staffId: string) => void;
  onToggleReadState: () => void;
  onEscalate: () => void;
  onTransferConversation: () => void;
  onOpenConversion: (mode: OmnichannelConversionMode) => void;
}

export const OmnichannelCustomerContextPanel: React.FC<OmnichannelCustomerContextPanelProps> = ({
  conversation,
  notes,
  removedRecords,
  activityEvents,
  hasLinkableRecords,
  onInsertReply,
  onAddNote,
  onUpdateNote,
  onArchiveNote,
  onRestoreNote,
  onDeleteNote,
  onUnlinkRecord,
  onRestoreRecord,
  onStatusChange,
  onPriorityChange,
  onAssignStaff,
  onToggleReadState,
  onEscalate,
  onTransferConversation,
  onOpenConversion,
}) => {
  const { t } = useLocale();

  return (
    <aside className="space-y-4">
      <section className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
        <div className="mb-3 flex items-center gap-2">
          <UserRound className="h-4 w-4 text-blue-600" />
          <h3 className="text-sm font-bold text-gray-900 dark:text-white">{t('omnichannel.conversation.customerContext')}</h3>
        </div>
        <div className="space-y-2 text-sm">
          <div className="font-bold text-gray-900 dark:text-white">{conversation.customer.name}</div>
          <StatusBadge variant={conversation.customer.role === 'customer' ? 'emerald' : 'blue'}>
            {conversation.customer.role === 'customer' ? t('omnichannel.record.customer') : t('omnichannel.record.lead')}
          </StatusBadge>
          {conversation.customer.phone && <div className="text-gray-500">{t('omnichannel.conversation.phone')}: <span className="ltr-value">{conversation.customer.phone}</span></div>}
          {conversation.customer.email && <div className="text-gray-500">{t('omnichannel.conversation.email')}: <span className="ltr-value">{conversation.customer.email}</span></div>}
          <div className="text-gray-500">{t('omnichannel.conversation.language')}: <span className="bidi-isolate">{conversation.customer.preferredLanguage.toUpperCase()}</span></div>
          <div className="text-gray-500">{t('omnichannel.conversation.id')}: <span className="ltr-value">{conversation.id}</span></div>
        </div>
      </section>
      <OmnichannelAssignmentPanel
        status={conversation.status}
        priority={conversation.priority}
        assignedStaffId={conversation.assignedStaffId}
        unreadCount={conversation.unreadCount}
        onStatusChange={onStatusChange}
        onPriorityChange={onPriorityChange}
        onAssignStaff={onAssignStaff}
        onToggleReadState={onToggleReadState}
        onEscalate={onEscalate}
        onTransferConversation={onTransferConversation}
      />
      <OmnichannelConversionPanel
        conversation={conversation}
        removedRecords={removedRecords}
        hasLinkableRecords={hasLinkableRecords}
        onOpen={onOpenConversion}
      />
      <OmnichannelLinkedRecordsPanel
        records={conversation.linkedRecords}
        removedRecords={removedRecords}
        onUnlinkRecord={onUnlinkRecord}
        onRestoreRecord={onRestoreRecord}
      />
      <OmnichannelConversionActivityPanel events={activityEvents} />
      <OmnichannelQuickRepliesPanel channelType={conversation.channelType} templates={mockOmnichannelTemplates} onInsert={onInsertReply} />
      <OmnichannelInternalNotesPanel
        notes={notes}
        onAddNote={onAddNote}
        onUpdateNote={onUpdateNote}
        onArchiveNote={onArchiveNote}
        onRestoreNote={onRestoreNote}
        onDeleteNote={onDeleteNote}
      />
    </aside>
  );
};
