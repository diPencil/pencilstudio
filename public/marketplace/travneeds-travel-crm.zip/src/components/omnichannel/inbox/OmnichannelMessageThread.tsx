import React from 'react';
import type { OmnichannelMessage } from '../../../types/omnichannel';
import { useLocale } from '../../../localization/useLocale';
import { OmnichannelMessageBubble } from './OmnichannelMessageBubble';

interface OmnichannelMessageThreadProps {
  messages: OmnichannelMessage[];
  onRetryMessage: (messageId: string) => void;
}

export const OmnichannelMessageThread: React.FC<OmnichannelMessageThreadProps> = ({ messages, onRetryMessage }) => {
  const { t } = useLocale();

  return (
    <div className="min-h-0 flex-1 space-y-3 overflow-y-auto rounded-lg border border-gray-100 bg-gray-50 p-3 dark:border-gray-800 dark:bg-gray-950/40">
      {messages.length > 0 ? (
        messages.map((message) => <OmnichannelMessageBubble key={message.id} message={message} onRetryMessage={onRetryMessage} />)
      ) : (
        <div className="flex h-full items-center justify-center text-sm text-gray-500">{t('omnichannel.conversation.noMessages')}</div>
      )}
    </div>
  );
};
