import React from 'react';
import { Select } from '../../ui/Select';
import { useLocale } from '../../../localization/useLocale';
import type { OmnichannelConversationStatus, OmnichannelPriority } from '../../../types/omnichannel';
import { mockOmnichannelAssignableStaff } from '../../../services/omnichannelMockData';
import { priorityLabelKeys, statusLabelKeys } from './omnichannelInboxLabels';

interface OmnichannelAssignmentPanelProps {
  status: OmnichannelConversationStatus;
  priority: OmnichannelPriority;
  assignedStaffId?: string;
  unreadCount: number;
  onStatusChange: (status: OmnichannelConversationStatus) => void;
  onPriorityChange: (priority: OmnichannelPriority) => void;
  onAssignStaff: (staffId: string) => void;
  onToggleReadState: () => void;
  onEscalate: () => void;
  onTransferConversation: () => void;
}

const statuses: OmnichannelConversationStatus[] = ['open', 'pending', 'waiting_agent', 'waiting_customer', 'closed', 'escalated'];
const priorities: OmnichannelPriority[] = ['low', 'normal', 'high', 'urgent'];

export const OmnichannelAssignmentPanel: React.FC<OmnichannelAssignmentPanelProps> = ({
  status,
  priority,
  assignedStaffId,
  unreadCount,
  onStatusChange,
  onPriorityChange,
  onAssignStaff,
}) => {
  const { t } = useLocale();

  return (
    <section className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
      <h3 className="mb-3 text-sm font-bold text-gray-900 dark:text-white">{t('omnichannel.conversation.assignment')}</h3>
      <div className="grid gap-3">
        <Select label={t('common.status')} value={status} onChange={(event) => onStatusChange(event.target.value as OmnichannelConversationStatus)}>
          {statuses.map((option) => <option key={option} value={option}>{t(statusLabelKeys[option])}</option>)}
        </Select>
        <Select label={t('omnichannel.inbox.priority')} value={priority} onChange={(event) => onPriorityChange(event.target.value as OmnichannelPriority)}>
          {priorities.map((option) => <option key={option} value={option}>{t(priorityLabelKeys[option])}</option>)}
        </Select>
        <Select label={t('omnichannel.inbox.assignedStaff')} value={assignedStaffId ?? ''} onChange={(event) => onAssignStaff(event.target.value)}>
          <option value="">{t('omnichannel.inbox.unassigned')}</option>
          {mockOmnichannelAssignableStaff.map((staff) => <option key={staff.id} value={staff.id}>{staff.name}</option>)}
        </Select>
        <div className="rounded-lg bg-gray-50 p-3 text-sm text-gray-600 dark:bg-gray-950/40 dark:text-gray-300">
          {t('omnichannel.inbox.readState')}: <span className="font-semibold">{unreadCount > 0 ? t('omnichannel.actions.markRead') : t('omnichannel.actions.markUnread')}</span>
        </div>
      </div>
    </section>
  );
};
