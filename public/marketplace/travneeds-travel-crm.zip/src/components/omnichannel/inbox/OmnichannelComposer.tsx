import React from 'react';
import { Paperclip, Send, Trash2, X } from 'lucide-react';
import { Button } from '../../ui/Button';
import { useLocale } from '../../../localization/useLocale';
import type { OmnichannelAttachment } from '../../../types/omnichannel';

interface OmnichannelComposerProps {
  value: string;
  attachments: OmnichannelAttachment[];
  isSending: boolean;
  errorMessage?: string;
  onChange: (value: string) => void;
  onSend: () => void;
  onMockAttach: () => void;
  onRemoveAttachment: (attachmentId: string) => void;
  onClearDraft: () => void;
}

export const OmnichannelComposer: React.FC<OmnichannelComposerProps> = ({
  value,
  attachments,
  isSending,
  errorMessage,
  onChange,
  onSend,
  onMockAttach,
  onRemoveAttachment,
  onClearDraft,
}) => {
  const { t, direction } = useLocale();
  const isEmpty = !value.trim() && attachments.length === 0;

  return (
    <div className="shrink-0 rounded-lg border border-gray-200 bg-white p-3 dark:border-gray-800 dark:bg-gray-900">
      <div className="flex items-end gap-2">
        <textarea
          dir={direction}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          rows={1}
          placeholder={t('omnichannel.conversation.composerPlaceholder')}
          className="min-h-11 flex-1 resize-none rounded-md border border-gray-300 bg-white px-3 py-2.5 text-sm text-gray-900 outline-none focus:ring-2 focus:ring-blue-500 dark:border-gray-700 dark:bg-gray-950 dark:text-white"
        />
        <Button type="button" size="sm" className="h-11 w-11 !p-0" onClick={onSend} disabled={isEmpty} loading={isSending} title={t('omnichannel.actions.sendMock')}>
          <Send className="h-4 w-4" />
        </Button>
        <Button type="button" variant="outline" size="sm" className="h-11 w-11 !p-0" onClick={onMockAttach} title={t('omnichannel.actions.mockAttach')}>
          <Paperclip className="h-4 w-4" />
        </Button>
        <Button type="button" variant="ghost" size="sm" className="h-11 w-11 !p-0" onClick={onClearDraft} disabled={isEmpty && !errorMessage} title={t('omnichannel.actions.clearDraft')}>
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
      {attachments.length > 0 ? (
        <div className="mt-3 flex flex-wrap gap-2">
          {attachments.map((attachment) => (
            <div key={attachment.id} className="inline-flex items-center gap-2 rounded-full border border-gray-200 bg-gray-50 px-3 py-1 text-xs text-gray-700 dark:border-gray-700 dark:bg-gray-950/40 dark:text-gray-200">
              <span className="ltr-value">{attachment.fileName}</span>
              <span className="bidi-isolate text-gray-400">{attachment.sizeKb} KB</span>
              <button type="button" onClick={() => onRemoveAttachment(attachment.id)} title={t('omnichannel.actions.removeAttachment')}>
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      ) : null}
      {errorMessage ? <div className="mt-2 text-xs text-rose-600">{errorMessage}</div> : null}
    </div>
  );
};
