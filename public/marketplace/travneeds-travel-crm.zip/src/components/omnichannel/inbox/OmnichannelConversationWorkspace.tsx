import React, { useState } from 'react';
import { AlertTriangle, CornerUpLeft, MailOpen, MailPlus, ShieldAlert, Tag, X } from 'lucide-react';
import { StatusBadge } from '../../ui/StatusBadge';
import { Button } from '../../ui/Button';
import { TableActionsDropdown } from '../../ui/TableActionsDropdown';
import { useLocale } from '../../../localization/useLocale';
import type { OmnichannelAttachment, OmnichannelConversation, OmnichannelMessage, OmnichannelPriority, OmnichannelTag } from '../../../types/omnichannel';
import { channelLabelKeys, priorityLabelKeys, priorityVariants, statusLabelKeys, statusVariants } from './omnichannelInboxLabels';
import { OmnichannelMessageThread } from './OmnichannelMessageThread';
import { OmnichannelComposer } from './OmnichannelComposer';

interface OmnichannelConversationWorkspaceProps {
  conversation: OmnichannelConversation;
  messages: OmnichannelMessage[];
  tags: OmnichannelTag[];
  composerValue: string;
  composerAttachments: OmnichannelAttachment[];
  isSending: boolean;
  messageFailureState: { messageId: string; reason: string } | null;
  onComposerChange: (value: string) => void;
  onSend: () => void;
  onMockAttach: () => void;
  onRemoveAttachment: (attachmentId: string) => void;
  onRetryMessage: (messageId: string) => void;
  onClearDraft: () => void;
  onChangePriority: (priority: OmnichannelPriority) => void;
  onToggleReadState: () => void;
  onEscalate: () => void;
  onTransfer: () => void;
  onCloseConversation: () => void;
  onReopenConversation: () => void;
  onOpenStandalone?: () => void;
  hideHeader?: boolean;
  onRemoveTag: (tagId: string) => void;
  onAddTag: (tagId: string) => void;
}

export const OmnichannelConversationWorkspace: React.FC<OmnichannelConversationWorkspaceProps> = ({
  conversation,
  messages,
  tags,
  composerValue,
  composerAttachments,
  isSending,
  messageFailureState,
  onComposerChange,
  onSend,
  onMockAttach,
  onRemoveAttachment,
  onRetryMessage,
  onClearDraft,
  onChangePriority,
  onToggleReadState,
  onEscalate,
  onTransfer,
  onCloseConversation,
  onReopenConversation,
  onOpenStandalone,
  hideHeader = false,
  onRemoveTag,
  onAddTag,
}) => {
  const { t, locale } = useLocale();
  const [isTagsOpen, setIsTagsOpen] = useState(false);
  const activeTags = tags.filter((tag) => conversation.tagIds.includes(tag.id));
  const availableTags = tags.filter((tag) => !conversation.tagIds.includes(tag.id));

  return (
    <section className="flex h-full min-h-0 flex-col rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
      {!hideHeader && <header className="shrink-0 border-b border-gray-100 pb-4 dark:border-gray-800">
        <div className="relative">
          <div className="min-w-0 pr-28 logical-start rtl:pl-28 rtl:pr-0">
            <div className="mb-2 flex flex-wrap items-center gap-2">
              <StatusBadge variant="gray">{t(channelLabelKeys[conversation.channelType])}</StatusBadge>
              <StatusBadge variant={statusVariants[conversation.status]}>{t(statusLabelKeys[conversation.status])}</StatusBadge>
              <StatusBadge variant={priorityVariants[conversation.priority]}>{t(priorityLabelKeys[conversation.priority])}</StatusBadge>
            </div>
            <h2 className="text-lg font-bold text-gray-900 dark:text-white">{conversation.subject}</h2>
            <p className="mt-1 text-xs text-gray-500">
              {conversation.customer.name} · <span className="ltr-value">{conversation.id}</span> · {conversation.assignedStaffName ?? t('omnichannel.inbox.unassigned')}
            </p>
          </div>
          <div className="absolute right-0 top-0 flex shrink-0 items-center gap-1.5 rtl:left-0 rtl:right-auto">
            <div className="rounded-full bg-gray-50 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-gray-500 dark:bg-gray-950/40">
              SLA <span className="ltr-value normal-case">{conversation.sla.firstResponseRemainingMinutes}m</span>
            </div>
            <div className="relative">
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="relative h-7 w-8 rounded-full !p-0"
                onClick={() => setIsTagsOpen((current) => !current)}
                title="Tags"
              >
                <Tag className="h-3.5 w-3.5" />
                {activeTags.length > 0 && (
                  <span className="absolute -right-1.5 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-blue-600 px-1 text-[9px] font-bold leading-none text-white">
                    {activeTags.length}
                  </span>
                )}
              </Button>
              {isTagsOpen && (
                <div className="absolute right-0 z-30 mt-2 w-72 rounded-xl border border-gray-200 bg-white p-2 shadow-xl dark:border-gray-800 dark:bg-gray-900 rtl:left-0 rtl:right-auto">
                  <div className="mb-2 px-2 text-[10px] font-bold uppercase tracking-widest text-gray-400">Conversation tags</div>
                  <div className="max-h-72 space-y-1 overflow-y-auto">
                    {activeTags.length > 0 && activeTags.map((tag) => (
                      <div key={tag.id} className="flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 hover:bg-gray-50 dark:hover:bg-gray-800">
                        <span className={`inline-flex min-w-0 items-center gap-1 rounded-full border px-2 py-1 text-xs font-semibold ${tag.colorClass}`}>
                          <span className="truncate">{tag.label[locale]}</span>
                        </span>
                        <button
                          type="button"
                          className="rounded-md p-1 text-gray-400 hover:bg-rose-50 hover:text-rose-600"
                          onClick={() => onRemoveTag(tag.id)}
                          title={t('omnichannel.actions.removeTag')}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                    {activeTags.length === 0 && <div className="px-2 py-3 text-sm text-gray-500">No tags selected.</div>}
                  </div>
                  {availableTags.length > 0 && (
                    <div className="mt-2 border-t border-gray-100 pt-2 dark:border-gray-800">
                      <div className="mb-2 px-2 text-[10px] font-bold uppercase tracking-widest text-gray-400">Add tag</div>
                      <div className="flex flex-wrap gap-2 px-2">
                        {availableTags.slice(0, 6).map((tag) => (
                          <button
                            key={tag.id}
                            type="button"
                            className={`inline-flex rounded-full border px-2 py-1 text-xs font-semibold ${tag.colorClass}`}
                            onClick={() => onAddTag(tag.id)}
                          >
                            {tag.label[locale]}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
            <TableActionsDropdown
              triggerClassName="h-7 w-8 rounded-full !p-0"
              triggerIconClassName="h-4 w-4"
              actions={[
                {
                  label: 'Open chat screen',
                  icon: MailOpen,
                  onClick: () => onOpenStandalone?.(),
                  hidden: !onOpenStandalone
                },
                {
                  label: conversation.status === 'closed' ? t('omnichannel.actions.reopenConversation') : t('omnichannel.actions.closeConversation'),
                  icon: CornerUpLeft,
                  onClick: conversation.status === 'closed' ? onReopenConversation : onCloseConversation
                },
                {
                  label: conversation.unreadCount > 0 ? t('omnichannel.actions.markRead') : t('omnichannel.actions.markUnread'),
                  icon: conversation.unreadCount > 0 ? MailOpen : MailPlus,
                  onClick: onToggleReadState
                },
                {
                  label: t('omnichannel.actions.transferConversation'),
                  icon: CornerUpLeft,
                  onClick: onTransfer
                },
                {
                  label: t('omnichannel.actions.changePriority'),
                  icon: AlertTriangle,
                  onClick: () => onChangePriority(conversation.priority === 'urgent' ? 'high' : 'urgent')
                },
                {
                  label: t('omnichannel.actions.escalateConversation'),
                  icon: ShieldAlert,
                  onClick: onEscalate
                }
              ]}
            />
          </div>
        </div>
      </header>}
      <div className={hideHeader ? "flex min-h-0 flex-1 flex-col gap-4" : "mt-4 flex min-h-0 flex-1 flex-col gap-4"}>
        <OmnichannelMessageThread messages={messages} onRetryMessage={onRetryMessage} />
        <OmnichannelComposer
          value={composerValue}
          attachments={composerAttachments}
          isSending={isSending}
          errorMessage={messageFailureState?.reason}
          onChange={onComposerChange}
          onSend={onSend}
          onMockAttach={onMockAttach}
          onRemoveAttachment={onRemoveAttachment}
          onClearDraft={onClearDraft}
        />
      </div>
    </section>
  );
};
