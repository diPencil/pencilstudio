import React, { useMemo, useState } from 'react';
import { Archive, PencilLine, RotateCcw, StickyNote, Trash2 } from 'lucide-react';
import { Button } from '../../ui/Button';
import { useLocale } from '../../../localization/useLocale';
import type { OmnichannelInternalNote } from '../../../types/omnichannel';

interface OmnichannelInternalNotesPanelProps {
  notes: OmnichannelInternalNote[];
  onAddNote: (body: string) => void;
  onUpdateNote: (noteId: string, body: string) => void;
  onArchiveNote: (noteId: string) => void;
  onRestoreNote: (noteId: string) => void;
  onDeleteNote: (noteId: string) => void;
}

export const OmnichannelInternalNotesPanel: React.FC<OmnichannelInternalNotesPanelProps> = ({
  notes,
  onAddNote,
  onUpdateNote,
  onArchiveNote,
  onRestoreNote,
  onDeleteNote,
}) => {
  const { t, direction } = useLocale();
  const [draft, setDraft] = useState('');
  const [validationError, setValidationError] = useState('');
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [editingValue, setEditingValue] = useState('');
  const [deleteCandidateId, setDeleteCandidateId] = useState<string | null>(null);

  const activeNotes = useMemo(() => notes.filter((note) => note.status !== 'archived'), [notes]);
  const archivedNotes = useMemo(() => notes.filter((note) => note.status === 'archived'), [notes]);

  const submitNote = () => {
    const body = draft.trim();
    if (!body) {
      setValidationError(t('omnichannel.inbox.noteValidation'));
      return;
    }

    onAddNote(body);
    setDraft('');
    setValidationError('');
  };

  const startEditing = (note: OmnichannelInternalNote) => {
    setEditingNoteId(note.id);
    setEditingValue(note.body);
    setDeleteCandidateId(null);
  };

  const saveEdit = () => {
    const body = editingValue.trim();
    if (!editingNoteId) {
      return;
    }

    if (!body) {
      setValidationError(t('omnichannel.inbox.noteValidation'));
      return;
    }

    onUpdateNote(editingNoteId, body);
    setEditingNoteId(null);
    setEditingValue('');
    setValidationError('');
  };

  return (
    <section className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
      <div className="mb-3 flex items-center gap-2">
        <StickyNote className="h-4 w-4 text-blue-600" />
        <h3 className="text-sm font-bold text-gray-900 dark:text-white">{t('omnichannel.conversation.internalNotes')}</h3>
      </div>

      <div className="space-y-2">
        {activeNotes.length > 0 ? activeNotes.map((note) => {
          const isEditing = editingNoteId === note.id;
          const confirmDelete = deleteCandidateId === note.id;

          return (
            <div key={note.id} className="rounded-lg border border-amber-100 bg-amber-50 p-3 text-sm text-amber-950 dark:border-amber-900/40 dark:bg-amber-950/20 dark:text-amber-100">
              {isEditing ? (
                <div className="space-y-2">
                  <textarea
                    dir={direction}
                    value={editingValue}
                    onChange={(event) => setEditingValue(event.target.value)}
                    rows={3}
                    className="w-full resize-none rounded-md border border-amber-200 bg-white px-3 py-2 text-sm text-gray-900 focus:ring-2 focus:ring-blue-500 dark:border-amber-900/50 dark:bg-gray-950 dark:text-white"
                  />
                  <div className="flex flex-wrap gap-2">
                    <Button type="button" size="sm" onClick={saveEdit}>
                      {t('common.save')}
                    </Button>
                    <Button type="button" size="sm" variant="outline" onClick={() => {
                      setEditingNoteId(null);
                      setEditingValue('');
                    }}>
                      {t('common.cancel')}
                    </Button>
                  </div>
                </div>
              ) : (
                <>
                  <p>{note.body}</p>
                  <div className="mt-1 text-[11px] text-amber-700 dark:text-amber-300">
                    {note.authorName} · <span className="ltr-value">{new Date(note.updatedAt ?? note.createdAt).toLocaleString()}</span>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button type="button" size="sm" variant="ghost" onClick={() => startEditing(note)}>
                      <PencilLine className="h-3.5 w-3.5" />
                      {t('common.edit')}
                    </Button>
                    <Button type="button" size="sm" variant="ghost" onClick={() => onArchiveNote(note.id)}>
                      <Archive className="h-3.5 w-3.5" />
                      {t('omnichannel.actions.archiveNote')}
                    </Button>
                    {confirmDelete ? (
                      <>
                        <Button type="button" size="sm" variant="danger" onClick={() => {
                          onDeleteNote(note.id);
                          setDeleteCandidateId(null);
                        }}>
                          {t('common.confirm')}
                        </Button>
                        <Button type="button" size="sm" variant="outline" onClick={() => setDeleteCandidateId(null)}>
                          {t('common.cancel')}
                        </Button>
                      </>
                    ) : (
                      <Button type="button" size="sm" variant="ghost" onClick={() => setDeleteCandidateId(note.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                        {t('common.delete')}
                      </Button>
                    )}
                  </div>
                </>
              )}
            </div>
          );
        }) : (
          <div className="rounded-lg border border-dashed border-gray-200 p-4 text-sm text-gray-500 dark:border-gray-800">
            {t('omnichannel.inbox.noNotes')}
          </div>
        )}
      </div>

      <textarea
        dir={direction}
        value={draft}
        onChange={(event) => {
          setDraft(event.target.value);
          if (validationError) {
            setValidationError('');
          }
        }}
        rows={3}
        className="mt-3 w-full resize-none rounded-md border border-gray-300 px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 dark:border-gray-700 dark:bg-gray-950 dark:text-white"
        placeholder={t('omnichannel.conversation.notePlaceholder')}
      />
      {validationError ? <div className="mt-2 text-xs text-rose-600">{validationError}</div> : null}
      <Button type="button" size="sm" variant="outline" className="mt-2 w-full" onClick={submitNote}>
        {t('omnichannel.actions.addInternalNote')}
      </Button>

      <div className="mt-4 space-y-2">
        <div className="text-xs font-semibold uppercase tracking-wide text-gray-500">{t('omnichannel.inbox.archivedNotes')}</div>
        {archivedNotes.length > 0 ? archivedNotes.map((note) => (
          <div key={`archived-${note.id}`} className="rounded-lg border border-dashed border-gray-200 p-3 text-sm text-gray-600 dark:border-gray-800 dark:text-gray-300">
            <p>{note.body}</p>
            <div className="mt-1 text-[11px] text-gray-500">
              {note.authorName} · <span className="ltr-value">{new Date(note.archivedAt ?? note.createdAt).toLocaleString()}</span>
            </div>
            <Button type="button" size="sm" variant="outline" className="mt-3" onClick={() => onRestoreNote(note.id)}>
              <RotateCcw className="h-3.5 w-3.5" />
              {t('omnichannel.actions.restoreNote')}
            </Button>
          </div>
        )) : (
          <div className="rounded-lg border border-dashed border-gray-200 p-4 text-sm text-gray-500 dark:border-gray-800">
            {t('omnichannel.inbox.noArchivedNotes')}
          </div>
        )}
      </div>
    </section>
  );
};
