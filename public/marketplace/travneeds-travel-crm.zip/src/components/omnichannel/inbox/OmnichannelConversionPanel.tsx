import React from 'react';
import { ArrowRightLeft, Briefcase, LifeBuoy, Link2, UserPlus, UserRoundCheck } from 'lucide-react';
import { Button } from '../../ui/Button';
import { useLocale } from '../../../localization/useLocale';
import type { OmnichannelConversionMode, OmnichannelLinkedRecord, OmnichannelConversation } from '../../../types/omnichannel';

interface OmnichannelConversionPanelProps {
  conversation: OmnichannelConversation;
  removedRecords: OmnichannelLinkedRecord[];
  hasLinkableRecords: boolean;
  onOpen: (mode: OmnichannelConversionMode) => void;
}

export const OmnichannelConversionPanel: React.FC<OmnichannelConversionPanelProps> = ({
  conversation,
  removedRecords,
  hasLinkableRecords,
  onOpen,
}) => {
  const { t } = useLocale();

  const hasType = (type: OmnichannelLinkedRecord['type']) => conversation.linkedRecords.some((record) => record.type === type);

  const actions: Array<{
    mode: OmnichannelConversionMode;
    icon: React.ReactNode;
    label: string;
    description: string;
    disabled?: boolean;
  }> = [
    {
      mode: 'convert_lead',
      icon: <UserPlus className="h-4 w-4 text-blue-600" />,
      label: t('omnichannel.actions.convertToLead'),
      description: t('omnichannel.conversion.convertLeadDescription'),
      disabled: hasType('lead'),
    },
    {
      mode: 'convert_customer',
      icon: <UserRoundCheck className="h-4 w-4 text-emerald-600" />,
      label: t('omnichannel.actions.convertToCustomer'),
      description: t('omnichannel.conversion.convertCustomerDescription'),
      disabled: hasType('customer'),
    },
    {
      mode: 'create_ticket',
      icon: <LifeBuoy className="h-4 w-4 text-amber-600" />,
      label: t('omnichannel.actions.createTicket'),
      description: t('omnichannel.conversion.createTicketDescription'),
      disabled: hasType('support_ticket'),
    },
    {
      mode: 'create_case',
      icon: <Briefcase className="h-4 w-4 text-purple-600" />,
      label: t('omnichannel.actions.createCase'),
      description: t('omnichannel.conversion.createCaseDescription'),
      disabled: hasType('sales_case'),
    },
    {
      mode: 'link_existing',
      icon: <Link2 className="h-4 w-4 text-slate-600" />,
      label: t('omnichannel.actions.linkExistingRecord'),
      description: t('omnichannel.conversion.linkExistingDescription'),
      disabled: !hasLinkableRecords,
    },
  ];

  return (
    <section className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
      <div className="mb-3 flex items-center gap-2">
        <ArrowRightLeft className="h-4 w-4 text-blue-600" />
        <h3 className="text-sm font-bold text-gray-900 dark:text-white">{t('omnichannel.conversion.title')}</h3>
      </div>
      <div className="space-y-3">
        {actions.map((action) => (
          <div key={action.mode} className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  {action.icon}
                  <div className="font-semibold text-gray-900 dark:text-white">{action.label}</div>
                </div>
                <div className="mt-1 text-xs text-gray-500">{action.description}</div>
              </div>
              <Button type="button" size="sm" variant="outline" onClick={() => onOpen(action.mode)} disabled={action.disabled}>
                {t('omnichannel.actions.open')}
              </Button>
            </div>
          </div>
        ))}
        {removedRecords.length > 0 && (
          <div className="rounded-lg border border-dashed border-blue-200 bg-blue-50 px-3 py-2 text-xs text-blue-700 dark:border-blue-900 dark:bg-blue-950/30 dark:text-blue-200">
            {t('omnichannel.conversion.restoreHint')}
          </div>
        )}
      </div>
    </section>
  );
};
