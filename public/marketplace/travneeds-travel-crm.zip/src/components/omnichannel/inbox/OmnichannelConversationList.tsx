import React from 'react';
import type { OmnichannelConversation } from '../../../types/omnichannel';
import { useLocale } from '../../../localization/useLocale';
import { OmnichannelConversationCard } from './OmnichannelConversationCard';

interface OmnichannelConversationListProps {
  conversations: OmnichannelConversation[];
  selectedConversationId?: string;
  onSelect: (conversationId: string) => void;
}

export const OmnichannelConversationList: React.FC<OmnichannelConversationListProps> = ({ conversations, selectedConversationId, onSelect }) => {
  const { t } = useLocale();

  return (
    <section className="flex h-full min-h-0 flex-col rounded-lg border border-gray-200 bg-white p-3 shadow-sm dark:border-gray-800 dark:bg-gray-900">
      <div className="mb-3 flex shrink-0 items-center justify-between gap-3">
        <h2 className="text-sm font-bold text-gray-900 dark:text-white">{t('omnichannel.inbox.conversationList')}</h2>
        <span className="text-xs font-semibold text-gray-500 bidi-isolate">{conversations.length}</span>
      </div>
      <div className="min-h-0 flex-1 space-y-2 overflow-y-auto pr-1">
        {conversations.length > 0 ? (
          conversations.map((conversation) => (
            <OmnichannelConversationCard
              key={conversation.id}
              conversation={conversation}
              isSelected={conversation.id === selectedConversationId}
              onSelect={onSelect}
            />
          ))
        ) : (
          <div className="rounded-lg border border-dashed border-gray-200 p-6 text-center text-sm text-gray-500 dark:border-gray-800">
            {t('omnichannel.inbox.noConversations')}
          </div>
        )}
      </div>
    </section>
  );
};
