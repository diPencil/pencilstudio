import React from 'react';
import { Clock3 } from 'lucide-react';
import { useLocale } from '../../../localization/useLocale';
import type { OmnichannelConversionActivityEvent } from '../../../types/omnichannel';

interface OmnichannelConversionActivityPanelProps {
  events: OmnichannelConversionActivityEvent[];
}

export const OmnichannelConversionActivityPanel: React.FC<OmnichannelConversionActivityPanelProps> = ({ events }) => {
  const { t } = useLocale();

  const eventLabelKeys: Record<OmnichannelConversionActivityEvent['type'], string> = {
    converted_to_lead: 'omnichannel.activity.convertedToLead',
    converted_to_customer: 'omnichannel.activity.convertedToCustomer',
    ticket_created: 'omnichannel.activity.ticketCreated',
    case_created: 'omnichannel.activity.caseCreated',
    record_linked: 'omnichannel.activity.recordLinked',
    record_unlinked: 'omnichannel.activity.recordUnlinked',
    record_restored: 'omnichannel.activity.recordRestored',
  };

  return (
    <section className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
      <div className="mb-3 flex items-center gap-2">
        <Clock3 className="h-4 w-4 text-blue-600" />
        <h3 className="text-sm font-bold text-gray-900 dark:text-white">{t('omnichannel.conversion.activityTitle')}</h3>
      </div>
      {events.length === 0 ? (
        <div className="rounded-lg border border-dashed border-gray-200 p-4 text-sm text-gray-500 dark:border-gray-800">
          {t('omnichannel.conversion.noActivity')}
        </div>
      ) : (
        <div className="space-y-3">
          {events.map((event) => (
            <div key={event.id} className="border-s-2 border-blue-200 ps-3 dark:border-blue-900">
              <div className="text-sm font-semibold text-gray-900 dark:text-white">
                {t(eventLabelKeys[event.type])}
              </div>
              <div className="mt-0.5 text-sm text-gray-600 dark:text-gray-300">{event.recordLabel}</div>
              <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-xs text-gray-500">
                <span className="bidi-isolate">{event.actorName}</span>
                <span className="ltr-value">{new Date(event.createdAt).toLocaleString()}</span>
              </div>
              {event.note && <div className="mt-1 text-xs text-gray-500">{event.note}</div>}
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
