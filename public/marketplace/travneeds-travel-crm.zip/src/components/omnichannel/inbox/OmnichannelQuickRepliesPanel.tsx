import React from 'react';
import { MessageSquarePlus } from 'lucide-react';
import { Button } from '../../ui/Button';
import { useLocale } from '../../../localization/useLocale';
import type { OmnichannelChannelType, OmnichannelQuickReplyTemplate } from '../../../types/omnichannel';

interface OmnichannelQuickRepliesPanelProps {
  channelType: OmnichannelChannelType;
  templates: OmnichannelQuickReplyTemplate[];
  onInsert: (body: string) => void;
}

export const OmnichannelQuickRepliesPanel: React.FC<OmnichannelQuickRepliesPanelProps> = ({ channelType, templates, onInsert }) => {
  const { t, locale } = useLocale();
  const availableTemplates = templates.filter((template) => template.channelTypes.includes(channelType));

  return (
    <section className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
      <div className="mb-3 flex items-center gap-2">
        <MessageSquarePlus className="h-4 w-4 text-blue-600" />
        <h3 className="text-sm font-bold text-gray-900 dark:text-white">{t('omnichannel.conversation.quickReplies')}</h3>
      </div>
      <div className="space-y-2">
        {availableTemplates.map((template) => (
          <div key={template.id} className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
            <div className="font-semibold text-gray-900 dark:text-white">{template.title[locale]}</div>
            <p className="mt-1 line-clamp-2 text-xs text-gray-500">{template.body[locale]}</p>
            <Button type="button" variant="outline" size="sm" className="mt-2 w-full" onClick={() => onInsert(template.body[locale])}>
              {t('omnichannel.actions.insertReply')}
            </Button>
          </div>
        ))}
        {availableTemplates.length === 0 && <div className="text-sm text-gray-500">{t('omnichannel.conversation.noQuickReplies')}</div>}
      </div>
    </section>
  );
};
