import React from 'react';
import { FileText, Lock, RotateCcw } from 'lucide-react';
import { cn } from '../../../utils/cn';
import { useLocale } from '../../../localization/useLocale';
import type { OmnichannelMessage } from '../../../types/omnichannel';
import { deliveryLabelKeys } from './omnichannelInboxLabels';
import { Button } from '../../ui/Button';

interface OmnichannelMessageBubbleProps {
  message: OmnichannelMessage;
  onRetryMessage: (messageId: string) => void;
}

export const OmnichannelMessageBubble: React.FC<OmnichannelMessageBubbleProps> = ({ message, onRetryMessage }) => {
  const { t, direction } = useLocale();
  const isOutbound = message.direction === 'outbound';
  const isInternal = message.direction === 'internal';
  const isSystem = message.direction === 'system';

  if (isSystem) {
    return (
      <div className="flex justify-center">
        <div className="rounded-full bg-gray-100 px-3 py-1 text-xs text-gray-500 dark:bg-gray-800 dark:text-gray-400">
          {message.body} <span className="ltr-value">{new Date(message.createdAt).toLocaleString()}</span>
        </div>
      </div>
    );
  }

  return (
    <div className={cn('flex', isOutbound ? 'justify-end' : 'justify-start')}>
      <div
        className={cn(
          'max-w-[78%] rounded-lg border px-3 py-2 shadow-sm',
          isOutbound && 'border-blue-100 bg-blue-50 text-blue-950 dark:border-blue-900/40 dark:bg-blue-950/30 dark:text-blue-50',
          !isOutbound && !isInternal && 'border-gray-200 bg-white text-gray-900 dark:border-gray-800 dark:bg-gray-900 dark:text-white',
          isInternal && 'border-amber-200 bg-amber-50 text-amber-950 dark:border-amber-900/50 dark:bg-amber-950/20 dark:text-amber-100'
        )}
      >
        <div className="mb-1 flex items-center justify-between gap-3 text-[11px] font-semibold text-gray-500">
          <span className="truncate">{message.authorName}</span>
          {isInternal && <Lock className="h-3.5 w-3.5" />}
        </div>
        <p className={cn('whitespace-pre-wrap text-sm leading-6', direction === 'rtl' && 'text-right')}>{message.body}</p>
        {message.attachments.length > 0 && (
          <div className="mt-2 space-y-1">
            {message.attachments.map((attachment) => (
              <div key={attachment.id} className="flex items-center gap-2 rounded border border-gray-200 bg-white/70 px-2 py-1 text-xs dark:border-gray-700 dark:bg-gray-950/40">
                <FileText className="h-3.5 w-3.5" />
                <span className="truncate ltr-value">{attachment.fileName}</span>
                <span className="text-gray-400 bidi-isolate">{attachment.sizeKb} KB</span>
              </div>
            ))}
          </div>
        )}
        <div className="mt-1 flex flex-wrap items-center justify-end gap-2 text-[11px] text-gray-400">
          <span className="ltr-value">{new Date(message.createdAt).toLocaleString()}</span>
          {message.deliveryStatus && <span>{t(deliveryLabelKeys[message.deliveryStatus])}</span>}
          {message.retryCount && message.retryCount > 0 ? <span className="bidi-isolate">{message.retryCount}x</span> : null}
        </div>
        {message.deliveryStatus === 'failed' ? (
          <div className="mt-2 flex flex-wrap items-center justify-between gap-2 rounded-md border border-rose-200 bg-rose-50 px-2 py-2 text-xs text-rose-700 dark:border-rose-900/40 dark:bg-rose-950/20 dark:text-rose-200">
            <span>{message.failureReason ?? t('omnichannel.inbox.messageFailureReason')}</span>
            <Button type="button" size="sm" variant="outline" onClick={() => onRetryMessage(message.id)}>
              <RotateCcw className="h-3.5 w-3.5" />
              {t('omnichannel.actions.retryMessage')}
            </Button>
          </div>
        ) : null}
      </div>
    </div>
  );
};
