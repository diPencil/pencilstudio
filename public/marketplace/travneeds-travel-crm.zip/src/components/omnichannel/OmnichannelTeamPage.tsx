import React, { useMemo, useState } from 'react';
import { Users } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { cn } from '../../utils/cn';
import { OmnichannelDrawer, OmnichannelStateNotice } from './OmnichannelInteractions';
import { OmnichannelSectionCard } from './OmnichannelUi';
import { mockOmnichannelTeamWorkload } from '../../services/omnichannelMockData';
import { Button } from '../ui/Button';
import { StatusBadge } from '../ui/StatusBadge';
import { onlineStatusLabelKeys } from './inbox/omnichannelInboxLabels';
import type { OmnichannelTeamMemberWorkload } from '../../types/omnichannel';
import { useToastContext } from '../../contexts/ToastContext';
import { evaluateAssignmentEligibility } from '../../utils/omnichannelIntegration';

export const OmnichannelTeamPage: React.FC = () => {
  const { t, locale, direction } = useLocale();
  const isRTL = direction === 'rtl' || locale === 'ar';
  const toast = useToastContext();
  const {
    teamMembers: members,
    updateTeamMemberStatus,
    rebalanceTeamWorkload,
  } = useOmnichannelMockStore();
  const [filter, setFilter] = useState('all');
  const [selectedMember, setSelectedMember] = useState<OmnichannelTeamMemberWorkload | null>(null);

  const filteredMembers = useMemo(
    () =>
      members.filter((member) => {
        if (filter === 'all') {
          return true;
        }
        if (filter === 'overloaded') {
          return member.workloadPercent >= 80;
        }
        if (filter === 'available') {
          return member.workloadPercent < 70 && member.onlineStatus === 'online';
        }
        if (filter === 'online') {
          return member.onlineStatus === 'online';
        }
        return member.teamName === filter;
      }),
    [filter, members]
  );

  const toggleStatus = (memberId: string) => {
    const member = members.find((m) => m.id === memberId);
    if (member) {
      const cycle: Array<OmnichannelTeamMemberWorkload['onlineStatus']> = ['online', 'busy', 'offline'];
      const nextStatus = cycle[(cycle.indexOf(member.onlineStatus) + 1) % cycle.length];
      updateTeamMemberStatus(memberId, nextStatus);
    }
  };

  const rebalance = () => {
    rebalanceTeamWorkload('Sales');
    rebalanceTeamWorkload('Reservations');
    rebalanceTeamWorkload('Support');
    toast.success(t('omnichannel.team.balanceTitle'), t('omnichannel.team.balanceDescription'));
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
          <div>
            <h1 className="text-2xl font-bold">{t('omnichannel.team.title')}</h1>
            <p className="mt-2 text-blue-100 opacity-90">{t('omnichannel.team.subtitle')}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={rebalance} className="bg-white/10 text-white hover:bg-white/20 border-transparent">{t('omnichannel.actions.balanceWorkload')}</Button>
            <Button onClick={() => toast.info(t('omnichannel.team.bulkAssignTitle'), t('omnichannel.team.bulkAssignDescription'))} className="bg-white/10 text-white hover:bg-white/20 border-transparent">{t('omnichannel.actions.bulkAssign')}</Button>
          </div>
        </div>
      <OmnichannelSectionCard
        title={t('omnichannel.team.workloadTitle')}
        action={
          <select value={filter} onChange={(event) => setFilter(event.target.value)} className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
            <option value="all">{t('common.all')}</option>
            <option value="online">{t('omnichannel.team.filterOnline')}</option>
            <option value="overloaded">{t('omnichannel.team.filterOverloaded')}</option>
            <option value="available">{t('omnichannel.team.filterAvailable')}</option>
            <option value="Sales">Sales</option>
            <option value="Reservations">Reservations</option>
          </select>
        }
      >
        <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-4">
          {filteredMembers.map((member) => (
            <div key={member.id} className="rounded-lg border border-gray-100 p-4 dark:border-gray-800">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="font-semibold text-gray-900 dark:text-white">{member.name}</div>
                  <div className="text-xs text-gray-500">{member.teamName}</div>
                </div>
                <button type="button" onClick={() => toggleStatus(member.id)}>
                  <StatusBadge variant={member.onlineStatus === 'busy' ? 'amber' : member.onlineStatus === 'online' ? 'emerald' : 'gray'}>
                    {t(onlineStatusLabelKeys[member.onlineStatus])}
                  </StatusBadge>
                </button>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 text-sm text-gray-600 dark:text-gray-300">
                <div>{t('omnichannel.team.assignedConversations')}: <span className="font-semibold">{member.assignedConversations}</span></div>
                <div>{t('omnichannel.team.activeTickets')}: <span className="font-semibold">{member.activeTickets}</span></div>
                <div>{t('omnichannel.team.averageResponse')}: <span className="font-semibold">{member.averageResponseMinutes}m</span></div>
                <div>{t('omnichannel.team.satisfaction')}: <span className="font-semibold">{member.satisfactionScore}%</span></div>
              </div>
              <div className="mt-3">
                <div className="mb-1 flex items-center justify-between text-xs text-gray-500">
                  <span>{t('omnichannel.team.workloadMeter')}</span>
                  <span className="bidi-isolate">{member.workloadPercent}%</span>
                </div>
                <div className="h-2 rounded-full bg-gray-100 dark:bg-gray-800">
                  <div className="h-2 rounded-full bg-blue-600" style={{ width: `${member.workloadPercent}%` }} />
                </div>
              </div>
              <div className="mt-3 text-xs text-gray-500">{`${t('omnichannel.team.supervisor')}: ${member.supervisorName}`}</div>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={() => setSelectedMember(member)}>{t('omnichannel.actions.viewProfile')}</Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    const eligibility = evaluateAssignmentEligibility(member);
                    if (!eligibility.allowed) {
                      toast.warning(t('omnichannel.team.reassignTitle'), t('omnichannel.team.reassignOfflineDescription'));
                      return;
                    }
                    toast.info(
                      t('omnichannel.team.reassignTitle'),
                      eligibility.warning === 'busy' ? t('omnichannel.team.reassignBusyDescription') : t('omnichannel.team.reassignDescription')
                    );
                  }}
                >
                  {t('omnichannel.actions.reassign')}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </OmnichannelSectionCard>

      <OmnichannelSectionCard title={t('omnichannel.team.supervisorView')}>
        <OmnichannelStateNotice
          title={t('omnichannel.team.supervisorView')}
          description={t('omnichannel.team.supervisorDescription')}
          action={<Users className="h-4 w-4 text-blue-600" />}
        />
      </OmnichannelSectionCard>

      <OmnichannelDrawer
        isOpen={Boolean(selectedMember)}
        title={selectedMember?.name ?? ''}
        description={selectedMember?.teamName}
        onClose={() => setSelectedMember(null)}
      >
        {selectedMember ? (
          <div className="space-y-3">
            <div className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
              <div className="text-xs font-semibold text-gray-500">{t('omnichannel.team.assignedConversations')}</div>
              <div className="mt-1 text-sm text-gray-900 dark:text-white">{selectedMember.assignedConversations}</div>
            </div>
            <div className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
              <div className="text-xs font-semibold text-gray-500">{t('omnichannel.team.averageResponse')}</div>
              <div className="mt-1 text-sm text-gray-900 dark:text-white">{selectedMember.averageResponseMinutes}m</div>
            </div>
            <div className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
              <div className="text-xs font-semibold text-gray-500">{t('omnichannel.team.satisfaction')}</div>
              <div className="mt-1 text-sm text-gray-900 dark:text-white">{selectedMember.satisfactionScore}%</div>
            </div>
          </div>
        ) : null}
      </OmnichannelDrawer>
      </div>
    </div>
  );
};
