import React, { useMemo, useState } from 'react';
import { Bolt, History, PlayCircle, Plus, Trash2 } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { cn } from '../../utils/cn';
import { OmnichannelConfirmationModal, OmnichannelDrawer } from './OmnichannelInteractions';
import { OmnichannelSectionCard } from './OmnichannelUi';
import {
  mockOmnichannelAutomationActivities,
  mockOmnichannelAutomationRules,
  mockOmnichannelQueues,
} from '../../services/omnichannelMockData';
import { Button } from '../ui/Button';
import { StatusBadge } from '../ui/StatusBadge';
import { routingStatusLabelKeys } from './inbox/omnichannelInboxLabels';
import { Modal } from '../ui/Modal';
import { useToastContext } from '../../contexts/ToastContext';
import type { OmnichannelAutomationRule } from '../../types/omnichannel';

interface AutomationDraft {
  id?: string;
  name: string;
  trigger: string;
  condition: string;
  action: string;
}

const emptyDraft: AutomationDraft = {
  name: '',
  trigger: '',
  condition: '',
  action: '',
};

export const OmnichannelAutomationPage: React.FC = () => {
  const { t, locale, direction } = useLocale();
  const isRTL = direction === 'rtl' || locale === 'ar';
  const toast = useToastContext();
  const {
    automationRules: rules,
    automationActivities: activities,
    addAutomationRule,
    updateAutomationRule,
    deleteAutomationRule,
    duplicateAutomationRule: storeDuplicateAutomationRule,
    enableAutomationRule,
    runAutomationNow,
  } = useOmnichannelMockStore();
  const [draft, setDraft] = useState<AutomationDraft>(emptyDraft);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);
  const [historyRuleId, setHistoryRuleId] = useState<string | null>(null);
  const [deleteRuleId, setDeleteRuleId] = useState<string | null>(null);
  const [activityFilter, setActivityFilter] = useState('');
  const [testPreview, setTestPreview] = useState<string | null>(null);
  const [isRunningNow, setIsRunningNow] = useState<string | null>(null);

  const filteredActivities = useMemo(
    () =>
      activityFilter ? activities.filter((activity) => activity.status === activityFilter) : activities,
    [activities, activityFilter]
  );

  const localized = (value: { en: string; ar: string }) => (locale === 'ar' ? value.ar : value.en);
  const knownTeamNames = useMemo(
    () =>
      mockOmnichannelQueues.flatMap((queue) => [queue.id, queue.name.en, queue.name.ar, queue.department]),
    []
  );

  const openEditor = (rule?: OmnichannelAutomationRule) => {
    if (!rule) {
      setDraft(emptyDraft);
      setEditingRuleId(null);
      setEditorOpen(true);
      return;
    }

    setDraft({
      id: rule.id,
      name: localized(rule.name),
      trigger: rule.trigger,
      condition: rule.conditions.join(', '),
      action: rule.actions.map((action) => action.summary).join(', '),
    });
    setEditingRuleId(rule.id);
    setEditorOpen(true);
  };

  const saveRule = () => {
    if (!draft.trigger || !draft.action || !draft.name.trim()) {
      toast.warning(t('omnichannel.automation.validationTitle'), t('omnichannel.automation.validationDescription'));
      return;
    }

    const actionSummaries = draft.action.split(',').map((item) => item.trim()).filter(Boolean);
    const invalidAssignment = actionSummaries.some(
      (summary) => summary.toLowerCase().includes('assign') && !knownTeamNames.some((team) => summary.toLowerCase().includes(team.toLowerCase()))
    );

    if (invalidAssignment) {
      toast.warning(t('omnichannel.automation.validationTitle'), t('omnichannel.automation.assignTeamValidation'));
      return;
    }

    const nextRule: OmnichannelAutomationRule = {
      id: editingRuleId ?? `AUTO-MOCK-${rules.length + 1}`,
      name: { en: draft.name, ar: draft.name },
      status: 'active',
      trigger: draft.trigger as OmnichannelAutomationRule['trigger'],
      conditions: draft.condition.split(',').map((item) => item.trim()).filter(Boolean),
      actions: actionSummaries.map((item) => ({
        type: item.toLowerCase().includes('ticket')
          ? 'create_ticket'
          : item.toLowerCase().includes('reply')
            ? 'send_quick_reply'
            : item.toLowerCase().includes('tag')
              ? 'add_tag'
              : item.toLowerCase().includes('escalat')
                ? 'escalate'
                : item.toLowerCase().includes('supervisor')
                  ? 'notify_supervisor'
                  : 'assign_team',
        summary: item,
      })),
      ownerId: 'USR-001',
      ownerName: 'Super Admin',
      priority: rules.length + 1,
    };

    if (editingRuleId) {
      updateAutomationRule(editingRuleId, nextRule);
    } else {
      addAutomationRule(nextRule);
    }
    toast.success(t('omnichannel.automation.savedTitle'), t('omnichannel.automation.savedDescription'));
    setEditorOpen(false);
    setDraft(emptyDraft);
    setEditingRuleId(null);
  };

  const duplicateRule = (rule: OmnichannelAutomationRule) => {
    storeDuplicateAutomationRule(rule.id);
    toast.success(t('omnichannel.routing.ruleDuplicatedTitle'), t('omnichannel.routing.ruleDuplicatedDescription'));
  };

  const runNow = async (rule: OmnichannelAutomationRule) => {
    setIsRunningNow(rule.id);
    await new Promise((resolve) => window.setTimeout(resolve, 650));
    setIsRunningNow(null);
    const result = runAutomationNow(rule.id);
    if (result.success) {
      toast.success(t('omnichannel.automation.runNowTitle'), t('omnichannel.automation.runNowSuccess'));
    } else {
      toast.error(t('omnichannel.automation.runNowTitle'), result.message);
    }
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
          <div>
            <h1 className="text-2xl font-bold">{t('omnichannel.automation.title')}</h1>
            <p className="mt-2 text-blue-100 opacity-90">{t('omnichannel.automation.subtitle')}</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => openEditor()} className="bg-white/10 text-white hover:bg-white/20 border-transparent">
              <Plus className="h-4 w-4" />
              {t('omnichannel.actions.createAutomation')}
            </Button>
          </div>
        </div>
      <div className="grid gap-4 xl:grid-cols-[1.2fr_1fr]">
        <OmnichannelSectionCard title={t('omnichannel.automation.ruleLibrary')}>
          <div className="space-y-3">
            {rules.map((rule) => (
              <div key={rule.id} className="rounded-lg border border-gray-100 p-4 dark:border-gray-800">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold text-gray-900 dark:text-white">{localized(rule.name)}</div>
                    <div className="mt-1 text-xs text-gray-500">{rule.conditions.join(' | ')}</div>
                  </div>
                  <StatusBadge variant={rule.status === 'active' ? 'emerald' : rule.status === 'paused' ? 'amber' : 'gray'}>
                    {t(routingStatusLabelKeys[rule.status])}
                  </StatusBadge>
                </div>
                <div className="mt-3 grid gap-3 md:grid-cols-2">
                  <div>
                    <div className="text-xs font-semibold text-gray-500">{t('omnichannel.automation.trigger')}</div>
                    <div className="mt-1 text-sm text-gray-900 dark:text-white">{t(`omnichannel.automation.trigger.${rule.trigger}` as never)}</div>
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-gray-500">{t('omnichannel.automation.actions')}</div>
                    <div className="mt-1 text-sm text-gray-900 dark:text-white">{rule.actions.map((action) => action.summary).join(', ')}</div>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => openEditor(rule)}>
                    {t('common.edit')}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => duplicateRule(rule)}>
                    {t('omnichannel.actions.duplicateAutomation')}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => enableAutomationRule(rule.id, rule.status !== 'active')}
                  >
                    {rule.status === 'active' ? t('omnichannel.actions.disable') : t('omnichannel.actions.enable')}
                  </Button>
                  <Button size="sm" variant="ghost" loading={isRunningNow === rule.id} onClick={() => runNow(rule)}>
                    <Bolt className="h-4 w-4" />
                    {t('omnichannel.actions.runNow')}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setHistoryRuleId(rule.id)}>
                    <History className="h-4 w-4" />
                    {t('omnichannel.actions.viewHistory')}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setDeleteRuleId(rule.id)}>
                    <Trash2 className="h-4 w-4" />
                    {t('common.delete')}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </OmnichannelSectionCard>

        <OmnichannelSectionCard
          title={t('omnichannel.automation.testPreview')}
          action={
            <Button
              variant="outline"
              onClick={() =>
                setTestPreview(
                  draft.trigger && draft.action
                    ? `${draft.trigger} -> ${draft.action}`
                    : t('omnichannel.automation.testPreviewDescription')
                )
              }
            >
              <PlayCircle className="h-4 w-4" />
              {t('omnichannel.actions.previewMock')}
            </Button>
          }
        >
          <div className="space-y-4">
            <SelectField label={t('omnichannel.automation.trigger')} value={draft.trigger} onChange={(value) => setDraft((current) => ({ ...current, trigger: value }))}>
              <option value="">{t('omnichannel.common.selectOption')}</option>
              <option value="new_conversation">{t('omnichannel.automation.trigger.new_conversation')}</option>
              <option value="sla_at_risk">{t('omnichannel.automation.trigger.sla_at_risk')}</option>
              <option value="keyword_detected">{t('omnichannel.automation.trigger.keyword_detected')}</option>
            </SelectField>
            <TextAreaField label={t('omnichannel.automation.conditions')} value={draft.condition} onChange={(value) => setDraft((current) => ({ ...current, condition: value }))} />
            <TextAreaField label={t('omnichannel.automation.actions')} value={draft.action} onChange={(value) => setDraft((current) => ({ ...current, action: value }))} />
            <div className="rounded-lg border border-dashed border-gray-200 p-5 text-sm text-gray-600 dark:border-gray-800 dark:text-gray-300">
              {testPreview ?? t('omnichannel.automation.testPreviewDescription')}
            </div>
          </div>
        </OmnichannelSectionCard>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1fr_1fr]">
        <OmnichannelSectionCard
          title={t('omnichannel.automation.activityLog')}
          action={
            <select
              value={activityFilter}
              onChange={(event) => setActivityFilter(event.target.value)}
              className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900"
            >
              <option value="">{t('common.all')}</option>
              <option value="success">{t('omnichannel.common.success')}</option>
              <option value="warning">{t('omnichannel.common.warning')}</option>
              <option value="failed">{t('omnichannel.common.failed')}</option>
            </select>
          }
        >
          <div className="space-y-3">
            {filteredActivities.map((activity) => (
              <div key={activity.id} className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-semibold text-gray-900 dark:text-white">{activity.ruleName}</div>
                    <div className="mt-1 text-xs text-gray-500">{activity.message}</div>
                  </div>
                  <StatusBadge variant={activity.status === 'success' ? 'emerald' : activity.status === 'warning' ? 'amber' : 'rose'}>
                    {t(`omnichannel.common.${activity.status}` as never)}
                  </StatusBadge>
                </div>
              </div>
            ))}
          </div>
        </OmnichannelSectionCard>

        <OmnichannelSectionCard title={t('omnichannel.automation.builderTitle')}>
          <div className="space-y-4">
            <TextField label={t('omnichannel.routing.ruleName')} value={draft.name} onChange={(value) => setDraft((current) => ({ ...current, name: value }))} />
            <TextAreaField label={t('omnichannel.automation.conditions')} value={draft.condition} onChange={(value) => setDraft((current) => ({ ...current, condition: value }))} />
            <TextAreaField label={t('omnichannel.automation.actions')} value={draft.action} onChange={(value) => setDraft((current) => ({ ...current, action: value }))} />
            <Button className="w-full" onClick={saveRule}>
              {t('omnichannel.actions.saveMockRule')}
            </Button>
          </div>
        </OmnichannelSectionCard>
      </div>

      <Modal isOpen={editorOpen} onClose={() => setEditorOpen(false)} title={t('omnichannel.automation.builderTitle')} size="lg">
        <div className="space-y-4">
          <TextField label={t('omnichannel.routing.ruleName')} value={draft.name} onChange={(value) => setDraft((current) => ({ ...current, name: value }))} />
          <SelectField label={t('omnichannel.automation.trigger')} value={draft.trigger} onChange={(value) => setDraft((current) => ({ ...current, trigger: value }))}>
            <option value="">{t('omnichannel.common.selectOption')}</option>
            <option value="new_conversation">{t('omnichannel.automation.trigger.new_conversation')}</option>
            <option value="sla_at_risk">{t('omnichannel.automation.trigger.sla_at_risk')}</option>
            <option value="keyword_detected">{t('omnichannel.automation.trigger.keyword_detected')}</option>
          </SelectField>
          <TextAreaField label={t('omnichannel.automation.conditions')} value={draft.condition} onChange={(value) => setDraft((current) => ({ ...current, condition: value }))} />
          <TextAreaField label={t('omnichannel.automation.actions')} value={draft.action} onChange={(value) => setDraft((current) => ({ ...current, action: value }))} />
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setEditorOpen(false)}>
              {t('common.cancel')}
            </Button>
            <Button onClick={saveRule}>{t('omnichannel.actions.saveMockRule')}</Button>
          </div>
        </div>
      </Modal>

      <OmnichannelDrawer
        isOpen={Boolean(historyRuleId)}
        title={t('omnichannel.automation.executionHistoryTitle')}
        description={historyRuleId ?? ''}
        onClose={() => setHistoryRuleId(null)}
      >
        <div className="space-y-3">
          {activities
            .filter((activity) => activity.ruleId === historyRuleId)
            .map((activity) => (
              <div key={activity.id} className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
                <div className="font-semibold text-gray-900 dark:text-white">{activity.ruleName}</div>
                <div className="mt-1 text-sm text-gray-500">{activity.message}</div>
                <div className="mt-1 text-xs text-gray-500 ltr-value">{activity.createdAt}</div>
              </div>
            ))}
        </div>
      </OmnichannelDrawer>

      <OmnichannelConfirmationModal
        isOpen={Boolean(deleteRuleId)}
        title={t('omnichannel.automation.deleteTitle')}
        description={t('omnichannel.automation.deleteDescription')}
        confirmLabel={t('common.delete')}
        tone="danger"
        onClose={() => setDeleteRuleId(null)}
        onConfirm={() => {
          if (deleteRuleId) {
            deleteAutomationRule(deleteRuleId);
            toast.success(t('omnichannel.automation.deleteSuccessTitle') || t('omnichannel.automation.savedTitle'), t('omnichannel.automation.deleteSuccessDescription') || t('omnichannel.automation.savedDescription'));
          }
          setDeleteRuleId(null);
        }}
      />
      </div>
    </div>
  );
};

const TextField: React.FC<{ label: string; value: string; onChange: (value: string) => void }> = ({ label, value, onChange }) => (
  <label className="block">
    <div className="mb-1 text-xs font-semibold text-gray-500">{label}</div>
    <input
      value={value}
      onChange={(event) => onChange(event.target.value)}
      className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900"
    />
  </label>
);

const TextAreaField: React.FC<{ label: string; value: string; onChange: (value: string) => void }> = ({ label, value, onChange }) => (
  <label className="block">
    <div className="mb-1 text-xs font-semibold text-gray-500">{label}</div>
    <textarea
      value={value}
      onChange={(event) => onChange(event.target.value)}
      rows={3}
      className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900"
    />
  </label>
);

const SelectField: React.FC<{
  label: string;
  value: string;
  onChange: (value: string) => void;
  children: React.ReactNode;
}> = ({ label, value, onChange, children }) => (
  <label className="block">
    <div className="mb-1 text-xs font-semibold text-gray-500">{label}</div>
    <select value={value} onChange={(event) => onChange(event.target.value)} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
      {children}
    </select>
  </label>
);
