import React, { useMemo, useState } from 'react';
import { GitBranch, Plus, ShieldAlert, Trash2 } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { OmnichannelModuleShell } from './OmnichannelModuleShell';
import { OmnichannelConfirmationModal, OmnichannelStateNotice } from './OmnichannelInteractions';
import { OmnichannelSectionCard } from './OmnichannelUi';
import { mockOmnichannelQueues, mockOmnichannelRoutingRules } from '../../services/omnichannelMockData';
import { Button } from '../ui/Button';
import { StatusBadge } from '../ui/StatusBadge';
import { channelLabelKeys, routingStatusLabelKeys } from './inbox/omnichannelInboxLabels';
import { Modal } from '../ui/Modal';
import type { OmnichannelChannelType, OmnichannelRoutingRule } from '../../types/omnichannel';
import { useToastContext } from '../../contexts/ToastContext';
import { resolveRoutingSimulation } from '../../utils/omnichannelIntegration';
import { cn } from '../../utils/cn';

interface RoutingDraft {
  id?: string;
  name: string;
  channel: string;
  destinationTeam: string;
  fallbackTeam: string;
  priority: string;
  keywords: string;
  language: string;
  sampleMessage: string;
}

const emptyDraft: RoutingDraft = {
  name: '',
  channel: '',
  destinationTeam: '',
  fallbackTeam: '',
  priority: '1',
  keywords: '',
  language: 'en',
  sampleMessage: '',
};

export const OmnichannelRoutingPage: React.FC = () => {
  const { t, locale, direction } = useLocale();
  const isRTL = direction === 'rtl';
  const toast = useToastContext();
  const {
    routingRules: rules,
    addRoutingRule,
    updateRoutingRule,
    deleteRoutingRule,
    duplicateRoutingRule: storeDuplicateRoutingRule,
    enableRoutingRule,
    reorderRoutingRules,
  } = useOmnichannelMockStore();
  const [draft, setDraft] = useState<RoutingDraft>(emptyDraft);
  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);
  const [deleteRuleId, setDeleteRuleId] = useState<string | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [simulationResult, setSimulationResult] = useState<string | null>(null);

  const duplicateName = useMemo(
    () =>
      rules.some(
        (rule) =>
          rule.id !== editingRuleId &&
          localized(rule.name, locale).toLowerCase() === draft.name.trim().toLowerCase()
      ),
    [draft.name, editingRuleId, locale, rules]
  );

  const duplicatePriority = useMemo(
    () =>
      rules.some(
        (rule) => rule.id !== editingRuleId && String(rule.priority) === draft.priority && rule.status !== 'draft'
      ),
    [draft.priority, editingRuleId, rules]
  );

  const queueLabel = (queueId: string) =>
    localized(mockOmnichannelQueues.find((queue) => queue.id === queueId)?.name ?? { en: queueId, ar: queueId }, locale);

  const resetDraft = () => {
    setDraft(emptyDraft);
    setEditingRuleId(null);
    setIsEditorOpen(false);
  };

  const openEditor = (rule?: OmnichannelRoutingRule) => {
    if (!rule) {
      setDraft({ ...emptyDraft, priority: String(rules.length + 1) });
      setEditingRuleId(null);
      setIsEditorOpen(true);
      return;
    }

    setDraft({
      id: rule.id,
      name: localized(rule.name, locale),
      channel: rule.conditions.find((condition) => condition.field === 'channelType')?.value ?? '',
      destinationTeam: rule.targetQueueId,
      fallbackTeam: rule.fallbackQueueId ?? '',
      priority: String(rule.priority),
      keywords: rule.keywords?.join(', ') ?? '',
      language: rule.language === 'any' ? 'en' : rule.language ?? 'en',
      sampleMessage: '',
    });
    setEditingRuleId(rule.id);
    setIsEditorOpen(true);
  };

  const saveRule = () => {
    if (!draft.name.trim() || !draft.channel || !draft.destinationTeam) {
      toast.warning(t('omnichannel.routing.validationTitle'), t('omnichannel.routing.validationRequiredFields'));
      return;
    }

    const nextRule = {
      name: { en: draft.name, ar: draft.name },
      status: 'active' as const,
      priority: Number(draft.priority),
      conditions: [
        { field: 'channelType' as const, operator: 'equals' as const, value: draft.channel },
        { field: 'language' as const, operator: 'equals' as const, value: draft.language },
      ],
      targetQueueId: draft.destinationTeam,
      fallbackQueueId: draft.fallbackTeam || undefined,
      assignToStaffId: undefined,
      autoTagIds: [],
      keywords: draft.keywords.split(',').map((item) => item.trim()).filter(Boolean),
      language: draft.language === 'ar' ? ('ar' as const) : ('en' as const),
    };

    if (editingRuleId) {
      updateRoutingRule(editingRuleId, nextRule);
    } else {
      addRoutingRule(nextRule);
    }
    toast.success(t('omnichannel.routing.ruleSavedTitle'), t('omnichannel.routing.ruleSavedDescription'));
    resetDraft();
  };

  const duplicateRule = (rule: OmnichannelRoutingRule) => {
    storeDuplicateRoutingRule(rule.id);
    toast.success(t('omnichannel.routing.ruleDuplicatedTitle'), t('omnichannel.routing.ruleDuplicatedDescription'));
  };

  const movePriority = (ruleId: string, direction: 'up' | 'down') => {
    const sorted = [...rules].sort((first, second) => first.priority - second.priority);
    const index = sorted.findIndex((rule) => rule.id === ruleId);
    if (index === -1) {
      return;
    }
    const swapIndex = direction === 'up' ? index - 1 : index + 1;
    if (swapIndex < 0 || swapIndex >= sorted.length) {
      return;
    }
    const swap = sorted[index];
    sorted[index] = sorted[swapIndex];
    sorted[swapIndex] = swap;
    reorderRoutingRules(sorted);
  };

  const simulateRule = () => {
    const normalizedMessage = draft.sampleMessage.toLowerCase();
    const matchedRule = rules.find((rule) => {
      const channelMatch = !draft.channel || rule.conditions.some((condition) => condition.value === draft.channel);
      const keywordMatch = !rule.keywords?.length || rule.keywords.some((keyword) => normalizedMessage.includes(keyword.toLowerCase()));
      return channelMatch && keywordMatch;
    });

    const result = resolveRoutingSimulation(rules, {
      channelType: (draft.channel || 'website_chat') as OmnichannelChannelType,
      language: draft.language === 'ar' ? 'ar' : 'en',
      messageText: draft.sampleMessage,
    });

    setSimulationResult(
      result.matchedRule
        ? `${localized(result.matchedRule.name, locale)} -> ${queueLabel(result.matchedQueueId ?? result.matchedRule.targetQueueId)}`
        : t('omnichannel.routing.noMatchedRule')
    );
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
          <div>
            <h1 className="text-2xl font-bold">{t('omnichannel.routing.title')}</h1>
            <p className="mt-1 text-white/80">{t('omnichannel.routing.subtitle')}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => openEditor()} variant="ghost" className="bg-white text-blue-600 hover:bg-white/90 hover:text-blue-700 border-0">
              <Plus className="h-4 w-4" />
              {t('omnichannel.actions.createRule')}
            </Button>
          </div>
        </div>
      <OmnichannelStateNotice
        tone="info"
        title={t('omnichannel.routing.simulationNoticeTitle')}
        description={t('omnichannel.routing.simulationNoticeDescription')}
      />

      <div className="grid gap-4 xl:grid-cols-[1.3fr_1fr]">
        <OmnichannelSectionCard title={t('omnichannel.routing.rulesTable')}>
          <div className="space-y-3">
            {rules
              .slice()
              .sort((first, second) => first.priority - second.priority)
              .map((rule) => (
                <div key={rule.id} className="rounded-lg border border-gray-100 p-4 dark:border-gray-800">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="font-semibold text-gray-900 dark:text-white">{localized(rule.name, locale)}</div>
                      <div className="mt-1 text-xs text-gray-500">{rule.conditions.map((condition) => condition.value).join(' | ')}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <StatusBadge variant={rule.status === 'active' ? 'emerald' : rule.status === 'paused' ? 'amber' : 'gray'}>
                        {t(routingStatusLabelKeys[rule.status])}
                      </StatusBadge>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => enableRoutingRule(rule.id, rule.status !== 'active')}
                      >
                        {rule.status === 'active' ? t('omnichannel.actions.disable') : t('omnichannel.actions.enable')}
                      </Button>
                    </div>
                  </div>
                    <div className="mt-3 grid gap-2 text-sm text-gray-600 dark:text-gray-300 md:grid-cols-3">
                      <div>
                      {t('omnichannel.routing.destinationTeam')}: <span className="font-semibold">{queueLabel(rule.targetQueueId)}</span>
                      </div>
                      <div>
                      {t('omnichannel.routing.fallbackTeam')}: <span className="font-semibold">{rule.fallbackQueueId ? queueLabel(rule.fallbackQueueId) : t('common.notAvailable')}</span>
                      </div>
                    <div>
                      {t('omnichannel.routing.priorityOrder')}: <span className="font-semibold bidi-isolate">{rule.priority}</span>
                    </div>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button size="sm" variant="outline" onClick={() => openEditor(rule)}>
                      {t('common.edit')}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => duplicateRule(rule)}>
                      {t('omnichannel.actions.duplicateRule')}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => movePriority(rule.id, 'up')}>
                      {t('omnichannel.actions.moveUp')}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => movePriority(rule.id, 'down')}>
                      {t('omnichannel.actions.moveDown')}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setDeleteRuleId(rule.id)}>
                      <Trash2 className="h-4 w-4" />
                      {t('common.delete')}
                    </Button>
                  </div>
                </div>
              ))}
          </div>
        </OmnichannelSectionCard>

        <OmnichannelSectionCard
          title={t('omnichannel.routing.testPanel')}
          action={
            <Button variant="outline" onClick={simulateRule}>
              {t('omnichannel.actions.simulateIncoming')}
            </Button>
          }
        >
          <div className="space-y-4">
            <FilterField label={t('omnichannel.routing.channel')} value={draft.channel} onChange={(value) => setDraft((current) => ({ ...current, channel: value }))}>
              <option value="">{t('omnichannel.common.selectOption')}</option>
              <option value="website_chat">{t(channelLabelKeys.website_chat)}</option>
              <option value="email">{t(channelLabelKeys.email)}</option>
              <option value="whatsapp">{t(channelLabelKeys.whatsapp)}</option>
            </FilterField>
            <FilterField label={t('omnichannel.routing.language')} value={draft.language} onChange={(value) => setDraft((current) => ({ ...current, language: value }))}>
              <option value="en">{t('common.english')}</option>
              <option value="ar">{t('common.arabic')}</option>
            </FilterField>
            <label className="block">
              <div className="mb-1 text-xs font-semibold text-gray-500">{t('omnichannel.routing.sampleMessage')}</div>
              <textarea
                value={draft.sampleMessage}
                onChange={(event) => setDraft((current) => ({ ...current, sampleMessage: event.target.value }))}
                rows={4}
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900"
              />
            </label>
            <div className="rounded-lg border border-dashed border-gray-200 p-4 text-sm text-gray-600 dark:border-gray-800 dark:text-gray-300">
              <div className="mb-2 flex items-center gap-2 font-semibold text-gray-900 dark:text-white">
                <GitBranch className="h-4 w-4 text-blue-600" />
                {t('omnichannel.routing.matchResult')}
              </div>
              {simulationResult ?? t('omnichannel.routing.simulationPlaceholder')}
            </div>
            {simulationResult === t('omnichannel.routing.noMatchedRule') ? (
              <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-100">
                <div className="flex items-start gap-2">
                  <ShieldAlert className="mt-0.5 h-4 w-4" />
                  <span>{t('omnichannel.routing.fallbackPathNotice')}</span>
                </div>
              </div>
            ) : null}
          </div>
        </OmnichannelSectionCard>
      </div>

      <Modal isOpen={isEditorOpen} onClose={resetDraft} title={t('omnichannel.routing.ruleBuilder')} size="lg">
        <div className="space-y-4">
          <TextField label={t('omnichannel.routing.ruleName')} value={draft.name} onChange={(value) => setDraft((current) => ({ ...current, name: value }))} />
          <div className="grid gap-4 md:grid-cols-2">
            <FilterField label={t('omnichannel.routing.channel')} value={draft.channel} onChange={(value) => setDraft((current) => ({ ...current, channel: value }))}>
              <option value="">{t('omnichannel.common.selectOption')}</option>
              <option value="website_chat">{t(channelLabelKeys.website_chat)}</option>
              <option value="email">{t(channelLabelKeys.email)}</option>
              <option value="whatsapp">{t(channelLabelKeys.whatsapp)}</option>
            </FilterField>
            <FilterField label={t('omnichannel.routing.destinationTeam')} value={draft.destinationTeam} onChange={(value) => setDraft((current) => ({ ...current, destinationTeam: value }))}>
              <option value="">{t('omnichannel.common.selectOption')}</option>
              {mockOmnichannelQueues.map((queue) => (
                <option key={queue.id} value={queue.id}>
                  {queueLabel(queue.id)}
                </option>
              ))}
            </FilterField>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <FilterField label={t('omnichannel.routing.fallbackTeam')} value={draft.fallbackTeam} onChange={(value) => setDraft((current) => ({ ...current, fallbackTeam: value }))}>
              <option value="">{t('common.notAvailable')}</option>
              {mockOmnichannelQueues.map((queue) => (
                <option key={queue.id} value={queue.id}>
                  {queueLabel(queue.id)}
                </option>
              ))}
            </FilterField>
            <TextField label={t('omnichannel.routing.priorityOrder')} value={draft.priority} onChange={(value) => setDraft((current) => ({ ...current, priority: value }))} />
          </div>
          <TextField label={t('omnichannel.routing.keywords')} value={draft.keywords} onChange={(value) => setDraft((current) => ({ ...current, keywords: value }))} />
          {duplicateName ? (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-100">
              {t('omnichannel.routing.duplicateWarning')}
            </div>
          ) : null}
          {duplicatePriority ? (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-100">
              {t('omnichannel.routing.duplicatePriorityWarning')}
            </div>
          ) : null}
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={resetDraft}>
              {t('common.cancel')}
            </Button>
            <Button disabled={!draft.name.trim() || !draft.channel || !draft.destinationTeam || duplicateName} onClick={saveRule}>
              {t('omnichannel.actions.saveMockRule')}
            </Button>
          </div>
        </div>
      </Modal>

      <OmnichannelConfirmationModal
        isOpen={Boolean(deleteRuleId)}
        title={t('omnichannel.routing.deleteRuleTitle')}
        description={t('omnichannel.routing.deleteRuleDescription')}
        confirmLabel={t('common.delete')}
        tone="danger"
        onClose={() => setDeleteRuleId(null)}
        onConfirm={() => {
          if (deleteRuleId) {
            deleteRoutingRule(deleteRuleId);
            toast.success(t('omnichannel.routing.ruleDeletedTitle'), t('omnichannel.routing.ruleDeletedDescription'));
          }
          setDeleteRuleId(null);
        }}
      />
      </div>
    </div>
  );
};

const localized = (value: { en: string; ar: string }, locale: 'en' | 'ar') => (locale === 'ar' ? value.ar : value.en);

const TextField: React.FC<{ label: string; value: string; onChange: (value: string) => void }> = ({ label, value, onChange }) => (
  <label className="block">
    <div className="mb-1 text-xs font-semibold text-gray-500">{label}</div>
    <input
      value={value}
      onChange={(event) => onChange(event.target.value)}
      className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900"
    />
  </label>
);

const FilterField: React.FC<{
  label: string;
  value: string;
  onChange: (value: string) => void;
  children: React.ReactNode;
}> = ({ label, value, onChange, children }) => (
  <label className="block">
    <div className="mb-1 text-xs font-semibold text-gray-500">{label}</div>
    <select
      value={value}
      onChange={(event) => onChange(event.target.value)}
      className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900"
    >
      {children}
    </select>
  </label>
);
