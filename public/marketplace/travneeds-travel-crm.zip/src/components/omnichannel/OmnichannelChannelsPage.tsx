import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  PauseCircle,
  PlayCircle,
  RadioTower,
  RefreshCcw,
  RotateCcw,
  Settings2,
  ShieldCheck,
} from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { OmnichannelModuleShell } from './OmnichannelModuleShell';
import { OmnichannelDrawer, OmnichannelStateNotice } from './OmnichannelInteractions';
import { OmnichannelSectionCard, OmnichannelStatsGrid, type OmnichannelStatItem } from './OmnichannelUi';
import { Button } from '../ui/Button';
import { StatusBadge } from '../ui/StatusBadge';
import { useToastContext } from '../../contexts/ToastContext';
import {
  mockOmnichannelChannelConfigurations,
  mockOmnichannelChannels,
  mockOmnichannelSlaPolicies,
} from '../../services/omnichannelMockData';
import { calculateChannelHealth } from '../../utils/omnichannelMetrics';
import type { OmnichannelChannel, OmnichannelChannelConfiguration } from '../../types/omnichannel';
import { cn } from '../../utils/cn';
import { Card, CardContent } from '../ui/Card';
import { OmnichannelChannelConfigModal } from './channels/OmnichannelChannelConfigModal';
import { connectionStatusLabelKeys, healthStatusLabelKeys } from './inbox/omnichannelInboxLabels';

type ChannelDrawerMode = 'logs' | 'health' | 'wizard' | null;

export const OmnichannelChannelsPage: React.FC = () => {
  const { t, locale, direction } = useLocale();
  const isRTL = direction === 'rtl';
  const toast = useToastContext();
  const {
    channels,
    channelConfigurations: configurations,
    channelEvents,
    pauseChannel,
    resumeChannel,
    syncChannel,
    reconnectChannel: storeReconnectChannel,
    testChannelConnection,
    saveChannelConfiguration,
    addChannelLogEvent,
  } = useOmnichannelMockStore();
  const [selectedChannelId, setSelectedChannelId] = useState<string | null>(null);
  const [drawerMode, setDrawerMode] = useState<ChannelDrawerMode>(null);
  const [drawerChannelId, setDrawerChannelId] = useState<string | null>(null);
  const [testingChannelId, setTestingChannelId] = useState<string | null>(null);
  const [syncingChannelId, setSyncingChannelId] = useState<string | null>(null);

  const selectedChannel = channels.find((channel) => channel.id === selectedChannelId) ?? null;
  const selectedConfig = configurations.find((config) => config.channelId === selectedChannelId) ?? null;
  const drawerChannel = channels.find((channel) => channel.id === drawerChannelId) ?? null;

  const stats: OmnichannelStatItem[] = [
    {
      id: 'connected',
      label: t('omnichannel.channels.connectedChannels'),
      value: channels.filter((channel) => channel.health.connectionStatus === 'connected').length,
      icon: CheckCircle2,
      trend: '+1',
      trendType: 'up',
    },
    {
      id: 'warning',
      label: t('omnichannel.channels.degradedChannels'),
      value: channels.filter((channel) => calculateChannelHealth(channel).status === 'degraded').length,
      icon: RefreshCcw,
      trend: '0',
      trendType: 'neutral',
    },
    {
      id: 'critical',
      label: t('omnichannel.channels.criticalChannels'),
      value: channels.filter((channel) => calculateChannelHealth(channel).status === 'critical').length,
      icon: ShieldCheck,
      trend: '-1',
      trendType: 'down',
    },
  ];

  const policiesById = useMemo(() => Object.fromEntries(mockOmnichannelSlaPolicies.map((policy) => [policy.id, policy])), []);

  const localized = (value: { en: string; ar: string }) => (locale === 'ar' ? value.ar : value.en);

  const openDrawer = (mode: ChannelDrawerMode, channelId: string) => {
    setDrawerMode(mode);
    setDrawerChannelId(channelId);
  };

  const handleToggle = (channelId: string, paused: boolean) => {
    if (paused) {
      resumeChannel(channelId);
      addChannelLogEvent(channelId, t('omnichannel.channels.channelResumed'));
      toast.success(t('omnichannel.channels.statusUpdated'), t('omnichannel.channels.channelResumed'));
    } else {
      pauseChannel(channelId);
      addChannelLogEvent(channelId, t('omnichannel.channels.channelPaused'));
      toast.success(t('omnichannel.channels.statusUpdated'), t('omnichannel.channels.channelPaused'));
    }
  };

  const handleSaveConfiguration = async (nextConfig: OmnichannelChannelConfiguration) => {
    await new Promise((resolve) => window.setTimeout(resolve, 300));
    saveChannelConfiguration(nextConfig.channelId, nextConfig);
    addChannelLogEvent(nextConfig.channelId, t('omnichannel.channels.configurationSavedDescription'));
    toast.success(t('omnichannel.channels.configurationSaved'), t('omnichannel.channels.configurationSavedDescription'));
  };

  const testConnection = async (channelId: string) => {
    setTestingChannelId(channelId);
    await new Promise((resolve) => window.setTimeout(resolve, 700));
    setTestingChannelId(null);
    testChannelConnection(channelId);
    const channel = channels.find((item) => item.id === channelId);
    if (!channel) {
      return;
    }
    const success = channel.health.status !== 'critical' && channel.health.connectionStatus !== 'disconnected';
    addChannelLogEvent(channelId, success ? t('omnichannel.channels.testConnectionSuccess') : t('omnichannel.channels.testConnectionFailure'));
    toast[success ? 'success' : 'warning'](
      t('omnichannel.channels.testConnectionTitle'),
      success ? t('omnichannel.channels.testConnectionSuccess') : t('omnichannel.channels.testConnectionFailure')
    );
  };

  const syncTemplates = async (channelId: string) => {
    setSyncingChannelId(channelId);
    await new Promise((resolve) => window.setTimeout(resolve, 600));
    setSyncingChannelId(null);
    syncChannel(channelId);
    addChannelLogEvent(channelId, t('omnichannel.channels.syncTemplatesSuccess'));
    toast.success(t('omnichannel.channels.syncTemplatesTitle'), t('omnichannel.channels.syncTemplatesSuccess'));
  };

  const reconnectChannel = async (channelId: string) => {
    setTestingChannelId(channelId);
    await new Promise((resolve) => window.setTimeout(resolve, 550));
    setTestingChannelId(null);
    storeReconnectChannel(channelId);
    addChannelLogEvent(channelId, t('omnichannel.channels.reconnectSuccess'));
    toast.success(t('omnichannel.channels.reconnectTitle'), t('omnichannel.channels.reconnectSuccess'));
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
          <div>
            <h1 className="text-2xl font-bold">{t('omnichannel.channels.title')}</h1>
            <p className="mt-1 text-white/80">{t('omnichannel.channels.subtitle')}</p>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {stats.map((item) => {
            const Icon = item.icon;
            return (
              <Card key={item.id} className="border-none shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group cursor-pointer" onClick={item.onClick}>
                <CardContent className="p-6">
                  <div className="relative z-10 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-semibold text-gray-500">{item.label}</div>
                      <div className="mt-1 text-2xl font-bold text-gray-950 dark:text-white bidi-isolate">{item.value}</div>
                    </div>
                  </div>
                  <Icon className="absolute ltr:-right-4 rtl:-left-4 -bottom-4 h-24 w-24 text-blue-500/10 group-hover:scale-110 transition-transform duration-300" />
                </CardContent>
              </Card>
            );
          })}
        </div>

      <OmnichannelStateNotice
        tone="warning"
        title={t('omnichannel.channels.credentialsWarningTitle')}
        description={t('omnichannel.channels.credentialsWarningDescription')}
      />

      <OmnichannelSectionCard title={t('omnichannel.channels.gridTitle')} description={t('omnichannel.channels.gridDescription')}>
        <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-3">
          {channels.map((channel) => {
            const health = calculateChannelHealth(channel);
            const config = configurations.find((item) => item.channelId === channel.id);
            const policy = config ? policiesById[config.defaultSlaPolicyId] : undefined;
            const connectionActive = channel.health.connectionStatus === 'connected';

            return (
              <article key={channel.id} className="rounded-lg border border-gray-200 p-4 dark:border-gray-800">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <button type="button" onClick={() => openDrawer('health', channel.id)} className="text-sm font-bold text-gray-900 dark:text-white">
                      {channel.name}
                    </button>
                    <div className="mt-1 text-xs text-gray-500 bidi-isolate">{channel.accountLabel}</div>
                  </div>
                  <StatusBadge variant={health.status === 'critical' ? 'rose' : health.status === 'degraded' ? 'amber' : health.status === 'offline' ? 'gray' : 'emerald'}>
                    {t(healthStatusLabelKeys[health.status])}
                  </StatusBadge>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                  <Info label={t('omnichannel.channels.connectionStatus')} value={t(connectionStatusLabelKeys[channel.health.connectionStatus])} />
                  <Info label={t('omnichannel.channels.messageVolume')} value={String(channel.health.openConversations)} />
                  <Info label={t('omnichannel.channels.lastSync')} value={channel.health.lastSyncAt ? new Date(channel.health.lastSyncAt).toLocaleString() : t('common.notAvailable')} />
                  <Info label={t('omnichannel.channels.assignedTeam')} value={config?.assignedTeamId ?? t('common.notAvailable')} />
                  <Info label={t('omnichannel.channels.defaultSla')} value={policy ? localized(policy.name) : t('common.notAvailable')} />
                  <Info label={t('omnichannel.channels.primaryLanguage')} value={config?.primaryLanguage.toUpperCase() ?? t('common.notAvailable')} />
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => setSelectedChannelId(channel.id)}>
                    <Settings2 className="h-4 w-4" />
                    {t('omnichannel.actions.configure')}
                  </Button>
                  <Button size="sm" variant="outline" loading={testingChannelId === channel.id} onClick={() => testConnection(channel.id)}>
                    <RefreshCcw className="h-4 w-4" />
                    {t('omnichannel.actions.testConnection')}
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => openDrawer('logs', channel.id)}>
                    <RadioTower className="h-4 w-4" />
                    {t('omnichannel.actions.viewLogs')}
                  </Button>
                  {connectionActive ? (
                    <Button size="sm" variant="ghost" onClick={() => handleToggle(channel.id, false)}>
                      <PauseCircle className="h-4 w-4" />
                      {t('omnichannel.actions.pause')}
                    </Button>
                  ) : (
                    <Button size="sm" variant="ghost" onClick={() => handleToggle(channel.id, true)}>
                      <PlayCircle className="h-4 w-4" />
                      {t('omnichannel.actions.resume')}
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" loading={syncingChannelId === channel.id} onClick={() => syncTemplates(channel.id)}>
                    {t('omnichannel.actions.syncTemplates')}
                  </Button>
                  <Button size="sm" variant="ghost" loading={testingChannelId === channel.id} onClick={() => reconnectChannel(channel.id)}>
                    <RotateCcw className="h-4 w-4" />
                    {t('omnichannel.actions.reconnect')}
                  </Button>
                  {!config ? (
                    <Button size="sm" variant="ghost" onClick={() => openDrawer('wizard', channel.id)}>
                      {t('omnichannel.actions.connect')}
                    </Button>
                  ) : null}
                </div>
              </article>
            );
          })}
        </div>
      </OmnichannelSectionCard>

      <OmnichannelChannelConfigModal
        isOpen={Boolean(selectedChannel)}
        channel={selectedChannel}
        configuration={selectedConfig}
        onClose={() => setSelectedChannelId(null)}
        onSave={handleSaveConfiguration}
      />

      <OmnichannelDrawer
        isOpen={Boolean(drawerMode && drawerChannel)}
        title={
          drawerMode === 'logs'
            ? t('omnichannel.channels.logsTitle')
            : drawerMode === 'wizard'
              ? t('omnichannel.channels.setupWizardTitle')
              : t('omnichannel.channels.healthDrawerTitle')
        }
        description={drawerChannel?.name}
        onClose={() => {
          setDrawerMode(null);
          setDrawerChannelId(null);
        }}
        footer={
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setDrawerMode(null)}>
              {t('common.close')}
            </Button>
            {drawerMode === 'wizard' && drawerChannel ? (
              <Button
                onClick={() => {
                  setSelectedChannelId(drawerChannel.id);
                  setDrawerMode(null);
                }}
              >
                {t('omnichannel.actions.startSetup')}
              </Button>
            ) : null}
          </div>
        }
      >
        {drawerMode === 'logs' && drawerChannel ? (
          <div className="space-y-3">
            <div className="rounded-lg border border-gray-200 p-4 dark:border-gray-800">
              <div className="font-semibold text-gray-900 dark:text-white">{t('omnichannel.channels.logsTitle')}</div>
              <div className="mt-2 space-y-2 text-sm text-gray-500">
                {(channelEvents[drawerChannel.id] ?? []).length > 0 ? (
                  (channelEvents[drawerChannel.id] ?? []).map((event) => (
                    <div key={event} className="rounded-lg border border-gray-100 p-2 dark:border-gray-800">
                      {event}
                    </div>
                  ))
                ) : (
                  <div>{t('omnichannel.channels.healthNote')}</div>
                )}
              </div>
            </div>
            <div className="rounded-lg border border-gray-200 p-4 dark:border-gray-800">
              <div className="font-semibold text-gray-900 dark:text-white">{t('omnichannel.channels.lastSync')}</div>
              <div className="mt-1 text-sm text-gray-500">{drawerChannel.health.lastSyncAt ?? t('common.notAvailable')}</div>
            </div>
            <div className="rounded-lg border border-gray-200 p-4 dark:border-gray-800">
              <div className="font-semibold text-gray-900 dark:text-white">{t('omnichannel.channels.webhookStatus')}</div>
              <div className="mt-1 text-sm text-gray-500">{drawerChannel.health.webhookStatus}</div>
            </div>
            <div className="rounded-lg border border-gray-200 p-4 dark:border-gray-800">
              <div className="font-semibold text-gray-900 dark:text-white">{t('omnichannel.channels.failuresToday')}</div>
              <div className="mt-1 text-sm text-gray-500 bidi-isolate">{drawerChannel.health.failedEventsToday}</div>
            </div>
          </div>
        ) : null}

        {drawerMode === 'health' && drawerChannel ? (
          <div className="space-y-3">
            <MetricRow label={t('omnichannel.channels.uptime')} value={`${Math.max(drawerChannel.health.healthScore, 12)}%`} />
            <MetricRow label={t('omnichannel.channels.lastSync')} value={drawerChannel.health.lastSyncAt ?? t('common.notAvailable')} />
            <MetricRow label={t('omnichannel.channels.webhookStatus')} value={drawerChannel.health.webhookStatus} />
            <MetricRow label={t('omnichannel.channels.permissions')} value={drawerChannel.provider} />
            <MetricRow label={t('omnichannel.channels.messageFailures')} value={String(drawerChannel.health.failedEventsToday)} />
            <MetricRow label={t('omnichannel.channels.healthNote')} value={drawerChannel.health.notes} />
          </div>
        ) : null}

        {drawerMode === 'wizard' && drawerChannel ? (
          <div className="space-y-4">
            <OmnichannelStateNotice
              tone="info"
              title={t('omnichannel.channels.setupWizardHintTitle')}
              description={t('omnichannel.channels.setupWizardHintDescription')}
            />
            <div className="rounded-lg border border-gray-200 p-4 dark:border-gray-800">
              <div className="text-sm font-semibold text-gray-900 dark:text-white">{t('omnichannel.channels.requiredFields')}</div>
              <ul className="mt-2 space-y-2 text-sm text-gray-500">
                <li>{t('omnichannel.channels.requiredFieldDisplayName')}</li>
                <li>{t('omnichannel.channels.requiredFieldTeam')}</li>
                <li>{t('omnichannel.channels.requiredFieldLanguage')}</li>
              </ul>
            </div>
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-100">
              <div className="flex items-start gap-3">
                <AlertTriangle className="mt-0.5 h-4 w-4" />
                <div>{t('omnichannel.channels.mockCredentialsWarning')}</div>
              </div>
            </div>
          </div>
        ) : null}
      </OmnichannelDrawer>
      </div>
    </div>
  );
};

const Info: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div>
    <div className="text-xs font-semibold text-gray-500">{label}</div>
    <div className="mt-1 text-sm text-gray-900 dark:text-white bidi-isolate">{value}</div>
  </div>
);

const MetricRow: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
    <div className="text-xs font-semibold text-gray-500">{label}</div>
    <div className="mt-1 text-sm text-gray-900 dark:text-white">{value}</div>
  </div>
);
