import type { LucideIcon } from 'lucide-react';
import {
  Activity,
  BarChart3,
  FolderKanban,
  Megaphone,
  LayoutDashboard,
  MessageSquareText,
  RadioTower,
  Settings2,
  ShieldAlert,
  Tags,
  Users,
  Workflow,
  GitBranch,
  Wrench,
} from 'lucide-react';
import type { TranslationKey } from '../../localization/messages';

export interface OmnichannelNavItem {
  id: string;
  href: string;
  labelKey: TranslationKey;
  icon: LucideIcon;
}

export const omnichannelNavItems: OmnichannelNavItem[] = [
  { id: 'dashboard', href: '/omnichannel', labelKey: 'nav.omnichannelDashboard', icon: LayoutDashboard },
  { id: 'inbox', href: '/omnichannel/inbox', labelKey: 'nav.omnichannelInbox', icon: MessageSquareText },
  { id: 'conversations', href: '/omnichannel/conversations', labelKey: 'nav.omnichannelConversations', icon: FolderKanban },
  { id: 'channels', href: '/omnichannel/channels', labelKey: 'nav.omnichannelChannels', icon: RadioTower },
  { id: 'routing', href: '/omnichannel/routing', labelKey: 'nav.omnichannelRouting', icon: GitBranch },
  { id: 'automation', href: '/omnichannel/automation', labelKey: 'nav.omnichannelAutomation', icon: Workflow },
  { id: 'templates', href: '/omnichannel/templates', labelKey: 'nav.omnichannelTemplates', icon: Megaphone },
  { id: 'tags', href: '/omnichannel/tags', labelKey: 'nav.omnichannelTags', icon: Tags },
  { id: 'sla', href: '/omnichannel/sla', labelKey: 'nav.omnichannelSla', icon: ShieldAlert },
  { id: 'team', href: '/omnichannel/team', labelKey: 'nav.omnichannelTeam', icon: Users },
  { id: 'analytics', href: '/omnichannel/analytics', labelKey: 'nav.omnichannelAnalytics', icon: BarChart3 },
  { id: 'activity', href: '/omnichannel/activity', labelKey: 'nav.omnichannelActivity', icon: Activity },
  { id: 'settings', href: '/omnichannel/settings', labelKey: 'nav.omnichannelSettings', icon: Settings2 },
  { id: 'broadcasts', href: '/omnichannel/broadcasts', labelKey: 'nav.omnichannelBroadcasts', icon: Megaphone },
  { id: 'diagnostics', href: '/omnichannel/diagnostics', labelKey: 'nav.omnichannelDiagnostics', icon: Wrench },
];
