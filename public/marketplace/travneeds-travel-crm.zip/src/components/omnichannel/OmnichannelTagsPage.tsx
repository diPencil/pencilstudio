import React, { useMemo, useState } from 'react';
import { Tags } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { cn } from '../../utils/cn';
import { OmnichannelConfirmationModal, OmnichannelDrawer } from './OmnichannelInteractions';
import { OmnichannelSectionCard } from './OmnichannelUi';
import { mockOmnichannelConversations, mockOmnichannelLabels } from '../../services/omnichannelMockData';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { tagGroupLabelKeys } from './inbox/omnichannelInboxLabels';
import { useToastContext } from '../../contexts/ToastContext';
import type { OmnichannelLabelDefinition } from '../../types/omnichannel';
import { deriveTagUsage } from '../../utils/omnichannelIntegration';

export const OmnichannelTagsPage: React.FC = () => {
  const { t, locale, direction } = useLocale();
  const isRTL = direction === 'rtl' || locale === 'ar';
  const toast = useToastContext();
  const {
    labels,
    conversations,
    tagUsage: labelsWithUsage,
    addLabel,
    deleteLabel,
    duplicateLabel: storeDuplicateLabel,
  } = useOmnichannelMockStore();
  const [draftName, setDraftName] = useState('');
  const [draftColor, setDraftColor] = useState('bg-blue-50 text-blue-700 border-blue-100');
  const [draftType, setDraftType] = useState<OmnichannelLabelDefinition['type']>('tag');
  const [deleteLabelId, setDeleteLabelId] = useState<string | null>(null);
  const [detailsLabel, setDetailsLabel] = useState<OmnichannelLabelDefinition | null>(null);

  const duplicate = useMemo(
    () => labels.some((label) => (locale === 'ar' ? label.name.ar : label.name.en).toLowerCase() === draftName.trim().toLowerCase()),
    [draftName, labels, locale]
  );

  const grouped = ['tag', 'segment', 'priority_label', 'sla_label'].map((type) => ({
    type,
    items: labelsWithUsage.filter((label) => label.type === type),
  }));

  const createLabel = () => {
    if (!draftName.trim() || duplicate) {
      return;
    }
    addLabel({
      name: { en: draftName, ar: draftName },
      colorClass: draftColor,
      type: draftType,
    });
    setDraftName('');
    toast.success(t('omnichannel.tags.createdTitle'), t('omnichannel.tags.createdDescription'));
  };

  const duplicateLabel = (label: OmnichannelLabelDefinition) => {
    storeDuplicateLabel(label.id);
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
          <div>
            <h1 className="text-2xl font-bold">{t('omnichannel.tags.title')}</h1>
            <p className="mt-2 text-blue-100 opacity-90">{t('omnichannel.tags.subtitle')}</p>
          </div>
        </div>
      <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <OmnichannelSectionCard title={t('omnichannel.tags.libraryTitle')}>
          <div className="space-y-4">
            {grouped.map((group) => (
              <div key={group.type}>
                <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-gray-900 dark:text-white">
                  <Tags className="h-4 w-4 text-blue-600" />
                  {t(tagGroupLabelKeys[group.type as keyof typeof tagGroupLabelKeys])}
                </div>
                <div className="grid gap-3 md:grid-cols-2">
                  {group.items.map((label) => (
                    <div key={label.id} className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <div className="font-semibold text-gray-900 dark:text-white">{locale === 'ar' ? label.name.ar : label.name.en}</div>
                          <div className="text-xs text-gray-500">{`${label.conversationCount} ${t('omnichannel.tags.usageCount')}`}</div>
                        </div>
                        <span className={`rounded-full border px-2 py-1 text-xs font-medium ${label.colorClass}`}>{t('common.active')}</span>
                      </div>
                      <div className="mt-3 flex flex-wrap gap-2">
                        <Button size="sm" variant="outline" onClick={() => setDetailsLabel(label)}>
                          {t('omnichannel.actions.viewConversationsWithTag')}
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => duplicateLabel(label)}>
                          {t('omnichannel.actions.duplicateTag')}
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setDeleteLabelId(label.id)}>
                          {t('common.delete')}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </OmnichannelSectionCard>

        <OmnichannelSectionCard title={t('omnichannel.tags.createLabel')}>
          <div className="space-y-4">
            <Input label={t('common.title')} value={draftName} onChange={(event) => setDraftName(event.target.value)} />
            <label className="block">
              <div className="mb-1 text-xs font-semibold text-gray-500">{t('omnichannel.tags.groupSelector')}</div>
              <select value={draftType} onChange={(event) => setDraftType(event.target.value as OmnichannelLabelDefinition['type'])} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
                <option value="tag">{t('omnichannel.tags.group.tag')}</option>
                <option value="segment">{t('omnichannel.tags.group.segment')}</option>
                <option value="priority_label">{t('omnichannel.tags.group.priority')}</option>
                <option value="sla_label">{t('omnichannel.tags.group.sla')}</option>
              </select>
            </label>
            <label className="block">
              <div className="mb-1 text-xs font-semibold text-gray-500">{t('omnichannel.tags.colorSelector')}</div>
              <select value={draftColor} onChange={(event) => setDraftColor(event.target.value)} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
                <option value="bg-blue-50 text-blue-700 border-blue-100">{t('omnichannel.tags.colorBlue')}</option>
                <option value="bg-emerald-50 text-emerald-700 border-emerald-100">{t('omnichannel.tags.colorGreen')}</option>
                <option value="bg-amber-50 text-amber-700 border-amber-100">{t('omnichannel.tags.colorAmber')}</option>
                <option value="bg-rose-50 text-rose-700 border-rose-100">{t('omnichannel.tags.colorRose')}</option>
              </select>
            </label>
            {duplicate ? (
              <div className="rounded-lg border border-rose-200 bg-rose-50 p-3 text-sm text-rose-700 dark:border-rose-900 dark:bg-rose-950/30 dark:text-rose-100">
                {t('omnichannel.tags.duplicateWarning')}
              </div>
            ) : null}
            <Button disabled={!draftName.trim() || duplicate} onClick={createLabel}>
              {t('omnichannel.actions.createTag')}
            </Button>
          </div>
        </OmnichannelSectionCard>
      </div>

      <OmnichannelDrawer
        isOpen={Boolean(detailsLabel)}
        title={detailsLabel ? (locale === 'ar' ? detailsLabel.name.ar : detailsLabel.name.en) : ''}
        description={t('omnichannel.tags.segmentRulesPreview')}
        onClose={() => setDetailsLabel(null)}
      >
        {detailsLabel ? (
          <div className="space-y-3">
            <div className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
              <div className="text-xs font-semibold text-gray-500">{t('omnichannel.tags.usageCount')}</div>
              <div className="mt-1 text-sm text-gray-900 dark:text-white">
                {conversations.filter((conversation) => conversation.tagIds.includes(detailsLabel.id)).length}
              </div>
            </div>
            <div className="rounded-lg border border-gray-200 p-3 text-sm text-gray-500 dark:border-gray-800">
              {t('omnichannel.tags.segmentRulesDescription')}
            </div>
            <div className="rounded-lg border border-gray-200 p-3 dark:border-gray-800">
              <div className="text-xs font-semibold text-gray-500">{t('omnichannel.actions.viewConversationsWithTag')}</div>
              <div className="mt-2 space-y-2">
                {conversations.filter((conversation) => conversation.tagIds.includes(detailsLabel.id)).map((conversation) => (
                  <div key={conversation.id} className="rounded-lg border border-gray-100 p-2 text-sm dark:border-gray-800">
                    <div className="font-semibold text-gray-900 dark:text-white">{conversation.customer.name}</div>
                    <div className="text-xs text-gray-500 ltr-value">{conversation.id}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : null}
      </OmnichannelDrawer>

      <OmnichannelConfirmationModal
        isOpen={Boolean(deleteLabelId)}
        title={t('omnichannel.tags.deleteTitle')}
        description={t('omnichannel.tags.deleteDescription')}
        confirmLabel={t('common.delete')}
        tone="danger"
        onClose={() => setDeleteLabelId(null)}
        onConfirm={() => {
          if (deleteLabelId) {
            const success = deleteLabel(deleteLabelId);
            if (!success) {
              toast.warning(t('omnichannel.tags.deleteTitle'), t('omnichannel.tags.deleteInUseDescription'));
            }
          }
          setDeleteLabelId(null);
        }}
      />
      </div>
    </div>
  );
};
