import React, { useEffect, useState } from 'react';
import { Modal } from '../../ui/Modal';
import { Input } from '../../ui/Input';
import { Select } from '../../ui/Select';
import { Button } from '../../ui/Button';
import { useLocale } from '../../../localization/useLocale';
import type { OmnichannelChannel, OmnichannelChannelConfiguration } from '../../../types/omnichannel';

interface OmnichannelChannelConfigModalProps {
  isOpen: boolean;
  channel: OmnichannelChannel | null;
  configuration: OmnichannelChannelConfiguration | null;
  onClose: () => void;
  onSave: (configuration: OmnichannelChannelConfiguration) => Promise<void>;
}

type ChannelConfigForm = OmnichannelChannelConfiguration;

export const OmnichannelChannelConfigModal: React.FC<OmnichannelChannelConfigModalProps> = ({
  isOpen,
  channel,
  configuration,
  onClose,
  onSave,
}) => {
  const { t } = useLocale();
  const [form, setForm] = useState<ChannelConfigForm | null>(configuration);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    setForm(configuration);
    setErrors({});
  }, [configuration]);

  if (!channel || !form) {
    return null;
  }

  const setField = <K extends keyof ChannelConfigForm>(key: K, value: ChannelConfigForm[K]) => {
    setForm((current) => current ? { ...current, [key]: value } : current);
    setErrors((current) => ({ ...current, [String(key)]: '' }));
  };

  const validate = () => {
    const nextErrors: Record<string, string> = {};

    if (channel.type === 'whatsapp_business' && !form.phoneNumber) {
      nextErrors.phoneNumber = t('omnichannel.validation.required');
    }
    if (channel.type === 'website_chat' && !form.widgetTitle) {
      nextErrors.widgetTitle = t('omnichannel.validation.required');
    }
    if (channel.type === 'email' && !form.mailboxName) {
      nextErrors.mailboxName = t('omnichannel.validation.required');
    }
    if (channel.type === 'sms' && !form.senderId) {
      nextErrors.senderId = t('omnichannel.validation.required');
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSave = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!validate() || !form) {
      return;
    }

    setIsSaving(true);
    try {
      await onSave(form);
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={t('omnichannel.channels.configTitle')} size="xl">
      <form className="space-y-6" onSubmit={handleSave}>
        <div className="grid gap-4 md:grid-cols-2">
          <Input label={t('omnichannel.channels.primaryLanguage')} value={form.primaryLanguage.toUpperCase()} disabled />
          <Input label={t('omnichannel.channels.provider')} value={form.provider ?? ''} onChange={(event) => setField('provider', event.target.value)} />

          {(channel.type === 'whatsapp' || channel.type === 'whatsapp_business') && (
            <>
              <Input label={t('omnichannel.channels.phoneNumber')} value={form.phoneNumber ?? ''} onChange={(event) => setField('phoneNumber', event.target.value)} error={errors.phoneNumber} />
              <Input label={t('omnichannel.channels.displayName')} value={form.displayName ?? ''} onChange={(event) => setField('displayName', event.target.value)} />
              <Input label={t('omnichannel.channels.businessId')} value={form.businessId ?? ''} onChange={(event) => setField('businessId', event.target.value)} />
              <Input label={t('omnichannel.channels.webhookUrl')} value={form.webhookUrlPreview ?? ''} onChange={(event) => setField('webhookUrlPreview', event.target.value)} />
              <Input label={t('omnichannel.channels.templateSyncStatus')} value={form.templateSyncStatus ?? ''} onChange={(event) => setField('templateSyncStatus', event.target.value)} />
            </>
          )}

          {channel.type === 'facebook_messenger' && (
            <>
              <Input label={t('omnichannel.channels.pageName')} value={form.pageName ?? ''} onChange={(event) => setField('pageName', event.target.value)} />
              <Input label={t('omnichannel.channels.pageId')} value={form.pageId ?? ''} onChange={(event) => setField('pageId', event.target.value)} />
            </>
          )}

          {(channel.type === 'instagram_dm' || channel.type === 'instagram_comment') && (
            <>
              <Input label={t('omnichannel.channels.accountHandle')} value={form.accountHandle ?? ''} onChange={(event) => setField('accountHandle', event.target.value)} />
              <Select label={t('omnichannel.channels.directMessages')} value={String(Boolean(form.monitorDirectMessages))} onChange={(event) => setField('monitorDirectMessages', event.target.value === 'true')}>
                <option value="true">{t('common.active')}</option>
                <option value="false">{t('common.inactive')}</option>
              </Select>
              <Select label={t('omnichannel.channels.comments')} value={String(Boolean(form.monitorComments))} onChange={(event) => setField('monitorComments', event.target.value === 'true')}>
                <option value="true">{t('common.active')}</option>
                <option value="false">{t('common.inactive')}</option>
              </Select>
              <Select label={t('omnichannel.channels.mentions')} value={String(Boolean(form.monitorMentions))} onChange={(event) => setField('monitorMentions', event.target.value === 'true')}>
                <option value="true">{t('common.active')}</option>
                <option value="false">{t('common.inactive')}</option>
              </Select>
            </>
          )}

          {channel.type === 'website_chat' && (
            <>
              <Input label={t('omnichannel.channels.widgetTitle')} value={form.widgetTitle ?? ''} onChange={(event) => setField('widgetTitle', event.target.value)} error={errors.widgetTitle} />
              <Input label={t('omnichannel.channels.brandColor')} value={form.brandColor ?? ''} onChange={(event) => setField('brandColor', event.target.value)} />
              <Input label={t('omnichannel.channels.greetingMessage')} value={form.greetingMessage ?? ''} onChange={(event) => setField('greetingMessage', event.target.value)} />
              <Input label={t('omnichannel.channels.offlineMessage')} value={form.offlineMessage ?? ''} onChange={(event) => setField('offlineMessage', event.target.value)} />
              <Input label={t('omnichannel.channels.embedCodePreview')} value={form.embedCodePreview ?? ''} onChange={(event) => setField('embedCodePreview', event.target.value)} />
            </>
          )}

          {channel.type === 'email' && (
            <>
              <Input label={t('omnichannel.channels.mailboxName')} value={form.mailboxName ?? ''} onChange={(event) => setField('mailboxName', event.target.value)} error={errors.mailboxName} />
              <Input label={t('omnichannel.channels.forwardingAddress')} value={form.forwardingAddress ?? ''} onChange={(event) => setField('forwardingAddress', event.target.value)} />
              <Input label={t('omnichannel.channels.senderIdentity')} value={form.senderIdentity ?? ''} onChange={(event) => setField('senderIdentity', event.target.value)} />
              <Input label={t('omnichannel.channels.signature')} value={form.signature ?? ''} onChange={(event) => setField('signature', event.target.value)} />
            </>
          )}

          {channel.type === 'sms' && (
            <>
              <Input label={t('omnichannel.channels.senderId')} value={form.senderId ?? ''} onChange={(event) => setField('senderId', event.target.value)} error={errors.senderId} />
              <Input label={t('omnichannel.channels.region')} value={form.region ?? ''} onChange={(event) => setField('region', event.target.value)} />
            </>
          )}

          {channel.type === 'phone' && (
            <>
              <Input label={t('omnichannel.channels.callSource')} value={form.callSource ?? ''} onChange={(event) => setField('callSource', event.target.value)} />
              <Input label={t('omnichannel.channels.missedCallRule')} value={form.missedCallRule ?? ''} onChange={(event) => setField('missedCallRule', event.target.value)} />
              <Input label={t('omnichannel.channels.callbackSla')} type="number" value={String(form.callbackSlaMinutes ?? 0)} onChange={(event) => setField('callbackSlaMinutes', Number(event.target.value))} />
            </>
          )}

          <Input label={t('omnichannel.channels.defaultSla')} value={form.defaultSlaPolicyId} onChange={(event) => setField('defaultSlaPolicyId', event.target.value)} />
          <Input label={t('omnichannel.channels.assignedTeam')} value={form.assignedTeamId} onChange={(event) => setField('assignedTeamId', event.target.value)} />
        </div>

        <div className="flex justify-end gap-3 border-t border-gray-200 pt-4 dark:border-gray-700">
          <Button type="button" variant="outline" onClick={onClose}>{t('common.cancel')}</Button>
          <Button type="submit" variant="outline" onClick={() => setForm(configuration)}>{t('omnichannel.actions.resetMock')}</Button>
          <Button type="submit" loading={isSaving}>{t('common.save')}</Button>
        </div>
      </form>
    </Modal>
  );
};
