import React from 'react';
import { AlertTriangle, Loader2, X } from 'lucide-react';
import { cn } from '../../utils/cn';
import { useLocale } from '../../localization/useLocale';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';

export const OmnichannelDrawer: React.FC<{
  isOpen: boolean;
  title: string;
  description?: string;
  onClose: () => void;
  children: React.ReactNode;
  footer?: React.ReactNode;
}> = ({ isOpen, title, description, onClose, children, footer }) => {
  const { direction, isRTL, t } = useLocale();

  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className={cn('absolute inset-y-0 flex max-w-full', isRTL ? 'left-0' : 'right-0')}>
        <aside
          className="flex h-full w-screen max-w-2xl flex-col border-l border-gray-200 bg-white shadow-xl dark:border-gray-800 dark:bg-gray-900"
          dir={direction}
        >
          <div className={cn('flex items-start justify-between gap-4 border-b border-gray-200 p-5 dark:border-gray-800', isRTL && 'flex-row-reverse')}>
            <div className="min-w-0">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">{title}</h2>
              {description ? <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">{description}</p> : null}
            </div>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg p-1 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-gray-800 dark:hover:text-gray-200"
              aria-label={t('common.close')}
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto p-5">{children}</div>
          {footer ? <div className="border-t border-gray-200 p-5 dark:border-gray-800">{footer}</div> : null}
        </aside>
      </div>
    </div>
  );
};

export const OmnichannelConfirmationModal: React.FC<{
  isOpen: boolean;
  title: string;
  description: string;
  confirmLabel: string;
  onConfirm: () => void;
  onClose: () => void;
  tone?: 'default' | 'danger';
}> = ({ isOpen, title, description, confirmLabel, onConfirm, onClose, tone = 'default' }) => {
  const { t } = useLocale();

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title} size="md">
      <div className="space-y-5">
        <div className="rounded-lg border border-gray-200 bg-gray-50 p-4 text-sm text-gray-600 dark:border-gray-800 dark:bg-gray-950/40 dark:text-gray-300">
          {description}
        </div>
        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button variant={tone === 'danger' ? 'danger' : 'primary'} onClick={onConfirm}>
            {confirmLabel}
          </Button>
        </div>
      </div>
    </Modal>
  );
};

export const OmnichannelStateNotice: React.FC<{
  tone?: 'info' | 'success' | 'warning' | 'error';
  title: string;
  description?: string;
  action?: React.ReactNode;
}> = ({ tone = 'info', title, description, action }) => {
  const toneClassName =
    tone === 'success'
      ? 'border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-900 dark:bg-emerald-950/30 dark:text-emerald-100'
      : tone === 'warning'
        ? 'border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-100'
        : tone === 'error'
          ? 'border-rose-200 bg-rose-50 text-rose-800 dark:border-rose-900 dark:bg-rose-950/30 dark:text-rose-100'
          : 'border-blue-200 bg-blue-50 text-blue-800 dark:border-blue-900 dark:bg-blue-950/30 dark:text-blue-100';

  return (
    <div className={cn('rounded-lg border p-4', toneClassName)}>
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="font-semibold">{title}</div>
          {description ? <div className="mt-1 text-sm">{description}</div> : null}
        </div>
        {action}
      </div>
    </div>
  );
};

export const OmnichannelEmptyStateCard: React.FC<{
  title: string;
  description: string;
  action?: React.ReactNode;
}> = ({ title, description, action }) => (
  <div className="rounded-lg border border-dashed border-gray-200 p-6 dark:border-gray-800">
    <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
      <div>
        <div className="font-semibold text-gray-900 dark:text-white">{title}</div>
        <div className="mt-1 text-sm text-gray-500 dark:text-gray-400">{description}</div>
      </div>
      {action}
    </div>
  </div>
);

export const OmnichannelLoadingBlock: React.FC<{ label: string }> = ({ label }) => (
  <div className="flex items-center gap-3 rounded-lg border border-gray-200 bg-gray-50 px-4 py-3 text-sm text-gray-600 dark:border-gray-800 dark:bg-gray-950/40 dark:text-gray-300">
    <Loader2 className="h-4 w-4 animate-spin" />
    <span>{label}</span>
  </div>
);

export const OmnichannelErrorBlock: React.FC<{
  title: string;
  description: string;
  action?: React.ReactNode;
}> = ({ title, description, action }) => (
  <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 dark:border-rose-900 dark:bg-rose-950/30">
    <div className="flex items-start gap-3">
      <AlertTriangle className="mt-0.5 h-5 w-5 text-rose-600 dark:text-rose-300" />
      <div className="min-w-0 flex-1">
        <div className="font-semibold text-rose-800 dark:text-rose-100">{title}</div>
        <div className="mt-1 text-sm text-rose-700 dark:text-rose-200">{description}</div>
        {action ? <div className="mt-3">{action}</div> : null}
      </div>
    </div>
  </div>
);
