import React, { useMemo, useState } from 'react';
import { Archive, Copy, Eye, Languages, PenSquare, Send, Plus } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { useOmnichannelMockStore } from './store/OmnichannelMockStore';
import { cn } from '../../utils/cn';
import { OmnichannelStateNotice } from './OmnichannelInteractions';
import { OmnichannelSectionCard } from './OmnichannelUi';
import { mockOmnichannelTemplates } from '../../services/omnichannelMockData';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { StatusBadge } from '../ui/StatusBadge';
import type { OmnichannelQuickReplyTemplate } from '../../types/omnichannel';
import { useToastContext } from '../../contexts/ToastContext';
import { getChannelLabel } from '../../utils/omnichannelLinks';

interface TemplateDraft {
  id?: string;
  title: string;
  body: string;
  language: 'en' | 'ar';
  category: OmnichannelQuickReplyTemplate['category'];
}

const emptyDraft: TemplateDraft = {
  title: '',
  body: '',
  language: 'en',
  category: 'general',
};

export const OmnichannelTemplatesPage: React.FC = () => {
  const { t, locale, direction } = useLocale();
  const isRTL = direction === 'rtl' || locale === 'ar';
  const toast = useToastContext();
  const {
    templates,
    addTemplate,
    updateTemplate,
    duplicateTemplate,
    archiveTemplate,
  } = useOmnichannelMockStore();
  const [languageFilter, setLanguageFilter] = useState('');
  const [channelFilter, setChannelFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [query, setQuery] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState<OmnichannelQuickReplyTemplate | null>(null);
  const [editorDraft, setEditorDraft] = useState<TemplateDraft>(emptyDraft);
  const [editorOpen, setEditorOpen] = useState(false);
  const [unsaved, setUnsaved] = useState(false);

  const filteredTemplates = useMemo(
    () =>
      templates.filter((template) => {
        const matchesLanguage = !languageFilter || template.language === languageFilter;
        const matchesChannel = !channelFilter || template.channelTypes.includes(channelFilter as typeof template.channelTypes[number]);
        const matchesStatus = !statusFilter || template.approvalStatus === statusFilter;
        const localizedTitle = locale === 'ar' ? template.title.ar : template.title.en;
        const matchesQuery = !query || localizedTitle.toLowerCase().includes(query.toLowerCase());
        return matchesLanguage && matchesChannel && matchesStatus && matchesQuery;
      }),
    [channelFilter, languageFilter, locale, query, statusFilter, templates]
  );

  const openEditor = (template?: OmnichannelQuickReplyTemplate) => {
    if (!template) {
      setEditorDraft(emptyDraft);
      setEditorOpen(true);
      setUnsaved(false);
      return;
    }

    setEditorDraft({
      id: template.id,
      title: locale === 'ar' ? template.title.ar : template.title.en,
      body: locale === 'ar' ? template.body.ar : template.body.en,
      language: template.language,
      category: template.category,
    });
    setEditorOpen(true);
    setUnsaved(false);
  };

  const saveTemplate = () => {
    if (!editorDraft.title.trim() || !editorDraft.body.trim()) {
      toast.warning(t('omnichannel.templates.validationTitle'), t('omnichannel.templates.validationDescription'));
      return;
    }

    const nextTemplate = {
      category: editorDraft.category,
      channelTypes: ['whatsapp' as const, 'website_chat' as const],
      title: { en: editorDraft.title, ar: editorDraft.title },
      body: { en: editorDraft.body, ar: editorDraft.body },
      language: editorDraft.language as any,
      approvalStatus: 'draft' as const,
      variables: [],
    };

    if (editorDraft.id) {
      updateTemplate(editorDraft.id, nextTemplate);
    } else {
      addTemplate(nextTemplate);
    }
    setEditorOpen(false);
    setEditorDraft(emptyDraft);
    setUnsaved(false);
    toast.success(t('omnichannel.templates.savedTitle'), t('omnichannel.templates.savedDescription'));
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
          <div>
            <h1 className="text-2xl font-bold">{t('omnichannel.templates.title')}</h1>
            <p className="mt-2 text-blue-100 opacity-90">{t('omnichannel.templates.subtitle')}</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => openEditor()} className="bg-white/10 text-white hover:bg-white/20 border-transparent">
              <Plus className="h-4 w-4" />
              {t('omnichannel.actions.createTemplate')}
            </Button>
          </div>
        </div>
      <div className="grid gap-4 xl:grid-cols-[1.25fr_1fr]">
        <OmnichannelSectionCard
          title={t('omnichannel.templates.libraryTitle')}
          action={
            <div className="grid gap-2 md:grid-cols-4">
              <input value={query} onChange={(event) => setQuery(event.target.value)} className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900" placeholder={t('omnichannel.inbox.searchPlaceholder')} />
              <select value={languageFilter} onChange={(event) => setLanguageFilter(event.target.value)} className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
                <option value="">{t('common.all')}</option>
                <option value="en">{t('common.english')}</option>
                <option value="ar">{t('common.arabic')}</option>
              </select>
              <select value={channelFilter} onChange={(event) => setChannelFilter(event.target.value)} className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
                <option value="">{t('common.all')}</option>
                <option value="whatsapp">{getChannelLabel('whatsapp')}</option>
                <option value="website_chat">{getChannelLabel('website_chat')}</option>
                <option value="email">{getChannelLabel('email')}</option>
              </select>
              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)} className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
                <option value="">{t('common.all')}</option>
                <option value="draft">{t('omnichannel.templates.status.draft')}</option>
                <option value="pending_review">{t('omnichannel.templates.status.pending_review')}</option>
                <option value="approved">{t('omnichannel.templates.status.approved')}</option>
                <option value="rejected">{t('omnichannel.templates.status.rejected')}</option>
              </select>
            </div>
          }
        >
          <div className="space-y-3">
            {filteredTemplates.map((template) => (
              <div key={template.id} className="rounded-lg border border-gray-100 p-4 dark:border-gray-800">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-semibold text-gray-900 dark:text-white">{locale === 'ar' ? template.title.ar : template.title.en}</div>
                    <div className="mt-1 text-sm text-gray-500 line-clamp-2">{locale === 'ar' ? template.body.ar : template.body.en}</div>
                  </div>
                  <StatusBadge variant={template.approvalStatus === 'approved' ? 'emerald' : template.approvalStatus === 'pending_review' ? 'amber' : template.approvalStatus === 'rejected' ? 'rose' : 'gray'}>
                    {t(`omnichannel.templates.status.${template.approvalStatus}` as never)}
                  </StatusBadge>
                </div>
                <div className="mt-3 flex flex-wrap gap-2 text-xs text-gray-500">
                  <span>{t(`omnichannel.templates.category.${template.category}` as never)}</span>
                  <span className="bidi-isolate">{template.language.toUpperCase()}</span>
                  <span>{`${template.usageCount} ${t('omnichannel.templates.usageCount')}`}</span>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" onClick={() => setSelectedTemplate(template)}>
                    <Eye className="h-4 w-4" />
                    {t('omnichannel.actions.previewMock')}
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => openEditor(template)}>
                    <PenSquare className="h-4 w-4" />
                    {t('common.edit')}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => {
                    duplicateTemplate(template.id);
                    toast.success(t('omnichannel.templates.duplicatedTitle'), t('omnichannel.templates.duplicatedDescription'));
                  }}>
                    <Copy className="h-4 w-4" />
                    {t('omnichannel.actions.duplicateTemplate')}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => {
                    updateTemplate(template.id, { approvalStatus: 'pending_review' });
                    toast.success(t('omnichannel.templates.savedTitle'), t('omnichannel.templates.savedDescription'));
                  }}>
                    <Send className="h-4 w-4" />
                    {t('omnichannel.actions.submitForApproval')}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => {
                    archiveTemplate(template.id, true);
                    toast.success(t('omnichannel.templates.savedTitle'), t('omnichannel.templates.savedDescription'));
                  }}>
                    <Archive className="h-4 w-4" />
                    {t('omnichannel.actions.archiveTemplate')}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </OmnichannelSectionCard>

        <OmnichannelSectionCard title={t('omnichannel.templates.previewTitle')}>
          {selectedTemplate ? (
            <div className="space-y-4">
              <div className="rounded-lg border border-gray-100 p-4 dark:border-gray-800">
                <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-gray-900 dark:text-white">
                  <Languages className="h-4 w-4 text-blue-600" />
                  {locale === 'ar' ? selectedTemplate.title.ar : selectedTemplate.title.en}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-300">{locale === 'ar' ? selectedTemplate.body.ar : selectedTemplate.body.en}</div>
              </div>
              <Input
                label={t('omnichannel.templates.insertVariable')}
                value="{{customer_name}}"
                readOnly
                onChange={() => undefined}
              />
              <Button variant="outline" onClick={() => toast.info(t('omnichannel.templates.variableInserted'), '{{customer_name}}')}>
                {t('omnichannel.actions.insertVariable')}
              </Button>
              {selectedTemplate.approvalStatus === 'rejected' ? (
                <OmnichannelStateNotice
                  tone="error"
                  title={t('omnichannel.templates.rejectReasonTitle')}
                  description={t('omnichannel.templates.rejectReasonDescription')}
                />
              ) : null}
            </div>
          ) : (
            <div className="rounded-lg border border-dashed border-gray-200 p-5 text-sm text-gray-500 dark:border-gray-800">
              {t('omnichannel.templates.selectTemplateHint')}
            </div>
          )}
        </OmnichannelSectionCard>
      </div>

      <Modal isOpen={editorOpen} onClose={() => setEditorOpen(false)} title={t('omnichannel.templates.editorTitle')} size="lg">
        <div className="space-y-4">
          {unsaved ? (
            <OmnichannelStateNotice tone="warning" title={t('omnichannel.templates.unsavedTitle')} description={t('omnichannel.templates.unsavedDescription')} />
          ) : null}
          <Input label={t('common.title')} value={editorDraft.title} onChange={(event) => {
            setEditorDraft((current) => ({ ...current, title: event.target.value }));
            setUnsaved(true);
          }} />
          <label className="block">
            <div className="mb-1 text-xs font-semibold text-gray-500">{t('omnichannel.templates.bodyLabel')}</div>
            <textarea value={editorDraft.body} onChange={(event) => {
              setEditorDraft((current) => ({ ...current, body: event.target.value }));
              setUnsaved(true);
            }} rows={5} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900" />
          </label>
          <div className="grid gap-4 md:grid-cols-2">
            <select value={editorDraft.language} onChange={(event) => {
              setEditorDraft((current) => ({ ...current, language: event.target.value as 'en' | 'ar' }));
              setUnsaved(true);
            }} className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
              <option value="en">{t('common.english')}</option>
              <option value="ar">{t('common.arabic')}</option>
            </select>
            <select value={editorDraft.category} onChange={(event) => {
              setEditorDraft((current) => ({ ...current, category: event.target.value as TemplateDraft['category'] }));
              setUnsaved(true);
            }} className="rounded-lg border border-gray-200 px-3 py-2 text-sm dark:border-gray-800 dark:bg-gray-900">
              <option value="general">{t('omnichannel.templates.category.general')}</option>
              <option value="sales">{t('omnichannel.templates.category.sales')}</option>
              <option value="support">{t('omnichannel.templates.category.support')}</option>
              <option value="reservation">{t('omnichannel.templates.category.reservation')}</option>
              <option value="payment">{t('omnichannel.templates.category.payment')}</option>
            </select>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setEditorOpen(false)}>{t('common.cancel')}</Button>
            <Button onClick={saveTemplate}>{t('common.save')}</Button>
          </div>
        </div>
      </Modal>
      </div>
    </div>
  );
};
