import React from 'react';
import { StatCard } from '../ui/StatCard';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { cn } from '../../utils/cn';
import type { LucideIcon } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';

export interface OmnichannelStatItem {
  id: string;
  label: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  trendType?: 'up' | 'down' | 'neutral';
  iconColor?: string;
  iconBg?: string;
  onClick?: () => void;
}

export const OmnichannelStatsGrid: React.FC<{ items: OmnichannelStatItem[] }> = ({ items }) => (
  <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
    {items.map((item) => (
      <StatCard
        key={item.id}
        label={item.label}
        value={item.value}
        icon={item.icon}
        trend={item.trend}
        trendType={item.trendType}
        iconColor={item.iconColor}
        iconBg={item.iconBg}
        onClick={item.onClick}
      />
    ))}
  </div>
);

export const OmnichannelSectionCard: React.FC<{
  title: string;
  description?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}> = ({ title, description, action, children, className }) => (
  <Card className={cn('rounded-3xl border-0 bg-white shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] transition-all duration-300 hover:shadow-[0_8px_32px_-8px_rgba(37,99,235,0.1)] dark:bg-gray-900', className)}>
    <CardHeader className="flex flex-col gap-3 pb-4 md:flex-row md:items-center md:justify-between">
      <div className="min-w-0">
        <CardTitle className="text-lg font-bold tracking-tight text-slate-800 dark:text-white">{title}</CardTitle>
        {description ? <p className="mt-1 text-sm font-medium text-slate-500 dark:text-gray-400">{description}</p> : null}
      </div>
      {action}
    </CardHeader>
    <CardContent>{children}</CardContent>
  </Card>
);

export const OmnichannelEmptyState: React.FC<{ label: string }> = ({ label }) => (
  <div className="rounded-2xl border border-dashed border-slate-200 p-6 text-sm text-slate-500 dark:border-gray-800 dark:text-gray-400">
    {label}
  </div>
);

export const OmnichannelMiniBarList: React.FC<{
  items: Array<{ id: string; label: string; value: number; hint?: string }>;
}> = ({ items }) => {
  const max = Math.max(...items.map((item) => item.value), 1);
  const { direction } = useLocale();

  return (
    <div className="space-y-4" dir={direction}>
      {items.map((item) => (
        <div key={item.id}>
          <div className="mb-2 flex items-center justify-between gap-3">
            <div className="truncate text-sm font-bold text-slate-800 dark:text-gray-200">{item.label}</div>
            <div className="text-xs font-semibold text-slate-500 bidi-isolate">{item.hint ?? item.value}</div>
          </div>
          <div className="h-2.5 rounded-full bg-slate-100 dark:bg-gray-800">
            <div
              className="h-2.5 rounded-full bg-gradient-to-r from-blue-500 to-[#2563EB] shadow-sm transition-all duration-700 ease-out"
              style={{ width: `${Math.max((item.value / max) * 100, 8)}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
};
