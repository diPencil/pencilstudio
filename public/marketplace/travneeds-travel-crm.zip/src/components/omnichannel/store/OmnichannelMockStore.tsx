import React, { createContext, useContext, useState, useMemo, ReactNode } from 'react';
import type {
  OmnichannelActivityCategory,
  OmnichannelActivityLogEntry,
  OmnichannelAutomationActivity,
  OmnichannelAutomationRule,
  OmnichannelBroadcastCampaign,
  OmnichannelCaseRecordMock,
  OmnichannelChannel,
  OmnichannelChannelConfiguration,
  OmnichannelConversation,
  OmnichannelConversionActivityEvent,
  OmnichannelCustomerRecordMock,
  OmnichannelInternalNote,
  OmnichannelLabelDefinition,
  OmnichannelLeadRecordMock,
  OmnichannelMessage,
  OmnichannelQuickReplyTemplate,
  OmnichannelRoutingRule,
  OmnichannelSlaPolicy,
  OmnichannelTeamMemberWorkload,
  OmnichannelTicketRecordMock,
  OmnichannelSettingsSnapshot,
  OmnichannelPriority,
  OmnichannelConversationStatus,
  OmnichannelChannelType,
} from '../../../types/omnichannel';
import {
  mockOmnichannelConversations,
  mockOmnichannelMessages,
  mockOmnichannelInternalNotes,
  mockOmnichannelLeadRecords,
  mockOmnichannelCustomerRecords,
  mockOmnichannelTicketRecords,
  mockOmnichannelCaseRecords,
  mockOmnichannelConversionActivities,
  mockOmnichannelChannels,
  mockOmnichannelChannelConfigurations,
  mockOmnichannelRoutingRules,
  mockOmnichannelAutomationRules,
  mockOmnichannelAutomationActivities,
  mockOmnichannelLabels,
  mockOmnichannelSlaPolicies,
  mockOmnichannelTeamWorkload,
  mockOmnichannelBroadcasts,
  mockOmnichannelSettings,
  mockOmnichannelActivityLogs,
  mockOmnichannelQueues,
  mockOmnichannelTemplates,
  mockOmnichannelAssignableStaff,
} from '../../../services/omnichannelMockData';
import {
  deriveQueueOverview,
  deriveSlaRisks,
  deriveChannelVolume,
  deriveAgentSnapshots,
  deriveConversionSummary,
  deriveTagUsage,
  type OmnichannelDerivedQueueOverview,
  type OmnichannelDerivedSlaRisk,
  type OmnichannelDerivedChannelVolume,
  type OmnichannelDerivedAgentSnapshot,
  type OmnichannelConversionSummary,
} from '../../../utils/omnichannelIntegration';
import { calculateOmnichannelMetrics } from '../../../utils/omnichannelMetrics';

export interface OmnichannelMockStoreState {
  conversations: OmnichannelConversation[];
  messages: OmnichannelMessage[];
  internalNotes: OmnichannelInternalNote[];
  leadRecords: OmnichannelLeadRecordMock[];
  customerRecords: OmnichannelCustomerRecordMock[];
  ticketRecords: OmnichannelTicketRecordMock[];
  caseRecords: OmnichannelCaseRecordMock[];
  activityEvents: OmnichannelConversionActivityEvent[];
  channels: OmnichannelChannel[];
  channelConfigurations: OmnichannelChannelConfiguration[];
  channelEvents: Record<string, string[]>;
  routingRules: OmnichannelRoutingRule[];
  automationRules: OmnichannelAutomationRule[];
  automationActivities: OmnichannelAutomationActivity[];
  templates: OmnichannelQuickReplyTemplate[];
  labels: OmnichannelLabelDefinition[];
  slaPolicies: OmnichannelSlaPolicy[];
  teamMembers: OmnichannelTeamMemberWorkload[];
  broadcasts: OmnichannelBroadcastCampaign[];
  settings: OmnichannelSettingsSnapshot;
  activityLogs: OmnichannelActivityLogEntry[];
}

export interface OmnichannelMockStoreActions {
  // Inbox Actions
  updateConversationStatus: (id: string, status: OmnichannelConversationStatus) => void;
  updateConversationPriority: (id: string, priority: OmnichannelPriority) => void;
  assignConversation: (id: string, staffId: string | null) => void;
  transferConversation: (id: string, queueId: string) => void;
  addConversationTag: (id: string, tagId: string) => void;
  removeConversationTag: (id: string, tagId: string) => void;
  markConversationRead: (id: string, read: boolean) => void;
  sendMessage: (conversationId: string, body: string, kind?: OmnichannelMessage['kind'], attachments?: OmnichannelMessage['attachments']) => void;
  updateMessageDelivery: (messageId: string, deliveryStatus: OmnichannelMessage['deliveryStatus'], failureReason?: string) => void;
  addInternalNote: (conversationId: string, body: string, authorId: string, authorName: string) => void;
  deleteInternalNote: (noteId: string) => void;
  updateInternalNote: (noteId: string, body: string) => void;
  archiveInternalNote: (noteId: string, archived: boolean) => void;
  
  // Conversions
  convertConversation: (conversationId: string, mode: 'convert_lead' | 'convert_customer' | 'create_ticket' | 'create_case' | 'link_existing', payload: {
    name?: string;
    phone?: string;
    email?: string;
    companyName?: string;
    subject?: string;
    priority?: OmnichannelPriority;
    category?: string;
    teamName?: string;
    caseType?: string;
    existingRecordId?: string;
    existingRecordType?: string;
    existingRecordLabel?: string;
    notes?: string;
  }) => void;
  unlinkRecord: (conversationId: string, recordType: string, recordId: string) => void;
  restoreLinkedRecord: (conversationId: string, recordType: string, recordId: string) => void;

  // Channels Actions
  pauseChannel: (channelId: string) => void;
  resumeChannel: (channelId: string) => void;
  syncChannel: (channelId: string) => void;
  reconnectChannel: (channelId: string) => void;
  testChannelConnection: (channelId: string) => void;
  saveChannelConfiguration: (channelId: string, config: Partial<OmnichannelChannelConfiguration>) => void;
  addChannelLogEvent: (channelId: string, eventText: string) => void;

  // Routing Rules Actions
  addRoutingRule: (rule: Omit<OmnichannelRoutingRule, 'id'>) => void;
  updateRoutingRule: (id: string, rule: Partial<OmnichannelRoutingRule>) => void;
  deleteRoutingRule: (id: string) => void;
  duplicateRoutingRule: (id: string) => void;
  enableRoutingRule: (id: string, enabled: boolean) => void;
  reorderRoutingRules: (rules: OmnichannelRoutingRule[]) => void;

  // Automation Rules Actions
  addAutomationRule: (rule: Omit<OmnichannelAutomationRule, 'id'>) => void;
  updateAutomationRule: (id: string, rule: Partial<OmnichannelAutomationRule>) => void;
  deleteAutomationRule: (id: string) => void;
  duplicateAutomationRule: (id: string) => void;
  enableAutomationRule: (id: string, enabled: boolean) => void;
  runAutomationNow: (id: string, conversationId?: string) => { success: boolean; message: string };

  // Templates Actions
  addTemplate: (template: Omit<OmnichannelQuickReplyTemplate, 'id'>) => void;
  updateTemplate: (id: string, template: Partial<OmnichannelQuickReplyTemplate>) => void;
  deleteTemplate: (id: string) => void;
  duplicateTemplate: (id: string) => void;
  archiveTemplate: (id: string, archived: boolean) => void;

  // Tags Actions
  addLabel: (label: Omit<OmnichannelLabelDefinition, 'id' | 'usageCount'>) => void;
  updateLabel: (id: string, label: Partial<OmnichannelLabelDefinition>) => void;
  deleteLabel: (id: string) => boolean; // returns false if tag in use
  duplicateLabel: (id: string) => void;

  // SLA Actions
  addSlaPolicy: (policy: Omit<OmnichannelSlaPolicy, 'id'>) => void;
  updateSlaPolicy: (id: string, policy: Partial<OmnichannelSlaPolicy>) => void;
  deleteSlaPolicy: (id: string) => void;
  enableSlaPolicy: (id: string, enabled: boolean) => void;

  // Team Actions
  updateTeamMemberStatus: (id: string, onlineStatus: 'online' | 'busy' | 'offline') => void;
  rebalanceTeamWorkload: (teamName: string) => void;

  // Broadcasts Actions
  addBroadcast: (broadcast: Omit<OmnichannelBroadcastCampaign, 'id' | 'deliveryStatus'>) => void;
  updateBroadcast: (id: string, broadcast: Partial<OmnichannelBroadcastCampaign>) => void;
  cancelBroadcast: (id: string) => void;
  duplicateBroadcast: (id: string) => void;

  // Settings Actions
  saveSettings: (settings: Partial<OmnichannelSettingsSnapshot>) => void;
  resetSettings: () => void;
  resetAllMockStore: () => void;
  addActivityLogEntry: (actorName: string, category: OmnichannelActivityCategory, channelType: OmnichannelChannelType, summary: string, conversationId?: string) => void;
}

export interface OmnichannelMockStoreSelectors {
  metrics: ReturnType<typeof calculateOmnichannelMetrics>;
  queueOverview: OmnichannelDerivedQueueOverview[];
  slaRisks: OmnichannelDerivedSlaRisk[];
  channelVolume: OmnichannelDerivedChannelVolume[];
  agentSnapshots: OmnichannelDerivedAgentSnapshot[];
  conversionSummary: OmnichannelConversionSummary;
  tagUsage: Array<OmnichannelLabelDefinition & { conversationCount: number }>;
}

export type OmnichannelMockStoreContextType = OmnichannelMockStoreState & OmnichannelMockStoreActions & OmnichannelMockStoreSelectors;

const OmnichannelMockStoreContext = createContext<OmnichannelMockStoreContextType | null>(null);

export const useOmnichannelMockStore = (): OmnichannelMockStoreContextType => {
  const context = useContext(OmnichannelMockStoreContext);
  if (!context) {
    throw new Error('useOmnichannelMockStore must be used within an OmnichannelMockStoreProvider');
  }
  return context;
};

interface ProviderProps {
  children: ReactNode;
}

export const OmnichannelMockStoreProvider: React.FC<ProviderProps> = ({ children }) => {
  // 1. Setup states
  const [conversations, setConversations] = useState<OmnichannelConversation[]>(mockOmnichannelConversations);
  const [messages, setMessages] = useState<OmnichannelMessage[]>(mockOmnichannelMessages);
  const [internalNotes, setInternalNotes] = useState<OmnichannelInternalNote[]>(mockOmnichannelInternalNotes);
  const [leadRecords, setLeadRecords] = useState<OmnichannelLeadRecordMock[]>(mockOmnichannelLeadRecords);
  const [customerRecords, setCustomerRecords] = useState<OmnichannelCustomerRecordMock[]>(mockOmnichannelCustomerRecords);
  const [ticketRecords, setTicketRecords] = useState<OmnichannelTicketRecordMock[]>(mockOmnichannelTicketRecords);
  const [caseRecords, setCaseRecords] = useState<OmnichannelCaseRecordMock[]>(mockOmnichannelCaseRecords);
  const [activityEvents, setActivityEvents] = useState<OmnichannelConversionActivityEvent[]>(mockOmnichannelConversionActivities);
  
  const [channels, setChannels] = useState<OmnichannelChannel[]>(mockOmnichannelChannels);
  const [channelConfigurations, setChannelConfigurations] = useState<OmnichannelChannelConfiguration[]>(mockOmnichannelChannelConfigurations);
  const [channelEvents, setChannelEvents] = useState<Record<string, string[]>>({});
  
  const [routingRules, setRoutingRules] = useState<OmnichannelRoutingRule[]>(mockOmnichannelRoutingRules);
  const [automationRules, setAutomationRules] = useState<OmnichannelAutomationRule[]>(mockOmnichannelAutomationRules);
  const [automationActivities, setAutomationActivities] = useState<OmnichannelAutomationActivity[]>(mockOmnichannelAutomationActivities);
  
  const [templates, setTemplates] = useState<OmnichannelQuickReplyTemplate[]>(mockOmnichannelTemplates);
  const [labels, setLabels] = useState<OmnichannelLabelDefinition[]>(mockOmnichannelLabels);
  const [slaPolicies, setSlaPolicies] = useState<OmnichannelSlaPolicy[]>(mockOmnichannelSlaPolicies);
  const [teamMembers, setTeamMembers] = useState<OmnichannelTeamMemberWorkload[]>(mockOmnichannelTeamWorkload);
  const [broadcasts, setBroadcasts] = useState<OmnichannelBroadcastCampaign[]>(mockOmnichannelBroadcasts);
  const [settings, setSettings] = useState<OmnichannelSettingsSnapshot>(mockOmnichannelSettings);
  const [activityLogs, setActivityLogs] = useState<OmnichannelActivityLogEntry[]>(mockOmnichannelActivityLogs);

  // Helper: append audit log
  const addAuditLog = (
    actorName: string,
    category: OmnichannelActivityCategory,
    channelType: OmnichannelChannelType,
    summary: string,
    conversationId?: string
  ) => {
    const newEntry: OmnichannelActivityLogEntry = {
      id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      actorName,
      category,
      channelType,
      conversationId,
      summary,
      createdAt: new Date().toISOString(),
    };
    setActivityLogs((prev) => [newEntry, ...prev]);
  };

  // 2. Setup actions
  const actions = useMemo<OmnichannelMockStoreActions>(() => {
    const triggerAuditLog = (
      actorName: string,
      category: OmnichannelActivityCategory,
      channelType: OmnichannelChannelType,
      summary: string,
      conversationId?: string
    ) => {
      addAuditLog(actorName, category, channelType, summary, conversationId);
    };

    return {
      updateConversationStatus: (id, status) => {
        setConversations((prev) =>
          prev.map((c) => {
            if (c.id === id) {
              triggerAuditLog(
                'Super Admin',
                'conversation_action',
                c.channelType,
                `Conversation status changed to ${status}.`,
                id
              );
              return { ...c, status, updatedAt: new Date().toISOString() };
            }
            return c;
          })
        );
      },
      updateConversationPriority: (id, priority) => {
        setConversations((prev) =>
          prev.map((c) => {
            if (c.id === id) {
              triggerAuditLog(
                'Super Admin',
                'conversation_action',
                c.channelType,
                `Conversation priority changed to ${priority}.`,
                id
              );
              return { ...c, priority, updatedAt: new Date().toISOString() };
            }
            return c;
          })
        );
      },
      assignConversation: (id, staffId) => {
        const staff = mockOmnichannelAssignableStaff.find((s) => s.id === staffId);
        const staffName = staff ? staff.name : undefined;
        setConversations((prev) =>
          prev.map((c) => {
            if (c.id === id) {
              triggerAuditLog(
                'Super Admin',
                'assignment_action',
                c.channelType,
                staffName ? `Conversation assigned to ${staffName}.` : 'Conversation unassigned.',
                id
              );
              return {
                ...c,
                assignedStaffId: staffId || undefined,
                assignedStaffName: staffName,
                status: staffId ? 'waiting_customer' : 'open',
                updatedAt: new Date().toISOString(),
              };
            }
            return c;
          })
        );
      },
      transferConversation: (id, queueId) => {
        const queue = mockOmnichannelQueues.find((q) => q.id === queueId);
        const queueName = queue ? queue.name.en : queueId;
        setConversations((prev) =>
          prev.map((c) => {
            if (c.id === id) {
              triggerAuditLog(
                'Super Admin',
                'assignment_action',
                c.channelType,
                `Conversation transferred to queue: ${queueName}.`,
                id
              );
              return {
                ...c,
                queueId,
                assignedStaffId: undefined,
                assignedStaffName: undefined,
                updatedAt: new Date().toISOString(),
              };
            }
            return c;
          })
        );
      },
      addConversationTag: (id, tagId) => {
        setConversations((prev) =>
          prev.map((c) => {
            if (c.id === id && !c.tagIds.includes(tagId)) {
              const tag = mockOmnichannelLabels.find((l) => l.id === tagId);
              const tagName = tag ? tag.name.en : tagId;
              triggerAuditLog(
                'Super Admin',
                'conversation_action',
                c.channelType,
                `Tag "${tagName}" added to conversation.`,
                id
              );
              return { ...c, tagIds: [...c.tagIds, tagId], updatedAt: new Date().toISOString() };
            }
            return c;
          })
        );
      },
      removeConversationTag: (id, tagId) => {
        setConversations((prev) =>
          prev.map((c) => {
            if (c.id === id && c.tagIds.includes(tagId)) {
              const tag = mockOmnichannelLabels.find((l) => l.id === tagId);
              const tagName = tag ? tag.name.en : tagId;
              triggerAuditLog(
                'Super Admin',
                'conversation_action',
                c.channelType,
                `Tag "${tagName}" removed from conversation.`,
                id
              );
              return {
                ...c,
                tagIds: c.tagIds.filter((t) => t !== tagId),
                updatedAt: new Date().toISOString(),
              };
            }
            return c;
          })
        );
      },
      markConversationRead: (id, read) => {
        setConversations((prev) =>
          prev.map((c) => {
            if (c.id === id) {
              return {
                ...c,
                unreadCount: read ? 0 : 1,
                updatedAt: new Date().toISOString(),
              };
            }
            return c;
          })
        );
      },
      sendMessage: (conversationId, body, kind = 'text', attachments = []) => {
        const conv = conversations.find((c) => c.id === conversationId);
        const channelType = conv ? conv.channelType : 'whatsapp';
        const newMsg: OmnichannelMessage = {
          id: `MSG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          conversationId,
          direction: 'outbound',
          kind,
          authorName: 'Super Admin',
          body,
          createdAt: new Date().toISOString(),
          status: 'sending',
          attachments,
        };

        setMessages((prev) => [...prev, newMsg]);

        // Auto transition the message state
        setTimeout(() => {
          setMessages((prev) =>
            prev.map((m) => (m.id === newMsg.id ? { ...m, status: 'sent' } : m))
          );
        }, 600);

        setTimeout(() => {
          setMessages((prev) =>
            prev.map((m) => (m.id === newMsg.id ? { ...m, status: 'delivered' } : m))
          );
        }, 1200);

        setTimeout(() => {
          setMessages((prev) =>
            prev.map((m) => (m.id === newMsg.id ? { ...m, status: 'read' } : m))
          );
        }, 2000);

        // Update last message in conversation
        setConversations((prev) =>
          prev.map((c) => {
            if (c.id === conversationId) {
              return {
                ...c,
                lastMessage: {
                  body,
                  createdAt: new Date().toISOString(),
                  senderName: 'Super Admin',
                },
                updatedAt: new Date().toISOString(),
              };
            }
            return c;
          })
        );

        triggerAuditLog(
          'Super Admin',
          'conversation_action',
          channelType,
          `Outbound message sent: "${body.substring(0, 30)}${body.length > 30 ? '...' : ''}"`,
          conversationId
        );
      },
      updateMessageDelivery: (messageId, deliveryStatus, failureReason) => {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === messageId ? { ...m, deliveryStatus, failureReason } : m
          )
        );
      },
      addInternalNote: (conversationId, body, authorId, authorName) => {
        const conv = conversations.find((c) => c.id === conversationId);
        const channelType = conv ? conv.channelType : 'whatsapp';
        const newNote: OmnichannelInternalNote = {
          id: `NOTE-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          conversationId,
          authorId,
          authorName,
          body,
          createdAt: new Date().toISOString(),
          visibility: 'internal',
        };

        setInternalNotes((prev) => [...prev, newNote]);
        triggerAuditLog(
          authorName,
          'conversation_action',
          channelType,
          `Internal note added: "${body.substring(0, 30)}..."`,
          conversationId
        );
      },
      deleteInternalNote: (noteId) => {
        setInternalNotes((prev) => prev.filter((n) => n.id !== noteId));
      },
      updateInternalNote: (noteId, body) => {
        setInternalNotes((prev) =>
          prev.map((n) => (n.id === noteId ? { ...n, body, updatedAt: new Date().toISOString() } : n))
        );
      },
      archiveInternalNote: (noteId, archived) => {
        setInternalNotes((prev) =>
          prev.map((n) => (n.id === noteId ? { ...n, archived, updatedAt: new Date().toISOString() } : n))
        );
      },
      
      // Conversions
      convertConversation: (conversationId, mode, payload) => {
        const conv = conversations.find((c) => c.id === conversationId);
        const channelType = conv ? conv.channelType : 'whatsapp';
        const newEventId = `ACT-${Date.now()}`;
        
        let recordId = payload.existingRecordId || '';
        let recordLabel = payload.existingRecordLabel || '';
        let recordType = payload.existingRecordType || '';
        
        if (mode === 'convert_lead') {
          recordId = `LD-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;
          recordLabel = payload.name || 'New Lead';
          recordType = 'lead';
          const newLead: OmnichannelLeadRecordMock = {
            id: recordId,
            name: payload.name || 'New Lead',
            phone: payload.phone,
            email: payload.email,
            companyName: payload.companyName,
            source: 'Omnichannel Inbox',
            stage: 'New',
            ownerId: 'USR-002',
            ownerName: 'Mahmoud Khalil',
            createdAt: new Date().toISOString(),
          };
          setLeadRecords((prev) => [newLead, ...prev]);
        } else if (mode === 'convert_customer') {
          recordId = `CUST-${Math.floor(100 + Math.random() * 900)}`;
          recordLabel = payload.name || 'New Customer';
          recordType = 'customer';
          const newCust: OmnichannelCustomerRecordMock = {
            id: recordId,
            name: payload.name || 'New Customer',
            phone: payload.phone,
            email: payload.email,
            companyName: payload.companyName,
            tier: 'Silver',
            ownerId: 'USR-002',
            ownerName: 'Mahmoud Khalil',
            createdAt: new Date().toISOString(),
          };
          setCustomerRecords((prev) => [newCust, ...prev]);
        } else if (mode === 'create_ticket') {
          recordId = `TKT-${Math.floor(100 + Math.random() * 900)}`;
          recordLabel = payload.subject || 'Support Ticket';
          recordType = 'support_ticket';
          const newTkt: OmnichannelTicketRecordMock = {
            id: recordId,
            subject: payload.subject || 'Support Ticket',
            customerName: conv ? conv.customer.name : 'Unknown',
            priority: payload.priority || 'normal',
            category: payload.category || 'Support',
            status: 'Open',
            ownerId: 'USR-001',
            ownerName: 'Super Admin',
            teamName: payload.teamName || 'Support',
            createdAt: new Date().toISOString(),
          };
          setTicketRecords((prev) => [newTkt, ...prev]);
        } else if (mode === 'create_case') {
          recordId = `CASE-2026-${Math.floor(100 + Math.random() * 900)}`;
          recordLabel = payload.subject || 'Sales Case';
          recordType = 'sales_case';
          const newCase: OmnichannelCaseRecordMock = {
            id: recordId,
            subject: payload.subject || 'Sales Case',
            customerName: conv ? conv.customer.name : 'Unknown',
            caseType: payload.caseType || 'Leisure Package',
            status: 'New',
            ownerId: 'USR-002',
            ownerName: 'Mahmoud Khalil',
            teamName: 'Sales',
            createdAt: new Date().toISOString(),
          };
          setCaseRecords((prev) => [newCase, ...prev]);
        }

        const newEvent: OmnichannelConversionActivityEvent = {
          id: newEventId,
          conversationId,
          type: mode === 'link_existing' ? 'record_linked' : 
                mode === 'convert_lead' ? 'converted_to_lead' :
                mode === 'convert_customer' ? 'converted_to_customer' :
                mode === 'create_ticket' ? 'ticket_created' : 'case_created',
          recordType: recordType as any,
          recordId,
          recordLabel,
          actorName: 'Super Admin',
          createdAt: new Date().toISOString(),
          note: payload.notes || '',
        };

        setActivityEvents((prev) => [newEvent, ...prev]);

        // Link record to conversation
        setConversations((prev) =>
          prev.map((c) => {
            if (c.id === conversationId) {
              const alreadyLinked = c.linkedRecords.some((r) => r.type === recordType && r.id === recordId);
              if (alreadyLinked) return c;
              return {
                ...c,
                linkedRecords: [
                  ...c.linkedRecords,
                  {
                    type: recordType as any,
                    id: recordId,
                    label: recordLabel,
                    origin: mode === 'link_existing' ? 'linked' : 'converted',
                    createdAt: new Date().toISOString(),
                    ownerName: 'Super Admin',
                    status: 'Active',
                  },
                ],
              };
            }
            return c;
          })
        );

        triggerAuditLog(
          'Super Admin',
          'audit_event',
          channelType,
          `Linked conversation to ${recordType}: ${recordLabel} (${recordId})`,
          conversationId
        );
      },
      unlinkRecord: (conversationId, recordType, recordId) => {
        const conv = conversations.find((c) => c.id === conversationId);
        const channelType = conv ? conv.channelType : 'whatsapp';
        setConversations((prev) =>
          prev.map((c) => {
            if (c.id === conversationId) {
              return {
                ...c,
                linkedRecords: c.linkedRecords.filter((r) => !(r.type === recordType && r.id === recordId)),
              };
            }
            return c;
          })
        );

        const newEvent: OmnichannelConversionActivityEvent = {
          id: `ACT-${Date.now()}`,
          conversationId,
          type: 'record_unlinked',
          recordType: recordType as any,
          recordId,
          recordLabel: recordId,
          actorName: 'Super Admin',
          createdAt: new Date().toISOString(),
          note: 'Record unlinked manually.',
        };
        setActivityEvents((prev) => [newEvent, ...prev]);

        triggerAuditLog(
          'Super Admin',
          'audit_event',
          channelType,
          `Unlinked ${recordType} (${recordId}) from conversation.`,
          conversationId
        );
      },
      restoreLinkedRecord: (conversationId, recordType, recordId) => {
        const conv = conversations.find((c) => c.id === conversationId);
        const channelType = conv ? conv.channelType : 'whatsapp';
        setConversations((prev) =>
          prev.map((c) => {
            if (c.id === conversationId) {
              const alreadyExists = c.linkedRecords.some((r) => r.type === recordType && r.id === recordId);
              if (alreadyExists) return c;
              return {
                ...c,
                linkedRecords: [
                  ...c.linkedRecords,
                  {
                    type: recordType as any,
                    id: recordId,
                    label: recordId,
                    origin: 'linked',
                    createdAt: new Date().toISOString(),
                    ownerName: 'Super Admin',
                    status: 'Restored',
                  },
                ],
              };
            }
            return c;
          })
        );

        const newEvent: OmnichannelConversionActivityEvent = {
          id: `ACT-${Date.now()}`,
          conversationId,
          type: 'record_restored',
          recordType: recordType as any,
          recordId,
          recordLabel: recordId,
          actorName: 'Super Admin',
          createdAt: new Date().toISOString(),
          note: 'Record restored manually.',
        };
        setActivityEvents((prev) => [newEvent, ...prev]);

        triggerAuditLog(
          'Super Admin',
          'audit_event',
          channelType,
          `Restored linked ${recordType} (${recordId}) on conversation.`,
          conversationId
        );
      },

      // Channels Actions
      pauseChannel: (channelId) => {
        setChannels((prev) =>
          prev.map((ch) => {
            if (ch.id === channelId) {
              triggerAuditLog(
                'Super Admin',
                'channel_connection',
                ch.type,
                `Channel connection paused: ${ch.name}.`
              );
              return {
                ...ch,
                health: {
                  ...ch.health,
                  status: 'offline',
                  connectionStatus: 'disconnected',
                  notes: 'Paused by supervisor.',
                },
              };
            }
            return ch;
          })
        );
      },
      resumeChannel: (channelId) => {
        setChannels((prev) =>
          prev.map((ch) => {
            if (ch.id === channelId) {
              triggerAuditLog(
                'Super Admin',
                'channel_connection',
                ch.type,
                `Channel connection resumed: ${ch.name}.`
              );
              return {
                ...ch,
                health: {
                  ...ch.health,
                  status: 'healthy',
                  connectionStatus: 'connected',
                  notes: 'Resumed. Monitoring active.',
                },
              };
            }
            return ch;
          })
        );
      },
      syncChannel: (channelId) => {
        setChannels((prev) =>
          prev.map((ch) => {
            if (ch.id === channelId) {
              triggerAuditLog(
                'Super Admin',
                'channel_connection',
                ch.type,
                `Channel synchronization triggered: ${ch.name}.`
              );
              return {
                ...ch,
                health: {
                  ...ch.health,
                  lastSyncAt: new Date().toISOString(),
                  syncStatus: 'synced',
                },
              };
            }
            return ch;
          })
        );
      },
      reconnectChannel: (channelId) => {
        setChannels((prev) =>
          prev.map((ch) => {
            if (ch.id === channelId) {
              triggerAuditLog(
                'Super Admin',
                'channel_connection',
                ch.type,
                `Channel connection reestablished: ${ch.name}.`
              );
              return {
                ...ch,
                health: {
                  ...ch.health,
                  status: 'healthy',
                  connectionStatus: 'connected',
                  lastSyncAt: new Date().toISOString(),
                  webhookStatus: 'ok',
                },
              };
            }
            return ch;
          })
        );
      },
      testChannelConnection: (channelId) => {
        const ch = channels.find((c) => c.id === channelId);
        if (ch) {
          triggerAuditLog(
            'Super Admin',
            'channel_connection',
            ch.type,
            `Channel diagnostic test run: ${ch.name}.`
          );
        }
      },
      saveChannelConfiguration: (channelId, config) => {
        setChannelConfigurations((prev) =>
          prev.map((cfg) => {
            if (cfg.channelId === channelId) {
              return { ...cfg, ...config };
            }
            return cfg;
          })
        );
        const ch = channels.find((c) => c.id === channelId);
        if (ch) {
          triggerAuditLog(
            'Super Admin',
            'channel_connection',
            ch.type,
            `Channel configuration saved: ${ch.name}.`
          );
        }
      },
      addChannelLogEvent: (channelId, eventText) => {
        setChannelEvents((prev) => {
          const current = prev[channelId] || [];
          return {
            ...prev,
            [channelId]: [`[${new Date().toLocaleTimeString()}] ${eventText}`, ...current].slice(0, 50),
          };
        });
      },

      // Routing Rules Actions
      addRoutingRule: (rule) => {
        const newRule: OmnichannelRoutingRule = {
          ...rule,
          id: `RULE-${Date.now()}`,
        };
        setRoutingRules((prev) => [...prev, newRule]);
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'whatsapp',
          `Routing rule created: ${rule.name.en}.`
        );
      },
      updateRoutingRule: (id, rule) => {
        setRoutingRules((prev) =>
          prev.map((r) => (r.id === id ? { ...r, ...rule } as OmnichannelRoutingRule : r))
        );
        const ruleName = routingRules.find((r) => r.id === id)?.name.en || id;
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'whatsapp',
          `Routing rule updated: ${ruleName}.`
        );
      },
      deleteRoutingRule: (id) => {
        const ruleName = routingRules.find((r) => r.id === id)?.name.en || id;
        setRoutingRules((prev) => prev.filter((r) => r.id !== id));
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'whatsapp',
          `Routing rule deleted: ${ruleName}.`
        );
      },
      duplicateRoutingRule: (id) => {
        const original = routingRules.find((r) => r.id === id);
        if (original) {
          const duplicated: OmnichannelRoutingRule = {
            ...original,
            id: `RULE-${Date.now()}`,
            name: {
              en: `${original.name.en} (Copy)`,
              ar: `${original.name.ar} (نسخة)`,
            },
            priority: routingRules.length + 1,
            status: 'draft',
          };
          setRoutingRules((prev) => [...prev, duplicated]);
          triggerAuditLog(
            'Super Admin',
            'audit_event',
            'whatsapp',
            `Routing rule duplicated: ${original.name.en}.`
          );
        }
      },
      enableRoutingRule: (id, enabled) => {
        setRoutingRules((prev) =>
          prev.map((r) => (r.id === id ? { ...r, status: enabled ? 'active' : 'paused' } : r))
        );
        const ruleName = routingRules.find((r) => r.id === id)?.name.en || id;
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'whatsapp',
          `Routing rule status toggled: ${ruleName} -> ${enabled ? 'active' : 'paused'}.`
        );
      },
      reorderRoutingRules: (rules) => {
        const updated = rules.map((r, index) => ({ ...r, priority: index + 1 }));
        setRoutingRules(updated);
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'whatsapp',
          'Routing rules order updated.'
        );
      },

      // Automation Rules Actions
      addAutomationRule: (rule) => {
        const newRule: OmnichannelAutomationRule = {
          ...rule,
          id: `AUTO-${Date.now()}`,
        };
        setAutomationRules((prev) => [...prev, newRule]);
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'email',
          `Automation rule created: ${rule.name.en}.`
        );
      },
      updateAutomationRule: (id, rule) => {
        setAutomationRules((prev) =>
          prev.map((r) => (r.id === id ? { ...r, ...rule } as OmnichannelAutomationRule : r))
        );
        const ruleName = automationRules.find((r) => r.id === id)?.name.en || id;
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'email',
          `Automation rule updated: ${ruleName}.`
        );
      },
      deleteAutomationRule: (id) => {
        const ruleName = automationRules.find((r) => r.id === id)?.name.en || id;
        setAutomationRules((prev) => prev.filter((r) => r.id !== id));
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'email',
          `Automation rule deleted: ${ruleName}.`
        );
      },
      duplicateAutomationRule: (id) => {
        const original = automationRules.find((r) => r.id === id);
        if (original) {
          const duplicated: OmnichannelAutomationRule = {
            ...original,
            id: `AUTO-${Date.now()}`,
            name: {
              en: `${original.name.en} (Copy)`,
              ar: `${original.name.ar} (نسخة)`,
            },
            status: 'draft',
          };
          setAutomationRules((prev) => [...prev, duplicated]);
          triggerAuditLog(
            'Super Admin',
            'audit_event',
            'email',
            `Automation rule duplicated: ${original.name.en}.`
          );
        }
      },
      enableAutomationRule: (id, enabled) => {
        setAutomationRules((prev) =>
          prev.map((r) => (r.id === id ? { ...r, status: enabled ? 'active' : 'paused' } : r))
        );
        const ruleName = automationRules.find((r) => r.id === id)?.name.en || id;
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'email',
          `Automation rule status toggled: ${ruleName} -> ${enabled ? 'active' : 'paused'}.`
        );
      },
      runAutomationNow: (id, conversationId) => {
        const rule = automationRules.find((r) => r.id === id);
        if (!rule) return { success: false, message: 'Rule not found' };

        const targetConv = conversationId ? conversations.find((c) => c.id === conversationId) : conversations[0];
        const newLog: OmnichannelAutomationActivity = {
          id: `AUTOLOG-${Date.now()}`,
          ruleId: id,
          ruleName: rule.name.en,
          conversationId: targetConv?.id,
          status: 'success',
          message: `Executed successfully. Actions triggered: ${rule.actions.map((a) => a.summary).join(', ')}.`,
          createdAt: new Date().toISOString(),
        };

        setAutomationActivities((prev) => [newLog, ...prev]);

        // If action is create ticket, mock create support ticket
        const hasTicketAction = rule.actions.some((a) => a.type === 'create_ticket');
        if (hasTicketAction && targetConv) {
          const newTkt: OmnichannelTicketRecordMock = {
            id: `TKT-${Math.floor(100 + Math.random() * 900)}`,
            subject: `Automated: ${rule.name.en}`,
            customerName: targetConv.customer.name,
            priority: 'normal',
            category: 'Automation',
            status: 'Open',
            ownerId: 'USR-001',
            ownerName: 'Super Admin',
            teamName: 'Support',
            createdAt: new Date().toISOString(),
          };
          setTicketRecords((prev) => [newTkt, ...prev]);

          // Link to conversation
          setConversations((prev) =>
            prev.map((c) => {
              if (c.id === targetConv.id) {
                return {
                  ...c,
                  linkedRecords: [
                    ...c.linkedRecords,
                    {
                      type: 'support_ticket',
                      id: newTkt.id,
                      label: newTkt.subject,
                      origin: 'converted',
                      createdAt: new Date().toISOString(),
                    },
                  ],
                };
              }
              return c;
            })
          );
        }

        // Audit log
        triggerAuditLog(
          'Automation Engine',
          'automation_event',
          targetConv ? targetConv.channelType : 'email',
          `Automation executed: "${rule.name.en}".`,
          targetConv?.id
        );

        return { success: true, message: `Successfully executed: ${rule.name.en}` };
      },

      // Templates Actions
      addTemplate: (template) => {
        const newTpl: OmnichannelQuickReplyTemplate = {
          ...template,
          id: `TPL-${Date.now()}`,
          usageCount: 0,
        };
        setTemplates((prev) => [...prev, newTpl]);
        triggerAuditLog(
          'Super Admin',
          'template_change',
          template.channelTypes[0] || 'whatsapp',
          `Template created: ${template.title.en}.`
        );
      },
      updateTemplate: (id, template) => {
        setTemplates((prev) =>
          prev.map((t) => (t.id === id ? { ...t, ...template } as OmnichannelQuickReplyTemplate : t))
        );
        const tpl = templates.find((t) => t.id === id);
        const tplName = tpl ? tpl.title.en : id;
        triggerAuditLog(
          'Super Admin',
          'template_change',
          tpl?.channelTypes[0] || 'whatsapp',
          `Template updated: ${tplName}.`
        );
      },
      deleteTemplate: (id) => {
        const tpl = templates.find((t) => t.id === id);
        const tplName = tpl ? tpl.title.en : id;
        setTemplates((prev) => prev.filter((t) => t.id !== id));
        triggerAuditLog(
          'Super Admin',
          'template_change',
          tpl?.channelTypes[0] || 'whatsapp',
          `Template deleted: ${tplName}.`
        );
      },
      duplicateTemplate: (id) => {
        const original = templates.find((t) => t.id === id);
        if (original) {
          const duplicated: OmnichannelQuickReplyTemplate = {
            ...original,
            id: `TPL-${Date.now()}`,
            title: {
              en: `${original.title.en} (Copy)`,
              ar: `${original.title.ar} (نسخة)`,
            },
            approvalStatus: 'draft',
            usageCount: 0,
          };
          setTemplates((prev) => [...prev, duplicated]);
          triggerAuditLog(
            'Super Admin',
            'template_change',
            original.channelTypes[0] || 'whatsapp',
            `Template duplicated: ${original.title.en}.`
          );
        }
      },
      archiveTemplate: (id, archived) => {
        setTemplates((prev) =>
          prev.map((t) => (t.id === id ? { ...t, approvalStatus: archived ? 'archived' : 'draft' } : t))
        );
        const tpl = templates.find((t) => t.id === id);
        triggerAuditLog(
          'Super Admin',
          'template_change',
          tpl?.channelTypes[0] || 'whatsapp',
          `Template archived/restored: ${tpl ? tpl.title.en : id} -> ${archived ? 'archived' : 'restored'}.`
        );
      },

      // Tags Actions
      addLabel: (label) => {
        const newLabel: OmnichannelLabelDefinition = {
          ...label,
          id: `label-${Date.now()}`,
          usageCount: 0,
        };
        setLabels((prev) => [...prev, newLabel]);
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'whatsapp',
          `Tag definition created: ${label.name.en}.`
        );
      },
      updateLabel: (id, label) => {
        setLabels((prev) =>
          prev.map((l) => (l.id === id ? { ...l, ...label } as OmnichannelLabelDefinition : l))
        );
      },
      deleteLabel: (id) => {
        const tagInUse = conversations.some((c) => c.tagIds.includes(id));
        if (tagInUse) return false;

        const tagName = labels.find((l) => l.id === id)?.name.en || id;
        setLabels((prev) => prev.filter((l) => l.id !== id));
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'whatsapp',
          `Tag definition deleted: ${tagName}.`
        );
        return true;
      },
      duplicateLabel: (id) => {
        const original = labels.find((l) => l.id === id);
        if (original) {
          const duplicated: OmnichannelLabelDefinition = {
            ...original,
            id: `label-${Date.now()}`,
            name: {
              en: `${original.name.en} (Copy)`,
              ar: `${original.name.ar} (نسخة)`,
            },
            usageCount: 0,
          };
          setLabels((prev) => [...prev, duplicated]);
          triggerAuditLog(
            'Super Admin',
            'audit_event',
            'whatsapp',
            `Tag definition duplicated: ${original.name.en}.`
          );
        }
      },

      // SLA Actions
      addSlaPolicy: (policy) => {
        const newPolicy: OmnichannelSlaPolicy = {
          ...policy,
          id: `SLA-${Date.now()}`,
        };
        setSlaPolicies((prev) => [...prev, newPolicy]);
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'email',
          `SLA policy created: ${policy.name.en}.`
        );
      },
      updateSlaPolicy: (id, policy) => {
        setSlaPolicies((prev) =>
          prev.map((p) => (p.id === id ? { ...p, ...policy } as OmnichannelSlaPolicy : p))
        );
        const policyName = slaPolicies.find((p) => p.id === id)?.name.en || id;
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'email',
          `SLA policy updated: ${policyName}.`
        );
      },
      deleteSlaPolicy: (id) => {
        const policyName = slaPolicies.find((p) => p.id === id)?.name.en || id;
        setSlaPolicies((prev) => prev.filter((p) => p.id !== id));
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'email',
          `SLA policy deleted: ${policyName}.`
        );
      },
      enableSlaPolicy: (id, enabled) => {
        setSlaPolicies((prev) =>
          prev.map((p) => (p.id === id ? { ...p, status: enabled ? 'active' : 'paused' } : p))
        );
        const policyName = slaPolicies.find((p) => p.id === id)?.name.en || id;
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'email',
          `SLA policy status toggled: ${policyName} -> ${enabled ? 'active' : 'paused'}.`
        );
      },

      // Team Actions
      updateTeamMemberStatus: (id, onlineStatus) => {
        setTeamMembers((prev) =>
          prev.map((m) => {
            if (m.id === id) {
              triggerAuditLog(
                'Super Admin',
                'audit_event',
                'whatsapp',
                `Staff member ${m.name} status changed to ${onlineStatus}.`
              );
              return { ...m, onlineStatus };
            }
            return m;
          })
        );
      },
      rebalanceTeamWorkload: (teamName) => {
        setTeamMembers((prev) =>
          prev.map((m) => {
            if (m.teamName === teamName) {
              return {
                ...m,
                workloadPercent: Math.max(30, Math.min(80, Math.floor(40 + Math.random() * 30))),
              };
            }
            return m;
          })
        );
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'whatsapp',
          `Rebalanced workload for team: ${teamName}.`
        );
      },

      // Broadcasts Actions
      addBroadcast: (broadcast) => {
        const newBc: OmnichannelBroadcastCampaign = {
          ...broadcast,
          id: `BC-${Date.now()}`,
          deliveryStatus: 'scheduled',
        };
        setBroadcasts((prev) => [...prev, newBc]);
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          broadcast.channelType,
          `Broadcast scheduled: ${broadcast.name}.`
        );
      },
      updateBroadcast: (id, broadcast) => {
        setBroadcasts((prev) =>
          prev.map((b) => (b.id === id ? { ...b, ...broadcast } as OmnichannelBroadcastCampaign : b))
        );
      },
      cancelBroadcast: (id) => {
        const name = broadcasts.find((b) => b.id === id)?.name || id;
        const channelType = broadcasts.find((b) => b.id === id)?.channelType || 'whatsapp';
        setBroadcasts((prev) =>
          prev.map((b) => (b.id === id ? { ...b, deliveryStatus: 'cancelled' } : b))
        );
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          channelType,
          `Broadcast cancelled: ${name}.`
        );
      },
      duplicateBroadcast: (id) => {
        const original = broadcasts.find((b) => b.id === id);
        if (original) {
          const duplicated: OmnichannelBroadcastCampaign = {
            ...original,
            id: `BC-${Date.now()}`,
            name: `${original.name} (Copy)`,
            deliveryStatus: 'draft',
            scheduledAt: new Date(Date.now() + 86400000).toISOString(), // +1 day
          };
          setBroadcasts((prev) => [...prev, duplicated]);
          triggerAuditLog(
            'Super Admin',
            'audit_event',
            original.channelType,
            `Broadcast duplicated: ${original.name}.`
          );
        }
      },

      // Settings Actions
      saveSettings: (newSettings) => {
        setSettings((prev) => ({ ...prev, ...newSettings }));
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'whatsapp',
          'Omnichannel configuration settings saved.'
        );
      },
      resetSettings: () => {
        setSettings(mockOmnichannelSettings);
        triggerAuditLog(
          'Super Admin',
          'audit_event',
          'whatsapp',
          'Omnichannel configuration settings reset to default.'
        );
      },
      resetAllMockStore: () => {
        setConversations(mockOmnichannelConversations);
        setMessages(mockOmnichannelMessages);
        setInternalNotes(mockOmnichannelInternalNotes);
        setLeadRecords(mockOmnichannelLeadRecords);
        setCustomerRecords(mockOmnichannelCustomerRecords);
        setTicketRecords(mockOmnichannelTicketRecords);
        setCaseRecords(mockOmnichannelCaseRecords);
        setActivityEvents(mockOmnichannelConversionActivities);
        setChannels(mockOmnichannelChannels);
        setChannelConfigurations(mockOmnichannelChannelConfigurations);
        setChannelEvents({});
        setRoutingRules(mockOmnichannelRoutingRules);
        setAutomationRules(mockOmnichannelAutomationRules);
        setAutomationActivities(mockOmnichannelAutomationActivities);
        setTemplates(mockOmnichannelTemplates);
        setLabels(mockOmnichannelLabels);
        setSlaPolicies(mockOmnichannelSlaPolicies);
        setTeamMembers(mockOmnichannelTeamWorkload);
        setBroadcasts(mockOmnichannelBroadcasts);
        setSettings(mockOmnichannelSettings);
        setActivityLogs(mockOmnichannelActivityLogs);
        triggerAuditLog(
          'System QA Runner',
          'audit_event',
          'whatsapp',
          'All Omnichannel mock store data was reset to default.'
        );
      },
      addActivityLogEntry: (actorName, category, channelType, summary, conversationId) => {
        triggerAuditLog(actorName, category, channelType, summary, conversationId);
      },
    };
  }, [conversations, routingRules, automationRules, templates, labels, slaPolicies, broadcasts]);

  // 3. Compute derived selectors
  const selectors = useMemo<OmnichannelMockStoreSelectors>(() => {
    return {
      metrics: calculateOmnichannelMetrics(conversations),
      queueOverview: deriveQueueOverview(conversations, mockOmnichannelQueues),
      slaRisks: deriveSlaRisks(conversations),
      channelVolume: deriveChannelVolume(conversations),
      agentSnapshots: deriveAgentSnapshots(conversations, teamMembers, ticketRecords),
      conversionSummary: deriveConversionSummary(conversations),
      tagUsage: deriveTagUsage(labels, conversations),
    };
  }, [conversations, teamMembers, ticketRecords, labels]);

  // 4. Combine into final context value
  const value = useMemo<OmnichannelMockStoreContextType>(() => {
    return {
      conversations,
      messages,
      internalNotes,
      leadRecords,
      customerRecords,
      ticketRecords,
      caseRecords,
      activityEvents,
      channels,
      channelConfigurations,
      channelEvents,
      routingRules,
      automationRules,
      automationActivities,
      templates,
      labels,
      slaPolicies,
      teamMembers,
      broadcasts,
      settings,
      activityLogs,
      ...actions,
      ...selectors,
    };
  }, [
    conversations,
    messages,
    internalNotes,
    leadRecords,
    customerRecords,
    ticketRecords,
    caseRecords,
    activityEvents,
    channels,
    channelConfigurations,
    channelEvents,
    routingRules,
    automationRules,
    automationActivities,
    templates,
    labels,
    slaPolicies,
    teamMembers,
    broadcasts,
    settings,
    activityLogs,
    actions,
    selectors,
  ]);

  return (
    <OmnichannelMockStoreContext.Provider value={value}>
      {children}
    </OmnichannelMockStoreContext.Provider>
  );
};
