import React from 'react';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

interface OmnichannelModuleShellProps {
  title: string;
  description: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
}

export const OmnichannelModuleShell: React.FC<OmnichannelModuleShellProps> = ({
  title,
  description,
  actions,
  children,
}) => {
  const { direction } = useLocale();
  const isRTL = direction === 'rtl';

  return (
    <div className="page-container bg-[#F4F7FE] dark:bg-gray-950 p-4 md:p-8 min-h-screen">
      <div className="mx-auto max-w-[1400px] space-y-6 overflow-x-clip" dir={direction}>
        
        {/* Top Welcome Banner (NeoPay Style) */}
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "flex-row-reverse")}>
            <div className={cn(isRTL ? "text-right" : "text-left")}>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                    {title}
                </h1>
                <p className="mt-1 text-sm text-blue-100 opacity-90">
                    {description}
                </p>
            </div>
            
            {actions && (
              <div className={cn("flex items-center gap-2 sm:gap-3 banner-actions", isRTL && "flex-row-reverse")}>
                {/* We render the passed actions here but style them inside the parent if needed, 
                    or they bring their own styling. We might need to ensure they look good on blue. */}
                {actions}
              </div>
            )}
        </div>

        {children}
      </div>
    </div>
  );
};
