import React from 'react';
import { Users, DollarSign, TrendingUp, Calendar, Briefcase, Navigation, ShieldCheck, Clock, Zap, ArrowRight, Activity, AlertCircle } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { PageHeader } from '../ui/PageHeader';
import { StatCard } from '../ui/StatCard';
import { Card, CardContent } from '../ui/Card';
import { Select } from '../ui/Select';
import ReactApexChart from 'react-apexcharts';
import { ApexOptions } from 'apexcharts';
import { useLocale } from '../../localization/useLocale';
import type { TranslationKey } from '../../localization/messages';
import { cn } from '../../utils/cn';

const revenueData = [
    { month: 'Aug', revenue: 45000, leads: 124 },
    { month: 'Sep', revenue: 52000, leads: 145 },
    { month: 'Oct', revenue: 48000, leads: 132 },
    { month: 'Nov', revenue: 61000, leads: 167 },
    { month: 'Dec', revenue: 55000, leads: 154 },
    { month: 'Jan', revenue: 67000, leads: 189 },
];

const leadSourceData = [
    { source: 'Website', value: 45, color: '#3B82F6' },
    { source: 'Social Media', value: 30, color: '#10B981' },
    { source: 'Direct Agent', value: 15, color: '#F59E0B' },
    { source: 'Referral', value: 10, color: '#EF4444' },
];

export const Dashboard: React.FC = () => {
    const navigate = useNavigate();
    const { t, isRTL } = useLocale();

    const getLocalizedSource = (source: string) => {
        switch (source) {
            case 'Website': return t('dashboard.charts.sources.website');
            case 'Social Media': return t('dashboard.charts.sources.socialMedia');
            case 'Direct Agent': return t('dashboard.charts.sources.directAgent');
            case 'Referral': return t('dashboard.charts.sources.referral');
            default: return source;
        }
    };

    const chartOptions: ApexOptions = {
        chart: {
            type: 'area',
            toolbar: { show: false },
            fontFamily: 'inherit',
            background: 'transparent',
        },
        dataLabels: { enabled: false },
        stroke: { curve: 'smooth', width: [3, 0] },
        xaxis: {
            categories: revenueData.map(d => {
                switch (d.month) {
                    case 'Aug': return t('dashboard.charts.months.aug');
                    case 'Sep': return t('dashboard.charts.months.sep');
                    case 'Oct': return t('dashboard.charts.months.oct');
                    case 'Nov': return t('dashboard.charts.months.nov');
                    case 'Dec': return t('dashboard.charts.months.dec');
                    case 'Jan': return t('dashboard.charts.months.jan');
                    default: return d.month;
                }
            }),
            axisBorder: { show: false },
            axisTicks: { show: false },
            labels: { style: { colors: '#94a3b8', fontSize: '10px', fontWeight: 600 } },
        },
        yaxis: [
            {
                title: { text: t('dashboard.charts.revenue'), style: { color: '#2563EB', fontWeight: 600, fontSize: '10px' } },
                labels: {
                    formatter: (val) => `$${(val / 1000).toFixed(0)}k`,
                    style: { colors: '#2563EB', fontSize: '10px', fontWeight: 600 },
                },
            },
            {
                opposite: !isRTL,
                title: { text: t('dashboard.charts.leads'), style: { color: '#94A3B8', fontWeight: 600, fontSize: '10px' } },
                labels: {
                    formatter: (val) => `${val}`,
                    style: { colors: '#94A3B8', fontSize: '10px', fontWeight: 600 },
                },
            }
        ],
        fill: {
            type: ['gradient', 'solid'],
            gradient: {
                shadeIntensity: 1,
                opacityFrom: 0.7,
                opacityTo: 0.15,
                stops: [0, 100],
            },
        },
        colors: ['#2563EB', 'transparent'],
        grid: { 
            borderColor: '#E2E8F0', 
            strokeDashArray: 6, 
            padding: { left: 0, right: 0 },
            xaxis: { lines: { show: true } },
            yaxis: { lines: { show: false } }
        },
        markers: { size: 0, hover: { size: 5 } },
        tooltip: { theme: 'light', x: { show: false }, shared: true, intersect: false },
    };

    return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
            {/* Top Welcome Banner (NeoPay Style) */}
            <div className={cn("flex flex-col xl:flex-row xl:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "xl:flex-row-reverse")}>
                <div className={cn(isRTL ? "text-right" : "text-left")}>
                    <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                        {t('dashboard.title')}
                    </h1>
                    <p className="mt-1 text-sm text-blue-100 opacity-90">
                        {t('dashboard.subtitle')}
                    </p>
                </div>
                
                <div className={cn("flex items-center gap-2 sm:gap-3 banner-actions", isRTL && "flex-row-reverse")}>
                    {/* Quick Actions inside Banner */}
                    <div className={cn("flex items-center gap-1 sm:gap-2 bg-white/10 rounded-2xl p-1 sm:p-1.5", isRTL && "flex-row-reverse")}>
                        {[
                            { labelKey: 'dashboard.actions.newReservation', icon: Calendar, href: '/reservations/new' },
                            { labelKey: 'dashboard.actions.addLead', icon: Zap, href: '/leads/new' },
                            { labelKey: 'dashboard.actions.recordPayment', icon: DollarSign, href: '/finance/record-payment' },
                            { labelKey: 'dashboard.actions.createTicket', icon: AlertCircle, href: '/help-center/new' },
                            { labelKey: 'dashboard.actions.assignStaff', icon: Users, href: '/operations/schedule' },
                            { labelKey: 'dashboard.actions.viewReports', icon: TrendingUp, href: '/reports' },
                        ].map((action, i) => (
                            <button
                                key={i}
                                onClick={() => navigate(action.href)}
                                className="flex h-8 w-8 sm:h-10 sm:w-10 items-center justify-center rounded-xl hover:bg-white text-blue-100 hover:text-blue-600 transition-all duration-300 tooltip-trigger"
                                title={t(action.labelKey as TranslationKey)}
                            >
                                <action.icon className="h-4 w-4 sm:h-5 sm:w-5" />
                            </button>
                        ))}
                    </div>

                    <div className={cn(
                        "flex items-center bg-white/10 rounded-2xl transition-all duration-300", 
                        isRTL ? "md:pr-2 md:pl-4 flex-row-reverse" : "md:pl-2 md:pr-4",
                        "p-1.5 md:py-2 gap-0 md:gap-3"
                    )}>
                        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white text-blue-600">
                            <Activity className="h-5 w-5 animate-pulse" />
                        </div>
                        <div className="hidden md:flex flex-col">
                            <span className="text-sm font-semibold leading-tight">{t('dashboard.realtimeData')}</span>
                            <span className="text-[10px] text-blue-200 uppercase tracking-widest">Active Session</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Core Metrics (3x2 Grid) */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                <StatCard 
                    label={t('dashboard.metrics.totalRevenue')} 
                    value="$284.5k" 
                    icon={DollarSign} 
                    trend={`↑ 12.5% ${t('dashboard.metrics.trend.month')}`} 
                    trendType="up" 
                    iconColor="text-emerald-500" 
                    iconBg="bg-emerald-50 dark:bg-emerald-900/20" 
                />
                <StatCard 
                    label={t('dashboard.metrics.totalBookings')} 
                    value="1,842" 
                    icon={Briefcase} 
                    trend={`↑ 8.2% ${t('dashboard.metrics.trend.week')}`} 
                    trendType="up" 
                    iconColor="text-blue-500" 
                    iconBg="bg-blue-50 dark:bg-blue-900/20" 
                />
                <StatCard 
                    label={t('dashboard.metrics.confirmations')} 
                    value="12" 
                    icon={Clock} 
                    trend={t('dashboard.metrics.trend.highPriority')} 
                    trendType="neutral" 
                    iconColor="text-amber-500" 
                    iconBg="bg-amber-50 dark:bg-amber-900/20" 
                />
                <StatCard 
                    label={t('dashboard.metrics.conversion')} 
                    value="18.5%" 
                    icon={TrendingUp} 
                    trend={t('dashboard.metrics.trend.stable')} 
                    trendType="neutral" 
                    iconColor="text-purple-500" 
                    iconBg="bg-purple-50 dark:bg-purple-900/20" 
                />
                <StatCard 
                    label={t('dashboard.metrics.operations')} 
                    value="42" 
                    icon={Navigation} 
                    trend={`8 ${t('dashboard.metrics.trend.activeNow')}`} 
                    trendType="up" 
                    iconColor="text-rose-500" 
                    iconBg="bg-rose-50 dark:bg-rose-900/20" 
                />
                <StatCard 
                    label={t('dashboard.metrics.efficiency')} 
                    value="92%" 
                    icon={ShieldCheck} 
                    trend={t('dashboard.metrics.trend.target')} 
                    trendType="neutral" 
                    iconColor="text-indigo-500" 
                    iconBg="bg-indigo-50 dark:bg-indigo-900/20" 
                />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                {/* Revenue Chart */}
                <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] lg:col-span-2">
                    <CardContent className="p-6">
                        <div className={cn("flex items-center justify-between mb-8", isRTL && "flex-row-reverse")}>
                            <h3 className="text-lg font-bold tracking-tight text-slate-800 dark:text-white">{t('dashboard.charts.revenueGrowth')}</h3>
                            <Select className="w-32 h-8 text-xs font-semibold rounded-xl bg-slate-50 border-0" value="Monthly" onChange={() => {}}>
                                <option value="Monthly">{t('dashboard.charts.filter.monthly')}</option>
                                <option value="Weekly">{t('dashboard.charts.filter.weekly')}</option>
                            </Select>
                        </div>
                        <div className="h-[300px]">
                            <ReactApexChart
                                options={chartOptions}
                                series={[
                                    { name: t('dashboard.charts.revenue'), type: 'area', data: revenueData.map(d => d.revenue) }
                                ]}
                                type="area"
                                height={300}
                            />
                        </div>
                    </CardContent>
                </Card>

                {/* Lead Distribution */}
                <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)]">
                    <CardContent className="p-6">
                        <h3 className="text-lg font-bold tracking-tight text-slate-800 dark:text-white mb-8 rtl:text-right">{t('dashboard.charts.leadDistribution')}</h3>
                        <div className="h-[280px]">
                            <ReactApexChart
                                options={{
                                    chart: { type: 'donut', fontFamily: 'inherit' },
                                    labels: leadSourceData.map(s => getLocalizedSource(s.source)),
                                    colors: leadSourceData.map(s => s.color),
                                    legend: { position: 'bottom', fontSize: '12px', fontWeight: 600, markers: { radius: 12 } },
                                    dataLabels: { enabled: false },
                                    stroke: { show: false },
                                    plotOptions: {
                                        pie: {
                                            donut: {
                                                size: '75%',
                                                labels: {
                                                    show: true,
                                                    total: { show: true, label: t('dashboard.charts.leads'), formatter: () => '1,847', fontSize: '14px', fontWeight: 700 }
                                                }
                                            }
                                        }
                                    }
                                }}
                                series={leadSourceData.map(s => s.value)}
                                type="donut"
                                height={280}
                            />
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Bottom Row Activity & Tasks */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)]">
                    <CardContent className="p-6">
                        <div className={cn("flex items-center justify-between mb-6", isRTL && "flex-row-reverse")}>
                            <h3 className="text-lg font-bold tracking-tight text-slate-800 dark:text-white">{t('dashboard.reminders.title')}</h3>
                            <Clock className="h-5 w-5 text-slate-400" />
                        </div>
                        <div className="space-y-2">
                            {[
                                { titleKey: 'dashboard.reminders.task1.title', subtitleKey: 'dashboard.reminders.task1.desc', time: '10:30 AM', priority: 'High' },
                                { titleKey: 'dashboard.reminders.task2.title', subtitleKey: 'dashboard.reminders.task2.desc', time: '12:00 PM', priority: 'Critical' },
                                { titleKey: 'dashboard.reminders.task3.title', subtitleKey: 'dashboard.reminders.task3.desc', time: '02:00 PM', priority: 'Medium' }
                            ].map((task, i) => (
                                <div key={i} className={cn("flex items-center justify-between p-3 rounded-2xl border border-transparent hover:border-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group cursor-pointer", isRTL && "flex-row-reverse text-right")}>
                                    <div className="flex items-center gap-4">
                                        <div className="w-5 h-5 rounded border border-slate-300 flex items-center justify-center text-transparent group-hover:border-blue-500 group-hover:text-blue-500 transition-colors">
                                           <svg className="w-3 h-3 fill-current" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"/></svg>
                                        </div>
                                        <div>
                                            <p className="text-sm font-bold text-slate-800 dark:text-white">{t(task.titleKey as TranslationKey)}</p>
                                            <p className="text-xs text-slate-500">{t(task.subtitleKey as TranslationKey)} - {task.time}</p>
                                        </div>
                                    </div>
                                    <div className={cn("px-2.5 py-1 rounded-md text-[10px] font-bold tracking-wide", task.priority === 'Critical' ? 'bg-rose-50 text-rose-600' : task.priority === 'High' ? 'bg-amber-50 text-amber-600' : 'bg-emerald-50 text-emerald-600')}>
                                        {task.priority.toUpperCase()}
                                    </div>
                                </div>
                            ))}
                        </div>
                        <button 
                            onClick={() => navigate('/sales/tasks')}
                            className="w-full mt-6 py-3 rounded-xl text-xs font-bold bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors"
                        >
                            {t('dashboard.reminders.viewAllTasks')}
                        </button>
                    </CardContent>
                </Card>

                <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] lg:col-span-2">
                    <CardContent className="p-6">
                        <div className={cn("flex items-center justify-between mb-6", isRTL && "flex-row-reverse")}>
                            <h3 className="text-lg font-bold tracking-tight text-slate-800 dark:text-white">{t('dashboard.activity.title')}</h3>
                            <Link to="/users/logs" className={cn("text-xs font-bold text-blue-600 hover:underline flex items-center gap-1", isRTL && "flex-row-reverse")}>
                                {t('dashboard.activity.viewAll')} <Activity className="h-4 w-4" />
                            </Link>
                        </div>
                        <div className="space-y-4">
                            {[
                                { actionKey: 'dashboard.activity.item1.action', timeKey: 'dashboard.activity.item1.time', typeKey: 'dashboard.activity.type.lead' },
                                { actionKey: 'dashboard.activity.item2.action', timeKey: 'dashboard.activity.item2.time', typeKey: 'dashboard.activity.type.finance' },
                                { actionKey: 'dashboard.activity.item3.action', timeKey: 'dashboard.activity.item3.time', typeKey: 'dashboard.activity.type.operations' },
                                { actionKey: 'dashboard.activity.item4.action', timeKey: 'dashboard.activity.item4.time', typeKey: 'dashboard.activity.type.system' }
                            ].map((a, i) => (
                                <div key={i} className={cn("flex items-center justify-between border-b border-slate-100 dark:border-gray-800 pb-4 last:border-0 last:pb-0 gap-3", isRTL && "flex-row-reverse")}>
                                    <div className={cn("flex items-center gap-2 sm:gap-4 banner-actions", isRTL && "flex-row-reverse text-right")}>
                                        <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center flex-shrink-0 text-slate-400">
                                            <Activity className="w-5 h-5" />
                                        </div>
                                        <div>
                                            <p className="text-sm font-semibold text-slate-800 dark:text-white">{t(a.actionKey as TranslationKey)}</p>
                                            <p className="text-xs text-slate-500 bidi-isolate">{t(a.timeKey as TranslationKey)}</p>
                                        </div>
                                    </div>
                                    <span className="text-[10px] px-2 py-1 bg-slate-50 text-slate-600 rounded-md font-bold uppercase tracking-widest flex-shrink-0">{t(a.typeKey as TranslationKey)}</span>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>
            </div>
        </div>
    );
};