import React, { useState, useEffect } from 'react';
import { Search, Eye, Edit, Key, UserX, Mail, Download, Users, Activity, Shield, ShieldCheck, UserPlus } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Card, CardContent } from '../ui/Card';
import { StatCard } from '../ui/StatCard';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { formatDate } from '../../utils/format';
// ExportModal replaced by toast
import { useToastContext } from '../../contexts/ToastContext';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';
import { mockUsers } from '../../services/mockData';

export const UsersPage: React.FC = () => {
    const [users, setUsers] = useState(mockUsers || []);
    const [searchTerm, setSearchTerm] = useState('');
    const [roleFilter, setRoleFilter] = useState('All Roles');

    // export modal replaced
    const { direction, isRTL } = useLocale();

    const toast = useToastContext();
    const navigate = useNavigate();

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'Active': return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/20';
            case 'Inactive': return 'bg-rose-100 text-rose-800 dark:bg-rose-900/20';
            default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20';
        }
    };

    const filteredUsers = users.filter(u => {
        const matchesSearch = u.name.toLowerCase().includes(searchTerm.toLowerCase()) || u.email.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesRole = roleFilter === 'All Roles' || u.role === roleFilter;
        return matchesSearch && matchesRole;
    });

    const metrics = {
        total: users.length,
        active: users.filter(u => u.status === 'Active').length,
        admins: users.filter(u => u.role.includes('Admin')).length,
        pending: 3
    };

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px] space-y-6">
            {/* Top Welcome Banner (NeoPay Style) */}
            <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "sm:flex-row-reverse")}>
                <div className={cn(isRTL ? "text-right" : "text-left")}>
                    <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Identity & Access</h1>
                    <p className="mt-1 text-sm text-blue-100 opacity-90">Manage team hierarchy, security credentials, and system access</p>
                </div>
                <div className={cn("flex items-center gap-2 sm:gap-3 banner-actions", isRTL && "flex-row-reverse")}>
                    <Button variant="outline" onClick={() => navigate('/users/roles')} className="bg-white/10 text-white border-transparent hover:bg-white/20">
                        <Shield className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                        Roles
                    </Button>
                    <Button variant="outline" onClick={() => navigate('/users/invite')} className="bg-white/10 text-white border-transparent hover:bg-white/20">
                        <Mail className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                        Invite
                    </Button>
                    <Button onClick={() => navigate('/users/new')} className="bg-white text-blue-600 hover:bg-blue-50 border-transparent">
                        <UserPlus className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                        Add User
                    </Button>
                </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <StatCard
                    label="Total Team"
                    value={metrics.total}
                    icon={Users}
                    iconColor="text-blue-500"
                    iconBg="bg-blue-50 dark:bg-blue-900/20"
                />

                <StatCard
                    label="Active Sessions"
                    value={metrics.active}
                    icon={Activity}
                    iconColor="text-emerald-500"
                    iconBg="bg-emerald-50 dark:bg-emerald-900/20"
                />

                <StatCard
                    label="Admin Roles"
                    value={metrics.admins}
                    icon={ShieldCheck}
                    iconColor="text-purple-500"
                    iconBg="bg-purple-50 dark:bg-purple-900/20"
                />

                <StatCard
                    label="Pending Invites"
                    value={metrics.pending}
                    icon={Mail}
                    iconColor="text-amber-500"
                    iconBg="bg-amber-50 dark:bg-amber-900/20"
                />
            </div>

            {/* Filters */}
            <Card className="card-premium">
                <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-4">
                        <div className="flex-1 w-full relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                            <Input
                                placeholder="Search team by name or email..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="pl-10"
                            />
                        </div>
                        <Select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} className="w-full md:w-64">
                            <option>All Roles</option>
                            <option>System Administrator</option>
                            <option>Sales Manager</option>
                            <option>Reservations Officer</option>
                            <option>Finance Manager</option>
                        </Select>
                        <Button variant="outline" onClick={() => toast.success('Export', 'Users data exported successfully.')}>
                            <Download className="h-4 w-4 mr-2" />
                            Export
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Table */}
            <div className="table-container">
                <table className="table-premium">
                    <thead>
                        <tr>
                            <th>User Profile</th>
                            <th>Organization</th>
                            <th>System Access</th>
                            <th>Activity</th>
                            <th>Status</th>
                            <th className="text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredUsers.map((u) => (
                            <tr key={u.id}>
                                <td>
                                    <div className="flex items-center">
                                        <div className="h-8 w-8 rounded-full bg-gray-100 overflow-hidden mr-3 border border-gray-200 dark:border-gray-700 shadow-sm flex-shrink-0">
                                            <img src={u.name.toLowerCase().includes('layla') || u.name.toLowerCase().includes('sarah') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
                                        </div>
                                        <div>
                                            <div className="text-sm font-bold text-gray-900 dark:text-white">{u.name}</div>
                                            <div className="text-[10px] text-gray-500">{u.email}</div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div className="text-xs font-medium">{u.role}</div>
                                    <div className="text-[10px] text-gray-500">{u.department}</div>
                                </td>
                                <td>
                                    <div className="flex flex-wrap gap-1">
                                        {u.permissions?.slice(0, 2).map((p: string) => (
                                            <span key={p} className="text-[9px] font-bold uppercase bg-gray-100 dark:bg-gray-800 px-1.5 py-0.5 rounded text-gray-600 dark:text-gray-400">
                                                {p}
                                            </span>
                                        ))}
                                        {u.permissions?.length > 2 && <span className="text-[9px] text-gray-400">+{u.permissions.length - 2}</span>}
                                    </div>
                                </td>
                                <td>
                                    <div className="text-xs font-medium">{u.lastLogin ? 'Last login: ' + formatDate(u.lastLogin) : 'Never'}</div>
                                    <div className="text-[10px] text-gray-500">Joined {formatDate(u.joinDate)}</div>
                                </td>
                                <td>
                                    <span className={`badge-standard ${getStatusColor(u.status)}`}>{u.status}</span>
                                </td>
                                <td className="text-right">
                                    <TableActionsDropdown
                                        actions={[
                                            { label: 'View Profile', icon: Eye, onClick: () => navigate('/users/view', { state: { user: u } }) },
                                            { label: 'Edit Settings', icon: Edit, onClick: () => navigate('/users/edit', { state: { user: u } }) },
                                            { label: 'View Permission Key', icon: Key, onClick: () => toast.info(`Security Token: ${u.id}-AUTH-KEY`, 'Use this key for API integrations.') },
                                            { label: 'Deactivate User', icon: UserX, onClick: () => toast.error('Account Deactivated', `Access for ${u.name} has been revoked.`) }
                                        ]}
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {/* ExportModal replaced by toast */}
            </div>
        </div>
    );
};