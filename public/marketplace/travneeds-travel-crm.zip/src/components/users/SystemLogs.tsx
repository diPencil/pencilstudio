import React, { useState } from 'react';
import { Search, AlertCircle, CheckCircle, User, Shield, Terminal, Download } from 'lucide-react';
import { Card, CardContent } from '../ui/Card';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { formatDate } from '../../utils/format';
import { useToastContext } from '../../contexts/ToastContext';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

const initialLogs = [
    {
        id: 1,
        user: 'Super Admin',
        action: 'User Login',
        module: 'Authentication',
        details: 'Successful login from IP 192.168.1.1',
        timestamp: new Date().toISOString(),
        status: 'Success',
        severity: 'Info'
    },
    {
        id: 2,
        user: 'Ahmed Hassan',
        action: 'Create Reservation',
        module: 'Reservations',
        details: 'New reservation BK-2025-156 created',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        status: 'Success',
        severity: 'Info'
    },
    {
        id: 3,
        user: 'System',
        action: 'Failed Login Attempt',
        module: 'Authentication',
        details: '3 failed attempts for user designer@example.com',
        timestamp: new Date(Date.now() - 7200000).toISOString(),
        status: 'Failed',
        severity: 'Warning'
    },
    {
        id: 4,
        user: 'Super Admin',
        action: 'Change Permissions',
        module: 'User Management',
        details: 'Updated Sales Manager role permissions',
        timestamp: new Date(Date.now() - 86400000).toISOString(),
        status: 'Success',
        severity: 'Critical'
    },
    {
        id: 5,
        user: 'Fatma Ali',
        action: 'Export Data',
        module: 'Customers',
        details: 'Exported customer list to Excel (500 records)',
        timestamp: new Date(Date.now() - 172800000).toISOString(),
        status: 'Success',
        severity: 'Info'
    }
];

export const SystemLogs: React.FC = () => {
    const { isRTL, direction } = useLocale();
    const [searchTerm, setSearchTerm] = useState('');
    const [moduleFilter, setModuleFilter] = useState('All Modules');
    const [severityFilter, setSeverityFilter] = useState('All Severities');
    const toast = useToastContext();

    const getSeverityColor = (severity: string) => {
        switch (severity) {
            case 'Critical': return 'text-red-600 bg-red-100 dark:bg-red-900/40';
            case 'Warning': return 'text-amber-600 bg-amber-100 dark:bg-amber-900/40';
            case 'Info': return 'text-blue-600 bg-blue-100 dark:bg-blue-900/40';
            default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/40';
        }
    };

    const getStatusIcon = (status: string) => {
        return status === 'Success' ? <CheckCircle className="h-4 w-4 text-emerald-500" /> : <AlertCircle className="h-4 w-4 text-rose-500" />;
    };

    const filteredLogs = initialLogs.filter(log => {
        const matchesSearch =
            log.user.toLowerCase().includes(searchTerm.toLowerCase()) ||
            log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
            log.details.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesModule = moduleFilter === 'All Modules' || log.module === moduleFilter;
        const matchesSeverity = severityFilter === 'All Severities' || log.severity === severityFilter;
        return matchesSearch && matchesModule && matchesSeverity;
    });

    const handleExport = () => {
        toast.info('Log Export', 'Generating audit log CSV... Your download will start shortly.');
    };

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
                    <div>
                        <h1 className="text-2xl font-bold flex items-center">
                            <div className={cn("p-2 bg-white/20 rounded-xl", isRTL ? "ml-3" : "mr-3")}>
                                <Terminal className="h-6 w-6 text-white" />
                            </div>
                            System Audit Trail
                        </h1>
                        <p className="text-blue-100 font-medium mt-1">Real-time surveillance of all system modules and security events</p>
                    </div>
                    <Button variant="outline" className="shadow-sm bg-white text-blue-600 hover:bg-blue-50 border-none" onClick={handleExport}>
                        <Download className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                        <span>Export Logs</span>
                    </Button>
                </div>

            <Card className="shadow-sm bg-white dark:bg-gray-800">
                <CardContent className="p-6">
                    <div className="flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-6">
                        <div className="relative flex-1">
                            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                            <Input
                                placeholder="Search logs..."
                                className="pl-12 h-10"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <div className="flex space-x-4">
                            <Select className="w-48 h-10" value={moduleFilter} onChange={e => setModuleFilter(e.target.value)}>
                                <option>All Modules</option>
                                <option>Authentication</option>
                                <option>Reservations</option>
                                <option>User Management</option>
                                <option>Customers</option>
                            </Select>
                            <Select className="w-48 h-10" value={severityFilter} onChange={e => setSeverityFilter(e.target.value)}>
                                <option>All Severities</option>
                                <option>Info</option>
                                <option>Warning</option>
                                <option>Critical</option>
                            </Select>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card className="overflow-hidden shadow-sm">
                <CardContent className="p-0">
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead className="bg-gray-50/50 dark:bg-gray-900/50 border-b border-gray-100 dark:border-gray-800">
                                <tr>
                                    <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-500 uppercase tracking-widest">Timestamp</th>
                                    <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-500 uppercase tracking-widest">Operator</th>
                                    <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-500 uppercase tracking-widest">Action</th>
                                    <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-500 uppercase tracking-widest">Module</th>
                                    <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-500 uppercase tracking-widest">Details</th>
                                    <th className="px-6 py-4 text-left text-[10px] font-bold text-gray-500 uppercase tracking-widest">Severity</th>
                                    <th className="px-6 py-4 text-center text-[10px] font-bold text-gray-500 uppercase tracking-widest">Status</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                                {filteredLogs.map((log) => (
                                    <tr key={log.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="text-sm font-bold text-gray-900 dark:text-white">{formatDate(log.timestamp)}</div>
                                            <div className="text-[10px] text-gray-400 mt-1">{new Date(log.timestamp).toLocaleTimeString()}</div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center space-x-3">
                                                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${log.user === 'System' ? 'bg-gray-100 dark:bg-gray-700 text-gray-500' : 'overflow-hidden border border-gray-200 dark:border-gray-700'}`}>
                                                    {log.user === 'System' ? <Shield className="h-4 w-4" /> : <img src={log.user.toLowerCase().includes('fatma') || log.user.toLowerCase().includes('nour') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />}
                                                </div>
                                                <span className="text-sm font-bold text-gray-700 dark:text-gray-300">{log.user}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className="text-sm font-bold text-gray-900 dark:text-white">{log.action}</span>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className="text-[10px] font-bold px-2 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-500 rounded uppercase tracking-widest">{log.module}</span>
                                        </td>
                                        <td className="px-6 py-4 max-w-xs">
                                            <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-1">{log.details}</p>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-widest ${getSeverityColor(log.severity)}`}>
                                                {log.severity}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-center">
                                            <div className="flex justify-center">
                                                {getStatusIcon(log.status)}
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                                {filteredLogs.length === 0 && (
                                    <tr>
                                        <td colSpan={7} className="px-8 py-20 text-center">
                                            <div className="flex flex-col items-center justify-center opacity-20">
                                                <Terminal className="h-16 w-16 mb-4" />
                                                <p className="text-xl font-black uppercase tracking-widest">No matching logs found</p>
                                            </div>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>

            <div className="flex items-center justify-between text-xs font-black uppercase tracking-widest text-gray-400 px-2">
                <p>Showing {filteredLogs.length} of 1,284 high-integrity entries</p>
                <div className="flex space-x-3">
                    <Button variant="outline" size="sm" className="h-10 px-6 border-none bg-white dark:bg-gray-800 shadow-sm opacity-50 cursor-not-allowed">Previous</Button>
                    <Button variant="outline" size="sm" className="h-10 px-6 border-none bg-white dark:bg-gray-800 shadow-sm hover:translate-x-1 transition-transform">Next Page</Button>
                </div>
            </div>
            </div>
        </div>
    );
};
