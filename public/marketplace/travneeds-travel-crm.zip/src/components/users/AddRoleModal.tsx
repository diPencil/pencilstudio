import React, { useState } from 'react';
import { X, Shield, Check } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface AddRoleModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (roleData: any) => void;
}

const permissionOptions = [
    { id: 'leads_view', label: 'View Leads', category: 'CRM' },
    { id: 'leads_create', label: 'Create Leads', category: 'CRM' },
    { id: 'sales_view', label: 'View Sales', category: 'Finance' },
    { id: 'sales_invoice', label: 'Create Invoices', category: 'Finance' },
    { id: 'users_manage', label: 'Manage Users', category: 'System' },
    { id: 'settings_edit', label: 'Edit Settings', category: 'System' }
];

export const AddRoleModal: React.FC<AddRoleModalProps> = ({ isOpen, onClose, onSave }) => {
    const [formData, setFormData] = useState({
        name: '',
        description: '',
        permissions: [] as string[]
    });

    if (!isOpen) return null;

    const togglePermission = (id: string) => {
        setFormData(prev => ({
            ...prev,
            permissions: prev.permissions.includes(id)
                ? prev.permissions.filter(p => p !== id)
                : [...prev.permissions, id]
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData);
        onClose();
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-white dark:bg-gray-800 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col scale-in-center">
                <div className="p-6 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                        <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
                            <Shield className="h-6 w-6" />
                        </div>
                        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Create New Role</h2>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full">
                        <X className="h-5 w-5 text-gray-400" />
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-6">
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-1">Role Name</label>
                            <Input
                                required
                                placeholder="e.g., Regional Manager"
                                value={formData.name}
                                onChange={e => setFormData({ ...formData, name: e.target.value })}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-gray-700 dark:text-gray-300 mb-1">Description</label>
                            <Input
                                required
                                placeholder="Short description of responsibilities"
                                value={formData.description}
                                onChange={e => setFormData({ ...formData, description: e.target.value })}
                            />
                        </div>
                    </div>

                    <div className="space-y-3">
                        <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">Module Permissions</label>
                        <div className="grid grid-cols-2 gap-3">
                            {permissionOptions.map(opt => (
                                <div
                                    key={opt.id}
                                    onClick={() => togglePermission(opt.id)}
                                    className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${formData.permissions.includes(opt.id)
                                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                                        : 'border-gray-100 dark:border-gray-700 hover:border-blue-200'
                                        }`}
                                >
                                    <div>
                                        <p className="text-sm font-bold text-gray-900 dark:text-white">{opt.label}</p>
                                        <p className="text-[10px] text-gray-400 uppercase tracking-widest">{opt.category}</p>
                                    </div>
                                    {formData.permissions.includes(opt.id) && (
                                        <div className="h-5 w-5 bg-blue-500 rounded-full flex items-center justify-center">
                                            <Check className="h-3 w-3 text-white" />
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="flex space-x-3 pt-4 border-t border-gray-100 dark:border-gray-700">
                        <Button type="button" variant="outline" className="flex-1" onClick={onClose}>Cancel</Button>
                        <Button type="submit" className="flex-1 bg-blue-600 shadow-xl shadow-blue-500/20">Create Role</Button>
                    </div>
                </form>
            </div>
        </div>
    );
};
