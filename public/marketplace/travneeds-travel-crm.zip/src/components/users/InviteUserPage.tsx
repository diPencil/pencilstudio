import React, { useState } from 'react';
import { Send, ArrowLeft, Shield, Users } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { Card, CardContent } from '../ui/Card';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';

const roles = ['Admin', 'Sales Manager', 'Manager', 'Reservation', 'Finance', 'Support Agent', 'Operations'];
const departments = ['Management', 'Sales', 'Operations', 'Finance', 'Support', 'Marketing'];

export const InviteUserPage: React.FC = () => {
    const navigate = useNavigate();
    const toast = useToastContext();
    const [formData, setFormData] = useState({
        email: '',
        role: 'Support Agent',
        department: 'Support',
        message: 'You have been invited to join the Nut Travel CRM system. Please check your email for login instructions.'
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(false);

    const validateForm = () => {
        const newErrors: Record<string, string> = {};

        if (!formData.email.trim()) {
            newErrors.email = 'Email is required';
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
            newErrors.email = 'Please enter a valid email address';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!validateForm()) {
            return;
        }

        setIsLoading(true);
        try {
            console.log('Sending invitation:', formData);
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 1000));

            toast.success('Invitation Sent', `A link has been sent to ${formData.email}`);
            navigate('/users');
        } catch (error) {
            console.error('Error sending invitation:', error);
            toast.error('Error', 'Failed to send invitation. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleInputChange = (field: string, value: string) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        if (errors[field]) {
            setErrors(prev => ({ ...prev, [field]: '' }));
        }
    };

  return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => navigate('/users')}
                            className="inline-flex items-center gap-2 text-blue-100 hover:text-white transition-colors group p-2 hover:bg-white/10 rounded-lg"
                        >
                            <ArrowLeft className="w-5 h-5 rtl-flip" />
                        </button>
                        <div>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Invite New User</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">Send an invitation link to a new team member</p>
                        </div>
                    </div>
                </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <Card>
                        <CardContent className="p-8">
                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div className="space-y-6">
                                    <Input
                                        label="Email Address *"
                                        type="email"
                                        value={formData.email}
                                        onChange={(e) => handleInputChange('email', e.target.value)}
                                        error={errors.email}
                                        placeholder="Enter email address"
                                    />

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <Select
                                            label="Role"
                                            value={formData.role}
                                            onChange={(e) => handleInputChange('role', e.target.value)}
                                        >
                                            {roles.map(role => (
                                                <option key={role} value={role}>{role}</option>
                                            ))}
                                        </Select>

                                        <Select
                                            label="Department"
                                            value={formData.department}
                                            onChange={(e) => handleInputChange('department', e.target.value)}
                                        >
                                            {departments.map(dept => (
                                                <option key={dept} value={dept}>{dept}</option>
                                            ))}
                                        </Select>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                            Invitation Message
                                        </label>
                                        <textarea
                                            value={formData.message}
                                            onChange={(e) => handleInputChange('message', e.target.value)}
                                            rows={4}
                                            className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                            placeholder="Custom invitation message..."
                                        />
                                    </div>
                                </div>

                                <div className="flex justify-end space-x-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                                    <Button
                                        type="button"
                                        variant="outline"
                                        onClick={() => navigate('/users')}
                                        disabled={isLoading}
                                    >
                                        Cancel
                                    </Button>
                                    <Button
                                        type="submit"
                                        disabled={isLoading}
                                        loading={isLoading}
                                    >
                                        <Send className="h-4 w-4 mr-2" />
                                        Send Invitation
                                    </Button>
                                </div>
                            </form>
                        </CardContent>
                    </Card>
                </div>

                <div className="space-y-6">
                    <Card className="bg-white dark:bg-gray-800 border-none shadow-md">
                        <CardContent className="p-6">
                            <div className="flex items-center space-x-3 mb-4">
                                <div className="p-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                                    <Shield className="h-5 w-5 text-blue-500" />
                                </div>
                                <h3 className="text-lg font-bold text-gray-900 dark:text-white">Security Note</h3>
                            </div>
                            <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">
                                Invitation links are valid for 24 hours. Users will be asked to set up their password and two-factor authentication upon first login.
                            </p>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardContent className="p-6">
                            <div className="flex items-center space-x-3 mb-4">
                                <Users className="h-5 w-5 text-gray-400" />
                                <h3 className="font-semibold text-gray-900 dark:text-white">Role Permissions</h3>
                            </div>
                            <div className="space-y-4">
                                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                                    <p className="text-[10px] font-bold text-gray-900 dark:text-white mb-1 uppercase tracking-widest">Admin</p>
                                    <p className="text-xs text-gray-500">Full system access, user management, and configuration.</p>
                                </div>
                                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                                    <p className="text-[10px] font-bold text-gray-900 dark:text-white mb-1 uppercase tracking-widest">Manager</p>
                                    <p className="text-xs text-gray-500">Department-wide access, reporting, and team oversight.</p>
                                </div>
                                <div className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                                    <p className="text-[10px] font-bold text-gray-900 dark:text-white mb-1 uppercase tracking-widest">Support Agent</p>
                                    <p className="text-xs text-gray-500">Daily operations, customer support, and sales tasks.</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
        </div>
    );
};
