import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { User, Calendar, Shield, Activity, Award, MessageSquare, FileText, Target, ArrowLeft } from 'lucide-react';
import { useToastContext } from '../../contexts/ToastContext';
import { formatDate, formatDateTime } from '../../utils/format';
import { Button } from '../ui/Button';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

const mockAssignments = [
  { id: 'LEAD-456', type: 'Lead', title: 'Ahmed Corporation - Dubai Package', status: 'In Progress' },
  { id: 'BOOK-789', type: 'Booking', title: 'Family Trip - Hurghada Resort', status: 'Confirmed' },
  { id: 'TICKET-123', type: 'Ticket', title: 'Payment Issue - Refund Request', status: 'In Progress' }
];

const mockRecentActivity = [
  { action: 'Updated lead status', time: '2 hours ago', type: 'lead' },
  { action: 'Created new booking', time: '4 hours ago', type: 'booking' },
  { action: 'Resolved support ticket', time: '1 day ago', type: 'ticket' }
];

export const ViewUserPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('personal');
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToastContext();
  const { t, direction, isRTL } = useLocale();

  const user = location.state?.user;

  if (!user) {
    return (
      <div className="w-full pb-8 pt-8 flex justify-center">
        <Button onClick={() => navigate('/users')}>{t('common.back') || 'Back to Users'}</Button>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'Inactive': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'Admin': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300';
      case 'Sales Manager': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const tabs = [
    { id: 'personal', label: 'Personal Info', icon: User },
    { id: 'work', label: 'Work Info', icon: Shield },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'permissions', label: 'Permissions', icon: Shield },
    { id: 'activity', label: 'Activity', icon: Activity },
    { id: 'performance', label: 'Performance', icon: Award }
  ];

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate('/users')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div className="flex items-center space-x-4">
              <div className="h-12 w-12 rounded-full overflow-hidden border-2 border-white/20 shadow-inner flex-shrink-0">
                <img src={user.name.toLowerCase().includes('layla') || user.name.toLowerCase().includes('sarah') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                  {user.name}
                </h1>
                <div className="flex items-center space-x-2 mt-2">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getRoleColor(user.role)}`}>
                    {user.role}
                  </span>
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(user.status)}`}>
                    {user.status}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar Navigation */}
          <div className="w-full md:w-1/4 bg-white dark:bg-gray-900 rounded-3xl p-6 shadow-sm">
            <nav className="space-y-2">
              {tabs.map((tab) => {
                const IconComponent = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center w-full px-3 py-2 text-sm font-medium rounded-xl transition-colors ${activeTab === tab.id
                      ? 'bg-blue-50 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300'
                      : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800'
                      }`}
                  >
                    <IconComponent className={cn("h-4 w-4", isRTL ? "ml-3" : "mr-3")} />
                    {tab.label}
                  </button>
                );
              })}
            </nav>

            {/* Quick Actions */}
            <div className="mt-8">
              <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-4">Quick Actions</h3>
              <div className="space-y-2">
                <button
                  onClick={() => {
                    toast.info('Direct Message', `Initiating secure chat with ${user.name}...`);
                  }}
                  className="w-full text-left text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 p-2 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20 flex items-center gap-2"
                >
                  <MessageSquare className="h-4 w-4" />
                  <span>Send Message</span>
                </button>
                <button
                  onClick={() => {
                    navigate('/help-center/new', { state: { customerName: user.name } });
                  }}
                  className="w-full text-left text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 p-2 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20 flex items-center gap-2"
                >
                  <FileText className="h-4 w-4" />
                  <span>Open Support Ticket</span>
                </button>
                <button
                  onClick={() => {
                    toast.success('Task Assignment', `Tasking module opened for ${user.name}.`);
                  }}
                  className="w-full text-left text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 p-2 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20 flex items-center gap-2"
                >
                  <Target className="h-4 w-4" />
                  <span>Assign Task</span>
                </button>
                <button
                  onClick={() => {
                    toast.info('Meeting Sync', `Checking calendar availability for ${user.name}...`);
                  }}
                  className="w-full text-left text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 p-2 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20 flex items-center gap-2"
                >
                  <Calendar className="h-4 w-4" />
                  <span>Schedule Meeting</span>
                </button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 bg-white dark:bg-gray-900 rounded-3xl p-6 md:p-8 shadow-sm">
            {activeTab === 'personal' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Personal Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Full Name</label>
                    <p className="text-gray-900 dark:text-white">{user.name}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Date of Birth</label>
                    <p className="text-gray-900 dark:text-white">March 15, 1990</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Nationality</label>
                    <p className="text-gray-900 dark:text-white">Egyptian</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Gender</label>
                    <p className="text-gray-900 dark:text-white">Female</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Address</label>
                    <p className="text-gray-900 dark:text-white">123 Tahrir Square, Cairo, Egypt</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Emergency Contact</label>
                    <p className="text-gray-900 dark:text-white">Ahmed Hassan (+20 123 456 700)</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Relationship</label>
                    <p className="text-gray-900 dark:text-white">Spouse</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'performance' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Performance Summary</h3>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="bg-blue-50 dark:bg-blue-900/20 rounded-2xl p-4">
                    <div className="text-2xl font-bold text-blue-800 dark:text-blue-300">{user.tasksCompleted}</div>
                    <div className="text-sm text-blue-600 dark:text-blue-400">Tasks Completed</div>
                  </div>
                  <div className="bg-green-50 dark:bg-green-900/20 rounded-2xl p-4">
                    <div className="text-2xl font-bold text-green-800 dark:text-green-300">{user.avgResponseTime}</div>
                    <div className="text-sm text-green-600 dark:text-green-400">Response Time</div>
                  </div>
                  <div className="bg-purple-50 dark:bg-purple-900/20 rounded-2xl p-4">
                    <div className="text-2xl font-bold text-purple-800 dark:text-purple-300">{user.casesClosed}</div>
                    <div className="text-sm text-purple-600 dark:text-purple-400">Cases Closed</div>
                  </div>
                  <div className="bg-orange-50 dark:bg-orange-900/20 rounded-2xl p-4">
                    <div className="text-2xl font-bold text-orange-800 dark:text-orange-300">{user.satisfactionRate}/5</div>
                    <div className="text-sm text-orange-600 dark:text-orange-400">Satisfaction Rate</div>
                  </div>
                </div>

                <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-6">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Active Assignments (12 items)</h4>
                  <div className="space-y-3">
                    {mockAssignments.map((assignment) => (
                      <div key={assignment.id} className="flex items-center justify-between p-3 bg-white dark:bg-gray-900 rounded-xl">
                        <div>
                          <div className="font-medium text-gray-900 dark:text-white">{assignment.title}</div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">{assignment.id}</div>
                        </div>
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${assignment.status === 'In Progress' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300' :
                          'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300'
                          }`}>
                          {assignment.status}
                        </span>
                      </div>
                    ))}
                  </div>
                  <button className="mt-4 text-sm font-bold text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300">
                    View All Assignments
                  </button>
                </div>

                <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl p-6">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-4">Recent Activity</h4>
                  <div className="space-y-3">
                    {mockRecentActivity.map((activity, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <div>
                          <div className="text-sm text-gray-900 dark:text-white">{activity.action}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">{activity.time}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'work' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Work Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Employee ID</label>
                    <p className="text-gray-900 dark:text-white">{user.id}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Department</label>
                    <p className="text-gray-900 dark:text-white">{user.department}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Role</label>
                    <p className="text-gray-900 dark:text-white">{user.role}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Join Date</label>
                    <p className="text-gray-900 dark:text-white">{formatDate(user.joinDate)}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Email</label>
                    <p className="text-gray-900 dark:text-white">{user.email}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Phone</label>
                    <p className="text-gray-900 dark:text-white">{user.phone}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Last Login</label>
                    <p className="text-gray-900 dark:text-white">
                      {user.lastLogin ? formatDateTime(user.lastLogin) : 'Never'}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'security' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Security Settings</h3>
                <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/30 rounded-2xl p-6">
                  <div className="flex items-start space-x-4">
                    <Shield className="h-8 w-8 text-amber-600 mt-1" />
                    <div>
                      <p className="font-bold text-amber-900 dark:text-amber-400 uppercase tracking-widest text-xs mb-2">Account Protection</p>
                      <p className="text-sm text-amber-800/80 dark:text-amber-500/80 leading-relaxed">Two-factor authentication is active. Last password change was 24 days ago from a verified IP in Cairo.</p>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                  <div className="p-4 border border-gray-100 dark:border-gray-700 rounded-2xl space-y-4">
                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest">Active Sessions</p>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-900 dark:text-white font-medium">Desktop - Chrome (Current)</span>
                      <span className="text-[10px] bg-green-50 text-green-600 px-2 py-0.5 rounded font-black">ACTIVE</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-900 dark:text-white font-medium">Mobile - Safari</span>
                      <span className="text-[10px] text-gray-400">2 hours ago</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'permissions' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Authorized Access Scope</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {(user.permissions || ['View Dashboard', 'Create Leads', 'Manage Bookings']).map((perm: string) => (
                    <div key={perm} className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-xl border border-transparent hover:border-blue-500/20 transition-all flex items-center space-x-3">
                      <div className="h-2 w-2 bg-blue-500 rounded-full shadow-[0_0_8px_rgba(59,130,246,0.5)]"></div>
                      <span className="text-sm font-bold text-gray-700 dark:text-gray-300">{perm}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'activity' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Activity Intelligence</h3>
                  <Button variant="outline" size="sm">Export Log</Button>
                </div>
                <div className="space-y-0 relative before:absolute before:left-[17px] before:top-2 before:bottom-2 before:w-0.5 before:bg-gray-100 dark:before:bg-gray-700">
                  {mockRecentActivity.map((activity, idx) => (
                    <div key={idx} className="relative pl-12 py-4">
                      <div className="absolute left-0 top-1/2 -translate-y-1/2 h-9 w-9 bg-white dark:bg-gray-800 rounded-full border-4 border-gray-50 dark:border-gray-900 flex items-center justify-center z-10">
                        <Activity className="h-3 w-3 text-blue-500" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-gray-900 dark:text-white">{activity.action}</p>
                        <p className="text-xs text-gray-500 mt-1">{activity.time} • via {activity.type === 'lead' ? 'Leads Module' : 'System Console'}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
