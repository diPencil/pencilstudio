import React, { useState } from 'react';
import { Shield, Lock, AlertCircle, Plus, Edit, Trash2, Info, Users as UsersIcon } from 'lucide-react';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
// AddRoleModal replaced by toast
import { useToastContext } from '../../contexts/ToastContext';

const initialRoles = [
    {
        name: 'System Administrator',
        description: 'Full access to all system modules and global configurations',
        users: 2,
        permissions: ['All Modules', 'User Management', 'System Settings', 'Financial Reports'],
        status: 'System'
    },
    {
        name: 'Sales Manager',
        description: 'Lead generation, customer acquisition, and pipeline tracking',
        users: 3,
        permissions: ['Leads', 'Customers', 'Sales Pipeline', 'Sales Reports'],
        status: 'Active'
    },
    {
        name: 'Reservations Officer',
        description: 'Booking fulfillment, supplier coordination, and tracker management',
        users: 8,
        permissions: ['Reservations', 'Supplier Tracker', 'Vouchers', 'Customer Viewing'],
        status: 'Active'
    }
];

const permissionModules = [
    {
        name: 'Leads & CRM',
        permissions: [
            { id: 'leads_view', name: 'View Leads', description: 'Can see the list of leads' },
            { id: 'leads_create', name: 'Create Leads', description: 'Can add new leads to the system' },
            { id: 'leads_edit', name: 'Edit Leads', description: 'Can modify lead details' }
        ]
    },
    {
        name: 'Finance & Sales',
        permissions: [
            { id: 'sales_view', name: 'View Sales', description: 'Can see sales records' },
            { id: 'sales_invoice', name: 'Create Invoices', description: 'Can generate new invoices' },
            { id: 'sales_pay', name: 'Process Payments', description: 'Can record payment entries' }
        ]
    }
];

export const RolesPermissions: React.FC = () => {
    const [roles, setRoles] = useState(initialRoles);
    const [selectedRole, setSelectedRole] = useState(roles[0]);
    // add role modal replaced
    const toast = useToastContext();

  return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div>
                        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Access Control Matrix</h1>
                        <p className="mt-1 text-sm text-blue-100 opacity-90">Define organizational roles and granular permission levels</p>
                    </div>
                    <Button onClick={() => toast.success('Role Created', 'New access level defined.')} className="mt-4 sm:mt-0 bg-white text-blue-600 hover:bg-gray-50 rounded-xl font-bold">
                        <Plus className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                        New Role
                    </Button>
                </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Roles List */}
                <div className="space-y-4">
                    <h3 className="text-[10px] font-bold uppercase tracking-widest text-gray-400 px-1 mb-4">Organizational Roles</h3>
                    {roles.map((role) => (
                        <Card
                            key={role.name}
                            className={`cursor-pointer transition-all border-2 ${selectedRole.name === role.name ? 'border-blue-500 ring-4 ring-blue-500/5' : 'border-transparent hover:border-gray-200'}`}
                            onClick={() => setSelectedRole(role)}
                        >
                            <CardContent className="p-5">
                                <div className="flex items-center justify-between mb-4">
                                    <div className={`p-2 rounded-lg ${selectedRole.name === role.name ? 'bg-blue-600 text-white' : 'bg-blue-50 text-blue-600'}`}>
                                        <Shield className="h-5 w-5" />
                                    </div>
                                    {role.status === 'System' && (
                                        <span className="text-[9px] font-bold uppercase tracking-widest bg-gray-100 text-gray-500 px-2 py-0.5 rounded">Core</span>
                                    )}
                                </div>
                                <h3 className="text-sm font-bold text-gray-900 dark:text-white">{role.name}</h3>
                                <p className="text-xs text-gray-500 mt-2 line-clamp-2">{role.description}</p>
                                <div className="flex items-center mt-6 space-x-4">
                                    <div className="flex items-center text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                                        <Lock className="h-3 w-3 mr-1.5" />
                                        {role.permissions.length} Modules
                                    </div>
                                    <div className="flex items-center text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                                        <UsersIcon className="h-3 w-3 mr-1.5" />
                                        {role.users} Users
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>

                {/* Permissions Editor */}
                <div className="lg:col-span-2 space-y-6">
                    <Card className="card-premium">
                        <CardContent className="p-8">
                            <div className="flex items-start justify-between mb-8 border-b border-gray-100 dark:border-gray-800 pb-6">
                                <div>
                                    <h2 className="text-xl font-bold text-gray-900 dark:text-white">{selectedRole.name}</h2>
                                    <p className="description-sm mt-1">{selectedRole.description}</p>
                                </div>
                                <div className="flex space-x-2">
                                    <Button variant="outline" size="sm">
                                        <Edit className="h-3 w-3 mr-2" />
                                        Rename
                                    </Button>
                                    {selectedRole.status !== 'System' && (
                                        <Button variant="ghost" size="sm" className="text-rose-500 hover:bg-rose-50">
                                            <Trash2 className="h-3 w-3" />
                                        </Button>
                                    )}
                                </div>
                            </div>

                            <div className="space-y-10">
                                {permissionModules.map((module) => (
                                    <div key={module.name}>
                                        <h4 className="text-xs font-bold text-gray-900 dark:text-white mb-6 uppercase tracking-widest flex items-center">
                                            <div className="w-1 h-4 bg-blue-600 rounded-full mr-3" />
                                            {module.name}
                                        </h4>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            {module.permissions.map((perm) => (
                                                <div key={perm.id} className="flex items-start p-4 rounded-xl border border-gray-100 dark:border-gray-700 hover:border-blue-100 transition-colors bg-gray-50/30">
                                                    <div className="flex items-center h-5 mr-3 mt-0.5">
                                                        <input
                                                            type="checkbox"
                                                            defaultChecked={true}
                                                            disabled={selectedRole.status === 'System'}
                                                            className="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500 transition-all cursor-pointer"
                                                        />
                                                    </div>
                                                    <div>
                                                        <p className="text-xs font-bold text-gray-900 dark:text-white">{perm.name}</p>
                                                        <p className="text-[10px] text-gray-500 mt-1">{perm.description}</p>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className="mt-12 p-4 bg-blue-50 dark:bg-blue-900/10 rounded-xl flex items-start space-x-4">
                                <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                                    <AlertCircle className="h-5 w-5 text-blue-600" />
                                </div>
                                <div>
                                    <p className="text-xs font-bold text-blue-900 dark:text-blue-300 uppercase tracking-widest">Permission Propagation</p>
                                    <p className="text-[10px] text-blue-800/70 dark:text-blue-400/70 mt-1">
                                        Modifying these permissions will affect all active users assigned to this role immediately upon save.
                                    </p>
                                </div>
                                <div className="ml-auto">
                                    {selectedRole.status !== 'System' && (
                                        <Button size="sm" onClick={() => toast.success('Policy Updated', 'Role permissions synchronized.')}>Save Changes</Button>
                                    )}
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>

            {/* AddRoleModal replaced by toast */}
        </div>
        </div>
    );
};
