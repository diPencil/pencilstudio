import React, { useState } from 'react';
import { X, Download } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { Input } from '../ui/Input';
import { FinanceBooking } from './FinancePage';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: FinanceBooking[];
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose, data }) => {
  const { t, direction } = useLocale();
  const [exportFormat, setExportFormat] = useState('excel');
  const [dateRange, setDateRange] = useState('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [includeFields, setIncludeFields] = useState({
    basicInfo: true,
    paymentDetails: true,
    supplierInfo: true,
    profitAnalysis: true,
    invoiceHistory: false
  });

  const handleExport = () => {
    const exportData = {
      format: exportFormat,
      dateRange: dateRange === 'custom' ? { start: startDate, end: endDate } : dateRange,
      fields: includeFields,
      recordCount: data.length
    };
    
    console.log('Exporting financial data:', exportData);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" dir={direction}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-lg bg-white dark:bg-gray-800 rounded-lg shadow-xl">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-3">
              <Download className="h-6 w-6 text-blue-500" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                {t('finance.modal.exportTitle')}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <div className="p-6 space-y-6">
            {/* Export Format */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                {t('finance.modal.exportFormat')}
              </label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { value: 'excel', label: t('finance.modal.excel'), desc: t('finance.modal.excelDesc') },
                  { value: 'csv', label: t('finance.modal.csv'), desc: t('finance.modal.csvDesc') },
                  { value: 'pdf', label: t('finance.modal.pdf'), desc: t('finance.modal.pdfDesc') }
                ].map((format) => (
                  <button
                    key={format.value}
                    onClick={() => setExportFormat(format.value)}
                    className={cn(
                      "p-3 text-left rtl:text-right border rounded-lg transition-colors",
                      exportFormat === format.value
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                        : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                    )}
                  >
                    <div className="font-medium text-gray-900 dark:text-white">{format.label}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">{format.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Date Range */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                {t('finance.modal.dateRange')}
              </label>
              <Select value={dateRange} onChange={(e) => setDateRange(e.target.value)}>
                <option value="all">{t('finance.modal.allTime')}</option>
                <option value="today">{t('finance.modal.today')}</option>
                <option value="week">{t('finance.reports.thisWeek')}</option>
                <option value="month">{t('finance.reports.thisMonth')}</option>
                <option value="quarter">{t('finance.reports.thisQuarter')}</option>
                <option value="year">{t('finance.reports.thisYear')}</option>
                <option value="custom">{t('finance.reports.customRange')}</option>
              </Select>
              
              {dateRange === 'custom' && (
                <div className="grid grid-cols-2 gap-3 mt-3">
                  <Input
                    type="date"
                    label={t('finance.modal.startDate')}
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                  <Input
                    type="date"
                    label={t('finance.modal.endDate')}
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                  />
                </div>
              )}
            </div>

            {/* Include Fields */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                {t('finance.modal.includeFields')}
              </label>
              <div className="space-y-2">
                {[
                  { key: 'basicInfo', label: t('finance.modal.field.basic'), desc: t('finance.modal.field.basicDesc') },
                  { key: 'paymentDetails', label: t('finance.modal.field.payment'), desc: t('finance.modal.field.paymentDesc') },
                  { key: 'supplierInfo', label: t('finance.modal.field.supplier'), desc: t('finance.modal.field.supplierDesc') },
                  { key: 'profitAnalysis', label: t('finance.modal.field.profit'), desc: t('finance.modal.field.profitDesc') },
                  { key: 'invoiceHistory', label: t('finance.modal.field.invoice'), desc: t('finance.modal.field.invoiceDesc') }
                ].map((field) => (
                  <label key={field.key} className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      checked={includeFields[field.key as keyof typeof includeFields]}
                      onChange={(e) => setIncludeFields(prev => ({
                        ...prev,
                        [field.key]: e.target.checked
                      }))}
                      className="mt-1 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <div>
                      <div className="text-sm font-medium text-gray-900 dark:text-white">
                        {field.label}
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        {field.desc}
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Export Summary */}
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
              <h4 className="text-sm font-medium text-blue-800 dark:text-blue-300 mb-2">
                {t('finance.modal.exportSummary')}
              </h4>
              <div className="text-sm text-blue-700 dark:text-blue-400 space-y-1">
                <div>{t('finance.modal.exportFormat')}: <span className="bidi-isolate">{exportFormat.toUpperCase()}</span></div>
                <div>{t('finance.modal.dateRange')}: <span className="bidi-isolate">{dateRange === 'custom' ? `${startDate} - ${endDate}` : dateRange}</span></div>
                <div>{t('finance.modal.records')}: <span className="bidi-isolate">{t('finance.modal.bookingsCount', { count: data.length })}</span></div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700">
            <Button variant="outline" onClick={onClose}>
              {t('common.cancel')}
            </Button>
            <Button onClick={handleExport}>
              <Download className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
              {t('finance.action.exportData')}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};