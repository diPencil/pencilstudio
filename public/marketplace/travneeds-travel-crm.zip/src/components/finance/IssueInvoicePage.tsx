import React, { useState } from 'react';
import { Save, FileText, Send, Download, ArrowLeft } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { formatCurrency } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { FinanceBooking } from './FinancePage';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';

export interface InvoiceFormData {
  template: string;
  amount: number;
  dueDate: string;
  paymentTerms: string;
  notes: string;
  sendImmediately: boolean;
  bookingId: string;
  issueDate: string;
  invoiceNumber: string;
  customer: string;
}

const invoiceTemplates = [
  { value: 'Standard Invoice', labelKey: 'finance.modal.template.standard' },
  { value: 'Corporate Invoice', labelKey: 'finance.modal.template.corporate' },
  { value: 'Proforma Invoice', labelKey: 'finance.modal.template.proforma' },
  { value: 'Credit Note', labelKey: 'finance.modal.template.creditNote' },
  { value: 'Deposit Invoice', labelKey: 'finance.modal.template.deposit' }
] as const;

const paymentTerms = [
  { value: '7 days', labelKey: 'finance.modal.term.7days' },
  { value: '14 days', labelKey: 'finance.modal.term.14days' },
  { value: '30 days', labelKey: 'finance.modal.term.30days' },
  { value: '45 days', labelKey: 'finance.modal.term.45days' },
  { value: 'Due on receipt', labelKey: 'finance.modal.term.dueOnReceipt' },
  { value: 'Net 30', labelKey: 'finance.modal.term.net30' }
] as const;

export const IssueInvoicePage: React.FC = () => {
  const { t, direction, isRTL } = useLocale();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToastContext();
  const booking = location.state?.booking as FinanceBooking | null;

  const [formData, setFormData] = useState({
    template: 'Standard Invoice',
    amount: '',
    dueDate: '',
    paymentTerms: '14 days',
    notes: '',
    sendImmediately: true
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  React.useEffect(() => {
    if (booking) {
      const dueDate = new Date();
      dueDate.setDate(dueDate.getDate() + 14);
      
      setFormData(prev => ({
        ...prev,
        amount: booking.outstandingBalance.toString(),
        dueDate: dueDate.toISOString().split('T')[0]
      }));
    }
  }, [booking]);

  if (!booking) {
    return (
      <div className="w-full pb-8 pt-8 flex justify-center">
        <Button onClick={() => navigate('/finance')}>{t('common.back') || 'Back to Finance'}</Button>
      </div>
    );
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.amount.trim()) {
      newErrors.amount = t('finance.modal.errAmount');
    } else if (isNaN(Number(formData.amount)) || Number(formData.amount) <= 0) {
      newErrors.amount = t('finance.modal.errAmountValid');
    }

    if (!formData.dueDate) {
      newErrors.dueDate = t('finance.modal.errDueDate');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    try {
      toast.success(
        isRTL ? 'تم إصدار الفاتورة' : 'Invoice Issued',
        isRTL ? 'تم إنشاء الفاتورة بنجاح' : 'Invoice generated successfully'
      );
      navigate('/finance');
    } catch (error) {
      console.error('Error issuing invoice:', error);
      toast.error(t('common.error'), 'Failed to issue invoice.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (typeof value === 'string' && errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handlePreview = () => {
    if (booking) {
      console.log('Previewing invoice for booking:', booking.id);
    }
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate('/finance')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                {t('finance.modal.issueInvoiceTitle')} - <span className="ltr-value bidi-isolate">{booking.id}</span>
              </h1>
              <p className="mt-1 text-sm text-blue-100 opacity-90">
                 {booking.customer}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-8 shadow-sm">
          {/* Booking Info */}
          <div className="bg-purple-50 dark:bg-purple-900/20 rounded-xl p-4 mb-6">
            <h4 className="text-sm font-medium text-purple-800 dark:text-purple-300 mb-2">
              {t('finance.modal.bookingInfo')}
            </h4>
            <div className="text-sm text-purple-700 dark:text-purple-400">
              <p><strong>{t('finance.table.customer')}:</strong> {booking.customer}</p>
              <p><strong>{t('finance.modal.service')}:</strong> {booking.tripItem}</p>
              <p>
                <strong>{t('finance.modal.totalBookingAmt')}:</strong>{' '}
                <span className="ltr-value bidi-isolate">{formatCurrency(booking.totalAmount)}</span>
              </p>
              <p>
                <strong>{t('finance.modal.remainingOutstanding')}:</strong>{' '}
                <span className="ltr-value bidi-isolate">{formatCurrency(booking.outstandingBalance)}</span>
              </p>
            </div>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Select
                label={t('finance.modal.invoiceTemplate')}
                value={formData.template}
                onChange={(e) => handleInputChange('template', e.target.value)}
              >
                {invoiceTemplates.map(template => (
                  <option key={template.value} value={template.value}>
                    {t(template.labelKey)}
                  </option>
                ))}
              </Select>

              <Input
                label={t('finance.modal.invoiceAmount')}
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={(e) => handleInputChange('amount', e.target.value)}
                error={errors.amount}
                placeholder={t('finance.modal.invoiceAmount')}
              />

              <Input
                label={t('finance.modal.invoiceDueDate')}
                type="date"
                value={formData.dueDate}
                onChange={(e) => handleInputChange('dueDate', e.target.value)}
                error={errors.dueDate}
                min={new Date().toISOString().split('T')[0]}
              />

              <Select
                label={t('finance.modal.paymentTerms')}
                value={formData.paymentTerms}
                onChange={(e) => handleInputChange('paymentTerms', e.target.value)}
              >
                {paymentTerms.map(term => (
                  <option key={term.value} value={term.value}>
                    {t(term.labelKey)}
                  </option>
                ))}
              </Select>
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('finance.modal.invoiceNotes')}
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                rows={4}
                className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder={t('finance.modal.notesPlaceholder')}
              />
            </div>

            <div className="mt-6">
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={formData.sendImmediately}
                  onChange={(e) => handleInputChange('sendImmediately', e.target.checked)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">
                  {t('finance.modal.sendImmediately')}
                </span>
              </label>
            </div>

            <div className="flex justify-between mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
              <Button
                type="button"
                variant="outline"
                onClick={handlePreview}
              >
                <Download className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                {t('common.preview')}
              </Button>
              
              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate('/finance')}
                  disabled={isLoading}
                >
                  {t('common.cancel')}
                </Button>
                <Button
                  type="submit"
                  disabled={isLoading}
                  loading={isLoading}
                >
                  {formData.sendImmediately ? (
                    <>
                      <Send className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                      {t('finance.action.issueAndSend')}
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                      {t('finance.action.issueInvoiceOnly')}
                    </>
                  )}
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
