import React, { useState } from 'react';
import { X, Send, MessageSquare } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { formatDate } from '../../utils/format';
import { FinanceBooking } from './FinancePage';
import { useLocale } from '../../localization/useLocale';

interface InternalChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  booking: FinanceBooking | null;
}

const departments = ['Sales', 'Reservation', 'Operations', 'Finance'];

const mockChatHistory = [
  {
    id: 1,
    message: 'Customer has requested to change check-in date. Can we accommodate?',
    sender: 'Super Admin',
    department: 'Sales',
    timestamp: '2025-01-15T10:30:00Z',
    type: 'message'
  },
  {
    id: 2,
    message: 'Checking with supplier for availability on new dates.',
    sender: 'Mahmoud Khalil',
    department: 'Reservation',
    timestamp: '2025-01-15T11:15:00Z',
    type: 'message'
  },
  {
    id: 3,
    message: 'Supplier confirmed availability. Additional cost of $50 per night.',
    sender: 'Mahmoud Khalil',
    department: 'Reservation',
    timestamp: '2025-01-15T14:20:00Z',
    type: 'update'
  },
  {
    id: 4,
    message: 'Customer agreed to additional cost. Please update invoice.',
    sender: 'Super Admin',
    department: 'Sales',
    timestamp: '2025-01-15T15:45:00Z',
    type: 'message'
  }
];

export const InternalChatModal: React.FC<InternalChatModalProps> = ({ 
  isOpen, 
  onClose, 
  booking 
}) => {
  const { t, direction } = useLocale();
  const [newMessage, setNewMessage] = useState('');
  const [targetDepartment, setTargetDepartment] = useState('Sales');
  const [messageType, setMessageType] = useState<'message' | 'update' | 'alert'>('message');

  const handleSendMessage = () => {
    if (!newMessage.trim() || !booking) return;

    const message = {
      message: newMessage,
      sender: 'Current User',
      department: 'Finance',
      targetDepartment: targetDepartment,
      type: messageType,
      timestamp: new Date().toISOString(),
      bookingId: booking.id
    };

    console.log('Sending internal message:', message);
    setNewMessage('');
  };

  const getMessageTypeColor = (type: string) => {
    switch (type) {
      case 'update': return 'bg-blue-50 dark:bg-blue-900/20 border-l-4 rtl:border-l-0 rtl:border-r-4 border-blue-500';
      case 'alert': return 'bg-red-50 dark:bg-red-900/20 border-l-4 rtl:border-l-0 rtl:border-r-4 border-red-500';
      default: return 'bg-gray-50 dark:bg-gray-700';
    }
  };

  const getDepartmentColor = (dept: string) => {
    switch (dept) {
      case 'Sales': return 'text-blue-600 dark:text-blue-400';
      case 'Reservation': return 'text-green-600 dark:text-green-400';
      case 'Operations': return 'text-purple-600 dark:text-purple-400';
      case 'Finance': return 'text-orange-600 dark:text-orange-400';
      default: return 'text-gray-600 dark:text-gray-400';
    }
  };

  const getLocalizedDeptName = (deptName: string): string => {
    switch (deptName) {
      case 'Sales': return t('common.sales');
      case 'Reservation': return t('common.reservations');
      case 'Finance': return t('common.finance');
      case 'Operations': return t('common.operations');
      default: return deptName;
    }
  };

  const getLocalizedMsgType = (type: string): string => {
    switch (type) {
      case 'message': return t('finance.modal.msgType.message');
      case 'update': return t('finance.modal.msgType.update');
      case 'alert': return t('finance.modal.msgType.alert');
      default: return type;
    }
  };

  if (!isOpen || !booking) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" dir={direction}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-3xl bg-white dark:bg-gray-800 rounded-lg shadow-xl max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-3">
              <MessageSquare className="h-6 w-6 text-green-500" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                {t('finance.action.internalChat')} - <span className="bidi-isolate">{booking.id}</span>
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <div className="p-6">
            {/* Booking Info */}
            <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 mb-6">
              <h4 className="text-sm font-medium text-green-800 dark:text-green-300 mb-2">
                {t('reservations.modal.resInfoTitle')}
              </h4>
              <div className="text-sm text-green-700 dark:text-green-400 space-y-1">
                <p><strong>{t('reservations.modal.resInfoCustomer')}:</strong> {booking.customer}</p>
                <p><strong>{t('reservations.modal.resInfoService')}:</strong> {booking.tripItem}</p>
                <p><strong>{t('reservations.modal.resInfoStatus')}:</strong> {booking.paymentStatus}</p>
                <p><strong>{t('finance.modal.remainingOutstanding')}:</strong> <span className="bidi-isolate">${booking.outstandingBalance}</span></p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Chat History */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  {t('reservations.modal.commHistory')}
                </h3>
                <div className="space-y-4 max-h-80 overflow-y-auto">
                  {mockChatHistory.map((chat) => (
                    <div key={chat.id} className={`p-4 rounded-lg ${getMessageTypeColor(chat.type)}`}>
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`text-sm font-medium ${getDepartmentColor(chat.department)}`}>
                            {chat.sender === 'Super Admin' ? t('app.superAdmin') : chat.sender}
                          </span>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            ({getLocalizedDeptName(chat.department)})
                          </span>
                          <span className="inline-flex px-1.5 py-0.5 text-[10px] font-semibold rounded-full bg-white/50 dark:bg-black/20">
                            {getLocalizedMsgType(chat.type)}
                          </span>
                        </div>
                        <div className="text-xs text-gray-500 dark:text-gray-400 bidi-isolate">
                          {formatDate(chat.timestamp)}
                        </div>
                      </div>
                      <p className="text-gray-700 dark:text-gray-300">{chat.message}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Send New Message */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  {t('reservations.modal.addNewComm')}
                </h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <Select
                      label={t('finance.modal.department')}
                      value={targetDepartment}
                      onChange={(e) => setTargetDepartment(e.target.value)}
                    >
                      {departments.filter(dept => dept !== 'Finance').map(dept => (
                        <option key={dept} value={dept}>{getLocalizedDeptName(dept)}</option>
                      ))}
                    </Select>

                    <Select
                      label={t('finance.modal.messageType')}
                      value={messageType}
                      onChange={(e) => setMessageType(e.target.value as 'message' | 'update' | 'alert')}
                    >
                      <option value="message">{t('finance.modal.msgType.message')}</option>
                      <option value="update">{t('finance.modal.msgType.update')}</option>
                      <option value="alert">{t('finance.modal.msgType.alert')}</option>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      {t('reservations.modal.taskDescription')}
                    </label>
                    <textarea
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      rows={6}
                      className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder={t('finance.modal.typePlaceholder')}
                    />
                  </div>

                  <Button 
                    onClick={handleSendMessage}
                    disabled={!newMessage.trim()}
                    className="w-full"
                  >
                    <Send className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                    {t('finance.modal.chatToDept', { dept: getLocalizedDeptName(targetDepartment) })}
                  </Button>
                </div>

                {/* Quick Templates */}
                <div className="mt-6">
                  <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                    {t('common.dashboard') === 'Dashboard' ? 'Quick Templates' : 'النماذج السريعة'}
                  </h4>
                  <div className="space-y-2">
                    <button
                      onClick={() => setNewMessage('Payment reminder sent to customer. Please follow up if no response within 3 days.')}
                      className="w-full text-left rtl:text-right text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 p-2 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20"
                    >
                      • {t('common.dashboard') === 'Dashboard' ? 'Payment reminder template' : 'نموذج تذكير بالدفع'}
                    </button>
                    <button
                      onClick={() => setNewMessage('Invoice has been issued and sent to customer. Payment due in 14 days.')}
                      className="w-full text-left rtl:text-right text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 p-2 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20"
                    >
                      • {t('common.dashboard') === 'Dashboard' ? 'Invoice issued notification' : 'إشعار بإصدار الفاتورة'}
                    </button>
                    <button
                      onClick={() => setNewMessage('Payment received and processed. Booking is now fully paid.')}
                      className="w-full text-left rtl:text-right text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 p-2 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20"
                    >
                      • {t('common.dashboard') === 'Dashboard' ? 'Payment confirmation' : 'تأكيد استلام الدفعة'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700">
            <Button variant="outline" onClick={onClose}>
              {t('common.close')}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};