import React, { useState } from 'react';
import { X, TrendingUp, Download, Calendar, DollarSign, PieChart, BarChart3 } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { Input } from '../ui/Input';
import { formatCurrency, formatDate } from '../../utils/format';
import ReactApexChart from 'react-apexcharts';
import { ApexOptions } from 'apexcharts';
import { ResponsiveContainer, PieChart as RechartsPieChart, Cell, Pie } from 'recharts';
import { FinanceBooking } from './FinancePage';
import { useLocale } from '../../localization/useLocale';

interface FinancialReportsModalProps {
  isOpen: boolean;
  onClose: () => void;
  financeData: FinanceBooking[];
}

const monthlyRevenueData = [
  { month: 'Oct', revenue: 45000, expenses: 32000, profit: 13000 },
  { month: 'Nov', revenue: 52000, expenses: 38000, profit: 14000 },
  { month: 'Dec', revenue: 48000, expenses: 35000, profit: 13000 },
  { month: 'Jan', revenue: 61000, expenses: 42000, profit: 19000 },
];

const profitByServiceData = [
  { name: 'Hotels', value: 35, color: '#3B82F6' },
  { name: 'Flights', value: 25, color: '#10B981' },
  { name: 'Tours', value: 20, color: '#F59E0B' },
  { name: 'Packages', value: 15, color: '#EF4444' },
  { name: 'Activities', value: 5, color: '#8B5CF6' }
];

const agentPerformanceData = [
  { agent: 'Super Admin', bookings: 24, revenue: 28500, profit: 7125 },
  { agent: 'Mahmoud Khalil', bookings: 18, revenue: 22000, profit: 5500 },
  { agent: 'Layla Ramadan', bookings: 21, revenue: 25200, profit: 6300 },
  { agent: 'Sami Youssef', bookings: 15, revenue: 18000, profit: 4500 },
  { agent: 'Mona Zaki', bookings: 12, revenue: 15800, profit: 3950 }
];

export const FinancialReportsModal: React.FC<FinancialReportsModalProps> = ({
  isOpen,
  onClose,
  financeData
}) => {
  const { t, direction } = useLocale();
  const [reportType, setReportType] = useState('overview');
  const [dateRange, setDateRange] = useState('month');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const handleExportReport = () => {
    const reportData = {
      type: reportType,
      dateRange: dateRange === 'custom' ? { start: startDate, end: endDate } : dateRange,
      data: financeData
    };

    console.log('Exporting financial report:', reportData);
  };

  const totalRevenue = financeData.reduce((sum, b) => sum + b.totalAmount, 0);
  const totalExpenses = financeData.reduce((sum, b) => sum + b.supplierCost, 0);
  const totalProfit = totalRevenue - totalExpenses;
  const profitMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;

  const apexOptions: ApexOptions = {
      chart: {
          type: 'bar',
          toolbar: { show: false },
          fontFamily: 'inherit',
          background: 'transparent',
          stacked: false,
      },
      plotOptions: {
          bar: {
              horizontal: false,
              columnWidth: '55%',
              borderRadius: 4,
          },
      },
      dataLabels: {
          enabled: false
      },
      stroke: {
          show: true,
          width: [0, 0, 4],
          curve: 'smooth'
      },
      xaxis: {
          categories: monthlyRevenueData.map(d => d.month),
          axisBorder: { show: false },
          axisTicks: { show: false },
          labels: { style: { colors: '#64748b', fontSize: '12px', fontWeight: 600 } },
      },
      yaxis: [
          {
              labels: {
                  formatter: (val) => `$${(val / 1000).toFixed(0)}k`,
                  style: { colors: '#64748b', fontSize: '12px', fontWeight: 600 },
              },
          }
      ],
      fill: {
          opacity: [1, 1, 1]
      },
      colors: ['#3B82F6', '#EF4444', '#10B981'],
      grid: { 
          borderColor: '#f1f5f9', 
          strokeDashArray: 4,
          xaxis: { lines: { show: false } },
          yaxis: { lines: { show: true } }
      },
      tooltip: {
          theme: 'light',
          y: {
              formatter: function (val) {
                  return "$" + val.toLocaleString()
              }
          }
      },
      legend: {
          position: 'top',
          horizontalAlign: 'center',
          fontWeight: 600
      }
  };

  const apexSeries = [
      {
          name: t('finance.reports.revenueExpensesChart').split(' ')[0],
          type: 'column',
          data: monthlyRevenueData.map(d => d.revenue)
      },
      {
          name: t('finance.reports.totalExpenses').split(' ')[1],
          type: 'column',
          data: monthlyRevenueData.map(d => d.expenses)
      },
      {
          name: t('finance.reports.netProfit').split(' ')[1],
          type: 'line',
          data: monthlyRevenueData.map(d => d.profit)
      }
  ];

  const getLocalizedCategoryName = (name: string): string => {
    switch (name) {
      case 'Hotels': return t('finance.reports.category.hotels');
      case 'Flights': return t('finance.reports.category.flights');
      case 'Tours': return t('finance.reports.category.tours');
      case 'Packages': return t('finance.reports.category.packages');
      case 'Activities': return t('finance.reports.category.activities');
      default: return name;
    }
  };

  const getLocalizedAgentName = (agent: string): string => {
    if (agent === 'Super Admin') return t('app.superAdmin');
    return agent;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" dir={direction}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-7xl bg-white dark:bg-gray-800 rounded-lg shadow-xl max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-3">
              <TrendingUp className="h-6 w-6 text-blue-500" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                {t('finance.reports.title')}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <div className="p-6">
            {/* Report Controls */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
              <div className="flex items-center gap-4">
                <Select
                  value={reportType}
                  onChange={(e) => setReportType(e.target.value)}
                >
                  <option value="overview">{t('finance.reports.overview')}</option>
                  <option value="profit">{t('finance.reports.profitAnalysis')}</option>
                  <option value="agent">{t('finance.reports.agentPerformance')}</option>
                  <option value="outstanding">{t('finance.reports.outstandingBalances')}</option>
                </Select>

                <Select
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value)}
                >
                  <option value="week">{t('finance.reports.thisWeek')}</option>
                  <option value="month">{t('finance.reports.thisMonth')}</option>
                  <option value="quarter">{t('finance.reports.thisQuarter')}</option>
                  <option value="year">{t('finance.reports.thisYear')}</option>
                  <option value="custom">{t('finance.reports.customRange')}</option>
                </Select>

                {dateRange === 'custom' && (
                  <div className="flex gap-2">
                    <Input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-auto"
                    />
                    <Input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="w-auto"
                    />
                  </div>
                )}
              </div>

              <Button onClick={handleExportReport} className="mt-4 sm:mt-0">
                <Download className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                {t('finance.action.exportData')}
              </Button>
            </div>

            {/* Financial Overview */}
            {reportType === 'overview' && (
              <div className="space-y-6">
                {/* Summary Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-green-600 dark:text-green-400">{t('finance.reports.totalRevenue')}</p>
                        <p className="text-2xl font-bold text-green-800 dark:text-green-300 bidi-isolate">
                          {formatCurrency(totalRevenue)}
                        </p>
                      </div>
                      <DollarSign className="h-8 w-8 text-green-500" />
                    </div>
                  </div>

                  <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-red-600 dark:text-red-400">{t('finance.reports.totalExpenses')}</p>
                        <p className="text-2xl font-bold text-red-800 dark:text-red-300 bidi-isolate">
                          {formatCurrency(totalExpenses)}
                        </p>
                      </div>
                      <TrendingUp className="h-8 w-8 text-red-500" />
                    </div>
                  </div>

                  <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-blue-600 dark:text-blue-400">{t('finance.reports.netProfit')}</p>
                        <p className="text-2xl font-bold text-blue-800 dark:text-blue-300 bidi-isolate">
                          {formatCurrency(totalProfit)}
                        </p>
                      </div>
                      <BarChart3 className="h-8 w-8 text-blue-500" />
                    </div>
                  </div>

                  <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-purple-600 dark:text-purple-400">{t('finance.reports.profitMargin')}</p>
                        <p className="text-2xl font-bold text-purple-800 dark:text-purple-300 bidi-isolate">
                          {profitMargin.toFixed(1)}%
                        </p>
                      </div>
                      <PieChart className="h-8 w-8 text-purple-500" />
                    </div>
                  </div>
                </div>

                {/* Revenue Chart */}
                <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    {t('finance.reports.revenueExpensesChart')}
                  </h3>
                  <div className="w-full" style={{ height: '300px' }}>
                    <ReactApexChart options={apexOptions} series={apexSeries} type="line" height={300} />
                  </div>
                </div>
              </div>
            )}

            {/* Profit Analysis */}
            {reportType === 'profit' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    {t('finance.reports.profitServiceChart')}
                  </h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <RechartsPieChart>
                      <Tooltip formatter={(value) => `${value}%`} contentStyle={{ textAlign: direction === 'rtl' ? 'right' : 'left' }} />
                      <Pie
                        data={profitByServiceData}
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {profitByServiceData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>

                <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    {t('finance.reports.profitServiceChart')}
                  </h3>
                  <div className="space-y-4">
                    {profitByServiceData.map((item) => (
                      <div key={item.name} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: item.color }}
                          />
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            {getLocalizedCategoryName(item.name)}
                          </span>
                        </div>
                        <span className="text-sm font-medium text-gray-900 dark:text-white bidi-isolate">{item.value}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Agent Performance */}
            {reportType === 'agent' && (
              <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  {t('finance.reports.agentPerformance')}
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left rtl:text-right">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                      <tr>
                        <th className="px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('finance.reports.agent.name')}
                        </th>
                        <th className="px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('finance.reports.agent.bookings')}
                        </th>
                        <th className="px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('finance.reports.agent.revenue')}
                        </th>
                        <th className="px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('finance.reports.agent.profit')}
                        </th>
                        <th className="px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('finance.reports.profitMargin').split(' ')[0]}
                        </th>
                        <th className="px-6 py-3 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('finance.reports.profitMargin').split(' ')[1]}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                      {agentPerformanceData.map((agent) => (
                        <tr key={agent.agent} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                            {getLocalizedAgentName(agent.agent)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white bidi-isolate">
                            {agent.bookings}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white bidi-isolate">
                            {formatCurrency(agent.revenue)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-green-600 dark:text-green-400 bidi-isolate">
                            {formatCurrency(agent.profit)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white bidi-isolate">
                            {formatCurrency(agent.revenue / agent.bookings)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-blue-600 dark:text-blue-400 bidi-isolate">
                            {((agent.profit / agent.revenue) * 100).toFixed(1)}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Outstanding Balances */}
            {reportType === 'outstanding' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-red-600 dark:text-red-400">{t('finance.status.overdue')}</p>
                        <p className="text-2xl font-bold text-red-800 dark:text-red-300 bidi-isolate">
                          {formatCurrency(financeData.filter(b => b.paymentStatus === 'Overdue').reduce((sum, b) => sum + b.outstandingBalance, 0))}
                        </p>
                      </div>
                      <Calendar className="h-8 w-8 text-red-500" />
                    </div>
                  </div>

                  <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-yellow-600 dark:text-yellow-400">{t('finance.reports.outstandingBalances').split(' ')[0]}</p>
                        <p className="text-2xl font-bold text-yellow-800 dark:text-yellow-300 bidi-isolate">
                          {formatCurrency(financeData.filter(b => b.outstandingBalance > 0 && b.paymentStatus !== 'Overdue').reduce((sum, b) => sum + b.outstandingBalance, 0))}
                        </p>
                      </div>
                      <DollarSign className="h-8 w-8 text-yellow-500" />
                    </div>
                  </div>

                  <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-blue-600 dark:text-blue-400">{t('finance.reports.netProfit')}</p>
                        <p className="text-2xl font-bold text-blue-800 dark:text-blue-300 bidi-isolate">
                          {((financeData.reduce((sum, b) => sum + b.paidAmount, 0) / totalRevenue) * 100).toFixed(1)}%
                        </p>
                      </div>
                      <TrendingUp className="h-8 w-8 text-blue-500" />
                    </div>
                  </div>
                </div>

                <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                    {t('finance.reports.outstandingBalances')}
                  </h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left rtl:text-right">
                      <thead className="bg-gray-50 dark:bg-gray-700">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                            {t('finance.reports.outstanding.customer')}
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                            {t('finance.reports.outstanding.bookingId')}
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                            {t('finance.reports.outstanding.amount')}
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                            {t('finance.reports.outstanding.dueDate')}
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                            {t('finance.reports.outstanding.action')}
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                        {financeData.filter(b => b.outstandingBalance > 0).map((booking) => {
                          const daysOverdue = Math.max(0, Math.floor((new Date().getTime() - new Date(booking.dueDate).getTime()) / (1000 * 60 * 60 * 24)));
                          return (
                            <tr key={booking.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                                {booking.customer}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white bidi-isolate">
                                {booking.id}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-red-600 dark:text-red-400 bidi-isolate">
                                {formatCurrency(booking.outstandingBalance)}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400 bidi-isolate">
                                {formatDate(booking.dueDate)}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                {daysOverdue > 0 ? (
                                  <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300 bidi-isolate">
                                    {daysOverdue} {t('common.none') === 'none' ? 'days' : 'أيام'}
                                  </span>
                                ) : (
                                  <span className="text-sm text-gray-500 dark:text-gray-400">-</span>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-end mt-6">
              <Button variant="outline" onClick={onClose}>
                {t('common.close')}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};