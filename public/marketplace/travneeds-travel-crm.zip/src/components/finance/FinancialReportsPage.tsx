import React, { useState } from 'react';
import { TrendingUp, Download, DollarSign, PieChart, BarChart3, ArrowLeft } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { Input } from '../ui/Input';
import { Card, CardContent } from '../ui/Card';
import { StatCard } from '../ui/StatCard';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { formatCurrency } from '../../utils/format';
import ReactApexChart from 'react-apexcharts';
import { ApexOptions } from 'apexcharts';
import { ResponsiveContainer, PieChart as RechartsPieChart, Cell, Pie } from 'recharts';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

const monthlyRevenueData = [
    { month: 'Oct', revenue: 45000, expenses: 32000, profit: 13000 },
    { month: 'Nov', revenue: 52000, expenses: 38000, profit: 14000 },
    { month: 'Dec', revenue: 48000, expenses: 35000, profit: 13000 },
    { month: 'Jan', revenue: 61000, expenses: 42000, profit: 19000 },
];

const profitByServiceData = [
    { name: 'Hotels', value: 35, color: '#3B82F6' },
    { name: 'Flights', value: 25, color: '#10B981' },
    { name: 'Tours', value: 20, color: '#F59E0B' },
    { name: 'Packages', value: 15, color: '#EF4444' },
    { name: 'Activities', value: 5, color: '#8B5CF6' }
];

const agentPerformanceData = [
    { agent: 'Super Admin', bookings: 24, revenue: 28500, profit: 7125 },
    { agent: 'Mahmoud Khalil', bookings: 18, revenue: 22000, profit: 5500 },
    { agent: 'Layla Ramadan', bookings: 21, revenue: 25200, profit: 6300 },
    { agent: 'Sami Youssef', bookings: 15, revenue: 18000, profit: 4500 },
    { agent: 'Mona Zaki', bookings: 12, revenue: 15800, profit: 3950 }
];

export const FinancialReportsPage: React.FC = () => {
    const { t, direction } = useLocale();
    const isRTL = direction === 'rtl';
    const navigate = useNavigate();
    const toast = useToastContext();
    const [reportType, setReportType] = useState('overview');
    const [dateRange, setDateRange] = useState('month');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');

    const totalRevenue = 206000; // Static mock for page
    const totalExpenses = 147000;
    const totalProfit = totalRevenue - totalExpenses;
    const profitMargin = (totalProfit / totalRevenue) * 100;

    const getLocalizedCategoryName = (name: string): string => {
        switch (name) {
            case 'Hotels': return t('finance.reports.category.hotels');
            case 'Flights': return t('finance.reports.category.flights');
            case 'Tours': return t('finance.reports.category.tours');
            case 'Packages': return t('finance.reports.category.packages');
            case 'Activities': return t('finance.reports.category.activities');
            default: return name;
        }
    };

    const getLocalizedAgentName = (agent: string): string => {
        if (agent === 'Super Admin') return t('app.superAdmin');
        return agent;
    };

    const apexOptions: ApexOptions = {
        chart: {
            type: 'bar',
            toolbar: { show: false },
            fontFamily: 'inherit',
            background: 'transparent',
            stacked: false,
        },
        plotOptions: {
            bar: {
                horizontal: false,
                columnWidth: '55%',
                borderRadius: 4,
            },
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            show: true,
            width: [0, 0, 4],
            curve: 'smooth'
        },
        xaxis: {
            categories: monthlyRevenueData.map(d => d.month),
            axisBorder: { show: false },
            axisTicks: { show: false },
            labels: { style: { colors: '#64748b', fontSize: '12px', fontWeight: 600 } },
        },
        yaxis: [
            {
                labels: {
                    formatter: (val) => `$${(val / 1000).toFixed(0)}k`,
                    style: { colors: '#64748b', fontSize: '12px', fontWeight: 600 },
                },
            }
        ],
        fill: {
            opacity: [1, 1, 1]
        },
        colors: ['#3B82F6', '#EF4444', '#10B981'],
        grid: { 
            borderColor: '#f1f5f9', 
            strokeDashArray: 4,
            xaxis: { lines: { show: false } },
            yaxis: { lines: { show: true } }
        },
        tooltip: {
            theme: 'light',
            y: {
                formatter: function (val) {
                    return "$" + val.toLocaleString()
                }
            }
        },
        legend: {
            position: 'top',
            horizontalAlign: 'center',
            fontWeight: 600
        }
    };

    const apexSeries = [
        {
            name: t('finance.reports.revenueExpensesChart').split(' ')[0],
            type: 'column',
            data: monthlyRevenueData.map(d => d.revenue)
        },
        {
            name: t('finance.reports.totalExpenses').split(' ')[1],
            type: 'column',
            data: monthlyRevenueData.map(d => d.expenses)
        },
        {
            name: t('finance.reports.netProfit').split(' ')[1],
            type: 'line',
            data: monthlyRevenueData.map(d => d.profit)
        }
    ];

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
                    <div className={cn("flex items-center gap-2 sm:gap-4 banner-actions", isRTL && "flex-row-reverse")}>
                        <Button variant="outline" onClick={() => navigate('/finance')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                            <ArrowLeft size={20} className={isRTL ? 'rtl-flip' : ''} />
                        </Button>
                        <div className={cn(isRTL ? "text-right" : "text-left")}>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                                {t('finance.reports.title')}
                            </h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">
                                {t('finance.reports.subtitle')}
                            </p>
                        </div>
                    </div>
                </div>
            <Card>
                <CardContent className="p-6">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8 space-y-4 sm:space-y-0">
                        <div className="flex flex-wrap items-center gap-4">
                            <Select
                                value={reportType}
                                onChange={(e) => setReportType(e.target.value)}
                                className="w-56"
                            >
                                <option value="overview">{t('finance.reports.overview')}</option>
                                <option value="profit">{t('finance.reports.profitAnalysis')}</option>
                                <option value="agent">{t('finance.reports.agentPerformance')}</option>
                            </Select>

                            <Select
                                value={dateRange}
                                onChange={(e) => setDateRange(e.target.value)}
                                className="w-48"
                            >
                                <option value="week">{t('finance.reports.thisWeek')}</option>
                                <option value="month">{t('finance.reports.thisMonth')}</option>
                                <option value="quarter">{t('finance.reports.thisQuarter')}</option>
                                <option value="year">{t('finance.reports.thisYear')}</option>
                                <option value="custom">{t('finance.reports.customRange')}</option>
                            </Select>

                            {dateRange === 'custom' && (
                                <div className="flex items-center gap-2">
                                    <Input
                                        type="date"
                                        value={startDate}
                                        onChange={(e) => setStartDate(e.target.value)}
                                        className="w-40"
                                    />
                                    <span className="text-gray-400">{t('common.none') === 'none' ? 'to' : 'إلى'}</span>
                                    <Input
                                        type="date"
                                        value={endDate}
                                        onChange={(e) => setEndDate(e.target.value)}
                                        className="w-40"
                                    />
                                </div>
                            )}
                        </div>

                        <Button onClick={() => toast.success('Export Started', 'Your financial report export is being prepared and will download shortly.')}>
                            <Download className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                            {t('finance.action.downloadReport')}
                        </Button>
                    </div>

                    {reportType === 'overview' && (
                        <div className="space-y-8">
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                                <StatCard
                                    label={t('finance.reports.totalRevenue')}
                                    value={formatCurrency(totalRevenue)}
                                    icon={DollarSign}
                                    iconColor="text-green-500"
                                    iconBg="bg-green-50 dark:bg-green-900/20"
                                />

                                <StatCard
                                    label={t('finance.reports.totalExpenses')}
                                    value={formatCurrency(totalExpenses)}
                                    icon={TrendingUp}
                                    iconColor="text-red-500"
                                    iconBg="bg-red-50 dark:bg-red-900/20"
                                />

                                <StatCard
                                    label={t('finance.reports.netProfit')}
                                    value={formatCurrency(totalProfit)}
                                    icon={BarChart3}
                                    iconColor="text-blue-500"
                                    iconBg="bg-blue-50 dark:bg-blue-900/20"
                                />

                                <StatCard
                                    label={t('finance.reports.profitMargin')}
                                    value={`${profitMargin.toFixed(1)}%`}
                                    icon={PieChart}
                                    iconColor="text-purple-500"
                                    iconBg="bg-purple-50 dark:bg-purple-900/20"
                                />
                            </div>

                            <div className="bg-gray-50 dark:bg-gray-900/50 rounded-xl p-6 border border-gray-100 dark:border-gray-800">
                                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">
                                    {t('finance.reports.revenueExpensesChart')}
                                </h3>
                                <div className="w-full" style={{ height: '350px' }}>
                                    <ReactApexChart options={apexOptions} series={apexSeries} type="line" height={350} />
                                </div>
                            </div>
                        </div>
                    )}

                    {reportType === 'profit' && (
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <div className="bg-gray-50 dark:bg-gray-900/50 rounded-xl p-6 border border-gray-100 dark:border-gray-800">
                                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">
                                    {t('finance.reports.profitServiceChart')}
                                </h3>
                                <ResponsiveContainer width="100%" height={300}>
                                    <RechartsPieChart>
                                        <Pie
                                            data={profitByServiceData}
                                            innerRadius={60}
                                            outerRadius={80}
                                            paddingAngle={5}
                                            dataKey="value"
                                        >
                                            {profitByServiceData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={entry.color} />
                                            ))}
                                        </Pie>
                                        <Tooltip contentStyle={{ textAlign: direction === 'rtl' ? 'right' : 'left' }} />
                                    </RechartsPieChart>
                                </ResponsiveContainer>
                            </div>

                            <div className="space-y-4">
                                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                                    {t('finance.reports.profitServiceChart')}
                                </h3>
                                {profitByServiceData.map((item) => (
                                    <div key={item.name} className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-100 dark:border-gray-700 shadow-sm">
                                        <div className="flex items-center gap-3">
                                            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                                            <span className="font-medium text-gray-700 dark:text-gray-300">
                                                {getLocalizedCategoryName(item.name)}
                                            </span>
                                        </div>
                                        <span className="font-bold text-gray-900 dark:text-white bidi-isolate">{item.value}%</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {reportType === 'agent' && (
                        <div className="overflow-hidden border border-gray-100 dark:border-gray-700 rounded-xl shadow-sm">
                            <table className="w-full text-left rtl:text-right">
                                <thead className="bg-gray-50 dark:bg-gray-800">
                                    <tr>
                                        <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase">{t('finance.reports.agent.name')}</th>
                                        <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase">{t('finance.reports.agent.bookings')}</th>
                                        <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase">{t('finance.reports.agent.revenue')}</th>
                                        <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase">{t('finance.reports.agent.profit')}</th>
                                        <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase text-right rtl:text-left">{t('finance.reports.profitMargin').split(' ')[1]}</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                                    {agentPerformanceData.map((agent) => (
                                        <tr key={agent.agent} className="hover:bg-gray-50 dark:hover:bg-gray-900/50 transition-colors">
                                            <td className="px-6 py-4 font-semibold text-gray-900 dark:text-white">
                                                {getLocalizedAgentName(agent.agent)}
                                            </td>
                                            <td className="px-6 py-4 text-gray-600 dark:text-gray-400 bidi-isolate">{agent.bookings}</td>
                                            <td className="px-6 py-4 font-medium bidi-isolate">{formatCurrency(agent.revenue)}</td>
                                            <td className="px-6 py-4 text-green-600 font-bold bidi-isolate">{formatCurrency(agent.profit)}</td>
                                            <td className="px-6 py-4 text-right rtl:text-left">
                                                <span className="bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 px-2.5 py-1 rounded text-xs font-bold bidi-isolate">
                                                    {((agent.profit / agent.revenue) * 100).toFixed(1)}%
                                                </span>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </CardContent>
            </Card>
            </div>
        </div>
    );
};
