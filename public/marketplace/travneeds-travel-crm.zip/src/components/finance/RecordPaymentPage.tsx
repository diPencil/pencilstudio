import React, { useState } from 'react';
import { Save, DollarSign, Upload, ArrowLeft } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { formatCurrency } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { FinanceBooking } from './FinancePage';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';
import { mockFinance } from '../../services/mockData';

export interface PaymentFormData {
  bookingId: string;
  amount: number;
  paymentMethod: string;
  date: string;
  reference: string;
  notes: string;
  receiptFile: File | null;
  timestamp: string;
  processedBy: string;
}

const paymentMethods = ['Cash', 'Credit Card', 'Bank Transfer', 'Check', 'Online Payment', 'Wire Transfer'] as const;

export const RecordPaymentPage: React.FC = () => {
  const { t, isRTL, direction } = useLocale();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToastContext();
  
  // Try to get bookings from location state, or fallback to mock
  const bookings = (location.state?.bookings as FinanceBooking[]) || (mockFinance as FinanceBooking[]);

  const [formData, setFormData] = useState({
    bookingId: '',
    amount: '',
    paymentMethod: 'Bank Transfer' as typeof paymentMethods[number],
    date: new Date().toISOString().split('T')[0],
    reference: '',
    notes: ''
  });
  
  const [receiptFile, setReceiptFile] = useState<File | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  const selectedBooking = bookings.find(b => b.id === formData.bookingId);

  const getLocalizedPaymentMethod = (method: string): string => {
    switch (method) {
      case 'Cash': return t('finance.record.method.cash');
      case 'Credit Card': return t('finance.record.method.creditCard');
      case 'Bank Transfer': return t('finance.record.method.bankTransfer');
      case 'Check': return t('finance.record.method.check');
      case 'Online Payment': return t('finance.record.method.onlinePayment');
      case 'Wire Transfer': return t('finance.record.method.wireTransfer');
      default: return method;
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.bookingId) {
      newErrors.bookingId = t('finance.record.errorBooking');
    }

    if (!formData.amount.trim()) {
      newErrors.amount = t('finance.record.errorAmount');
    } else if (isNaN(Number(formData.amount)) || Number(formData.amount) <= 0) {
      newErrors.amount = t('finance.record.errorAmountValid');
    } else if (selectedBooking && Number(formData.amount) > selectedBooking.outstandingBalance) {
      newErrors.amount = t('finance.record.errorAmountExceeds').replace('{balance}', formatCurrency(selectedBooking.outstandingBalance));
    }

    if (!formData.date) {
      newErrors.date = t('finance.record.errorDate');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    try {
      toast.success(
        isRTL ? 'تم تسجيل الدفعة' : 'Payment Recorded',
        isRTL ? `تم استلام ${formatCurrency(Number(formData.amount))} للحجز #${formData.bookingId}` : `Received ${formatCurrency(Number(formData.amount))} for booking #${formData.bookingId}`
      );
      navigate('/finance');
    } catch (error) {
      console.error('Error recording payment:', error);
      toast.error(t('common.error'), 'Failed to record payment.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setReceiptFile(file);
    }
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate('/finance')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
                <DollarSign className="h-8 w-8 text-green-300" />
                {t('finance.action.recordPayment')}
              </h1>
              <p className="mt-1 text-sm text-blue-100 opacity-90">
                 {t('finance.record.subtitle') || 'Record a new payment transaction'}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-sm p-6 sm:p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <Select
                  label={t('finance.record.selectBooking')}
                  value={formData.bookingId}
                  onChange={(e) => handleInputChange('bookingId', e.target.value)}
                  error={errors.bookingId}
                >
                  <option value="">{t('finance.record.searchPlaceholder')}</option>
                  {bookings.filter(b => b.outstandingBalance > 0).map(booking => (
                    <option key={booking.id} value={booking.id}>
                      {booking.id} - {booking.customer} ({formatCurrency(booking.outstandingBalance)} {t('finance.table.bal')})
                    </option>
                  ))}
                </Select>
              </div>

              {selectedBooking && (
                <div className="md:col-span-2 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h4 className="text-sm font-medium text-blue-800 dark:text-blue-300 mb-2">
                    {t('finance.modal.bookingInfo')}
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-blue-700 dark:text-blue-400">{t('finance.table.customer')}: </span>
                      <span className="text-blue-800 dark:text-blue-300">{selectedBooking.customer}</span>
                    </div>
                    <div>
                      <span className="text-blue-700 dark:text-blue-400">{t('finance.modal.totalBookingAmt')}: </span>
                      <span className="text-blue-800 dark:text-blue-300 ltr-value bidi-isolate">{formatCurrency(selectedBooking.totalAmount)}</span>
                    </div>
                    <div>
                      <span className="text-blue-700 dark:text-blue-400">{t('finance.record.summaryPaid')}: </span>
                      <span className="text-blue-800 dark:text-blue-300 ltr-value bidi-isolate">{formatCurrency(selectedBooking.paidAmount)}</span>
                    </div>
                    <div>
                      <span className="text-blue-700 dark:text-blue-400">{t('finance.modal.remainingOutstanding')}: </span>
                      <span className="text-blue-800 dark:text-blue-300 font-medium ltr-value bidi-isolate">{formatCurrency(selectedBooking.outstandingBalance)}</span>
                    </div>
                  </div>
                </div>
              )}

              <Input
                label={t('finance.record.paymentAmount')}
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={(e) => handleInputChange('amount', e.target.value)}
                error={errors.amount}
                placeholder={t('finance.record.paymentAmount')}
              />

              <Select
                label={t('finance.record.paymentMethod')}
                value={formData.paymentMethod}
                onChange={(e) => handleInputChange('paymentMethod', e.target.value)}
              >
                {paymentMethods.map(method => (
                  <option key={method} value={method}>{getLocalizedPaymentMethod(method)}</option>
                ))}
              </Select>

              <Input
                label={t('finance.record.paymentDate')}
                type="date"
                value={formData.date}
                onChange={(e) => handleInputChange('date', e.target.value)}
                error={errors.date}
              />

              <Input
                label={t('finance.record.referenceNumber')}
                value={formData.reference}
                onChange={(e) => handleInputChange('reference', e.target.value)}
                placeholder={t('finance.record.referenceNumber')}
              />
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('finance.record.uploadReceipt')}
              </label>
              <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-md hover:border-gray-400 dark:hover:border-gray-500 transition-colors">
                <div className="space-y-1 text-center">
                  <Upload className="mx-auto h-8 w-8 text-gray-400" />
                  <div className="flex text-sm text-gray-600 dark:text-gray-400 gap-1 justify-center">
                    <label htmlFor="receipt-upload" className="relative cursor-pointer bg-white dark:bg-gray-800 rounded-md font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500">
                      <span>{t('finance.record.uploadBtn')}</span>
                      <input
                        id="receipt-upload"
                        name="receipt-upload"
                        type="file"
                        className="sr-only"
                        accept=".pdf,.jpg,.jpeg,.png"
                        onChange={handleFileSelect}
                      />
                    </label>
                    <p className="pl-1 rtl:pl-0 rtl:pr-1">{t('finance.record.dragDrop')}</p>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {t('finance.record.uploadHelper')}
                  </p>
                </div>
              </div>
              
              {receiptFile && (
                <div className="mt-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <p className="text-sm text-green-800 dark:text-green-300">
                    {t('finance.record.selected')}: {receiptFile.name}
                  </p>
                </div>
              )}
            </div>

            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('finance.record.notes')}
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                rows={3}
                className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder={t('finance.record.notesPlaceholder')}
              />
            </div>

            <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate('/finance')}
                disabled={isLoading}
              >
                {t('common.cancel')}
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                loading={isLoading}
              >
                <Save className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                {t('finance.action.recordPayment')}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
