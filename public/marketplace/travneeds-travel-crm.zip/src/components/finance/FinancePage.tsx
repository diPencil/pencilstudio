import React, { useState } from 'react';
import { Plus, Search, Eye, MessageSquare, FileText, DollarSign, CreditCard, AlertTriangle, TrendingUp, Users, Download, PieChart } from 'lucide-react';
import { PageHeader } from '../ui/PageHeader';
import { StatCard } from '../ui/StatCard';
import { StatusBadge, BadgeVariant } from '../ui/StatusBadge';
import { TableActionsDropdown, ActionItem } from '../ui/TableActionsDropdown';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { formatCurrency, formatDate } from '../../utils/format';
import { useNavigate } from 'react-router-dom';
// Modals replaced by page navigation
import { useToastContext } from '../../contexts/ToastContext';
import { mockFinance } from '../../services/mockData';
import { useLocale } from '../../localization/useLocale';
import { pickDirectionalValue } from '../../localization/direction';
import { cn } from '../../utils/cn';

export interface FinanceBooking {
    id: string;
    customer: string;
    tripItem: string;
    totalAmount: number;
    paidAmount: number;
    outstandingBalance: number;
    paymentStatus: string;
    dueDate: string;
    agent: string;
    createdAt: string;
    invoiceStatus: string;
    invoiceDate: string | null;
    supplier: string;
    supplierCost: number;
    profit: number;
    profitMargin: number;
}

export const FinancePage: React.FC = () => {
    const { t, direction, isRTL } = useLocale();
    const navigate = useNavigate();
    const [financeData] = useState<FinanceBooking[]>(mockFinance as FinanceBooking[]);
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('All Status');
    const [agentFilter, setAgentFilter] = useState('All Agents');
    const [supplierFilter] = useState('All Suppliers');

    const [selectedBooking, setSelectedBooking] = useState<FinanceBooking | null>(null);

    const toast = useToastContext();

    const getPaymentStatusVariant = (status: string): BadgeVariant => {
        switch (status) {
            case 'Fully Paid': return 'emerald';
            case 'Deposit Paid': return 'blue';
            case 'Partially Paid': return 'amber';
            case 'Overdue': return 'rose';
            default: return 'gray';
        }
    };

    const getLocalizedPaymentStatus = (status: string): string => {
        switch (status) {
            case 'Fully Paid': return t('finance.status.fullyPaid');
            case 'Deposit Paid': return t('finance.status.depositPaid');
            case 'Partially Paid': return t('finance.status.partiallyPaid');
            case 'Overdue': return t('finance.status.overdue');
            default: return status;
        }
    };

    const getLocalizedInvoiceStatus = (status: string): string => {
        switch (status) {
            case 'Partial': return t('reservations.finance.partial') || status;
            case 'Final': return t('reservations.finance.final') || status;
            default: return status;
        }
    };

    const getLocalizedAgent = (agentName: string): string => {
        if (agentName === 'Super Admin') return t('app.superAdmin');
        return agentName;
    };

    const filteredData = financeData.filter(b => {
        const matchesSearch = b.customer.toLowerCase().includes(searchTerm.toLowerCase()) || b.id.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = statusFilter === 'All Status' || b.paymentStatus === statusFilter;
        const matchesAgent = agentFilter === 'All Agents' || b.agent === agentFilter;
        const matchesSupplier = supplierFilter === 'All Suppliers' || b.supplier === supplierFilter;
        return matchesSearch && matchesStatus && matchesAgent && matchesSupplier;
    });

    const metrics = {
        received: financeData.reduce((sum, b) => sum + b.paidAmount, 0),
        pending: financeData.reduce((sum, b) => sum + b.outstandingBalance, 0),
        profit: financeData.reduce((sum, b) => sum + b.profit, 0),
        payables: financeData.reduce((sum, b) => sum + (b.totalAmount - b.profit - 100), 0),
        overdue: financeData.filter(b => b.paymentStatus === 'Overdue').length
    };

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px]">
                {/* Top Welcome Banner (NeoPay Style) */}
                <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "flex-row-reverse")}>
                    <div className={cn(isRTL ? "text-right" : "text-left")}>
                        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                            {t('finance.title')}
                        </h1>
                        <p className="mt-1 text-sm text-blue-100 opacity-90">
                            {t('finance.subtitle')}
                        </p>
                    </div>
                    
                    <div className={cn("flex items-center gap-2 sm:gap-3 banner-actions", isRTL && "flex-row-reverse")}>
                        <Button variant="outline" className="bg-white/10 text-white border-transparent hover:bg-white/20" onClick={() => navigate('/finance/reports')}>
                            <PieChart className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                            {t('finance.action.reports')}
                        </Button>
                        <Button className="bg-white text-blue-600 hover:bg-gray-50" onClick={() => navigate('/finance/record-payment')}>
                            <Plus className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
                            {t('finance.action.recordPayment')}
                        </Button>
                    </div>
                </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                <StatCard label={t('finance.metrics.cashReceived')} value={formatCurrency(metrics.received)} icon={DollarSign} iconColor="text-emerald-500" iconBg="bg-emerald-50 dark:bg-emerald-900/20" trend={t('finance.metrics.trendUp').replace('{trend}', '4.2%')} trendType="up" />
                <StatCard label={t('finance.metrics.receivables')} value={formatCurrency(metrics.pending)} icon={CreditCard} iconColor="text-amber-500" iconBg="bg-amber-50 dark:bg-amber-900/20" />
                <StatCard label={t('finance.metrics.supplierPayables')} value={formatCurrency(metrics.payables)} icon={Users} iconColor="text-rose-500" iconBg="bg-rose-50 dark:bg-rose-900/20" />
                <StatCard label={t('finance.metrics.netProfit')} value={formatCurrency(metrics.profit)} icon={TrendingUp} iconColor="text-blue-500" iconBg="bg-blue-50 dark:bg-blue-900/20" trend={t('finance.metrics.margin').replace('{margin}', '18.5')} trendType="neutral" />
                <StatCard label={t('finance.metrics.overdueItems')} value={metrics.overdue} icon={AlertTriangle} iconColor="text-rose-500" iconBg="bg-rose-50 dark:bg-rose-900/20" trend={t('finance.metrics.trendAttention')} trendType="down" />
            </div>

            <Card className="card-premium mt-6">
                <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row items-center gap-4">
                        <div className="flex-1 w-full relative">
                            <Search className={cn("absolute top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400", pickDirectionalValue(direction, 'left-3', 'right-3'))} />
                            <Input
                                placeholder={t('finance.filter.searchPlaceholder')}
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className={pickDirectionalValue(direction, 'pl-10', 'pr-10')}
                            />
                        </div>
                        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="w-full md:w-40">
                            <option value="All Status">{t('finance.filter.allStatus')}</option>
                            <option value="Fully Paid">{t('finance.status.fullyPaid')}</option>
                            <option value="Deposit Paid">{t('finance.status.depositPaid')}</option>
                            <option value="Partially Paid">{t('finance.status.partiallyPaid')}</option>
                            <option value="Overdue">{t('finance.status.overdue')}</option>
                        </Select>
                        <Select value={agentFilter} onChange={(e) => setAgentFilter(e.target.value)} className="w-full md:w-40">
                            <option value="All Agents">{t('finance.filter.allAgents')}</option>
                            <option value="Super Admin">{t('app.superAdmin')}</option>
                            <option value="Mahmoud Khalil">Mahmoud Khalil</option>
                            <option value="Layla Ramadan">Layla Ramadan</option>
                        </Select>
                        <Select value={supplierFilter} onChange={(e) => setSupplierFilter(e.target.value)} className="w-full md:w-40">
                            <option value="All Suppliers">{t('finance.filter.allSuppliers')}</option>
                            <option value="Steigenberger Hotels">Steigenberger Hotels</option>
                            <option value="EgyptAir">EgyptAir</option>
                        </Select>
                        <Button variant="outline" className="w-full md:w-auto" onClick={() => toast.success(t('finance.export.title') || 'Export', t('finance.export.success') || 'Data exported successfully.')}>
                            <Download className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                            {t('finance.action.export')}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            <div className="table-container mt-6">
                <table className="table-premium">
                    <thead>
                        <tr>
                            <th>{t('finance.table.bookingId')}</th>
                            <th>{t('finance.table.customer')}</th>
                            <th>{t('finance.table.financialSummary')}</th>
                            <th>{t('finance.table.paymentStatus')}</th>
                            <th>{t('finance.table.invoice')}</th>
                            <th>{t('finance.table.profit')}</th>
                            <th className="text-right rtl:text-left">{t('finance.table.actions')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredData.map((b) => (
                            <tr key={b.id} className={b.paymentStatus === 'Overdue' ? 'bg-rose-50/30 dark:bg-rose-900/5' : ''}>
                                <td>
                                    <div className="font-bold text-gray-900 dark:text-white bidi-isolate">{b.id}</div>
                                    <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest bidi-isolate">{formatDate(b.createdAt)}</div>
                                </td>
                                <td>
                                    <div className="text-sm font-medium">{b.customer}</div>
                                    <div className="text-[10px] text-gray-500">{getLocalizedAgent(b.agent)}</div>
                                </td>
                                <td>
                                    <div className="text-xs font-bold text-gray-900 dark:text-white bidi-isolate">{formatCurrency(b.totalAmount)}</div>
                                    <div className="text-[10px] text-emerald-600">{t('finance.table.paid')}: <span className="bidi-isolate">{formatCurrency(b.paidAmount)}</span></div>
                                    <div className={cn("text-[10px]", b.outstandingBalance > 0 ? "text-rose-500 font-bold" : "text-gray-400")}>
                                        {t('finance.table.bal')}: <span className="bidi-isolate">{formatCurrency(b.outstandingBalance)}</span>
                                    </div>
                                </td>
                                <td>
                                    <StatusBadge variant={getPaymentStatusVariant(b.paymentStatus)}>{getLocalizedPaymentStatus(b.paymentStatus)}</StatusBadge>
                                </td>
                                <td>
                                    <div className="text-xs font-medium">{getLocalizedInvoiceStatus(b.invoiceStatus)}</div>
                                    <div className="text-[10px] text-gray-500 bidi-isolate">{b.invoiceDate ? formatDate(b.invoiceDate) : t('finance.invoice.notIssued')}</div>
                                </td>
                                <td>
                                    <div className="text-xs font-bold text-blue-600 bidi-isolate">{formatCurrency(b.profit)}</div>
                                    <div className="text-[10px] text-gray-500">{t('finance.table.margin')}: <span className="bidi-isolate">{b.profitMargin}%</span></div>
                                </td>
                                <td className="text-right rtl:text-left">
                                    <TableActionsDropdown
                                        actions={[
                                            { label: t('finance.action.viewDetails'), icon: Eye, onClick: () => navigate('/finance/view-payment', { state: { booking: b } }) },
                                            { label: t('finance.action.internalChat') || 'Internal Chat', icon: MessageSquare, onClick: () => toast.info(t('finance.action.internalChat') || 'Internal Chat', 'Chat feature coming soon.') },
                                            { label: t('finance.action.issueClientInvoice'), icon: FileText, onClick: () => navigate('/finance/issue-invoice', { state: { booking: b } }) },
                                            { label: t('finance.action.recordSupplierInvoice'), icon: DollarSign, onClick: () => navigate('/finance/supplier-invoice', { state: { booking: b } }) }
                                        ]}
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* All Finance modals replaced by page navigation */}
            </div>
        </div>
    );
};