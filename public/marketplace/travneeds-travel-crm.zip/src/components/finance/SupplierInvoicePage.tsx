import React, { useState } from 'react';
import { Save, Upload, FileText, DollarSign, CheckCircle, ArrowLeft } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { formatCurrency, formatDate } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { FinanceBooking } from './FinancePage';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';

interface SupplierInvoice {
  id: string;
  supplier: string;
  amount: number;
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  status: string;
  uploadDate: string;
  uploadedBy: string;
  notes?: string;
}

const mockSupplierInvoices: SupplierInvoice[] = [
  {
    id: 'SINV-001',
    supplier: 'Steigenberger Hotels',
    amount: 900,
    invoiceNumber: 'STG-2025-001',
    issueDate: '2025-01-13',
    dueDate: '2025-01-27',
    status: 'Awaiting Approval',
    uploadDate: '2025-01-13',
    uploadedBy: 'Super Admin',
    notes: 'Hotel confirmation for 3 nights'
  }
];

const supplierInvoiceStatuses = [
  { value: 'Awaiting Confirmation', labelKey: 'finance.modal.invoiceStatus.awaitingConf' },
  { value: 'Awaiting Approval', labelKey: 'finance.modal.invoiceStatus.awaitingAppr' },
  { value: 'Approved', labelKey: 'finance.modal.invoiceStatus.approved' },
  { value: 'Paid', labelKey: 'finance.modal.invoiceStatus.paid' },
  { value: 'Overdue', labelKey: 'finance.modal.invoiceStatus.overdue' },
  { value: 'Disputed', labelKey: 'finance.modal.invoiceStatus.disputed' }
] as const;

export const SupplierInvoicePage: React.FC = () => {
  const { t, direction, isRTL } = useLocale();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToastContext();
  const booking = location.state?.booking as FinanceBooking | null;

  const [formData, setFormData] = useState({
    supplier: '',
    amount: '',
    invoiceNumber: '',
    issueDate: '',
    dueDate: '',
    status: 'Awaiting Confirmation',
    notes: ''
  });
  const [invoiceFile, setInvoiceFile] = useState<File | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'existing' | 'new'>('existing');

  React.useEffect(() => {
    if (booking) {
      const dueDate = new Date();
      dueDate.setDate(dueDate.getDate() + 14);
      
      setFormData(prev => ({
        ...prev,
        supplier: booking.supplier || '',
        amount: booking.supplierCost.toString(),
        dueDate: dueDate.toISOString().split('T')[0]
      }));
    }
  }, [booking]);

  if (!booking) {
    return (
      <div className="w-full pb-8 pt-8 flex justify-center">
        <Button onClick={() => navigate('/finance')}>{t('common.back') || 'Back to Finance'}</Button>
      </div>
    );
  }

  const getLocalizedInvoiceStatus = (status: string): string => {
    switch (status) {
      case 'Awaiting Confirmation': return t('finance.modal.invoiceStatus.awaitingConf');
      case 'Awaiting Approval': return t('finance.modal.invoiceStatus.awaitingAppr');
      case 'Approved': return t('finance.modal.invoiceStatus.approved');
      case 'Paid': return t('finance.modal.invoiceStatus.paid');
      case 'Overdue': return t('finance.modal.invoiceStatus.overdue');
      case 'Disputed': return t('finance.modal.invoiceStatus.disputed');
      default: return status;
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.supplier.trim()) {
      newErrors.supplier = t('finance.modal.errSupplier');
    }

    if (!formData.amount.trim()) {
      newErrors.amount = t('finance.modal.errAmount');
    } else if (isNaN(Number(formData.amount)) || Number(formData.amount) <= 0) {
      newErrors.amount = t('finance.modal.errAmountValid');
    }

    if (!formData.invoiceNumber.trim()) {
      newErrors.invoiceNumber = t('finance.modal.errInvoiceNum');
    }

    if (!formData.issueDate) {
      newErrors.issueDate = t('finance.modal.errIssueDate');
    }

    if (!formData.dueDate) {
      newErrors.dueDate = t('finance.modal.errDueDate');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    try {
      toast.success(
        isRTL ? 'تم تسجيل فاتورة المورد' : 'Supplier Invoice Recorded',
        isRTL ? `تم تسجيل فاتورة المورد ${formData.supplier} بنجاح` : `Invoice for ${formData.supplier} recorded successfully`
      );
      navigate('/finance');
    } catch (error) {
      console.error('Error recording supplier invoice:', error);
      toast.error(t('common.error'), 'Failed to record invoice.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setInvoiceFile(file);
    }
  };

  const handleApproveInvoice = (invoiceId: string) => {
    toast.success(isRTL ? 'تم الموافقة' : 'Approved', isRTL ? 'تم الموافقة على الفاتورة' : 'Invoice approved');
  };

  const handlePayInvoice = (invoiceId: string) => {
    toast.success(isRTL ? 'تم الدفع' : 'Paid', isRTL ? 'تم تسجيل الفاتورة كمدفوعة' : 'Invoice marked as paid');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Paid': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'Approved': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      case 'Awaiting Approval': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'Overdue': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      case 'Disputed': return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate('/finance')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                {t('finance.modal.supplierInvoicesTitle')} - <span className="ltr-value bidi-isolate">{booking.id}</span>
              </h1>
              <p className="mt-1 text-sm text-blue-100 opacity-90">
                 {booking.customer}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-8 shadow-sm">
          {/* Tab Navigation */}
          <div className="flex gap-1 mb-6">
            <button
              onClick={() => setActiveTab('existing')}
              className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                activeTab === 'existing'
                  ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300'
                  : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
            >
              {t('finance.modal.existingInvoices')}
            </button>
            <button
              onClick={() => setActiveTab('new')}
              className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                activeTab === 'new'
                  ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300'
                  : 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
              }`}
            >
              {t('finance.modal.recordNewInvoice')}
            </button>
          </div>

          {activeTab === 'existing' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                {t('finance.modal.supplierInvoicesBooking')}
              </h3>
              
              {mockSupplierInvoices.map((invoice) => (
                <div key={invoice.id} className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-orange-50 dark:bg-orange-900/50 rounded-lg">
                        <FileText className="h-5 w-5 text-orange-600 dark:text-orange-400" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">
                          {invoice.supplier}
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {t('finance.table.invoice')}: <span className="ltr-value bidi-isolate">{invoice.invoiceNumber}</span>
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {t('finance.modal.invoice.amount')}: <span className="ltr-value bidi-isolate">{formatCurrency(invoice.amount)}</span>
                        </p>
                        <p className="text-xs text-gray-400">
                          {t('finance.modal.invoice.dueDate')}: <span className="ltr-value bidi-isolate">{formatDate(invoice.dueDate)}</span>
                        </p>
                      </div>
                    </div>
                    <div className="text-right rtl:text-left space-y-2">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(invoice.status)}`}>
                        {getLocalizedInvoiceStatus(invoice.status)}
                      </span>
                      <div className="flex gap-2 justify-end">
                        {invoice.status === 'Awaiting Approval' && (
                          <button
                            onClick={() => handleApproveInvoice(invoice.id)}
                            className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300 p-1 rounded hover:bg-green-50 dark:hover:bg-green-900/20 transition-colors"
                            title={t('finance.modal.invoiceStatus.approved')}
                          >
                            <CheckCircle className="h-4 w-4" />
                          </button>
                        )}
                        {invoice.status === 'Approved' && (
                          <button
                            onClick={() => handlePayInvoice(invoice.id)}
                            className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 p-1 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                            title={t('finance.modal.invoiceStatus.paid')}
                          >
                            <DollarSign className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="mt-3 text-xs text-gray-500 dark:text-gray-400">
                    {t('finance.modal.uploadedBy')
                      .replace('{user}', invoice.uploadedBy)
                      .replace('{date}', formatDate(invoice.uploadDate))}
                  </div>
                  {invoice.notes && (
                    <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                      {invoice.notes}
                    </div>
                  )}
                </div>
              ))}

              {mockSupplierInvoices.length === 0 && (
                <div className="text-center py-8">
                  <FileText className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {t('finance.modal.noSupplierInvoices')}
                  </p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'new' && (
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Input
                  label={t('finance.modal.supplier') + ' *'}
                  value={formData.supplier}
                  onChange={(e) => handleInputChange('supplier', e.target.value)}
                  error={errors.supplier}
                  placeholder={t('finance.modal.supplier')}
                />

                <Input
                  label={t('finance.modal.supplierInvoiceAmt') + ' *'}
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => handleInputChange('amount', e.target.value)}
                  error={errors.amount}
                  placeholder={t('finance.modal.invoice.amount')}
                />

                <Input
                  label={t('finance.modal.supplierInvoiceNum') + ' *'}
                  value={formData.invoiceNumber}
                  onChange={(e) => handleInputChange('invoiceNumber', e.target.value)}
                  error={errors.invoiceNumber}
                  placeholder={t('finance.modal.supplierInvoiceNum')}
                />

                <Select
                  label={t('finance.modal.invoice.status')}
                  value={formData.status}
                  onChange={(e) => handleInputChange('status', e.target.value)}
                >
                  {supplierInvoiceStatuses.map(status => (
                    <option key={status.value} value={status.value}>
                      {t(status.labelKey)}
                    </option>
                  ))}
                </Select>

                <Input
                  label={t('finance.modal.invoice.issueDate') + ' *'}
                  type="date"
                  value={formData.issueDate}
                  onChange={(e) => handleInputChange('issueDate', e.target.value)}
                  error={errors.issueDate}
                />

                <Input
                  label={t('finance.modal.invoice.dueDate') + ' *'}
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => handleInputChange('dueDate', e.target.value)}
                  error={errors.dueDate}
                  min={formData.issueDate}
                />
              </div>

              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('finance.modal.invoiceFile')}
                </label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-md hover:border-gray-400 dark:hover:border-gray-500 transition-colors">
                  <div className="space-y-1 text-center">
                    <Upload className="mx-auto h-8 w-8 text-gray-400" />
                    <div className="flex text-sm text-gray-600 dark:text-gray-400 gap-1 justify-center">
                      <label htmlFor="invoice-upload" className="relative cursor-pointer bg-white dark:bg-gray-800 rounded-md font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500">
                        <span>{t('finance.modal.uploadInvoiceBtn')}</span>
                        <input
                          id="invoice-upload"
                          name="invoice-upload"
                          type="file"
                          className="sr-only"
                          accept=".pdf,.jpg,.jpeg,.png"
                          onChange={handleFileSelect}
                        />
                      </label>
                      <p className="pl-1 rtl:pl-0 rtl:pr-1">{t('finance.record.dragDrop')}</p>
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {t('finance.modal.uploadInvoiceHelper')}
                    </p>
                  </div>
                </div>
                
                {invoiceFile && (
                  <div className="mt-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <p className="text-sm text-green-800 dark:text-green-300">
                      {t('finance.record.selected')}: {invoiceFile.name}
                    </p>
                  </div>
                )}
              </div>

              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t('finance.record.notes')}
                </label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                  rows={3}
                  className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder={t('finance.modal.notesSupplierPlaceholder')}
                />
              </div>

              <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate('/finance')}
                  disabled={isLoading}
                >
                  {t('common.cancel')}
                </Button>
                <Button
                  type="submit"
                  disabled={isLoading}
                  loading={isLoading}
                >
                  <Save className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                  {t('finance.action.recordInvoice')}
                </Button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
