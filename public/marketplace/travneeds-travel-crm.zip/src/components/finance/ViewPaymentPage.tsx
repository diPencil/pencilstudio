import React from 'react';
import { DollarSign, Calendar, FileText, Clock, CheckCircle, ArrowLeft } from 'lucide-react';
import { formatCurrency, formatDate } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { FinanceBooking } from './FinancePage';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '../ui/Button';
import { cn } from '../../utils/cn';

interface PaymentHistoryItem {
  id: string;
  amount: number;
  method: string;
  date: string;
  reference: string;
  processedBy: string;
  notes: string;
  receiptUrl: string | null;
}

interface InvoiceHistoryItem {
  id: string;
  amount: number;
  issueDate: string;
  dueDate: string;
  status: string;
  sentDate: string;
  paidDate: string | null;
  notes: string;
}

const mockPaymentHistory: PaymentHistoryItem[] = [
  {
    id: 'PAY-001',
    amount: 400,
    method: 'Bank Transfer',
    date: '2025-01-12',
    reference: 'TXN-123456789',
    processedBy: 'Super Admin',
    notes: 'Initial deposit payment',
    receiptUrl: null
  },
  {
    id: 'PAY-002',
    amount: 800,
    method: 'Credit Card',
    date: '2025-01-15',
    reference: 'CC-987654321',
    processedBy: 'Finance Team',
    notes: 'Final payment before travel',
    receiptUrl: 'receipt_002.pdf'
  }
];

const mockInvoiceHistory: InvoiceHistoryItem[] = [
  {
    id: 'INV-001',
    amount: 1200,
    issueDate: '2025-01-10',
    dueDate: '2025-01-20',
    status: 'Sent',
    sentDate: '2025-01-10',
    paidDate: null,
    notes: 'Initial invoice for booking'
  }
];

export const ViewPaymentPage: React.FC = () => {
  const { t, direction, isRTL } = useLocale();
  const navigate = useNavigate();
  const location = useLocation();
  const booking = location.state?.booking as FinanceBooking | null;

  if (!booking) {
    return (
      <div className="w-full pb-8 pt-8 flex justify-center">
        <Button onClick={() => navigate('/finance')}>{t('common.back') || 'Back to Finance'}</Button>
      </div>
    );
  }

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'Fully Paid': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'Deposit Paid': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      case 'Partially Paid': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'Overdue': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const getInvoiceStatusColor = (status: string) => {
    switch (status) {
      case 'Paid': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'Sent': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      case 'Issued': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'Overdue': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const getLocalizedPaymentStatus = (status: string) => {
    switch (status) {
      case 'Fully Paid': return t('finance.status.fullyPaid');
      case 'Deposit Paid': return t('finance.status.depositPaid');
      case 'Partially Paid': return t('finance.status.partiallyPaid');
      case 'Overdue': return t('finance.status.overdue');
      default: return status;
    }
  };

  const getLocalizedInvoiceStatus = (status: string) => {
    switch (status) {
      case 'Paid': return t('finance.modal.invoiceStatus.paid');
      case 'Sent': return t('finance.modal.invoiceStatus.awaitingConf');
      case 'Issued': return t('finance.modal.invoiceStatus.awaitingAppr');
      case 'Overdue': return t('finance.modal.invoiceStatus.overdue');
      default: return status;
    }
  };

  const getLocalizedPaymentMethod = (method: string): string => {
    switch (method) {
      case 'Cash': return t('finance.record.method.cash');
      case 'Credit Card': return t('finance.record.method.creditCard');
      case 'Bank Transfer': return t('finance.record.method.bankTransfer');
      case 'Check': return t('finance.record.method.check');
      case 'Online Payment': return t('finance.record.method.onlinePayment');
      case 'Wire Transfer': return t('finance.record.method.wireTransfer');
      default: return method;
    }
  };

  const paymentProgress = (booking.paidAmount / booking.totalAmount) * 100;

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate('/finance')} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
                <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                {t('finance.modal.paymentDetailsTitle').replace('{id}', '')} <span className="ltr-value bidi-isolate">{booking.id}</span>
              </h1>
              <p className="mt-1 text-sm text-blue-100 opacity-90">
                {booking.customer}
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Payment Overview */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                {t('finance.modal.paymentOverview')}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-3">
                  <DollarSign className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{t('finance.modal.totalBookingAmt')}</p>
                    <p className="font-medium text-gray-900 dark:text-white ltr-value bidi-isolate">{formatCurrency(booking.totalAmount)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{t('finance.record.summaryPaid')}</p>
                    <p className="font-medium text-gray-900 dark:text-white ltr-value bidi-isolate">{formatCurrency(booking.paidAmount)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{t('finance.modal.remainingOutstanding')}</p>
                    <p className="font-medium text-gray-900 dark:text-white ltr-value bidi-isolate">{formatCurrency(booking.outstandingBalance)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{t('finance.modal.invoice.dueDate')}</p>
                    <p className="font-medium text-gray-900 dark:text-white ltr-value bidi-isolate">{formatDate(booking.dueDate)}</p>
                  </div>
                </div>
              </div>

              {/* Payment Progress */}
              <div className="mt-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('finance.modal.paymentProgress')}</span>
                  <span className="text-sm text-gray-500 dark:text-gray-400 ltr-value bidi-isolate">{paymentProgress.toFixed(1)}%</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-3">
                  <div 
                    className="bg-green-500 h-3 rounded-full transition-all duration-300"
                    style={{ width: `${paymentProgress}%` }}
                  />
                </div>
              </div>

              <div className="mt-4">
                <span className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full ${getPaymentStatusColor(booking.paymentStatus)}`}>
                  {getLocalizedPaymentStatus(booking.paymentStatus)}
                </span>
              </div>
            </div>

            {/* Payment History */}
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                {t('finance.modal.paymentHistory')}
              </h3>
              <div className="space-y-4">
                {mockPaymentHistory.map((payment) => (
                  <div key={payment.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-green-50 dark:bg-green-900/50 rounded-lg">
                        <DollarSign className="h-5 w-5 text-green-600 dark:text-green-400" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white ltr-value bidi-isolate">{formatCurrency(payment.amount)}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{getLocalizedPaymentMethod(payment.method)}</p>
                        <p className="text-xs text-gray-400">Ref: <span className="ltr-value bidi-isolate">{payment.reference}</span></p>
                      </div>
                    </div>
                    <div className="text-right rtl:text-left">
                      <p className="text-sm text-gray-900 dark:text-white ltr-value bidi-isolate">{formatDate(payment.date)}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {t('finance.modal.history.processedBy').toLowerCase()} <span className="font-medium">{payment.processedBy}</span>
                      </p>
                      {payment.receiptUrl && (
                        <button className="text-xs text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300">
                          {t('finance.modal.invoice.viewReceipt')}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Invoice History */}
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                {t('finance.modal.invoiceHistory')}
              </h3>
              <div className="space-y-4">
                {mockInvoiceHistory.map((invoice) => (
                  <div key={invoice.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-blue-50 dark:bg-blue-900/50 rounded-lg">
                        <FileText className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white ltr-value bidi-isolate">{invoice.id}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400 ltr-value bidi-isolate">{formatCurrency(invoice.amount)}</p>
                        <p className="text-xs text-gray-400">{t('finance.modal.invoice.dueDate')}: <span className="ltr-value bidi-isolate">{formatDate(invoice.dueDate)}</span></p>
                      </div>
                    </div>
                    <div className="text-right rtl:text-left">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getInvoiceStatusColor(invoice.status)}`}>
                        {getLocalizedInvoiceStatus(invoice.status)}
                      </span>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {t('finance.modal.invoice.issueDate')}: <span className="ltr-value bidi-isolate">{formatDate(invoice.issueDate)}</span>
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Financial Summary */}
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                {t('finance.table.financialSummary')}
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">{t('finance.modal.bookingValue')}</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-white ltr-value bidi-isolate">
                    {formatCurrency(booking.totalAmount)}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">{t('finance.modal.supplierCost')}</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-white ltr-value bidi-isolate">
                    {formatCurrency(booking.supplierCost)}
                  </span>
                </div>
                <div className="flex items-center justify-between border-t border-gray-200 dark:border-gray-600 pt-2">
                  <span className="text-sm font-medium text-gray-900 dark:text-white">{t('finance.reports.agent.profit')}</span>
                  <div className="text-right rtl:text-left">
                    <span className="text-sm font-medium text-gray-900 dark:text-white ltr-value bidi-isolate">
                      {formatCurrency(booking.profit)}
                    </span>
                    <div className="text-xs text-green-600 dark:text-green-400 bidi-isolate">
                      {booking.profitMargin}% {t('finance.table.margin')}
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">{t('finance.modal.supplierStatus')}</span>
                  <span className={`text-sm font-medium ${booking.supplierPaid ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                    {booking.supplierPaid ? t('finance.modal.invoiceStatus.paid') : t('reservations.finance.pending')}
                  </span>
                </div>
              </div>
            </div>

            {/* Booking Details */}
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 shadow-sm">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                {t('finance.modal.bookingDetails')}
              </h3>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{t('finance.table.customer')}</p>
                  <p className="font-medium text-gray-900 dark:text-white">{booking.customer}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{t('finance.modal.service')}</p>
                  <p className="font-medium text-gray-900 dark:text-white">{booking.tripItem}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{t('finance.modal.destination')}</p>
                  <p className="font-medium text-gray-900 dark:text-white">{booking.destination as any}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{t('finance.reports.agent.name')}</p>
                  <p className="font-medium text-gray-900 dark:text-white">{booking.agent}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{t('finance.modal.created')}</p>
                  <p className="font-medium text-gray-900 dark:text-white ltr-value bidi-isolate">{formatDate(booking.createdAt)}</p>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-4">
              <h4 className="text-sm font-semibold text-blue-800 dark:text-blue-300 mb-3">
                {t('finance.modal.quickActions')}
              </h4>
              <div className="space-y-2">
                <button className="w-full text-left rtl:text-right text-sm text-blue-700 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300">
                  • {t('finance.modal.action.recordNewPayment')}
                </button>
                <button className="w-full text-left rtl:text-right text-sm text-blue-700 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300">
                  • {t('finance.modal.action.sendReminder')}
                </button>
                <button className="w-full text-left rtl:text-right text-sm text-blue-700 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300">
                  • {t('finance.modal.action.generateReceipt')}
                </button>
                <button className="w-full text-left rtl:text-right text-sm text-blue-700 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300">
                  • {t('finance.modal.action.updateTerms')}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
