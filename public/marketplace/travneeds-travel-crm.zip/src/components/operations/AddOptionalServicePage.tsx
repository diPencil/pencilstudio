import React, { useState } from 'react';
import { Save, Upload, ArrowLeft, Info, CheckCircle2 } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { formatCurrency, formatDate } from '../../utils/format';

const serviceCategories = [
    'Activity', 'Entertainment', 'Photography', 'Wellness', 'Dining',
    'Shopping', 'Transport', 'Accommodation', 'Guide Services', 'Equipment', 'Other'
];

const predefinedServices = [
    { name: 'Camel Ride', category: 'Activity', price: 50 },
    { name: 'Sound & Light Show', category: 'Entertainment', price: 30 },
    { name: 'Spa Package', category: 'Wellness', price: 120 },
    { name: 'Hot Air Balloon', category: 'Activity', price: 150 },
    { name: 'Airport Transfer', category: 'Transport', price: 35 }
];

const mockTrips = [
    { id: 'TRP-2025-001', customer: 'Ahmed Hassan', count: 4, itinerary: 'Cairo & Luxor Classic', startDate: '2025-03-10', endDate: '2025-03-18' },
    { id: 'TRP-2025-012', customer: 'Sarah Williams', count: 2, itinerary: 'Red Sea Divine', startDate: '2025-03-15', endDate: '2025-03-22' }
];

export const AddOptionalServicePage: React.FC = () => {
    const navigate = useNavigate();
    const toast = useToastContext();
    const [formData, setFormData] = useState({
        tripId: '',
        serviceName: '',
        price: '',
        category: 'Activity',
        description: '',
        invoiceToFinance: true
    });
    const [attachment, setAttachment] = useState<File | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleQuickSelect = (service: any) => {
        setFormData(prev => ({
            ...prev,
            serviceName: service.name,
            category: service.category,
            price: service.price.toString()
        }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setTimeout(() => {
            toast.success('Service Added', 'Optional service has been successfully added to the trip itinerary.');
            navigate('/operations');
        }, 800);
    };

    const selectedTrip = mockTrips.find(t => t.id === formData.tripId);

    return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => navigate('/operations')}
                            className="inline-flex items-center gap-2 text-blue-100 hover:text-white transition-colors group p-2 hover:bg-white/10 rounded-lg"
                        >
                            <ArrowLeft className="w-5 h-5 rtl-flip" />
                        </button>
                        <div>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Add Optional Service</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">Enhance customer experience by adding extra services during the trip</p>
                        </div>
                    </div>
                </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    <Card>
                        <CardHeader className="border-b border-gray-100 dark:border-gray-800">
                            <CardTitle className="text-sm font-bold uppercase tracking-wider text-orange-600">Quick Selection</CardTitle>
                        </CardHeader>
                        <CardContent className="p-6">
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                                {predefinedServices.map((s, i) => (
                                    <button
                                        key={i}
                                        onClick={() => handleQuickSelect(s)}
                                        className="p-3 text-left border border-gray-100 dark:border-gray-700 rounded-xl hover:border-orange-500 hover:bg-orange-50 dark:hover:bg-orange-900/10 transition-all group"
                                    >
                                        <div className="font-bold text-sm text-gray-900 dark:text-white group-hover:text-orange-600">{s.name}</div>
                                        <div className="text-[10px] text-gray-500 uppercase font-medium">{s.category} • {formatCurrency(s.price)}</div>
                                    </button>
                                ))}
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardContent className="p-6">
                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <Select
                                        label="Target Trip *"
                                        value={formData.tripId}
                                        onChange={(e) => setFormData(prev => ({ ...prev, tripId: e.target.value }))}
                                        required
                                    >
                                        <option value="">Select an active trip...</option>
                                        {mockTrips.map(t => (
                                            <option key={t.id} value={t.id}>{t.id} - {t.customer} ({t.itinerary})</option>
                                        ))}
                                    </Select>

                                    <Select
                                        label="Service Category"
                                        value={formData.category}
                                        onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                                    >
                                        {serviceCategories.map(c => <option key={c} value={c}>{c}</option>)}
                                    </Select>

                                    <Input
                                        label="Service Name *"
                                        value={formData.serviceName}
                                        onChange={(e) => setFormData(prev => ({ ...prev, serviceName: e.target.value }))}
                                        required
                                        placeholder="e.g. Private Felucca Session"
                                    />

                                    <Input
                                        label="Selling Price *"
                                        type="number"
                                        value={formData.price}
                                        onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                                        required
                                        placeholder="0.00"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-200 mb-2">Service Description</label>
                                    <textarea
                                        value={formData.description}
                                        onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                                        rows={3}
                                        className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
                                        placeholder="Details about the service to be provided..."
                                    />
                                </div>

                                <div className="p-6 border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-xl text-center">
                                    <input type="file" id="ops-file" className="sr-only" onChange={(e) => setAttachment(e.target.files?.[0] || null)} />
                                    <label htmlFor="ops-file" className="cursor-pointer group">
                                        <Upload className="mx-auto h-10 w-10 text-gray-400 group-hover:text-blue-500 mb-2" />
                                        <p className="text-sm font-medium">{attachment ? attachment.name : 'Upload Service Voucher / Agreement'}</p>
                                    </label>
                                </div>

                                <div className="flex items-center space-x-3 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-xl">
                                    <input
                                        type="checkbox"
                                        id="finance"
                                        checked={formData.invoiceToFinance}
                                        onChange={(e) => setFormData(prev => ({ ...prev, invoiceToFinance: e.target.checked }))}
                                        className="h-4 w-4 text-blue-600 rounded"
                                    />
                                    <label htmlFor="finance" className="text-sm font-medium text-gray-700 dark:text-gray-300">Synchronize with Finance for automated invoicing</label>
                                </div>

                                <div className="flex justify-end space-x-3 pt-6 border-t border-gray-100 dark:border-gray-800">
                                    <Button variant="outline" type="button" onClick={() => navigate('/operations')}>Cancel</Button>
                                    <Button type="submit" loading={isLoading}>
                                        <Save className="h-4 w-4 mr-2" />
                                        Save Service
                                    </Button>
                                </div>
                            </form>
                        </CardContent>
                    </Card>
                </div>

                <div className="space-y-6">
                    {selectedTrip && (
                        <Card className="bg-white dark:bg-gray-800 border-none shadow-sm">
                            <CardContent className="p-6 space-y-4">
                                <div className="flex items-center space-x-3 text-blue-600 dark:text-blue-400">
                                    <Info size={20} />
                                    <span className="font-bold text-sm uppercase tracking-tight">Active Trip Context</span>
                                </div>
                                <div className="space-y-3">
                                    <div>
                                        <p className="text-[10px] text-gray-500 uppercase font-bold">Customer</p>
                                        <p className="text-sm font-bold text-gray-900 dark:text-white">{selectedTrip.customer} ({selectedTrip.count} pax)</p>
                                    </div>
                                    <div>
                                        <p className="text-[10px] text-gray-500 uppercase font-bold">Current Itinerary</p>
                                        <p className="text-sm text-gray-700 dark:text-gray-300">{selectedTrip.itinerary}</p>
                                    </div>
                                    <div className="pt-2 flex items-center justify-between border-t border-blue-200 dark:border-blue-800">
                                        <span className="text-xs font-medium text-gray-600 dark:text-gray-400">{formatDate(selectedTrip.startDate)} - {formatDate(selectedTrip.endDate)}</span>
                                        <span className="px-2 py-0.5 bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300 rounded text-[10px] font-bold">ONGOING</span>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    <Card>
                        <CardContent className="p-4 flex items-start space-x-3">
                            <CheckCircle2 className="text-green-500 mt-0.5 flex-shrink-0" size={18} />
                            <div className="space-y-1">
                                <h4 className="text-sm font-bold">Operations Memo</h4>
                                <p className="text-xs text-gray-500 leading-relaxed">Optional services are billed immediately if 'Sync with Finance' is checked. Ensure guide commission is noted in description.</p>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
        </div>
    );
};
