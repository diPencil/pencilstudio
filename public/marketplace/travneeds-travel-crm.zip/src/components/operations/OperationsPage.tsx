import React, { useState } from 'react';
import { Plus, Search, Eye, MessageSquare, MapPin, Users, Car, Calendar, Clock, AlertTriangle, Navigation, Phone } from 'lucide-react';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { formatDate, formatCurrency } from '../../utils/format';
import { mockTrips, mockTasks } from '../../services/mockData';
import { useNavigate } from 'react-router-dom';
import { useLocale } from '../../localization/useLocale';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';
import { cn } from '../../utils/cn';
import { useToastContext } from '../../contexts/ToastContext';

export const OperationsPage: React.FC = () => {
    const { t, direction, isRTL } = useLocale();
    const navigate = useNavigate();
    const toast = useToastContext();
    const [trips, setTrips] = useState(mockTrips || []);
    const [tasks] = useState(mockTasks || []);
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('All Status');
    const [destinationFilter, setDestinationFilter] = useState('All Destinations');

    const [selectedTrip, setSelectedTrip] = useState<any>(null);

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'Planned': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20';
            case 'In Progress': return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/20';
            case 'Issue': return 'bg-rose-100 text-rose-800 dark:bg-rose-900/20';
            case 'Completed': return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20';
            default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20';
        }
    };

    const filteredTrips = trips.filter(t => {
        const matchesSearch = t.customer.toLowerCase().includes(searchTerm.toLowerCase()) || t.id.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = statusFilter === 'All Status' || t.status === statusFilter;
        return matchesSearch && matchesStatus;
    });

    const metrics = {
        active: trips.filter(t => t.status === 'In Progress').length,
        planned: trips.filter(t => t.status === 'Planned').length,
        tasks: tasks.length,
        issues: trips.filter(t => t.status === 'Issue').length
    };

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px]">
            {/* Top Welcome Banner (NeoPay Style) */}
            <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
                <div className={cn(isRTL ? "text-right" : "text-left")}>
                    <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                        Field Operations
                    </h1>
                    <p className="mt-1 text-sm text-blue-100 opacity-90">
                        Dispatching, itinerary tracking, and fleet coordination
                    </p>
                </div>
                <div className={cn("flex items-center gap-2 sm:gap-3 banner-actions", isRTL && "flex-row-reverse")}>
                    <button onClick={() => navigate('/operations/schedule')} className="flex items-center gap-2 bg-white/10 hover:bg-white text-blue-50 hover:text-blue-600 px-4 py-2.5 rounded-xl font-bold transition-all duration-300">
                        <Clock className="h-4 w-4" />
                        <span>Today</span>
                    </button>
                    <button onClick={() => navigate('/operations/calendar')} className="flex items-center gap-2 bg-white/10 hover:bg-white text-blue-50 hover:text-blue-600 px-4 py-2.5 rounded-xl font-bold transition-all duration-300">
                        <Calendar className="h-4 w-4" />
                        <span>Calendar</span>
                    </button>
                    <button onClick={() => navigate('/operations/add-service')} className="flex items-center gap-2 bg-white text-blue-600 hover:bg-blue-50 px-4 py-2.5 rounded-xl font-bold transition-all duration-300 shadow-sm hover:shadow">
                        <Plus className="h-4 w-4" />
                        <span>Add Service</span>
                    </button>
                </div>
            </div>

            {/* Schedule Preview & Logistics Metrics */}
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
                <Card className="rounded-3xl border-0 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_8px_32px_-8px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-300 relative overflow-hidden group lg:col-span-2">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400">Today's Dispatch Schedule</h3>
                            <span className="px-3 py-1 bg-blue-50 text-blue-600 text-[10px] font-bold rounded-full uppercase tracking-wider">Live</span>
                        </div>
                        <div className="space-y-3">
                            {trips.slice(0, 3).map((t, i) => (
                                <div key={i} className="flex items-center justify-between p-2 rounded hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                                    <div className="flex items-center space-x-3">
                                        <div className="w-8 h-8 rounded bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-[10px] font-bold">
                                            {t.id.slice(-3)}
                                        </div>
                                        <div>
                                            <p className="text-xs font-bold">{t.itinerary}</p>
                                            <p className="text-[10px] text-gray-500">{t.assignedDriver} • {t.transport}</p>
                                        </div>
                                    </div>
                                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${getStatusColor(t.status)}`}>{t.status}</span>
                                </div>
                            ))}
                        </div>
                        <button className="w-full mt-4 py-2 text-[10px] font-bold text-blue-600 border-t border-gray-50 dark:border-gray-800 uppercase tracking-widest" onClick={() => setIsScheduleModalOpen(true)}>
                            View Full Schedule
                        </button>
                    </CardContent>
                </Card>

                <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6 h-full">
                    <Card className="rounded-3xl border-0 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_8px_32px_-8px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-300 relative overflow-hidden group h-full">
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Active Missions</p>
                                    <p className="text-3xl font-bold mt-2 text-emerald-600">{metrics.active}</p>
                                    <p className="text-[10px] text-emerald-500 font-bold mt-2">↑ 2 from yesterday</p>
                                </div>
                                <Navigation className="absolute -bottom-4 -right-4 h-24 w-24 text-emerald-500/10 group-hover:scale-110 group-hover:-translate-y-2 group-hover:-translate-x-2 transition-all duration-500" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="rounded-3xl border-0 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_8px_32px_-8px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-300 relative overflow-hidden group h-full">
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Fleet Utilization</p>
                                    <p className="text-3xl font-bold mt-2 text-blue-600">82%</p>
                                    <p className="text-[10px] text-blue-500 font-bold mt-2">12 Vehicles Active</p>
                                </div>
                                <Car className="absolute -bottom-4 -right-4 h-24 w-24 text-blue-500/10 group-hover:scale-110 group-hover:-translate-y-2 group-hover:-translate-x-2 transition-all duration-500" />
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>

            {/* Filters */}
            <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900 mb-8">
                <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row items-center gap-4">
                        <div className="flex-1 w-full relative">
                            <Search className={cn("absolute top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400", isRTL ? "right-4" : "left-4")} />
                            <Input
                                placeholder="Search by trip, customer, or ID..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className={cn("h-12 bg-slate-50 border-0 rounded-2xl font-medium", isRTL ? "pr-12" : "pl-12")}
                            />
                        </div>
                        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="w-full md:w-48 h-12 bg-slate-50 border-0 rounded-2xl font-medium">
                            <option>All Status</option>
                            <option>Planned</option>
                            <option>In Progress</option>
                            <option>Issue</option>
                            <option>Completed</option>
                        </Select>
                        <Select value={destinationFilter} onChange={(e) => setDestinationFilter(e.target.value)} className="w-full md:w-48 h-12 bg-slate-50 border-0 rounded-2xl font-medium">
                            <option>All Destinations</option>
                            <option>Luxor</option>
                            <option>Aswan</option>
                            <option>Cairo</option>
                        </Select>
                    </div>
                </CardContent>
            </Card>

            {/* Table */}
            <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900 overflow-hidden mb-8">
                <div className="overflow-x-auto">
                    <table className="table-premium w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-slate-50/50 dark:bg-gray-800/50">
                            <th>Operation ID</th>
                            <th>Customer & Group</th>
                            <th>Itinerary Details</th>
                            <th>Assignments</th>
                            <th>Vehicle/Asset</th>
                            <th>Status</th>
                            <th className="text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredTrips.map((t) => (
                            <tr key={t.id} className={t.status === 'Issue' ? 'bg-rose-50/30 dark:bg-rose-900/5' : ''}>
                                <td>
                                    <div className="font-bold text-gray-900 dark:text-white">{t.id}</div>
                                    <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{formatDate(t.createdAt)}</div>
                                </td>
                                <td>
                                    <div className="text-sm font-medium">{t.customer}</div>
                                    <div className="text-[10px] text-gray-500 font-bold">{t.customerCount} Pax</div>
                                </td>
                                <td>
                                    <div className="text-xs font-bold text-gray-900 dark:text-white">{t.itinerary}</div>
                                    <div className="text-[10px] text-gray-500">{formatDate(t.startDate)} - {formatDate(t.endDate)}</div>
                                </td>
                                <td>
                                    <div className="flex flex-col space-y-1">
                                        <div 
                                            onClick={() => toast.info(`Calling Guide: ${t.assignedGuide}`, 'Establishing secure line...')}
                                            className="flex items-center text-[10px] text-gray-600 hover:text-blue-500 cursor-pointer"
                                        >
                                            <Users className="h-3 w-3 mr-1" /> {t.assignedGuide} <Phone className="h-2 w-2 ml-1" />
                                        </div>
                                        <div 
                                            onClick={() => toast.info(`Calling Driver: ${t.assignedDriver}`, 'Establishing secure line...')}
                                            className="flex items-center text-[10px] text-gray-600 hover:text-blue-500 cursor-pointer"
                                        >
                                            <Car className="h-3 w-3 mr-1" /> {t.assignedDriver} <Phone className="h-2 w-2 ml-1" />
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div className="text-xs font-medium">{t.transport}</div>
                                    <div className="text-[10px] text-gray-500">{t.transportDetails}</div>
                                </td>
                                <td>
                                    <span className={`badge-standard ${getStatusColor(t.status)}`}>{t.status}</span>
                                </td>
                                <td className="text-right">
                                    <TableActionsDropdown
                                        actions={[
                                            { label: 'View Itinerary', icon: Eye, onClick: () => navigate('/operations/view-trip', { state: { trip: t } }) },
                                            { label: 'Reassign Staff', icon: Users, onClick: () => { setSelectedTrip(t); navigate('/operations/assign-staff', { state: { trip: t } }); } },
                                            { label: 'Track Live Location', icon: MapPin, onClick: () => toast.info('Live Tracking Initialized', `Connecting to vehicle GPS for ${t.transportDetails}...`) },
                                            { label: 'Report Issue', icon: AlertTriangle, onClick: () => navigate('/operations/report-issue', { state: { trip: t } }) }
                                        ]}
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            </Card>

            {/* All Modals replaced by page navigation */}
            </div>
        </div>
    );
};