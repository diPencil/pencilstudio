import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { AlertTriangle, ArrowLeft, Calendar, User, MapPin, Hash, Phone } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { useToastContext } from '../../contexts/ToastContext';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';

const ISSUE_TYPE_OPTIONS = [
  { value: '', label: 'Select issue type' },
  { value: 'Vehicle Breakdown', label: 'Vehicle Breakdown' },
  { value: 'Medical Emergency', label: 'Medical Emergency' },
  { value: 'Customer Complaint', label: 'Customer Complaint' },
  { value: 'Safety Concern', label: 'Safety Concern' },
  { value: 'Weather Delay', label: 'Weather Delay' },
  { value: 'Other', label: 'Other' },
];

const PRIORITY_OPTIONS = [
  { value: '', label: 'Select priority' },
  { value: 'Critical', label: '🔴 Critical' },
  { value: 'High', label: '🟠 High' },
  { value: 'Medium', label: '🟡 Medium' },
  { value: 'Low', label: '🟢 Low' },
];

const PRIORITY_STYLES: Record<string, string> = {
  Critical: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
  High: 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400',
  Medium: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400',
  Low: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
};

export const ReportIssuePage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useLocale();
  const { showToast } = useToastContext();

  const trip = location.state?.trip;

  React.useEffect(() => {
    if (!trip) {
      navigate('/operations', { replace: true });
    }
  }, [trip, navigate]);

  const [issueType, setIssueType] = useState('');
  const [priority, setPriority] = useState('');
  const [description, setDescription] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (!trip) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 700));
    showToast(
      t('Issue Logged - Management has been notified') ??
        'Issue Logged - Management has been notified',
      'warning'
    );
    navigate(-1);
  };

  return (
    <div className="w-full pb-8">
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(-1)}
              className="inline-flex items-center gap-2 text-blue-100 hover:text-white transition-colors group p-2 hover:bg-white/10 rounded-lg"
            >
              <ArrowLeft className="w-5 h-5 rtl-flip" />
            </button>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3 flex-shrink-0 hidden sm:block">
              <AlertTriangle className="w-6 h-6 text-rose-300" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                {t('Report Issue / Emergency') ?? 'Report Issue / Emergency'}
              </h1>
              <p className="mt-1 text-sm text-blue-100 opacity-90">
                {t('Log an issue or emergency for this trip') ?? 'Log an issue or emergency for this trip'}
              </p>
            </div>
          </div>
        </div>
        {/* Trip Info Card */}
        <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 p-6">
          <h2 className="text-base font-semibold text-gray-700 dark:text-gray-300 mb-4">
            {t('Trip Information') ?? 'Trip Information'}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="flex items-start gap-3">
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-2 flex-shrink-0">
                <Hash className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('Trip ID') ?? 'Trip ID'}
                </p>
                <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">
                  {trip.id ?? '—'}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="bg-purple-50 dark:bg-purple-900/20 rounded-xl p-2 flex-shrink-0">
                <User className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('Customer') ?? 'Customer'}
                </p>
                <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">
                  {trip.customer ?? trip.customerName ?? '—'}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded-xl p-2 flex-shrink-0">
                <MapPin className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('Itinerary') ?? 'Itinerary'}
                </p>
                <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">
                  {trip.itinerary ?? trip.destination ?? '—'}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="bg-amber-50 dark:bg-amber-900/20 rounded-xl p-2 flex-shrink-0">
                <Calendar className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('Dates') ?? 'Dates'}
                </p>
                <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">
                  {trip.startDate && trip.endDate
                    ? `${trip.startDate} → ${trip.endDate}`
                    : trip.dates ?? '—'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Issue Report Form */}
        <form onSubmit={handleSubmit}>
          <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 p-6 space-y-6">
            {/* Alert banner */}
            <div className="flex items-start gap-3 bg-rose-50 dark:bg-rose-900/20 border border-rose-200 dark:border-rose-800/50 rounded-2xl p-4">
              <AlertTriangle className="w-5 h-5 text-rose-500 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-rose-700 dark:text-rose-300">
                {t(
                  'This report will be immediately escalated to management. Please provide accurate and detailed information.'
                ) ??
                  'This report will be immediately escalated to management. Please provide accurate and detailed information.'}
              </p>
            </div>

            <h2 className="text-base font-semibold text-gray-700 dark:text-gray-300">
              {t('Issue Details') ?? 'Issue Details'}
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Issue Type */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {t('Issue Type') ?? 'Issue Type'}
                </label>
                <Select
                  value={issueType}
                  onChange={(e) => setIssueType(e.target.value)}
                  options={ISSUE_TYPE_OPTIONS}
                />
              </div>

              {/* Priority */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {t('Priority') ?? 'Priority'}
                </label>
                <Select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value)}
                  options={PRIORITY_OPTIONS}
                />
                {priority && (
                  <span
                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      PRIORITY_STYLES[priority] ?? ''
                    }`}
                  >
                    {priority}
                  </span>
                )}
              </div>
            </div>

            {/* Description */}
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                {t('Description') ?? 'Description'}
                <span className="text-rose-500 ml-1">*</span>
              </label>
              <textarea
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={5}
                placeholder={
                  t('Describe the issue in detail...') ??
                  'Describe the issue in detail...'
                }
                className="w-full rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 px-4 py-3 text-sm text-gray-800 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 resize-none transition-colors"
              />
            </div>

            {/* Contact Number */}
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                {t('Contact Number') ?? 'Contact Number'}
              </label>
              <div className="relative">
                <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                <Input
                  type="tel"
                  value={contactNumber}
                  onChange={(e) => setContactNumber(e.target.value)}
                  placeholder={t('+20 1xx xxx xxxx') ?? '+20 1xx xxx xxxx'}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <Button
                type="button"
                variant="ghost"
                onClick={() => navigate(-1)}
              >
                {t('Cancel') ?? 'Cancel'}
              </Button>
              <Button
                type="submit"
                variant="danger"
                loading={submitting}
                disabled={submitting || !description.trim()}
              >
                {t('Submit Report') ?? 'Submit Report'}
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};


