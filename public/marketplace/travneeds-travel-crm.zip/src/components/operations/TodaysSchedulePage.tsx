import React, { useState } from 'react';
import { Clock, MapPin, Users, Car, Phone, AlertTriangle, ArrowLeft, Filter } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { useNavigate } from 'react-router-dom';
import { formatDate } from '../../utils/format';

const mockTasks = [
    { id: 'T1', time: '09:00', type: 'Pickup', title: 'Airport Pickup - Cairo', customer: 'Ahmed Hassan Group', location: 'CAI Terminal 3', assignedTo: 'Hassan (Driver)', priority: 'High', status: 'Pending' },
    { id: 'T2', time: '10:30', type: 'Tour', title: 'Giza Pyramids Guided Visit', customer: 'Sarah Williams', location: 'Giza Plateau', assignedTo: 'Mahmoud (Guide)', priority: 'Critical', status: 'In Progress' },
    { id: 'T3', time: '13:00', type: 'Lunch', title: 'Traditional Lunch Arrangement', customer: 'Sarah Williams', location: 'Andrea Mariouteya', assignedTo: 'Mahmoud (Guide)', priority: 'Medium', status: 'Pending' },
    { id: 'T4', time: '15:00', type: 'Activity', title: 'Nile Felucca Ride', customer: 'Ahmed Hassan Group', location: 'Maadi Dock', assignedTo: 'Hassan (Driver)', priority: 'Low', status: 'Pending' }
];

const mockTrips = [
    { id: 'TR1', customer: 'Ahmed Hassan Group', itinerary: 'Cairo Express', status: 'In Progress', assignedGuide: 'Omar', assignedDriver: 'Hassan', pax: 4 },
    { id: 'TR2', customer: 'Sarah Williams', itinerary: 'Nile Explorer', status: 'Issue', assignedGuide: 'Mahmoud', assignedDriver: 'Mustafa', pax: 2 }
];

export const TodaysSchedulePage: React.FC = () => {
    const navigate = useNavigate();
    const [staffFilter, setStaffFilter] = useState('All Staff');

    const getStatusStyles = (status: string) => {
        switch (status) {
            case 'Pending': return 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/20 dark:text-yellow-400';
            case 'In Progress': return 'bg-blue-100 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400';
            case 'Issue': return 'bg-red-100 text-red-700 dark:bg-red-900/20 dark:text-red-400';
            default: return 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300';
        }
    };

  return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => navigate('/operations')}
                            className="inline-flex items-center gap-2 text-blue-100 hover:text-white transition-colors group p-2 hover:bg-white/10 rounded-lg"
                        >
                            <ArrowLeft className="w-5 h-5 rtl-flip" />
                        </button>
                        <div>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Today's Schedule</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">{formatDate(new Date().toISOString())} • Real-time field operations log</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-3 mt-4 sm:mt-0">
                        <div className="bg-white/10 p-1.5 rounded-xl backdrop-blur-sm">
                            <Select value={staffFilter} onChange={(e) => setStaffFilter(e.target.value)} className="w-40 border-none bg-transparent text-white focus:ring-0 [&>option]:text-gray-900">
                                <option>All Staff</option>
                                <option>Mahmoud (Guide)</option>
                                <option>Hassan (Driver)</option>
                                <option>Omar (Guide)</option>
                            </Select>
                        </div>
                        <Button className="bg-white text-blue-600 hover:bg-gray-50 rounded-xl font-bold h-[42px]">
                            <Filter className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                            Quick Filter
                        </Button>
                    </div>
                </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-4">
                    <Card>
                        <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-bold uppercase tracking-wider flex items-center">
                                <Clock className="mr-2 h-4 w-4 text-blue-500" />
                                Sequence of Tasks
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                            <div className="divide-y divide-gray-100 dark:divide-gray-800">
                                {mockTasks.map(task => (
                                    <div key={task.id} className="p-5 flex items-start space-x-4 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors group">
                                        <div className="text-center w-16 flex-shrink-0">
                                            <p className="text-lg font-black text-blue-600 dark:text-blue-400 leading-none">{task.time}</p>
                                            <p className="text-[10px] uppercase font-bold text-gray-400 mt-1">Start</p>
                                        </div>
                                        <div className="flex-1">
                                            <div className="flex items-center justify-between mb-1">
                                                <h4 className="font-bold text-gray-900 dark:text-white">{task.title}</h4>
                                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${getStatusStyles(task.status)}`}>{task.status}</span>
                                            </div>
                                            <div className="grid grid-cols-2 gap-y-2 mt-2">
                                                <div className="flex items-center text-xs text-gray-500">
                                                    <Users size={12} className="mr-1.5" />
                                                    {task.customer}
                                                </div>
                                                <div className="flex items-center text-xs text-gray-500">
                                                    <MapPin size={12} className="mr-1.5" />
                                                    {task.location}
                                                </div>
                                                <div className="flex items-center text-xs text-blue-500 font-medium">
                                                    <Car size={12} className="mr-1.5" />
                                                    {task.assignedTo}
                                                </div>
                                                <div className="flex items-center text-xs">
                                                    <span className={`w-2 h-2 rounded-full mr-2 ${task.priority === 'Critical' ? 'bg-red-500' : 'bg-orange-400'}`}></span>
                                                    <span className="text-gray-500 text-[10px] font-bold uppercase">{task.priority} Priority</span>
                                                </div>
                                            </div>
                                        </div>
                                        <button className="opacity-0 group-hover:opacity-100 p-2 hover:bg-white dark:hover:bg-gray-700 rounded-lg shadow-sm border border-gray-100 dark:border-gray-600 transition-all">
                                            <Phone size={14} className="text-green-600" />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <div className="space-y-6">
                    <Card className="bg-white dark:bg-gray-800 border-none shadow-sm">
                        <CardContent className="p-6">
                            <h4 className="label-xs mb-4">Operational Pulse</h4>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                    <p className="stat-value">85%</p>
                                    <p className="label-xs">On-Time Rate</p>
                                </div>
                                <div className="space-y-1">
                                    <p className="stat-value">12</p>
                                    <p className="label-xs">Total Pax Today</p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-bold uppercase tracking-wider">Field Presence</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            {mockTrips.map(trip => (
                                <div key={trip.id} className="p-4 border border-gray-100 dark:border-gray-800 rounded-xl relative overflow-hidden group">
                                    {trip.status === 'Issue' && <div className="absolute top-0 right-0 w-1 h-full bg-red-500"></div>}
                                    <div className="flex justify-between items-start mb-2">
                                        <h5 className="font-bold text-sm">{trip.customer}</h5>
                                        <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${getStatusStyles(trip.status)}`}>{trip.status}</span>
                                    </div>
                                    <p className="text-xs text-gray-500 mb-3">{trip.itinerary}</p>
                                    <div className="space-y-1.5">
                                        <div className="flex items-center text-[11px] text-gray-600 dark:text-gray-400">
                                            <Users size={12} className="mr-2" />
                                            Guide: <span className="ml-1 font-bold text-gray-900 dark:text-white">{trip.assignedGuide}</span>
                                        </div>
                                        <div className="flex items-center text-[11px] text-gray-600 dark:text-gray-400">
                                            <Car size={12} className="mr-2" />
                                            Driver: <span className="ml-1 font-bold text-gray-900 dark:text-white">{trip.assignedDriver}</span>
                                        </div>
                                    </div>
                                    {trip.status === 'Issue' && (
                                        <div className="mt-3 flex items-center space-x-2 p-2 bg-red-50 dark:bg-red-900/10 rounded text-red-600">
                                            <AlertTriangle size={14} />
                                            <span className="text-[10px] font-bold">Needs Supervisor Attention</span>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
        </div>
    );
};
