import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Users, ArrowLeft, Calendar, User, MapPin, Hash } from 'lucide-react';
import { useLocale } from '../../localization/useLocale';
import { useToastContext } from '../../contexts/ToastContext';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';

const STAFF_OPTIONS = [
  { value: '', label: 'Select staff member' },
  { value: 'Ahmed Hassan', label: 'Ahmed Hassan' },
  { value: 'Sara Kamal', label: 'Sara Kamal' },
  { value: 'Mohamed Ali', label: 'Mohamed Ali' },
  { value: 'Fatima Nour', label: 'Fatima Nour' },
  { value: 'Omar Saeed', label: 'Omar Saeed' },
];

export const AssignStaffPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useLocale();
  const { showToast } = useToastContext();

  const trip = location.state?.trip;

  React.useEffect(() => {
    if (!trip) {
      navigate('/operations', { replace: true });
    }
  }, [trip, navigate]);

  const [guide, setGuide] = useState<string>(trip?.guide ?? '');
  const [driver, setDriver] = useState<string>(trip?.driver ?? '');
  const [submitting, setSubmitting] = useState(false);

  if (!trip) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 600));
    showToast(
      t('Staff assigned successfully') ?? 'Staff assigned successfully',
      'success'
    );
    navigate(-1);
  };

  return (
    <div className="w-full pb-8">
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(-1)}
              className="inline-flex items-center gap-2 text-blue-100 hover:text-white transition-colors group p-2 hover:bg-white/10 rounded-lg"
            >
              <ArrowLeft className="w-5 h-5 rtl-flip" />
            </button>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-3 flex-shrink-0 hidden sm:block">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                {t('Assign Staff') ?? 'Assign Staff'}
              </h1>
              <p className="mt-1 text-sm text-blue-100 opacity-90">
                {t('Reassign guide and driver to the trip') ?? 'Reassign guide and driver to the trip'}
              </p>
            </div>
          </div>
        </div>
        {/* Trip Info Card */}
        <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 p-6">
          <h2 className="text-base font-semibold text-gray-700 dark:text-gray-300 mb-4">
            {t('Trip Information') ?? 'Trip Information'}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="flex items-start gap-3">
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-2 flex-shrink-0">
                <Hash className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('Trip ID') ?? 'Trip ID'}
                </p>
                <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">
                  {trip.id ?? '—'}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="bg-purple-50 dark:bg-purple-900/20 rounded-xl p-2 flex-shrink-0">
                <User className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('Customer') ?? 'Customer'}
                </p>
                <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">
                  {trip.customer ?? trip.customerName ?? '—'}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded-xl p-2 flex-shrink-0">
                <MapPin className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('Itinerary') ?? 'Itinerary'}
                </p>
                <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">
                  {trip.itinerary ?? trip.destination ?? '—'}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="bg-amber-50 dark:bg-amber-900/20 rounded-xl p-2 flex-shrink-0">
                <Calendar className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  {t('Dates') ?? 'Dates'}
                </p>
                <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">
                  {trip.startDate && trip.endDate
                    ? `${trip.startDate} → ${trip.endDate}`
                    : trip.dates ?? '—'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Assignment Form */}
        <form onSubmit={handleSubmit}>
          <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 p-6 space-y-6">
            <h2 className="text-base font-semibold text-gray-700 dark:text-gray-300">
              {t('Staff Assignment') ?? 'Staff Assignment'}
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Guide Select */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {t('Guide') ?? 'Guide'}
                </label>
                <Select
                  value={guide}
                  onChange={(e) => setGuide(e.target.value)}
                  options={STAFF_OPTIONS}
                />
              </div>

              {/* Driver Select */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {t('Driver') ?? 'Driver'}
                </label>
                <Select
                  value={driver}
                  onChange={(e) => setDriver(e.target.value)}
                  options={STAFF_OPTIONS}
                />
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <Button
                type="button"
                variant="ghost"
                onClick={() => navigate(-1)}
              >
                {t('Cancel') ?? 'Cancel'}
              </Button>
              <Button
                type="submit"
                variant="primary"
                loading={submitting}
                disabled={submitting}
              >
                {t('Assign Staff') ?? 'Assign Staff'}
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};


