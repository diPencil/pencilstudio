import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, MapPin, Clock, ArrowLeft, Layers, MoreHorizontal, Plus, X } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { useNavigate } from 'react-router-dom';
import { formatDate } from '../../utils/format';
import { useToastContext } from '../../contexts/ToastContext';

type Activity = {
    id: string;
    date: string;
    type: 'Trip' | 'Task';
    title: string;
    detail: string;
    pax?: number;
    time?: string;
    status: string;
};

// Generate dates dynamically relative to the current month
const today = new Date();
const y = today.getFullYear();
const m = String(today.getMonth() + 1).padStart(2, '0');

const initialData: Activity[] = [
    { id: 'TR1', date: `${y}-${m}-${String(today.getDate()).padStart(2, '0')}`, type: 'Trip', title: 'Ahmed Hassan', detail: 'Cairo & Luxor', pax: 4, status: 'Active' },
    { id: 'TS1', date: `${y}-${m}-${String(today.getDate()).padStart(2, '0')}`, type: 'Task', title: 'Airport Pickups', detail: 'Terminal 3', time: '09:00', status: 'Pending' },
    { id: 'TR2', date: `${y}-${m}-${String(Math.min(today.getDate() + 1, 28)).padStart(2, '0')}`, type: 'Trip', title: 'Sarah Williams', detail: 'Red Sea Dive', pax: 2, status: 'Active' },
    { id: 'TS2', date: `${y}-${m}-${String(Math.min(today.getDate() + 2, 28)).padStart(2, '0')}`, type: 'Task', title: 'Guide Briefing', detail: 'HQ Office', time: '18:00', status: 'Upcoming' },
    { id: 'TR3', date: `${y}-${m}-${String(Math.min(today.getDate() + 3, 28)).padStart(2, '0')}`, type: 'Trip', title: 'Italian Group', detail: 'Historic Cairo', pax: 15, status: 'Confirmed' },
];

export const CalendarViewPage: React.FC = () => {
    const navigate = useNavigate();
    const toast = useToastContext();
    const [currentDate, setCurrentDate] = useState(new Date());
    const [activities, setActivities] = useState<Activity[]>(initialData);
    const [selectedDay, setSelectedDay] = useState<string | null>(null);
    const [showModal, setShowModal] = useState(false);
    const [newEntry, setNewEntry] = useState({ type: 'Trip', title: '', detail: '', time: '' });

    const getDaysInMonth = (date: Date) => {
        const year = date.getFullYear();
        const month = date.getMonth();
        const firstDay = new Date(year, month, 1).getDay();
        const numDays = new Date(year, month + 1, 0).getDate();
        const days: (Date | null)[] = [];
        for (let i = 0; i < firstDay; i++) days.push(null);
        for (let i = 1; i <= numDays; i++) days.push(new Date(year, month, i));
        return days;
    };

    const calendarHeader = currentDate.toLocaleString('default', { month: 'long', year: 'numeric' });
    const days = getDaysInMonth(currentDate);
    const todayStr = new Date().toISOString().split('T')[0];

    const changeMonth = (offset: number) => {
        setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + offset, 1));
    };

    const handleDayClick = (dayStr: string) => {
        setSelectedDay(dayStr);
        setShowModal(true);
    };

    const handleAddEntry = () => {
        if (!newEntry.title || !selectedDay) return;
        const entry: Activity = {
            id: `custom-${Date.now()}`,
            date: selectedDay,
            type: newEntry.type as 'Trip' | 'Task',
            title: newEntry.title,
            detail: newEntry.detail,
            time: newEntry.time,
            status: 'Pending'
        };
        setActivities(prev => [...prev, entry]);
        setShowModal(false);
        setNewEntry({ type: 'Trip', title: '', detail: '', time: '' });
        toast.success('Entry Added', `"${entry.title}" was added to ${formatDate(selectedDay)}.`);
    };

    const recentActivities = [...activities].sort((a, b) => a.date.localeCompare(b.date)).slice(0, 4);

  return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => navigate('/operations')}
                            className="inline-flex items-center gap-2 text-blue-100 hover:text-white transition-colors group p-2 hover:bg-white/10 rounded-lg"
                        >
                            <ArrowLeft className="w-5 h-5 rtl-flip" />
                        </button>
                        <div>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Operations Calendar</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">Monthly overview of trips, tasks, and resource allocation</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-2 mt-4 sm:mt-0 bg-white/10 p-1.5 rounded-xl backdrop-blur-sm">
                        <button className="p-2 hover:bg-white/20 rounded-lg transition-colors" onClick={() => changeMonth(-1)}><ChevronLeft className="w-4 h-4 rtl-flip" /></button>
                        <span className="text-sm font-bold min-w-[120px] text-center">{calendarHeader}</span>
                        <button className="p-2 hover:bg-white/20 rounded-lg transition-colors" onClick={() => changeMonth(1)}><ChevronRight className="w-4 h-4 rtl-flip" /></button>
                        <button className="ml-2 font-bold uppercase tracking-tight text-[10px] px-4 py-2 bg-white text-blue-600 rounded-lg shadow hover:bg-blue-50 transition-colors" onClick={() => setCurrentDate(new Date())}>Today</button>
                    </div>
                </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {/* Calendar Grid */}
                <div className="lg:col-span-3">
                    <Card className="overflow-hidden border-none shadow-xl">
                        <div className="grid grid-cols-7 bg-gray-50 dark:bg-gray-800/50 border-b border-gray-100 dark:border-gray-800">
                            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
                                <div key={d} className="py-2.5 text-center text-[10px] font-black uppercase tracking-widest text-gray-400">{d}</div>
                            ))}
                        </div>
                        <div className="grid grid-cols-7 bg-white dark:bg-gray-900">
                            {days.map((day, i) => {
                                const dayStr = day ? day.toISOString().split('T')[0] : '';
                                const dayActivities = activities.filter(a => a.date === dayStr);
                                const isToday = dayStr === todayStr;

                                return (
                                    <div
                                        key={i}
                                        onClick={() => day && handleDayClick(dayStr)}
                                        className={`min-h-[120px] border-r border-b border-gray-50 dark:border-gray-800 p-2 transition-colors group
                                            ${day ? 'cursor-pointer hover:bg-blue-50/40 dark:hover:bg-blue-900/10' : 'bg-gray-50/20 dark:bg-gray-800/10'}`}
                                    >
                                        {day && (
                                            <>
                                                <div className="flex justify-between items-center mb-1.5">
                                                    <span className={`text-xs font-bold px-1.5 py-0.5 rounded-full ${isToday ? 'bg-indigo-600 text-white' : 'text-gray-400'}`}>
                                                        {day.getDate()}
                                                    </span>
                                                    <span className="opacity-0 group-hover:opacity-100 transition-opacity">
                                                        <Plus size={12} className="text-gray-400 hover:text-blue-500" />
                                                    </span>
                                                </div>
                                                <div className="space-y-1">
                                                    {dayActivities.map(activity => (
                                                        <div
                                                            key={activity.id}
                                                            className={`p-1.5 rounded text-[10px] leading-tight font-medium border ${activity.type === 'Trip'
                                                                ? 'bg-blue-50 border-blue-100 text-blue-700 dark:bg-blue-900/20 dark:border-blue-900/30 dark:text-blue-300'
                                                                : 'bg-indigo-50 border-indigo-100 text-indigo-700 dark:bg-indigo-900/20 dark:border-indigo-900/30 dark:text-indigo-300'
                                                                }`}
                                                        >
                                                            <div className="flex items-center justify-between">
                                                                <span className="truncate pr-1">{activity.title}</span>
                                                                <span className="font-bold opacity-60 uppercase tracking-tighter text-[8px] flex-shrink-0">
                                                                    {activity.type === 'Trip' ? 'TRP' : 'TSK'}
                                                                </span>
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                            </>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    </Card>
                    <p className="text-center text-xs text-gray-400 mt-2">💡 Click on any day to add a trip or task</p>
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                    <Card>
                        <CardHeader className="pb-2 flex flex-row items-center justify-between">
                            <CardTitle className="text-sm font-bold uppercase tracking-wider">Legend</CardTitle>
                            <Layers size={14} className="text-gray-400" />
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <div className="flex items-center space-x-3">
                                <div className="w-3 h-3 bg-blue-500 rounded"></div>
                                <span className="text-xs font-semibold text-gray-700 dark:text-gray-300">Active Trip</span>
                            </div>
                            <div className="flex items-center space-x-3">
                                <div className="w-3 h-3 bg-indigo-500 rounded"></div>
                                <span className="text-xs font-semibold text-gray-700 dark:text-gray-300">Field Task</span>
                            </div>
                            <div className="flex items-center space-x-3">
                                <div className="w-3 h-3 bg-red-400 rounded"></div>
                                <span className="text-xs font-semibold text-gray-700 dark:text-gray-300">Alert / Delay</span>
                            </div>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader className="pb-2">
                            <CardTitle className="text-sm font-bold uppercase tracking-wider">Quick Details</CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                            <div className="p-4 space-y-4">
                                {recentActivities.map(item => (
                                    <div key={item.id} className="group">
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <p className="text-[10px] font-bold text-gray-400 uppercase leading-none mb-1">{formatDate(item.date)}</p>
                                                <h6 className="text-sm font-bold text-gray-900 dark:text-white group-hover:text-blue-600 transition-colors uppercase">{item.title}</h6>
                                            </div>
                                            <button className="text-gray-300 hover:text-gray-600"><MoreHorizontal size={14} /></button>
                                        </div>
                                        <div className="flex items-center mt-1 text-[11px] text-gray-500">
                                            {item.type === 'Trip' ? <MapPin size={10} className="mr-1.5" /> : <Clock size={10} className="mr-1.5" />}
                                            {item.detail}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>

            {/* Add Entry Modal */}
            {showModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
                    <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full max-w-md mx-4 p-6 space-y-5">
                        <div className="flex items-center justify-between">
                            <div>
                                <h2 className="text-lg font-bold text-gray-900 dark:text-white">Add to Calendar</h2>
                                <p className="text-xs text-gray-500">{selectedDay ? formatDate(selectedDay) : ''}</p>
                            </div>
                            <button onClick={() => setShowModal(false)} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
                                <X size={18} />
                            </button>
                        </div>

                        <Select
                            label="Entry Type"
                            value={newEntry.type}
                            onChange={e => setNewEntry(prev => ({ ...prev, type: e.target.value }))}
                        >
                            <option value="Trip">🗺️ Trip</option>
                            <option value="Task">✅ Task</option>
                        </Select>

                        <Input
                            label="Title *"
                            value={newEntry.title}
                            onChange={e => setNewEntry(prev => ({ ...prev, title: e.target.value }))}
                            placeholder={newEntry.type === 'Trip' ? 'e.g. Ahmed Hassan Group' : 'e.g. Airport Pickup'}
                        />

                        <Input
                            label="Location / Detail"
                            value={newEntry.detail}
                            onChange={e => setNewEntry(prev => ({ ...prev, detail: e.target.value }))}
                            placeholder={newEntry.type === 'Trip' ? 'e.g. Cairo & Luxor' : 'e.g. Terminal 3'}
                        />

                        {newEntry.type === 'Task' && (
                            <Input
                                label="Time"
                                type="time"
                                value={newEntry.time}
                                onChange={e => setNewEntry(prev => ({ ...prev, time: e.target.value }))}
                            />
                        )}

                        <div className="flex space-x-3 pt-2">
                            <Button variant="outline" className="flex-1" onClick={() => setShowModal(false)}>Cancel</Button>
                            <Button
                                className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                                onClick={handleAddEntry}
                                disabled={!newEntry.title}
                            >
                                <Plus size={16} className="mr-2" />
                                Add Entry
                            </Button>
                        </div>
                    </div>
                </div>
            )}
        </div>
        </div>
    );
};
