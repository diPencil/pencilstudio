import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Clock, AlertTriangle, CheckCircle, Phone, Mail, TrendingUp, Star, Search } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { Input } from '../ui/Input';
import { Card, CardContent } from '../ui/Card';
import { StatCard } from '../ui/StatCard';
import { mockSuppliers, mockReservations, mockItems } from '../../services/mockData';
import { useToastContext } from '../../contexts/ToastContext';
import { useLocale } from '../../localization/useLocale';
import { TableActionsDropdown } from '../ui/TableActionsDropdown';

export const SupplierTrackerPage: React.FC = () => {
    const navigate = useNavigate();
    const { isRTL, t, direction } = useLocale();
    
    const [supplierFilter] = useState('All Suppliers');
    const [searchTerm, setSearchTerm] = useState('');
    const [typeFilter, setTypeFilter] = useState('All Types');
    const [statusFilter, setStatusFilter] = useState('All Status');
    const [destinationFilter] = useState('All Destinations');
    const [riskFilter] = useState('All Risk');
    const [requestActions, setRequestActions] = useState<Record<string, string>>({});

    const getResponseRateColor = (rate: number) => {
        if (rate >= 95) return 'text-emerald-600';
        if (rate >= 85) return 'text-amber-600';
        return 'text-rose-600';
    };

    const getRiskLabel = (score = 0) => {
        if (score < 70) return { label: t('supplier.tracker.risk.high'), className: 'bg-rose-50 text-rose-700 border-rose-100 dark:bg-rose-950/20 dark:text-rose-400 dark:border-rose-900/30' };
        if (score < 85) return { label: t('supplier.tracker.risk.monitor'), className: 'bg-amber-50 text-amber-700 border-amber-100 dark:bg-amber-950/20 dark:text-amber-400 dark:border-amber-900/30' };
        return { label: t('supplier.tracker.risk.healthy'), className: 'bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-950/20 dark:text-emerald-400 dark:border-emerald-900/30' };
    };

    const getTranslatedType = (type: string) => {
        if (type === 'Hotel') return t('supplier.type.hotel');
        if (type === 'Airline') return t('supplier.type.airline');
        if (type === 'Tour Operator') return t('supplier.type.tourOperator');
        if (type === 'Cruise Line') return t('supplier.type.cruiseLine');
        return type;
    };

    const formatDaysString = (str: string | undefined | null) => {
        if (!str) return '-';
        if (str.toLowerCase().includes('days')) {
            const val = str.replace(/days/i, '').trim();
            return `${val} ${t('supplier.tracker.days')}`;
        }
        return str;
    };

    const supplierServiceText = (supplierId: string) => mockItems
        .filter(item => item.supplierId === supplierId)
        .map(item => `${item.name} ${item.categoryType} ${item.destination || ''}`)
        .join(' ');

    const filteredSuppliers = mockSuppliers.filter(s => {
        const matchesSupplier = supplierFilter === 'All Suppliers' || s.name === supplierFilter;
        const matchesType = typeFilter === 'All Types' || s.type === typeFilter;
        const matchesStatus = statusFilter === 'All Status' || s.status === statusFilter;
        const matchesDestination = destinationFilter === 'All Destinations' || (s.destinations || []).includes(destinationFilter);
        const matchesRisk = riskFilter === 'All Risk' || (riskFilter === 'High' ? (s.performance?.qualityScore || 0) < 70 : riskFilter === 'Medium' ? (s.performance?.qualityScore || 0) >= 70 && (s.performance?.qualityScore || 0) < 85 : (s.performance?.qualityScore || 0) >= 85);
        const contactText = (s.contacts || []).map(c => `${c.name} ${c.role} ${c.email || ''} ${c.phone || ''}`).join(' ');
        const matchesSearch = [s.name, s.email, s.phone, s.location, contactText, supplierServiceText(s.id), ...(s.destinations || [])].join(' ').toLowerCase().includes(searchTerm.toLowerCase());
        return matchesSupplier && matchesType && matchesStatus && matchesDestination && matchesRisk && matchesSearch;
    });

    const metrics = {
        total: mockSuppliers.length,
        active: mockSuppliers.filter(s => s.status === 'Active').length,
        pending: mockSuppliers.reduce((acc, s) => acc + (s.pendingRequests || 0), 0),
        critical: mockSuppliers.reduce((acc, s) => acc + (s.overdueRequests || 0), 0),
        avgTime: (mockSuppliers.reduce((acc, s) => acc + (s.performance?.responseTimeDays || 0), 0) / (mockSuppliers.length || 1)).toFixed(1),
        topSupplier: mockSuppliers.reduce((best, s) => (s.rating || 0) > (best.rating || 0) ? s : best, mockSuppliers[0]).name
    };

    return (
        <div className="w-full pb-8">
            {/* Header */}
            <div className="mx-auto max-w-[1400px]">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8">
                    <div className="flex min-w-0 items-center space-x-4 rtl:space-x-reverse">
                        <Button variant="ghost" size="sm" onClick={() => navigate('/reservations')} className="p-2 text-blue-100 hover:text-white hover:bg-white/10">
                            <ArrowLeft size={20} className="rtl-flip" />
                        </Button>
                        <div className="min-w-0">
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">{t('supplier.tracker.title')}</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">{t('supplier.tracker.subtitle')}</p>
                        </div>
                    </div>
                    <Button className="bg-white text-blue-600 hover:bg-gray-50 mt-4 sm:mt-0" onClick={() => navigate('/reservations/new-supplier')}>
                        <CheckCircle className="h-4 w-4 mr-2 rtl-flip" />
                        {t('supplier.tracker.newSupplier')}
                    </Button>
                </div>

            {/* Summary */}
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
                <StatCard label={t('supplier.tracker.pendingRequests')} value={metrics.pending} icon={Clock} iconColor="text-blue-500" iconBg="bg-blue-50 dark:bg-blue-900/20" />
                <StatCard label={t('supplier.tracker.avgResponse')} value={`${metrics.avgTime} ${t('supplier.tracker.days')}`} icon={TrendingUp} iconColor="text-emerald-500" iconBg="bg-emerald-50 dark:bg-emerald-900/20" />
                <StatCard label={t('supplier.tracker.topPartner')} value={metrics.topSupplier} icon={Star} iconColor="text-purple-500" iconBg="bg-purple-50 dark:bg-purple-900/20" />
                <StatCard label={t('supplier.tracker.criticalOverdue')} value={metrics.critical} icon={AlertTriangle} iconColor="text-rose-500" iconBg="bg-rose-50 dark:bg-rose-900/20" />
            </div>

            {/* Filters */}
            <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900 mb-8">
                <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-4 rtl:md:space-x-reverse">
                        <div className="flex-1 w-full relative">
                            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400`} />
                            <Input
                                placeholder={t('supplier.tracker.searchPlaceholder')}
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className={isRTL ? 'pr-10 pl-4' : 'pl-10 pr-4'}
                            />
                        </div>
                        <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="w-full md:w-48">
                            <option value="All Types">{t('supplier.tracker.filter.allTypes')}</option>
                            {[...new Set(mockSuppliers.map(s => s.type))].map(t => (
                                <option key={t} value={t}>{getTranslatedType(t)}</option>
                            ))}
                        </Select>
                        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="w-full md:w-48">
                            <option value="All Status">{t('supplier.tracker.filter.allStatus')}</option>
                            <option value="Active">{t('common.active')}</option>
                            <option value="Onboarding">{t('supplier.tracker.status.onboarding')}</option>
                            <option value="Inactive">{t('common.inactive')}</option>
                        </Select>
                    </div>
                </CardContent>
            </Card>

            <div className="table-container mt-4 max-w-full">
                <table style={{ direction }} className="table-premium">
                    <thead>
                        <tr>
                            <th className="logical-start">{t('supplier.tracker.table.partner')}</th>
                            <th className="logical-start">{t('supplier.tracker.table.volume')}</th>
                            <th className="logical-start">{t('supplier.tracker.table.performance')}</th>
                            <th className="logical-start">{t('supplier.tracker.table.responseRate')}</th>
                            <th className="logical-start">{t('common.status')}</th>
                            <th className="logical-start">{t('supplier.tracker.table.rating')}</th>
                            <th className="logical-end">{t('supplier.tracker.table.contact')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredSuppliers.map((s) => (
                            <tr key={s.id} className="hover:bg-gray-50 cursor-pointer" onClick={() => navigate(`/reservations/suppliers/${s.id}`)}>
                                <td className="logical-start">
                                    <div className="font-bold text-gray-900 dark:text-white">{s.name}</div>
                                    <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest ltr-value inline-block">{s.id}</div>
                                    <div className="mt-1 text-[11px] text-gray-500">{(s.destinations || []).join(', ')}</div>
                                </td>
                                <td className="logical-start"><div className="text-sm font-medium bidi-isolate">{s.totalRequests ?? 0} {t('supplier.tracker.requests')}</div></td>
                                <td className="logical-start">
                                    <div className="text-xs font-bold text-gray-900 dark:text-white ltr-value inline-block">{formatDaysString(s.avgResponseTime)}</div>
                                    <div className="text-[10px] text-gray-500">{t('supplier.tracker.avgResponse')}</div>
                                </td>
                                <td className="logical-start">
                                    <div className={`text-sm font-bold ltr-value inline-block ${getResponseRateColor(s.responseRate || 0)}`}>{s.responseRate}%</div>
                                    <div className="w-16 bg-gray-100 dark:bg-gray-800 rounded-full h-1 mt-1 overflow-hidden">
                                        <div className={`h-full ${s.responseRate && s.responseRate >= 95 ? 'bg-emerald-500' : s.responseRate && s.responseRate >= 85 ? 'bg-amber-500' : 'bg-rose-500'}`} style={{ width: `${s.responseRate || 0}%` }} />
                                    </div>
                                </td>
                                <td className="logical-start">
                                    <div className="flex flex-col space-y-1">
                                        <span className={`inline-flex w-fit rounded-full border px-2 py-0.5 text-[10px] font-bold ${getRiskLabel(s.performance?.qualityScore).className}`}>
                                            {getRiskLabel(s.performance?.qualityScore).label}
                                        </span>
                                        <div className="text-[10px] font-bold text-blue-600 bidi-isolate">{s.pendingRequests ?? 0} {t('supplier.tracker.status.pending')}</div>
                                        {s.overdueRequests > 0 && <div className="text-[10px] font-bold text-rose-600 bidi-isolate">{s.overdueRequests} {t('supplier.tracker.status.overdue')}</div>}
                                    </div>
                                </td>
                                <td className="logical-start">
                                    <div className="flex items-center space-x-1 rtl:space-x-reverse">
                                        <Star className="h-3 w-3 text-amber-400 fill-amber-400" />
                                        <span className="text-sm font-bold bidi-isolate">{s.rating}</span>
                                    </div>
                                </td>
                                <td className="logical-end" onClick={(e) => e.stopPropagation()}>
                                    <TableActionsDropdown
                                        actions={[
                                            { label: `${t('supplier.tracker.call')} ${s.name}`, icon: Phone, onClick: () => { window.location.href = `tel:${s.phone || ''}`; } },
                                            { label: `${t('supplier.tracker.email')} ${s.name}`, icon: Mail, onClick: () => { window.location.href = `mailto:${s.email || ''}`; } }
                                        ]}
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Detailed Pending Requests */}
            <div className="mt-8 space-y-6">
                <div className="flex items-center justify-between">
                    <h2 className="text-lg font-bold text-gray-900 dark:text-white">{t('supplier.tracker.criticalPending')}</h2>
                    <span className="px-2 py-0.5 bg-rose-50 text-rose-600 text-[10px] font-bold rounded uppercase tracking-wider">{t('supplier.tracker.attentionRequired')}</span>
                </div>
                <div className="table-container max-w-full">
                    <table style={{ direction }} className="table-premium">
                        <thead>
                            <tr>
                                <th className="logical-start">{t('supplier.tracker.table.bookingRef')}</th>
                                <th className="logical-start">{t('supplier.tracker.table.supplier')}</th>
                                <th className="logical-start">{t('supplier.tracker.table.service')}</th>
                                <th className="logical-start">{t('supplier.tracker.table.waitTime')}</th>
                                <th className="logical-start">{t('supplier.tracker.table.priority')}</th>
                                <th className="logical-end">{t('common.actions')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {mockReservations.filter(r => r.status === 'Pending' || r.status === 'Awaiting Supplier').map((r) => (
                                <tr key={r.id}>
                                    <td className="logical-start"><div className="font-bold ltr-value inline-block">{r.id}</div></td>
                                    <td className="logical-start"><div className="text-xs">{r.supplier}</div></td>
                                    <td className="logical-start"><div className="text-xs">{r.tripItem}</div></td>
                                    <td className="logical-start">
                                        <div className="text-xs text-rose-600 font-bold bidi-isolate">
                                            {requestActions[r.id] === 'escalated' ? t('supplier.tracker.action.escalated') :
                                             requestActions[r.id] === 'confirmed' ? t('supplier.tracker.action.forceConfirmed') :
                                             t('supplier.tracker.status.overdue48h')}
                                        </div>
                                    </td>
                                    <td className="logical-start">
                                        <span className="px-1.5 py-0.5 bg-rose-50 text-rose-600 text-[9px] font-bold rounded uppercase">
                                            {t('supplier.tracker.priority.high')}
                                        </span>
                                    </td>
                                     <td className="logical-end">
                                        <TableActionsDropdown
                                            actions={[
                                                { label: t('supplier.tracker.action.escalate'), icon: AlertTriangle, onClick: () => setRequestActions(prev => ({ ...prev, [r.id]: 'escalated' })) },
                                                { label: t('supplier.tracker.action.forceConfirm'), icon: CheckCircle, onClick: () => setRequestActions(prev => ({ ...prev, [r.id]: 'confirmed' })) }
                                            ]}
                                        />
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            </div>
        </div>
    );
};
