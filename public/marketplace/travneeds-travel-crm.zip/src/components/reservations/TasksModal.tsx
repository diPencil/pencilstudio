import React, { useState } from 'react';
import { X, Calendar, Clock, AlertTriangle, CheckCircle, Plus, Edit, Save } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { formatDate } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { ReservationTask } from './ReservationsPage';

interface TasksModalProps {
  isOpen: boolean;
  onClose: () => void;
  tasks: ReservationTask[];
  onTaskUpdate: (tasks: ReservationTask[]) => void;
}

export const TasksModal: React.FC<TasksModalProps> = ({ 
  isOpen, 
  onClose, 
  tasks, 
  onTaskUpdate 
}) => {
  const { t, dir } = useLocale();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [isNewTaskModalOpen, setIsNewTaskModalOpen] = useState(false);
  const [isEditTaskModalOpen, setIsEditTaskModalOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<ReservationTask | null>(null);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Overdue': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      case 'Due Today': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'Completed': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'Pending': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Critical': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      case 'High': return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'Low': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const translateStatus = (status: string) => {
    switch (status) {
      case 'Overdue': return t('reservations.taskStatus.overdue');
      case 'Due Today': return t('reservations.taskStatus.dueToday');
      case 'Completed': return t('reservations.taskStatus.completed');
      case 'Pending': return t('reservations.taskStatus.pending');
      default: return status;
    }
  };

  const translatePriority = (priority: string) => {
    switch (priority) {
      case 'Critical': return t('reservations.priority.critical');
      case 'High': return t('reservations.priority.high');
      case 'Medium': return t('reservations.priority.medium');
      case 'Low': return t('reservations.priority.low');
      default: return priority;
    }
  };

  const translateAgent = (agent: string) => {
    switch (agent) {
      case 'Super Admin': return t('reservations.agent.superadmin');
      case 'Mahmoud Khalil': return t('reservations.agent.mahmoud');
      case 'Layla Ramadan': return t('reservations.agent.layla');
      case 'Sami Youssef': return t('reservations.agent.sami');
      case 'Mona Zaki': return t('reservations.agent.mona');
      default: return agent;
    }
  };

  const handleCompleteTask = (taskId: string) => {
    const updatedTasks = tasks.map(task => 
      task.id === taskId ? { ...task, status: 'Completed' } : task
    );
    onTaskUpdate(updatedTasks);
  };

  const handleEditTask = (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    setSelectedTask(task);
    setIsEditTaskModalOpen(true);
  };

  const handleCreateTask = () => {
    setIsNewTaskModalOpen(true);
  };

  const handleSaveTask = async (taskData: Partial<ReservationTask>) => {
    // In real app, save to Supabase
    console.log('Saving task:', taskData);
    setIsNewTaskModalOpen(false);
  };

  const handleUpdateTask = async (taskData: ReservationTask) => {
    const updatedTasks = tasks.map(task => 
      task.id === taskData.id ? { ...task, ...taskData } : task
    );
    onTaskUpdate(updatedTasks);
    setIsEditTaskModalOpen(false);
  };

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         task.customer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || task.status === statusFilter;
    const matchesPriority = priorityFilter === 'All' || task.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const todaysTasks = filteredTasks.filter(task => {
    const today = new Date().toISOString().split('T')[0];
    return task.dueDate === today || task.status === 'Overdue';
  });

  const overdueTasks = todaysTasks.filter(task => task.status === 'Overdue');
  const dueTodayTasks = todaysTasks.filter(task => task.status === 'Due Today');
  const completedTasks = todaysTasks.filter(task => task.status === 'Completed');

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 overflow-y-auto" dir={dir}>
        <div className="flex min-h-screen items-center justify-center p-4">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
          <div className="relative w-full max-w-6xl bg-white dark:bg-gray-800 rounded-lg shadow-xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center gap-3">
                <Calendar className="h-6 w-6 text-blue-500" />
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  {t('reservations.modal.tasksTitleCount').replace('{count}', String(todaysTasks.length))}
                </h2>
              </div>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X size={24} />
              </button>
            </div>

            <div className="p-6">
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-red-600 dark:text-red-400">{t('reservations.modal.overdueTasks')}</p>
                      <p className="text-2xl font-bold text-red-800 dark:text-red-300">
                        {overdueTasks.length}
                      </p>
                    </div>
                    <AlertTriangle className="h-8 w-8 text-red-500" />
                  </div>
                </div>

                <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-yellow-600 dark:text-yellow-400">{t('reservations.modal.dueTodayTasks')}</p>
                      <p className="text-2xl font-bold text-yellow-800 dark:text-yellow-300">
                        {dueTodayTasks.length}
                      </p>
                    </div>
                    <Clock className="h-8 w-8 text-yellow-500" />
                  </div>
                </div>

                <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-green-600 dark:text-green-400">{t('reservations.modal.completedTasks')}</p>
                      <p className="text-2xl font-bold text-green-800 dark:text-green-300">
                        {completedTasks.length}
                      </p>
                    </div>
                    <CheckCircle className="h-8 w-8 text-green-500" />
                  </div>
                </div>
              </div>

              {/* Filters */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
                <div className="relative flex-1 max-w-md">
                  <Input
                    placeholder={t('reservations.modal.searchTasks')}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="flex items-center gap-3 mt-4 sm:mt-0">
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="All">{t('reservations.taskStatus.all')}</option>
                    <option value="Overdue">{t('reservations.taskStatus.overdue')}</option>
                    <option value="Due Today">{t('reservations.taskStatus.dueToday')}</option>
                    <option value="Completed">{t('reservations.taskStatus.completed')}</option>
                  </select>
                  <select
                    value={priorityFilter}
                    onChange={(e) => setPriorityFilter(e.target.value)}
                    className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="All">{t('reservations.priority.all')}</option>
                    <option value="Critical">{t('reservations.priority.critical')}</option>
                    <option value="High">{t('reservations.priority.high')}</option>
                    <option value="Medium">{t('reservations.priority.medium')}</option>
                    <option value="Low">{t('reservations.priority.low')}</option>
                  </select>
                  <Button size="sm" onClick={handleCreateTask}>
                    <Plus className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                    {t('reservations.modal.createTask')}
                  </Button>
                </div>
              </div>

              {/* Tasks Table */}
              <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                      <tr>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('reservations.modal.colTask')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('reservations.table.customer')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('reservations.table.bookingId')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('reservations.modal.colDueDate')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('reservations.modal.colPriority')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('reservations.modal.colStatus')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('reservations.modal.colAssignedTo')}
                        </th>
                        <th className="px-6 py-3 text-left rtl:text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                          {t('reservations.modal.colActions')}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                      {todaysTasks.map((task) => (
                        <tr key={task.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                          <td className="px-6 py-4">
                            <div>
                              <div className="text-sm font-medium text-gray-900 dark:text-white">
                                {task.title}
                              </div>
                              <div className="text-sm text-gray-500 dark:text-gray-400 truncate max-w-xs">
                                {task.description}
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                            {task.customer}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <button className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 font-medium">
                              <span className="bidi-isolate">{task.bookingId}</span>
                            </button>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            <span className="bidi-isolate">{formatDate(task.dueDate)}</span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getPriorityColor(task.priority)}`}>
                              {translatePriority(task.priority)}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(task.status)}`}>
                              {translateStatus(task.status)}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            {translateAgent(task.assignedTo)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            <div className="flex gap-2">
                              <button 
                                onClick={() => handleEditTask(task.id)}
                                className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300 p-1 rounded hover:bg-green-50 dark:hover:bg-green-900/20 transition-colors"
                                title={t('reservations.modal.editTask')}
                              >
                                <Edit className="h-4 w-4" />
                              </button>
                              {task.status !== 'Completed' && (
                                <button 
                                  onClick={() => handleCompleteTask(task.id)}
                                  className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 p-1 rounded hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors"
                                  title={t('reservations.modal.markComplete')}
                                >
                                  <CheckCircle className="h-4 w-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {todaysTasks.length === 0 && (
                <div className="text-center py-12">
                  <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    {t('reservations.modal.noTasksTitle')}
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    {t('reservations.modal.noTasksDesc')}
                  </p>
                </div>
              )}

              <div className="flex justify-end mt-6">
                <Button onClick={onClose}>
                  {t('reservations.modal.close')}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* New Task Modal */}
      {isNewTaskModalOpen && (
        <div className="fixed inset-0 z-[60] overflow-y-auto" dir={dir}>
          <div className="flex min-h-screen items-center justify-center p-4">
            <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setIsNewTaskModalOpen(false)} />
            <div className="relative w-full max-w-lg bg-white dark:bg-gray-800 rounded-lg shadow-xl">
              <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{t('reservations.modal.createTaskTitle')}</h3>
                <button onClick={() => setIsNewTaskModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                  <X size={24} />
                </button>
              </div>
              <div className="p-6">
                <form onSubmit={(e) => { e.preventDefault(); handleSaveTask({}); }}>
                  <div className="space-y-4">
                    <Input label={t('reservations.modal.taskName')} placeholder={t('reservations.modal.taskName').replace(' *', '')} required />
                    <Input label={t('reservations.modal.taskCustomer')} placeholder={t('reservations.modal.taskCustomer')} required />
                    <Input label={t('reservations.modal.taskBookingId')} placeholder={t('reservations.modal.taskBookingId')} />
                    <Input type="date" label={t('reservations.modal.taskDueDate')} required />
                    <Select label={t('reservations.modal.taskPriority')}>
                      <option value="Low">{t('reservations.priority.low')}</option>
                      <option value="Medium">{t('reservations.priority.medium')}</option>
                      <option value="High">{t('reservations.priority.high')}</option>
                      <option value="Critical">{t('reservations.priority.critical')}</option>
                    </Select>
                    <Select label={t('reservations.modal.taskAssignedTo')}>
                      <option value="Super Admin">{t('reservations.agent.superadmin')}</option>
                      <option value="Mahmoud Khalil">{t('reservations.agent.mahmoud')}</option>
                      <option value="Layla Ramadan">{t('reservations.agent.layla')}</option>
                      <option value="Sami Youssef">{t('reservations.agent.sami')}</option>
                      <option value="Mona Zaki">{t('reservations.agent.mona')}</option>
                    </Select>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        {t('reservations.modal.taskDescription')}
                      </label>
                      <textarea
                        rows={3}
                        className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder={t('reservations.modal.taskDescriptionPlaceholder')}
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-3 mt-6">
                    <Button type="button" variant="outline" onClick={() => setIsNewTaskModalOpen(false)}>
                      {t('reservations.modal.cancel')}
                    </Button>
                    <Button type="submit">
                      <Plus className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                      {t('reservations.modal.createTaskBtn')}
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Task Modal */}
      {isEditTaskModalOpen && selectedTask && (
        <div className="fixed inset-0 z-[60] overflow-y-auto" dir={dir}>
          <div className="flex min-h-screen items-center justify-center p-4">
            <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setIsEditTaskModalOpen(false)} />
            <div className="relative w-full max-w-lg bg-white dark:bg-gray-800 rounded-lg shadow-xl">
              <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{t('reservations.modal.editTaskTitle')}</h3>
                <button onClick={() => setIsEditTaskModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                  <X size={24} />
                </button>
              </div>
              <div className="p-6">
                <form onSubmit={(e) => { e.preventDefault(); handleUpdateTask(selectedTask); }}>
                  <div className="space-y-4">
                    <Input label={t('reservations.modal.taskName')} defaultValue={selectedTask.title} required />
                    <Input label={t('reservations.modal.taskCustomer')} defaultValue={selectedTask.customer} required />
                    <Input label={t('reservations.modal.taskBookingId')} defaultValue={selectedTask.bookingId} />
                    <Input type="date" label={t('reservations.modal.taskDueDate')} defaultValue={selectedTask.dueDate} required />
                    <Select label={t('reservations.modal.taskPriority')} defaultValue={selectedTask.priority}>
                      <option value="Low">{t('reservations.priority.low')}</option>
                      <option value="Medium">{t('reservations.priority.medium')}</option>
                      <option value="High">{t('reservations.priority.high')}</option>
                      <option value="Critical">{t('reservations.priority.critical')}</option>
                    </Select>
                    <Select label={t('reservations.modal.taskStatus')} defaultValue={selectedTask.status}>
                      <option value="Pending">{t('reservations.taskStatus.pending')}</option>
                      <option value="Due Today">{t('reservations.taskStatus.dueToday')}</option>
                      <option value="Overdue">{t('reservations.taskStatus.overdue')}</option>
                      <option value="Completed">{t('reservations.taskStatus.completed')}</option>
                    </Select>
                    <Select label={t('reservations.modal.taskAssignedTo')} defaultValue={selectedTask.assignedTo}>
                      <option value="Super Admin">{t('reservations.agent.superadmin')}</option>
                      <option value="Mahmoud Khalil">{t('reservations.agent.mahmoud')}</option>
                      <option value="Layla Ramadan">{t('reservations.agent.layla')}</option>
                      <option value="Sami Youssef">{t('reservations.agent.sami')}</option>
                      <option value="Mona Zaki">{t('reservations.agent.mona')}</option>
                    </Select>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        {t('reservations.modal.taskDescription')}
                      </label>
                      <textarea
                        rows={3}
                        defaultValue={selectedTask.description}
                        className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder={t('reservations.modal.taskDescriptionPlaceholder')}
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-3 mt-6">
                    <Button type="button" variant="outline" onClick={() => setIsEditTaskModalOpen(false)}>
                      {t('reservations.modal.cancel')}
                    </Button>
                    <Button type="submit">
                      <Save className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                      {t('reservations.modal.updateTaskBtn')}
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};