import React, { useState } from 'react';
import { X, Save, Building } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';

interface AddSupplierModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (supplierData: any) => Promise<void>;
}

const supplierTypes = [
    'Hotel', 'Airline', 'Tour Operator', 'Activity Provider', 'Car Rental',
    'Transportation', 'Restaurant', 'Event Organizer', 'Cruise Line', 'Other'
];

export const AddSupplierModal: React.FC<AddSupplierModalProps> = ({ isOpen, onClose, onSave }) => {
    const [formData, setFormData] = useState({
        name: '',
        type: 'Hotel',
        email: '',
        phone: '',
        location: ''
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(false);

    const validateForm = () => {
        const newErrors: Record<string, string> = {};

        if (!formData.name.trim()) {
            newErrors.name = 'Supplier name is required';
        }

        if (!formData.email.trim()) {
            newErrors.email = 'Email is required';
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
            newErrors.email = 'Please enter a valid email address';
        }

        if (!formData.phone.trim()) {
            newErrors.phone = 'Phone number is required';
        }

        if (!formData.location.trim()) {
            newErrors.location = 'Location is required';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!validateForm()) {
            return;
        }

        setIsLoading(true);
        try {
            await onSave(formData);
            setFormData({
                name: '',
                type: 'Hotel',
                email: '',
                phone: '',
                location: ''
            });
            setErrors({});
            onClose();
        } catch (error) {
            console.error('Error saving supplier:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleInputChange = (field: string, value: string) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        if (errors[field]) {
            setErrors(prev => ({ ...prev, [field]: '' }));
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 overflow-y-auto">
            <div className="flex min-h-screen items-center justify-center p-4">
                <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
                <div className="relative w-full max-w-lg bg-white dark:bg-gray-800 rounded-lg shadow-xl overflow-hidden">
                    <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
                        <div className="flex items-center space-x-3">
                            <Building className="h-6 w-6 text-blue-500" />
                            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                                Add New Supplier
                            </h2>
                        </div>
                        <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                            <X size={24} />
                        </button>
                    </div>

                    <form onSubmit={handleSubmit} className="p-6 space-y-4">
                        <Input
                            label="Supplier Name *"
                            value={formData.name}
                            onChange={(e) => handleInputChange('name', e.target.value)}
                            error={errors.name}
                            placeholder="Enter supplier name"
                        />

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Select
                                label="Type"
                                value={formData.type}
                                onChange={(e) => handleInputChange('type', e.target.value)}
                            >
                                {supplierTypes.map(type => (
                                    <option key={type} value={type}>{type}</option>
                                ))}
                            </Select>

                            <Input
                                label="Location *"
                                value={formData.location}
                                onChange={(e) => handleInputChange('location', e.target.value)}
                                error={errors.location}
                                placeholder="Enter location"
                            />
                        </div>

                        <Input
                            label="Contact Email *"
                            type="email"
                            value={formData.email}
                            onChange={(e) => handleInputChange('email', e.target.value)}
                            error={errors.email}
                            placeholder="Enter email address"
                        />

                        <Input
                            label="Phone *"
                            value={formData.phone}
                            onChange={(e) => handleInputChange('phone', e.target.value)}
                            error={errors.phone}
                            placeholder="Enter phone number"
                        />

                        <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200 dark:border-gray-700">
                            <Button type="button" variant="outline" onClick={onClose} disabled={isLoading}>
                                Cancel
                            </Button>
                            <Button type="submit" disabled={isLoading} loading={isLoading}>
                                <Save className="h-4 w-4 mr-2" />
                                Save Supplier
                            </Button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};
