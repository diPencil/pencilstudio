import React, { useState, useEffect } from 'react';
import { Upload, File, ArrowLeft } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { formatDate } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';
import { Reservation } from './ReservationsPage';

const documentTypes = [
  'Supplier Confirmation',
  'Hotel Voucher',
  'Flight Ticket',
  'Tour Confirmation',
  'Transfer Voucher',
  'Insurance Document',
  'Visa Document',
  'Payment Receipt',
  'Other'
];

export const UploadDocumentPage: React.FC = () => {
  const { t, direction, isRTL } = useLocale();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToastContext();

  const reservation = location.state?.reservation as Reservation;

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [documentType, setDocumentType] = useState('Supplier Confirmation');
  const [description, setDescription] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!reservation) {
      navigate('/reservations');
    }
  }, [reservation, navigate]);

  if (!reservation) return null;

  const getLocalizedDocType = (type: string) => {
    switch (type) {
      case 'Supplier Confirmation': return t('reservations.docType.supplierConf');
      case 'Hotel Voucher': return t('reservations.docType.hotelVoucher');
      case 'Flight Ticket': return t('reservations.docType.flightTicket');
      case 'Tour Confirmation': return t('reservations.docType.tourConf');
      case 'Transfer Voucher': return t('reservations.docType.transferVoucher');
      case 'Insurance Document': return t('reservations.docType.insuranceDoc');
      case 'Visa Document': return t('reservations.docType.visaDoc');
      case 'Payment Receipt': return t('reservations.docType.paymentReceipt');
      case 'Other': return t('reservations.docType.other');
      default: return type;
    }
  };

  const getLocalizedTripItem = (item: string) => {
    switch (item) {
      case 'Hotel: Steigenberger Luxor': return t('reservations.tripType.hotelSteigenberger');
      case 'Hotel: Hilton Aswan Resort': return t('reservations.tripType.hotelHilton');
      case 'Flight: CAI-LXR Economy': return t('reservations.tripType.flightCaiLxr');
      case 'Tour: Valley of Kings': return t('reservations.tripType.tourValley');
      case 'Activity: Nile Felucca Ride': return t('reservations.tripType.activityNile');
      case 'Package: Nile Cruise 4 Days': return t('reservations.tripType.packageNile');
      case 'Transport: Airport Transfer': return t('reservations.tripType.transportAirport');
      case 'Cruise: Red Sea Diving': return t('reservations.tripType.cruiseRedSea');
      default: return item;
    }
  };

  const getLocalizedSupplier = (supplier: string) => {
    switch (supplier) {
      case 'Steigenberger Hotels': return t('reservations.supplier.steigerberger');
      case 'Hilton Hotels': return t('reservations.supplier.hilton');
      case 'EgyptAir': return t('reservations.supplier.egyptair');
      case 'Cairo Tours': return t('reservations.supplier.cairotours');
      case 'Nile Cruise Co': return t('reservations.supplier.nilecruise');
      case 'Local Operators': return t('reservations.supplier.local');
      default: return supplier;
    }
  };

  const mockExistingDocuments = [
    {
      id: 1,
      name: 'Hotel_Confirmation_Steigenberger.pdf',
      type: t('reservations.docType.supplierConf') || 'Supplier Confirmation',
      uploadedBy: t('reservations.agent.superadmin') || 'Super Admin',
      uploadDate: '2025-01-14T10:30:00Z',
      size: '245 KB'
    },
    {
      id: 2,
      name: 'Payment_Receipt_001.pdf',
      type: t('reservations.docType.paymentReceipt') || 'Payment Receipt',
      uploadedBy: t('reservations.agent.superadmin') || 'Super Admin',
      uploadDate: '2025-01-13T16:45:00Z',
      size: '128 KB'
    }
  ];

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedFile) {
      return;
    }

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      toast.success(
        isRTL ? 'تم الرفع بنجاح' : 'Uploaded Successfully',
        isRTL ? 'تم رفع المستند للنظام.' : 'Document has been uploaded to the system.'
      );
      navigate(-1);
    } catch (error) {
      toast.error('Error', 'Failed to upload document.');
    } finally {
      setIsLoading(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        {/* Top Header Banner */}
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate(-1)} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
              <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-xl">
                <Upload className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight bidi-isolate">
                  {t('reservations.modal.uploadTitle')?.replace('{id}', reservation.id) || 'Upload Document'}
                </h1>
                <p className="mt-1 text-sm text-blue-100 opacity-90">
                  {isRTL ? 'إرفاق وتخزين المستندات المتعلقة بهذا الحجز' : 'Attach and store documents related to this reservation'}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-10 shadow-sm border border-gray-100 dark:border-gray-800">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {/* Upload Form Area */}
            <div className="space-y-8">
              {/* Reservation Info */}
              <div className="bg-purple-50 dark:bg-purple-900/10 rounded-2xl p-6 border border-purple-100 dark:border-purple-900/30">
                <h4 className="text-sm font-bold text-purple-800 dark:text-purple-300 mb-4 uppercase tracking-wider">
                  {t('reservations.modal.tripSection') || 'Trip Details'}
                </h4>
                <div className="text-sm text-purple-900 dark:text-purple-100 space-y-3 font-medium">
                  <div className="flex justify-between items-center pb-2 border-b border-purple-200/50 dark:border-purple-800/50">
                    <span className="text-purple-600 dark:text-purple-400">{t('reservations.table.customer') || 'Customer'}:</span>
                    <span className="font-bold">{reservation.customer}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-purple-200/50 dark:border-purple-800/50">
                    <span className="text-purple-600 dark:text-purple-400">{t('reservations.table.tripItem') || 'Trip Item'}:</span>
                    <span className="font-bold">{getLocalizedTripItem(reservation.tripItem)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-purple-600 dark:text-purple-400">{t('reservations.table.supplier') || 'Supplier'}:</span>
                    <span className="font-bold">{getLocalizedSupplier(reservation.supplier)}</span>
                  </div>
                </div>
              </div>

              {/* Form */}
              <form onSubmit={handleSubmit} className="bg-gray-50 dark:bg-gray-800/50 p-6 rounded-2xl border border-gray-100 dark:border-gray-700/50">
                <h4 className="text-sm font-bold text-gray-900 dark:text-white mb-6 uppercase tracking-wider">
                  {t('reservations.modal.addNewNote') || 'Upload New Document'}
                </h4>

                <div className="space-y-5">
                  <Select
                    label={t('reservations.modal.docType')}
                    value={documentType}
                    onChange={(e) => setDocumentType(e.target.value)}
                  >
                    {documentTypes.map(type => (
                      <option key={type} value={type}>{getLocalizedDocType(type)}</option>
                    ))}
                  </Select>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      {t('reservations.modal.selectFile')} *
                    </label>
                    <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-xl hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-gray-800 transition-colors group">
                      <div className="space-y-2 text-center">
                        <div className="w-16 h-16 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center mx-auto group-hover:bg-blue-100 dark:group-hover:bg-blue-900/50 transition-colors">
                          <Upload className="h-8 w-8 text-gray-400 group-hover:text-blue-500 transition-colors" />
                        </div>
                        <div className="flex justify-center text-sm text-gray-600 dark:text-gray-400">
                          <label htmlFor="file-upload" className="relative cursor-pointer rounded-md font-medium text-blue-600 dark:text-blue-400 hover:text-blue-500 focus-within:outline-none">
                            <span>Upload a file</span>
                            <input
                              id="file-upload"
                              name="file-upload"
                              type="file"
                              className="sr-only"
                              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                              onChange={handleFileSelect}
                            />
                          </label>
                          <p className={isRTL ? 'pr-1' : 'pl-1'}>or drag and drop</p>
                        </div>
                        <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                          PDF, DOC, DOCX, JPG, PNG up to 10MB
                        </p>
                      </div>
                    </div>
                    
                    {selectedFile && (
                      <div className="mt-4 p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-900/50 rounded-xl">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-green-100 dark:bg-green-900/50 rounded-lg">
                            <File className="h-6 w-6 text-green-600 dark:text-green-400" />
                          </div>
                          <div>
                            <p className="text-sm font-bold text-green-800 dark:text-green-300">
                              {selectedFile.name}
                            </p>
                            <p className="text-xs text-green-600 dark:text-green-400 font-medium bidi-isolate mt-0.5">
                              {formatFileSize(selectedFile.size)}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      {t('reservations.modal.description')}
                    </label>
                    <textarea
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={3}
                      className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none dark:text-white shadow-sm transition-all"
                      placeholder="Add description or notes about this document..."
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={isLoading || !selectedFile}
                    loading={isLoading}
                    className="w-full bg-blue-600 hover:bg-blue-700 py-6"
                  >
                    <Upload className={`h-5 w-5 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                    {t('reservations.action.uploadDocument')}
                  </Button>
                </div>
              </form>
            </div>

            {/* Existing Documents Feed */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                  {t('reservations.modal.existingDocs') || 'Existing Documents'}
                </h3>
                <span className="px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-xs font-bold rounded-full">
                  {mockExistingDocuments.length} Items
                </span>
              </div>
              <div className="space-y-4">
                {mockExistingDocuments.map((doc) => (
                  <div key={doc.id} className="p-5 bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 hover:shadow-md transition-shadow group flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-xl">
                        <File className="h-6 w-6" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-gray-900 dark:text-white mb-1">
                          {doc.name}
                        </p>
                        <div className="flex flex-wrap items-center gap-2 mb-2">
                          <span className="px-2.5 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 text-xs font-semibold rounded-md">
                            {doc.type}
                          </span>
                          <span className="text-xs text-gray-400 font-medium bidi-isolate">{doc.size}</span>
                        </div>
                        <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                          {t('reservations.modal.uploadedBy')} <span className="font-bold text-gray-700 dark:text-gray-300">{doc.uploadedBy}</span> on <span className="bidi-isolate">{formatDate(doc.uploadDate)}</span>
                        </p>
                      </div>
                    </div>
                    <Button variant="outline" className="w-full sm:w-auto self-start bg-white dark:bg-gray-800">
                      Download
                    </Button>
                  </div>
                ))}
                
                {mockExistingDocuments.length === 0 && (
                  <div className="text-center py-12 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-dashed border-gray-200 dark:border-gray-700">
                    <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                      <File className="h-8 w-8 text-gray-400" />
                    </div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{t('reservations.modal.noDocs')}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
