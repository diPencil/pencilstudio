import React, { useMemo, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Eye, Link2, Trash2, Unlink, Edit, Plus, Save, X } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { mockSuppliers, mockItems, mockFinance } from '../../services/mockData';
import type { SupplierContact, SupplierContract, SupplierDocument, SupplierEvaluationCriterion, SupplierEvaluationReview, SupplierPayment, ContractPolicyRule } from '../../types';
import { useLocale } from '../../localization/useLocale';
import { formatCurrency, formatDate } from '../../utils/format';

const tabs = [
  'Overview',
  'Contacts',
  'Contracts',
  'Products & Services',
  'Payments',
  'Documents',
  'Performance',
  'Activity Timeline'
] as const;

type TabName = typeof tabs[number];

type LocalItem = typeof mockItems[number];

const badgeClass = (tone: 'green' | 'amber' | 'red' | 'blue' | 'gray') => {
  const tones = {
    green: 'bg-emerald-50 text-emerald-700 border-emerald-100 dark:bg-emerald-950/20 dark:text-emerald-400 dark:border-emerald-900/30',
    amber: 'bg-amber-50 text-amber-700 border-amber-100 dark:bg-amber-950/20 dark:text-amber-400 dark:border-amber-900/30',
    red: 'bg-rose-50 text-rose-700 border-rose-100 dark:bg-rose-950/20 dark:text-rose-400 dark:border-rose-900/30',
    blue: 'bg-blue-50 text-blue-700 border-blue-100 dark:bg-blue-950/20 dark:text-blue-400 dark:border-blue-900/30',
    gray: 'bg-gray-50 text-gray-700 border-gray-100 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700'
  };

  return `inline-flex w-fit rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${tones[tone]}`;
};

const statusTone = (status?: string) => {
  if (status === 'Active' || status === 'Valid' || status === 'Paid') return 'green';
  if (status === 'Draft' || status === 'Expiring' || status === 'Pending' || status === 'Onboarding') return 'amber';
  if (status === 'Expired' || status === 'Suspended' || status === 'Overdue') return 'red';
  return 'gray';
};

export const SupplierProfilePage: React.FC = () => {
  const { supplierId } = useParams<{ supplierId: string }>();
  const navigate = useNavigate();
  const { t, direction } = useLocale();

  const supplier = useMemo(() => mockSuppliers.find(s => s.id === supplierId), [supplierId]);
  const [activeTab, setActiveTab] = useState<TabName>('Overview');
  const [selectedContractId, setSelectedContractId] = useState<string | null>(null);
  const [documentName, setDocumentName] = useState('');

  const [contacts, setContacts] = useState<SupplierContact[]>(supplier?.contacts || []);
  const [contracts, setContracts] = useState<SupplierContract[]>(supplier?.contracts || []);
  const [documents, setDocuments] = useState<SupplierDocument[]>(supplier?.documents || []);
  const [evaluations, setEvaluations] = useState<SupplierEvaluationReview[]>(supplier?.evaluations || []);
  const [linkedItems, setLinkedItems] = useState<LocalItem[]>(mockItems.filter(item => item.supplierId === supplierId));

  const supplierInvoices = useMemo(() => {
    if (!supplier) return [] as SupplierPayment[];
    const financeInvoices = mockFinance
      .filter(f => f.supplier === supplier.name)
      .map(f => ({
        id: f.id,
        invoiceRef: f.id,
        amount: f.totalAmount || 0,
        currency: 'USD',
        status: f.outstandingBalance && f.outstandingBalance > 0 ? 'Pending' : 'Paid',
        date: f.createdAt || ''
      })) as SupplierPayment[];

    return financeInvoices.length > 0 ? financeInvoices : supplier.payments || [];
  }, [supplier]);

  const availableItems = mockItems.filter(item => !linkedItems.some(linked => linked.id === item.id));
  const selectedContract = contracts.find(contract => contract.id === selectedContractId);

  const getTabLabel = (tab: TabName) => {
    switch (tab) {
      case 'Overview': return t('supplier.profile.tabs.overview');
      case 'Contacts': return t('supplier.profile.tabs.contacts');
      case 'Contracts': return t('supplier.profile.tabs.contracts');
      case 'Products & Services': return t('supplier.profile.tabs.products');
      case 'Payments': return t('supplier.profile.tabs.payments');
      case 'Documents': return t('supplier.profile.tabs.documents');
      case 'Performance': return t('supplier.profile.tabs.performance');
      case 'Activity Timeline': return t('supplier.profile.tabs.activity');
      default: return tab;
    }
  };

  const getStatusLabel = (val: string) => {
    if (val === 'Active') return t('common.active');
    if (val === 'Inactive') return t('common.inactive');
    if (val === 'Valid') return t('supplier.profile.status.valid');
    if (val === 'Invalid') return t('supplier.profile.status.invalid');
    if (val === 'Expiring') return t('supplier.profile.status.expiring');
    if (val === 'Expired') return t('supplier.profile.status.expired');
    if (val === 'Pending') return t('supplier.profile.status.pending');
    if (val === 'Paid') return t('supplier.profile.status.paid');
    if (val === 'Draft') return t('common.draft');
    if (val === 'Onboarding') return t('supplier.tracker.status.onboarding');
    if (val === 'Suspended') return t('supplier.profile.status.suspended');
    if (val === 'Overdue') return t('supplier.tracker.status.overdue');
    return val;
  };

  const getTranslatedType = (type: string) => {
    if (type === 'Hotel') return t('supplier.type.hotel');
    if (type === 'Airline') return t('supplier.type.airline');
    if (type === 'Tour Operator') return t('supplier.type.tourOperator');
    if (type === 'Cruise Line') return t('supplier.type.cruiseLine');
    return type;
  };

  const formatDaysString = (str: string | undefined | null) => {
    if (!str) return '-';
    if (str.toLowerCase().includes('days')) {
      const val = str.replace(/days/i, '').trim();
      return `${val} ${t('supplier.tracker.days')}`;
    }
    return str;
  };

  const getContactRoleLabel = (role: string) => {
    if (role === 'Reservations') return t('supplier.profile.contacts.role.reservations');
    if (role === 'Accounting') return t('supplier.profile.contacts.role.accounting');
    if (role === 'Emergency') return t('supplier.profile.contacts.role.emergency');
    if (role === 'Main') return t('supplier.profile.contacts.role.main');
    return role;
  };

  if (!supplier) {
    return (
      <div className="page-container py-20 text-center">
        <h2 className="text-xl font-bold">{t('supplier.profile.notFound')}</h2>
        <Button variant="outline" className="mt-4" onClick={() => navigate('/reservations/tracker')}>
          {t('supplier.profile.backToTracker')}
        </Button>
      </div>
    );
  }

  const handleAddContact = (contact: SupplierContact) => setContacts(prev => [contact, ...prev]);
  const handleRemoveContact = (id: string) => setContacts(prev => prev.filter(contact => contact.id !== id));
  const handleAddContract = (contract: SupplierContract) => setContracts(prev => [contract, ...prev]);
  const handleUpdatePolicyRules = (contractId: string, rules: ContractPolicyRule[]) => {
    setContracts(prev => prev.map(c => c.id === contractId ? { ...c, policyRules: rules } : c));
  };

  const handleUploadDocument = () => {
    const name = documentName.trim();
    if (!name) return;

    const document: SupplierDocument = {
      id: `DOC-${Date.now()}`,
      name,
      type: 'Other',
      uploadedAt: new Date().toISOString().slice(0, 10),
      status: 'Valid'
    };

    setDocuments(prev => [document, ...prev]);
    setDocumentName('');
  };

  const handleLinkItem = (item: LocalItem) => setLinkedItems(prev => [{ ...item, supplierId: supplier.id }, ...prev]);
  const handleUnlinkItem = (id: string) => setLinkedItems(prev => prev.filter(item => item.id !== id));

  return (
    <div className="w-full pb-8 overflow-x-hidden">
      <div className="mx-auto max-w-[1400px] space-y-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
          <div className="min-w-0 logical-start">
            <Button variant="ghost" size="sm" className="mb-3 text-blue-100 hover:text-white hover:bg-white/10" onClick={() => navigate('/reservations/tracker')}>
              <ArrowLeft className="h-4 w-4 rtl-flip" />
              {t('supplier.profile.backToTracker')}
            </Button>
            <h1 className="break-words text-2xl sm:text-3xl font-bold tracking-tight">{supplier.name}</h1>
            <p className="mt-1 text-sm text-blue-100 opacity-90">{getTranslatedType(supplier.type)} - {supplier.location}</p>
          </div>
          <div className="flex flex-wrap gap-2 mt-4 sm:mt-0">
            <Button variant="outline" className="bg-white/10 text-white border-transparent hover:bg-white/20" onClick={() => navigate('/reservations/tracker')}>{t('supplier.profile.backToTracker')}</Button>
            <Button className="bg-white text-blue-600 hover:bg-gray-50" onClick={() => navigate('/reservations/new-supplier')}>{t('supplier.profile.editNew')}</Button>
          </div>
        </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-4">
        <div className="min-w-0 xl:col-span-3">
          <Card>
            <CardContent className="p-4 sm:p-6">
              <div className="mb-4 flex min-w-0 flex-col gap-3 sm:flex-row sm:items-center logical-start">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full overflow-hidden border border-gray-200 dark:border-gray-700 shadow-sm">
                  <img src={supplier.name.toLowerCase().includes('fatma') || supplier.name.toLowerCase().includes('nour') || supplier.name.toLowerCase().includes('sarah') || supplier.name.toLowerCase().includes('layla') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
                </div>
                <div className="min-w-0">
                  <div className="break-words font-semibold">{supplier.name}</div>
                  <div className="break-words text-xs text-gray-500">
                    <span className="ltr-value inline-block">{supplier.email}</span>
                    <span> - </span>
                    <span className="ltr-value inline-block">{supplier.phone}</span>
                  </div>
                </div>
              </div>

              <div className="mb-4 grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
                <SummaryPill label={t('supplier.profile.summary.destinations')} value={supplier.destinations?.join(', ') || '-'} />
                <SummaryPill label={t('supplier.profile.summary.status')} value={supplier.status || '-'} badge />
                <SummaryPill label={t('supplier.profile.summary.rating')} value={`${supplier.rating || '-'} / 5`} />
                <SummaryPill label={t('supplier.profile.summary.avgResponse')} value={supplier.avgResponseTime || '-'} />
              </div>

              <nav className="flex max-w-full gap-2 overflow-x-auto pb-1" aria-label="Supplier profile tabs">
                {tabs.map(tab => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`shrink-0 rounded-md px-3 py-2 text-sm font-medium ${activeTab === tab ? 'bg-blue-50 text-blue-700' : 'text-gray-600 hover:bg-gray-50'}`}
                  >
                    {getTabLabel(tab)}
                  </button>
                ))}
              </nav>

              <div className="mt-6 min-w-0">
                {activeTab === 'Overview' && (
                  <div className="space-y-4">
                    <InfoCard title={t('supplier.profile.overview.businessInfo')}>
                      {supplier.name} {t('supplier.profile.overview.businessDescPart1')} {getTranslatedType(supplier.type)} {t('supplier.profile.overview.businessDescPart2')} {supplier.destinations?.join(', ') || supplier.location}.
                    </InfoCard>
                    <InfoCard title={t('supplier.profile.overview.financialHighlights')}>
                      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <Metric label={t('supplier.profile.overview.outstandingBalance')} value={formatCurrency(supplier.payments?.reduce((sum, payment) => sum + (payment.status === 'Pending' ? payment.amount : 0), 0) ?? 0, { currency: 'USD' })} />
                        <Metric label={t('supplier.profile.overview.totalPaid')} value={formatCurrency(supplier.payments?.reduce((sum, payment) => sum + (payment.status === 'Paid' ? payment.amount : 0), 0) ?? 0, { currency: 'USD' })} />
                      </div>
                    </InfoCard>
                    <InfoCard title={t('supplier.profile.overview.recentActivity')}>
                      <ActivityList activity={supplier.activity || []} limit={5} />
                    </InfoCard>
                  </div>
                )}

                {activeTab === 'Contacts' && (
                  <div className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="logical-start">{t('supplier.profile.contacts.title')}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        {contacts.map(contact => (
                          <div key={contact.id} className="flex flex-col gap-3 rounded border border-gray-100 p-3 sm:flex-row sm:items-center sm:justify-between logical-start">
                            <div className="min-w-0 logical-start">
                              <div className="break-words font-medium">{contact.name}</div>
                              <div className="mt-1 flex flex-wrap gap-2">
                                <span className={badgeClass('blue')}>{getContactRoleLabel(contact.role)}</span>
                                <span className={badgeClass(contact.active === false ? 'gray' : 'green')}>{getStatusLabel(contact.active === false ? 'Inactive' : 'Active')}</span>
                              </div>
                              <div className="mt-1 break-words text-xs text-gray-500">
                                <span className="ltr-value inline-block">{contact.email || t('common.none')}</span>
                                <span> - </span>
                                <span className="ltr-value inline-block">{contact.phone || t('common.none')}</span>
                              </div>
                            </div>
                            <Button variant="outline" size="sm" onClick={() => handleRemoveContact(contact.id)}>
                              <Trash2 className="h-4 w-4" />
                              {t('common.delete')}
                            </Button>
                          </div>
                        ))}
                        <AddContactForm onAdd={handleAddContact} />
                      </CardContent>
                    </Card>
                  </div>
                )}

                {activeTab === 'Contracts' && (
                  <div className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="logical-start">{t('supplier.profile.contracts.title')}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        {contracts.map(contract => (
                          <div key={contract.id} className="rounded border border-gray-100 p-3 logical-start">
                            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                              <div className="min-w-0 logical-start">
                                <div className="break-words font-medium">{contract.title}</div>
                                <div className="text-xs text-gray-500 bidi-isolate">{formatDate(contract.startDate)} {t('common.to')} {formatDate(contract.endDate)}</div>
                                <div className="mt-2">
                                  <span className={badgeClass(statusTone(contract.status))}>{getStatusLabel(contract.status)}</span>
                                </div>
                              </div>
                              <Button variant="outline" size="sm" onClick={() => setSelectedContractId(selectedContractId === contract.id ? null : contract.id)}>
                                <Eye className="h-4 w-4" />
                                {selectedContractId === contract.id ? t('supplier.profile.contracts.hideDetails') : t('supplier.profile.contracts.viewDetails')}
                              </Button>
                            </div>
                            {selectedContractId === contract.id && (
                              <div className="mt-3 space-y-3 rounded bg-gray-50 p-3 text-sm logical-start">
                                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                                  <Metric label={t('supplier.profile.contracts.paymentTerms')} value={contract.paymentTerms || t('common.none')} />
                                  <Metric label={t('supplier.profile.contracts.commissionNotes')} value={contract.commissionNotes || t('common.none')} />
                                  <Metric label={t('supplier.profile.contracts.linkedServices')} value={contract.linkedServices?.join(', ') || t('common.none')} />
                                </div>
                                <ContractPolicyRulesBuilder
                                  contract={contract}
                                  linkedServices={linkedItems.map(item => item.name)}
                                  onUpdateRules={handleUpdatePolicyRules}
                                />
                              </div>
                            )}
                          </div>
                        ))}
                        {selectedContract && <div className="sr-only">Selected contract: {selectedContract.title}</div>}
                        <AddContractForm onAdd={handleAddContract} />
                      </CardContent>
                    </Card>
                  </div>
                )}

                {activeTab === 'Products & Services' && (
                  <div className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="logical-start">{t('supplier.profile.products.title')}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="overflow-x-auto">
                          <table style={{ direction }} className="w-full min-w-[680px] text-sm">
                            <thead>
                              <tr>
                                <th className="py-2 text-xs text-gray-500 logical-start">{t('supplier.tracker.table.service')}</th>
                                <th className="py-2 text-xs text-gray-500 logical-start">{t('supplier.profile.overview.businessInfo')}</th>
                                <th className="py-2 text-xs text-gray-500 logical-start">{t('supplier.profile.summary.destinations')}</th>
                                <th className="py-2 text-xs text-gray-500 logical-start">{t('common.price')}</th>
                                <th className="py-2 text-xs text-gray-500 logical-end">{t('common.actions')}</th>
                              </tr>
                            </thead>
                            <tbody>
                              {linkedItems.map(item => (
                                <tr key={item.id} className="border-t">
                                  <td className="break-words py-3 logical-start">{item.name}</td>
                                  <td className="logical-start">{getTranslatedType(item.categoryType)}</td>
                                  <td className="logical-start">{item.destination || supplier.destinations?.[0] || '-'}</td>
                                  <td className="logical-start font-medium bidi-isolate">{formatCurrency(item.price, { currency: 'USD' })}</td>
                                  <td className="logical-end">
                                    <Button variant="outline" size="sm" onClick={() => handleUnlinkItem(item.id)}>
                                      <Unlink className="h-4 w-4" />
                                      {t('supplier.profile.products.unlink')}
                                    </Button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                        <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap logical-start">
                          {availableItems.map(item => (
                            <Button key={item.id} variant="outline" size="sm" onClick={() => handleLinkItem(item)}>
                              <Link2 className="h-4 w-4" />
                              {t('supplier.profile.products.link')} {item.name}
                            </Button>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}

                {activeTab === 'Payments' && (
                  <TableCard title={t('supplier.profile.payments.title')}>
                    <table style={{ direction }} className="w-full min-w-[560px] text-sm">
                      <thead>
                        <tr>
                          <th className="py-2 text-xs text-gray-500 logical-start">{t('supplier.profile.payments.table.ref')}</th>
                          <th className="py-2 text-xs text-gray-500 logical-start">{t('supplier.profile.payments.table.amount')}</th>
                          <th className="py-2 text-xs text-gray-500 logical-start">{t('supplier.profile.payments.table.status')}</th>
                          <th className="py-2 text-xs text-gray-500 logical-start">{t('supplier.profile.payments.table.date')}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {supplierInvoices.map(invoice => (
                          <tr key={invoice.id} className="border-t">
                            <td className="break-words py-3 logical-start ltr-value inline-block">{invoice.invoiceRef}</td>
                            <td className="logical-start font-medium bidi-isolate">{formatCurrency(invoice.amount, { currency: invoice.currency || 'USD' })}</td>
                            <td className="logical-start"><span className={badgeClass(statusTone(invoice.status))}>{getStatusLabel(invoice.status)}</span></td>
                            <td className="logical-start bidi-isolate">{formatDate(invoice.date)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </TableCard>
                )}

                {activeTab === 'Documents' && (
                  <div className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="logical-start">{t('supplier.profile.documents.title')}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        {documents.map(document => (
                          <div key={document.id} className="flex flex-col gap-3 rounded border border-gray-100 p-3 sm:flex-row sm:items-center sm:justify-between logical-start">
                            <div className="min-w-0 logical-start">
                              <div className="break-words font-medium">{document.name}</div>
                              <div className="break-words text-xs text-gray-500">
                                {getTranslatedType(document.type)} - {t('supplier.profile.documents.uploaded')} <span className="bidi-isolate">{formatDate(document.uploadedAt)}</span>
                              </div>
                            </div>
                            <span className={badgeClass(statusTone(document.status))}>{getStatusLabel(document.status || 'Stored')}</span>
                          </div>
                        ))}
                        <div className="grid grid-cols-1 gap-2 border-t pt-4 sm:grid-cols-[1fr_auto]">
                          <Input
                            placeholder={t('supplier.profile.documents.placeholder')}
                            value={documentName}
                            onChange={(event) => setDocumentName(event.target.value)}
                            onKeyDown={(event) => {
                              if (event.key === 'Enter') handleUploadDocument();
                            }}
                          />
                          <Button onClick={handleUploadDocument} disabled={!documentName.trim()}>{t('supplier.profile.documents.upload')}</Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}

                {activeTab === 'Performance' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <MetricCard label={t('supplier.profile.performance.responseTime')} value={formatDaysString(supplier.performance?.responseTimeDays ? `${supplier.performance.responseTimeDays} Days` : '-')} />
                      <MetricCard label={t('supplier.tracker.table.responseRate')} value={supplier.performance?.responseRatePercent ? `${supplier.performance.responseRatePercent}%` : '-'} />
                      <MetricCard label={t('supplier.profile.performance.confirmationRate')} value={supplier.performance?.confirmationRatePercent ? `${supplier.performance.confirmationRatePercent}%` : '-'} />
                      <MetricCard label={t('supplier.profile.performance.qualityScore')} value={supplier.performance?.qualityScore ? `${supplier.performance.qualityScore}/100` : '-'} />
                      <MetricCard label={t('supplier.profile.performance.cancellationIssues')} value={supplier.performance?.cancellationIssues?.toString() ?? '0'} />
                      <MetricCard label={t('supplier.profile.performance.complaints')} value={supplier.performance?.complaints?.toString() ?? '0'} />
                    </div>
                    <SupplierEvaluationScorecard
                      evaluations={evaluations}
                      onAdd={(review) => setEvaluations(prev => [review, ...prev])}
                      onDelete={(id) => setEvaluations(prev => prev.filter(review => review.id !== id))}
                    />
                  </div>
                )}

                {activeTab === 'Activity Timeline' && (
                  <Card>
                    <CardContent>
                      <ActivityList activity={supplier.activity || []} />
                    </CardContent>
                  </Card>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardContent className="logical-start">
              <div className="text-sm text-gray-500">{t('supplier.profile.sidebar.performanceScore')}</div>
              <div className="text-2xl font-bold bidi-isolate">{supplier.performance?.qualityScore ?? '-'}</div>
              <div className="mt-2 break-words text-xs text-gray-500 logical-start">
                {t('supplier.profile.sidebar.response')}: <span className="bidi-isolate">{supplier.performance?.responseRatePercent}%</span> - {t('supplier.profile.sidebar.confirmation')}: <span className="bidi-isolate">{supplier.performance?.confirmationRatePercent}%</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="logical-start">
              <div className="text-sm text-gray-500">{t('supplier.profile.sidebar.primaryContacts')}</div>
              <div className="mt-2 space-y-2 logical-start">
                {contacts.slice(0, 3).map(contact => (
                  <div key={contact.id} className="break-words text-sm">{contact.name} - {getContactRoleLabel(contact.role)}</div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      </div>
    </div>
  );
};

const SummaryPill: React.FC<{ label: string; value: string; badge?: boolean }> = ({ label, value, badge }) => {
  const { t } = useLocale();

  const getStatusLabel = (val: string) => {
    if (val === 'Active') return t('common.active');
    if (val === 'Inactive') return t('common.inactive');
    if (val === 'Valid') return t('supplier.profile.status.valid');
    if (val === 'Invalid') return t('supplier.profile.status.invalid');
    if (val === 'Expiring') return t('supplier.profile.status.expiring');
    if (val === 'Expired') return t('supplier.profile.status.expired');
    if (val === 'Pending') return t('supplier.profile.status.pending');
    if (val === 'Paid') return t('supplier.profile.status.paid');
    if (val === 'Draft') return t('common.draft');
    if (val === 'Onboarding') return t('supplier.tracker.status.onboarding');
    if (val === 'Suspended') return t('supplier.profile.status.suspended');
    if (val === 'Overdue') return t('supplier.tracker.status.overdue');
    return val;
  };

  const formatDaysString = (str: string | undefined | null) => {
    if (!str) return '-';
    if (str.toLowerCase().includes('days')) {
      const val = str.replace(/days/i, '').trim();
      return `${val} ${t('supplier.tracker.days')}`;
    }
    return str;
  };

  return (
    <div className="min-w-0 rounded-md bg-gray-50 p-3 logical-start">
      <div className="text-[10px] font-bold uppercase tracking-wide text-gray-500">{label}</div>
      {badge ? (
        <span className={badgeClass(statusTone(value))}>{getStatusLabel(value)}</span>
      ) : (
        <div className="break-words text-sm font-semibold bidi-isolate">{formatDaysString(value)}</div>
      )}
    </div>
  );
};

const InfoCard: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <Card>
    <CardContent className="logical-start">
      <h3 className="font-bold">{title}</h3>
      <div className="mt-2 break-words text-sm text-gray-600">{children}</div>
    </CardContent>
  </Card>
);

const Metric: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div className="min-w-0 logical-start">
    <div className="text-sm text-gray-500">{label}</div>
    <div className="break-words font-bold bidi-isolate">{value}</div>
  </div>
);

const MetricCard: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <Card>
    <CardContent className="logical-start">
      <Metric label={label} value={value} />
    </CardContent>
  </Card>
);

const TableCard: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <Card>
    <CardHeader>
      <CardTitle className="logical-start">{title}</CardTitle>
    </CardHeader>
    <CardContent>
      <div className="overflow-x-auto">{children}</div>
    </CardContent>
  </Card>
);

const ActivityList: React.FC<{ activity: Array<{ id: string; type: string; message: string; user?: string; date: string }>; limit?: number }> = ({ activity, limit }) => {
  const { t } = useLocale();
  const visibleActivity = typeof limit === 'number' ? activity.slice(0, limit) : activity;

  const getActivityTypeLabel = (type: string) => {
    if (type === 'Created') return t('supplier.profile.activity.type.created');
    if (type === 'Contract') return t('supplier.profile.activity.type.contract');
    if (type === 'Review') return t('supplier.profile.activity.type.review');
    if (type === 'Pricing') return t('supplier.profile.activity.type.pricing');
    if (type === 'Usage') return t('supplier.profile.activity.type.usage');
    if (type === 'Draft') return t('common.draft');
    return type;
  };

  if (visibleActivity.length === 0) {
    return <div className="text-sm text-gray-500 logical-start">{t('common.noData')}</div>;
  }

  return (
    <div className="space-y-3">
      {visibleActivity.map(item => (
        <div key={item.id} className="rounded border border-gray-100 p-3 text-sm logical-start">
          <div className="font-semibold">{getActivityTypeLabel(item.type)}</div>
          <div className="break-words text-xs text-gray-500 logical-start">
            {item.message} - <span className="bidi-isolate">{formatDate(item.date)}</span>
            {item.user ? ` - ${item.user}` : ''}
          </div>
        </div>
      ))}
    </div>
  );
};

const defaultEvaluationCriteria: SupplierEvaluationCriterion[] = [
  { id: 'response-quality', area: 'Response Quality', weight: 20, score: 90, status: 'Pass', notes: '' },
  { id: 'confirmation-accuracy', area: 'Confirmation Accuracy', weight: 20, score: 90, status: 'Pass', notes: '' },
  { id: 'document-compliance', area: 'Document Compliance', weight: 15, score: 85, status: 'Pass', notes: '' },
  { id: 'customer-feedback', area: 'Customer Feedback', weight: 15, score: 85, status: 'Pass', notes: '' },
  { id: 'contract-compliance', area: 'Contract Compliance', weight: 15, score: 85, status: 'Pass', notes: '' },
  { id: 'financial-reliability', area: 'Financial Reliability', weight: 15, score: 85, status: 'Pass', notes: '' }
];

const getEvaluationStatus = (criteria: SupplierEvaluationCriterion[], score: number): SupplierEvaluationReview['status'] => {
  if (criteria.some(item => item.status === 'Fail') || score < 60) return 'Rejected';
  if (criteria.some(item => item.status === 'Watch') || score < 80) return 'Watchlist';
  return 'Approved';
};

const calculateEvaluationScore = (criteria: SupplierEvaluationCriterion[]) => {
  const totalWeight = criteria.reduce((sum, item) => sum + Number(item.weight || 0), 0);
  if (!totalWeight) return 0;

  const weightedScore = criteria.reduce((sum, item) => {
    const boundedScore = Math.max(0, Math.min(100, Number(item.score || 0)));
    return sum + boundedScore * Number(item.weight || 0);
  }, 0);

  return Math.round(weightedScore / totalWeight);
};

const SupplierEvaluationScorecard: React.FC<{
  evaluations: SupplierEvaluationReview[];
  onAdd: (review: SupplierEvaluationReview) => void;
  onDelete: (id: string) => void;
}> = ({ evaluations, onAdd, onDelete }) => {
  const [reviewer, setReviewer] = useState('Operations Manager');
  const [notes, setNotes] = useState('');
  const [criteria, setCriteria] = useState<SupplierEvaluationCriterion[]>(defaultEvaluationCriteria);

  const overallScore = calculateEvaluationScore(criteria);
  const reviewStatus = getEvaluationStatus(criteria, overallScore);

  const updateCriterion = (id: string, updates: Partial<SupplierEvaluationCriterion>) => {
    setCriteria(prev => prev.map(item => item.id === id ? { ...item, ...updates } : item));
  };

  const resetForm = () => {
    setCriteria(defaultEvaluationCriteria.map(item => ({ ...item })));
    setNotes('');
  };

  const saveEvaluation = () => {
    const cleanReviewer = reviewer.trim();
    if (!cleanReviewer) return;

    const stamp = Date.now();
    onAdd({
      id: `EV-${stamp}`,
      date: new Date().toISOString().slice(0, 10),
      reviewer: cleanReviewer,
      overallScore,
      status: reviewStatus,
      criteria: criteria.map(item => ({ ...item, id: `${item.id}-${stamp}` })),
      notes: notes.trim()
    });
    resetForm();
  };

  const statusClass = (status: string) => {
    if (status === 'Approved' || status === 'Pass') return badgeClass('green');
    if (status === 'Watchlist' || status === 'Watch' || status === 'Pending') return badgeClass('amber');
    if (status === 'Rejected' || status === 'Fail') return badgeClass('red');
    return badgeClass('gray');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="logical-start">Operational Evaluation Scorecard</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 gap-3 lg:grid-cols-[1fr_140px_140px]">
          <Input placeholder="Reviewer" value={reviewer} onChange={(event) => setReviewer(event.target.value)} />
          <Metric label="Overall Score" value={`${overallScore}/100`} />
          <div className="rounded border border-gray-100 p-3 logical-start">
            <div className="text-xs text-gray-500">Approval Status</div>
            <div className="mt-2">
              <span className={statusClass(reviewStatus)}>{reviewStatus}</span>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-[760px] w-full text-sm">
            <thead className="bg-gray-50 text-xs uppercase text-gray-500">
              <tr>
                <th className="px-3 py-2 text-left">Criterion</th>
                <th className="px-3 py-2 text-left">Weight</th>
                <th className="px-3 py-2 text-left">Score</th>
                <th className="px-3 py-2 text-left">Status</th>
                <th className="px-3 py-2 text-left">Notes</th>
              </tr>
            </thead>
            <tbody>
              {criteria.map(item => (
                <tr key={item.id} className="border-t border-gray-100">
                  <td className="px-3 py-2 font-medium">{item.area}</td>
                  <td className="px-3 py-2">
                    <Input
                      type="number"
                      min="0"
                      max="100"
                      value={item.weight}
                      onChange={(event) => updateCriterion(item.id, { weight: Number(event.target.value) })}
                    />
                  </td>
                  <td className="px-3 py-2">
                    <Input
                      type="number"
                      min="0"
                      max="100"
                      value={item.score}
                      onChange={(event) => updateCriterion(item.id, { score: Number(event.target.value) })}
                    />
                  </td>
                  <td className="px-3 py-2">
                    <Select value={item.status} onChange={(event) => updateCriterion(item.id, { status: event.target.value as SupplierEvaluationCriterion['status'] })}>
                      <option value="Pass">Pass</option>
                      <option value="Watch">Watch</option>
                      <option value="Fail">Fail</option>
                    </Select>
                  </td>
                  <td className="px-3 py-2">
                    <Input value={item.notes || ''} onChange={(event) => updateCriterion(item.id, { notes: event.target.value })} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <textarea
          className="min-h-20 w-full rounded-md border border-gray-200 bg-white px-3 py-2 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 dark:border-gray-700 dark:bg-gray-900"
          placeholder="Evaluation notes"
          value={notes}
          onChange={(event) => setNotes(event.target.value)}
        />

        <div className="flex flex-wrap justify-end gap-2 rtl:justify-start">
          <Button variant="outline" onClick={resetForm}>Reset</Button>
          <Button onClick={saveEvaluation} disabled={!reviewer.trim()}>
            <Save className="h-4 w-4" />
            Save Evaluation
          </Button>
        </div>

        <div className="space-y-2 border-t pt-4">
          <div className="text-sm font-semibold logical-start">Evaluation History</div>
          {evaluations.length === 0 ? (
            <div className="text-sm text-gray-500 logical-start">No evaluations recorded.</div>
          ) : (
            evaluations.map(review => (
              <div key={review.id} className="rounded border border-gray-100 p-3 logical-start">
                <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <div className="font-medium">{review.reviewer} - {review.overallScore}/100</div>
                    <div className="text-xs text-gray-500">{formatDate(review.date)} {review.notes ? `- ${review.notes}` : ''}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={statusClass(review.status)}>{review.status}</span>
                    <Button variant="outline" size="sm" onClick={() => onDelete(review.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {review.criteria.map(item => (
                    <div key={item.id} className="rounded bg-gray-50 p-2 text-xs">
                      <div className="font-semibold">{item.area}: {item.score}/100</div>
                      <div className="mt-1"><span className={statusClass(item.status)}>{item.status}</span></div>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
};

const AddContactForm: React.FC<{ onAdd: (contact: SupplierContact) => void }> = ({ onAdd }) => {
  const { t } = useLocale();
  const [name, setName] = useState('');
  const [role, setRole] = useState('Reservations');
  const [status, setStatus] = useState('Active');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const nameError = submitted && !name.trim() ? t('supplier.profile.contacts.nameError') : '';
  const contactError = submitted && !email.trim() && !phone.trim() ? t('supplier.profile.contacts.contactError') : '';

  const handleAdd = () => {
    setSubmitted(true);
    if (!name.trim() || (!email.trim() && !phone.trim())) return;

    onAdd({
      id: `C-${Date.now()}`,
      name: name.trim(),
      role,
      email: email.trim(),
      phone: phone.trim(),
      active: status === 'Active'
    });

    setName('');
    setRole('Reservations');
    setStatus('Active');
    setEmail('');
    setPhone('');
    setSubmitted(false);
  };

  return (
    <div className="border-t pt-4 logical-start">
      <div className="grid grid-cols-1 gap-2 lg:grid-cols-5 logical-start">
        <Input placeholder={t('supplier.profile.contacts.name')} value={name} onChange={(event) => setName(event.target.value)} error={nameError} />
        <Select value={role} onChange={(event) => setRole(event.target.value)}>
          <option value="Reservations">{t('supplier.profile.contacts.role.reservations')}</option>
          <option value="Accounting">{t('supplier.profile.contacts.role.accounting')}</option>
          <option value="Emergency">{t('supplier.profile.contacts.role.emergency')}</option>
          <option value="Main">{t('supplier.profile.contacts.role.main')}</option>
        </Select>
        <Select value={status} onChange={(event) => setStatus(event.target.value)}>
          <option value="Active">{t('common.active')}</option>
          <option value="Inactive">{t('common.inactive')}</option>
        </Select>
        <Input placeholder={t('supplier.profile.contacts.email')} value={email} onChange={(event) => setEmail(event.target.value)} error={contactError} />
        <Input placeholder={t('supplier.profile.contacts.phone')} value={phone} onChange={(event) => setPhone(event.target.value)} />
      </div>
      <div className="mt-3 flex justify-end rtl:justify-start">
        <Button onClick={handleAdd}>{t('supplier.profile.contacts.add')}</Button>
      </div>
    </div>
  );
};

const AddContractForm: React.FC<{ onAdd: (contract: SupplierContract) => void }> = ({ onAdd }) => {
  const { t } = useLocale();
  const [title, setTitle] = useState('');
  const [startDate, setStartDate] = useState('2026-01-01');
  const [endDate, setEndDate] = useState('2026-12-31');
  const [status, setStatus] = useState<'Draft' | 'Active' | 'Expiring' | 'Expired' | 'Suspended'>('Draft');
  const [submitted, setSubmitted] = useState(false);

  const getStatusLabel = (val: string) => {
    if (val === 'Active') return t('common.active');
    if (val === 'Inactive') return t('common.inactive');
    if (val === 'Valid') return t('supplier.profile.status.valid');
    if (val === 'Invalid') return t('supplier.profile.status.invalid');
    if (val === 'Expiring') return t('supplier.profile.status.expiring');
    if (val === 'Expired') return t('supplier.profile.status.expired');
    if (val === 'Pending') return t('supplier.profile.status.pending');
    if (val === 'Paid') return t('supplier.profile.status.paid');
    if (val === 'Draft') return t('common.draft');
    if (val === 'Onboarding') return t('supplier.tracker.status.onboarding');
    if (val === 'Suspended') return t('supplier.profile.status.suspended');
    if (val === 'Overdue') return t('supplier.tracker.status.overdue');
    return val;
  };

  const handleAdd = () => {
    setSubmitted(true);
    if (!title.trim() || !startDate || !endDate) return;

    onAdd({
      id: `CTR-${Date.now()}`,
      title: title.trim(),
      status,
      startDate,
      endDate,
      linkedServices: [],
      paymentTerms: 'Mock payment terms',
      commissionNotes: 'Mock commission notes'
    });

    setTitle('');
    setStatus('Draft');
    setSubmitted(false);
  };

  return (
    <div className="border-t pt-4 logical-start">
      <div className="grid grid-cols-1 gap-2 lg:grid-cols-4 logical-start">
        <Input placeholder={t('supplier.profile.contracts.newContract')} value={title} onChange={(event) => setTitle(event.target.value)} error={submitted && !title.trim() ? t('supplier.profile.contacts.nameError') : ''} />
        <Input type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} />
        <Input type="date" value={endDate} onChange={(event) => setEndDate(event.target.value)} />
        <Select value={status} onChange={(event) => setStatus(event.target.value as 'Draft' | 'Active' | 'Expiring' | 'Expired' | 'Suspended')}>
          <option value="Draft">{getStatusLabel('Draft')}</option>
          <option value="Active">{getStatusLabel('Active')}</option>
          <option value="Expiring">{getStatusLabel('Expiring')}</option>
          <option value="Expired">{getStatusLabel('Expired')}</option>
          <option value="Suspended">{getStatusLabel('Suspended')}</option>
        </Select>
      </div>
      <div className="mt-3 flex justify-end rtl:justify-start">
        <Button onClick={handleAdd}>{t('supplier.profile.contracts.add')}</Button>
      </div>
    </div>
  );
};

interface ContractPolicyRulesBuilderProps {
  contract: SupplierContract;
  linkedServices: string[];
  onUpdateRules: (contractId: string, rules: ContractPolicyRule[]) => void;
}

export const ContractPolicyRulesBuilder: React.FC<ContractPolicyRulesBuilderProps> = ({
  contract,
  linkedServices,
  onUpdateRules
}) => {
  const { t, direction } = useLocale();
  const rules = contract.policyRules || [];
  const [editingRule, setEditingRule] = useState<ContractPolicyRule | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);

  // Form states
  const [name, setName] = useState('');
  const [type, setType] = useState('Cancellation');
  const [appliesToService, setAppliesToService] = useState('All Services');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [season, setSeason] = useState('');
  const [chargeType, setChargeType] = useState('Percentage');
  const [value, setValue] = useState<number>(0);
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<'Active' | 'Inactive'>('Active');

  const openAddForm = () => {
    setEditingRule(null);
    setName('');
    setType('Cancellation');
    setAppliesToService('All Services');
    setStartDate('');
    setEndDate('');
    setSeason('');
    setChargeType('Percentage');
    setValue(0);
    setNotes('');
    setStatus('Active');
    setIsFormOpen(true);
  };

  const openEditForm = (rule: ContractPolicyRule) => {
    setEditingRule(rule);
    setName(rule.name);
    setType(rule.type);
    setAppliesToService(rule.appliesToService || 'All Services');
    setStartDate(rule.startDate || '');
    setEndDate(rule.endDate || '');
    setSeason(rule.season || '');
    setChargeType(rule.chargeType);
    setValue(rule.value);
    setNotes(rule.notes || '');
    setStatus(rule.status);
    setIsFormOpen(true);
  };

  const handleSave = () => {
    if (!name.trim()) return;

    const newRule: ContractPolicyRule = {
      id: editingRule ? editingRule.id : `PR-${Date.now()}`,
      name: name.trim(),
      type,
      appliesToService: appliesToService === 'All Services' ? undefined : appliesToService,
      startDate: startDate || undefined,
      endDate: endDate || undefined,
      season: season || undefined,
      chargeType,
      value: Number(value) || 0,
      notes: notes.trim() || undefined,
      status
    };

    let nextRules: ContractPolicyRule[];
    if (editingRule) {
      nextRules = rules.map(r => r.id === editingRule.id ? newRule : r);
    } else {
      nextRules = [...rules, newRule];
    }

    onUpdateRules(contract.id, nextRules);
    setIsFormOpen(false);
    setEditingRule(null);
  };

  const handleDelete = (ruleId: string) => {
    const nextRules = rules.filter(r => r.id !== ruleId);
    onUpdateRules(contract.id, nextRules);
  };

  const getRuleTypeLabel = (type: string) => {
    switch (type) {
      case 'Cancellation': return t('supplier.profile.contracts.ruleType.cancellation');
      case 'Seasonal Supplement': return t('supplier.profile.contracts.ruleType.seasonalSupplement');
      case 'Child Policy': return t('supplier.profile.contracts.ruleType.childPolicy');
      case 'Extra Bed': return t('supplier.profile.contracts.ruleType.extraBed');
      case 'Blackout Date': return t('supplier.profile.contracts.ruleType.blackoutDate');
      default: return type;
    }
  };

  const getChargeTypeLabel = (type: string) => {
    switch (type) {
      case 'Percentage': return t('supplier.profile.contracts.chargeType.percentage');
      case 'Fixed Amount': return t('supplier.profile.contracts.chargeType.fixedAmount');
      case 'Per Person': return t('supplier.profile.contracts.chargeType.perPerson');
      case 'Per Night': return t('supplier.profile.contracts.chargeType.perNight');
      default: return type;
    }
  };

  const getStatusLabel = (val: string) => {
    if (val === 'Active') return t('common.active');
    if (val === 'Inactive') return t('common.inactive');
    return val;
  };

  return (
    <div className="mt-4 border-t border-gray-200 pt-4 logical-start">
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-sm font-bold text-gray-800 uppercase tracking-wider logical-start">{t('supplier.profile.contracts.policyRules')}</h4>
        {!isFormOpen && (
          <Button size="sm" onClick={openAddForm}>
            <Plus className="h-3 w-3" /> {t('supplier.profile.contracts.addRule')}
          </Button>
        )}
      </div>

      {isFormOpen && (
        <Card className="mb-4 bg-gray-50 border border-gray-200 dark:bg-gray-800/20 dark:border-gray-700 logical-start">
          <CardContent className="p-4 space-y-4 logical-start">
            <div className="flex justify-between items-center pb-2 border-b border-gray-200 dark:border-gray-700">
              <h5 className="text-xs font-bold text-gray-700 dark:text-gray-300 uppercase">{editingRule ? t('common.edit') : t('supplier.profile.contracts.addRule')}</h5>
              <button onClick={() => setIsFormOpen(false)} className="text-gray-400 hover:text-gray-600">
                <X className="h-4 w-4" />
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 logical-start">
              <Input label={t('supplier.profile.contracts.ruleName') + ' *'} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Standard Cancellation" />
              <Select label={t('supplier.profile.contracts.ruleType')} value={type} onChange={(e) => setType(e.target.value)}>
                <option value="Cancellation">{getRuleTypeLabel('Cancellation')}</option>
                <option value="Seasonal Supplement">{getRuleTypeLabel('Seasonal Supplement')}</option>
                <option value="Child Policy">{getRuleTypeLabel('Child Policy')}</option>
                <option value="Extra Bed">{getRuleTypeLabel('Extra Bed')}</option>
                <option value="Blackout Date">{getRuleTypeLabel('Blackout Date')}</option>
              </Select>
              <Select label={t('supplier.profile.contracts.appliesTo')} value={appliesToService} onChange={(e) => setAppliesToService(e.target.value)}>
                <option value="All Services">{t('common.all')}</option>
                {linkedServices.map(srv => (
                  <option key={srv} value={srv}>{srv}</option>
                ))}
              </Select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 logical-start">
              <Input label={t('supplier.profile.contracts.startDate')} type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
              <Input label={t('supplier.profile.contracts.endDate')} type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
              <Input label={t('supplier.profile.contracts.season')} value={season} onChange={(e) => setSeason(e.target.value)} placeholder="e.g. High Season 2026" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 logical-start">
              <Select label={t('supplier.profile.contracts.chargeType')} value={chargeType} onChange={(e) => setChargeType(e.target.value)}>
                <option value="Percentage">{getChargeTypeLabel('Percentage')}</option>
                <option value="Fixed Amount">{getChargeTypeLabel('Fixed Amount')}</option>
                <option value="Per Person">{getChargeTypeLabel('Per Person')}</option>
                <option value="Per Night">{getChargeTypeLabel('Per Night')}</option>
              </Select>
              <Input label={t('supplier.profile.contracts.value')} type="number" value={value.toString()} onChange={(e) => setValue(Number(e.target.value) || 0)} />
              <Select label={t('common.status')} value={status} onChange={(e) => setStatus(e.target.value as 'Active' | 'Inactive')}>
                <option value="Active">{getStatusLabel('Active')}</option>
                <option value="Inactive">{getStatusLabel('Inactive')}</option>
              </Select>
            </div>

            <Input label={t('supplier.profile.contracts.notes')} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Add any special conditions..." />

            <div className="flex justify-end rtl:justify-start gap-2 pt-2">
              <Button size="sm" variant="outline" onClick={() => setIsFormOpen(false)}>{t('common.cancel')}</Button>
              <Button size="sm" onClick={handleSave} disabled={!name.trim()}>
                <Save className="h-3.5 w-3.5" /> {t('supplier.profile.contracts.saveRule')}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {rules.length > 0 ? (
        <div className="overflow-x-auto rounded border border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900">
          <table style={{ direction }} className="w-full min-w-[760px] text-xs">
            <thead className="bg-gray-50 dark:bg-gray-800 text-gray-500 dark:text-gray-400 uppercase font-bold tracking-wider border-b border-gray-100 dark:border-gray-800">
              <tr>
                <th className="px-3 py-2 logical-start">{t('supplier.profile.contracts.ruleTable.name')}</th>
                <th className="px-3 py-2 logical-start">{t('supplier.profile.contracts.ruleTable.type')}</th>
                <th className="px-3 py-2 logical-start">{t('supplier.profile.contracts.ruleTable.applies')}</th>
                <th className="px-3 py-2 logical-start">{t('supplier.profile.contracts.ruleTable.dates')}</th>
                <th className="px-3 py-2 logical-start">{t('supplier.profile.contracts.ruleTable.charge')}</th>
                <th className="px-3 py-2 logical-start">{t('supplier.profile.contracts.ruleTable.status')}</th>
                <th className="px-3 py-2 logical-end">{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {rules.map(rule => (
                <tr key={rule.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                  <td className="px-3 py-2 font-medium text-gray-900 dark:text-white logical-start">
                    <div>{rule.name}</div>
                    {rule.notes && <div className="text-[10px] text-gray-400 font-normal">{rule.notes}</div>}
                  </td>
                  <td className="px-3 py-2 logical-start">
                    <span className={`inline-flex px-1.5 py-0.5 rounded-full text-[9px] font-bold uppercase ${
                      rule.type === 'Cancellation' ? 'bg-red-50 text-red-600 border border-red-100 dark:bg-red-950/20 dark:text-red-400 dark:border-red-900/30' :
                      rule.type === 'Seasonal Supplement' ? 'bg-orange-50 text-orange-600 border border-orange-100 dark:bg-orange-950/20 dark:text-orange-400 dark:border-orange-900/30' :
                      rule.type === 'Child Policy' ? 'bg-blue-50 text-blue-600 border border-blue-100 dark:bg-blue-950/20 dark:text-blue-400 dark:border-blue-900/30' :
                      rule.type === 'Extra Bed' ? 'bg-purple-50 text-purple-600 border border-purple-100 dark:bg-purple-950/20 dark:text-purple-400 dark:border-purple-900/30' :
                      'bg-gray-50 text-gray-600 border border-gray-100 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700'
                    }`}>
                      {getRuleTypeLabel(rule.type)}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-gray-500 dark:text-gray-400 logical-start">{rule.appliesToService || t('common.all')}</td>
                  <td className="px-3 py-2 text-gray-500 dark:text-gray-400 logical-start">
                    {rule.startDate && rule.endDate ? (
                      <span className="bidi-isolate">
                        {formatDate(rule.startDate)} {t('common.to')} {formatDate(rule.endDate)}
                      </span>
                    ) : rule.season || t('supplier.profile.contracts.anytime')}
                  </td>
                  <td className="px-3 py-2 text-gray-900 dark:text-white font-semibold logical-start">
                    {rule.chargeType === 'Percentage' ? (
                      <span className="bidi-isolate">{rule.value}%</span>
                    ) : (
                      <span className="bidi-isolate">
                        {formatCurrency(rule.value, { currency: 'USD' })} ({getChargeTypeLabel(rule.chargeType)})
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-2 logical-start">
                    <span className={`inline-flex px-1.5 py-0.5 rounded-full text-[9px] font-bold ${
                      rule.status === 'Active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100 dark:bg-emerald-950/20 dark:text-emerald-400 dark:border-emerald-900/30' : 'bg-gray-50 text-gray-500 border border-gray-100 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700'
                    }`}>
                      {getStatusLabel(rule.status)}
                    </span>
                  </td>
                  <td className="px-3 py-2 logical-end">
                    <div className="flex justify-end rtl:justify-start gap-1">
                      <button onClick={() => openEditForm(rule)} className="p-1 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded" title={t('common.edit')}>
                        <Edit className="h-3.5 w-3.5" />
                      </button>
                      <button onClick={() => handleDelete(rule.id)} className="p-1 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded" title={t('common.delete')}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="text-center py-6 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded text-gray-400 text-xs logical-start">
          {t('supplier.profile.contracts.noRules')}
        </div>
      )}
    </div>
  );
};

export default SupplierProfilePage;
