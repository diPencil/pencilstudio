import React from 'react';
import { User, Mail, Phone, Calendar, MapPin, Users, Bed, Utensils, Globe, Building, FileText, Clock, ArrowLeft, ArrowRight } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { formatDate } from '../../utils/format';
import { getStatusColor, getFinanceStatusColor } from '../../utils/statusColors';
import { useLocale } from '../../localization/useLocale';
import { Reservation } from './ReservationsPage';
import { Button } from '../ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { cn } from '../../utils/cn';

export const ViewReservationPage: React.FC = () => {
  const { t, isRTL } = useLocale();
  const location = useLocation();
  const navigate = useNavigate();
  
  const reservation = location.state?.reservation as Reservation;

  if (!reservation) {
    return (
      <div className="w-full pb-8">
        <div className="mx-auto max-w-[1400px] text-center mt-20">
          <p className="text-gray-500">{t('reservations.modal.viewTitle').replace('{id}', '')}</p>
          <Button onClick={() => navigate('/reservations')} className="mt-4">
            {t('app.back')}
          </Button>
        </div>
      </div>
    );
  }

  const getLocalizedStatus = (status: string) => {
    switch (status) {
      case 'New': return t('reservations.status.new');
      case 'Pending': return t('reservations.status.pending');
      case 'Confirmed': return t('reservations.status.confirmed');
      case 'Awaiting Supplier': return t('reservations.status.awaitingSupplier');
      case 'Reserved': return t('reservations.status.reserved');
      case 'Cancelled': return t('reservations.status.cancelled');
      default: return status;
    }
  };

  const getLocalizedFinanceStatus = (status: string) => {
    switch (status) {
      case 'Pending': return t('reservations.finance.pending');
      case 'Payment Requested': return t('reservations.finance.paymentRequested');
      case 'Deposit Paid': return t('reservations.finance.depositPaid');
      case 'Paid': return t('reservations.finance.paid');
      case 'Fully Paid': return t('reservations.finance.fullyPaid');
      case 'Refunded': return t('reservations.finance.refunded');
      default: return status;
    }
  };

  const getLocalizedSupplier = (supplier: string) => {
    switch (supplier) {
      case 'Steigenberger Hotels': return t('reservations.supplier.steigerberger');
      case 'Hilton Hotels': return t('reservations.supplier.hilton');
      case 'EgyptAir': return t('reservations.supplier.egyptair');
      case 'Cairo Tours': return t('reservations.supplier.cairotours');
      case 'Nile Cruise Co': return t('reservations.supplier.nilecruise');
      case 'Local Operators': return t('reservations.supplier.local');
      default: return supplier;
    }
  };

  const getLocalizedAgent = (agent: string) => {
    switch (agent) {
      case 'Super Admin': return t('reservations.agent.superadmin');
      case 'Mahmoud Khalil': return t('reservations.agent.mahmoud');
      case 'Layla Ramadan': return t('reservations.agent.layla');
      case 'Sami Youssef': return t('reservations.agent.sami');
      case 'Mona Zaki': return t('reservations.agent.mona');
      default: return agent;
    }
  };

  const getLocalizedTripItem = (item: string) => {
    switch (item) {
      case 'Hotel: Steigenberger Luxor': return t('reservations.tripType.hotelSteigenberger');
      case 'Hotel: Hilton Aswan Resort': return t('reservations.tripType.hotelHilton');
      case 'Flight: CAI-LXR Economy': return t('reservations.tripType.flightCaiLxr');
      case 'Tour: Valley of Kings': return t('reservations.tripType.tourValley');
      case 'Activity: Nile Felucca Ride': return t('reservations.tripType.activityNile');
      case 'Package: Nile Cruise 4 Days': return t('reservations.tripType.packageNile');
      case 'Transport: Airport Transfer': return t('reservations.tripType.transportAirport');
      case 'Cruise: Red Sea Diving': return t('reservations.tripType.cruiseRedSea');
      default: return item;
    }
  };

  const getLocalizedDestination = (dest: string) => {
    switch (dest) {
      case 'Luxor': return t('reservations.destination.luxor');
      case 'Aswan': return t('reservations.destination.aswan');
      case 'Cairo': return t('reservations.destination.cairo');
      case 'Hurghada': return t('reservations.destination.hurghada');
      case 'Sharm El Sheikh': return t('reservations.destination.sharm');
      case 'Alexandria': return t('reservations.destination.alexandria');
      default: return dest;
    }
  };

  const getLocalizedRoomType = (type: string) => {
    switch (type) {
      case 'Standard': return t('reservations.roomType.standard');
      case 'Deluxe': return t('reservations.roomType.deluxe');
      case 'Superior': return t('reservations.roomType.superior');
      case 'Suite': return t('reservations.roomType.suite');
      case 'Family Room': return t('reservations.roomType.family');
      case 'Connecting Rooms': return t('reservations.roomType.connecting');
      default: return type;
    }
  };

  const getLocalizedMealPlan = (plan: string) => {
    switch (plan) {
      case 'Room Only': return t('reservations.mealPlan.roomOnly');
      case 'Breakfast': return t('reservations.mealPlan.breakfast');
      case 'Half Board': return t('reservations.mealPlan.halfBoard');
      case 'Full Board': return t('reservations.mealPlan.fullBoard');
      case 'All Inclusive': return t('reservations.mealPlan.allInclusive');
      default: return plan;
    }
  };

  const getLocalizedNationality = (nat: string) => {
    switch (nat) {
      case 'Egyptian': return t('reservations.nationality.egyptian');
      case 'American': return t('reservations.nationality.american');
      case 'British': return t('reservations.nationality.british');
      case 'German': return t('reservations.nationality.german');
      case 'French': return t('reservations.nationality.french');
      case 'Italian': return t('reservations.nationality.italian');
      case 'Spanish': return t('reservations.nationality.spanish');
      case 'Other': return t('reservations.nationality.other');
      default: return nat;
    }
  };

  const mockActivityLog = [
    {
      id: 1,
      type: 'created',
      description: t('reservations.activity.created'),
      user: t('reservations.agent.superadmin'),
      timestamp: '2025-01-12T14:30:00Z',
      details: t('reservations.activity.createdDesc')
    },
    {
      id: 2,
      type: 'assigned',
      description: t('reservations.activity.assigned'),
      user: t('reservations.agent.superadmin'),
      timestamp: '2025-01-12T14:35:00Z',
      details: t('reservations.activity.assignedDesc')
    },
    {
      id: 3,
      type: 'supplier_contact',
      description: t('reservations.activity.supplierContact'),
      user: t('reservations.agent.superadmin'),
      timestamp: '2025-01-13T09:15:00Z',
      details: t('reservations.activity.supplierContactDesc')
    },
    {
      id: 4,
      type: 'status_update',
      description: t('reservations.activity.statusUpdate'),
      user: t('reservations.agent.superadmin'),
      timestamp: '2025-01-13T16:45:00Z',
      details: t('reservations.activity.statusUpdateDesc')
    }
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'created': return <FileText className="h-4 w-4 text-blue-500" />;
      case 'assigned': return <User className="h-4 w-4 text-green-500" />;
      case 'supplier_contact': return <Phone className="h-4 w-4 text-orange-500" />;
      case 'status_update': return <Clock className="h-4 w-4 text-purple-500" />;
      default: return <FileText className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="w-full pb-8">
        <div className="mx-auto max-w-[1400px]">
            {/* Top Welcome Banner (NeoPay Style) */}
            <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "flex-row-reverse")}>
                <div className={cn(isRTL ? "text-right" : "text-left")}>
                    <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                        {t('reservations.modal.viewTitle').replace('{id}', reservation.id)}
                    </h1>
                </div>
                
                <div className={cn("flex items-center gap-2 sm:gap-3 banner-actions", isRTL && "flex-row-reverse")}>
                    <Button variant="outline" className="bg-white/10 text-white border-transparent hover:bg-white/20" onClick={() => navigate(-1)}>
                        {isRTL ? <ArrowRight className="h-4 w-4 ml-2" /> : <ArrowLeft className="h-4 w-4 mr-2" />}
                        {t('app.back')}
                    </Button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main Information */}
              <div className="lg:col-span-2 space-y-6">
                {/* Customer Information */}
                <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                      {t('reservations.modal.customerSection')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center gap-3">
                        <User className="h-5 w-5 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.form.customerName').replace(' *', '')}</p>
                          <p className="font-medium text-gray-900 dark:text-white">{reservation.customer}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Mail className="h-5 w-5 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.form.email').replace(' *', '')}</p>
                          <p className="font-medium text-gray-900 dark:text-white bidi-isolate">{reservation.customerEmail}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Phone className="h-5 w-5 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.form.phone').replace(' *', '')}</p>
                          <p className="font-medium text-gray-900 dark:text-white bidi-isolate">{reservation.customerPhone}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Globe className="h-5 w-5 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.form.nationality')}</p>
                          <p className="font-medium text-gray-900 dark:text-white">{getLocalizedNationality(reservation.nationality)}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Trip Information */}
                <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                      {t('reservations.modal.tripSection')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center gap-3">
                        <Building className="h-5 w-5 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.form.tripItem')}</p>
                          <p className="font-medium text-gray-900 dark:text-white">{getLocalizedTripItem(reservation.tripItem)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <MapPin className="h-5 w-5 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.form.destination')}</p>
                          <p className="font-medium text-gray-900 dark:text-white">{getLocalizedDestination(reservation.destination)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Calendar className="h-5 w-5 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.form.checkIn').replace(' *', '')}</p>
                          <p className="font-medium text-gray-900 dark:text-white bidi-isolate">{formatDate(reservation.checkIn)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Calendar className="h-5 w-5 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.form.checkOut').replace(' *', '')}</p>
                          <p className="font-medium text-gray-900 dark:text-white bidi-isolate">{formatDate(reservation.checkOut)}</p>
                        </div>
                      </div>
                      {reservation.totalNights > 0 && (
                        <div className="flex items-center gap-3">
                          <Clock className="h-5 w-5 text-gray-400" />
                          <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.table.nights')}</p>
                            <p className="font-medium text-gray-900 dark:text-white">{t('reservations.table.nightsCount').replace('{count}', String(reservation.totalNights))}</p>
                          </div>
                        </div>
                      )}
                      <div className="flex items-center gap-3">
                        <Users className="h-5 w-5 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.table.pax')}</p>
                          <p className="font-medium text-gray-900 dark:text-white">
                            {reservation.adults} {t('reservations.form.adults').replace(' *', '')}{reservation.children > 0 ? `, ${reservation.children} ${t('reservations.form.children')}` : ''}
                          </p>
                          {reservation.children > 0 && (
                            <p className="text-xs text-gray-500 dark:text-gray-400 bidi-isolate">
                              Ages: {reservation.childAges.join(', ')}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Service Details */}
                <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                      {t('reservations.form.specialRequests')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="flex items-center gap-3">
                        <Bed className="h-5 w-5 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.form.roomType')}</p>
                          <p className="font-medium text-gray-900 dark:text-white">{getLocalizedRoomType(reservation.roomType)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Utensils className="h-5 w-5 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.form.mealPlan')}</p>
                          <p className="font-medium text-gray-900 dark:text-white">{getLocalizedMealPlan(reservation.mealPlan)}</p>
                        </div>
                      </div>
                      {reservation.rooms > 0 && (
                        <div className="flex items-center gap-3">
                          <Bed className="h-5 w-5 text-gray-400" />
                          <div>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.form.rooms')}</p>
                            <p className="font-medium text-gray-900 dark:text-white">{reservation.rooms}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Special Requests */}
                {reservation.specialRequests && (
                  <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900">
                    <CardHeader>
                      <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                        {t('reservations.form.specialRequests')}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 dark:text-gray-300">{reservation.specialRequests}</p>
                    </CardContent>
                  </Card>
                )}

                {/* Notes */}
                {reservation.notes && (
                  <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900">
                    <CardHeader>
                      <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                        {t('reservations.action.internalNotes')}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 dark:text-gray-300">{reservation.notes}</p>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Status Information */}
                <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                      {t('reservations.filter.status')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.table.status')}</p>
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(reservation.status)}`}>
                          {getLocalizedStatus(reservation.status)}
                        </span>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.filter.finance')}</p>
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getFinanceStatusColor(reservation.financeStatus)}`}>
                          {getLocalizedFinanceStatus(reservation.financeStatus)}
                        </span>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.filter.agent')}</p>
                        <p className="font-medium text-gray-900 dark:text-white">{getLocalizedAgent(reservation.assignedAgent)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.table.supplier')}</p>
                        <p className="font-medium text-gray-900 dark:text-white">{getLocalizedSupplier(reservation.supplier)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.modal.taskDueDate')}</p>
                        <p className="font-medium text-gray-900 dark:text-white bidi-isolate">{formatDate(reservation.dueDate)}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Activity Log */}
                <Card className="rounded-3xl border-0 shadow-[0_4px_24px_-8px_rgba(0,0,0,0.05)] bg-white dark:bg-gray-900">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">
                      {t('reservations.modal.activitySection')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mockActivityLog.map((activity) => (
                        <div key={activity.id} className="flex gap-3">
                          <div className="flex-shrink-0">
                            {getActivityIcon(activity.type)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 dark:text-white">
                              {activity.description}
                            </p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">
                              by {activity.user} • <span className="bidi-isolate">{formatDate(activity.timestamp)}</span>
                            </p>
                            {activity.details && (
                              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                                {activity.details}
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                  <h4 className="text-sm font-semibold text-blue-800 dark:text-blue-300 mb-3">
                    {t('reservations.modal.activitySection')}
                  </h4>
                  <div className="space-y-2">
                    <button className="w-full text-left rtl:text-right text-sm text-blue-700 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300">
                      • {t('reservations.action.contactSupplier')}
                    </button>
                    <button className="w-full text-left rtl:text-right text-sm text-blue-700 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300">
                      • {t('reservations.modal.editTask')}
                    </button>
                    <button className="w-full text-left rtl:text-right text-sm text-blue-700 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300">
                      • {t('reservations.finance.paymentRequested')}
                    </button>
                    <button className="w-full text-left rtl:text-right text-sm text-blue-700 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300">
                      • {t('reservations.action.uploadDocument')}
                    </button>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
  );
};