import React, { useState } from 'react';
import { Plus, Search, Eye, MessageSquare, Upload, Phone, UserCheck, Calendar, Clock, AlertTriangle, CheckCircle, Download, FileText } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { PageHeader } from '../ui/PageHeader';
import { TableActionsDropdown, ActionItem } from '../ui/TableActionsDropdown';
import { StatCard } from '../ui/StatCard';
import { StatusBadge, BadgeVariant } from '../ui/StatusBadge';
import { Card, CardContent } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { formatDate } from '../../utils/format';
// All modals converted to pages
import { useToastContext } from '../../contexts/ToastContext';
import { mockReservations, mockTasks } from '../../services/mockData';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

export interface ReservationTask {
  id: string;
  title: string;
  bookingId: string;
  customer: string;
  dueDate: string;
  status: string;
  priority: string;
  assignedTo: string;
  description: string;
}

export interface Reservation {
  id: string;
  customer: string;
  customerEmail: string;
  customerPhone: string;
  tripItem: string;
  roomType: string;
  destination: string;
  checkIn: string;
  checkOut: string;
  totalNights: number;
  adults: number;
  children: number;
  childAges: number[];
  rooms: number;
  mealPlan: string;
  nationality: string;
  supplier: string;
  status: string;
  financeStatus: string;
  assignedAgent: string;
  specialRequests: string;
  createdAt: string;
  dueDate: string;
  supplierResponseTime: string;
  notes?: string;
}

export interface ReservationDocument {
  file: File;
  type: string;
  description: string;
  reservationId: string;
  uploadedBy: string;
  uploadDate: string;
}

export type NewReservationData = Omit<Reservation, 'id' | 'status' | 'financeStatus' | 'createdAt' | 'supplierResponseTime'>;

export const ReservationsPage: React.FC = () => {
    const { t, isRTL, direction } = useLocale();
    const navigate = useNavigate();
    const [reservations, setReservations] = useState<Reservation[]>(mockReservations as Reservation[]);
    const [tasks, setTasks] = useState<ReservationTask[]>(mockTasks as ReservationTask[]);
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('All Status');
    const [supplierFilter, setSupplierFilter] = useState('All Suppliers');
    const [agentFilter, setAgentFilter] = useState('All Agents');
    const [financeFilter, setFinanceFilter] = useState('All Finance Status');
    const [dateFromFilter, setDateFromFilter] = useState('');
    const [dateToFilter, setDateToFilter] = useState('');
    const [activeMetricFilter, setActiveMetricFilter] = useState('');

    // All modal states replaced by page navigation
    const [selectedReservation, setSelectedReservation] = useState<Reservation | null>(null);

    const toast = useToastContext();

    const getLocalizedStatus = (status: string) => {
        switch (status) {
            case 'New': return t('reservations.status.new');
            case 'Pending': return t('reservations.status.pending');
            case 'Confirmed': return t('reservations.status.confirmed');
            case 'Awaiting Supplier': return t('reservations.status.awaitingSupplier');
            case 'Reserved': return t('reservations.status.reserved');
            case 'Cancelled': return t('reservations.status.cancelled');
            default: return status;
        }
    };

    const getLocalizedFinanceStatus = (status: string) => {
        switch (status) {
            case 'Pending': return t('reservations.finance.pending');
            case 'Payment Requested': return t('reservations.finance.paymentRequested');
            case 'Deposit Paid': return t('reservations.finance.depositPaid');
            case 'Paid': return t('reservations.finance.paid');
            case 'Fully Paid': return t('reservations.finance.fullyPaid');
            case 'Refunded': return t('reservations.finance.refunded');
            default: return status;
        }
    };

    const getLocalizedSupplier = (supplier: string) => {
        switch (supplier) {
            case 'Steigenberger Hotels': return t('reservations.supplier.steigerberger');
            case 'Hilton Hotels': return t('reservations.supplier.hilton');
            case 'EgyptAir': return t('reservations.supplier.egyptair');
            case 'Cairo Tours': return t('reservations.supplier.cairotours');
            case 'Nile Cruise Co': return t('reservations.supplier.nilecruise');
            case 'Local Operators': return t('reservations.supplier.local');
            default: return supplier;
        }
    };

    const getLocalizedTripItem = (item: string) => {
        switch (item) {
            case 'Hotel: Steigenberger Luxor': return t('reservations.tripType.hotelSteigenberger');
            case 'Hotel: Hilton Aswan Resort': return t('reservations.tripType.hotelHilton');
            case 'Flight: CAI-LXR Economy': return t('reservations.tripType.flightCaiLxr');
            case 'Tour: Valley of Kings': return t('reservations.tripType.tourValley');
            case 'Activity: Nile Felucca Ride': return t('reservations.tripType.activityNile');
            case 'Package: Nile Cruise 4 Days': return t('reservations.tripType.packageNile');
            case 'Transport: Airport Transfer': return t('reservations.tripType.transportAirport');
            case 'Cruise: Red Sea Diving': return t('reservations.tripType.cruiseRedSea');
            default: return item;
        }
    };

    const getLocalizedDestination = (dest: string) => {
        switch (dest) {
            case 'Luxor': return t('reservations.destination.luxor');
            case 'Aswan': return t('reservations.destination.aswan');
            case 'Cairo': return t('reservations.destination.cairo');
            case 'Hurghada': return t('reservations.destination.hurghada');
            case 'Sharm El Sheikh': return t('reservations.destination.sharm');
            case 'Alexandria': return t('reservations.destination.alexandria');
            default: return dest;
        }
    };

    const getStatusVariant = (status: string): BadgeVariant => {
        switch (status) {
            case 'New': return 'blue';
            case 'Pending': return 'amber';
            case 'Confirmed': return 'emerald';
            case 'Awaiting Supplier': return 'amber';
            case 'Reserved': return 'purple';
            case 'Cancelled': return 'rose';
            default: return 'gray';
        }
    };

    const getFinanceStatusVariant = (status: string): BadgeVariant => {
        switch (status) {
            case 'Pending': return 'gray';
            case 'Payment Requested': return 'amber';
            case 'Deposit Paid': return 'blue';
            case 'Paid': return 'emerald';
            case 'Fully Paid': return 'emerald';
            case 'Refunded': return 'rose';
            default: return 'gray';
        }
    };

    const handleNotes = (reservation: Reservation) => {
        navigate('/reservations/notes', { state: { reservation } });
    };

    const handleUpload = (reservation: Reservation) => {
        navigate('/reservations/upload', { state: { reservation } });
    };

    const handleConfirmReservation = (reservationId: string) => {
        setReservations(prev => prev.map(res =>
            res.id === reservationId
                ? { ...res, status: 'Confirmed', financeStatus: 'Payment Requested' }
                : res
        ));
        toast.success(t('reservations.toast.confirmed'), t('reservations.toast.confirmedDesc'));
    };

    const handleSupplierContact = (reservation: Reservation) => {
        toast.info(t('reservations.toast.contact'), t('reservations.toast.contactDesc').replace('{supplier}', getLocalizedSupplier(reservation.supplier)).replace('{customer}', reservation.customer));
    };

    const handleMetricClick = (metricType: string) => {
        setActiveMetricFilter(metricType);
        switch (metricType) {
            case 'new':
                setStatusFilter('New');
                break;
            case 'pending':
                setStatusFilter('Pending');
                break;
            case 'overdue':
                setStatusFilter('All Status');
                break;
            case 'ready':
                setStatusFilter('Reserved');
                break;
            case 'tasks':
                navigate('/reservations/tasks', { state: { tasks } });
                break;
            default:
                setStatusFilter('All Status');
        }
    };

    const filteredReservations = reservations.filter(reservation => {
        const matchesSearch = reservation.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
            reservation.id.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus = statusFilter === 'All Status' || reservation.status === statusFilter;
        const matchesSupplier = supplierFilter === 'All Suppliers' || reservation.supplier === supplierFilter;
        const matchesAgent = agentFilter === 'All Agents' || reservation.assignedAgent === agentFilter;
        const matchesFinance = financeFilter === 'All Finance Status' || reservation.financeStatus === financeFilter;

        let matchesDateRange = true;
        if (dateFromFilter && dateToFilter) {
            const checkInDate = new Date(reservation.checkIn);
            const fromDate = new Date(dateFromFilter);
            const toDate = new Date(dateToFilter);
            matchesDateRange = checkInDate >= fromDate && checkInDate <= toDate;
        }

        return matchesSearch && matchesStatus && matchesSupplier && matchesAgent && matchesFinance && matchesDateRange;
    });

    const metrics = {
        new: reservations.filter(r => r.status === 'New').length,
        pending: reservations.filter(r => r.status === 'Pending' || r.status === 'Awaiting Supplier').length,
        overdue: reservations.filter(r => {
            const dueDate = new Date(r.dueDate);
            const today = new Date();
            return dueDate < today && (r.status === 'New' || r.status === 'Pending');
        }).length,
        ready: reservations.filter(r => r.status === 'Reserved' || r.status === 'Confirmed').length,
        tasks: tasks.filter(t => t.status === 'Due Today' || t.status === 'Overdue').length
    };

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", isRTL && "sm:flex-row-reverse")}>
                    <div>
                        <h1 className="text-2xl font-bold text-white mb-1">{t('reservations.title')}</h1>
                        <p className="text-blue-100 font-medium">{t('reservations.subtitle')}</p>
                    </div>
                    <div className={cn("flex flex-wrap gap-2", isRTL && "flex-row-reverse")}>
                        <Button variant="outline" className="bg-white/10 text-white border-white/20 hover:bg-white/20" onClick={() => navigate('/reservations/tracker')}>
                            <Clock className={cn("h-4 w-4", isRTL ? 'ml-2' : 'mr-2')} />
                            {t('reservations.action.tracker')}
                        </Button>
                        <Button variant="outline" className="bg-white/10 text-white border-white/20 hover:bg-white/20" onClick={() => navigate('/reservations/new-supplier')}>
                            <Plus className={cn("h-4 w-4", isRTL ? 'ml-2' : 'mr-2')} />
                            {t('reservations.action.supplier')}
                        </Button>
                        <Button className="bg-white text-blue-600 hover:bg-blue-50" onClick={() => navigate('/reservations/new')}>
                            <Plus className={cn("h-4 w-4", isRTL ? 'ml-2' : 'mr-2')} />
                            {t('reservations.action.newReservation')}
                        </Button>
                    </div>
                </div>

            {/* Dashboard Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                <StatCard label={t('reservations.metrics.new')} value={metrics.new} icon={FileText} iconBg="bg-blue-50 dark:bg-blue-900/20" iconColor="text-blue-500" onClick={() => handleMetricClick('new')} isActive={activeMetricFilter === 'new'} />
                <StatCard label={t('reservations.metrics.pending')} value={metrics.pending} icon={Clock} iconBg="bg-yellow-50 dark:bg-yellow-900/20" iconColor="text-yellow-500" onClick={() => handleMetricClick('pending')} isActive={activeMetricFilter === 'pending'} />
                <StatCard label={t('reservations.metrics.overdue')} value={metrics.overdue} icon={AlertTriangle} iconBg="bg-red-50 dark:bg-red-900/20" iconColor="text-red-500" onClick={() => handleMetricClick('overdue')} isActive={activeMetricFilter === 'overdue'} />
                <StatCard label={t('reservations.metrics.ready')} value={metrics.ready} icon={CheckCircle} iconBg="bg-green-50 dark:bg-green-900/20" iconColor="text-green-500" onClick={() => handleMetricClick('ready')} isActive={activeMetricFilter === 'ready'} />
                <StatCard label={t('reservations.metrics.tasks')} value={metrics.tasks} icon={Calendar} iconBg="bg-purple-50 dark:bg-purple-900/20" iconColor="text-purple-500" onClick={() => handleMetricClick('tasks')} isActive={activeMetricFilter === 'tasks'} />
            </div>

            {/* Filters */}
            <Card className="card-premium mt-6">
                <CardContent className="p-6">
                    <div className="grid grid-cols-1 lg:grid-cols-7 gap-4">
                        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                            <option value="All Status">{t('reservations.filter.allStatus')}</option>
                            <option value="New">{t('reservations.status.new')}</option>
                            <option value="Pending">{t('reservations.status.pending')}</option>
                            <option value="Confirmed">{t('reservations.status.confirmed')}</option>
                            <option value="Awaiting Supplier">{t('reservations.status.awaitingSupplier')}</option>
                            <option value="Reserved">{t('reservations.status.reserved')}</option>
                            <option value="Cancelled">{t('reservations.status.cancelled')}</option>
                        </Select>

                        <Select value={supplierFilter} onChange={(e) => setSupplierFilter(e.target.value)}>
                            <option value="All Suppliers">{t('reservations.filter.allSuppliers')}</option>
                            <option value="Steigenberger Hotels">{t('reservations.supplier.steigerberger')}</option>
                            <option value="EgyptAir">{t('reservations.supplier.egyptair')}</option>
                            <option value="Cairo Tours">{t('reservations.supplier.cairotours')}</option>
                            <option value="Hilton Hotels">{t('reservations.supplier.hilton')}</option>
                            <option value="Nile Cruise Co">{t('reservations.supplier.nilecruise')}</option>
                        </Select>

                        <Select value={agentFilter} onChange={(e) => setAgentFilter(e.target.value)}>
                            <option value="All Agents">{t('reservations.filter.allAgents')}</option>
                            <option value="Super Admin">{t('reservations.agent.superadmin')}</option>
                            <option value="Mahmoud Khalil">{t('reservations.agent.mahmoud')}</option>
                            <option value="Layla Ramadan">{t('reservations.agent.layla')}</option>
                            <option value="Sami Youssef">{t('reservations.agent.sami')}</option>
                            <option value="Mona Zaki">{t('reservations.agent.mona')}</option>
                        </Select>

                        <Select value={financeFilter} onChange={(e) => setFinanceFilter(e.target.value)}>
                            <option value="All Finance Status">{t('reservations.filter.allFinanceStatus')}</option>
                            <option value="Pending">{t('reservations.finance.pending')}</option>
                            <option value="Payment Requested">{t('reservations.finance.paymentRequested')}</option>
                            <option value="Deposit Paid">{t('reservations.finance.depositPaid')}</option>
                            <option value="Paid">{t('reservations.finance.paid')}</option>
                            <option value="Fully Paid">{t('reservations.finance.fullyPaid')}</option>
                        </Select>

                        <Input type="date" value={dateFromFilter} onChange={(e) => setDateFromFilter(e.target.value)} />
                        <Input type="date" value={dateToFilter} onChange={(e) => setDateToFilter(e.target.value)} />

                        <div className="relative">
                            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400`} />
                            <Input
                                placeholder={t('reservations.filter.searchPlaceholder')}
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className={isRTL ? 'pr-10 pl-3' : 'pl-10 pr-3'}
                            />
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Table */}
            <div className="table-container mt-6">
                <table className="table-premium">
                    <thead>
                        <tr>
                            <th>{t('reservations.table.bookingId')}</th>
                            <th>{t('reservations.table.customer')}</th>
                            <th>{t('reservations.table.tripItem')}</th>
                            <th>{t('reservations.table.dates')}</th>
                            <th>{t('reservations.table.pax')}</th>
                            <th>{t('reservations.table.supplier')}</th>
                            <th>{t('reservations.table.status')}</th>
                            <th>{t('reservations.table.finance')}</th>
                            <th className={isRTL ? 'text-left' : 'text-right'}>{t('reservations.table.actions')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredReservations.map((reservation) => (
                            <tr key={reservation.id}>
                                <td>
                                    <div className="font-bold text-gray-900 dark:text-white bidi-isolate">{reservation.id}</div>
                                    <div className="text-[10px] text-gray-500 font-bold uppercase tracking-widest bidi-isolate">{formatDate(reservation.createdAt)}</div>
                                </td>
                                <td>
                                    <div className="text-sm font-medium">{reservation.customer}</div>
                                    <div className="text-[10px] text-gray-500 bidi-isolate">{reservation.customerEmail}</div>
                                </td>
                                <td>
                                    <div className="text-xs font-bold text-gray-900 dark:text-white">{getLocalizedTripItem(reservation.tripItem)}</div>
                                    <div className="text-[10px] text-gray-500">{getLocalizedDestination(reservation.destination)}</div>
                                </td>
                                <td>
                                    <div className="text-xs bidi-isolate">{formatDate(reservation.checkIn)}</div>
                                    <div className="text-[10px] text-gray-500">{t('reservations.table.nightsCount').replace('{count}', String(reservation.totalNights))}</div>
                                </td>
                                <td>
                                    <div className="text-xs bidi-isolate">{reservation.adults}A, {reservation.children}C</div>
                                </td>
                                <td>
                                    <div className="text-xs font-medium">{getLocalizedSupplier(reservation.supplier)}</div>
                                </td>
                                <td>
                                    <StatusBadge variant={getStatusVariant(reservation.status)}>{getLocalizedStatus(reservation.status)}</StatusBadge>
                                </td>
                                <td>
                                    <StatusBadge variant={getFinanceStatusVariant(reservation.financeStatus)}>{getLocalizedFinanceStatus(reservation.financeStatus)}</StatusBadge>
                                </td>
                                <td className={isRTL ? 'text-left' : 'text-right'}>
                                    <TableActionsDropdown
                                        actions={[
                                            { label: t('reservations.action.viewDetails'), icon: Eye, onClick: () => navigate('/reservations/view', { state: { reservation } }) },
                                            { label: t('reservations.action.internalNotes'), icon: MessageSquare, onClick: () => handleNotes(reservation) },
                                            { label: t('reservations.action.uploadDocument'), icon: Upload, onClick: () => handleUpload(reservation) },
                                            { label: t('reservations.action.contactSupplier'), icon: Phone, onClick: () => handleSupplierContact(reservation) },
                                            { label: t('reservations.action.downloadVoucher'), icon: Download, onClick: () => { toast.success(t('reservations.toast.voucherGenerated'), t('reservations.toast.voucherGeneratedDesc').replace('{id}', reservation.id)); } },
                                            ...(reservation.status === 'Pending' || reservation.status === 'Awaiting Supplier' ? [{ label: t('reservations.action.confirmBooking'), icon: UserCheck, onClick: () => handleConfirmReservation(reservation.id) }] : [])
                                        ]}
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {filteredReservations.length === 0 && (
                <Card className="card-premium mt-6">
                    <CardContent className="p-12 text-center">
                        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-50 dark:bg-gray-800 mb-4 text-gray-400">
                            <Calendar className="h-8 w-8" />
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white">{t('reservations.empty.title')}</h3>
                        <p className="description-sm">{t('reservations.empty.desc')}</p>
                    </CardContent>
                </Card>
            )}

            {/* All modals converted to pages */}
            </div>
        </div>
    );
};
