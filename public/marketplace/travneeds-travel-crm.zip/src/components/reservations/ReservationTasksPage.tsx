import React, { useState, useEffect } from 'react';
import { Calendar, Clock, AlertTriangle, CheckCircle, Plus, Edit, Save, ArrowLeft, Search } from 'lucide-react';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { formatDate } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';
import { ReservationTask } from './ReservationsPage';
import { mockTasks } from '../../services/mockData';

export const ReservationTasksPage: React.FC = () => {
  const { t, direction, isRTL } = useLocale();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToastContext();

  const initialTasks = (location.state?.tasks as ReservationTask[]) || mockTasks || [];
  const [tasks, setTasks] = useState<ReservationTask[]>(initialTasks);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [isNewTaskOpen, setIsNewTaskOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<ReservationTask | null>(null);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Overdue': return 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-300';
      case 'Due Today': return 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-300';
      case 'Completed': return 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-300';
      case 'Pending': return 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/20 dark:text-blue-300';
      default: return 'bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Critical': return 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-300';
      case 'High': return 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-900/20 dark:text-orange-300';
      case 'Medium': return 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-300';
      case 'Low': return 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-300';
      default: return 'bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const translateStatus = (status: string) => {
    switch (status) {
      case 'Overdue': return t('reservations.taskStatus.overdue');
      case 'Due Today': return t('reservations.taskStatus.dueToday');
      case 'Completed': return t('reservations.taskStatus.completed');
      case 'Pending': return t('reservations.taskStatus.pending');
      default: return status;
    }
  };

  const translatePriority = (priority: string) => {
    switch (priority) {
      case 'Critical': return t('reservations.priority.critical');
      case 'High': return t('reservations.priority.high');
      case 'Medium': return t('reservations.priority.medium');
      case 'Low': return t('reservations.priority.low');
      default: return priority;
    }
  };

  const translateAgent = (agent: string) => {
    switch (agent) {
      case 'Super Admin': return t('reservations.agent.superadmin');
      case 'Mahmoud Khalil': return t('reservations.agent.mahmoud');
      case 'Layla Ramadan': return t('reservations.agent.layla');
      case 'Sami Youssef': return t('reservations.agent.sami');
      case 'Mona Zaki': return t('reservations.agent.mona');
      default: return agent;
    }
  };

  const handleCompleteTask = (taskId: string) => {
    const updated = tasks.map(task => task.id === taskId ? { ...task, status: 'Completed' } : task);
    setTasks(updated);
    toast.success(isRTL ? 'تم إتمام المهمة' : 'Task Completed', isRTL ? 'تم تحديث حالة المهمة بنجاح.' : 'Task status updated successfully.');
  };

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         task.customer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || task.status === statusFilter;
    const matchesPriority = priorityFilter === 'All' || task.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const overdueTasks = tasks.filter(t => t.status === 'Overdue');
  const dueTodayTasks = tasks.filter(t => t.status === 'Due Today');
  const completedTasks = tasks.filter(t => t.status === 'Completed');

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        {/* Header Banner */}
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate(-1)} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
              <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-xl">
                <Calendar className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                  {t('reservations.modal.tasksTitleCount')?.replace('{count}', String(tasks.length)) || `Reservation Tasks (${tasks.length})`}
                </h1>
                <p className="mt-1 text-sm text-blue-100 opacity-90">
                  {isRTL ? 'إدارة ومتابعة مهام الحجوزات' : 'Manage and follow up on reservation tasks'}
                </p>
              </div>
            </div>
          </div>
          <Button onClick={() => setIsNewTaskOpen(true)} className="bg-white text-blue-600 hover:bg-blue-50 border-transparent font-bold">
            <Plus className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
            {t('reservations.modal.createTask')}
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/30 rounded-2xl p-6 flex items-center justify-between">
            <div>
              <p className="text-sm font-bold text-red-600 dark:text-red-400 uppercase tracking-wider">{t('reservations.modal.overdueTasks')}</p>
              <p className="text-3xl font-black text-red-800 dark:text-red-300 mt-1">{overdueTasks.length}</p>
            </div>
            <div className="p-3 bg-red-100 dark:bg-red-900/30 rounded-2xl">
              <AlertTriangle className="h-7 w-7 text-red-500" />
            </div>
          </div>
          <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/30 rounded-2xl p-6 flex items-center justify-between">
            <div>
              <p className="text-sm font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">{t('reservations.modal.dueTodayTasks')}</p>
              <p className="text-3xl font-black text-amber-800 dark:text-amber-300 mt-1">{dueTodayTasks.length}</p>
            </div>
            <div className="p-3 bg-amber-100 dark:bg-amber-900/30 rounded-2xl">
              <Clock className="h-7 w-7 text-amber-500" />
            </div>
          </div>
          <div className="bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-900/30 rounded-2xl p-6 flex items-center justify-between">
            <div>
              <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">{t('reservations.modal.completedTasks')}</p>
              <p className="text-3xl font-black text-emerald-800 dark:text-emerald-300 mt-1">{completedTasks.length}</p>
            </div>
            <div className="p-3 bg-emerald-100 dark:bg-emerald-900/30 rounded-2xl">
              <CheckCircle className="h-7 w-7 text-emerald-500" />
            </div>
          </div>
        </div>

        {/* Tasks Table */}
        <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-800 overflow-hidden">
          {/* Filters */}
          <div className="p-6 border-b border-gray-100 dark:border-gray-800 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400`} />
              <input
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder={t('reservations.modal.searchTasks') || 'Search tasks...'}
                className={`w-full ${isRTL ? 'pr-10 pl-4' : 'pl-10 pr-4'} py-2.5 border border-gray-200 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none`}
              />
            </div>
            <div className="flex items-center gap-3">
              <select
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value)}
                className="px-4 py-2.5 border border-gray-200 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-sm font-medium focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="All">{t('reservations.taskStatus.all')}</option>
                <option value="Overdue">{t('reservations.taskStatus.overdue')}</option>
                <option value="Due Today">{t('reservations.taskStatus.dueToday')}</option>
                <option value="Completed">{t('reservations.taskStatus.completed')}</option>
                <option value="Pending">{t('reservations.taskStatus.pending')}</option>
              </select>
              <select
                value={priorityFilter}
                onChange={e => setPriorityFilter(e.target.value)}
                className="px-4 py-2.5 border border-gray-200 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-sm font-medium focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="All">{t('reservations.priority.all')}</option>
                <option value="Critical">{t('reservations.priority.critical')}</option>
                <option value="High">{t('reservations.priority.high')}</option>
                <option value="Medium">{t('reservations.priority.medium')}</option>
                <option value="Low">{t('reservations.priority.low')}</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-800/50 border-b border-gray-100 dark:border-gray-800">
                <tr>
                  {[t('reservations.modal.colTask'), t('reservations.table.customer'), t('reservations.table.bookingId'), t('reservations.modal.colDueDate'), t('reservations.modal.colPriority'), t('reservations.modal.colStatus'), t('reservations.modal.colAssignedTo'), t('reservations.modal.colActions')].map(header => (
                    <th key={header} className={`px-6 py-4 ${isRTL ? 'text-right' : 'text-left'} text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider`}>{header}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                {filteredTasks.map((task) => (
                  <tr key={task.id} className="hover:bg-blue-50/30 dark:hover:bg-gray-800/50 transition-colors">
                    <td className="px-6 py-4">
                      <div>
                        <div className="text-sm font-bold text-gray-900 dark:text-white">{task.title}</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400 truncate max-w-xs mt-0.5">{task.description}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-gray-900 dark:text-white whitespace-nowrap">{task.customer}</td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-bold text-blue-600 dark:text-blue-400 bidi-isolate">{task.bookingId}</span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 whitespace-nowrap">
                      <span className="bidi-isolate">{formatDate(task.dueDate)}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2.5 py-1 text-xs font-bold rounded-lg border ${getPriorityColor(task.priority)}`}>
                        {translatePriority(task.priority)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2.5 py-1 text-xs font-bold rounded-lg border ${getStatusColor(task.status)}`}>
                        {translateStatus(task.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600 dark:text-gray-300 whitespace-nowrap font-medium">{translateAgent(task.assignedTo)}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex gap-2">
                        <button
                          onClick={() => setEditingTask(task)}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                          title={t('reservations.modal.editTask')}
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        {task.status !== 'Completed' && (
                          <button
                            onClick={() => handleCompleteTask(task.id)}
                            className="p-1.5 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition-colors"
                            title={t('reservations.modal.markComplete')}
                          >
                            <CheckCircle className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {filteredTasks.length === 0 && (
              <div className="text-center py-16">
                <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="text-base font-bold text-gray-900 dark:text-white mb-1">{t('reservations.modal.noTasksTitle')}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">{t('reservations.modal.noTasksDesc')}</p>
              </div>
            )}
          </div>
        </div>

        {/* New Task Inline Form */}
        {isNewTaskOpen && (
          <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-sm border border-blue-100 dark:border-blue-900/30 p-8">
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-3">
              <div className="p-2 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
                <Plus className="h-5 w-5 text-blue-600" />
              </div>
              {t('reservations.modal.createTaskTitle')}
            </h3>
            <form onSubmit={e => { e.preventDefault(); toast.success(isRTL ? 'تم إنشاء المهمة' : 'Task Created', ''); setIsNewTaskOpen(false); }}>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <Input label={t('reservations.modal.taskName')} placeholder={isRTL ? 'اسم المهمة' : 'Task name'} required />
                <Input label={t('reservations.modal.taskCustomer')} placeholder={isRTL ? 'اسم العميل' : 'Customer name'} required />
                <Input label={t('reservations.modal.taskBookingId')} placeholder="RES-001" />
                <Input type="date" label={t('reservations.modal.taskDueDate')} required />
                <Select label={t('reservations.modal.taskPriority')}>
                  <option value="Low">{t('reservations.priority.low')}</option>
                  <option value="Medium">{t('reservations.priority.medium')}</option>
                  <option value="High">{t('reservations.priority.high')}</option>
                  <option value="Critical">{t('reservations.priority.critical')}</option>
                </Select>
                <Select label={t('reservations.modal.taskAssignedTo')}>
                  <option value="Super Admin">{t('reservations.agent.superadmin')}</option>
                  <option value="Mahmoud Khalil">{t('reservations.agent.mahmoud')}</option>
                  <option value="Layla Ramadan">{t('reservations.agent.layla')}</option>
                  <option value="Sami Youssef">{t('reservations.agent.sami')}</option>
                  <option value="Mona Zaki">{t('reservations.agent.mona')}</option>
                </Select>
              </div>
              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('reservations.modal.taskDescription')}</label>
                <textarea rows={3} className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500 dark:text-white" placeholder={t('reservations.modal.taskDescriptionPlaceholder')} />
              </div>
              <div className="flex justify-end gap-3 mt-6">
                <Button type="button" variant="outline" onClick={() => setIsNewTaskOpen(false)}>{t('reservations.modal.cancel')}</Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  <Plus className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                  {t('reservations.modal.createTaskBtn')}
                </Button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
