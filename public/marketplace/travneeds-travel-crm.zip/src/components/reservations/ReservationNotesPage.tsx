import React, { useState, useEffect } from 'react';
import { Save, MessageSquare, Send, ArrowLeft } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { formatDate } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToastContext } from '../../contexts/ToastContext';
import { cn } from '../../utils/cn';
import { Reservation } from './ReservationsPage';

export interface ReservationNote {
  id: number;
  content: string;
  author: string;
  department: string;
  timestamp: string;
  type: string;
  recipient: string | null;
}

const mockExistingNotes: ReservationNote[] = [
  {
    id: 1,
    content: 'Customer confirmed Nile view room preference. Contacted supplier for availability.',
    author: 'Super Admin',
    department: 'Reservation',
    timestamp: '2025-01-15T10:30:00Z',
    type: 'internal',
    recipient: null
  },
  {
    id: 2,
    content: 'Payment request sent to Finance team. Awaiting deposit confirmation.',
    author: 'Super Admin',
    department: 'Reservation',
    timestamp: '2025-01-14T16:45:00Z',
    type: 'interdepartmental',
    recipient: 'Finance'
  },
  {
    id: 3,
    content: 'Supplier response received. Room available but rate increased by $20/night.',
    author: 'Super Admin',
    department: 'Reservation',
    timestamp: '2025-01-13T09:15:00Z',
    type: 'supplier_update',
    recipient: null
  }
];

const departments = ['Sales', 'Finance', 'Operations', 'Customer Service'];

export const ReservationNotesPage: React.FC = () => {
  const { t, direction, isRTL } = useLocale();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToastContext();

  const reservation = location.state?.reservation as Reservation;

  const [newNote, setNewNote] = useState('');
  const [noteType, setNoteType] = useState<'internal' | 'interdepartmental'>('internal');
  const [targetDepartment, setTargetDepartment] = useState('Sales');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!reservation) {
      navigate('/reservations');
    }
  }, [reservation, navigate]);

  if (!reservation) return null;

  const translateDepartment = (dept: string) => {
    switch (dept) {
      case 'Sales': return t('nav.sales') || 'Sales';
      case 'Finance': return t('common.finance') || 'Finance';
      case 'Operations': return t('nav.operations') || 'Operations';
      case 'Customer Service': return isRTL ? 'خدمة العملاء' : 'Customer Service';
      default: return dept;
    }
  };

  const translateTripItem = (item: string) => {
    switch (item) {
      case 'Hotel: Steigenberger Luxor': return t('reservations.tripType.hotelSteigenberger');
      case 'Hotel: Hilton Aswan Resort': return t('reservations.tripType.hotelHilton');
      case 'Flight: CAI-LXR Economy': return t('reservations.tripType.flightCaiLxr');
      case 'Tour: Valley of Kings': return t('reservations.tripType.tourValley');
      case 'Activity: Nile Felucca Ride': return t('reservations.tripType.activityNile');
      case 'Package: Nile Cruise 4 Days': return t('reservations.tripType.packageNile');
      case 'Transport: Airport Transfer': return t('reservations.tripType.transportAirport');
      case 'Cruise: Red Sea Diving': return t('reservations.tripType.cruiseRedSea');
      default: return item;
    }
  };

  const translateStatus = (status: string) => {
    switch (status) {
      case 'New': return t('reservations.status.new');
      case 'Pending': return t('reservations.status.pending');
      case 'Confirmed': return t('reservations.status.confirmed');
      case 'Awaiting Supplier': return t('reservations.status.awaitingSupplier');
      case 'Reserved': return t('reservations.status.reserved');
      case 'Cancelled': return t('reservations.status.cancelled');
      default: return status;
    }
  };

  const translateSupplier = (supplier: string) => {
    switch (supplier) {
      case 'Steigenberger Hotels': return t('reservations.supplier.steigerberger');
      case 'Hilton Hotels': return t('reservations.supplier.hilton');
      case 'EgyptAir': return t('reservations.supplier.egyptair');
      case 'Cairo Tours': return t('reservations.supplier.cairotours');
      case 'Nile Cruise Co': return t('reservations.supplier.nilecruise');
      case 'Local Operators': return t('reservations.supplier.local');
      default: return supplier;
    }
  };

  const translateAgent = (agent: string) => {
    switch (agent) {
      case 'Super Admin': return t('reservations.agent.superadmin');
      case 'Mahmoud Khalil': return t('reservations.agent.mahmoud');
      case 'Layla Ramadan': return t('reservations.agent.layla');
      case 'Sami Youssef': return t('reservations.agent.sami');
      case 'Mona Zaki': return t('reservations.agent.mona');
      default: return agent;
    }
  };

  const translateNoteContent = (noteContent: string, noteId: number) => {
    switch (noteId) {
      case 1: return t('reservations.notes.item1');
      case 2: return t('reservations.notes.item2');
      case 3: return t('reservations.notes.item3');
      default: return noteContent;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim()) return;

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      toast.success(
        isRTL ? 'تم الحفظ بنجاح' : 'Saved Successfully',
        isRTL ? 'تم حفظ الملاحظة للمراجعة لاحقاً.' : 'Note has been saved successfully.'
      );
      setNewNote('');
      navigate(-1);
    } catch (error) {
      toast.error('Error', 'Failed to save note.');
    } finally {
      setIsLoading(false);
    }
  };

  const getNoteTypeColor = (type: string) => {
    switch (type) {
      case 'internal': return 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/20 dark:text-blue-300';
      case 'interdepartmental': return 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-900/20 dark:text-purple-300';
      case 'supplier_update': return 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-300';
      default: return 'bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  return (
    <div className="w-full pb-8" dir={direction}>
      <div className="mx-auto max-w-[1400px] space-y-6">
        {/* Top Header Banner */}
        <div className={cn("flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#2563EB] text-white p-8 rounded-3xl shadow-lg shadow-blue-500/20", isRTL && "flex-row-reverse")}>
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => navigate(-1)} className="p-2 bg-white/10 text-white border-transparent hover:bg-white/20">
              <ArrowLeft size={20} className={cn(isRTL && "rotate-180")} />
            </Button>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 rounded-xl">
                <MessageSquare className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight bidi-isolate">
                  {t('reservations.modal.notesTitle')?.replace('{id}', reservation.id) || `Communication Notes`}
                </h1>
                <p className="mt-1 text-sm text-blue-100 opacity-90">
                  {isRTL ? 'متابعة الملاحظات والرسائل للحجز الحالي' : 'Track and manage communication notes for this reservation'}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-10 shadow-sm border border-gray-100 dark:border-gray-800">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Sidebar Data & Form */}
            <div className="lg:col-span-1 space-y-8">
              {/* Reservation Info */}
              <div className="bg-blue-50 dark:bg-blue-900/10 rounded-2xl p-6 border border-blue-100 dark:border-blue-900/30">
                <h4 className="text-sm font-bold text-blue-800 dark:text-blue-300 mb-4 uppercase tracking-wider">
                  {t('reservations.modal.resInfoTitle') || 'Reservation Info'}
                </h4>
                <div className="text-sm text-blue-900 dark:text-blue-100 space-y-3 font-medium">
                  <div className="flex justify-between items-center pb-2 border-b border-blue-200/50 dark:border-blue-800/50">
                    <span className="text-blue-600 dark:text-blue-400">{t('reservations.modal.resInfoCustomer') || 'Customer'}:</span>
                    <span className="font-bold">{reservation.customer}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-blue-200/50 dark:border-blue-800/50">
                    <span className="text-blue-600 dark:text-blue-400">{t('reservations.modal.resInfoService') || 'Service'}:</span>
                    <span className="font-bold">{translateTripItem(reservation.tripItem)}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-blue-200/50 dark:border-blue-800/50">
                    <span className="text-blue-600 dark:text-blue-400">{t('reservations.modal.resInfoStatus') || 'Status'}:</span>
                    <span className="font-bold">{translateStatus(reservation.status)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-blue-600 dark:text-blue-400">{t('reservations.modal.resInfoSupplier') || 'Supplier'}:</span>
                    <span className="font-bold">{translateSupplier(reservation.supplier)}</span>
                  </div>
                </div>
              </div>

              {/* Add New Note Form */}
              <form onSubmit={handleSubmit} className="bg-gray-50 dark:bg-gray-800/50 p-6 rounded-2xl border border-gray-100 dark:border-gray-700/50">
                <h4 className="text-sm font-bold text-gray-900 dark:text-white mb-4 uppercase tracking-wider">
                  {t('reservations.modal.addNewComm') || 'Add New Note'}
                </h4>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    {t('reservations.modal.commType') || 'Communication Type'}
                  </label>
                  <div className="flex flex-col gap-2">
                    <label className="flex items-center gap-2 bg-white dark:bg-gray-800 p-3 rounded-lg border border-gray-200 dark:border-gray-700 cursor-pointer hover:border-blue-500 transition-colors">
                      <input
                        type="radio"
                        value="internal"
                        checked={noteType === 'internal'}
                        onChange={(e) => setNoteType(e.target.value as 'internal' | 'interdepartmental')}
                        className="text-blue-600"
                      />
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('reservations.modal.internalNote')}</span>
                    </label>
                    <label className="flex items-center gap-2 bg-white dark:bg-gray-800 p-3 rounded-lg border border-gray-200 dark:border-gray-700 cursor-pointer hover:border-blue-500 transition-colors">
                      <input
                        type="radio"
                        value="interdepartmental"
                        checked={noteType === 'interdepartmental'}
                        onChange={(e) => setNoteType(e.target.value as 'internal' | 'interdepartmental')}
                        className="text-blue-600"
                      />
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('reservations.modal.messageToDept')}</span>
                    </label>
                  </div>
                </div>

                {noteType === 'interdepartmental' && (
                  <div className="mb-4">
                    <Select
                      label={t('reservations.modal.targetDept')}
                      value={targetDepartment}
                      onChange={(e) => setTargetDepartment(e.target.value)}
                    >
                      {departments.map(dept => (
                        <option key={dept} value={dept}>{translateDepartment(dept)}</option>
                      ))}
                    </Select>
                  </div>
                )}

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    {noteType === 'internal' 
                      ? t('reservations.modal.internalNote') 
                      : t('reservations.modal.messageToDeptLabel')?.replace('{department}', translateDepartment(targetDepartment))}
                  </label>
                  <textarea
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    rows={4}
                    className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 outline-none dark:text-white shadow-sm transition-all"
                    placeholder={noteType === 'internal' 
                      ? t('reservations.modal.internalNotePlaceholder') 
                      : t('reservations.modal.messageToDeptPlaceholder')?.replace('{department}', translateDepartment(targetDepartment))}
                    required
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isLoading || !newNote.trim()}
                  loading={isLoading}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {noteType === 'internal' ? (
                    <>
                      <Save className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                      {t('reservations.modal.saveNoteBtn') || 'Save Note'}
                    </>
                  ) : (
                    <>
                      <Send className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                      {t('reservations.modal.sendMessageBtn') || 'Send Message'}
                    </>
                  )}
                </Button>
              </form>
            </div>

            {/* Existing Notes Feed */}
            <div className="lg:col-span-2">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                  {t('reservations.modal.commHistory') || 'Communication History'}
                </h3>
                <span className="px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-xs font-bold rounded-full">
                  {mockExistingNotes.length} Items
                </span>
              </div>
              
              <div className="space-y-4 max-h-[700px] overflow-y-auto pr-2 custom-scrollbar">
                {mockExistingNotes.map((note) => (
                  <div key={note.id} className="p-5 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full overflow-hidden shadow-sm flex-shrink-0 border border-gray-200 dark:border-gray-700">
                          <img src={translateAgent(note.author).toLowerCase().includes('fatma') || translateAgent(note.author).toLowerCase().includes('nour') ? '/avatar-female.png' : '/avatar-male.png'} alt="Avatar" className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-gray-900 dark:text-white">
                            {t('reservations.modal.byAuthor')?.replace('{author}', translateAgent(note.author)).replace('{department}', translateDepartment(note.department))}
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-400 bidi-isolate">{formatDate(note.timestamp)}</p>
                        </div>
                      </div>
                      <span className={`inline-flex px-3 py-1 text-[10px] font-bold rounded-full border uppercase tracking-wider ${getNoteTypeColor(note.type)}`}>
                        {note.type === 'internal' ? t('reservations.modal.internal') : 
                         note.type === 'interdepartmental' ? t('reservations.modal.toRecipient')?.replace('{recipient}', translateDepartment(note.recipient || '')) : 
                         t('reservations.modal.supplierUpdate')}
                      </span>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-900/50 p-4 rounded-xl border border-gray-100 dark:border-gray-800">
                      <p className="text-base text-gray-700 dark:text-gray-300 leading-relaxed">
                        {translateNoteContent(note.content, note.id)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};
