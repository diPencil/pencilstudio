import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, ShieldCheck, Info } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { Card, CardContent } from '../ui/Card';
import { useToastContext } from '../../contexts/ToastContext';
import { useLocale } from '../../localization/useLocale';

const supplierTypes = [
    'Hotel', 'Airline', 'Tour Operator', 'Activity Provider', 'Car Rental',
    'Transportation', 'Restaurant', 'Event Organizer', 'Cruise Line', 'Other'
];

export const AddSupplierPage: React.FC = () => {
    const toast = useToastContext();
    const navigate = useNavigate();
    const { isRTL } = useLocale();
    const [formData, setFormData] = useState({
        name: '',
        type: 'Hotel',
        email: '',
        phone: '',
        location: '',
        taxId: '',
        contractTerms: ''
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(false);

    const validateForm = () => {
        const newErrors: Record<string, string> = {};
        if (!formData.name.trim()) newErrors.name = 'Supplier name is required';
        if (!formData.email.trim()) newErrors.email = 'Email is required';
        if (!formData.location.trim()) newErrors.location = 'Location is required';
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!validateForm()) return;

        setIsLoading(true);
        setTimeout(() => {
            toast.success('Supplier Added', 'New partner registration completed.');
            setIsLoading(false);
            navigate('/reservations/tracker');
        }, 800);
    };

    const handleInputChange = (field: string, value: string) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        if (errors[field]) setErrors(prev => ({ ...prev, [field]: '' }));
    };

    return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center gap-4">
                        <Button variant="ghost" size="sm" onClick={() => navigate('/reservations/tracker')} className="p-2 text-blue-100 hover:text-white hover:bg-white/10">
                            <ArrowLeft size={20} className={isRTL ? 'rtl-flip' : ''} />
                        </Button>
                        <div>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">New Supplier Registration</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">Onboard a new travel partner or service provider</p>
                        </div>
                    </div>
                </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <Card className="card-premium">
                        <CardContent className="p-6">
                            <form onSubmit={handleSubmit} className="space-y-8">
                                <div>
                                    <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-6 border-b border-gray-100 dark:border-gray-800 pb-2">Business Identity</h3>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <Input
                                            label="Legal Entity Name"
                                            value={formData.name}
                                            onChange={(e) => handleInputChange('name', e.target.value)}
                                            error={errors.name}
                                            placeholder="Company Name"
                                        />
                                        <Select
                                            label="Supplier Category"
                                            value={formData.type}
                                            onChange={(e) => handleInputChange('type', e.target.value)}
                                        >
                                            {supplierTypes.map(type => <option key={type} value={type}>{type}</option>)}
                                        </Select>
                                        <Input
                                            label="Headquarters Location"
                                            value={formData.location}
                                            onChange={(e) => handleInputChange('location', e.target.value)}
                                            error={errors.location}
                                            placeholder="City, Country"
                                        />
                                        <Input
                                            label="Tax / VAT ID"
                                            value={formData.taxId}
                                            onChange={(e) => handleInputChange('taxId', e.target.value)}
                                            placeholder="TRN-..."
                                        />
                                    </div>
                                </div>

                                <div>
                                    <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-6 border-b border-gray-100 dark:border-gray-800 pb-2">Operational Contact</h3>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <Input
                                            label="Booking Email"
                                            type="email"
                                            value={formData.email}
                                            onChange={(e) => handleInputChange('email', e.target.value)}
                                            error={errors.email}
                                            placeholder="reservations@company.com"
                                        />
                                        <Input
                                            label="Emergency Phone"
                                            value={formData.phone}
                                            onChange={(e) => handleInputChange('phone', e.target.value)}
                                            placeholder="+..."
                                        />
                                    </div>
                                </div>

                                <div>
                                    <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-6 border-b border-gray-100 dark:border-gray-800 pb-2">Contract Details</h3>
                                    <textarea
                                        value={formData.contractTerms}
                                        onChange={(e) => handleInputChange('contractTerms', e.target.value)}
                                        rows={4}
                                        className="w-full px-3 py-2 border border-gray-200 dark:border-gray-700 rounded-lg bg-transparent text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                        placeholder="Commissions, payment terms, cancellation policy..."
                                    />
                                </div>

                                <div className="pt-6 border-t border-gray-100 dark:border-gray-800 flex justify-end gap-4">
                                    <Button type="button" variant="ghost" onClick={() => navigate('/reservations/tracker')} disabled={isLoading}>Cancel</Button>
                                    <Button type="submit" loading={isLoading}>
                                        <Save className="h-4 w-4" />
                                        Register Partner
                                    </Button>
                                </div>
                            </form>
                        </CardContent>
                    </Card>
                </div>

                <div className="space-y-6">
                    <Card className="card-premium">
                        <CardContent className="p-6 flex items-start gap-3">
                            <ShieldCheck className="h-5 w-5 text-emerald-500 mt-1" />
                            <div>
                                <h4 className="text-sm font-bold text-gray-900 dark:text-white">KYC Verification</h4>
                                <p className="text-xs text-gray-500 mt-1">
                                    All new suppliers must undergo a verification process. Financial settlements will be enabled after document review.
                                </p>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-blue-50 dark:bg-blue-900/10 border-blue-100 dark:border-blue-900/20">
                        <CardContent className="p-4 flex items-start gap-3">
                            <Info className="h-5 w-5 text-blue-500 mt-0.5" />
                            <div>
                                <h4 className="text-xs font-bold text-blue-900 dark:text-blue-300">Partner Portal</h4>
                                <p className="text-[10px] text-blue-800/70 dark:text-blue-400/70 mt-1">
                                    Once added, the supplier can be invited to the Partner Portal to manage their own inventory and responses directly.
                                </p>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
            </div>
        </div>
    );
};
