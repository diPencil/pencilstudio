import React, { useState } from 'react';
import { X, Save, MessageSquare, Send } from 'lucide-react';
import { Button } from '../ui/Button';
import { Select } from '../ui/Select';
import { formatDate } from '../../utils/format';
import { useLocale } from '../../localization/useLocale';
import { Reservation } from './ReservationsPage';

interface NotesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (note: string) => Promise<void>;
  reservation: Reservation;
}

export interface ReservationNote {
  id: number;
  content: string;
  author: string;
  department: string;
  timestamp: string;
  type: string;
  recipient: string | null;
}

const mockExistingNotes: ReservationNote[] = [
  {
    id: 1,
    content: 'Customer confirmed Nile view room preference. Contacted supplier for availability.',
    author: 'Super Admin',
    department: 'Reservation',
    timestamp: '2025-01-15T10:30:00Z',
    type: 'internal',
    recipient: null
  },
  {
    id: 2,
    content: 'Payment request sent to Finance team. Awaiting deposit confirmation.',
    author: 'Super Admin',
    department: 'Reservation',
    timestamp: '2025-01-14T16:45:00Z',
    type: 'interdepartmental',
    recipient: 'Finance'
  },
  {
    id: 3,
    content: 'Supplier response received. Room available but rate increased by $20/night.',
    author: 'Super Admin',
    department: 'Reservation',
    timestamp: '2025-01-13T09:15:00Z',
    type: 'supplier_update',
    recipient: null
  }
];

const departments = ['Sales', 'Finance', 'Operations', 'Customer Service'];

export const NotesModal: React.FC<NotesModalProps> = ({ isOpen, onClose, onSave, reservation }) => {
  const { t, dir, isRTL } = useLocale();
  const [newNote, setNewNote] = useState('');
  const [noteType, setNoteType] = useState<'internal' | 'interdepartmental'>('internal');
  const [targetDepartment, setTargetDepartment] = useState('Sales');
  const [isLoading, setIsLoading] = useState(false);

  const translateDepartment = (dept: string) => {
    switch (dept) {
      case 'Sales': return t('nav.sales') || 'Sales';
      case 'Finance': return t('common.finance') || 'Finance';
      case 'Operations': return t('nav.operations') || 'Operations';
      case 'Customer Service': return isRTL ? 'خدمة العملاء' : 'Customer Service';
      default: return dept;
    }
  };

  const translateTripItem = (item: string) => {
    switch (item) {
      case 'Hotel: Steigenberger Luxor': return t('reservations.tripType.hotelSteigenberger');
      case 'Hotel: Hilton Aswan Resort': return t('reservations.tripType.hotelHilton');
      case 'Flight: CAI-LXR Economy': return t('reservations.tripType.flightCaiLxr');
      case 'Tour: Valley of Kings': return t('reservations.tripType.tourValley');
      case 'Activity: Nile Felucca Ride': return t('reservations.tripType.activityNile');
      case 'Package: Nile Cruise 4 Days': return t('reservations.tripType.packageNile');
      case 'Transport: Airport Transfer': return t('reservations.tripType.transportAirport');
      case 'Cruise: Red Sea Diving': return t('reservations.tripType.cruiseRedSea');
      default: return item;
    }
  };

  const translateStatus = (status: string) => {
    switch (status) {
      case 'New': return t('reservations.status.new');
      case 'Pending': return t('reservations.status.pending');
      case 'Confirmed': return t('reservations.status.confirmed');
      case 'Awaiting Supplier': return t('reservations.status.awaitingSupplier');
      case 'Reserved': return t('reservations.status.reserved');
      case 'Cancelled': return t('reservations.status.cancelled');
      default: return status;
    }
  };

  const translateSupplier = (supplier: string) => {
    switch (supplier) {
      case 'Steigenberger Hotels': return t('reservations.supplier.steigerberger');
      case 'Hilton Hotels': return t('reservations.supplier.hilton');
      case 'EgyptAir': return t('reservations.supplier.egyptair');
      case 'Cairo Tours': return t('reservations.supplier.cairotours');
      case 'Nile Cruise Co': return t('reservations.supplier.nilecruise');
      case 'Local Operators': return t('reservations.supplier.local');
      default: return supplier;
    }
  };

  const translateAgent = (agent: string) => {
    switch (agent) {
      case 'Super Admin': return t('reservations.agent.superadmin');
      case 'Mahmoud Khalil': return t('reservations.agent.mahmoud');
      case 'Layla Ramadan': return t('reservations.agent.layla');
      case 'Sami Youssef': return t('reservations.agent.sami');
      case 'Mona Zaki': return t('reservations.agent.mona');
      default: return agent;
    }
  };

  const translateNoteContent = (noteContent: string, noteId: number) => {
    switch (noteId) {
      case 1: return t('reservations.notes.item1');
      case 2: return t('reservations.notes.item2');
      case 3: return t('reservations.notes.item3');
      default: return noteContent;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newNote.trim()) {
      return;
    }

    setIsLoading(true);
    try {
      await onSave(newNote);
      setNewNote('');
      onClose();
    } catch (error) {
      console.error('Error saving note:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getNoteTypeColor = (type: string) => {
    switch (type) {
      case 'internal': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      case 'interdepartmental': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300';
      case 'supplier_update': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  if (!isOpen || !reservation) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" dir={dir}>
      <div className="flex min-h-screen items-center justify-center p-4">
        <div className="fixed inset-0 bg-black bg-opacity-50" onClick={onClose} />
        <div className="relative w-full max-w-3xl bg-white dark:bg-gray-800 rounded-lg shadow-xl max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center gap-3">
              <MessageSquare className="h-6 w-6 text-green-500" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                {t('reservations.modal.notesTitle').replace('{id}', reservation.id)}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            >
              <X size={24} />
            </button>
          </div>

          <div className="p-6">
            {/* Reservation Info */}
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 mb-6">
              <h4 className="text-sm font-medium text-blue-800 dark:text-blue-300 mb-2">
                {t('reservations.modal.resInfoTitle')}
              </h4>
              <div className="text-sm text-blue-700 dark:text-blue-400 space-y-1">
                <p><strong>{t('reservations.modal.resInfoCustomer')}:</strong> <span className="bidi-isolate">{reservation.customer}</span></p>
                <p><strong>{t('reservations.modal.resInfoService')}:</strong> {translateTripItem(reservation.tripItem)}</p>
                <p><strong>{t('reservations.modal.resInfoStatus')}:</strong> {translateStatus(reservation.status)}</p>
                <p><strong>{t('reservations.modal.resInfoSupplier')}:</strong> {translateSupplier(reservation.supplier)}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Existing Notes */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  {t('reservations.modal.commHistory')}
                </h3>
                <div className="space-y-4 max-h-80 overflow-y-auto">
                  {mockExistingNotes.map((note) => (
                    <div key={note.id} className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getNoteTypeColor(note.type)}`}>
                            {note.type === 'internal' ? t('reservations.modal.internal') : 
                             note.type === 'interdepartmental' ? t('reservations.modal.toRecipient').replace('{recipient}', translateDepartment(note.recipient || '')) : 
                             t('reservations.modal.supplierUpdate')}
                          </span>
                        </div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">
                          <span className="bidi-isolate">{formatDate(note.timestamp)}</span>
                        </div>
                      </div>
                      <p className="text-gray-700 dark:text-gray-300 mb-2">{translateNoteContent(note.content, note.id)}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {t('reservations.modal.byAuthor').replace('{author}', translateAgent(note.author)).replace('{department}', translateDepartment(note.department))}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Add New Note */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  {t('reservations.modal.addNewComm')}
                </h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      {t('reservations.modal.commType')}
                    </label>
                    <div className="space-y-2">
                      <label className="flex items-center">
                        <input
                          type="radio"
                          value="internal"
                          checked={noteType === 'internal'}
                          onChange={(e) => setNoteType(e.target.value as 'internal' | 'interdepartmental')}
                          className="mr-2 rtl:mr-0 rtl:ml-2"
                        />
                        <span className="text-sm text-gray-700 dark:text-gray-300">{t('reservations.modal.internalNote')}</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          value="interdepartmental"
                          checked={noteType === 'interdepartmental'}
                          onChange={(e) => setNoteType(e.target.value as 'internal' | 'interdepartmental')}
                          className="mr-2 rtl:mr-0 rtl:ml-2"
                        />
                        <span className="text-sm text-gray-700 dark:text-gray-300">{t('reservations.modal.messageToDept')}</span>
                      </label>
                    </div>
                  </div>

                  {noteType === 'interdepartmental' && (
                    <Select
                      label={t('reservations.modal.targetDept')}
                      value={targetDepartment}
                      onChange={(e) => setTargetDepartment(e.target.value)}
                    >
                      {departments.map(dept => (
                        <option key={dept} value={dept}>{translateDepartment(dept)}</option>
                      ))}
                    </Select>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      {noteType === 'internal' 
                        ? t('reservations.modal.internalNote') 
                        : t('reservations.modal.messageToDeptLabel').replace('{department}', translateDepartment(targetDepartment))}
                    </label>
                    <textarea
                      value={newNote}
                      onChange={(e) => setNewNote(e.target.value)}
                      rows={6}
                      className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder={noteType === 'internal' 
                        ? t('reservations.modal.internalNotePlaceholder') 
                        : t('reservations.modal.messageToDeptPlaceholder').replace('{department}', translateDepartment(targetDepartment))}
                      required
                    />
                  </div>

                  <div className="flex justify-end gap-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={onClose}
                      disabled={isLoading}
                    >
                      {t('reservations.modal.cancel')}
                    </Button>
                    <Button
                      type="submit"
                      disabled={isLoading || !newNote.trim()}
                      loading={isLoading}
                    >
                      {noteType === 'internal' ? (
                        <>
                          <Save className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                          {t('reservations.modal.saveNoteBtn')}
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                          {t('reservations.modal.sendMessageBtn')}
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};