import React, { useState } from 'react';
import { Save, ArrowLeft, Info } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { Card, CardContent } from '../ui/Card';
import { useToastContext } from '../../contexts/ToastContext';
import { useNavigate } from 'react-router-dom';
import { useLocale } from '../../localization/useLocale';

const tripTypes = [
    'Hotel: Steigenberger Luxor',
    'Hotel: Hilton Aswan Resort',
    'Flight: CAI-LXR Economy',
    'Tour: Valley of Kings',
    'Activity: Nile Felucca Ride',
    'Package: Nile Cruise 4 Days',
    'Transport: Airport Transfer',
    'Cruise: Red Sea Diving'
];

const destinations = ['Luxor', 'Aswan', 'Cairo', 'Hurghada', 'Sharm El Sheikh', 'Alexandria'];
const roomTypes = ['Standard', 'Deluxe', 'Superior', 'Suite', 'Family Room', 'Connecting Rooms'];
const mealPlans = ['Room Only', 'Breakfast', 'Half Board', 'Full Board', 'All Inclusive'];
const nationalities = ['Egyptian', 'American', 'British', 'German', 'French', 'Italian', 'Spanish', 'Other'];
const suppliers = ['Steigenberger Hotels', 'Hilton Hotels', 'EgyptAir', 'Cairo Tours', 'Nile Cruise Co', 'Local Operators'];
const agents = ['Super Admin', 'Mahmoud Khalil', 'Layla Ramadan', 'Sami Youssef', 'Mona Zaki'];

export const NewReservationPage: React.FC = () => {
    const { t, isRTL } = useLocale();
    const toast = useToastContext();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        customer: '',
        customerEmail: '',
        customerPhone: '',
        tripItem: 'Hotel: Steigenberger Luxor',
        destination: 'Luxor',
        checkIn: '',
        checkOut: '',
        adults: '2',
        children: '0',
        childAges: '',
        rooms: '1',
        roomType: 'Standard',
        mealPlan: 'Half Board',
        nationality: 'Egyptian',
        supplier: 'Steigenberger Hotels',
        assignedAgent: 'Super Admin',
        specialRequests: ''
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(false);

    const getLocalizedNationality = (nat: string) => {
        switch (nat) {
            case 'Egyptian': return t('reservations.nationality.egyptian');
            case 'American': return t('reservations.nationality.american');
            case 'British': return t('reservations.nationality.british');
            case 'German': return t('reservations.nationality.german');
            case 'French': return t('reservations.nationality.french');
            case 'Italian': return t('reservations.nationality.italian');
            case 'Spanish': return t('reservations.nationality.spanish');
            case 'Other': return t('reservations.nationality.other');
            default: return nat;
        }
    };

    const getLocalizedTripType = (type: string) => {
        switch (type) {
            case 'Hotel: Steigenberger Luxor': return t('reservations.tripType.hotelSteigenberger');
            case 'Hotel: Hilton Aswan Resort': return t('reservations.tripType.hotelHilton');
            case 'Flight: CAI-LXR Economy': return t('reservations.tripType.flightCaiLxr');
            case 'Tour: Valley of Kings': return t('reservations.tripType.tourValley');
            case 'Activity: Nile Felucca Ride': return t('reservations.tripType.activityNile');
            case 'Package: Nile Cruise 4 Days': return t('reservations.tripType.packageNile');
            case 'Transport: Airport Transfer': return t('reservations.tripType.transportAirport');
            case 'Cruise: Red Sea Diving': return t('reservations.tripType.cruiseRedSea');
            default: return type;
        }
    };

    const getLocalizedDestination = (dest: string) => {
        switch (dest) {
            case 'Luxor': return t('reservations.destination.luxor');
            case 'Aswan': return t('reservations.destination.aswan');
            case 'Cairo': return t('reservations.destination.cairo');
            case 'Hurghada': return t('reservations.destination.hurghada');
            case 'Sharm El Sheikh': return t('reservations.destination.sharm');
            case 'Alexandria': return t('reservations.destination.alexandria');
            default: return dest;
        }
    };

    const getLocalizedRoomType = (type: string) => {
        switch (type) {
            case 'Standard': return t('reservations.roomType.standard');
            case 'Deluxe': return t('reservations.roomType.deluxe');
            case 'Superior': return t('reservations.roomType.superior');
            case 'Suite': return t('reservations.roomType.suite');
            case 'Family Room': return t('reservations.roomType.family');
            case 'Connecting Rooms': return t('reservations.roomType.connecting');
            default: return type;
        }
    };

    const getLocalizedMealPlan = (plan: string) => {
        switch (plan) {
            case 'Room Only': return t('reservations.mealPlan.roomOnly');
            case 'Breakfast': return t('reservations.mealPlan.breakfast');
            case 'Half Board': return t('reservations.mealPlan.halfBoard');
            case 'Full Board': return t('reservations.mealPlan.fullBoard');
            case 'All Inclusive': return t('reservations.mealPlan.allInclusive');
            default: return plan;
        }
    };

    const getLocalizedSupplier = (supplier: string) => {
        switch (supplier) {
            case 'Steigenberger Hotels': return t('reservations.supplier.steigerberger');
            case 'Hilton Hotels': return t('reservations.supplier.hilton');
            case 'EgyptAir': return t('reservations.supplier.egyptair');
            case 'Cairo Tours': return t('reservations.supplier.cairotours');
            case 'Nile Cruise Co': return t('reservations.supplier.nilecruise');
            case 'Local Operators': return t('reservations.supplier.local');
            default: return supplier;
        }
    };

    const getLocalizedAgent = (agent: string) => {
        switch (agent) {
            case 'Super Admin': return t('reservations.agent.superadmin');
            case 'Mahmoud Khalil': return t('reservations.agent.mahmoud');
            case 'Layla Ramadan': return t('reservations.agent.layla');
            case 'Sami Youssef': return t('reservations.agent.sami');
            case 'Mona Zaki': return t('reservations.agent.mona');
            default: return agent;
        }
    };

    const calculateNights = () => {
        if (formData.checkIn && formData.checkOut) {
            const checkInDate = new Date(formData.checkIn);
            const checkOutDate = new Date(formData.checkOut);
            const diffTime = checkOutDate.getTime() - checkInDate.getTime();
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            return diffDays > 0 ? diffDays : 0;
        }
        return 0;
    };

    const validateForm = () => {
        const newErrors: Record<string, string> = {};
        if (!formData.customer.trim()) newErrors.customer = t('reservations.validation.customer');
        if (!formData.customerEmail.trim()) newErrors.customerEmail = t('reservations.validation.email');
        if (!formData.checkIn) newErrors.checkIn = t('reservations.validation.checkIn');
        if (!formData.checkOut) newErrors.checkOut = t('reservations.validation.checkOut');
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!validateForm()) return;

        setIsLoading(true);
        setTimeout(() => {
            toast.success(t('reservations.toast.created'), t('reservations.toast.createdDesc'));
            setIsLoading(false);
            navigate('/reservations');
        }, 1000);
    };

    const handleInputChange = (field: string, value: string) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        if (errors[field]) setErrors(prev => ({ ...prev, [field]: '' }));
    };

    return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div className="flex items-center gap-4">
                        <Button variant="ghost" size="sm" onClick={() => navigate('/reservations')} className="p-2 text-blue-100 hover:text-white hover:bg-white/10">
                            <ArrowLeft size={20} className={isRTL ? 'transform rotate-180' : ''} />
                        </Button>
                        <div>
                            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">{t('reservations.new.title')}</h1>
                            <p className="mt-1 text-sm text-blue-100 opacity-90">{t('reservations.new.subtitle')}</p>
                        </div>
                    </div>
                </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <Card className="card-premium">
                        <CardContent className="p-6">
                            <form onSubmit={handleSubmit} className="space-y-8">
                                <div>
                                    <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-6 border-b border-gray-100 dark:border-gray-800 pb-2">{t('reservations.modal.customerSection')}</h3>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <Input
                                            label={t('reservations.form.customerName')}
                                            value={formData.customer}
                                            onChange={(e) => handleInputChange('customer', e.target.value)}
                                            error={errors.customer}
                                            placeholder="Full Name"
                                        />
                                        <Input
                                            label={t('reservations.form.email')}
                                            type="email"
                                            value={formData.customerEmail}
                                            onChange={(e) => handleInputChange('customerEmail', e.target.value)}
                                            error={errors.customerEmail}
                                            placeholder="email@example.com"
                                            className="bidi-isolate"
                                        />
                                        <Input
                                            label={t('reservations.form.phone')}
                                            value={formData.customerPhone}
                                            onChange={(e) => handleInputChange('customerPhone', e.target.value)}
                                            placeholder="+20..."
                                            className="bidi-isolate"
                                        />
                                        <Select
                                            label={t('reservations.form.nationality')}
                                            value={formData.nationality}
                                            onChange={(e) => handleInputChange('nationality', e.target.value)}
                                        >
                                            {nationalities.map(nat => <option key={nat} value={nat}>{getLocalizedNationality(nat)}</option>)}
                                        </Select>
                                    </div>
                                </div>

                                <div>
                                    <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-6 border-b border-gray-100 dark:border-gray-800 pb-2">{t('reservations.modal.tripSection')}</h3>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <Select
                                            label={t('reservations.form.tripItem')}
                                            value={formData.tripItem}
                                            onChange={(e) => handleInputChange('tripItem', e.target.value)}
                                        >
                                            {tripTypes.map(type => <option key={type} value={type}>{getLocalizedTripType(type)}</option>)}
                                        </Select>
                                        <Select
                                            label={t('reservations.form.destination')}
                                            value={formData.destination}
                                            onChange={(e) => handleInputChange('destination', e.target.value)}
                                        >
                                            {destinations.map(dest => <option key={dest} value={dest}>{getLocalizedDestination(dest)}</option>)}
                                        </Select>
                                        <Input
                                            label={t('reservations.form.checkIn')}
                                            type="date"
                                            value={formData.checkIn}
                                            onChange={(e) => handleInputChange('checkIn', e.target.value)}
                                            error={errors.checkIn}
                                            className="bidi-isolate"
                                        />
                                        <Input
                                            label={t('reservations.form.checkOut')}
                                            type="date"
                                            value={formData.checkOut}
                                            onChange={(e) => handleInputChange('checkOut', e.target.value)}
                                            error={errors.checkOut}
                                            className="bidi-isolate"
                                        />
                                    </div>
                                    {calculateNights() > 0 && (
                                        <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg flex items-center text-blue-600 dark:text-blue-400">
                                            <Info className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                                            <span className="text-xs font-bold">{t('reservations.table.nightsCount').replace('{count}', String(calculateNights()))}</span>
                                        </div>
                                    )}
                                </div>

                                <div>
                                    <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-6 border-b border-gray-100 dark:border-gray-800 pb-2">{t('reservations.form.specialRequests')}</h3>
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                        <Input label={t('reservations.form.adults')} type="number" value={formData.adults} onChange={(e) => handleInputChange('adults', e.target.value)} />
                                        <Input label={t('reservations.form.children')} type="number" value={formData.children} onChange={(e) => handleInputChange('children', e.target.value)} />
                                        <Input label={t('reservations.form.rooms')} type="number" value={formData.rooms} onChange={(e) => handleInputChange('rooms', e.target.value)} />
                                    </div>
                                    <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <Select label={t('reservations.form.roomType')} value={formData.roomType} onChange={(e) => handleInputChange('roomType', e.target.value)}>
                                            {roomTypes.map(type => <option key={type} value={type}>{getLocalizedRoomType(type)}</option>)}
                                        </Select>
                                        <Select label={t('reservations.form.mealPlan')} value={formData.mealPlan} onChange={(e) => handleInputChange('mealPlan', e.target.value)}>
                                            {mealPlans.map(plan => <option key={plan} value={plan}>{getLocalizedMealPlan(plan)}</option>)}
                                        </Select>
                                    </div>
                                    <div className="mt-6">
                                        <label className="label-xs mb-2 block">{t('reservations.form.specialRequests')}</label>
                                        <textarea
                                            value={formData.specialRequests}
                                            onChange={(e) => handleInputChange('specialRequests', e.target.value)}
                                            rows={3}
                                            className="w-full px-3 py-2 border border-gray-200 dark:border-gray-700 rounded-lg bg-transparent text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                            placeholder="Allergies, high floor, etc."
                                        />
                                    </div>
                                </div>

                                <div className="pt-6 border-t border-gray-100 dark:border-gray-800 flex justify-end gap-4">
                                    <Button type="button" variant="ghost" onClick={() => navigate('/reservations')} disabled={isLoading}>{t('sales.modal.cancel')}</Button>
                                    <Button type="submit" loading={isLoading}>
                                        <Save className={`h-4 w-4 ${isRTL ? 'ml-2' : 'mr-2'}`} />
                                        {t('reservations.form.save')}
                                    </Button>
                                </div>
                            </form>
                        </CardContent>
                    </Card>
                </div>

                <div className="space-y-6">
                    <Card className="card-premium">
                        <CardContent className="p-6">
                            <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-4">{t('reservations.filter.agent')}</h3>
                            <div className="space-y-4">
                                <Select label={t('reservations.form.supplier')} value={formData.supplier} onChange={(e) => handleInputChange('supplier', e.target.value)}>
                                    {suppliers.map(s => <option key={s} value={s}>{getLocalizedSupplier(s)}</option>)}
                                </Select>
                                <Select label={t('reservations.form.agent')} value={formData.assignedAgent} onChange={(e) => handleInputChange('assignedAgent', e.target.value)}>
                                    {agents.map(a => <option key={a} value={a}>{getLocalizedAgent(a)}</option>)}
                                </Select>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="bg-amber-50 dark:bg-amber-900/10 border-amber-100 dark:border-amber-900/20">
                        <CardContent className="p-4 flex items-start gap-3">
                            <Info className="h-5 w-5 text-amber-500 mt-0.5" />
                            <div>
                                <h4 className="text-xs font-bold text-amber-900 dark:text-amber-300">{t('reservations.activity.supplierContact')}</h4>
                                <p className="text-[10px] text-amber-800/70 dark:text-amber-400/70 mt-1">
                                    Selecting a supplier will notify their operations desk. Response tracking will start immediately after saving.
                                </p>
                            </div>
                        </CardContent>
                    </Card>
            </div>
            </div>
        </div>
        </div>
    );
};
