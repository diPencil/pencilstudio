import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Save, Bell, Mail, Smartphone, Globe, Shield, Activity } from 'lucide-react';
import { Button } from '../ui/Button';
import { useLocale } from '../../localization/useLocale';
import { cn } from '../../utils/cn';

export const NotificationSettingsPage: React.FC = () => {
    const { direction } = useLocale();
    // Mock settings state
    const [settings, setSettings] = useState({
        emailNotifications: true,
        pushNotifications: true,
        smsNotifications: false,
        soundEnabled: true,
        mentionAlerts: true,
        updateAlerts: false,
        marketingEmails: false,
        reservationUpdates: true,
        systemAlerts: true,
    });

    const handleToggle = (key: keyof typeof settings) => {
        setSettings(prev => ({ ...prev, [key]: !prev[key] }));
    };

    return (
        <div className="w-full pb-8" dir={direction}>
            <div className="mx-auto max-w-[1400px] space-y-6">
            <div className={cn("flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20 mb-8", direction === 'rtl' && "sm:flex-row-reverse")}>
                <div className={cn(direction === 'rtl' ? "text-right" : "text-left")}>
                    <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Notification Settings</h1>
                    <p className="mt-1 text-sm text-blue-100 opacity-90">Control how and when you want to be notified</p>
                </div>
                <div className="mt-4 sm:mt-0">
                    <Button className="bg-white text-blue-600 hover:bg-gray-100 font-semibold border-none">
                        <Save size={16} className={cn(direction === 'rtl' ? "ml-2" : "mr-2")} />
                        Save Preferences
                    </Button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    {/* Delivery Methods */}
                    <Card>
                        <CardHeader className="pb-4 border-b border-gray-100 dark:border-gray-800">
                            <CardTitle className="text-base font-bold flex items-center gap-2">
                                <Globe size={18} className="text-blue-500" />
                                Delivery Methods
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                            <div className="divide-y divide-gray-100 dark:divide-gray-800">
                                <div className="p-6 flex items-center justify-between">
                                    <div className="flex gap-4">
                                        <Mail className="text-gray-400 mt-1" size={24} />
                                        <div>
                                            <h4 className="font-semibold text-gray-900 dark:text-white">Email Notifications</h4>
                                            <p className="text-sm text-gray-500">Receive daily summaries and urgent alerts via email.</p>
                                        </div>
                                    </div>
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" className="sr-only peer" checked={settings.emailNotifications} onChange={() => handleToggle('emailNotifications')} />
                                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                                    </label>
                                </div>
                                <div className="p-6 flex items-center justify-between">
                                    <div className="flex gap-4">
                                        <Bell className="text-gray-400 mt-1" size={24} />
                                        <div>
                                            <h4 className="font-semibold text-gray-900 dark:text-white">Push Notifications</h4>
                                            <p className="text-sm text-gray-500">Get notified instantly on your browser or desktop.</p>
                                        </div>
                                    </div>
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" className="sr-only peer" checked={settings.pushNotifications} onChange={() => handleToggle('pushNotifications')} />
                                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                                    </label>
                                </div>
                                <div className="p-6 flex items-center justify-between">
                                    <div className="flex gap-4">
                                        <Smartphone className="text-gray-400 mt-1" size={24} />
                                        <div>
                                            <h4 className="font-semibold text-gray-900 dark:text-white">SMS Alerts</h4>
                                            <p className="text-sm text-gray-500">Only for high-priority security or system downtime alerts.</p>
                                        </div>
                                    </div>
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" className="sr-only peer" checked={settings.smsNotifications} onChange={() => handleToggle('smsNotifications')} />
                                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                                    </label>
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Alert Types */}
                    <Card>
                        <CardHeader className="pb-4 border-b border-gray-100 dark:border-gray-800">
                            <CardTitle className="text-base font-bold flex items-center gap-2">
                                <Activity size={18} className="text-green-500" />
                                Alert Preferences
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                            <div className="divide-y divide-gray-100 dark:divide-gray-800">
                                <div className="p-5 flex items-center justify-between">
                                    <div>
                                        <h4 className="font-semibold text-sm text-gray-900 dark:text-white">Reservation Updates</h4>
                                        <p className="text-xs text-gray-500 mt-1">When bookings are confirmed, modified or canceled.</p>
                                    </div>
                                    <input type="checkbox" checked={settings.reservationUpdates} onChange={() => handleToggle('reservationUpdates')} className="w-5 h-5 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600" />
                                </div>
                                <div className="p-5 flex items-center justify-between">
                                    <div>
                                        <h4 className="font-semibold text-sm text-gray-900 dark:text-white">Mentions & Comments</h4>
                                        <p className="text-xs text-gray-500 mt-1">When someone tags you in a task or leaves a comment.</p>
                                    </div>
                                    <input type="checkbox" checked={settings.mentionAlerts} onChange={() => handleToggle('mentionAlerts')} className="w-5 h-5 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600" />
                                </div>
                                <div className="p-5 flex items-center justify-between">
                                    <div>
                                        <h4 className="font-semibold text-sm text-gray-900 dark:text-white">System Alerts</h4>
                                        <p className="text-xs text-gray-500 mt-1">Important updates about the CRM system itself.</p>
                                    </div>
                                    <input type="checkbox" checked={settings.systemAlerts} onChange={() => handleToggle('systemAlerts')} className="w-5 h-5 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600" />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <div className="space-y-6">
                    <Card>
                        <CardHeader className="pb-3 border-b border-gray-100 dark:border-gray-800">
                            <CardTitle className="text-sm font-bold flex items-center gap-2">
                                <Shield size={16} className="text-indigo-500" />
                                Security Info
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-4 space-y-4">
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                                Your notification preferences are securely saved to your profile and will sync across your devices.
                            </p>
                            <Button variant="outline" className="w-full text-sm">
                                Manage Devices
                            </Button>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
        </div>
    );
};
