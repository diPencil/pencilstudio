import React, { useState } from 'react';
import { Card, CardContent, CardHeader } from '../ui/Card';
import { Bell, MessageSquare, AlertCircle, Check, Trash2, Filter, MoreVertical } from 'lucide-react';
import { Button } from '../ui/Button';

// Reuse mock data but extended
const allNotifications = [
    { id: 1, type: 'comment', user: 'Sally Travels', avatar: '/avatar-female.png', content: 'commented on the new Cairo & Luxor itinerary.', time: '2h', isUnread: true },
    { id: 2, type: 'mention', user: 'Mahmoud Guide', avatar: '/avatar-male.png', content: 'mentioned you in a task: "Airport Pickups".', time: '5h', isUnread: true },
    { id: 3, type: 'system', user: 'System', avatar: '/avatar-male.png', content: 'Payment received for Reservation #TR-2026.', time: '1d', isUnread: false },
    { id: 4, type: 'alert', user: 'Operations', avatar: '/avatar-male.png', content: 'Flight delayed for Sarah Williams Group.', time: '2d', isUnread: false },
    { id: 5, type: 'comment', user: 'Ahmed Hassan', avatar: '/avatar-male.png', content: 'liked your recent post about the Red Sea trip.', time: '3d', isUnread: false },
    { id: 6, type: 'system', user: 'System', avatar: '/avatar-male.png', content: 'Weekly performance report is ready to download.', time: '4d', isUnread: false },
];

export const NotificationsPage: React.FC = () => {
    const [notifications, setNotifications] = useState(allNotifications);
    const [filter, setFilter] = useState<'All' | 'Unread'>('All');

    const filteredNotifications = notifications.filter(n => filter === 'All' || n.isUnread);

    const markAllAsRead = () => {
        setNotifications(notifications.map(n => ({ ...n, isUnread: false })));
    };

    const deleteNotification = (id: number, e: React.MouseEvent) => {
        e.stopPropagation();
        setNotifications(notifications.filter(n => n.id !== id));
    };

  return (
        <div className="w-full pb-8">
            <div className="mx-auto max-w-[1400px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-[#2563EB] text-white p-6 sm:p-8 rounded-3xl shadow-lg shadow-blue-500/20">
                    <div>
                        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Notifications</h1>
                        <p className="mt-1 text-sm text-blue-100 opacity-90">Manage all your alerts, messages, and system updates</p>
                    </div>
                    <div className="flex gap-2 mt-4 sm:mt-0">
                        <Button onClick={markAllAsRead} className="bg-white text-blue-600 hover:bg-gray-50 rounded-xl font-bold border-0 shadow-sm">
                            <Check className="h-4 w-4 mr-2 rtl:mr-0 rtl:ml-2" />
                            Mark All as Read
                        </Button>
                    </div>
                </div>

            <Card>
                <CardHeader className="flex flex-row items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-4">
                    <div className="flex space-x-2">
                        <button
                            onClick={() => setFilter('All')}
                            className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-colors ${filter === 'All' ? 'bg-blue-50 text-blue-600 dark:bg-blue-500/10 dark:text-blue-400' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-white/5'}`}
                        >
                            All
                        </button>
                        <button
                            onClick={() => setFilter('Unread')}
                            className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-colors ${filter === 'Unread' ? 'bg-blue-50 text-blue-600 dark:bg-blue-500/10 dark:text-blue-400' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-white/5'}`}
                        >
                            Unread
                        </button>
                    </div>
                    <Button variant="ghost" size="sm" className="hidden sm:flex">
                        <Filter size={16} className="mr-2" />
                        Filter
                    </Button>
                </CardHeader>

                <CardContent className="p-0">
                    {filteredNotifications.length > 0 ? (
                        <div className="divide-y divide-gray-100 dark:divide-gray-800">
                            {filteredNotifications.map(notification => (
                                <div
                                    key={notification.id}
                                    className={`flex items-start p-6 transition-colors ${notification.isUnread ? 'bg-blue-50/30 dark:bg-blue-900/10' : 'hover:bg-gray-50 dark:hover:bg-white/5'}`}
                                >
                                    <div className="relative flex-shrink-0 mr-4">
                                        <img src={notification.avatar} alt={notification.user} className="w-12 h-12 rounded-full border border-gray-100 dark:border-gray-800" />
                                        {notification.type === 'comment' && <div className="absolute -bottom-1 -right-1 bg-green-500 w-6 h-6 rounded-full border-2 border-white dark:border-[#242526] flex items-center justify-center p-0.5"><MessageSquare size={10} className="text-white" /></div>}
                                        {notification.type === 'system' && <div className="absolute -bottom-1 -right-1 bg-blue-500 w-6 h-6 rounded-full border-2 border-white dark:border-[#242526] flex items-center justify-center p-0.5"><Bell size={10} className="text-white" /></div>}
                                        {notification.type === 'alert' && <div className="absolute -bottom-1 -right-1 bg-red-500 w-6 h-6 rounded-full border-2 border-white dark:border-[#242526] flex items-center justify-center p-0.5"><AlertCircle size={10} className="text-white" /></div>}
                                    </div>

                                    <div className="flex-1 min-w-0 pr-4">
                                        <p className="text-base text-gray-900 dark:text-gray-100">
                                            <span className="font-bold text-gray-900 dark:text-white mr-1.5">{notification.user}</span>
                                            <span className="text-gray-600 dark:text-gray-300">{notification.content}</span>
                                        </p>
                                        <p className={`text-sm font-medium mt-1.5 ${notification.isUnread ? 'text-blue-600 dark:text-blue-400' : 'text-gray-500'}`}>
                                            {notification.time}
                                        </p>
                                    </div>

                                    <div className="flex flex-col items-center gap-2">
                                        {notification.isUnread && (
                                            <div className="w-2.5 h-2.5 rounded-full bg-blue-600 dark:bg-blue-500 shadow-sm mb-2"></div>
                                        )}
                                        <button className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 p-1">
                                            <MoreVertical size={16} />
                                        </button>
                                        <button
                                            onClick={(e) => deleteNotification(notification.id, e)}
                                            className="text-gray-400 hover:text-red-500 p-1 transition-colors"
                                        >
                                            <Trash2 size={16} />
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="py-20 text-center text-gray-500 dark:text-gray-400 flex flex-col items-center">
                            <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mb-4">
                                <Bell size={32} className="text-gray-400" />
                            </div>
                            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1">You're all caught up!</h3>
                            <p className="text-sm">There are no {filter === 'Unread' ? 'new ' : ''}notifications for you to review.</p>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
        </div>
    );
};
