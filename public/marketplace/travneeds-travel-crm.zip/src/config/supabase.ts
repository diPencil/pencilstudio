import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'placeholder_key';

// Create a mock client when Supabase is not configured
const createMockClient = () => ({
  auth: {
    signInWithPassword: () => Promise.reject(new Error('Supabase not configured')),
    signOut: () => Promise.resolve({ error: null }),
    getSession: () => Promise.resolve({ data: { session: null } }),
    onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } })
  }
});

export const supabase = supabaseUrl === 'https://placeholder.supabase.co' 
  ? createMockClient() as any
  : createClient(supabaseUrl, supabaseKey);

export default supabase;