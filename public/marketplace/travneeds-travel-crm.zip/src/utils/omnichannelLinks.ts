import type {
  OmnichannelChannelType,
  OmnichannelConversationStatus,
  OmnichannelLinkedRecord,
  OmnichannelPriority,
  OmnichannelSlaStatus,
} from '../types/omnichannel';

export const getLinkedRecordUrl = (record: OmnichannelLinkedRecord): string => {
  if (record.href) {
    return record.href;
  }

  switch (record.type) {
    case 'lead':
      return '/leads';
    case 'customer':
      return '/customers';
    case 'reservation':
      return '/reservations';
    case 'sales_case':
      return `/sales/cases/${record.id}`;
    case 'quotation':
      return '/sales';
    case 'support_ticket':
      return '/help-center/tickets';
  }
};

export const getChannelLabel = (type: OmnichannelChannelType): string => {
  const labels: Record<OmnichannelChannelType, string> = {
    whatsapp: 'WhatsApp',
    whatsapp_business: 'WhatsApp Business/API',
    facebook_messenger: 'Facebook Messenger',
    instagram_dm: 'Instagram DMs',
    instagram_comment: 'Instagram Comments',
    website_chat: 'Website Live Chat',
    email: 'Email',
    sms: 'SMS',
    phone: 'Phone / Call Logs',
    future: 'Future Channel',
  };

  return labels[type];
};

export const getConversationStatusLabel = (status: OmnichannelConversationStatus): string => {
  const labels: Record<OmnichannelConversationStatus, string> = {
    open: 'Open',
    pending: 'Pending',
    waiting_agent: 'Waiting Agent',
    waiting_customer: 'Waiting Customer',
    closed: 'Closed',
    escalated: 'Escalated',
  };

  return labels[status];
};

export const getPriorityLabel = (priority: OmnichannelPriority): string => {
  const labels: Record<OmnichannelPriority, string> = {
    low: 'Low',
    normal: 'Normal',
    high: 'High',
    urgent: 'Urgent',
  };

  return labels[priority];
};

export const getSlaStatusLabel = (status: OmnichannelSlaStatus): string => {
  const labels: Record<OmnichannelSlaStatus, string> = {
    ok: 'OK',
    at_risk: 'At Risk',
    breached: 'Breached',
    paused: 'Paused',
    none: 'No SLA',
  };

  return labels[status];
};
