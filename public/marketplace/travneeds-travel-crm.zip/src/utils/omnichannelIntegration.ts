import type {
  OmnichannelAutomationRule,
  OmnichannelBroadcastCampaign,
  OmnichannelBusinessHours,
  OmnichannelChannel,
  OmnichannelChannelType,
  OmnichannelConversation,
  OmnichannelLabelDefinition,
  OmnichannelQuickReplyTemplate,
  OmnichannelRoutingRule,
  OmnichannelSlaPolicy,
  OmnichannelTeamMemberWorkload,
  OmnichannelTicketRecordMock,
} from '../types/omnichannel';
import { calculateChannelHealth, hasSlaBreach } from './omnichannelMetrics';

export interface OmnichannelDerivedQueueOverview {
  queueId: string;
  openCount: number;
  waitingCustomerCount: number;
  waitingAgentCount: number;
  breachedCount: number;
  assignedTeam: string;
}

export interface OmnichannelDerivedSlaRisk {
  conversationId: string;
  customerName: string;
  channelType: OmnichannelChannelType;
  riskLevel: 'low' | 'medium' | 'high';
  remainingMinutes: number;
  assignedStaffName?: string;
}

export interface OmnichannelDerivedChannelVolume {
  channelType: OmnichannelChannelType;
  conversations: number;
  replies: number;
  conversionCount: number;
}

export interface OmnichannelDerivedAgentSnapshot {
  staffId: string;
  staffName: string;
  teamName: string;
  onlineStatus: 'online' | 'offline' | 'busy';
  assignedConversations: number;
  activeTickets: number;
  averageResponseMinutes: number;
  satisfactionScore: number;
  workloadPercent: number;
}

export interface OmnichannelConversionSummary {
  leadConversions: number;
  customerLinks: number;
  ticketCreations: number;
  caseCreations: number;
}

export interface OmnichannelRoutingSimulationInput {
  channelType: OmnichannelChannelType;
  priority?: OmnichannelConversation['priority'];
  language?: 'en' | 'ar';
  tagIds?: string[];
  unassigned?: boolean;
  messageText?: string;
}

export interface OmnichannelRoutingSimulationResult {
  matchedRule: OmnichannelRoutingRule | null;
  matchedQueueId: string | null;
  reasons: string[];
}

export interface OmnichannelTemplateEligibility {
  allowed: boolean;
  reason?: 'approval' | 'channel';
}

export interface OmnichannelAssignmentEligibility {
  allowed: boolean;
  warning?: 'busy' | 'offline';
}

export interface OmnichannelBroadcastDraftValidation {
  valid: boolean;
  blockedReason?: 'required' | 'template_not_found' | 'template_not_approved' | 'channel_mismatch';
}

export interface OmnichannelSlaSimulationResult {
  policyName: string;
  firstResponseDueAt: string;
  resolutionDueAt: string;
  breachRisk: 'low' | 'medium' | 'high';
  explanation: string;
}

const activeConversationStatuses: OmnichannelConversation['status'][] = [
  'open',
  'pending',
  'waiting_agent',
  'waiting_customer',
  'escalated',
];

const addMinutes = (date: Date, minutes: number): Date => new Date(date.getTime() + minutes * 60 * 1000);

const formatTime = (date: Date): string =>
  `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;

const isHoliday = (date: Date, holidays: Array<{ date: string }>): boolean => {
  const isoDate = date.toISOString().slice(0, 10);
  return holidays.some((holiday) => holiday.date === isoDate);
};

const dayKeyMap: Record<number, OmnichannelBusinessHours['days'][number]> = {
  0: 'sun',
  1: 'mon',
  2: 'tue',
  3: 'wed',
  4: 'thu',
  5: 'fri',
  6: 'sat',
};

const buildDateAtTime = (date: Date, time: string): Date => {
  const [hours, minutes] = time.split(':').map(Number);
  const copy = new Date(date);
  copy.setHours(hours, minutes, 0, 0);
  return copy;
};

const moveIntoBusinessWindow = (
  source: Date,
  businessHours: OmnichannelBusinessHours | undefined,
  holidays: Array<{ date: string }>
): Date => {
  if (!businessHours) {
    return source;
  }

  const result = new Date(source);

  for (let attempts = 0; attempts < 14; attempts += 1) {
    const dayKey = dayKeyMap[result.getDay()];
    const start = buildDateAtTime(result, businessHours.startTime);
    const end = buildDateAtTime(result, businessHours.endTime);
    const inWorkingDay = businessHours.days.includes(dayKey);
    const blockedDay = !inWorkingDay || isHoliday(result, holidays);

    if (blockedDay) {
      result.setDate(result.getDate() + 1);
      result.setHours(0, 0, 0, 0);
      continue;
    }

    if (result < start) {
      return start;
    }

    if (result > end) {
      result.setDate(result.getDate() + 1);
      result.setHours(0, 0, 0, 0);
      continue;
    }

    return result;
  }

  return result;
};

export const deriveQueueOverview = (
  conversations: OmnichannelConversation[],
  queues: Array<{ id: string; department: string }>
): OmnichannelDerivedQueueOverview[] =>
  queues.map((queue) => {
    const queueConversations = conversations.filter((conversation) => conversation.queueId === queue.id);
    return {
      queueId: queue.id,
      openCount: queueConversations.filter((conversation) => activeConversationStatuses.includes(conversation.status)).length,
      waitingCustomerCount: queueConversations.filter((conversation) => conversation.status === 'waiting_customer').length,
      waitingAgentCount: queueConversations.filter((conversation) => conversation.status === 'waiting_agent').length,
      breachedCount: queueConversations.filter(hasSlaBreach).length,
      assignedTeam: queue.department,
    };
  });

export const deriveSlaRisks = (conversations: OmnichannelConversation[]): OmnichannelDerivedSlaRisk[] =>
  conversations
    .filter((conversation) => activeConversationStatuses.includes(conversation.status))
    .map((conversation) => {
      const remainingMinutes =
        conversation.sla.firstResponseRemainingMinutes !== 0
          ? conversation.sla.firstResponseRemainingMinutes
          : conversation.sla.resolutionRemainingMinutes;

      return {
        conversationId: conversation.id,
        customerName: conversation.customer.name,
        channelType: conversation.channelType,
        riskLevel: remainingMinutes <= 10 || hasSlaBreach(conversation) ? 'high' : remainingMinutes <= 30 ? 'medium' : 'low',
        remainingMinutes,
        assignedStaffName: conversation.assignedStaffName,
      };
    })
    .filter((risk) => risk.remainingMinutes <= 60 || risk.riskLevel === 'high')
    .sort((first, second) => first.remainingMinutes - second.remainingMinutes);

export const deriveChannelVolume = (conversations: OmnichannelConversation[]): OmnichannelDerivedChannelVolume[] => {
  const grouped = new Map<OmnichannelChannelType, OmnichannelDerivedChannelVolume>();

  conversations.forEach((conversation) => {
    const current = grouped.get(conversation.channelType) ?? {
      channelType: conversation.channelType,
      conversations: 0,
      replies: 0,
      conversionCount: 0,
    };

    current.conversations += 1;
    current.replies += conversation.unreadCount + 1;
    current.conversionCount += conversation.linkedRecords.filter((record) => ['lead', 'customer', 'support_ticket', 'sales_case'].includes(record.type)).length;
    grouped.set(conversation.channelType, current);
  });

  return [...grouped.values()].sort((first, second) => second.conversations - first.conversations);
};

export const deriveAgentSnapshots = (
  conversations: OmnichannelConversation[],
  members: OmnichannelTeamMemberWorkload[],
  tickets: OmnichannelTicketRecordMock[]
): OmnichannelDerivedAgentSnapshot[] =>
  members.map((member) => ({
    staffId: member.id,
    staffName: member.name,
    teamName: member.teamName,
    onlineStatus: member.onlineStatus,
    assignedConversations: conversations.filter((conversation) => conversation.assignedStaffId === member.id && activeConversationStatuses.includes(conversation.status)).length,
    activeTickets: tickets.filter((ticket) => ticket.ownerId === member.id && ticket.status !== 'Closed').length,
    averageResponseMinutes: member.averageResponseMinutes,
    satisfactionScore: member.satisfactionScore,
    workloadPercent: member.workloadPercent,
  }));

export const deriveConversionSummary = (conversations: OmnichannelConversation[]): OmnichannelConversionSummary => ({
  leadConversions: conversations.filter((conversation) => conversation.linkedRecords.some((record) => record.type === 'lead')).length,
  customerLinks: conversations.filter((conversation) => conversation.linkedRecords.some((record) => record.type === 'customer')).length,
  ticketCreations: conversations.filter((conversation) => conversation.linkedRecords.some((record) => record.type === 'support_ticket')).length,
  caseCreations: conversations.filter((conversation) => conversation.linkedRecords.some((record) => record.type === 'sales_case')).length,
});

export const deriveTagUsage = (
  labels: OmnichannelLabelDefinition[],
  conversations: OmnichannelConversation[]
): Array<OmnichannelLabelDefinition & { conversationCount: number }> =>
  labels.map((label) => ({
    ...label,
    conversationCount: conversations.filter((conversation) => conversation.tagIds.includes(label.id)).length,
  }));

export const resolveRoutingSimulation = (
  rules: OmnichannelRoutingRule[],
  input: OmnichannelRoutingSimulationInput
): OmnichannelRoutingSimulationResult => {
  const orderedRules = [...rules]
    .filter((rule) => rule.status === 'active')
    .sort((first, second) => first.priority - second.priority);

  for (const rule of orderedRules) {
    const reasons: string[] = [];

    const matches = rule.conditions.every((condition) => {
      switch (condition.field) {
        case 'channelType':
          return input.channelType === condition.value;
        case 'priority':
          return input.priority === condition.value;
        case 'language':
          return (input.language ?? 'en') === condition.value;
        case 'tagId':
          return (input.tagIds ?? []).includes(condition.value);
        case 'unassigned':
          return String(Boolean(input.unassigned)) === condition.value;
      }
    });

    const keywordMatch =
      !rule.keywords?.length ||
      rule.keywords.some((keyword) => (input.messageText ?? '').toLowerCase().includes(keyword.toLowerCase()));

    if (matches && keywordMatch) {
      reasons.push(rule.conditions.map((condition) => `${condition.field}:${condition.value}`).join(', '));
      if (rule.keywords?.length) {
        reasons.push(`keywords:${rule.keywords.join(', ')}`);
      }
      return {
        matchedRule: rule,
        matchedQueueId: rule.targetQueueId,
        reasons,
      };
    }
  }

  return {
    matchedRule: null,
    matchedQueueId: null,
    reasons: [],
  };
};

export const evaluateTemplateEligibility = (
  template: OmnichannelQuickReplyTemplate,
  channelType: OmnichannelChannelType
): OmnichannelTemplateEligibility => {
  if (template.approvalStatus !== 'approved') {
    return { allowed: false, reason: 'approval' };
  }

  if (!template.channelTypes.includes(channelType)) {
    return { allowed: false, reason: 'channel' };
  }

  return { allowed: true };
};

export const evaluateAssignmentEligibility = (
  member: OmnichannelTeamMemberWorkload | undefined
): OmnichannelAssignmentEligibility => {
  if (!member) {
    return { allowed: false, warning: 'offline' };
  }

  if (member.onlineStatus === 'offline') {
    return { allowed: false, warning: 'offline' };
  }

  if (member.onlineStatus === 'busy') {
    return { allowed: true, warning: 'busy' };
  }

  return { allowed: true };
};

export const validateBroadcastDraft = (
  draft: Pick<OmnichannelBroadcastCampaign, 'channelType' | 'templateId' | 'scheduledAt' | 'audienceSegmentId'>,
  templates: OmnichannelQuickReplyTemplate[]
): OmnichannelBroadcastDraftValidation => {
  if (!draft.audienceSegmentId || !draft.channelType || !draft.templateId || !draft.scheduledAt) {
    return { valid: false, blockedReason: 'required' };
  }

  const template = templates.find((item) => item.id === draft.templateId);
  if (!template) {
    return { valid: false, blockedReason: 'template_not_found' };
  }

  const eligibility = evaluateTemplateEligibility(template, draft.channelType);
  if (!eligibility.allowed) {
    return {
      valid: false,
      blockedReason: eligibility.reason === 'approval' ? 'template_not_approved' : 'channel_mismatch',
    };
  }

  return { valid: true };
};

export const simulateSlaPolicy = (
  policy: OmnichannelSlaPolicy,
  incomingAt: Date,
  businessHours: OmnichannelBusinessHours[],
  holidays: Array<{ date: string }>
): OmnichannelSlaSimulationResult => {
  const hours = businessHours.find((item) => item.id === policy.businessHoursId);
  const normalizedStart = moveIntoBusinessWindow(incomingAt, hours, holidays);
  const firstResponseDue = moveIntoBusinessWindow(addMinutes(normalizedStart, policy.firstResponseMinutes), hours, holidays);
  const resolutionDue = moveIntoBusinessWindow(addMinutes(normalizedStart, policy.resolutionMinutes), hours, holidays);
  const firstResponseMinutes = Math.max(0, Math.round((firstResponseDue.getTime() - normalizedStart.getTime()) / 60000));
  const breachRisk = firstResponseMinutes <= 15 ? 'high' : firstResponseMinutes <= 30 ? 'medium' : 'low';

  return {
    policyName: policy.name.en,
    firstResponseDueAt: `${normalizedStart.toISOString().slice(0, 10)} ${formatTime(firstResponseDue)}`,
    resolutionDueAt: `${normalizedStart.toISOString().slice(0, 10)} ${formatTime(resolutionDue)}`,
    breachRisk,
    explanation: hours
      ? `${hours.name.en}: ${hours.startTime}-${hours.endTime}`
      : 'No business-hours window was applied.',
  };
};

export const summarizeChannelHealth = (channels: OmnichannelChannel[]) => ({
  connected: channels.filter((channel) => channel.health.connectionStatus === 'connected').length,
  degraded: channels.filter((channel) => calculateChannelHealth(channel).status === 'degraded').length,
  critical: channels.filter((channel) => calculateChannelHealth(channel).status === 'critical').length,
});
