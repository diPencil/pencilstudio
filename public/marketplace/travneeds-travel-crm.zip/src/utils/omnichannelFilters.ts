import type { OmnichannelConversation, OmnichannelConversationFilters } from '../types/omnichannel';

const normalize = (value: string) => value.trim().toLowerCase();

const includesNormalized = (value: string | undefined, query: string) =>
  value ? normalize(value).includes(query) : false;

export const conversationMatchesSearch = (conversation: OmnichannelConversation, rawQuery: string): boolean => {
  const query = normalize(rawQuery);

  if (!query) {
    return true;
  }

  return [
    conversation.id,
    conversation.subject,
    conversation.customer.name,
    conversation.customer.phone,
    conversation.customer.email,
    conversation.lastMessagePreview,
    conversation.assignedStaffName,
    ...conversation.linkedRecords.map((record) => record.id),
    ...conversation.linkedRecords.map((record) => record.label),
  ].some((value) => includesNormalized(value, query));
};

export const filterOmnichannelConversations = (
  conversations: OmnichannelConversation[],
  filters: OmnichannelConversationFilters
): OmnichannelConversation[] =>
  conversations.filter((conversation) => {
    const matchesQuery = conversationMatchesSearch(conversation, filters.query ?? '');
    const matchesChannel = !filters.channelTypes?.length || filters.channelTypes.includes(conversation.channelType);
    const matchesStatus = !filters.statuses?.length || filters.statuses.includes(conversation.status);
    const matchesPriority = !filters.priorities?.length || filters.priorities.includes(conversation.priority);
    const matchesSla = !filters.slaStatuses?.length || filters.slaStatuses.includes(conversation.sla.status);
    const matchesUnread = !filters.unreadOnly || conversation.unreadCount > 0;
    const matchesTags = !filters.tagIds?.length || filters.tagIds.every((tagId) => conversation.tagIds.includes(tagId));
    const matchesAssignment =
      !filters.assignedState ||
      filters.assignedState === 'all' ||
      (filters.assignedState === 'assigned' && Boolean(conversation.assignedStaffId)) ||
      (filters.assignedState === 'unassigned' && !conversation.assignedStaffId);

    return matchesQuery && matchesChannel && matchesStatus && matchesPriority && matchesSla && matchesUnread && matchesTags && matchesAssignment;
  });
