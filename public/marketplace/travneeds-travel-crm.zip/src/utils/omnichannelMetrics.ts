import type {
  OmnichannelAnalyticsSummary,
  OmnichannelChannel,
  OmnichannelChannelHealth,
  OmnichannelConversation,
  OmnichannelConversationStatus,
  OmnichannelPriority,
  OmnichannelSlaStatus,
} from '../types/omnichannel';

export interface OmnichannelMetrics {
  total: number;
  open: number;
  pending: number;
  closed: number;
  escalated: number;
  unassigned: number;
  unread: number;
  slaBreaches: number;
  slaAtRisk: number;
  highPriority: number;
}

const countByStatus = (conversations: OmnichannelConversation[], status: OmnichannelConversationStatus) =>
  conversations.filter((conversation) => conversation.status === status).length;

const countByPriority = (conversations: OmnichannelConversation[], priority: OmnichannelPriority) =>
  conversations.filter((conversation) => conversation.priority === priority).length;

const countBySlaStatus = (conversations: OmnichannelConversation[], status: OmnichannelSlaStatus) =>
  conversations.filter((conversation) => conversation.sla.status === status).length;

export const calculateOmnichannelMetrics = (conversations: OmnichannelConversation[]): OmnichannelMetrics => ({
  total: conversations.length,
  open: countByStatus(conversations, 'open'),
  pending: countByStatus(conversations, 'pending'),
  closed: countByStatus(conversations, 'closed'),
  escalated: countByStatus(conversations, 'escalated'),
  unassigned: conversations.filter((conversation) => !conversation.assignedStaffId).length,
  unread: conversations.reduce((sum, conversation) => sum + conversation.unreadCount, 0),
  slaBreaches: countBySlaStatus(conversations, 'breached'),
  slaAtRisk: countBySlaStatus(conversations, 'at_risk'),
  highPriority: countByPriority(conversations, 'high') + countByPriority(conversations, 'urgent'),
});

export const calculateChannelHealth = (channel: OmnichannelChannel): OmnichannelChannelHealth => {
  if (channel.isFuture) {
    return channel.health;
  }

  if (channel.health.failedEventsToday >= 5 || channel.health.webhookStatus === 'failed') {
    return { ...channel.health, status: 'critical', healthScore: Math.min(channel.health.healthScore, 45) };
  }

  if (channel.health.connectionStatus === 'disconnected') {
    return { ...channel.health, status: 'offline', healthScore: Math.min(channel.health.healthScore, 25) };
  }

  if (channel.health.syncStatus === 'delayed' || channel.health.connectionStatus === 'sync_warning') {
    return { ...channel.health, status: 'degraded', healthScore: Math.min(channel.health.healthScore, 75) };
  }

  return { ...channel.health, status: 'healthy', healthScore: Math.max(channel.health.healthScore, 85) };
};

export const hasSlaBreach = (conversation: OmnichannelConversation): boolean =>
  conversation.sla.status === 'breached' ||
  conversation.sla.firstResponseRemainingMinutes < 0 ||
  conversation.sla.resolutionRemainingMinutes < 0;

export const summarizeAnalyticsFromConversations = (conversations: OmnichannelConversation[]): Pick<OmnichannelAnalyticsSummary, 'totalConversations' | 'openConversations' | 'pendingConversations' | 'closedConversations' | 'unassignedConversations' | 'unreadMessages' | 'slaBreaches'> => {
  const metrics = calculateOmnichannelMetrics(conversations);

  return {
    totalConversations: metrics.total,
    openConversations: metrics.open,
    pendingConversations: metrics.pending,
    closedConversations: metrics.closed,
    unassignedConversations: metrics.unassigned,
    unreadMessages: metrics.unread,
    slaBreaches: metrics.slaBreaches,
  };
};
