import type { OmnichannelMockStoreContextType } from '../components/omnichannel/store/OmnichannelMockStore';

export interface SelfTestResult {
  id: string;
  name: string;
  groupName: string;
  status: 'passed' | 'failed' | 'partial' | 'snapshot_only' | 'not_implemented';
  expected: string;
  actual: string;
  errorMessage?: string;
}

export type TestProgressCallback = (result: SelfTestResult) => void;

const delay = (ms: number = 60) => new Promise((resolve) => window.setTimeout(resolve, ms));

function getErrorMessage(error: unknown): string {
  if (error instanceof Error) {
    return error.message;
  }
  return String(error);
}

export async function runOmnichannelSelfTests(
  store: OmnichannelMockStoreContextType,
  onResult: TestProgressCallback
): Promise<void> {
  // Reset store to start clean
  store.resetAllMockStore();
  await delay(100);

  // ==========================================
  // Group 1: Inbox -> Dashboard / Analytics / Activity
  // ==========================================
  const group1 = 'Inbox -> Dashboard / Analytics / Activity';

  // Test 1.1: Send Message
  try {
    const targetConvId = 'conv-whatsapp-1';
    const originalMsgCount = store.messages.filter(m => m.conversationId === targetConvId).length;
    
    store.sendMessage(targetConvId, 'QA Diagnostic Message');
    await delay();

    const newMsgCount = store.messages.filter(m => m.conversationId === targetConvId).length;
    const lastMsg = store.messages[store.messages.length - 1];

    if (newMsgCount === originalMsgCount + 1 && lastMsg.body === 'QA Diagnostic Message') {
      onResult({
        id: 'inbox-send',
        name: 'Send Inbox Message',
        groupName: group1,
        status: 'passed',
        expected: `Message count: ${originalMsgCount + 1}`,
        actual: `Message count: ${newMsgCount}, Content: "${lastMsg.body}"`,
      });
    } else {
      throw new Error(`Expected message count ${originalMsgCount + 1}, got ${newMsgCount}`);
    }
  } catch (error: unknown) {
    onResult({
      id: 'inbox-send',
      name: 'Send Inbox Message',
      groupName: group1,
      status: 'failed',
      expected: 'New message added to store messages list',
      actual: 'Failed to update message list',
      errorMessage: getErrorMessage(error),
    });
  }

  // Test 1.2: Status Close/Reopen
  try {
    const targetConvId = 'conv-whatsapp-1';
    store.updateConversationStatus(targetConvId, 'closed');
    await delay();

    let conv = store.conversations.find(c => c.id === targetConvId);
    if (!conv || conv.status !== 'closed') {
      throw new Error('Status did not update to closed');
    }

    store.updateConversationStatus(targetConvId, 'open');
    await delay();

    conv = store.conversations.find(c => c.id === targetConvId);
    if (!conv || conv.status !== 'open') {
      throw new Error('Status did not revert to open');
    }

    onResult({
      id: 'inbox-status',
      name: 'Close and Reopen Conversation',
      groupName: group1,
      status: 'passed',
      expected: 'Status changes closed -> open',
      actual: `Status toggled, final: "${conv.status}"`,
    });
  } catch (error: unknown) {
    onResult({
      id: 'inbox-status',
      name: 'Close and Reopen Conversation',
      groupName: group1,
      status: 'failed',
      expected: 'Status close/reopen updates store conversation list',
      actual: 'Status mismatch',
      errorMessage: getErrorMessage(error),
    });
  }

  // Test 1.3: Priority Change
  try {
    const targetConvId = 'conv-whatsapp-1';
    store.updateConversationPriority(targetConvId, 'urgent');
    await delay();

    const conv = store.conversations.find(c => c.id === targetConvId);
    if (!conv || conv.priority !== 'urgent') {
      throw new Error('Priority did not update to urgent');
    }

    onResult({
      id: 'inbox-priority',
      name: 'Priority Modification',
      groupName: group1,
      status: 'passed',
      expected: 'Priority set to urgent',
      actual: `Priority updated: "${conv.priority}"`,
    });
  } catch (error: unknown) {
    onResult({
      id: 'inbox-priority',
      name: 'Priority Modification',
      groupName: group1,
      status: 'failed',
      expected: 'Priority change updates conversation list',
      actual: 'Failed to update priority',
      errorMessage: getErrorMessage(error),
    });
  }

  // Test 1.4: Tag Add/Remove
  try {
    const targetConvId = 'conv-whatsapp-1';
    const tagId = 'label-1'; // VIP Tag
    store.addConversationTag(targetConvId, tagId);
    await delay();

    let conv = store.conversations.find(c => c.id === targetConvId);
    if (!conv || !conv.tagIds.includes(tagId)) {
      throw new Error('VIP tag was not added');
    }

    store.removeConversationTag(targetConvId, tagId);
    await delay();

    conv = store.conversations.find(c => c.id === targetConvId);
    if (!conv || conv.tagIds.includes(tagId)) {
      throw new Error('VIP tag was not removed');
    }

    onResult({
      id: 'inbox-tag',
      name: 'Add and Remove Tags',
      groupName: group1,
      status: 'passed',
      expected: 'Tag is added then removed from tagIds array',
      actual: 'Tag successfully toggled on store conversation',
    });
  } catch (error: unknown) {
    onResult({
      id: 'inbox-tag',
      name: 'Add and Remove Tags',
      groupName: group1,
      status: 'failed',
      expected: 'Tags array updates correctly in store',
      actual: 'Tag manipulation error',
      errorMessage: getErrorMessage(error),
    });
  }

  // Test 1.5: Assignment / Transfer
  try {
    const targetConvId = 'conv-whatsapp-1';
    const staffId = 'USR-002'; // Alice Smith
    store.assignConversation(targetConvId, staffId);
    await delay();

    let conv = store.conversations.find(c => c.id === targetConvId);
    if (!conv || conv.assignedStaffId !== staffId) {
      throw new Error('Staff ID did not update');
    }

    onResult({
      id: 'inbox-assign',
      name: 'Staff Reassignment',
      groupName: group1,
      status: 'passed',
      expected: `Assigned staff set to "${staffId}"`,
      actual: `Assigned staff is: "${conv.assignedStaffId}"`,
    });
  } catch (error: unknown) {
    onResult({
      id: 'inbox-assign',
      name: 'Staff Reassignment',
      groupName: group1,
      status: 'failed',
      expected: 'Staff assignment propagates to store',
      actual: 'Failed to assign staff',
      errorMessage: getErrorMessage(error),
    });
  }

  // Test 1.6: Escalate
  try {
    const targetConvId = 'conv-whatsapp-1';
    store.updateConversationStatus(targetConvId, 'escalated');
    store.updateConversationPriority(targetConvId, 'urgent');
    await delay();

    const conv = store.conversations.find(c => c.id === targetConvId);
    if (!conv || conv.status !== 'escalated' || conv.priority !== 'urgent') {
      throw new Error('Escalation status or priority mismatch');
    }

    onResult({
      id: 'inbox-escalate',
      name: 'Conversation Escalation',
      groupName: group1,
      status: 'passed',
      expected: 'Status set to escalated and priority set to urgent',
      actual: `Status: "${conv.status}", Priority: "${conv.priority}"`,
    });
  } catch (error: unknown) {
    onResult({
      id: 'inbox-escalate',
      name: 'Conversation Escalation',
      groupName: group1,
      status: 'failed',
      expected: 'Escalation updates conversation list',
      actual: 'Escalation failure',
      errorMessage: getErrorMessage(error),
    });
  }

  // Test 1.7: Dashboard Integration
  try {
    // Check if store selectors update when values are mutated
    const unassignedCount = store.metrics.unassigned;
    onResult({
      id: 'dash-integration',
      name: 'Dashboard Derived Metrics Live Calculation',
      groupName: group1,
      status: 'passed',
      expected: 'Derived unassigned count resolves reactively',
      actual: `Current live derived unassigned: ${unassignedCount}`,
    });
  } catch (error: unknown) {
    onResult({
      id: 'dash-integration',
      name: 'Dashboard Derived Metrics Live Calculation',
      groupName: group1,
      status: 'failed',
      expected: 'Live selectors calculate metrics correctly',
      actual: 'Failed to read metrics',
      errorMessage: getErrorMessage(error),
    });
  }

  // ==========================================
  // Group 2: Conversion Flow
  // ==========================================
  const group2 = 'Record Conversions';

  // Test 2.1: Convert to Lead
  try {
    const targetConvId = 'conv-whatsapp-1';
    const prevCount = store.leadRecords.length;

    store.convertConversation(targetConvId, 'convert_lead', {
      name: 'QA Test Lead',
      phone: '+971500000000',
      email: 'qa@testlead.com',
      companyName: 'QA Enterprises',
    });
    await delay();

    const newCount = store.leadRecords.length;
    const conv = store.conversations.find(c => c.id === targetConvId);
    const hasLeadLink = conv?.linkedRecords.some(r => r.type === 'lead');

    if (newCount === prevCount + 1 && hasLeadLink) {
      onResult({
        id: 'conv-lead',
        name: 'Convert Conversation to Lead',
        groupName: group2,
        status: 'passed',
        expected: `Lead records: ${prevCount + 1}, Link type "lead" present`,
        actual: `Lead records: ${newCount}, Converted: ${hasLeadLink}`,
      });
    } else {
      throw new Error(`Records count: ${newCount}, Converted link check: ${hasLeadLink}`);
    }
  } catch (error: unknown) {
    onResult({
      id: 'conv-lead',
      name: 'Convert Conversation to Lead',
      groupName: group2,
      status: 'failed',
      expected: 'Lead record created and linked to conversation',
      actual: 'Conversion failed',
      errorMessage: getErrorMessage(error),
    });
  }

  // Test 2.2: Convert to Customer
  try {
    const targetConvId = 'conv-whatsapp-2';
    const prevCount = store.customerRecords.length;

    store.convertConversation(targetConvId, 'convert_customer', {
      name: 'QA Test Customer',
      phone: '+962790000000',
      email: 'qa@testcustomer.com',
    });
    await delay();

    const newCount = store.customerRecords.length;
    const conv = store.conversations.find(c => c.id === targetConvId);
    const hasCustLink = conv?.linkedRecords.some(r => r.type === 'customer');

    if (newCount === prevCount + 1 && hasCustLink) {
      onResult({
        id: 'conv-customer',
        name: 'Convert Conversation to Customer',
        groupName: group2,
        status: 'passed',
        expected: `Customer records: ${prevCount + 1}, Link type "customer" present`,
        actual: `Customer records: ${newCount}, Converted: ${hasCustLink}`,
      });
    } else {
      throw new Error(`Records count: ${newCount}, Converted link check: ${hasCustLink}`);
    }
  } catch (error: unknown) {
    onResult({
      id: 'conv-customer',
      name: 'Convert Conversation to Customer',
      groupName: group2,
      status: 'failed',
      expected: 'Customer record created and linked to conversation',
      actual: 'Conversion failed',
      errorMessage: getErrorMessage(error),
    });
  }

  // Test 2.3: Create Ticket
  try {
    const targetConvId = 'conv-whatsapp-1';
    const prevCount = store.ticketRecords.length;

    store.convertConversation(targetConvId, 'create_ticket', {
      name: 'QA Ticket Customer',
      subject: 'QA Ticket Issue',
      priority: 'high',
      category: 'support',
    });
    await delay();

    const newCount = store.ticketRecords.length;
    const conv = store.conversations.find(c => c.id === targetConvId);
    const hasTicketLink = conv?.linkedRecords.some(r => r.type === 'support_ticket');

    if (newCount === prevCount + 1 && hasTicketLink) {
      onResult({
        id: 'conv-ticket',
        name: 'Create Ticket',
        groupName: group2,
        status: 'passed',
        expected: `Ticket records: ${prevCount + 1}, Link type "support_ticket" present`,
        actual: `Ticket records: ${newCount}, Converted: ${hasTicketLink}`,
      });
    } else {
      throw new Error(`Records count: ${newCount}, Converted link check: ${hasTicketLink}`);
    }
  } catch (error: unknown) {
    onResult({
      id: 'conv-ticket',
      name: 'Create Ticket',
      groupName: group2,
      status: 'failed',
      expected: 'Ticket record created and linked to conversation',
      actual: 'Conversion failed',
      errorMessage: getErrorMessage(error),
    });
  }

  // Test 2.4: Create Case
  try {
    const targetConvId = 'conv-whatsapp-2';
    const prevCount = store.caseRecords.length;

    store.convertConversation(targetConvId, 'create_case', {
      name: 'QA Case Customer',
      subject: 'QA Booking inquiry',
      caseType: 'booking',
    });
    await delay();

    const newCount = store.caseRecords.length;
    const conv = store.conversations.find(c => c.id === targetConvId);
    const hasCaseLink = conv?.linkedRecords.some(r => r.type === 'sales_case');

    if (newCount === prevCount + 1 && hasCaseLink) {
      onResult({
        id: 'conv-case',
        name: 'Create Sales Case',
        groupName: group2,
        status: 'passed',
        expected: `Case records: ${prevCount + 1}, Link type "sales_case" present`,
        actual: `Case records: ${newCount}, Converted: ${hasCaseLink}`,
      });
    } else {
      throw new Error(`Records count: ${newCount}, Converted link check: ${hasCaseLink}`);
    }
  } catch (error: unknown) {
    onResult({
      id: 'conv-case',
      name: 'Create Sales Case',
      groupName: group2,
      status: 'failed',
      expected: 'Case record created and linked to conversation',
      actual: 'Conversion failed',
      errorMessage: getErrorMessage(error),
    });
  }

  // Test 2.5: Unlink and Restore
  try {
    const targetConvId = 'conv-whatsapp-1';
    let conv = store.conversations.find(c => c.id === targetConvId);
    if (!conv) {
      throw new Error('Conversation not found');
    }
    const targetRecord = conv.linkedRecords[0];
    if (!targetRecord) {
      throw new Error('No linked records to test unlinking');
    }

    store.unlinkRecord(targetConvId, targetRecord.id, targetRecord.type);
    await delay();

    conv = store.conversations.find(c => c.id === targetConvId);
    const stillLinked = conv?.linkedRecords.some(r => r.id === targetRecord.id && r.type === targetRecord.type);
    if (stillLinked) {
      throw new Error('Record unlinking failed');
    }

    store.restoreLinkedRecord(targetConvId, targetRecord.id, targetRecord.type);
    await delay();

    conv = store.conversations.find(c => c.id === targetConvId);
    const restoredLinked = conv?.linkedRecords.some(r => r.id === targetRecord.id && r.type === targetRecord.type);
    if (!restoredLinked) {
      throw new Error('Record restoring failed');
    }

    onResult({
      id: 'conv-unlink',
      name: 'Unlink and Restore Linked Record',
      groupName: group2,
      status: 'passed',
      expected: 'Record is removed from linkedRecords, then restored back',
      actual: 'Record successfully unlinked and restored in store state',
    });
  } catch (error: unknown) {
    onResult({
      id: 'conv-unlink',
      name: 'Unlink and Restore Linked Record',
      groupName: group2,
      status: 'failed',
      expected: 'Unlink/Restore actions update linkedRecords array',
      actual: 'Unlink/Restore failed',
      errorMessage: getErrorMessage(error),
    });
  }

  // ==========================================
  // Group 3: Channels -> Dashboard / Activity / Broadcasts
  // ==========================================
  const group3 = 'Channels -> Dashboard / Activity / Broadcasts';

  // Test 3.1: Pause and Resume Channel
  try {
    const targetChannelId = 'whatsapp';
    store.pauseChannel(targetChannelId);
    await delay();

    let channel = store.channels.find(ch => ch.id === targetChannelId);
    if (!channel || channel.health.connectionStatus !== 'suspended') {
      throw new Error(`Expected connectionStatus suspended, got ${channel?.health.connectionStatus}`);
    }

    store.resumeChannel(targetChannelId);
    await delay();

    channel = store.channels.find(ch => ch.id === targetChannelId);
    if (!channel || channel.health.connectionStatus !== 'connected') {
      throw new Error(`Expected connectionStatus connected, got ${channel?.health.connectionStatus}`);
    }

    onResult({
      id: 'channel-toggle',
      name: 'Pause and Resume Channel',
      groupName: group3,
      status: 'passed',
      expected: 'Connection status changes connected -> suspended -> connected',
      actual: `Status toggled successfully, final: "${channel.health.connectionStatus}"`,
    });
  } catch (error: unknown) {
    onResult({
      id: 'channel-toggle',
      name: 'Pause and Resume Channel',
      groupName: group3,
      status: 'failed',
      expected: 'Channel status toggles in shared store state',
      actual: 'Channel status mismatch',
      errorMessage: getErrorMessage(error),
    });
  }

  // Test 3.2: Configure Channel Settings
  try {
    const targetChannelId = 'whatsapp';
    const config = store.channelConfigurations.find(c => c.channelId === targetChannelId);
    if (!config) {
      throw new Error('Config snapshot not found');
    }

    const nextConfig = {
      ...config,
      webhookUrl: 'https://qa.travneeds.com/omni-webhook-updated',
    };

    store.saveChannelConfiguration(targetChannelId, nextConfig);
    await delay();

    const updated = store.channelConfigurations.find(c => c.channelId === targetChannelId);
    if (!updated || updated.webhookUrl !== 'https://qa.travneeds.com/omni-webhook-updated') {
      throw new Error('Config webhook did not update');
    }

    onResult({
      id: 'channel-config',
      name: 'Save Channel Configuration Settings',
      groupName: group3,
      status: 'passed',
      expected: 'Webhook URL updates to "https://qa.travneeds.com/omni-webhook-updated"',
      actual: `Webhook URL updated: "${updated.webhookUrl}"`,
    });
  } catch (error: unknown) {
    onResult({
      id: 'channel-config',
      name: 'Save Channel Configuration Settings',
      groupName: group3,
      status: 'failed',
      expected: 'Channel settings save updates settings collection',
      actual: 'Settings update failure',
      errorMessage: getErrorMessage(error),
    });
  }

  // ==========================================
  // Group 4: Routing -> Team / SLA / Activity
  // ==========================================
  const group4 = 'Routing -> Team / SLA / Activity';

  // Test 4.1: Add and Disable Routing Rule
  try {
    const prevCount = store.routingRules.length;
    const ruleDraft = {
      name: { en: 'QA Test Routing Rule', ar: 'QA Test Routing Rule' },
      status: 'active' as const,
      priority: prevCount + 1,
      conditions: [{ field: 'channelType' as const, operator: 'equals' as const, value: 'whatsapp' }],
      targetQueueId: 'queue-sales',
      fallbackQueueId: 'queue-support',
      language: 'en' as const,
    };

    store.addRoutingRule(ruleDraft);
    await delay();

    let newCount = store.routingRules.length;
    let rule = store.routingRules.find(r => r.name.en === 'QA Test Routing Rule');
    if (newCount !== prevCount + 1 || !rule) {
      throw new Error('Rule was not added');
    }

    store.enableRoutingRule(rule.id, false);
    await delay();

    rule = store.routingRules.find(r => r.name.en === 'QA Test Routing Rule');
    if (!rule || rule.status !== 'paused') {
      throw new Error(`Expected rule status paused, got ${rule?.status}`);
    }

    onResult({
      id: 'routing-rule',
      name: 'Add and Disable Routing Rule',
      groupName: group4,
      status: 'passed',
      expected: `Routing rules count: ${prevCount + 1}, added status: "paused" after disable`,
      actual: `Rules count: ${newCount}, Rule status: "${rule.status}"`,
    });
  } catch (error: unknown) {
    onResult({
      id: 'routing-rule',
      name: 'Add and Disable Routing Rule',
      groupName: group4,
      status: 'failed',
      expected: 'Routing rules addition and status toggle persist in store',
      actual: 'Routing rule failure',
      errorMessage: getErrorMessage(error),
    });
  }

  // ==========================================
  // Group 5: Automation -> Activity / Ticket / Assignment
  // ==========================================
  const group5 = 'Automation -> Activity / Ticket / Assignment';

  // Test 5.1: Create and Run Automation Rule
  try {
    const prevCount = store.automationRules.length;
    const ruleDraft = {
      name: { en: 'QA Automation Rule', ar: 'QA Automation Rule' },
      status: 'active' as const,
      trigger: 'message_received' as const,
      conditions: ['VIP Customer'],
      actions: [{ type: 'add_tag' as const, summary: 'VIP tag' }],
      ownerId: 'USR-001',
      ownerName: 'Super Admin',
      priority: prevCount + 1,
    };

    store.addAutomationRule(ruleDraft);
    await delay();

    let rule = store.automationRules.find(r => r.name.en === 'QA Automation Rule');
    if (!rule) {
      throw new Error('Automation rule was not added');
    }

    const prevActCount = store.automationActivities.length;
    store.runAutomationNow(rule.id);
    await delay();

    const newActCount = store.automationActivities.length;
    if (newActCount !== prevActCount + 1) {
      throw new Error('Automation rule execution activity was not logged');
    }

    onResult({
      id: 'automation-run',
      name: 'Create and Run Automation Rule',
      groupName: group5,
      status: 'passed',
      expected: `Automation rule created, Activities count: ${prevActCount + 1}`,
      actual: `Activities count: ${newActCount}`,
    });
  } catch (error: unknown) {
    onResult({
      id: 'automation-run',
      name: 'Create and Run Automation Rule',
      groupName: group5,
      status: 'failed',
      expected: 'Automation rules addition and program execution update state',
      actual: 'Automation failure',
      errorMessage: getErrorMessage(error),
    });
  }

  // ==========================================
  // Group 6: Templates -> Broadcasts
  // ==========================================
  const group6 = 'Templates -> Broadcasts';

  // Test 6.1: Add and Archive Reply Template
  try {
    const prevCount = store.templates.length;
    const templateDraft = {
      category: 'welcome' as const,
      channelTypes: ['whatsapp' as const],
      title: { en: 'QA Welcome Reply', ar: 'QA Welcome Reply' },
      body: { en: 'Welcome to QA test!', ar: 'QA Welcome Reply' },
      language: 'en',
      approvalStatus: 'draft' as const,
      variables: [],
    };

    store.addTemplate(templateDraft);
    await delay();

    let tpl = store.templates.find(t => t.title.en === 'QA Welcome Reply');
    if (!tpl) {
      throw new Error('Template was not added');
    }

    store.archiveTemplate(tpl.id, true);
    await delay();

    tpl = store.templates.find(t => t.title.en === 'QA Welcome Reply');
    if (!tpl || tpl.approvalStatus !== 'archived') {
      throw new Error(`Expected template status archived, got ${tpl?.approvalStatus}`);
    }

    onResult({
      id: 'template-archive',
      name: 'Add and Archive Template',
      groupName: group6,
      status: 'passed',
      expected: `Template created, Archived approvalStatus: "archived"`,
      actual: `Template status: "${tpl.approvalStatus}"`,
    });
  } catch (error: unknown) {
    onResult({
      id: 'template-archive',
      name: 'Add and Archive Template',
      groupName: group6,
      status: 'failed',
      expected: 'Templates addition and archiving update state',
      actual: 'Templates failure',
      errorMessage: getErrorMessage(error),
    });
  }

  // ==========================================
  // Group 7: Tags -> Inbox / Analytics
  // ==========================================
  const group7 = 'Tags -> Inbox / Analytics';

  // Test 7.1: Add Label and Delete Label In Use
  try {
    const labelDraft = {
      name: { en: 'QA Stale Label', ar: 'QA Stale Label' },
      colorClass: 'bg-red-50 text-red-700 border-red-100',
      type: 'tag' as const,
    };

    store.addLabel(labelDraft);
    await delay();

    let tag = store.labels.find(l => l.name.en === 'QA Stale Label');
    if (!tag) {
      throw new Error('Tag was not created');
    }

    // Link tag to conversation so it is in use
    const targetConvId = 'conv-whatsapp-1';
    store.addConversationTag(targetConvId, tag.id);
    await delay();

    // Verify tag deletion is blocked safely
    const deleteResult = store.deleteLabel(tag.id);
    await delay();

    if (deleteResult === true) {
      throw new Error('Label in use deletion was not blocked');
    }

    onResult({
      id: 'tag-delete-block',
      name: 'Tag Creation & Delete In-Use Protection',
      groupName: group7,
      status: 'passed',
      expected: 'Tag is created, and deleteLabel returns false because it is referenced in conversations',
      actual: `Created tag ID: "${tag.id}", Delete operation return code: false (blocked)`,
    });
  } catch (error: unknown) {
    onResult({
      id: 'tag-delete-block',
      name: 'Tag Creation & Delete In-Use Protection',
      groupName: group7,
      status: 'failed',
      expected: 'Tags in active use cannot be deleted from the store',
      actual: 'Tag validation mismatch',
      errorMessage: getErrorMessage(error),
    });
  }

  // ==========================================
  // Group 8: SLA -> Dashboard / Routing / Conversations
  // ==========================================
  const group8 = 'SLA -> Dashboard / Routing / Conversations';

  // Test 8.1: Create SLA Policy
  try {
    const prevCount = store.slaPolicies.length;
    const policyDraft = {
      name: { en: 'QA Custom SLA', ar: 'QA Custom SLA' },
      queueId: 'queue-sales',
      priority: 'high' as const,
      firstResponseMinutes: 5,
      resolutionMinutes: 60,
      businessHoursId: 'bh-sales-weekday',
      status: 'active' as const,
    };

    store.addSlaPolicy(policyDraft);
    await delay();

    const newCount = store.slaPolicies.length;
    const policy = store.slaPolicies.find(p => p.name.en === 'QA Custom SLA');

    if (newCount === prevCount + 1 && policy) {
      onResult({
        id: 'sla-policy',
        name: 'Create SLA Policy',
        groupName: group8,
        status: 'passed',
        expected: `SLA policies count: ${prevCount + 1}`,
        actual: `Policies count: ${newCount}`,
      });
    } else {
      throw new Error('SLA policy was not added');
    }
  } catch (error: unknown) {
    onResult({
      id: 'sla-policy',
      name: 'Create SLA Policy',
      groupName: group8,
      status: 'failed',
      expected: 'SLA policy creation updates SLA rules collection in store',
      actual: 'SLA policy failure',
      errorMessage: getErrorMessage(error),
    });
  }

  // ==========================================
  // Group 9: Team -> Inbox / Routing / Automation / Dashboard
  // ==========================================
  const group9 = 'Team -> Inbox / Routing / Automation / Dashboard';

  // Test 9.1: Staff onlineStatus Toggles & Workload Rebalancing
  try {
    const targetMemberId = 'staff-1';
    store.updateTeamMemberStatus(targetMemberId, 'offline');
    await delay();

    let member = store.teamMembers.find(m => m.id === targetMemberId);
    if (!member || member.onlineStatus !== 'offline') {
      throw new Error(`Expected onlineStatus offline, got ${member?.onlineStatus}`);
    }

    // Rebalance workloads
    store.rebalanceTeamWorkload('Sales');
    await delay();

    onResult({
      id: 'team-workload',
      name: 'Team Status and Workload Rebalance',
      groupName: group9,
      status: 'passed',
      expected: 'onlineStatus set offline, workloads balanced successfully',
      actual: 'Team status toggled and rebalanced successfully',
    });
  } catch (error: unknown) {
    onResult({
      id: 'team-workload',
      name: 'Team Status and Workload Rebalance',
      groupName: group9,
      status: 'failed',
      expected: 'Staff workload rebalance and status changes update state',
      actual: 'Team manipulation error',
      errorMessage: getErrorMessage(error),
    });
  }

  // ==========================================
  // Group 10: Activity Center
  // ==========================================
  const group10 = 'Activity Center';

  // Test 10.1: Activity Events Presence
  try {
    const count = store.activityLogs.length;
    if (count === 0) {
      throw new Error('No activity logs generated');
    }

    onResult({
      id: 'activity-timeline',
      name: 'Activity Center Timeline Events Stream',
      groupName: group10,
      status: 'passed',
      expected: 'Activity logs populated with programmatic QA events',
      actual: `Activity logs count: ${count}`,
    });
  } catch (error: unknown) {
    onResult({
      id: 'activity-timeline',
      name: 'Activity Center Timeline Events Stream',
      groupName: group10,
      status: 'failed',
      expected: 'Activity logs have timeline events',
      actual: 'Zero activity logs found',
      errorMessage: getErrorMessage(error),
    });
  }

  // Restore defaults after tests complete
  store.resetAllMockStore();
}
