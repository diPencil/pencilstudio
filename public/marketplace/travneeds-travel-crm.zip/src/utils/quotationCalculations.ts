import {
    QuotationCostItem,
    MarkupType,
    QuotationPricingSummary,
    QuotationServiceLine,
    QuotationCostSummary,
    QuotationProfitAnalysis,
    QuotationFixedCost
} from '../types/quotation';

/**
 * Calculates the total cost for a single cost item.
 */
export const calculateCostItemTotal = (item: QuotationCostItem): number => {
    let total = item.rate * item.quantity;
    
    // Per Night logic
    if (item.nights && item.nights > 0 && (item.pricingType === 'Per Night' || item.pricingType === 'Per Room')) {
        total = total * item.nights;
    }
    
    return total;
};

/**
 * Calculates the markup amount based on cost and markup settings.
 */
export const calculateMarkupAmount = (cost: number, type: MarkupType, value: number): number => {
    if (type === 'Percentage') {
        return (cost * value) / 100;
    }
    return value;
};

/**
 * Calculates totals for the pricing summary based on cost items and markup.
 */
export const calculateQuotationTotals = (
    items: QuotationCostItem[],
    markupType: MarkupType,
    markupValue: number,
    paxCount: number,
    currency: string = 'USD',
    exchangeRate: number = 1
): QuotationPricingSummary => {
    const summary: QuotationPricingSummary = {
        totalAccommodationCost: 0,
        totalSightseeingCost: 0,
        totalTransferCost: 0,
        totalMealsCost: 0,
        totalServiceCost: 0,
        totalOptionalCost: 0,
        grandTotalCost: 0,
        costPerPerson: 0,
        markupType,
        markupValue,
        profitAmount: 0,
        totalSellingPrice: 0,
        sellingPricePerPerson: 0,
        currency,
        exchangeRate,
        totalPax: paxCount
    };

    items.forEach(item => {
        const total = calculateCostItemTotal(item);
        switch (item.category) {
            case 'Accommodation': summary.totalAccommodationCost += total; break;
            case 'Sightseeing': summary.totalSightseeingCost += total; break;
            case 'Transfers': summary.totalTransferCost += total; break;
            case 'Meals': summary.totalMealsCost += total; break;
            case 'Services': summary.totalServiceCost += total; break;
            case 'Optional': summary.totalOptionalCost += total; break;
        }
    });

    // Optional costs are usually separated from the "required" grand total in some systems,
    // but here we'll include everything except Optional in the base grand total for profit calculation,
    // or as per requirement: "Optional Add-ons should be separated from required costs".
    // Let's exclude Optional from grandTotalCost for markup calculation.
    
    summary.grandTotalCost = 
        summary.totalAccommodationCost + 
        summary.totalSightseeingCost + 
        summary.totalTransferCost + 
        summary.totalMealsCost + 
        summary.totalServiceCost;

    summary.profitAmount = calculateMarkupAmount(summary.grandTotalCost, markupType, markupValue);
    summary.totalSellingPrice = summary.grandTotalCost + summary.profitAmount;
    
    // We add optional costs to the final selling price if they are selected, 
    // but for now we just show them in the summary. 
    // Note: In some cases, optionals have their own markup, but we'll keep it simple.
    
    summary.costPerPerson = summary.grandTotalCost / (paxCount || 1);
    summary.sellingPricePerPerson = summary.totalSellingPrice / (paxCount || 1);
    
    return summary;
};

export const calculateServiceLineTotals = (line: QuotationServiceLine): QuotationServiceLine => {
    const unitMultiplier = Math.max(1, line.quantity || 1)
        * Math.max(1, line.nights || 1)
        * Math.max(1, line.pax || 1)
        * Math.max(1, line.units || 1);
    const totalCost = (line.costPrice * unitMultiplier) + (line.taxes || 0) + (line.adjustment || 0);
    const totalSelling = line.isComplimentary ? 0 : (line.sellingPrice * unitMultiplier);
    const profit = totalSelling - totalCost;
    const marginPercent = totalSelling > 0 ? Math.round((profit / totalSelling) * 100) : 0;

    return {
        ...line,
        totalCost,
        totalSelling,
        profit,
        marginPercent
    };
};

export const calculateFixedCostItemTotal = (item: QuotationFixedCost, paxCount: number): number => {
    if (item.status === 'Inactive') return 0;
    const q = item.quantity || 1;
    const d = item.days || 1;
    if (item.allocationMethod === 'Per Person') {
        return item.amount * q * d * paxCount;
    }
    return item.amount * q * d;
};

export const buildCostSummaryFromServiceLines = (
    serviceLines: QuotationServiceLine[],
    paxCount: number,
    fixedCosts?: QuotationFixedCost[]
): QuotationCostSummary => {
    const calculated = serviceLines.map(calculateServiceLineTotals);
    const taxesAndFees = calculated.reduce((sum, line) => sum + (line.taxes || 0), 0);
    const adjustments = calculated.reduce((sum, line) => sum + (line.adjustment || 0), 0);
    
    const activeFixedCosts = fixedCosts ? fixedCosts.filter(fc => fc.status === 'Active') : [];
    const totalFixedCosts = activeFixedCosts.reduce((sum, fc) => sum + calculateFixedCostItemTotal(fc, paxCount), 0);
    const groupTotalCost = calculated.reduce((sum, line) => sum + line.totalCost, 0) + totalFixedCosts;

    const byCategory: Record<string, number> = {};
    const bySupplier: Record<string, number> = {};
    const byDay: Record<string, number> = {};

    calculated.forEach(line => {
        byCategory[line.category] = (byCategory[line.category] || 0) + line.totalCost;
        bySupplier[line.supplierName || 'Without supplier'] = (bySupplier[line.supplierName || 'Without supplier'] || 0) + line.totalCost;
        byDay[`Day ${line.day || 0}`] = (byDay[`Day ${line.day || 0}`] || 0) + line.totalCost;
    });

    activeFixedCosts.forEach(fc => {
        const itemTotal = calculateFixedCostItemTotal(fc, paxCount);
        byCategory[fc.category] = (byCategory[fc.category] || 0) + itemTotal;
        bySupplier[fc.supplierName || 'Without supplier'] = (bySupplier[fc.supplierName || 'Without supplier'] || 0) + itemTotal;
        byDay['Fixed Costs'] = (byDay['Fixed Costs'] || 0) + itemTotal;
    });

    return {
        totalDirectCost: groupTotalCost - taxesAndFees - adjustments,
        taxesAndFees,
        adjustments,
        groupTotalCost,
        perPersonCost: groupTotalCost / Math.max(1, paxCount || 1),
        byCategory,
        bySupplier,
        byDay
    };
};

export const calculatePricingFromServiceLines = (
    serviceLines: QuotationServiceLine[],
    markupType: MarkupType,
    markupValue: number,
    paxCount: number,
    currency: string,
    exchangeRate: number,
    discountAmount = 0,
    commissionAmount = 0,
    manualOverride = false,
    manualSellingPrice = 0,
    fixedCosts?: QuotationFixedCost[],
    appliedScenario?: 'Budget' | 'Standard' | 'Premium' | 'Custom'
): QuotationPricingSummary => {
    const costSummary = buildCostSummaryFromServiceLines(serviceLines, paxCount, fixedCosts);
    
    // Cost base excluding FOC services
    const calculatedLines = serviceLines.map(calculateServiceLineTotals);
    const nonComplimentaryCost = calculatedLines
        .filter(line => !line.isComplimentary)
        .reduce((sum, line) => sum + line.totalCost, 0);

    const activeFixedCosts = fixedCosts ? fixedCosts.filter(fc => fc.status === 'Active') : [];
    const totalFixedCosts = activeFixedCosts.reduce((sum, fc) => sum + calculateFixedCostItemTotal(fc, paxCount), 0);

    const baseCostForMarkup = nonComplimentaryCost + totalFixedCosts;
    const baseMarkup = calculateMarkupAmount(baseCostForMarkup, markupType, markupValue);
    const calculatedSelling = baseCostForMarkup + baseMarkup + commissionAmount - discountAmount;
    const totalSellingPrice = manualOverride ? manualSellingPrice : calculatedSelling;
    const profitAmount = totalSellingPrice - costSummary.groupTotalCost;

    return {
        totalAccommodationCost: costSummary.byCategory.Accommodation || 0,
        totalSightseeingCost: costSummary.byCategory.Sightseeing || 0,
        totalTransferCost: costSummary.byCategory.Transfers || 0,
        totalMealsCost: costSummary.byCategory.Meals || 0,
        totalServiceCost: costSummary.byCategory.Services || 0,
        totalOptionalCost: costSummary.byCategory.Optional || 0,
        grandTotalCost: costSummary.groupTotalCost,
        costPerPerson: costSummary.perPersonCost,
        markupType,
        markupValue,
        profitAmount,
        totalSellingPrice,
        sellingPricePerPerson: totalSellingPrice / Math.max(1, paxCount || 1),
        currency,
        exchangeRate,
        totalPax: paxCount,
        discountAmount,
        commissionAmount,
        manualOverride,
        manualSellingPrice,
        appliedScenario
    };
};

export const buildProfitAnalysis = (
    serviceLines: QuotationServiceLine[],
    pricing: QuotationPricingSummary
): QuotationProfitAnalysis => {
    const calculated = serviceLines.map(calculateServiceLineTotals);
    const totalCost = pricing.grandTotalCost;
    const totalSelling = pricing.totalSellingPrice;
    const grossProfit = totalSelling - totalCost;
    const marginPercent = totalSelling > 0 ? Math.round((grossProfit / totalSelling) * 100) : 0;
    const markupPercent = totalCost > 0 ? Math.round((grossProfit / totalCost) * 100) : 0;
    const profitByCategory: Record<string, number> = {};
    const profitBySupplier: Record<string, number> = {};

    calculated.forEach(line => {
        profitByCategory[line.category] = (profitByCategory[line.category] || 0) + line.profit;
        profitBySupplier[line.supplierName || 'Without supplier'] = (profitBySupplier[line.supplierName || 'Without supplier'] || 0) + line.profit;
    });

    return {
        totalCost,
        totalSelling,
        grossProfit,
        marginPercent,
        markupPercent,
        breakEvenPrice: totalCost,
        lowMarginWarning: marginPercent > 0 && marginPercent < 15 ? 'Margin is below the 15% target.' : undefined,
        highRiskSupplierWarnings: calculated
            .filter(line => line.supplierRisk === 'High Risk' || line.supplierRisk === 'Missing' || line.productStatus === 'Without supplier')
            .map(line => `${line.serviceName}: ${line.warning || line.supplierRisk}`),
        profitByService: calculated.map(line => ({
            serviceName: line.serviceName,
            profit: line.profit,
            marginPercent: line.marginPercent
        })),
        profitByCategory,
        profitBySupplier
    };
};
