import { BrowserRouter as Router, Routes, Route, Outlet } from 'react-router-dom';
import { ToastProvider } from './contexts/ToastContext';
import { ToastContainer } from './components/ui/ToastContainer';
import { LoginPage } from './components/auth/LoginPage';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import { Layout } from './components/layout/Layout';
import { Dashboard } from './components/dashboard/Dashboard';
import { LeadsPage } from './components/leads/LeadsPage';
import { CustomersPage } from './components/customers/CustomersPage';
import { SalesPage } from './components/sales/SalesPage';
import { ReservationsPage } from './components/reservations/ReservationsPage';
import { ProductServiceCategoriesPage } from './components/categories/ProductServiceCategoriesPage';
import { FinancePage } from './components/finance/FinancePage';
import { OperationsPage } from './components/operations/OperationsPage';
import { ReportsPage } from './components/reports/ReportsPage';

// Placeholder components for other pages
import { HelpCenter } from './components/support/HelpCenter';
import { NewTicketPage } from './components/support/NewTicketPage';
import { SupportPage } from './components/support/SupportPage';
import { ViewTicketPage } from './components/support/ViewTicketPage';
import { EditTicketPage } from './components/support/EditTicketPage';
import { KnowledgeBase } from './components/support/KnowledgeBase';
import { UsersPage } from './components/users/UsersPage';
import { InviteUserPage } from './components/users/InviteUserPage';
import { RolesPermissions } from './components/users/RolesPermissions';
import { SystemLogs } from './components/users/SystemLogs';
import { AttendancePage } from './components/attendance/AttendancePage';
import { LeaveRequestsPage } from './components/attendance/LeaveRequestsPage';
import { OvertimeLogs } from './components/attendance/OvertimeLogs';
import { LandingPage } from './components/landing/LandingPage';
import { SupplierTrackerPage } from './components/reservations/SupplierTrackerPage';
import { AddSupplierPage } from './components/reservations/AddSupplierPage';
import { ViewReservationPage } from './components/reservations/ViewReservationPage';
import { NewReservationPage } from './components/reservations/NewReservationPage';
import SupplierProfilePage from './components/reservations/SupplierProfilePage';
import { NewLeadPage } from './components/leads/NewLeadPage';
import { ViewLeadPage } from './components/leads/ViewLeadPage';
import { EditLeadPage } from './components/leads/EditLeadPage';
import { NewCustomerPage } from './components/customers/NewCustomerPage';
import { ViewCustomerPage } from './components/customers/ViewCustomerPage';
import { EditCustomerPage } from './components/customers/EditCustomerPage';
import { NewCorporateAccountPage } from './components/customers/NewCorporateAccountPage';
import { ViewCorporateAccountPage } from './components/customers/ViewCorporateAccountPage';
import { EditCorporateAccountPage } from './components/customers/EditCorporateAccountPage';
import { TodayTasksPage } from './components/sales/TodayTasksPage';
import { NewCasePage } from './components/sales/NewCasePage';
import { CaseDetailsPage } from './components/sales/CaseDetailsPage';
import { QuotationDashboardPage } from './components/sales/QuotationDashboardPage';
import { QuotationAnalyticsPage, QuotationApprovalsPage, QuotationVersionHistoryPage } from './components/sales/QuotationWorkspacePages';
import { QuotationBuilderPage } from './components/sales/QuotationBuilderPage';
import { QuotationPreviewPage } from './components/sales/QuotationPreviewPage';
import { QuotationPrintPage } from './components/sales/QuotationPrintPage';
import { FinancialReportsPage } from './components/finance/FinancialReportsPage';
import { RecordPaymentPage } from './components/finance/RecordPaymentPage';
import { ViewPaymentPage } from './components/finance/ViewPaymentPage';
import { IssueInvoicePage } from './components/finance/IssueInvoicePage';
import { SupplierInvoicePage } from './components/finance/SupplierInvoicePage';
import { CustomReportsPage } from './components/reports/CustomReportsPage';
import { AddOptionalServicePage } from './components/operations/AddOptionalServicePage';
import { TodaysSchedulePage } from './components/operations/TodaysSchedulePage';
import { CalendarViewPage } from './components/operations/CalendarViewPage';
import { ViewTripPage } from './components/operations/ViewTripPage';
import { AddNewItemPage } from './components/categories/AddNewItemPage';
import ProductServiceDetailsPage from './components/categories/ProductServiceDetailsPage';
import { NotificationsPage } from './components/notifications/NotificationsPage';
import { NotificationSettingsPage } from './components/notifications/NotificationSettingsPage';
import { CorporateAccountsPage } from './components/customers/CorporateAccountsPage';
import { AddUserPage } from './components/users/AddUserPage';
import { EditUserPage } from './components/users/EditUserPage';
import { ViewUserPage } from './components/users/ViewUserPage';
import { LocaleProvider } from './localization/LocaleProvider';
import { AssignLeadPage } from './components/leads/AssignLeadPage';
import { ConvertLeadPage } from './components/leads/ConvertLeadPage';
import { OverdueLeadsPage } from './components/leads/OverdueLeadsPage';
import { SchedulePage } from './components/sales/SchedulePage';
import { TaskPage } from './components/sales/TaskPage';
import { NotesPage } from './components/sales/NotesPage';
import { ReservationNotesPage } from './components/reservations/ReservationNotesPage';
import { UploadDocumentPage } from './components/reservations/UploadDocumentPage';
import { ReservationTasksPage } from './components/reservations/ReservationTasksPage';
import { BulkEmailPage } from './components/customers/BulkEmailPage';
import { UpdatePreferencesPage } from './components/customers/UpdatePreferencesPage';
import { AssignStaffPage } from './components/operations/AssignStaffPage';
import { ReportIssuePage } from './components/operations/ReportIssuePage';

import { OmnichannelDashboardPage } from './components/omnichannel/OmnichannelDashboardPage';
import { OmnichannelInboxPage } from './components/omnichannel/OmnichannelInboxPage';
import { OmnichannelConversationsPage } from './components/omnichannel/OmnichannelConversationsPage';
import { OmnichannelChannelsPage } from './components/omnichannel/OmnichannelChannelsPage';
import { OmnichannelTemplatesPage } from './components/omnichannel/OmnichannelTemplatesPage';
import { OmnichannelAutomationPage } from './components/omnichannel/OmnichannelAutomationPage';
import { OmnichannelSlaPage } from './components/omnichannel/OmnichannelSlaPage';
import { OmnichannelAnalyticsPage } from './components/omnichannel/OmnichannelAnalyticsPage';
import { OmnichannelSettingsPage } from './components/omnichannel/OmnichannelSettingsPage';
import { OmnichannelRoutingPage } from './components/omnichannel/OmnichannelRoutingPage';
import { OmnichannelTagsPage } from './components/omnichannel/OmnichannelTagsPage';
import { OmnichannelTeamPage } from './components/omnichannel/OmnichannelTeamPage';
import { OmnichannelActivityPage } from './components/omnichannel/OmnichannelActivityPage';
import { OmnichannelBroadcastsPage } from './components/omnichannel/OmnichannelBroadcastsPage';
import { OmnichannelMockStoreProvider } from './components/omnichannel/store/OmnichannelMockStore';
import { OmnichannelDiagnosticsPage } from './components/omnichannel/OmnichannelDiagnosticsPage';

function App() {
  return (
    <LocaleProvider>
      <ToastProvider>
        <Router>
          <Routes>
            <Route path="/landing" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/" element={
              <ProtectedRoute>
                <Layout />
              </ProtectedRoute>
            }>
              <Route index element={<Dashboard />} />
              <Route path="notifications" element={<NotificationsPage />} />
              <Route path="notifications/settings" element={<NotificationSettingsPage />} />
              <Route path="leads" element={<LeadsPage />} />
              <Route path="leads/new" element={<NewLeadPage />} />
              <Route path="leads/view" element={<ViewLeadPage />} />
              <Route path="leads/edit" element={<EditLeadPage />} />
              <Route path="leads/assign" element={<AssignLeadPage />} />
              <Route path="leads/convert" element={<ConvertLeadPage />} />
              <Route path="leads/overdue" element={<OverdueLeadsPage />} />
              <Route path="customers" element={<CustomersPage />} />
              <Route path="customers/corporate" element={<CorporateAccountsPage />} />
              <Route path="customers/corporate/new" element={<NewCorporateAccountPage />} />
              <Route path="customers/corporate/view" element={<ViewCorporateAccountPage />} />
              <Route path="customers/corporate/edit" element={<EditCorporateAccountPage />} />
              <Route path="customers/new" element={<NewCustomerPage />} />
              <Route path="customers/view" element={<ViewCustomerPage />} />
              <Route path="customers/edit" element={<EditCustomerPage />} />
              <Route path="omnichannel" element={<OmnichannelMockStoreProvider><Outlet /></OmnichannelMockStoreProvider>}>
                <Route index element={<OmnichannelDashboardPage />} />
                <Route path="dashboard" element={<OmnichannelDashboardPage />} />
                <Route path="inbox" element={<OmnichannelInboxPage />} />
                <Route path="inbox/:conversationId/chat" element={<OmnichannelInboxPage standaloneChat />} />
                <Route path="inbox/:conversationId" element={<OmnichannelInboxPage />} />
                <Route path="conversations" element={<OmnichannelConversationsPage />} />
                <Route path="channels" element={<OmnichannelChannelsPage />} />
                <Route path="routing" element={<OmnichannelRoutingPage />} />
                <Route path="templates" element={<OmnichannelTemplatesPage />} />
                <Route path="tags" element={<OmnichannelTagsPage />} />
                <Route path="automation" element={<OmnichannelAutomationPage />} />
                <Route path="sla" element={<OmnichannelSlaPage />} />
                <Route path="team" element={<OmnichannelTeamPage />} />
                <Route path="analytics" element={<OmnichannelAnalyticsPage />} />
                <Route path="activity" element={<OmnichannelActivityPage />} />
                <Route path="settings" element={<OmnichannelSettingsPage />} />
                <Route path="broadcasts" element={<OmnichannelBroadcastsPage />} />
                <Route path="diagnostics" element={<OmnichannelDiagnosticsPage />} />
              </Route>
              <Route path="product-categories" element={<ProductServiceCategoriesPage />} />
              <Route path="products-services" element={<ProductServiceCategoriesPage />} />
              <Route path="products-services/dashboard" element={<ProductServiceCategoriesPage />} />
              <Route path="products-services/catalog" element={<ProductServiceCategoriesPage />} />
              <Route path="products-services/categories" element={<ProductServiceCategoriesPage />} />
              <Route path="products-services/pricing" element={<ProductServiceCategoriesPage />} />
              <Route path="products-services/analytics" element={<ProductServiceCategoriesPage />} />
              <Route path="products-services/packages" element={<ProductServiceCategoriesPage />} />
              <Route path="product-categories/items/:itemId" element={<ProductServiceDetailsPage />} />
              <Route path="products-services/items/:itemId" element={<ProductServiceDetailsPage />} />
              <Route path="sales" element={<SalesPage />} />
              <Route path="sales/tasks" element={<TodayTasksPage />} />
              <Route path="sales/task" element={<TaskPage />} />
              <Route path="sales/schedule" element={<SchedulePage />} />
              <Route path="sales/notes" element={<NotesPage />} />
              <Route path="sales/new-case" element={<NewCasePage />} />
              <Route path="sales/case-details" element={<CaseDetailsPage />} />
              <Route path="reservations" element={<ReservationsPage />} />
              <Route path="reservations/new" element={<NewReservationPage />} />
              <Route path="reservations/view" element={<ViewReservationPage />} />
              <Route path="reservations/suppliers" element={<SupplierTrackerPage />} />
              <Route path="sales/cases" element={<SalesPage />} />
              <Route path="sales/quotations" element={<QuotationDashboardPage />} />
              <Route path="sales/quotations/analytics" element={<QuotationAnalyticsPage />} />
              <Route path="sales/quotations/approvals" element={<QuotationApprovalsPage />} />
              <Route path="sales/quotations/version-history" element={<QuotationVersionHistoryPage />} />
              <Route path="sales/cases/new" element={<NewCasePage />} />
              <Route path="sales/cases/:caseId" element={<CaseDetailsPage />} />
              <Route path="sales/cases/:caseId/quotations" element={<CaseDetailsPage />} />
              <Route path="sales/cases/:caseId/quotations/create" element={<QuotationBuilderPage />} />
              <Route path="sales/cases/:caseId/quotations/new" element={<QuotationBuilderPage />} />
              <Route path="sales/cases/:caseId/quotations/:quotationId/edit" element={<QuotationBuilderPage />} />
              <Route path="sales/cases/:caseId/quotations/:quotationId/preview" element={<QuotationPreviewPage />} />
              <Route path="sales/cases/:caseId/quotations/:quotationId/print" element={<QuotationPrintPage />} />
              <Route path="reservations/tracker" element={<SupplierTrackerPage />} />
              <Route path="reservations/notes" element={<ReservationNotesPage />} />
              <Route path="reservations/upload" element={<UploadDocumentPage />} />
              <Route path="reservations/tasks" element={<ReservationTasksPage />} />
              <Route path="reservations/new-supplier" element={<AddSupplierPage />} />
              <Route path="reservations/suppliers/:supplierId" element={<SupplierProfilePage />} />
              <Route path="customers/bulk-email" element={<BulkEmailPage />} />
              <Route path="customers/preferences" element={<UpdatePreferencesPage />} />
              <Route path="finance" element={<FinancePage />} />
              <Route path="finance/reports" element={<FinancialReportsPage />} />
              <Route path="finance/record-payment" element={<RecordPaymentPage />} />
              <Route path="finance/view-payment" element={<ViewPaymentPage />} />
              <Route path="finance/issue-invoice" element={<IssueInvoicePage />} />
              <Route path="finance/supplier-invoice" element={<SupplierInvoicePage />} />
              <Route path="operations" element={<OperationsPage />} />
              <Route path="operations/view-trip" element={<ViewTripPage />} />
              <Route path="operations/assign-staff" element={<AssignStaffPage />} />
              <Route path="operations/report-issue" element={<ReportIssuePage />} />
              <Route path="operations/new-service" element={<AddOptionalServicePage />} />
              <Route path="operations/schedule" element={<TodaysSchedulePage />} />
              <Route path="operations/calendar" element={<CalendarViewPage />} />
              <Route path="reports" element={<ReportsPage />} />
              <Route path="reports/custom" element={<CustomReportsPage />} />
              <Route path="product-categories/new" element={<AddNewItemPage />} />
              <Route path="help-center" element={<HelpCenter />} />
              <Route path="help-center/new" element={<NewTicketPage />} />
              <Route path="help-center/tickets" element={<SupportPage />} />
              <Route path="help-center/tickets/view" element={<ViewTicketPage />} />
              <Route path="help-center/tickets/edit" element={<EditTicketPage />} />
              <Route path="help-center/docs" element={<KnowledgeBase />} />
              <Route path="users" element={<UsersPage />} />
              <Route path="users/new" element={<AddUserPage />} />
              <Route path="users/edit" element={<EditUserPage />} />
              <Route path="users/view" element={<ViewUserPage />} />
              <Route path="users/invite" element={<InviteUserPage />} />
              <Route path="users/roles" element={<RolesPermissions />} />
              <Route path="users/logs" element={<SystemLogs />} />
              <Route path="attendance" element={<AttendancePage />} />
              <Route path="attendance/leaves" element={<LeaveRequestsPage />} />
              <Route path="attendance/overtime" element={<OvertimeLogs />} />
            </Route>
          </Routes>
          <ToastContainer />
        </Router>
      </ToastProvider>
    </LocaleProvider>
  );
}

export default App;
