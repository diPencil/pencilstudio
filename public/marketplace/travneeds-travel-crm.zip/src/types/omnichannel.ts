export type OmnichannelChannelType =
  | 'whatsapp'
  | 'whatsapp_business'
  | 'facebook_messenger'
  | 'instagram_dm'
  | 'instagram_comment'
  | 'website_chat'
  | 'email'
  | 'sms'
  | 'phone'
  | 'future';

export type OmnichannelConnectionStatus = 'connected' | 'sync_warning' | 'disconnected' | 'pending_setup' | 'planned';

export type OmnichannelHealthStatus = 'healthy' | 'degraded' | 'critical' | 'offline' | 'planned';

export type OmnichannelConversationStatus = 'open' | 'pending' | 'waiting_agent' | 'waiting_customer' | 'closed' | 'escalated';

export type OmnichannelPriority = 'low' | 'normal' | 'high' | 'urgent';

export type OmnichannelSlaStatus = 'ok' | 'at_risk' | 'breached' | 'paused' | 'none';

export type OmnichannelMessageDirection = 'inbound' | 'outbound' | 'internal' | 'system';

export type OmnichannelMessageKind = 'text' | 'template' | 'attachment' | 'call_log' | 'system_event';

export type OmnichannelTemplateLanguage = 'en' | 'ar';

export type OmnichannelTemplateApprovalStatus = 'draft' | 'pending_review' | 'approved' | 'rejected' | 'archived';

export type OmnichannelLinkedRecordType = 'lead' | 'customer' | 'reservation' | 'sales_case' | 'quotation' | 'support_ticket';

export type OmnichannelRuleStatus = 'active' | 'paused' | 'draft';
export type OmnichannelAutomationTrigger =
  | 'new_conversation'
  | 'no_agent_reply'
  | 'sla_at_risk'
  | 'customer_replied'
  | 'conversation_closed'
  | 'keyword_detected'
  | 'channel_disconnected';

export type OmnichannelAutomationActionType =
  | 'assign_team'
  | 'add_tag'
  | 'send_quick_reply'
  | 'create_ticket'
  | 'escalate'
  | 'notify_supervisor';

export type OmnichannelActivityCategory =
  | 'channel_connection'
  | 'conversation_action'
  | 'assignment_action'
  | 'template_change'
  | 'automation_event'
  | 'audit_event';

export type OmnichannelConversionMode = 'convert_lead' | 'convert_customer' | 'create_ticket' | 'create_case' | 'link_existing';

export type OmnichannelConversionActivityType =
  | 'converted_to_lead'
  | 'converted_to_customer'
  | 'ticket_created'
  | 'case_created'
  | 'record_linked'
  | 'record_unlinked'
  | 'record_restored';

export interface OmnichannelLocalizedText {
  en: string;
  ar: string;
}

export interface OmnichannelChannelOwner {
  id: string;
  name: string;
  department: 'Sales' | 'Reservations' | 'Operations' | 'Support' | 'Marketing' | 'Management';
  email: string;
}

export interface OmnichannelChannelSettings {
  businessHoursId: string;
  defaultQueueId: string;
  autoReplyEnabled: boolean;
  templatesEnabled: boolean;
  attachmentsEnabled: boolean;
  maxAttachmentSizeMb: number;
  inboundSyncEnabled: boolean;
  outboundMockEnabled: boolean;
}

export interface OmnichannelChannelHealth {
  status: OmnichannelHealthStatus;
  connectionStatus: OmnichannelConnectionStatus;
  syncStatus: 'realtime' | 'synced' | 'delayed' | 'failed' | 'not_configured' | 'planned';
  lastSyncAt?: string;
  lastInboundAt?: string;
  webhookStatus: 'ok' | 'warning' | 'failed' | 'not_configured' | 'planned';
  openConversations: number;
  failedEventsToday: number;
  healthScore: number;
  notes: string;
}

export interface OmnichannelChannel {
  id: string;
  type: OmnichannelChannelType;
  name: string;
  provider: string;
  accountLabel: string;
  owner: OmnichannelChannelOwner;
  settings: OmnichannelChannelSettings;
  health: OmnichannelChannelHealth;
  isFuture: boolean;
}

export interface OmnichannelTag {
  id: string;
  label: OmnichannelLocalizedText;
  colorClass: string;
  category: 'travel_interest' | 'priority' | 'language' | 'sales_stage' | 'support' | 'automation';
}

export interface OmnichannelLinkedRecord {
  type: OmnichannelLinkedRecordType;
  id: string;
  label: string;
  href?: string;
  status?: string;
  ownerName?: string;
  createdAt?: string;
  priority?: OmnichannelPriority;
  stage?: string;
  teamName?: string;
  origin?: 'existing' | 'converted' | 'linked';
}

export interface OmnichannelParticipant {
  id: string;
  name: string;
  role: 'customer' | 'lead' | 'agent' | 'system';
  phone?: string;
  email?: string;
  preferredLanguage: OmnichannelTemplateLanguage;
}

export interface OmnichannelSlaSnapshot {
  status: OmnichannelSlaStatus;
  firstResponseDueAt?: string;
  resolutionDueAt?: string;
  firstResponseRemainingMinutes: number;
  resolutionRemainingMinutes: number;
  breachedAt?: string;
}

export interface OmnichannelConversation {
  id: string;
  channelId: string;
  channelType: OmnichannelChannelType;
  subject: string;
  customer: OmnichannelParticipant;
  status: OmnichannelConversationStatus;
  priority: OmnichannelPriority;
  queueId: string;
  assignedStaffId?: string;
  assignedStaffName?: string;
  unreadCount: number;
  tagIds: string[];
  linkedRecords: OmnichannelLinkedRecord[];
  sla: OmnichannelSlaSnapshot;
  lastMessagePreview: string;
  lastMessageAt: string;
  createdAt: string;
}

export interface OmnichannelAttachment {
  id: string;
  fileName: string;
  fileType: 'image' | 'pdf' | 'document' | 'audio' | 'other';
  sizeKb: number;
  mockUrlLabel: string;
}

export interface OmnichannelMessage {
  id: string;
  conversationId: string;
  direction: OmnichannelMessageDirection;
  kind: OmnichannelMessageKind;
  authorName: string;
  body: string;
  createdAt: string;
  deliveryStatus?: 'sending' | 'sent' | 'delivered' | 'read' | 'failed';
  failureReason?: string;
  retryCount?: number;
  templateId?: string;
  attachments: OmnichannelAttachment[];
}

export interface OmnichannelInternalNote {
  id: string;
  conversationId: string;
  authorId: string;
  authorName: string;
  body: string;
  createdAt: string;
  visibility: 'internal';
  status?: 'active' | 'archived';
  updatedAt?: string;
  archivedAt?: string;
}

export interface OmnichannelTemplateVariable {
  key: string;
  label: OmnichannelLocalizedText;
  exampleValue: string;
  required: boolean;
}

export interface OmnichannelQuickReplyTemplate {
  id: string;
  category: 'sales' | 'support' | 'reservation' | 'payment' | 'general';
  channelTypes: OmnichannelChannelType[];
  title: OmnichannelLocalizedText;
  body: OmnichannelLocalizedText;
  language: OmnichannelTemplateLanguage;
  approvalStatus: OmnichannelTemplateApprovalStatus;
  variables: OmnichannelTemplateVariable[];
  usageCount: number;
}

export interface OmnichannelRoutingCondition {
  field: 'channelType' | 'priority' | 'tagId' | 'language' | 'unassigned';
  operator: 'equals' | 'includes' | 'is';
  value: string;
}

export interface OmnichannelRoutingRule {
  id: string;
  name: OmnichannelLocalizedText;
  status: OmnichannelRuleStatus;
  priority: number;
  conditions: OmnichannelRoutingCondition[];
  targetQueueId: string;
  assignToStaffId?: string;
  autoTagIds: string[];
  fallbackQueueId?: string;
  slaPolicyId?: string;
  keywords?: string[];
  language?: OmnichannelTemplateLanguage | 'any';
  customerSegmentId?: string;
  testSummary?: string;
}

export interface OmnichannelBusinessHours {
  id: string;
  name: OmnichannelLocalizedText;
  timezone: string;
  days: Array<'sun' | 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat'>;
  startTime: string;
  endTime: string;
}

export interface OmnichannelSlaPolicy {
  id: string;
  name: OmnichannelLocalizedText;
  queueId: string;
  priority: OmnichannelPriority;
  firstResponseMinutes: number;
  resolutionMinutes: number;
  businessHoursId: string;
  escalationQueueId?: string;
  status: OmnichannelRuleStatus;
}

export interface OmnichannelQueue {
  id: string;
  name: OmnichannelLocalizedText;
  department: 'Sales' | 'Reservations' | 'Operations' | 'Support' | 'Management';
  ownerId: string;
  openCount: number;
  pendingCount: number;
  breachedCount: number;
  averageFirstResponseMinutes: number;
}

export interface OmnichannelStaffPerformance {
  staffId: string;
  staffName: string;
  department: string;
  assignedCount: number;
  openCount: number;
  closedToday: number;
  averageFirstResponseMinutes: number;
  slaBreaches: number;
  convertedLeads: number;
  linkedBookings: number;
  customerSatisfactionScore: number;
}

export interface OmnichannelAnalyticsChannelSummary {
  channelType: OmnichannelChannelType;
  conversationCount: number;
  openCount: number;
  closedCount: number;
  averageResponseMinutes: number;
  slaBreaches: number;
  conversionCount: number;
}

export interface OmnichannelAnalyticsSummary {
  totalConversations: number;
  openConversations: number;
  pendingConversations: number;
  closedConversations: number;
  unassignedConversations: number;
  unreadMessages: number;
  slaBreaches: number;
  averageFirstResponseMinutes: number;
  leadConversions: number;
  bookingConversions: number;
  caseConversions: number;
  channelSummaries: OmnichannelAnalyticsChannelSummary[];
}

export interface OmnichannelConversationFilters {
  query?: string;
  channelTypes?: OmnichannelChannelType[];
  statuses?: OmnichannelConversationStatus[];
  priorities?: OmnichannelPriority[];
  slaStatuses?: OmnichannelSlaStatus[];
  assignedState?: 'all' | 'assigned' | 'unassigned';
  unreadOnly?: boolean;
  tagIds?: string[];
}

export interface OmnichannelLeadRecordMock {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  companyName?: string;
  source: string;
  stage: string;
  ownerId: string;
  ownerName: string;
  createdAt: string;
}

export interface OmnichannelCustomerRecordMock {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  companyName?: string;
  tier: string;
  ownerId: string;
  ownerName: string;
  createdAt: string;
}

export interface OmnichannelTicketRecordMock {
  id: string;
  subject: string;
  customerName: string;
  priority: OmnichannelPriority;
  category: string;
  status: string;
  ownerId: string;
  ownerName: string;
  teamName: string;
  createdAt: string;
}

export interface OmnichannelCaseRecordMock {
  id: string;
  subject: string;
  customerName: string;
  caseType: string;
  status: string;
  ownerId: string;
  ownerName: string;
  teamName: string;
  createdAt: string;
}

export interface OmnichannelConversionActivityEvent {
  id: string;
  conversationId: string;
  type: OmnichannelConversionActivityType;
  recordType: OmnichannelLinkedRecordType;
  recordId: string;
  recordLabel: string;
  actorName: string;
  createdAt: string;
  note?: string;
}

export interface OmnichannelConversionDraft {
  mode: OmnichannelConversionMode;
  customerName: string;
  phone: string;
  email: string;
  channelIdentity: string;
  companyName: string;
  leadSource: string;
  leadStage: string;
  ticketPriority: '' | OmnichannelPriority;
  ticketCategory: string;
  caseType: string;
  assignedStaffId: string;
  assignedTeamId: string;
  notes: string;
  existingRecordKey: string;
}

export interface OmnichannelConversionSubmitPayload extends OmnichannelConversionDraft {
  conversationId: string;
}

export interface OmnichannelDashboardMetric {
  id: string;
  label: OmnichannelLocalizedText;
  value: string;
  trend: string;
  trendType: 'up' | 'down' | 'neutral';
}

export interface OmnichannelQueueOverviewItem {
  queueId: string;
  queueName: OmnichannelLocalizedText;
  openCount: number;
  waitingCustomerCount: number;
  waitingAgentCount: number;
  breachedCount: number;
  assignedTeam: string;
}

export interface OmnichannelChannelVolumeBreakdown {
  channelType: OmnichannelChannelType;
  conversations: number;
  replies: number;
  conversionCount: number;
}

export interface OmnichannelAgentWorkloadSnapshot {
  staffId: string;
  staffName: string;
  teamName: string;
  onlineStatus: 'online' | 'offline' | 'busy';
  assignedConversations: number;
  activeTickets: number;
  averageResponseMinutes: number;
  satisfactionScore: number;
  workloadPercent: number;
}

export interface OmnichannelSlaRiskItem {
  conversationId: string;
  customerName: string;
  channelType: OmnichannelChannelType;
  riskLevel: 'low' | 'medium' | 'high';
  remainingMinutes: number;
  assignedStaffName?: string;
}

export interface OmnichannelEscalationAlert {
  id: string;
  conversationId: string;
  title: string;
  severity: 'info' | 'warning' | 'critical';
  channelType: OmnichannelChannelType;
  ownerName: string;
  createdAt: string;
}

export interface OmnichannelPendingHandoff {
  id: string;
  conversationId: string;
  fromTeam: string;
  toTeam: string;
  reason: string;
  dueAt: string;
}

export interface OmnichannelDashboardSnapshot {
  metrics: OmnichannelDashboardMetric[];
  queueOverview: OmnichannelQueueOverviewItem[];
  channelVolume: OmnichannelChannelVolumeBreakdown[];
  agentSnapshots: OmnichannelAgentWorkloadSnapshot[];
  slaRisks: OmnichannelSlaRiskItem[];
  escalations: OmnichannelEscalationAlert[];
  pendingHandoffs: OmnichannelPendingHandoff[];
}

export interface OmnichannelChannelConfiguration {
  channelId: string;
  phoneNumber?: string;
  displayName?: string;
  provider?: string;
  businessId?: string;
  webhookUrlPreview?: string;
  templateSyncStatus?: string;
  pageName?: string;
  pageId?: string;
  permissionsChecklist?: string[];
  accountHandle?: string;
  monitorDirectMessages?: boolean;
  monitorComments?: boolean;
  monitorMentions?: boolean;
  widgetTitle?: string;
  brandColor?: string;
  greetingMessage?: string;
  offlineMessage?: string;
  embedCodePreview?: string;
  mailboxName?: string;
  forwardingAddress?: string;
  senderIdentity?: string;
  signature?: string;
  senderId?: string;
  region?: string;
  callSource?: string;
  missedCallRule?: string;
  callbackSlaMinutes?: number;
  primaryLanguage: OmnichannelTemplateLanguage;
  defaultSlaPolicyId: string;
  assignedTeamId: string;
}

export interface OmnichannelRoutingSimulation {
  id: string;
  channelType: OmnichannelChannelType;
  language: OmnichannelTemplateLanguage;
  customerSegmentId?: string;
  priority: OmnichannelPriority;
  keywords: string[];
  workingHours: boolean;
  matchedRuleId: string;
  matchedQueueId: string;
}

export interface OmnichannelAutomationRule {
  id: string;
  name: OmnichannelLocalizedText;
  status: OmnichannelRuleStatus;
  trigger: OmnichannelAutomationTrigger;
  conditions: string[];
  actions: Array<{
    type: OmnichannelAutomationActionType;
    summary: string;
  }>;
  ownerId: string;
  ownerName: string;
  priority: number;
  lastRunAt?: string;
}

export interface OmnichannelAutomationActivity {
  id: string;
  ruleId: string;
  ruleName: string;
  conversationId?: string;
  status: 'success' | 'warning' | 'failed';
  message: string;
  createdAt: string;
}

export interface OmnichannelLabelDefinition {
  id: string;
  name: OmnichannelLocalizedText;
  description?: OmnichannelLocalizedText;
  colorClass: string;
  usageCount: number;
  type: 'tag' | 'segment' | 'priority_label' | 'sla_label';
}

export interface OmnichannelHoliday {
  id: string;
  name: OmnichannelLocalizedText;
  date: string;
}

export interface OmnichannelEscalationStep {
  id: string;
  level: 1 | 2 | 3;
  roleName: string;
  responseMinutes: number;
}

export interface OmnichannelTeamMemberWorkload {
  id: string;
  name: string;
  teamName: string;
  onlineStatus: 'online' | 'offline' | 'busy';
  assignedConversations: number;
  activeTickets: number;
  averageResponseMinutes: number;
  satisfactionScore: number;
  workloadPercent: number;
  supervisorName: string;
}

export interface OmnichannelReportSchedule {
  id: string;
  name: string;
  frequency: 'daily' | 'weekly' | 'monthly';
  nextRunAt: string;
  recipients: string[];
}

export interface OmnichannelActivityLogEntry {
  id: string;
  actorName: string;
  category: OmnichannelActivityCategory;
  channelType?: OmnichannelChannelType;
  conversationId?: string;
  summary: string;
  createdAt: string;
}

export interface OmnichannelSettingsSnapshot {
  defaultAssignmentPolicy: string;
  defaultSlaPolicyId: string;
  notificationEmail: boolean;
  notificationBrowser: boolean;
  closeReasons: string[];
  dataRetentionDays: number;
  consentOptInRequired: boolean;
  languageFallback: OmnichannelTemplateLanguage;
  internalNoteVisibility: 'team_only' | 'department' | 'management';
  identityMergeRule: 'strict' | 'suggested' | 'auto';
}

export interface OmnichannelBroadcastCampaign {
  id: string;
  name: string;
  audienceSegmentId: string;
  channelType: OmnichannelChannelType;
  templateId: string;
  scheduledAt: string;
  deliveryStatus: 'draft' | 'scheduled' | 'sent' | 'paused';
  optInWarning: string;
}
