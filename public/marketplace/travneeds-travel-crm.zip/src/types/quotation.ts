/**
 * Quotation Module Types & Interfaces
 */

export type QuotationStatus = 'Draft' | 'Sent' | 'Revised' | 'Approved' | 'Rejected' | 'Expired';

export type PricingType = 'Per Person' | 'Per Group' | 'Per Room' | 'Per Vehicle' | 'Per Night' | 'Fixed';

export type CostCategory = 'Accommodation' | 'Sightseeing' | 'Transfers' | 'Meals' | 'Services' | 'Optional';

export type MarkupType = 'Fixed' | 'Percentage';

export type QuotationServiceStatus = 'Active' | 'Draft' | 'Inactive' | 'Archived' | 'Needs review' | 'Without supplier';

export interface QuotationServiceLine {
    id: string;
    productId: string;
    serviceName: string;
    category: CostCategory;
    type: string;
    destination: string;
    supplierId?: string;
    supplierName?: string;
    supplierStatus?: string;
    supplierRisk?: 'Healthy' | 'Monitor' | 'High Risk' | 'Missing';
    productStatus: QuotationServiceStatus;
    costPrice: number;
    sellingPrice: number;
    quantity: number;
    nights: number;
    pax: number;
    units: number;
    taxes: number;
    adjustment: number;
    totalCost: number;
    totalSelling: number;
    profit: number;
    marginPercent: number;
    day?: number;
    availability: string;
    notes?: string;
    warning?: string;
    isComplimentary?: boolean;
}

export interface QuotationCostSummary {
    totalDirectCost: number;
    taxesAndFees: number;
    adjustments: number;
    groupTotalCost: number;
    perPersonCost: number;
    byCategory: Record<string, number>;
    bySupplier: Record<string, number>;
    byDay: Record<string, number>;
}

export interface QuotationProfitAnalysis {
    totalCost: number;
    totalSelling: number;
    grossProfit: number;
    marginPercent: number;
    markupPercent: number;
    breakEvenPrice: number;
    lowMarginWarning?: string;
    highRiskSupplierWarnings: string[];
    profitByService: Array<{ serviceName: string; profit: number; marginPercent: number }>;
    profitByCategory: Record<string, number>;
    profitBySupplier: Record<string, number>;
}

export interface QuotationActivity {
    id: string;
    type: string;
    message: string;
    date: string;
    user?: string;
}

export interface ProposalLog {
    id: string;
    action: string;
    status: QuotationStatus;
    date: string;
    note: string;
}

export interface QuotationAttachment {
    id: string;
    fileName: string;
    type: 'Passport Copy' | 'Supplier Confirmation' | 'Visa Document' | 'Payment Proof' | 'Proposal PDF' | 'Other' | string;
    status: 'Draft' | 'Attached' | 'Verified' | 'Rejected';
    uploadedAt: string;
    visibility: 'Internal' | 'Client';
    notes?: string;
}

export interface QuotationApprovalReview {
    id: string;
    reviewer: string;
    status: 'Pending' | 'Approved' | 'Rejected' | 'Changes Requested';
    date: string;
    comment: string;
}

export interface QuotationPaxTemplate {
    id: string;
    label: string; // e.g., "10+1", "15+1", "Custom"
    adults: number;
    focCount: number;
    sharingType: 'Double' | 'Triple' | 'Single';
}

export interface QuotationCustomerInfo {
    customerName: string;
    companyName?: string;
    contactPerson?: string;
    email: string;
    phone: string;
    whatsapp?: string;
    nationality: string;
    market?: string;
    groupType: 'FIT' | 'Group' | 'Corporate' | 'Incentive';
    pax: {
        adults: number;
        children: number;
        infants: number;
        total: number;
        arrival: string;
        departure: string;
        nights: number;
    };
}

export interface QuotationProgramOverview {
    title: string;
    subtitle?: string;
    packageCode: string;
    packageType: string;
    destinations: string[];
    citiesCovered: string[];
    nights: number;
    season: string;
    description: string;
    highlights: string[];
    coverImage?: string;
}

export interface QuotationItineraryDay {
    day: number;
    date?: string;
    title: string;
    route: string;
    city: string;
    description: string;
    highlights?: string[];
    meals: ('B' | 'L' | 'D' | 'MOB')[];
    accommodation?: string;
    transport?: string;
    optionalTours?: string[];
    image?: string;
    notes?: string;
    serviceLineIds?: string[];
}

export interface QuotationCostItem {
    id: string;
    name: string;
    category: CostCategory;
    city: string;
    description?: string;
    rate: number;
    currency: string;
    pricingType: PricingType;
    quantity: number;
    nights?: number;
    totalCost: number;
    notes?: string;
}

export interface QuotationPricingSummary {
    totalAccommodationCost: number;
    totalSightseeingCost: number;
    totalTransferCost: number;
    totalMealsCost: number;
    totalServiceCost: number;
    totalOptionalCost: number;
    grandTotalCost: number;
    costPerPerson: number;
    markupType: MarkupType;
    markupValue: number;
    profitAmount: number;
    totalSellingPrice: number;
    sellingPricePerPerson: number;
    currency: string;
    exchangeRate: number;
    singleSupplement?: number;
    childPrice?: number;
    infantPrice?: number;
    totalPax?: number;
    discountAmount?: number;
    commissionAmount?: number;
    manualOverride?: boolean;
    manualSellingPrice?: number;
    appliedScenario?: 'Budget' | 'Standard' | 'Premium' | 'Custom';
}

export interface QuotationFixedCost {
    id: string;
    name: string;
    category: 'Tour Guide' | 'Private Vehicle' | 'Airport Representative' | 'Group Handling Fee' | 'Service Fee' | 'Miscellaneous' | string;
    supplierId?: string;
    supplierName?: string;
    amount: number;
    currency: string;
    allocationMethod: 'Split Equally' | 'Per Person' | 'Per Group' | 'Per Day';
    quantity: number;
    days?: number;
    notes?: string;
    status: 'Active' | 'Inactive';
}

export interface QuotationVersion {
    id: string;
    versionNumber: number;
    status: QuotationStatus;
    preparedBy: string;
    preparedDate: string;
    expiryDate: string;
    internalNotes?: string;
    clientFacingNotes?: string;
    customerInfo: QuotationCustomerInfo;
    programOverview: QuotationProgramOverview;
    inclusions: string[];
    exclusions: string[];
    itinerary: QuotationItineraryDay[];
    costing: QuotationCostItem[];
    serviceLines?: QuotationServiceLine[];
    costSummary?: QuotationCostSummary;
    pricing: QuotationPricingSummary;
    profitAnalysis?: QuotationProfitAnalysis;
    activity?: QuotationActivity[];
    proposalLogs?: ProposalLog[];
    attachments?: QuotationAttachment[];
    approvalReviews?: QuotationApprovalReview[];
    pdfTemplate?: 'Classic' | 'Modern' | 'Corporate';
    terms: string;
    fixedCosts?: QuotationFixedCost[];
}

export interface Quotation {
    id: string;
    caseId: string;
    reference: string;
    currentVersion: number;
    versions: QuotationVersion[];
    createdAt: string;
    updatedAt: string;
}
