export interface User {
  id: string;
  email: string;
  full_name: string;
  avatar_url?: string;
  role: 'admin' | 'manager' | 'agent';
  created_at: string;
  updated_at: string;
}

export interface Lead {
  id: string;
  lead_id: string;
  name: string;
  email: string;
  phone: string;
  source: 'Website' | 'Social Media' | 'Email' | 'Walk-in' | 'Referral';
  type: 'B2B' | 'B2C';
  status: 'New' | 'Contacted' | 'Qualified' | 'Proposal' | 'Negotiation' | 'Closed Won' | 'Closed Lost';
  agent_id: string;
  agent?: User;
  value?: number;
  notes?: string;
  last_contact?: string;
  next_followup?: string;
  created_at: string;
  updated_at: string;
}

export interface Customer {
  id: string;
  customer_id: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  address?: string;
  category_id?: string;
  category?: Category;
  total_value: number;
  status: 'Active' | 'Inactive' | 'Suspended';
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  color: string;
  created_at: string;
  updated_at: string;
}

export interface Sale {
  id: string;
  sale_id: string;
  customer_id: string;
  customer?: Customer;
  agent_id: string;
  agent?: User;
  amount: number;
  status: 'Pending' | 'Confirmed' | 'Cancelled' | 'Refunded';
  payment_method: 'Cash' | 'Card' | 'Bank Transfer' | 'Check';
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Reservation {
  id: string;
  reservation_id: string;
  customer_id: string;
  customer?: Customer;
  service: string;
  date: string;
  time: string;
  duration: number;
  status: 'Confirmed' | 'Pending' | 'Cancelled' | 'Completed';
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface SupportTicket {
  id: string;
  ticket_id: string;
  customer_id: string;
  customer?: Customer;
  subject: string;
  description: string;
  status: 'Open' | 'In Progress' | 'Resolved' | 'Closed';
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  assigned_to?: string;
  assignee?: User;
  created_at: string;
  updated_at: string;
}

export interface Attendance {
  id: string;
  user_id: string;
  user?: User;
  date: string;
  check_in: string;
  check_out?: string;
  total_hours?: number;
  status: 'Present' | 'Absent' | 'Late' | 'Half Day';
  notes?: string;
  created_at: string;
  updated_at: string;
}

// Supplier related types for the Supplier Management upgrade
export interface SupplierContact {
  id: string;
  name: string;
  role: 'Main' | 'Reservations' | 'Accounting' | 'Emergency' | string;
  email?: string;
  phone?: string;
  notes?: string;
  active?: boolean;
}

export interface ContractPolicyRule {
  id: string;
  name: string;
  type: 'Cancellation' | 'Seasonal Supplement' | 'Child Policy' | 'Extra Bed' | 'Blackout Date' | string;
  appliesToService?: string;
  startDate?: string;
  endDate?: string;
  season?: string;
  chargeType: 'Percentage' | 'Fixed Amount' | 'Per Person' | 'Per Night' | string;
  value: number;
  notes?: string;
  status: 'Active' | 'Inactive';
}

export interface SupplierContract {
  id: string;
  title: string;
  status: 'Draft' | 'Active' | 'Expiring' | 'Expired' | 'Suspended';
  startDate: string;
  endDate: string;
  linkedServices?: string[]; // item ids
  paymentTerms?: string;
  commissionNotes?: string;
  policyRules?: ContractPolicyRule[];
}

export interface SupplierDocument {
  id: string;
  name: string;
  type: string;
  uploadedAt: string;
  expiresAt?: string;
  status?: 'Valid' | 'Expiring' | 'Expired';
}

export interface SupplierPayment {
  id: string;
  invoiceRef?: string;
  amount: number;
  currency?: string;
  status: 'Paid' | 'Pending' | 'Overdue';
  date: string;
}

export interface SupplierPerformance {
  responseTimeDays: number;
  responseRatePercent: number;
  confirmationRatePercent: number;
  cancellationIssues: number;
  qualityScore: number; // 0-100
  complaints: number;
}

export interface SupplierEvaluationCriterion {
  id: string;
  area: string;
  weight: number;
  score: number;
  status: 'Pass' | 'Watch' | 'Fail';
  notes?: string;
}

export interface SupplierEvaluationReview {
  id: string;
  date: string;
  reviewer: string;
  overallScore: number;
  status: 'Approved' | 'Watchlist' | 'Rejected' | 'Pending';
  criteria: SupplierEvaluationCriterion[];
  notes?: string;
}

export interface SupplierActivity {
  id: string;
  type: string;
  message: string;
  user?: string;
  date: string;
}

export interface Supplier {
  id: string;
  name: string;
  type: string;
  email?: string;
  phone?: string;
  location?: string;
  destinations?: string[];
  avgResponseTime?: string;
  responseRate?: number;
  totalRequests?: number;
  pendingRequests?: number;
  overdueRequests?: number;
  rating?: number;
  status?: 'Active' | 'Inactive' | 'Onboarding' | 'Suspended';
  contacts?: SupplierContact[];
  contracts?: SupplierContract[];
  documents?: SupplierDocument[];
  payments?: SupplierPayment[];
  performance?: SupplierPerformance;
  evaluations?: SupplierEvaluationReview[];
  activity?: SupplierActivity[];
}

export type ProductServiceStatus = 'Active' | 'Draft' | 'Inactive' | 'Archived' | 'Needs review' | 'Without supplier';

export interface ProductAttribute {
  duration?: string;
  capacity?: string;
  serviceClass?: string;
  roomType?: string;
  vehicleType?: string;
  inclusions: string[];
  exclusions: string[];
  cancellationPolicy: string;
  bookingNotes?: string;
  internalNotes?: string;
}

export interface ProductMedia {
  id: string;
  fileName: string;
  type: 'Main image' | 'Gallery image' | 'Document';
  status: 'Placeholder' | 'Uploaded';
}

export interface ProductDestination {
  country: string;
  city: string;
  destination: string;
  status: 'Active' | 'Inactive';
}

export interface ProductActivity {
  id: string;
  type: string;
  message: string;
  date: string;
  user?: string;
}

export interface ProductSupplierMapping {
  supplierId?: string;
  supplierName?: string;
  status: 'Linked' | 'Unlinked' | 'Needs review';
  lastChecked?: string;
}

export interface ProductCategory {
  id: string;
  name: string;
  type: string;
  status: 'Active' | 'Draft' | 'Inactive' | 'Archived';
  usageCount: number;
}

export interface ProductSeasonalRate {
  id: string;
  seasonName: string;
  startDate: string;
  endDate: string;
  costPrice: number;
  sellingPrice: number;
  currency: string;
  status: 'Active' | 'Inactive';
  notes?: string;
}

export interface ProductCostComponent {
  id: string;
  name: string;
  costType: 'Fixed' | 'Per Person' | 'Per Night' | 'Percentage' | string;
  amount: number;
  currency: string;
  taxable: boolean;
  supplierId?: string;
  notes?: string;
}

export interface ProductCostTemplate {
  id: string;
  name: string;
  categoryId?: string;
  appliesToType: string;
  components: ProductCostComponent[];
  status: 'Active' | 'Draft' | 'Archived';
  lastUpdated: string;
}

export interface ProductPricingRule {
  id: string;
  name: string;
  categoryId?: string;
  destination?: string;
  ruleType: 'Markup %' | 'Fixed Markup' | 'Seasonal Margin' | string;
  value: number;
  minMarginPercent: number;
  startDate?: string;
  endDate?: string;
  priority: number;
  status: 'Active' | 'Inactive';
}

export interface ProductAvailabilityRule {
  id: string;
  itemId: string;
  name: string;
  ruleType: 'Allocation' | 'Blackout' | 'Release Period' | 'On Request' | string;
  startDate: string;
  endDate: string;
  quantity: number;
  releaseDays: number;
  status: 'Open' | 'Limited' | 'Closed';
  supplierId?: string;
  notes?: string;
}

export interface ProductPackageTemplate {
  id: string;
  name: string;
  packageType: string;
  destination: string;
  itemIds: string[];
  basePax: number;
  status: 'Active' | 'Draft' | 'Archived';
  lastUpdated: string;
}

export interface ProductServiceItem {
  id: string;
  name: string;
  description: string;
  categoryId: string;
  category: string;
  categoryType: string;
  type: string;
  destination: string;
  location: string;
  costPrice: number;
  sellingPrice: number;
  price: number;
  priceUnit: string;
  supplierId?: string;
  supplierName?: string;
  status: ProductServiceStatus;
  availability: string;
  linkedBookings: number;
  lastUpdated: string;
  createdAt: string;
  attributes: ProductAttribute;
  media: ProductMedia[];
  destinationCoverage: ProductDestination[];
  supplierMapping: ProductSupplierMapping;
  activity: ProductActivity[];
  notes?: string;
  seasonalRates?: ProductSeasonalRate[];
}
