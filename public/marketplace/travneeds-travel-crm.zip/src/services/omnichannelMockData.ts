import type {
  OmnichannelActivityLogEntry,
  OmnichannelAnalyticsSummary,
  OmnichannelAutomationActivity,
  OmnichannelAutomationRule,
  OmnichannelBroadcastCampaign,
  OmnichannelBusinessHours,
  OmnichannelCaseRecordMock,
  OmnichannelChannel,
  OmnichannelChannelConfiguration,
  OmnichannelDashboardSnapshot,
  OmnichannelInternalNote,
  OmnichannelConversionActivityEvent,
  OmnichannelCustomerRecordMock,
  OmnichannelEscalationStep,
  OmnichannelHoliday,
  OmnichannelLabelDefinition,
  OmnichannelLeadRecordMock,
  OmnichannelMessage,
  OmnichannelQueue,
  OmnichannelReportSchedule,
  OmnichannelRoutingSimulation,
  OmnichannelQuickReplyTemplate,
  OmnichannelRoutingRule,
  OmnichannelSlaPolicy,
  OmnichannelSettingsSnapshot,
  OmnichannelStaffPerformance,
  OmnichannelTag,
  OmnichannelConversation,
  OmnichannelTeamMemberWorkload,
  OmnichannelTicketRecordMock,
} from '../types/omnichannel';

export const mockOmnichannelTags: OmnichannelTag[] = [
  { id: 'tag-egypt-package', label: { en: 'Egypt Package', ar: 'برنامج مصر' }, colorClass: 'bg-blue-50 text-blue-700 border-blue-100', category: 'travel_interest' },
  { id: 'tag-vip', label: { en: 'VIP', ar: 'عميل مميز' }, colorClass: 'bg-purple-50 text-purple-700 border-purple-100', category: 'priority' },
  { id: 'tag-arabic', label: { en: 'Arabic', ar: 'العربية' }, colorClass: 'bg-emerald-50 text-emerald-700 border-emerald-100', category: 'language' },
  { id: 'tag-price-request', label: { en: 'Price Request', ar: 'طلب سعر' }, colorClass: 'bg-amber-50 text-amber-700 border-amber-100', category: 'sales_stage' },
  { id: 'tag-complaint', label: { en: 'Complaint', ar: 'شكوى' }, colorClass: 'bg-rose-50 text-rose-700 border-rose-100', category: 'support' },
  { id: 'tag-auto-reply', label: { en: 'Auto Reply', ar: 'رد تلقائي' }, colorClass: 'bg-gray-50 text-gray-700 border-gray-100', category: 'automation' },
];

export const mockOmnichannelBusinessHours: OmnichannelBusinessHours[] = [
  {
    id: 'bh-sales-weekday',
    name: { en: 'Sales Weekday Hours', ar: 'ساعات مبيعات أيام العمل' },
    timezone: 'Africa/Cairo',
    days: ['sun', 'mon', 'tue', 'wed', 'thu'],
    startTime: '09:00',
    endTime: '18:00',
  },
  {
    id: 'bh-support-extended',
    name: { en: 'Support Extended Hours', ar: 'ساعات الدعم الممتدة' },
    timezone: 'Africa/Cairo',
    days: ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'],
    startTime: '08:00',
    endTime: '22:00',
  },
];

export const mockOmnichannelQueues: OmnichannelQueue[] = [
  { id: 'queue-sales', name: { en: 'Sales Queue', ar: 'قائمة المبيعات' }, department: 'Sales', ownerId: 'USR-002', openCount: 6, pendingCount: 3, breachedCount: 1, averageFirstResponseMinutes: 14 },
  { id: 'queue-reservations', name: { en: 'Reservations Queue', ar: 'قائمة الحجوزات' }, department: 'Reservations', ownerId: 'USR-003', openCount: 3, pendingCount: 2, breachedCount: 0, averageFirstResponseMinutes: 19 },
  { id: 'queue-support', name: { en: 'Support Queue', ar: 'قائمة الدعم' }, department: 'Support', ownerId: 'USR-001', openCount: 4, pendingCount: 5, breachedCount: 2, averageFirstResponseMinutes: 27 },
  { id: 'queue-unassigned', name: { en: 'Unassigned Queue', ar: 'قائمة غير معينة' }, department: 'Management', ownerId: 'USR-001', openCount: 5, pendingCount: 1, breachedCount: 1, averageFirstResponseMinutes: 32 },
];

export const mockOmnichannelChannels: OmnichannelChannel[] = [
  {
    id: 'CH-WA-001',
    type: 'whatsapp',
    name: 'WhatsApp Sales Line',
    provider: 'WhatsApp Mock',
    accountLabel: '+20 100 555 0101',
    owner: { id: 'USR-002', name: 'Mahmoud Khalil', department: 'Sales', email: 'mahmoud@travneeds.com' },
    settings: { businessHoursId: 'bh-sales-weekday', defaultQueueId: 'queue-sales', autoReplyEnabled: true, templatesEnabled: true, attachmentsEnabled: true, maxAttachmentSizeMb: 10, inboundSyncEnabled: true, outboundMockEnabled: true },
    health: { status: 'healthy', connectionStatus: 'connected', syncStatus: 'realtime', lastSyncAt: '2026-06-27T09:54:00+03:00', lastInboundAt: '2026-06-27T09:53:00+03:00', webhookStatus: 'ok', openConversations: 4, failedEventsToday: 0, healthScore: 98, notes: 'Mock realtime feed is healthy.' },
    isFuture: false,
  },
  {
    id: 'CH-WABA-001',
    type: 'whatsapp_business',
    name: 'WhatsApp Business API',
    provider: 'Meta Business Mock',
    accountLabel: 'WABA-TRAVNEEDS-01',
    owner: { id: 'USR-001', name: 'Super Admin', department: 'Management', email: 'admin@travneeds.com' },
    settings: { businessHoursId: 'bh-sales-weekday', defaultQueueId: 'queue-sales', autoReplyEnabled: true, templatesEnabled: true, attachmentsEnabled: true, maxAttachmentSizeMb: 16, inboundSyncEnabled: true, outboundMockEnabled: true },
    health: { status: 'healthy', connectionStatus: 'connected', syncStatus: 'synced', lastSyncAt: '2026-06-27T09:50:00+03:00', lastInboundAt: '2026-06-27T09:48:00+03:00', webhookStatus: 'ok', openConversations: 5, failedEventsToday: 0, healthScore: 96, notes: 'Template approval sync is mocked.' },
    isFuture: false,
  },
  {
    id: 'CH-FB-001',
    type: 'facebook_messenger',
    name: 'Facebook Messenger',
    provider: 'Meta Page Mock',
    accountLabel: 'Nile Travel Page',
    owner: { id: 'USR-004', name: 'Nadia Samir', department: 'Marketing', email: 'nadia@travneeds.com' },
    settings: { businessHoursId: 'bh-sales-weekday', defaultQueueId: 'queue-sales', autoReplyEnabled: true, templatesEnabled: false, attachmentsEnabled: true, maxAttachmentSizeMb: 8, inboundSyncEnabled: true, outboundMockEnabled: true },
    health: { status: 'degraded', connectionStatus: 'sync_warning', syncStatus: 'delayed', lastSyncAt: '2026-06-27T08:40:00+03:00', lastInboundAt: '2026-06-27T08:35:00+03:00', webhookStatus: 'warning', openConversations: 3, failedEventsToday: 2, healthScore: 74, notes: 'Mock webhook delay on page comments.' },
    isFuture: false,
  },
  {
    id: 'CH-IGDM-001',
    type: 'instagram_dm',
    name: 'Instagram DMs',
    provider: 'Instagram Mock',
    accountLabel: '@travneeds',
    owner: { id: 'USR-004', name: 'Nadia Samir', department: 'Marketing', email: 'nadia@travneeds.com' },
    settings: { businessHoursId: 'bh-sales-weekday', defaultQueueId: 'queue-sales', autoReplyEnabled: true, templatesEnabled: false, attachmentsEnabled: true, maxAttachmentSizeMb: 8, inboundSyncEnabled: true, outboundMockEnabled: true },
    health: { status: 'healthy', connectionStatus: 'connected', syncStatus: 'synced', lastSyncAt: '2026-06-27T09:42:00+03:00', lastInboundAt: '2026-06-27T09:30:00+03:00', webhookStatus: 'ok', openConversations: 2, failedEventsToday: 0, healthScore: 91, notes: 'DM sync mock is active.' },
    isFuture: false,
  },
  {
    id: 'CH-IGC-001',
    type: 'instagram_comment',
    name: 'Instagram Comments',
    provider: 'Instagram Mock',
    accountLabel: '@travneeds comments',
    owner: { id: 'USR-004', name: 'Nadia Samir', department: 'Marketing', email: 'nadia@travneeds.com' },
    settings: { businessHoursId: 'bh-support-extended', defaultQueueId: 'queue-support', autoReplyEnabled: false, templatesEnabled: false, attachmentsEnabled: false, maxAttachmentSizeMb: 0, inboundSyncEnabled: true, outboundMockEnabled: true },
    health: { status: 'critical', connectionStatus: 'sync_warning', syncStatus: 'failed', lastSyncAt: '2026-06-27T06:15:00+03:00', lastInboundAt: '2026-06-27T06:12:00+03:00', webhookStatus: 'failed', openConversations: 6, failedEventsToday: 7, healthScore: 42, notes: 'Comment sync failure is intentionally mocked.' },
    isFuture: false,
  },
  {
    id: 'CH-WEB-001',
    type: 'website_chat',
    name: 'Website Live Chat',
    provider: 'Travneeds Widget Mock',
    accountLabel: 'widget-main',
    owner: { id: 'USR-003', name: 'Layla Ramadan', department: 'Reservations', email: 'layla@travneeds.com' },
    settings: { businessHoursId: 'bh-support-extended', defaultQueueId: 'queue-unassigned', autoReplyEnabled: true, templatesEnabled: true, attachmentsEnabled: true, maxAttachmentSizeMb: 5, inboundSyncEnabled: true, outboundMockEnabled: true },
    health: { status: 'healthy', connectionStatus: 'connected', syncStatus: 'realtime', lastSyncAt: '2026-06-27T09:55:00+03:00', lastInboundAt: '2026-06-27T09:55:00+03:00', webhookStatus: 'ok', openConversations: 2, failedEventsToday: 0, healthScore: 94, notes: 'Website chat widget is mock connected.' },
    isFuture: false,
  },
  {
    id: 'CH-EMAIL-001',
    type: 'email',
    name: 'Support Email',
    provider: 'Mailbox Mock',
    accountLabel: 'support@travneeds.com',
    owner: { id: 'USR-001', name: 'Super Admin', department: 'Support', email: 'admin@travneeds.com' },
    settings: { businessHoursId: 'bh-support-extended', defaultQueueId: 'queue-support', autoReplyEnabled: true, templatesEnabled: true, attachmentsEnabled: true, maxAttachmentSizeMb: 25, inboundSyncEnabled: false, outboundMockEnabled: true },
    health: { status: 'offline', connectionStatus: 'disconnected', syncStatus: 'not_configured', webhookStatus: 'not_configured', openConversations: 1, failedEventsToday: 0, healthScore: 20, notes: 'Mailbox remains disconnected in mock data.' },
    isFuture: false,
  },
  {
    id: 'CH-SMS-001',
    type: 'sms',
    name: 'SMS Gateway',
    provider: 'SMS Provider Mock',
    accountLabel: 'Pending sender ID',
    owner: { id: 'USR-001', name: 'Super Admin', department: 'Management', email: 'admin@travneeds.com' },
    settings: { businessHoursId: 'bh-support-extended', defaultQueueId: 'queue-support', autoReplyEnabled: false, templatesEnabled: true, attachmentsEnabled: false, maxAttachmentSizeMb: 0, inboundSyncEnabled: false, outboundMockEnabled: false },
    health: { status: 'degraded', connectionStatus: 'pending_setup', syncStatus: 'not_configured', webhookStatus: 'not_configured', openConversations: 0, failedEventsToday: 0, healthScore: 55, notes: 'Sender setup is pending.' },
    isFuture: false,
  },
  {
    id: 'CH-PHONE-001',
    type: 'phone',
    name: 'Phone / Call Logs',
    provider: 'VoIP Logs Mock',
    accountLabel: 'Travneeds PBX',
    owner: { id: 'USR-003', name: 'Layla Ramadan', department: 'Reservations', email: 'layla@travneeds.com' },
    settings: { businessHoursId: 'bh-support-extended', defaultQueueId: 'queue-reservations', autoReplyEnabled: false, templatesEnabled: false, attachmentsEnabled: false, maxAttachmentSizeMb: 0, inboundSyncEnabled: true, outboundMockEnabled: false },
    health: { status: 'healthy', connectionStatus: 'connected', syncStatus: 'synced', lastSyncAt: '2026-06-27T09:25:00+03:00', lastInboundAt: '2026-06-27T09:20:00+03:00', webhookStatus: 'ok', openConversations: 2, failedEventsToday: 0, healthScore: 89, notes: 'Call logs are imported as mock conversations.' },
    isFuture: false,
  },
  {
    id: 'CH-FUTURE-001',
    type: 'future',
    name: 'Future Channel Placeholder',
    provider: 'Future Integration',
    accountLabel: 'Not scheduled',
    owner: { id: 'USR-001', name: 'Super Admin', department: 'Management', email: 'admin@travneeds.com' },
    settings: { businessHoursId: 'bh-sales-weekday', defaultQueueId: 'queue-unassigned', autoReplyEnabled: false, templatesEnabled: false, attachmentsEnabled: false, maxAttachmentSizeMb: 0, inboundSyncEnabled: false, outboundMockEnabled: false },
    health: { status: 'planned', connectionStatus: 'planned', syncStatus: 'planned', webhookStatus: 'planned', openConversations: 0, failedEventsToday: 0, healthScore: 0, notes: 'Reserved for future channels.' },
    isFuture: true,
  },
];

export const mockOmnichannelConversations: OmnichannelConversation[] = [
  {
    id: 'CONV-2026-001',
    channelId: 'CH-WA-001',
    channelType: 'whatsapp',
    subject: 'Cairo package price request',
    customer: { id: 'CUST-001', name: 'Ahmed Hassan', role: 'customer', phone: '+20 111 222 3333', email: 'ahmed.h@gmail.com', preferredLanguage: 'ar' },
    status: 'open',
    priority: 'high',
    queueId: 'queue-sales',
    unreadCount: 2,
    tagIds: ['tag-egypt-package', 'tag-price-request', 'tag-arabic'],
    linkedRecords: [
      { type: 'customer', id: 'CUST-001', label: 'Ahmed Hassan', href: '/customers', status: 'Gold', ownerName: 'Layla Ramadan', createdAt: '2026-05-11T10:00:00+03:00', stage: 'Gold' },
      { type: 'quotation', id: 'Q-2026-001', label: 'Cairo Package Quote', href: '/sales/cases/CASE-2025-001/quotations/Q-2026-001/preview', status: 'Draft', ownerName: 'Mahmoud Khalil', createdAt: '2026-06-27T08:32:00+03:00' },
      { type: 'sales_case', id: 'CASE-2025-001', label: 'Ahmed Hassan Package', href: '/sales/cases/CASE-2025-001', status: 'Quotation Sent', ownerName: 'Mahmoud Khalil', createdAt: '2026-06-20T10:20:00+03:00', stage: 'Leisure Package', teamName: 'Sales' },
    ],
    sla: { status: 'at_risk', firstResponseDueAt: '2026-06-27T10:05:00+03:00', resolutionDueAt: '2026-06-30T09:50:00+03:00', firstResponseRemainingMinutes: 10, resolutionRemainingMinutes: 4320 },
    lastMessagePreview: 'Can I get the final price for 2 adults?',
    lastMessageAt: '2026-06-27T09:55:00+03:00',
    createdAt: '2026-06-27T08:15:00+03:00',
  },
  {
    id: 'CONV-2026-002',
    channelId: 'CH-WABA-001',
    channelType: 'whatsapp_business',
    subject: 'Corporate retreat inquiry',
    customer: { id: 'LD-2025-003', name: 'Business Solutions Co', role: 'lead', phone: '+20 2 2345 6789', email: 'info@bizsol.com', preferredLanguage: 'en' },
    status: 'pending',
    priority: 'urgent',
    queueId: 'queue-sales',
    assignedStaffId: 'USR-002',
    assignedStaffName: 'Mahmoud Khalil',
    unreadCount: 0,
    tagIds: ['tag-vip'],
    linkedRecords: [
      { type: 'lead', id: 'LD-2025-003', label: 'Business Solutions Co', href: '/leads', status: 'Qualified', ownerName: 'Mahmoud Khalil', createdAt: '2026-06-26T16:05:00+03:00', stage: 'Qualified' },
      { type: 'sales_case', id: 'CASE-2025-003', label: 'Corporate Retreat', href: '/sales/cases/CASE-2025-003', status: 'New', ownerName: 'Mahmoud Khalil', createdAt: '2026-06-26T16:15:00+03:00', stage: 'Corporate Group', teamName: 'Sales' },
    ],
    sla: { status: 'ok', firstResponseRemainingMinutes: 0, resolutionDueAt: '2026-06-29T15:00:00+03:00', resolutionRemainingMinutes: 3180 },
    lastMessagePreview: 'Please send options for 45 employees.',
    lastMessageAt: '2026-06-27T08:45:00+03:00',
    createdAt: '2026-06-26T16:00:00+03:00',
  },
  {
    id: 'CONV-2026-003',
    channelId: 'CH-EMAIL-001',
    channelType: 'email',
    subject: 'Invoice discrepancy',
    customer: { id: 'CUST-002', name: 'Corporate Travel Inc', role: 'customer', phone: '+20 2 9876 5432', email: 'logistics@corptravel.com', preferredLanguage: 'en' },
    status: 'escalated',
    priority: 'urgent',
    queueId: 'queue-support',
    assignedStaffId: 'USR-001',
    assignedStaffName: 'Super Admin',
    unreadCount: 1,
    tagIds: ['tag-complaint'],
    linkedRecords: [
      { type: 'customer', id: 'CUST-002', label: 'Corporate Travel Inc', href: '/customers', status: 'Corporate', ownerName: 'Super Admin', createdAt: '2026-04-02T09:30:00+03:00', stage: 'Corporate' },
      { type: 'reservation', id: 'BK-2025-013', label: 'Group flight booking', href: '/reservations', status: 'Confirmed', ownerName: 'Layla Ramadan', createdAt: '2026-06-15T12:45:00+03:00', teamName: 'Reservations' },
      { type: 'support_ticket', id: 'TKT-002', label: 'Invoice Discrepancy', href: '/help-center/tickets', status: 'Escalated', ownerName: 'Super Admin', createdAt: '2026-06-27T07:30:00+03:00', priority: 'urgent', teamName: 'Support' },
    ],
    sla: { status: 'breached', firstResponseRemainingMinutes: 0, resolutionRemainingMinutes: -95, breachedAt: '2026-06-27T08:20:00+03:00' },
    lastMessagePreview: 'The invoice total does not match the quotation.',
    lastMessageAt: '2026-06-27T07:20:00+03:00',
    createdAt: '2026-06-26T11:00:00+03:00',
  },
  {
    id: 'CONV-2026-004',
    channelId: 'CH-IGDM-001',
    channelType: 'instagram_dm',
    subject: 'Honeymoon package inquiry',
    customer: { id: 'LD-2025-001', name: 'Sarah Ahmed', role: 'lead', phone: '+20 100 123 4567', email: 'sarah.ahmed@example.com', preferredLanguage: 'en' },
    status: 'waiting_customer',
    priority: 'normal',
    queueId: 'queue-sales',
    assignedStaffId: 'USR-003',
    assignedStaffName: 'Layla Ramadan',
    unreadCount: 0,
    tagIds: ['tag-egypt-package'],
    linkedRecords: [{ type: 'lead', id: 'LD-2025-001', label: 'Sarah Ahmed', href: '/leads', status: 'New', ownerName: 'Layla Ramadan', createdAt: '2026-06-26T18:25:00+03:00', stage: 'New' }],
    sla: { status: 'paused', firstResponseRemainingMinutes: 0, resolutionRemainingMinutes: 3880 },
    lastMessagePreview: 'Thanks, I will confirm the dates tonight.',
    lastMessageAt: '2026-06-26T21:10:00+03:00',
    createdAt: '2026-06-26T18:22:00+03:00',
  },
  {
    id: 'CONV-2026-005',
    channelId: 'CH-WEB-001',
    channelType: 'website_chat',
    subject: 'Aswan hotel availability',
    customer: { id: 'GUEST-001', name: 'Mona Adel', role: 'lead', phone: '+20 122 000 4444', preferredLanguage: 'ar' },
    status: 'open',
    priority: 'normal',
    queueId: 'queue-unassigned',
    unreadCount: 3,
    tagIds: ['tag-arabic'],
    linkedRecords: [],
    sla: { status: 'at_risk', firstResponseDueAt: '2026-06-27T10:00:00+03:00', firstResponseRemainingMinutes: 5, resolutionRemainingMinutes: 4310 },
    lastMessagePreview: 'هل يوجد فندق متاح في أسوان؟',
    lastMessageAt: '2026-06-27T09:55:00+03:00',
    createdAt: '2026-06-27T09:40:00+03:00',
  },
  {
    id: 'CONV-2026-006',
    channelId: 'CH-PHONE-001',
    channelType: 'phone',
    subject: 'Call log: Nile view room confirmation',
    customer: { id: 'CUST-001', name: 'Ahmed Hassan', role: 'customer', phone: '+20 111 222 3333', email: 'ahmed.h@gmail.com', preferredLanguage: 'ar' },
    status: 'closed',
    priority: 'low',
    queueId: 'queue-reservations',
    assignedStaffId: 'USR-003',
    assignedStaffName: 'Layla Ramadan',
    unreadCount: 0,
    tagIds: ['tag-egypt-package'],
    linkedRecords: [
      { type: 'reservation', id: 'BK-2025-001', label: 'Steigenberger Luxor', href: '/reservations', status: 'Pending', ownerName: 'Layla Ramadan', createdAt: '2026-06-24T11:15:00+03:00', teamName: 'Reservations' },
      { type: 'support_ticket', id: 'TKT-001', label: 'Room view inquiry', href: '/help-center/tickets', status: 'Open', ownerName: 'Layla Ramadan', createdAt: '2026-06-26T13:18:00+03:00', priority: 'normal', teamName: 'Reservations' },
    ],
    sla: { status: 'none', firstResponseRemainingMinutes: 0, resolutionRemainingMinutes: 0 },
    lastMessagePreview: 'Call completed and notes attached.',
    lastMessageAt: '2026-06-26T13:15:00+03:00',
    createdAt: '2026-06-26T13:00:00+03:00',
  },
];

export const mockOmnichannelMessages: OmnichannelMessage[] = [
  { id: 'MSG-001', conversationId: 'CONV-2026-001', direction: 'inbound', kind: 'text', authorName: 'Ahmed Hassan', body: 'Hi, can I get the price for a 5-day Cairo package for 2 adults?', createdAt: '2026-06-27T08:15:00+03:00', attachments: [] },
  { id: 'MSG-002', conversationId: 'CONV-2026-001', direction: 'outbound', kind: 'template', authorName: 'Travneeds Sales', body: 'Thanks for reaching Travneeds. Please confirm your travel dates.', createdAt: '2026-06-27T08:20:00+03:00', deliveryStatus: 'read', templateId: 'TPL-001', attachments: [] },
  { id: 'MSG-003', conversationId: 'CONV-2026-003', direction: 'inbound', kind: 'attachment', authorName: 'Corporate Travel Inc', body: 'Please review the attached invoice copy.', createdAt: '2026-06-27T07:20:00+03:00', attachments: [{ id: 'ATT-001', fileName: 'invoice-mismatch.pdf', fileType: 'pdf', sizeKb: 420, mockUrlLabel: 'Mock invoice PDF' }] },
  { id: 'MSG-004', conversationId: 'CONV-2026-006', direction: 'system', kind: 'call_log', authorName: 'Phone Logs', body: 'Inbound call lasted 6 minutes. Customer asked about Nile view confirmation.', createdAt: '2026-06-26T13:15:00+03:00', attachments: [] },
  { id: 'MSG-005', conversationId: 'CONV-2026-002', direction: 'inbound', kind: 'text', authorName: 'Business Solutions Co', body: 'Please send options for 45 employees with meeting space.', createdAt: '2026-06-27T08:45:00+03:00', attachments: [] },
  { id: 'MSG-006', conversationId: 'CONV-2026-004', direction: 'outbound', kind: 'text', authorName: 'Layla Ramadan', body: 'I can prepare a honeymoon package once dates are confirmed.', createdAt: '2026-06-26T19:05:00+03:00', deliveryStatus: 'delivered', attachments: [] },
  { id: 'MSG-007', conversationId: 'CONV-2026-005', direction: 'inbound', kind: 'text', authorName: 'Mona Adel', body: 'هل يوجد فندق متاح في أسوان؟', createdAt: '2026-06-27T09:55:00+03:00', attachments: [] },
];

export const mockOmnichannelInternalNotes: OmnichannelInternalNote[] = [
  { id: 'NOTE-001', conversationId: 'CONV-2026-001', authorId: 'USR-002', authorName: 'Mahmoud Khalil', body: 'High intent. Link to Cairo package quotation once dates are confirmed.', createdAt: '2026-06-27T08:30:00+03:00', visibility: 'internal' },
  { id: 'NOTE-002', conversationId: 'CONV-2026-003', authorId: 'USR-001', authorName: 'Super Admin', body: 'Escalated to Finance mock flow. Keep customer updated every 2 hours.', createdAt: '2026-06-27T08:25:00+03:00', visibility: 'internal' },
];

export const mockOmnichannelTemplates: OmnichannelQuickReplyTemplate[] = [
  {
    id: 'TPL-001',
    category: 'sales',
    channelTypes: ['whatsapp', 'whatsapp_business', 'website_chat'],
    title: { en: 'Travel Dates Request', ar: 'طلب تواريخ السفر' },
    body: { en: 'Thanks for contacting Travneeds. Could you please confirm your preferred travel dates and number of travelers?', ar: 'شكرا لتواصلك مع Travneeds. من فضلك أكد تواريخ السفر وعدد المسافرين.' },
    language: 'en',
    approvalStatus: 'approved',
    variables: [{ key: 'customer_name', label: { en: 'Customer Name', ar: 'اسم العميل' }, exampleValue: 'Ahmed Hassan', required: true }],
    usageCount: 48,
  },
  {
    id: 'TPL-002',
    category: 'support',
    channelTypes: ['email', 'website_chat', 'facebook_messenger'],
    title: { en: 'Ticket Received', ar: 'تم استلام التذكرة' },
    body: { en: 'We received your request and our team is reviewing it. Your reference is {{ticket_id}}.', ar: 'تم استلام طلبك ويقوم فريقنا بمراجعته. رقم المرجع هو {{ticket_id}}.' },
    language: 'ar',
    approvalStatus: 'approved',
    variables: [{ key: 'ticket_id', label: { en: 'Ticket ID', ar: 'رقم التذكرة' }, exampleValue: 'TKT-002', required: true }],
    usageCount: 31,
  },
  {
    id: 'TPL-003',
    category: 'reservation',
    channelTypes: ['sms', 'phone', 'whatsapp_business'],
    title: { en: 'Booking Confirmation Follow-up', ar: 'متابعة تأكيد الحجز' },
    body: { en: 'Your booking {{booking_id}} is being confirmed with the supplier. We will update you shortly.', ar: 'جاري تأكيد حجزك {{booking_id}} مع المورد وسنوافيك بالتحديث قريبا.' },
    language: 'en',
    approvalStatus: 'pending_review',
    variables: [{ key: 'booking_id', label: { en: 'Booking ID', ar: 'رقم الحجز' }, exampleValue: 'BK-2025-001', required: true }],
    usageCount: 12,
  },
];

export const mockOmnichannelRoutingRules: OmnichannelRoutingRule[] = [
  { id: 'RULE-001', name: { en: 'VIP to Sales Manager', ar: 'العملاء المميزون إلى مدير المبيعات' }, status: 'active', priority: 1, conditions: [{ field: 'tagId', operator: 'includes', value: 'tag-vip' }], targetQueueId: 'queue-sales', assignToStaffId: 'USR-002', autoTagIds: [] },
  { id: 'RULE-002', name: { en: 'Complaints to Support', ar: 'الشكاوى إلى الدعم' }, status: 'active', priority: 2, conditions: [{ field: 'tagId', operator: 'includes', value: 'tag-complaint' }], targetQueueId: 'queue-support', autoTagIds: ['tag-auto-reply'] },
  { id: 'RULE-003', name: { en: 'Unassigned Web Chat', ar: 'محادثات الموقع غير المعينة' }, status: 'active', priority: 3, conditions: [{ field: 'channelType', operator: 'equals', value: 'website_chat' }, { field: 'unassigned', operator: 'is', value: 'true' }], targetQueueId: 'queue-unassigned', autoTagIds: [] },
];

export const mockOmnichannelSlaPolicies: OmnichannelSlaPolicy[] = [
  { id: 'SLA-001', name: { en: 'High Priority Sales', ar: 'مبيعات أولوية عالية' }, queueId: 'queue-sales', priority: 'high', firstResponseMinutes: 15, resolutionMinutes: 4320, businessHoursId: 'bh-sales-weekday', escalationQueueId: 'queue-unassigned', status: 'active' },
  { id: 'SLA-002', name: { en: 'Urgent Support', ar: 'دعم عاجل' }, queueId: 'queue-support', priority: 'urgent', firstResponseMinutes: 10, resolutionMinutes: 240, businessHoursId: 'bh-support-extended', escalationQueueId: 'queue-unassigned', status: 'active' },
  { id: 'SLA-003', name: { en: 'Normal Reservations', ar: 'حجوزات عادية' }, queueId: 'queue-reservations', priority: 'normal', firstResponseMinutes: 30, resolutionMinutes: 2880, businessHoursId: 'bh-support-extended', status: 'active' },
];

export const mockOmnichannelStaffPerformance: OmnichannelStaffPerformance[] = [
  { staffId: 'USR-002', staffName: 'Mahmoud Khalil', department: 'Sales', assignedCount: 9, openCount: 4, closedToday: 5, averageFirstResponseMinutes: 12, slaBreaches: 1, convertedLeads: 3, linkedBookings: 1, customerSatisfactionScore: 92 },
  { staffId: 'USR-003', staffName: 'Layla Ramadan', department: 'Reservations', assignedCount: 7, openCount: 3, closedToday: 4, averageFirstResponseMinutes: 18, slaBreaches: 0, convertedLeads: 1, linkedBookings: 3, customerSatisfactionScore: 95 },
  { staffId: 'USR-001', staffName: 'Super Admin', department: 'Management', assignedCount: 5, openCount: 2, closedToday: 2, averageFirstResponseMinutes: 24, slaBreaches: 2, convertedLeads: 0, linkedBookings: 1, customerSatisfactionScore: 86 },
];

export const mockOmnichannelAssignableStaff = [
  { id: 'USR-001', name: 'Super Admin', department: 'Management' },
  { id: 'USR-002', name: 'Mahmoud Khalil', department: 'Sales' },
  { id: 'USR-003', name: 'Layla Ramadan', department: 'Reservations' },
  { id: 'USR-004', name: 'Nadia Samir', department: 'Marketing' },
] as const;

export const mockOmnichannelLeadRecords: OmnichannelLeadRecordMock[] = [
  { id: 'LD-2025-001', name: 'Sarah Ahmed', phone: '+20 100 123 4567', email: 'sarah.ahmed@example.com', source: 'Instagram DMs', stage: 'New', ownerId: 'USR-003', ownerName: 'Layla Ramadan', createdAt: '2026-06-26T18:25:00+03:00' },
  { id: 'LD-2025-003', name: 'Business Solutions Co', phone: '+20 2 2345 6789', email: 'info@bizsol.com', companyName: 'Business Solutions Co', source: 'WhatsApp Business/API', stage: 'Qualified', ownerId: 'USR-002', ownerName: 'Mahmoud Khalil', createdAt: '2026-06-26T16:05:00+03:00' },
  { id: 'LD-2025-009', name: 'Mona Adel', phone: '+20 122 000 4444', source: 'Website Live Chat', stage: 'Contacted', ownerId: 'USR-001', ownerName: 'Super Admin', createdAt: '2026-06-25T14:20:00+03:00' },
];

export const mockOmnichannelCustomerRecords: OmnichannelCustomerRecordMock[] = [
  { id: 'CUST-001', name: 'Ahmed Hassan', phone: '+20 111 222 3333', email: 'ahmed.h@gmail.com', tier: 'Gold', ownerId: 'USR-003', ownerName: 'Layla Ramadan', createdAt: '2026-05-11T10:00:00+03:00' },
  { id: 'CUST-002', name: 'Corporate Travel Inc', phone: '+20 2 9876 5432', email: 'logistics@corptravel.com', companyName: 'Corporate Travel Inc', tier: 'Corporate', ownerId: 'USR-001', ownerName: 'Super Admin', createdAt: '2026-04-02T09:30:00+03:00' },
  { id: 'CUST-014', name: 'Al Noor Holdings', phone: '+20 100 888 1020', email: 'travel@alnoor.com', companyName: 'Al Noor Holdings', tier: 'Enterprise', ownerId: 'USR-002', ownerName: 'Mahmoud Khalil', createdAt: '2026-06-01T13:15:00+03:00' },
];

export const mockOmnichannelTicketRecords: OmnichannelTicketRecordMock[] = [
  { id: 'TKT-001', subject: 'Room view inquiry', customerName: 'Ahmed Hassan', priority: 'normal', category: 'Reservation Support', status: 'Open', ownerId: 'USR-003', ownerName: 'Layla Ramadan', teamName: 'Reservations', createdAt: '2026-06-26T13:18:00+03:00' },
  { id: 'TKT-002', subject: 'Invoice discrepancy', customerName: 'Corporate Travel Inc', priority: 'urgent', category: 'Billing', status: 'Escalated', ownerId: 'USR-001', ownerName: 'Super Admin', teamName: 'Support', createdAt: '2026-06-27T07:30:00+03:00' },
  { id: 'TKT-014', subject: 'Group transport follow-up', customerName: 'Business Solutions Co', priority: 'high', category: 'Operations', status: 'Pending', ownerId: 'USR-002', ownerName: 'Mahmoud Khalil', teamName: 'Support', createdAt: '2026-06-24T12:00:00+03:00' },
];

export const mockOmnichannelCaseRecords: OmnichannelCaseRecordMock[] = [
  { id: 'CASE-2025-001', subject: 'Ahmed Hassan Package', customerName: 'Ahmed Hassan', caseType: 'Leisure Package', status: 'Quotation Sent', ownerId: 'USR-002', ownerName: 'Mahmoud Khalil', teamName: 'Sales', createdAt: '2026-06-20T10:20:00+03:00' },
  { id: 'CASE-2025-003', subject: 'Corporate Retreat', customerName: 'Business Solutions Co', caseType: 'Corporate Group', status: 'New', ownerId: 'USR-002', ownerName: 'Mahmoud Khalil', teamName: 'Sales', createdAt: '2026-06-26T16:15:00+03:00' },
  { id: 'CASE-2025-007', subject: 'Aswan Weekend Inquiry', customerName: 'Mona Adel', caseType: 'Domestic Hotel Stay', status: 'Draft', ownerId: 'USR-003', ownerName: 'Layla Ramadan', teamName: 'Reservations', createdAt: '2026-06-23T11:40:00+03:00' },
];

export const mockOmnichannelConversionActivities: OmnichannelConversionActivityEvent[] = [
  { id: 'ACT-001', conversationId: 'CONV-2026-001', type: 'record_linked', recordType: 'quotation', recordId: 'Q-2026-001', recordLabel: 'Cairo Package Quote', actorName: 'Mahmoud Khalil', createdAt: '2026-06-27T08:32:00+03:00', note: 'Quotation draft linked for sales follow-up.' },
  { id: 'ACT-002', conversationId: 'CONV-2026-003', type: 'ticket_created', recordType: 'support_ticket', recordId: 'TKT-002', recordLabel: 'Invoice Discrepancy', actorName: 'Super Admin', createdAt: '2026-06-27T07:31:00+03:00', note: 'Billing issue routed to Support.' },
  { id: 'ACT-003', conversationId: 'CONV-2026-004', type: 'converted_to_lead', recordType: 'lead', recordId: 'LD-2025-001', recordLabel: 'Sarah Ahmed', actorName: 'Layla Ramadan', createdAt: '2026-06-26T18:28:00+03:00', note: 'Lead created from Instagram inquiry.' },
];

export const mockOmnichannelDashboardSnapshot: OmnichannelDashboardSnapshot = {
  metrics: [
    { id: 'total-conversations', label: { en: 'Total conversations', ar: 'إجمالي المحادثات' }, value: '72', trend: '+12%', trendType: 'up' },
    { id: 'open-conversations', label: { en: 'Open conversations', ar: 'المحادثات المفتوحة' }, value: '18', trend: '+4%', trendType: 'up' },
    { id: 'waiting-customer', label: { en: 'Waiting customer', ar: 'بانتظار العميل' }, value: '9', trend: '-2%', trendType: 'down' },
    { id: 'waiting-agent', label: { en: 'Waiting agent', ar: 'بانتظار الموظف' }, value: '6', trend: '+1%', trendType: 'up' },
    { id: 'sla-breached', label: { en: 'SLA breached', ar: 'اختراقات الخدمة' }, value: '4', trend: '-1%', trendType: 'down' },
    { id: 'first-response', label: { en: 'Avg first response', ar: 'متوسط أول رد' }, value: '18m', trend: '-6%', trendType: 'down' },
    { id: 'resolution-time', label: { en: 'Avg resolution', ar: 'متوسط الحل' }, value: '6.4h', trend: '-3%', trendType: 'down' },
    { id: 'csat', label: { en: 'Customer satisfaction', ar: 'رضا العملاء' }, value: '91%', trend: '+2%', trendType: 'up' },
    { id: 'channel-health', label: { en: 'Channel health', ar: 'صحة القنوات' }, value: '84', trend: '+5%', trendType: 'up' },
  ],
  queueOverview: [
    { queueId: 'queue-sales', queueName: { en: 'Sales Queue', ar: 'قائمة المبيعات' }, openCount: 6, waitingCustomerCount: 2, waitingAgentCount: 1, breachedCount: 1, assignedTeam: 'Sales' },
    { queueId: 'queue-support', queueName: { en: 'Support Queue', ar: 'قائمة الدعم' }, openCount: 4, waitingCustomerCount: 1, waitingAgentCount: 2, breachedCount: 2, assignedTeam: 'Support' },
    { queueId: 'queue-reservations', queueName: { en: 'Reservations Queue', ar: 'قائمة الحجوزات' }, openCount: 3, waitingCustomerCount: 1, waitingAgentCount: 1, breachedCount: 0, assignedTeam: 'Reservations' },
  ],
  channelVolume: [
    { channelType: 'whatsapp', conversations: 18, replies: 52, conversionCount: 4 },
    { channelType: 'whatsapp_business', conversations: 13, replies: 31, conversionCount: 3 },
    { channelType: 'website_chat', conversations: 10, replies: 28, conversionCount: 2 },
    { channelType: 'email', conversations: 5, replies: 11, conversionCount: 1 },
  ],
  agentSnapshots: [
    { staffId: 'USR-002', staffName: 'Mahmoud Khalil', teamName: 'Sales', onlineStatus: 'online', assignedConversations: 9, activeTickets: 2, averageResponseMinutes: 12, satisfactionScore: 92, workloadPercent: 78 },
    { staffId: 'USR-003', staffName: 'Layla Ramadan', teamName: 'Reservations', onlineStatus: 'busy', assignedConversations: 7, activeTickets: 3, averageResponseMinutes: 18, satisfactionScore: 95, workloadPercent: 84 },
    { staffId: 'USR-001', staffName: 'Super Admin', teamName: 'Support', onlineStatus: 'online', assignedConversations: 5, activeTickets: 4, averageResponseMinutes: 24, satisfactionScore: 86, workloadPercent: 66 },
  ],
  slaRisks: [
    { conversationId: 'CONV-2026-001', customerName: 'Ahmed Hassan', channelType: 'whatsapp', riskLevel: 'high', remainingMinutes: 10, assignedStaffName: 'Mahmoud Khalil' },
    { conversationId: 'CONV-2026-005', customerName: 'Mona Adel', channelType: 'website_chat', riskLevel: 'high', remainingMinutes: 5 },
    { conversationId: 'CONV-2026-003', customerName: 'Corporate Travel Inc', channelType: 'email', riskLevel: 'high', remainingMinutes: -95, assignedStaffName: 'Super Admin' },
  ],
  escalations: [
    { id: 'ESC-001', conversationId: 'CONV-2026-003', title: 'Invoice discrepancy escalation', severity: 'critical', channelType: 'email', ownerName: 'Super Admin', createdAt: '2026-06-27T08:20:00+03:00' },
    { id: 'ESC-002', conversationId: 'CONV-2026-005', title: 'Live chat waiting without agent', severity: 'warning', channelType: 'website_chat', ownerName: 'Unassigned', createdAt: '2026-06-27T09:55:00+03:00' },
  ],
  pendingHandoffs: [
    { id: 'HANDOFF-001', conversationId: 'CONV-2026-001', fromTeam: 'Sales', toTeam: 'Reservations', reason: 'Dates confirmed, move to booking team', dueAt: '2026-06-28T11:00:00+03:00' },
    { id: 'HANDOFF-002', conversationId: 'CONV-2026-003', fromTeam: 'Support', toTeam: 'Finance', reason: 'Invoice total dispute follow-up', dueAt: '2026-06-28T09:30:00+03:00' },
  ],
};

export const mockOmnichannelChannelConfigurations: OmnichannelChannelConfiguration[] = [
  {
    channelId: 'CH-WABA-001',
    phoneNumber: '+20 100 555 0102',
    displayName: 'Travneeds Business',
    provider: 'Meta Business Mock',
    businessId: 'META-BIZ-TRV-2026',
    webhookUrlPreview: 'https://mock.travneeds.local/webhooks/whatsapp-business',
    templateSyncStatus: 'Synced 15 minutes ago',
    primaryLanguage: 'en',
    defaultSlaPolicyId: 'SLA-001',
    assignedTeamId: 'queue-sales',
  },
  {
    channelId: 'CH-FB-001',
    pageName: 'Nile Travel Page',
    pageId: 'FB-PAGE-99871',
    permissionsChecklist: ['messages', 'pages_manage_metadata', 'pages_read_engagement'],
    primaryLanguage: 'en',
    defaultSlaPolicyId: 'SLA-001',
    assignedTeamId: 'queue-sales',
  },
  {
    channelId: 'CH-IGDM-001',
    accountHandle: '@travneeds',
    monitorDirectMessages: true,
    monitorComments: false,
    monitorMentions: true,
    primaryLanguage: 'en',
    defaultSlaPolicyId: 'SLA-001',
    assignedTeamId: 'queue-sales',
  },
  {
    channelId: 'CH-WEB-001',
    widgetTitle: 'Travneeds Live Concierge',
    brandColor: '#2563EB',
    greetingMessage: 'Welcome to Travneeds. How can we help with your trip today?',
    offlineMessage: 'We are offline now, but leave your details and we will get back to you.',
    embedCodePreview: '<script>window.TravneedsChat=...</script>',
    primaryLanguage: 'ar',
    defaultSlaPolicyId: 'SLA-003',
    assignedTeamId: 'queue-unassigned',
  },
  {
    channelId: 'CH-EMAIL-001',
    mailboxName: 'Support Inbox',
    forwardingAddress: 'support@travneeds.com',
    senderIdentity: 'Travneeds Support',
    signature: 'Travneeds Support Team',
    primaryLanguage: 'en',
    defaultSlaPolicyId: 'SLA-002',
    assignedTeamId: 'queue-support',
  },
  {
    channelId: 'CH-SMS-001',
    senderId: 'TRAVNEEDS',
    region: 'Egypt',
    provider: 'SMS Provider Mock',
    primaryLanguage: 'ar',
    defaultSlaPolicyId: 'SLA-002',
    assignedTeamId: 'queue-support',
  },
  {
    channelId: 'CH-PHONE-001',
    callSource: 'Travneeds PBX',
    missedCallRule: 'Create callback task after 10 minutes',
    callbackSlaMinutes: 30,
    primaryLanguage: 'ar',
    defaultSlaPolicyId: 'SLA-003',
    assignedTeamId: 'queue-reservations',
  },
];

export const mockOmnichannelRoutingSimulations: OmnichannelRoutingSimulation[] = [
  { id: 'SIM-001', channelType: 'website_chat', language: 'ar', priority: 'normal', keywords: ['أسوان', 'فندق'], workingHours: true, matchedRuleId: 'RULE-003', matchedQueueId: 'queue-unassigned' },
  { id: 'SIM-002', channelType: 'email', language: 'en', customerSegmentId: 'segment-corporate', priority: 'urgent', keywords: ['invoice', 'complaint'], workingHours: true, matchedRuleId: 'RULE-002', matchedQueueId: 'queue-support' },
];

export const mockOmnichannelAutomationRules: OmnichannelAutomationRule[] = [
  {
    id: 'AUTO-001',
    name: { en: 'Escalate SLA risk to supervisor', ar: 'تصعيد خطر الخدمة إلى المشرف' },
    status: 'active',
    trigger: 'sla_at_risk',
    conditions: ['Priority is high or urgent', 'No agent reply within 10 minutes'],
    actions: [{ type: 'notify_supervisor', summary: 'Send supervisor alert' }, { type: 'add_tag', summary: 'Add SLA at risk tag' }],
    ownerId: 'USR-001',
    ownerName: 'Super Admin',
    priority: 1,
    lastRunAt: '2026-06-27T09:42:00+03:00',
  },
  {
    id: 'AUTO-002',
    name: { en: 'Create ticket from complaint keyword', ar: 'إنشاء تذكرة عند رصد كلمة شكوى' },
    status: 'active',
    trigger: 'keyword_detected',
    conditions: ['Keyword contains complaint or refund', 'Channel is email or website chat'],
    actions: [{ type: 'create_ticket', summary: 'Open support ticket' }, { type: 'assign_team', summary: 'Assign Support queue' }],
    ownerId: 'USR-001',
    ownerName: 'Super Admin',
    priority: 2,
    lastRunAt: '2026-06-27T08:14:00+03:00',
  },
  {
    id: 'AUTO-003',
    name: { en: 'Send welcome quick reply', ar: 'إرسال رد ترحيبي سريع' },
    status: 'paused',
    trigger: 'new_conversation',
    conditions: ['Channel is website live chat', 'Business hours are active'],
    actions: [{ type: 'send_quick_reply', summary: 'Insert greeting template' }, { type: 'assign_team', summary: 'Assign Sales queue' }],
    ownerId: 'USR-004',
    ownerName: 'Nadia Samir',
    priority: 3,
  },
];

export const mockOmnichannelAutomationActivities: OmnichannelAutomationActivity[] = [
  { id: 'AUTOLOG-001', ruleId: 'AUTO-001', ruleName: 'Escalate SLA risk to supervisor', conversationId: 'CONV-2026-001', status: 'warning', message: 'Supervisor alert sent for SLA risk.', createdAt: '2026-06-27T09:42:00+03:00' },
  { id: 'AUTOLOG-002', ruleId: 'AUTO-002', ruleName: 'Create ticket from complaint keyword', conversationId: 'CONV-2026-003', status: 'success', message: 'Ticket created after complaint keyword match.', createdAt: '2026-06-27T07:32:00+03:00' },
  { id: 'AUTOLOG-003', ruleId: 'AUTO-003', ruleName: 'Send welcome quick reply', status: 'failed', message: 'Automation skipped because business hours were inactive.', createdAt: '2026-06-26T23:11:00+03:00' },
];

export const mockOmnichannelLabels: OmnichannelLabelDefinition[] = [
  { id: 'label-vip', name: { en: 'VIP', ar: 'مهم جداً' }, colorClass: 'bg-purple-50 text-purple-700 border-purple-100', usageCount: 12, type: 'segment' },
  { id: 'label-newlywed', name: { en: 'Honeymoon', ar: 'شهر عسل' }, colorClass: 'bg-pink-50 text-pink-700 border-pink-100', usageCount: 4, type: 'tag' },
  { id: 'label-priority-hot', name: { en: 'Hot Opportunity', ar: 'فرصة ساخنة' }, colorClass: 'bg-amber-50 text-amber-700 border-amber-100', usageCount: 9, type: 'priority_label' },
  { id: 'label-sla-vip', name: { en: 'VIP SLA', ar: 'خدمة كبار العملاء' }, colorClass: 'bg-blue-50 text-blue-700 border-blue-100', usageCount: 5, type: 'sla_label' },
  { id: 'segment-corporate', name: { en: 'Corporate', ar: 'شركات' }, colorClass: 'bg-slate-50 text-slate-700 border-slate-200', usageCount: 7, type: 'segment' },
];

export const mockOmnichannelHolidays: OmnichannelHoliday[] = [
  { id: 'HOL-001', name: { en: 'Arafat Day', ar: 'وقفة عرفة' }, date: '2026-06-29' },
  { id: 'HOL-002', name: { en: 'Eid Al Adha', ar: 'عيد الأضحى' }, date: '2026-06-30' },
];

export const mockOmnichannelEscalationSteps: OmnichannelEscalationStep[] = [
  { id: 'STEP-001', level: 1, roleName: 'Agent', responseMinutes: 15 },
  { id: 'STEP-002', level: 2, roleName: 'Supervisor', responseMinutes: 30 },
  { id: 'STEP-003', level: 3, roleName: 'Manager', responseMinutes: 60 },
];

export const mockOmnichannelTeamWorkload: OmnichannelTeamMemberWorkload[] = [
  { id: 'USR-002', name: 'Mahmoud Khalil', teamName: 'Sales', onlineStatus: 'online', assignedConversations: 9, activeTickets: 2, averageResponseMinutes: 12, satisfactionScore: 92, workloadPercent: 78, supervisorName: 'Super Admin' },
  { id: 'USR-003', name: 'Layla Ramadan', teamName: 'Reservations', onlineStatus: 'busy', assignedConversations: 7, activeTickets: 3, averageResponseMinutes: 18, satisfactionScore: 95, workloadPercent: 84, supervisorName: 'Super Admin' },
  { id: 'USR-001', name: 'Super Admin', teamName: 'Support', onlineStatus: 'online', assignedConversations: 5, activeTickets: 4, averageResponseMinutes: 24, satisfactionScore: 86, workloadPercent: 66, supervisorName: 'CEO Desk' },
  { id: 'USR-004', name: 'Nadia Samir', teamName: 'Marketing', onlineStatus: 'offline', assignedConversations: 2, activeTickets: 0, averageResponseMinutes: 20, satisfactionScore: 89, workloadPercent: 25, supervisorName: 'Super Admin' },
];

export const mockOmnichannelReportSchedules: OmnichannelReportSchedule[] = [
  { id: 'REP-001', name: 'Daily SLA Digest', frequency: 'daily', nextRunAt: '2026-06-29T08:00:00+03:00', recipients: ['ops@travneeds.com', 'support@travneeds.com'] },
  { id: 'REP-002', name: 'Weekly Channel Performance', frequency: 'weekly', nextRunAt: '2026-07-02T09:00:00+03:00', recipients: ['management@travneeds.com'] },
];

export const mockOmnichannelActivityLogs: OmnichannelActivityLogEntry[] = [
  { id: 'LOG-001', actorName: 'Super Admin', category: 'channel_connection', channelType: 'email', summary: 'Support Email was revalidated against policy settings.', createdAt: '2026-06-27T09:15:00+03:00' },
  { id: 'LOG-002', actorName: 'Mahmoud Khalil', category: 'conversation_action', channelType: 'whatsapp', conversationId: 'CONV-2026-001', summary: 'Conversation priority changed to high.', createdAt: '2026-06-27T08:40:00+03:00' },
  { id: 'LOG-003', actorName: 'Layla Ramadan', category: 'assignment_action', channelType: 'website_chat', conversationId: 'CONV-2026-005', summary: 'Conversation reassigned to Reservations queue.', createdAt: '2026-06-27T09:58:00+03:00' },
  { id: 'LOG-004', actorName: 'Nadia Samir', category: 'template_change', channelType: 'instagram_dm', summary: 'Arabic welcome template duplicated for Instagram DMs.', createdAt: '2026-06-27T08:05:00+03:00' },
  { id: 'LOG-005', actorName: 'Automation Engine', category: 'automation_event', channelType: 'email', conversationId: 'CONV-2026-003', summary: 'Complaint automation opened a support ticket.', createdAt: '2026-06-27T07:31:00+03:00' },
];

export const mockOmnichannelSettings: OmnichannelSettingsSnapshot = {
  defaultAssignmentPolicy: 'Round robin within the selected team',
  defaultSlaPolicyId: 'SLA-001',
  notificationEmail: true,
  notificationBrowser: true,
  closeReasons: ['Issue resolved', 'Customer stopped replying', 'Duplicate conversation', 'Wrong channel'],
  dataRetentionDays: 365,
  consentOptInRequired: true,
  languageFallback: 'en',
  internalNoteVisibility: 'department',
  identityMergeRule: 'suggested',
};

export const mockOmnichannelBroadcasts: OmnichannelBroadcastCampaign[] = [
  { id: 'BC-001', name: 'Summer Upgrade Reminder', audienceSegmentId: 'segment-corporate', channelType: 'whatsapp_business', templateId: 'TPL-001', scheduledAt: '2026-06-29T12:00:00+03:00', deliveryStatus: 'scheduled', optInWarning: 'Only opted-in contacts will be included.' },
  { id: 'BC-002', name: 'Arabic Payment Reminder', audienceSegmentId: 'label-vip', channelType: 'sms', templateId: 'TPL-003', scheduledAt: '2026-06-30T10:30:00+03:00', deliveryStatus: 'draft', optInWarning: 'Review SMS opt-in before scheduling.' },
];

export const mockOmnichannelAnalytics: OmnichannelAnalyticsSummary = {
  totalConversations: 72,
  openConversations: 18,
  pendingConversations: 11,
  closedConversations: 43,
  unassignedConversations: 5,
  unreadMessages: 17,
  slaBreaches: 4,
  averageFirstResponseMinutes: 18,
  leadConversions: 9,
  bookingConversions: 5,
  caseConversions: 7,
  channelSummaries: [
    { channelType: 'whatsapp', conversationCount: 18, openCount: 5, closedCount: 10, averageResponseMinutes: 12, slaBreaches: 1, conversionCount: 4 },
    { channelType: 'whatsapp_business', conversationCount: 13, openCount: 4, closedCount: 8, averageResponseMinutes: 10, slaBreaches: 0, conversionCount: 3 },
    { channelType: 'facebook_messenger', conversationCount: 8, openCount: 3, closedCount: 4, averageResponseMinutes: 21, slaBreaches: 1, conversionCount: 1 },
    { channelType: 'instagram_dm', conversationCount: 9, openCount: 2, closedCount: 6, averageResponseMinutes: 19, slaBreaches: 0, conversionCount: 2 },
    { channelType: 'instagram_comment', conversationCount: 6, openCount: 3, closedCount: 2, averageResponseMinutes: 34, slaBreaches: 2, conversionCount: 0 },
    { channelType: 'website_chat', conversationCount: 10, openCount: 4, closedCount: 5, averageResponseMinutes: 15, slaBreaches: 0, conversionCount: 2 },
    { channelType: 'email', conversationCount: 5, openCount: 1, closedCount: 3, averageResponseMinutes: 42, slaBreaches: 1, conversionCount: 0 },
    { channelType: 'sms', conversationCount: 1, openCount: 0, closedCount: 1, averageResponseMinutes: 25, slaBreaches: 0, conversionCount: 0 },
    { channelType: 'phone', conversationCount: 2, openCount: 1, closedCount: 1, averageResponseMinutes: 8, slaBreaches: 0, conversionCount: 1 },
  ],
};
