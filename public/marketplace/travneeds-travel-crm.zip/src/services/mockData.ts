import { Quotation } from '../types/quotation';
import type {
    ProductAvailabilityRule,
    ProductCategory,
    ProductCostTemplate,
    ProductPackageTemplate,
    ProductPricingRule,
    ProductServiceItem
} from '../types';

/**
 * Centralized Mock Data for Travneeds System
 * This ensures data consistency across different modules (Leads, Customers, Sales, Finance).
 */

export const mockLeads = [
    {
        id: 'LD-2025-001',
        fullName: 'Sarah Ahmed',
        email: 'sarah.ahmed@example.com',
        phone: '+20 100 123 4567',
        company: 'Travel Buddies',
        source: 'Website',
        type: 'B2C',
        status: 'New',
        priority: 'High',
        staff: 'Layla Ramadan',
        notes: 'Interested in a honeymoon package to Luxor.',
        dateAdded: '2025-01-15'
    },
    {
        id: 'LD-2025-002',
        fullName: 'John Smith',
        email: 'john.smith@gmail.com',
        phone: '+1 555 0199',
        company: null,
        source: 'Social Media',
        type: 'B2C',
        status: 'Contacted',
        priority: 'Medium',
        staff: 'Mahmoud Khalil',
        notes: 'Asking about Nile Cruise availability for March.',
        dateAdded: '2025-01-14'
    },
    {
        id: 'LD-2025-003',
        fullName: 'Business Solutions Co',
        email: 'info@bizsol.com',
        phone: '+20 2 2345 6789',
        company: 'Business Solutions Ltd',
        source: 'Referral',
        type: 'B2B',
        status: 'Qualified',
        priority: 'Low',
        staff: 'Super Admin',
        notes: 'Corporate account inquiry for annual staff retreat.',
        dateAdded: '2025-01-12'
    }
];

export const mockCustomers = [
    {
        id: 'CUST-001',
        name: 'Ahmed Hassan',
        email: 'ahmed.h@gmail.com',
        phone: '+20 111 222 3333',
        type: 'Individual',
        status: 'Active',
        totalBookings: 5,
        totalSpent: 12450,
        lastBooking: '2025-01-10',
        nationality: 'Egyptian',
        address: 'Maadi, Cairo',
        createdAt: '2024-01-15',
        contactMethod: 'WhatsApp'
    },
    {
        id: 'CUST-002',
        name: 'Corporate Travel Inc',
        email: 'logistics@corptravel.com',
        phone: '+20 2 9876 5432',
        type: 'Corporate',
        status: 'Active',
        totalBookings: 24,
        totalSpent: 85600,
        lastBooking: '2025-01-12',
        nationality: 'International',
        address: 'New Cairo, Egypt',
        createdAt: '2024-03-20',
        contactMethod: 'Email'
    }
];

export const mockFinance = [
    {
        id: 'BK-2025-012',
        customer: 'Ahmed Hassan',
        tripItem: 'Hotel: Steigenberger Luxor',
        totalAmount: 1200,
        paidAmount: 400,
        outstandingBalance: 800,
        paymentStatus: 'Deposit Paid',
        dueDate: '2025-01-20',
        agent: 'Super Admin',
        createdAt: '2025-01-05',
        invoiceStatus: 'Partial',
        invoiceDate: '2025-01-06',
        supplier: 'Steigenberger Hotels',
        supplierCost: 900,
        profit: 200,
        profitMargin: 15
    },
    {
        id: 'BK-2025-013',
        customer: 'Cairo Tours Ltd',
        tripItem: 'Flight: Cairo-Luxor EgyptAir',
        totalAmount: 4500,
        paidAmount: 4500,
        outstandingBalance: 0,
        paymentStatus: 'Fully Paid',
        dueDate: '2025-01-15',
        agent: 'Mahmoud Khalil',
        createdAt: '2025-01-08',
        invoiceStatus: 'Final',
        invoiceDate: '2025-01-08',
        supplier: 'EgyptAir',
        supplierCost: 3800,
        profit: 450,
        profitMargin: 10
    }
];

export const mockSuppliers = [
    {
        id: 'SUP-001',
        name: 'Steigenberger Hotels',
        type: 'Hotel',
        email: 'info@steigenberger.com',
        phone: '+20 2 1234567',
        location: 'Luxor',
        destinations: ['Luxor', 'Aswan'],
        avgResponseTime: '1.2 Days',
        responseRate: 98,
        totalRequests: 145,
        pendingRequests: 3,
        overdueRequests: 0,
        rating: 4.8,
        status: 'Active',
        contacts: [
            { id: 'C-SUP-001-1', name: 'Reservations Office', role: 'Reservations', email: 'reservations@steigenberger.com', phone: '+20 2 1234567', active: true },
            { id: 'C-SUP-001-2', name: 'Finance Dept', role: 'Accounting', email: 'finance@steigenberger.com', phone: '+20 2 1234568', active: true }
        ],
        contracts: [
            {
                id: 'CTR-1001',
                title: 'Standard Hotel Contract 2024-2026',
                status: 'Active',
                startDate: '2024-01-01',
                endDate: '2026-01-01',
                linkedServices: ['ITEM-001'],
                paymentTerms: '30 days after invoice',
                commissionNotes: '10% on room revenue',
                policyRules: [
                    { id: 'PR-1001-1', name: 'Standard Cancellation Policy', type: 'Cancellation', chargeType: 'Percentage', value: 100, startDate: '2024-01-01', endDate: '2026-01-01', status: 'Active', notes: 'Within 7 days of check-in.' },
                    { id: 'PR-1001-2', name: 'Peak Season Supplement', type: 'Seasonal Supplement', chargeType: 'Fixed Amount', value: 50, startDate: '2025-12-20', endDate: '2026-01-05', status: 'Active', notes: 'Applicable per room per night.' }
                ]
            }
        ],
        documents: [
            { id: 'DOC-1001', name: 'Commercial Register', type: 'KYC', uploadedAt: '2024-01-10', expiresAt: '2026-01-09', status: 'Valid' }
        ],
        payments: [
            { id: 'PAY-1001', invoiceRef: 'INV-2025-001', amount: 900, currency: 'USD', status: 'Pending', date: '2025-01-10' }
        ],
        performance: { responseTimeDays: 1.2, responseRatePercent: 98, confirmationRatePercent: 96, cancellationIssues: 2, qualityScore: 92, complaints: 1 },
        evaluations: [
            {
                id: 'EV-SUP-001-1',
                date: '2026-06-20',
                reviewer: 'Operations Manager',
                overallScore: 92,
                status: 'Approved',
                criteria: [
                    { id: 'EV-SUP-001-1-C1', area: 'Response Quality', weight: 20, score: 94, status: 'Pass', notes: 'Fast and complete responses.' },
                    { id: 'EV-SUP-001-1-C2', area: 'Confirmation Accuracy', weight: 20, score: 96, status: 'Pass', notes: 'Few correction requests.' },
                    { id: 'EV-SUP-001-1-C3', area: 'Document Compliance', weight: 15, score: 90, status: 'Pass', notes: 'KYC documents valid.' },
                    { id: 'EV-SUP-001-1-C4', area: 'Customer Feedback', weight: 15, score: 88, status: 'Pass', notes: 'Positive service feedback.' },
                    { id: 'EV-SUP-001-1-C5', area: 'Contract Compliance', weight: 15, score: 94, status: 'Pass', notes: 'Policies followed.' },
                    { id: 'EV-SUP-001-1-C6', area: 'Financial Reliability', weight: 15, score: 90, status: 'Pass', notes: 'Invoices match agreed terms.' }
                ],
                notes: 'Approved for preferred supplier usage.'
            }
        ],
        activity: [
            { id: 'ACT-1', type: 'Created', message: 'Supplier added to system', user: 'Super Admin', date: '2024-01-15' },
            { id: 'ACT-2', type: 'Contract', message: 'Contract CTR-1001 activated', user: 'Super Admin', date: '2024-01-20' }
        ]
    },
    {
        id: 'SUP-002',
        name: 'EgyptAir',
        type: 'Airline',
        email: 'support@egyptair.com',
        phone: '+20 2 9876543',
        location: 'Cairo',
        destinations: ['Cairo', 'Luxor', 'Aswan'],
        avgResponseTime: '0.5 Days',
        responseRate: 99,
        totalRequests: 412,
        pendingRequests: 1,
        overdueRequests: 0,
        rating: 4.9,
        status: 'Active',
        contacts: [
            { id: 'C-SUP-002-1', name: 'Cargo & Groups', role: 'Reservations', email: 'groups@egyptair.com', phone: '+20 2 9876543', active: true }
        ],
        contracts: [
            { id: 'CTR-2001', title: 'Corporate Fares Agreement', status: 'Active', startDate: '2023-06-01', endDate: '2026-06-01', linkedServices: ['ITEM-003'], paymentTerms: 'Net 45', commissionNotes: 'N/A' }
        ],
        documents: [
            { id: 'DOC-2001', name: 'Air Operator License', type: 'License', uploadedAt: '2023-05-10', expiresAt: '2026-05-09', status: 'Valid' }
        ],
        payments: [
            { id: 'PAY-2001', invoiceRef: 'INV-2025-002', amount: 3800, currency: 'USD', status: 'Paid', date: '2025-01-08' }
        ],
        performance: { responseTimeDays: 0.5, responseRatePercent: 99, confirmationRatePercent: 99, cancellationIssues: 0, qualityScore: 97, complaints: 0 },
        activity: [
            { id: 'ACT-10', type: 'Created', message: 'Supplier added', user: 'Super Admin', date: '2023-06-01' }
        ]
    },
    {
        id: 'SUP-003',
        name: 'Cairo Tours',
        type: 'Tour Operator',
        email: 'bookings@cairotours.com',
        phone: '+20 2 5550123',
        location: 'Cairo',
        destinations: ['Luxor', 'Cairo'],
        avgResponseTime: '2.1 Days',
        responseRate: 88,
        totalRequests: 89,
        pendingRequests: 5,
        overdueRequests: 2,
        rating: 4.2,
        status: 'Active',
        contacts: [
            { id: 'C-SUP-003-1', name: 'Operations', role: 'Reservations', email: 'ops@cairotours.com', phone: '+20 2 5550123', active: true }
        ],
        contracts: [],
        documents: [],
        payments: [],
        performance: { responseTimeDays: 2.1, responseRatePercent: 88, confirmationRatePercent: 86, cancellationIssues: 3, qualityScore: 78, complaints: 4 },
        activity: []
    },
    {
        id: 'SUP-004',
        name: 'Hilton Hotels',
        type: 'Hotel',
        email: 'reservations@hilton.com',
        phone: '+20 2 8887776',
        location: 'Aswan',
        destinations: ['Aswan'],
        avgResponseTime: '1.5 Days',
        responseRate: 94,
        totalRequests: 76,
        pendingRequests: 2,
        overdueRequests: 0,
        rating: 4.5,
        status: 'Active',
        contacts: [],
        contracts: [],
        documents: [],
        payments: [],
        performance: { responseTimeDays: 1.5, responseRatePercent: 94, confirmationRatePercent: 92, cancellationIssues: 1, qualityScore: 88, complaints: 1 },
        activity: []
    },
    {
        id: 'SUP-005',
        name: 'Nile Cruise Co',
        type: 'Cruise Line',
        email: 'info@nilecruise.com',
        phone: '+20 2 4443332',
        location: 'Aswan',
        destinations: ['Aswan', 'Luxor'],
        avgResponseTime: '3.0 Days',
        responseRate: 75,
        totalRequests: 34,
        pendingRequests: 8,
        overdueRequests: 4,
        rating: 3.8,
        status: 'Onboarding',
        contacts: [],
        contracts: [],
        documents: [],
        payments: [],
        performance: { responseTimeDays: 3.0, responseRatePercent: 75, confirmationRatePercent: 70, cancellationIssues: 6, qualityScore: 62, complaints: 6 },
        activity: []
    }
];

export const mockReservations = [
    {
        id: 'BK-2025-001',
        customer: 'Ahmed Hassan',
        customerEmail: 'ahmed.h@gmail.com',
        customerPhone: '+20 111 222 3333',
        tripItem: 'Hotel: Steigenberger Luxor',
        roomType: 'Deluxe Nile View',
        destination: 'Luxor',
        checkIn: '2025-01-15',
        checkOut: '2025-01-18',
        totalNights: 3,
        adults: 2,
        children: 1,
        childAges: [8],
        rooms: 1,
        mealPlan: 'Full Board',
        nationality: 'Egyptian',
        supplier: 'Steigenberger Hotels',
        status: 'Pending',
        financeStatus: 'Payment Requested',
        assignedAgent: 'Super Admin',
        specialRequests: 'Late check-in requested',
        createdAt: '2025-01-12',
        dueDate: '2025-01-16',
        supplierResponseTime: '2 days',
        notes: 'Customer prefers room with Nile view'
    },
    {
        id: 'BK-2025-013',
        customer: 'Corporate Travel Inc',
        customerEmail: 'logistics@corptravel.com',
        customerPhone: '+20 2 9876 5432',
        tripItem: 'Flight: Cairo-Luxor EgyptAir',
        roomType: 'Business Class',
        destination: 'Cairo - Luxor',
        checkIn: '2025-01-20',
        checkOut: '2025-01-20',
        totalNights: 0,
        adults: 15,
        children: 0,
        childAges: [],
        rooms: 0,
        mealPlan: 'N/A',
        nationality: 'Mixed Group',
        supplier: 'EgyptAir',
        status: 'Confirmed',
        financeStatus: 'Paid',
        assignedAgent: 'Mahmoud Khalil',
        specialRequests: 'Group booking, special assistance needed',
        createdAt: '2025-01-11',
        dueDate: '2025-01-15',
        supplierResponseTime: '1 day',
        notes: 'Corporate group booking'
    }
];

export const mockTasks = [
    {
        id: 'TASK-001',
        title: 'Confirm hotel availability with Steigenberger',
        bookingId: 'BK-2025-001',
        customer: 'Ahmed Hassan',
        dueDate: '2025-01-16',
        status: 'Overdue',
        priority: 'High',
        assignedTo: 'Super Admin',
        description: 'Customer needs confirmation for Nile view room'
    }
];

export const mockCases = [
    { id: 'CASE-2025-001', customer: 'Ahmed Hassan', customerEmail: 'ahmed.h@gmail.com', type: 'Package', status: 'Quotation Sent', value: 24500, agent: 'Mahmoud Khalil', date: '2025-01-10', createdAt: '2025-01-10', quotationStatus: 'Accepted', assignedAgent: 'Mahmoud Khalil' },
    { id: 'CASE-2025-002', customer: 'Sarah Ahmed', customerEmail: 'sarah.ahmed@example.com', type: 'Flight Only', status: 'In Progress', value: 1200, agent: 'Layla Ramadan', date: '2025-01-14', createdAt: '2025-01-14', quotationStatus: 'Pending', assignedAgent: 'Layla Ramadan' },
    { id: 'CASE-2025-003', customer: 'Corporate Travel Inc', customerEmail: 'logistics@corptravel.com', type: 'Custom Tour', status: 'New', value: 85600, agent: 'Super Admin', date: '2025-01-15', createdAt: '2025-01-15', quotationStatus: 'N/A', assignedAgent: 'Super Admin' }
];

export const mockTrips = [
    { id: 'TRP-001', customer: 'Ahmed Hassan', customerCount: 4, itinerary: 'Luxor & Aswan Nile Cruise', startDate: '2025-01-20', endDate: '2025-01-24', status: 'In Progress', assignedGuide: 'Omar Kamal', assignedDriver: 'Hassan Said', transport: 'Private Van', transportDetails: 'Toyota Hiace (ABC-123)', createdAt: '2025-01-10' },
    { id: 'TRP-002', customer: 'Sarah Ahmed', customerCount: 2, itinerary: 'Cairo Day Tour - Pyramids', startDate: '2025-01-18', endDate: '2025-01-18', status: 'Planned', assignedGuide: 'Mona Zaki', assignedDriver: 'Ali Reda', transport: 'Sedan', transportDetails: 'Hyundai Elantra (XYZ-789)', createdAt: '2025-01-12' },
    { id: 'TRP-003', customer: 'John Smith', customerCount: 1, itinerary: 'Airport Transfer - Hurghada', startDate: '2025-01-15', endDate: '2025-01-15', status: 'Issue', assignedGuide: 'N/A', assignedDriver: 'Sami Bakr', transport: 'SUV', transportDetails: 'Kia Sportage (DEF-456)', createdAt: '2025-01-14' }
];

export const mockTickets = [
    { id: 'TKT-001', customer: 'Ahmed Hassan', bookingRef: 'BK-2025-001', subject: 'Inquiry about room view', description: 'Customer wants to ensure the room has a Nile view as requested.', status: 'Open', priority: 'Normal', department: 'Reservations', source: 'WhatsApp', createdAt: '2025-01-15' },
    { id: 'TKT-002', customer: 'Corporate Travel Inc', bookingRef: 'BK-2025-013', subject: 'Invoice Discrepancy', description: 'Total amount on invoice does not match the quotation.', status: 'Escalated', priority: 'Urgent', department: 'Finance', source: 'Email', createdAt: '2025-01-14' }
];

export const mockUsers = [
    { id: 'USR-001', name: 'Super Admin', email: 'admin@travneeds.com', role: 'System Administrator', department: 'Management', status: 'Active', joinDate: '2024-01-01', lastLogin: '2025-01-15T10:00:00Z', permissions: ['all'] },
    { id: 'USR-002', name: 'Mahmoud Khalil', email: 'mahmoud@travneeds.com', role: 'Sales Manager', department: 'Sales', status: 'Active', joinDate: '2024-03-15', lastLogin: '2025-01-15T09:30:00Z', permissions: ['sales', 'leads'] },
    { id: 'USR-003', name: 'Layla Ramadan', email: 'layla@travneeds.com', role: 'Reservations Officer', department: 'Operations', status: 'Active', joinDate: '2024-05-10', lastLogin: '2025-01-14T16:45:00Z', permissions: ['reservations'] }
];

export const mockProductCategories: ProductCategory[] = [
    { id: 'CAT-001', name: 'Accommodation', type: 'Hotel', status: 'Active', usageCount: 42 },
    { id: 'CAT-002', name: 'Cruise', type: 'Cruise', status: 'Active', usageCount: 18 },
    { id: 'CAT-003', name: 'Flight', type: 'Airline', status: 'Active', usageCount: 64 },
    { id: 'CAT-004', name: 'Tours', type: 'Tour', status: 'Active', usageCount: 36 },
    { id: 'CAT-005', name: 'Transfers', type: 'Transportation', status: 'Draft', usageCount: 9 }
];

export const mockProductCostTemplates: ProductCostTemplate[] = [
    {
        id: 'CT-001',
        name: 'Hotel Room Net Cost',
        categoryId: 'CAT-001',
        appliesToType: 'Hotel',
        status: 'Active',
        lastUpdated: '2026-06-18',
        components: [
            { id: 'CC-001', name: 'Supplier net room', costType: 'Per Night', amount: 90, currency: 'USD', taxable: true, supplierId: 'SUP-001' },
            { id: 'CC-002', name: 'City tax estimate', costType: 'Percentage', amount: 8, currency: 'USD', taxable: false },
            { id: 'CC-003', name: 'Reservation handling', costType: 'Fixed', amount: 12, currency: 'USD', taxable: false }
        ]
    },
    {
        id: 'CT-002',
        name: 'Private Tour Operating Cost',
        categoryId: 'CAT-004',
        appliesToType: 'Sightseeing',
        status: 'Active',
        lastUpdated: '2026-06-20',
        components: [
            { id: 'CC-004', name: 'Licensed guide', costType: 'Fixed', amount: 65, currency: 'USD', taxable: false, supplierId: 'SUP-003' },
            { id: 'CC-005', name: 'Private vehicle', costType: 'Fixed', amount: 45, currency: 'USD', taxable: true },
            { id: 'CC-006', name: 'Operations buffer', costType: 'Percentage', amount: 5, currency: 'USD', taxable: false }
        ]
    }
];

export const mockProductPricingRules: ProductPricingRule[] = [
    { id: 'PR-001', name: 'Accommodation Standard Margin', categoryId: 'CAT-001', ruleType: 'Markup %', value: 28, minMarginPercent: 18, priority: 1, status: 'Active' },
    { id: 'PR-002', name: 'Cruise Peak Season Margin', categoryId: 'CAT-002', ruleType: 'Seasonal Margin', value: 32, minMarginPercent: 20, startDate: '2026-12-01', endDate: '2027-01-15', priority: 2, status: 'Active' },
    { id: 'PR-003', name: 'Cairo Tours Competitive Markup', categoryId: 'CAT-004', destination: 'Cairo', ruleType: 'Markup %', value: 22, minMarginPercent: 15, priority: 1, status: 'Active' }
];

export const mockProductAvailabilityRules: ProductAvailabilityRule[] = [
    { id: 'AR-001', itemId: 'ITEM-001', name: 'Winter room allocation', ruleType: 'Allocation', startDate: '2026-12-15', endDate: '2027-01-15', quantity: 12, releaseDays: 7, status: 'Open', supplierId: 'SUP-001', notes: 'Block rooms must be released one week before arrival.' },
    { id: 'AR-002', itemId: 'ITEM-002', name: 'Dry dock blackout', ruleType: 'Blackout', startDate: '2026-09-01', endDate: '2026-09-14', quantity: 0, releaseDays: 0, status: 'Closed', supplierId: 'SUP-005', notes: 'Cruise vessel maintenance period.' },
    { id: 'AR-003', itemId: 'ITEM-004', name: 'Daily guide capacity', ruleType: 'Allocation', startDate: '2026-07-01', endDate: '2026-12-31', quantity: 20, releaseDays: 2, status: 'Limited', supplierId: 'SUP-003' }
];

export const mockProductPackageTemplates: ProductPackageTemplate[] = [
    { id: 'PKT-001', name: 'Classic Nile Discovery', packageType: 'Nile Cruise', destination: 'Luxor / Aswan', itemIds: ['ITEM-001', 'ITEM-002', 'ITEM-004'], basePax: 2, status: 'Active', lastUpdated: '2026-06-22' },
    { id: 'PKT-002', name: 'Cairo City Break', packageType: 'City Break', destination: 'Cairo', itemIds: ['ITEM-003', 'ITEM-004', 'ITEM-005'], basePax: 2, status: 'Draft', lastUpdated: '2026-06-25' }
];

export const mockItems: ProductServiceItem[] = [
    {
        id: 'ITEM-001',
        name: 'Deluxe Room - Steigenberger',
        description: 'Deluxe Nile-view room with breakfast and flexible supplier confirmation.',
        categoryId: 'CAT-001',
        category: 'Accommodation',
        categoryType: 'Accommodation',
        type: 'Hotel',
        destination: 'Luxor',
        location: 'Luxor, Egypt',
        costPrice: 90,
        sellingPrice: 120,
        price: 120,
        priceUnit: 'per night',
        supplierId: 'SUP-001',
        supplierName: 'Steigenberger Hotels',
        status: 'Active',
        availability: 'Daily allocation',
        linkedBookings: 3,
        lastUpdated: '2026-06-10',
        createdAt: '2025-01-15',
        attributes: {
            duration: '1 night',
            capacity: '2 adults + 1 child',
            roomType: 'Deluxe Nile View',
            serviceClass: '5-star',
            inclusions: ['Breakfast', 'Taxes', 'Supplier confirmation'],
            exclusions: ['Personal expenses', 'Late checkout'],
            cancellationPolicy: 'Free cancellation until 7 days before arrival.',
            bookingNotes: 'Request Nile-view allocation before confirmation.',
            internalNotes: 'Preferred room block during winter season.'
        },
        media: [
            { id: 'MED-001', fileName: 'steigenberger-deluxe-placeholder.jpg', type: 'Main image', status: 'Placeholder' },
            { id: 'MED-002', fileName: 'room-gallery-placeholder.jpg', type: 'Gallery image', status: 'Placeholder' }
        ],
        destinationCoverage: [{ country: 'Egypt', city: 'Luxor', destination: 'Luxor', status: 'Active' }],
        supplierMapping: { supplierId: 'SUP-001', supplierName: 'Steigenberger Hotels', status: 'Linked', lastChecked: '2026-06-10' },
        activity: [
            { id: 'PACT-001', type: 'Created', message: 'Product created from accommodation catalog.', date: '2025-01-15', user: 'Super Admin' },
            { id: 'PACT-002', type: 'Supplier', message: 'Linked to Steigenberger Hotels.', date: '2026-06-10', user: 'Super Admin' }
        ],
        notes: 'Premium hotel product for Luxor packages.',
        seasonalRates: [
            { id: 'SR-001-1', seasonName: 'Peak Winter Season', startDate: '2026-12-15', endDate: '2027-01-15', costPrice: 130, sellingPrice: 180, currency: 'USD', status: 'Active', notes: 'Christmas and New Year peak surcharge.' },
            { id: 'SR-001-2', seasonName: 'Summer Low Season', startDate: '2026-06-01', endDate: '2026-08-31', costPrice: 70, sellingPrice: 95, currency: 'USD', status: 'Active', notes: 'Summer promotional rate.' }
        ]
    },
    {
        id: 'ITEM-002',
        name: 'Nile Cruise Cabin',
        description: 'Standard Nile cruise cabin between Aswan and Luxor.',
        categoryId: 'CAT-002',
        category: 'Cruise',
        categoryType: 'Cruise',
        type: 'Cruise',
        destination: 'Aswan',
        location: 'Aswan - Luxor, Egypt',
        costPrice: 280,
        sellingPrice: 350,
        price: 350,
        priceUnit: 'per cabin',
        supplierId: 'SUP-005',
        supplierName: 'Nile Cruise Co',
        status: 'Needs review',
        availability: 'Seasonal allotment',
        linkedBookings: 8,
        lastUpdated: '2026-06-08',
        createdAt: '2025-02-04',
        attributes: {
            duration: '4 nights',
            capacity: '2 guests',
            serviceClass: 'Standard cabin',
            inclusions: ['Full board', 'Cruise accommodation', 'Port taxes'],
            exclusions: ['Sightseeing entrance fees', 'Guide tips'],
            cancellationPolicy: 'Review supplier terms before final confirmation.',
            bookingNotes: 'Cabin category must be reconfirmed.',
            internalNotes: 'Supplier has overdue requests; monitor closely.'
        },
        media: [
            { id: 'MED-003', fileName: 'nile-cruise-placeholder.jpg', type: 'Main image', status: 'Placeholder' }
        ],
        destinationCoverage: [
            { country: 'Egypt', city: 'Aswan', destination: 'Aswan', status: 'Active' },
            { country: 'Egypt', city: 'Luxor', destination: 'Luxor', status: 'Active' }
        ],
        supplierMapping: { supplierId: 'SUP-005', supplierName: 'Nile Cruise Co', status: 'Needs review', lastChecked: '2026-06-08' },
        activity: [
            { id: 'PACT-003', type: 'Review', message: 'Marked for supplier performance review.', date: '2026-06-08', user: 'Reservations' }
        ],
        notes: 'Review before using in high-value packages.'
    },
    {
        id: 'ITEM-003',
        name: 'Corporate Fare - EgyptAir',
        description: 'Corporate economy fare for Cairo to Luxor group movements.',
        categoryId: 'CAT-003',
        category: 'Flight',
        categoryType: 'Flight',
        type: 'Airline',
        destination: 'Cairo',
        location: 'Cairo - Luxor, Egypt',
        costPrice: 380,
        sellingPrice: 450,
        price: 450,
        priceUnit: 'per person',
        supplierId: 'SUP-002',
        supplierName: 'EgyptAir',
        status: 'Active',
        availability: 'On request',
        linkedBookings: 5,
        lastUpdated: '2026-06-12',
        createdAt: '2025-01-12',
        attributes: {
            duration: '1h 10m',
            capacity: 'Group fare blocks',
            serviceClass: 'Economy',
            inclusions: ['Base fare', 'Airport taxes', 'Group booking support'],
            exclusions: ['Extra baggage', 'Name change penalties'],
            cancellationPolicy: 'Airline fare rules apply.',
            bookingNotes: 'Hold seats before sending final quotation.',
            internalNotes: 'Best response time among suppliers.'
        },
        media: [
            { id: 'MED-004', fileName: 'egyptair-fare-placeholder.jpg', type: 'Main image', status: 'Placeholder' }
        ],
        destinationCoverage: [
            { country: 'Egypt', city: 'Cairo', destination: 'Cairo', status: 'Active' },
            { country: 'Egypt', city: 'Luxor', destination: 'Luxor', status: 'Active' }
        ],
        supplierMapping: { supplierId: 'SUP-002', supplierName: 'EgyptAir', status: 'Linked', lastChecked: '2026-06-12' },
        activity: [
            { id: 'PACT-004', type: 'Pricing', message: 'Corporate fare updated for group movement.', date: '2026-06-12', user: 'Sales Manager' }
        ],
        notes: 'Use for corporate group bookings.'
    },
    {
        id: 'ITEM-004',
        name: 'Cairo Heritage Day Tour',
        description: 'Private guided day tour covering Pyramids, Egyptian Museum, and Khan el-Khalili.',
        categoryId: 'CAT-004',
        category: 'Tours',
        categoryType: 'Tour',
        type: 'Sightseeing',
        destination: 'Cairo',
        location: 'Cairo, Egypt',
        costPrice: 55,
        sellingPrice: 85,
        price: 85,
        priceUnit: 'per person',
        supplierId: 'SUP-003',
        supplierName: 'Cairo Tours',
        status: 'Active',
        availability: 'Daily on request',
        linkedBookings: 12,
        lastUpdated: '2026-06-01',
        createdAt: '2025-03-09',
        attributes: {
            duration: '8 hours',
            capacity: '1-20 guests',
            serviceClass: 'Private guided tour',
            inclusions: ['Licensed guide', 'Private vehicle', 'Bottled water'],
            exclusions: ['Entrance tickets', 'Lunch'],
            cancellationPolicy: 'Free cancellation until 48 hours before service.',
            bookingNotes: 'Confirm guide language.',
            internalNotes: 'Good fit for city break packages.'
        },
        media: [
            { id: 'MED-005', fileName: 'cairo-tour-placeholder.jpg', type: 'Main image', status: 'Placeholder' }
        ],
        destinationCoverage: [{ country: 'Egypt', city: 'Cairo', destination: 'Cairo', status: 'Active' }],
        supplierMapping: { supplierId: 'SUP-003', supplierName: 'Cairo Tours', status: 'Linked', lastChecked: '2026-06-01' },
        activity: [
            { id: 'PACT-005', type: 'Usage', message: 'Used in Cairo Weekend Escape quotation mock data.', date: '2026-06-01', user: 'Sales' }
        ],
        notes: 'Popular tour package.'
    },
    {
        id: 'ITEM-005',
        name: 'Private Airport Transfer - Sedan',
        description: 'Door-to-door private sedan transfer for Cairo arrivals.',
        categoryId: 'CAT-005',
        category: 'Transfers',
        categoryType: 'Transportation',
        type: 'Transfer',
        destination: 'Cairo',
        location: 'Cairo International Airport',
        costPrice: 18,
        sellingPrice: 35,
        price: 35,
        priceUnit: 'per trip',
        status: 'Without supplier',
        availability: 'Draft coverage',
        linkedBookings: 0,
        lastUpdated: '2026-06-05',
        createdAt: '2025-04-20',
        attributes: {
            duration: '45-90 minutes',
            capacity: '2 guests + luggage',
            vehicleType: 'Sedan',
            serviceClass: 'Private transfer',
            inclusions: ['Meet and assist', 'One-way transfer'],
            exclusions: ['Waiting time above 60 minutes', 'Extra stops'],
            cancellationPolicy: 'Draft policy until supplier is linked.',
            bookingNotes: 'Do not use until supplier mapping is complete.',
            internalNotes: 'Needs supplier before activation.'
        },
        media: [
            { id: 'MED-006', fileName: 'transfer-placeholder.jpg', type: 'Main image', status: 'Placeholder' }
        ],
        destinationCoverage: [{ country: 'Egypt', city: 'Cairo', destination: 'Cairo', status: 'Inactive' }],
        supplierMapping: { status: 'Unlinked' },
        activity: [
            { id: 'PACT-006', type: 'Draft', message: 'Created as draft transfer item without supplier.', date: '2026-06-05', user: 'Operations' }
        ],
        notes: 'Supplier required before using in operations.'
    }
];

export const mockQuotations: Quotation[] = [
    {
        id: 'QUO-2025-001',
        caseId: 'CASE-2025-001',
        reference: 'TVN-QT-1001',
        currentVersion: 1,
        createdAt: '2025-01-10T10:00:00Z',
        updatedAt: '2025-01-10T10:00:00Z',
        versions: [
            {
                id: 'QUO-V1-001',
                versionNumber: 1,
                status: 'Approved',
                preparedBy: 'Mahmoud Khalil',
                preparedDate: '2025-01-10',
                expiryDate: '2025-01-25',
                customerInfo: {
                    customerName: 'Ahmed Hassan',
                    email: 'ahmed.h@gmail.com',
                    phone: '+20 111 222 3333',
                    nationality: 'Egyptian',
                    groupType: 'FIT'
                },
                programOverview: {
                    title: 'Luxor & Aswan Nile Odyssey',
                    packageCode: 'LXR-ASW-05D',
                    packageType: 'Nile Cruise',
                    destinations: ['Luxor', 'Aswan'],
                    citiesCovered: ['Luxor', 'Edfu', 'Kom Ombo', 'Aswan'],
                    nights: 4,
                    season: 'Winter 2025',
                    description: 'A magical journey through the heart of ancient Egypt.',
                    highlights: ['Valley of the Kings', 'Karnak Temple', 'Philae Temple']
                },
                inclusions: ['4 Nights Nile Cruise', 'All Transfers', 'Full Board Meals', 'Licensed Guide'],
                exclusions: ['International Flights', 'Visa Fees', 'Tips'],
                itinerary: [
                    { day: 1, title: 'Arrival in Luxor', route: 'Airport - Cruise', city: 'Luxor', description: 'Meet & assist at airport, transfer to cruise.', meals: ['L', 'D'] }
                ],
                costing: [
                    { id: 'C1', name: 'Nile Cruise', category: 'Accommodation', city: 'Luxor', rate: 150, currency: 'USD', pricingType: 'Per Night', quantity: 2, nights: 4, totalCost: 1200 }
                ],
                pricing: {
                    totalAccommodationCost: 1200, totalSightseeingCost: 400, totalTransferCost: 200, totalMealsCost: 0, totalServiceCost: 100, totalOptionalCost: 0,
                    grandTotalCost: 1900, costPerPerson: 950, markupType: 'Percentage', markupValue: 15, profitAmount: 285, totalSellingPrice: 2185, sellingPricePerPerson: 1092.5,
                    currency: 'USD', exchangeRate: 1
                },
                terms: 'Standard booking terms apply.',
                fixedCosts: [
                    { id: 'FC-1001-1', name: 'Private Bus Cairo-Luxor', category: 'Private Vehicle', amount: 400, currency: 'USD', allocationMethod: 'Split Equally', quantity: 1, days: 1, status: 'Active', notes: 'Shared coach transfer.' },
                    { id: 'FC-1001-2', name: 'Egyptologist Guide Luxor', category: 'Tour Guide', amount: 150, currency: 'USD', allocationMethod: 'Per Group', quantity: 1, days: 2, status: 'Active', notes: 'Licensed tour guide.' }
                ]
            }
        ]
    },
    {
        id: 'QUO-2025-002',
        caseId: 'CASE-2025-003',
        reference: 'TVN-QT-2001',
        currentVersion: 2,
        createdAt: '2025-01-12T14:00:00Z',
        updatedAt: '2025-01-14T11:00:00Z',
        versions: [
            {
                id: 'QUO-V1-002',
                versionNumber: 1,
                status: 'Revised',
                preparedBy: 'Super Admin',
                preparedDate: '2025-01-12',
                expiryDate: '2025-01-20',
                customerInfo: {
                    customerName: 'Corporate Travel Inc',
                    companyName: 'Corporate Travel Inc',
                    email: 'logistics@corptravel.com',
                    phone: '+20 2 9876 5432',
                    nationality: 'International',
                    groupType: 'Corporate'
                },
                programOverview: {
                    title: 'Annual Corporate Retreat - Red Sea',
                    packageCode: 'CORP-HUR-04D',
                    packageType: 'Corporate',
                    destinations: ['Hurghada'],
                    citiesCovered: ['Hurghada'],
                    nights: 3,
                    season: 'Spring 2025',
                    description: 'Team building and relaxation by the Red Sea.',
                    highlights: ['Team Building Activities', 'Gala Dinner', 'Snorkeling Trip']
                },
                inclusions: ['3 Nights 5-star Hotel', 'Conference Room', 'All-inclusive Meals'],
                exclusions: ['Personal Expenses'],
                itinerary: [
                    { day: 1, title: 'Check-in and Welcome', route: 'Cairo - Hurghada', city: 'Hurghada', description: 'Private bus transfer to hotel.', meals: ['D'] }
                ],
                costing: [
                    { id: 'C1', name: 'Steigenberger ALDAU', category: 'Accommodation', city: 'Hurghada', rate: 120, currency: 'USD', pricingType: 'Per Night', quantity: 20, nights: 3, totalCost: 7200 }
                ],
                pricing: {
                    totalAccommodationCost: 7200, totalSightseeingCost: 0, totalTransferCost: 1500, totalMealsCost: 0, totalServiceCost: 2000, totalOptionalCost: 0,
                    grandTotalCost: 10700, costPerPerson: 267.5, markupType: 'Percentage', markupValue: 10, profitAmount: 1070, totalSellingPrice: 11770, sellingPricePerPerson: 294.25,
                    currency: 'USD', exchangeRate: 1
                },
                terms: 'Corporate contract terms apply.'
            },
            {
                id: 'QUO-V2-002',
                versionNumber: 2,
                status: 'Sent',
                preparedBy: 'Super Admin',
                preparedDate: '2025-01-14',
                expiryDate: '2025-01-25',
                customerInfo: {
                    customerName: 'Corporate Travel Inc',
                    companyName: 'Corporate Travel Inc',
                    email: 'logistics@corptravel.com',
                    phone: '+20 2 9876 5432',
                    nationality: 'International',
                    groupType: 'Corporate'
                },
                programOverview: {
                    title: 'Annual Corporate Retreat - Red Sea (v2)',
                    packageCode: 'CORP-HUR-04D',
                    packageType: 'Corporate',
                    destinations: ['Hurghada'],
                    citiesCovered: ['Hurghada'],
                    nights: 3,
                    season: 'Spring 2025',
                    description: 'Enhanced team building with additional activities.',
                    highlights: ['Enhanced Team Building', 'Beach Party', 'Private Yacht']
                },
                inclusions: ['3 Nights 5-star Hotel', 'Conference Room', 'All-inclusive Meals', 'Private Yacht Trip'],
                exclusions: ['Personal Expenses'],
                itinerary: [
                    { day: 1, title: 'Check-in and Team Dinner', route: 'Cairo - Hurghada', city: 'Hurghada', description: 'Luxury bus transfer.', meals: ['D'] }
                ],
                costing: [
                    { id: 'C1', name: 'Steigenberger ALDAU', category: 'Accommodation', city: 'Hurghada', rate: 130, currency: 'USD', pricingType: 'Per Night', quantity: 20, nights: 3, totalCost: 7800 }
                ],
                pricing: {
                    totalAccommodationCost: 7800, totalSightseeingCost: 500, totalTransferCost: 1500, totalMealsCost: 0, totalServiceCost: 2500, totalOptionalCost: 0,
                    grandTotalCost: 12300, costPerPerson: 307.5, markupType: 'Percentage', markupValue: 12, profitAmount: 1476, totalSellingPrice: 13776, sellingPricePerPerson: 344.4,
                    currency: 'USD', exchangeRate: 1
                },
                terms: 'Corporate contract terms apply.'
            }
        ]
    },
    {
        id: 'QUO-2025-003',
        caseId: 'CASE-2025-002',
        reference: 'TVN-QT-3001',
        currentVersion: 1,
        createdAt: '2025-01-15T09:00:00Z',
        updatedAt: '2025-01-15T09:00:00Z',
        versions: [
            {
                id: 'QUO-V1-003',
                versionNumber: 1,
                status: 'Draft',
                preparedBy: 'Layla Ramadan',
                preparedDate: '2025-01-15',
                expiryDate: '2025-01-30',
                customerInfo: {
                    customerName: 'Sarah Ahmed',
                    email: 'sarah.ahmed@example.com',
                    phone: '+20 100 123 4567',
                    nationality: 'Egyptian',
                    groupType: 'FIT'
                },
                programOverview: {
                    title: 'Cairo Weekend Escape',
                    packageCode: 'CAI-ESC-03D',
                    packageType: 'City Break',
                    destinations: ['Cairo'],
                    citiesCovered: ['Cairo'],
                    nights: 2,
                    season: 'Spring 2025',
                    description: 'Short and sweet escape to the capital.',
                    highlights: ['Pyramids of Giza', 'Egyptian Museum', 'Khan el-Khalili']
                },
                inclusions: ['2 Nights Hotel', 'Private Guide', 'Breakfast'],
                exclusions: ['Lunch and Dinner'],
                itinerary: [
                    { day: 1, title: 'Ancient Wonders', route: 'Hotel - Giza', city: 'Cairo', description: 'Visit the Giza Pyramids and the Sphinx.', meals: ['B'] }
                ],
                costing: [
                    { id: 'C1', name: 'Marriott Mena House', category: 'Accommodation', city: 'Cairo', rate: 200, currency: 'USD', pricingType: 'Per Night', quantity: 1, nights: 2, totalCost: 400 }
                ],
                pricing: {
                    totalAccommodationCost: 400, totalSightseeingCost: 150, totalTransferCost: 80, totalMealsCost: 0, totalServiceCost: 50, totalOptionalCost: 0,
                    grandTotalCost: 680, costPerPerson: 340, markupType: 'Fixed', markupValue: 100, profitAmount: 100, totalSellingPrice: 780, sellingPricePerPerson: 390,
                    currency: 'USD', exchangeRate: 1
                },
                terms: 'Non-refundable deposit required.'
            }
        ]
    },
    {
        id: 'QUO-2025-004',
        caseId: 'CASE-2025-003',
        reference: 'TVN-QT-4001',
        currentVersion: 1,
        createdAt: '2025-01-16T10:00:00Z',
        updatedAt: '2025-01-16T10:00:00Z',
        versions: [
            {
                id: 'QUO-V1-004',
                versionNumber: 1,
                status: 'Sent',
                preparedBy: 'Super Admin',
                preparedDate: '2025-01-16',
                expiryDate: '2025-02-05',
                customerInfo: {
                    customerName: 'Leisure Groups Ltd',
                    companyName: 'Leisure Groups Ltd',
                    email: 'bookings@leisuregroups.co.uk',
                    phone: '+44 20 7123 4567',
                    nationality: 'British',
                    groupType: 'Group'
                },
                programOverview: {
                    title: 'Classical Egypt Group Tour (15+1 FOC)',
                    packageCode: 'GRP-CLS-10D',
                    packageType: 'Cultural Group',
                    destinations: ['Cairo', 'Luxor', 'Aswan'],
                    citiesCovered: ['Cairo', 'Luxor', 'Aswan', 'Abu Simbel'],
                    nights: 9,
                    season: 'Autumn 2025',
                    description: 'Full classical tour for leisure groups.',
                    highlights: ['Private Abu Simbel Trip', 'Felucca Sailing', 'Karnak Sound & Light']
                },
                inclusions: ['9 Nights 4-star Hotels', 'Private Coach', 'Half Board', 'Licensed Guide'],
                exclusions: ['International Flights', 'Tips'],
                itinerary: [
                    { day: 1, title: 'Arrival in Cairo', route: 'Airport - Hotel', city: 'Cairo', description: 'Transfer to hotel and welcome briefing.', meals: ['D'] }
                ],
                costing: [
                    { id: 'C1', name: 'Hotels HB', category: 'Accommodation', city: 'Various', rate: 85, currency: 'USD', pricingType: 'Per Night', quantity: 16, nights: 9, totalCost: 12240 }
                ],
                pricing: {
                    totalAccommodationCost: 12240, totalSightseeingCost: 2000, totalTransferCost: 3500, totalMealsCost: 0, totalServiceCost: 1500, totalOptionalCost: 0,
                    grandTotalCost: 19240, costPerPerson: 1202.5, markupType: 'Percentage', markupValue: 12, profitAmount: 2308.8, totalSellingPrice: 21548.8, sellingPricePerPerson: 1346.8,
                    currency: 'USD', exchangeRate: 1
                },
                terms: '15+1 FOC on half twin basis.'
            }
        ]
    }
];

export const mockStaff = [
    'Super Admin',
    'Mahmoud Khalil',
    'Layla Ramadan',
    'Sami Youssef',
    'Mona Zaki'
];
