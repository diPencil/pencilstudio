import { OmnichannelInboxFilters } from './src/components/omnichannel/inbox/OmnichannelInboxFilters';
import * as OmnichannelConversationListModule from './src/components/omnichannel/inbox/OmnichannelConversationList';
import * as OmnichannelConversationWorkspaceModule from './src/components/omnichannel/inbox/OmnichannelConversationWorkspace';
import * as OmnichannelCustomerContextPanelModule from './src/components/omnichannel/inbox/OmnichannelCustomerContextPanel';
import * as OmnichannelConversionModalModule from './src/components/omnichannel/inbox/OmnichannelConversionModal';
import * as OmnichannelInboxPageModule from './src/components/omnichannel/OmnichannelInboxPage';

console.log("OmnichannelConversationListModule keys:", Object.keys(OmnichannelConversationListModule));
console.log("OmnichannelInboxPageModule keys:", Object.keys(OmnichannelInboxPageModule));
