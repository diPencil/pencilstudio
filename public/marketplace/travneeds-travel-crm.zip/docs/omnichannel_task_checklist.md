# Omnichannel Module Task Checklist

Status: Phase 3 full Omnichannel surface implementation in progress. Core foundations and inbox workspace are complete.

## Preflight

- [x] Run `git status --short` before any work.
- [x] Confirm clean working tree.
- [x] Review `wireframe_reference/omnichannel`.
- [x] Review current routes in `src/App.tsx`.
- [x] Review sidebar/navigation in `src/components/layout/Sidebar.tsx`.
- [x] Review relevant existing modules and mock data for Leads, Customers, Sales cases, Reservations, Quotations, and Support tickets.
- [x] Create implementation plan artifact.
- [x] Create task checklist artifact.

## Phase 1: Foundations

- [x] Create `src/types/omnichannel.ts`.
- [x] Create `src/services/omnichannelMockData.ts`.
- [x] Create `src/utils/omnichannelMetrics.ts`.
- [x] Create `src/utils/omnichannelFilters.ts`.
- [x] Create `src/utils/omnichannelLinks.ts`.
- [x] Add `omnichannel.*` localization keys to English messages.
- [x] Add mirrored Arabic `omnichannel.*` localization keys.
- [x] Add Omnichannel `nav.*` keys.
- [x] Add Omnichannel routes to `src/App.tsx`.
- [x] Add Omnichannel sidebar group/subitems.
- [x] Create shared module shell/tabs/metric/badge/filter components.

## Phase 2: Unified Inbox And Conversation Workspace

- [x] Build `/omnichannel/inbox`.
- [x] Build `/omnichannel/inbox/:conversationId` selected conversation behavior.
- [x] Add all-conversation inbox list.
- [x] Add channel filters.
- [x] Add unread/assigned/open/pending/closed filters.
- [x] Add priority and SLA indicators.
- [x] Add search and tags filtering.
- [x] Add conversation list with assigned staff and last message preview.
- [x] Add message thread.
- [x] Add channel badge.
- [x] Add customer/lead profile panel.
- [x] Add internal notes.
- [x] Add quick replies/templates.
- [x] Add attachment mock controls.
- [x] Add assign staff control.
- [x] Add status change control.
- [x] Add tag edit control.
- [x] Add mock conversion to lead/customer/ticket/case.
- [x] Add mock linking to reservation/quotation/sales case.

### Phase 3A Summary

- Added conversion actions for lead, customer, ticket, case, and existing-record linking inside the inbox workspace.
- Added a mock conversion modal with validation, staff/team assignment, notes, and channel identity context.
- Added linked-record metadata cards, unlink/restore actions, and a conversion activity timeline.
- Added frontend-only local state updates for new mock records and audit events without backend integration.

## Phase 3B: Full Omnichannel Surface Build Pass

- [x] Build `/omnichannel`.
- [x] Add dashboard KPIs.
- [x] Add channel performance section.
- [x] Add SLA and queue health.
- [x] Add staff performance summary.
- [x] Add conversion funnel.
- [x] Add attention-required alerts.
- [x] Add pending handoffs panel.
- [x] Build `/omnichannel/conversations`.
- [x] Add conversations summary metrics.
- [x] Add conversations filters.
- [x] Add conversations table.
- [x] Add bulk assign/status/tag mock actions.
- [x] Build `/omnichannel/channels`.
- [x] Add WhatsApp channel card.
- [x] Add WhatsApp Business/API channel card.
- [x] Add Facebook Messenger channel card.
- [x] Add Instagram DMs channel card.
- [x] Add Instagram comments channel card.
- [x] Add website live chat channel card.
- [x] Add email channel card.
- [x] Add SMS channel card.
- [x] Add phone/call logs channel card.
- [x] Add future channels section.
- [x] Add connection status mock.
- [x] Add sync status mock.
- [x] Add channel health panel.
- [x] Add channel owners/team metadata.
- [x] Add sync/webhook logs mock.
- [x] Add channel configuration modal.
- [x] Build `/omnichannel/routing`.
- [x] Add routing rules list and simulator.
- [x] Build `/omnichannel/templates`.
- [x] Add template categories.
- [x] Add channel-specific template filters.
- [x] Add approval status mock.
- [x] Add variable display/editing.
- [x] Add Arabic and English templates.
- [x] Add usage count.
- [x] Build `/omnichannel/tags`.
- [x] Add reusable tags, segments, priority labels, and SLA labels.
- [x] Build `/omnichannel/automation`.
- [x] Add assignment rules.
- [x] Add business hours references.
- [x] Add escalation rules.
- [x] Add auto-tagging.
- [x] Add auto-replies mock.
- [x] Build `/omnichannel/sla`.
- [x] Add SLA simulator.
- [x] Add SLA policy cards/table.
- [x] Add queue and business-hours summaries.
- [x] Add breach/escalation mock actions.
- [x] Build `/omnichannel/team`.
- [x] Add team workload cards and supervisor summary.
- [x] Build `/omnichannel/analytics`.
- [x] Add conversations by channel.
- [x] Add response time analytics.
- [x] Add SLA breach analytics.
- [x] Add staff performance analytics.
- [x] Add conversion analytics from conversation to lead/booking/case.
- [x] Add channel health analytics.
- [x] Build `/omnichannel/activity`.
- [x] Add audit log filters for activity center.
- [x] Build `/omnichannel/settings`.
- [x] Add frontend-only settings controls and mock notices.
- [x] Build `/omnichannel/broadcasts`.
- [x] Add outbound campaign planning mock surface.

### Phase 3B Summary

- Replaced the remaining Omnichannel placeholders with Travneeds-native dashboard, channels, routing, templates, tags, automation, SLA, team, analytics, activity, settings, and broadcast surfaces.
- Added a shared Omnichannel module shell, cross-page secondary navigation, reusable section/stat presentation helpers, and typed navigation label maps.
- Expanded Omnichannel mock data for dashboard snapshots, channel configuration, routing simulations, automation activity, labels, workload, scheduled reports, settings, activity logs, and broadcasts.
- Localized the new UI surface in both English and Arabic, including new navigation items and action labels for RTL-ready enterprise layouts.

## Deep Internal UX + Button Logic Pass

- [x] Add shared Omnichannel interaction helpers for drawers, confirmations, notices, empty states, and loading states.
- [x] Make dashboard cards, refresh/export actions, range switchers, escalations, and drill-down drawers interactive.
- [x] Make conversation management filters, bulk actions, row actions, audit modal, close/reopen, transfer, and tag toggles interactive.
- [x] Make channel connect/configure/pause/resume/test/sync/reconnect/log/health flows interactive with mock feedback.
- [x] Add routing rule create/edit/duplicate/delete/enable-disable/reorder flows and simulation results.
- [x] Add automation create/edit/duplicate/delete/enable-disable/run-now/history flows and validation states.
- [x] Add template search/filter/create/edit/duplicate/archive/approval/preview flows and unsaved-state warnings.
- [x] Add tag create/delete/duplicate/group/color/detail flows and duplicate validation.
- [x] Add SLA policy create/edit/duplicate/delete/enable-disable flows, simulator logic, and validation for impossible times.
- [x] Add team workload filters, online/busy/offline toggles, profile drawer, and rebalance interactions.
- [x] Add analytics filter/loading/export/schedule/drill-down flows and no-data state.
- [x] Add activity filters, timeline/table switching, detail drawer, copy-event action, export action, and no-results state.
- [x] Add settings dirty-state indication, reset/save flows, and closing-reason add/delete interactions.
- [x] Add broadcast planning create/schedule/duplicate/cancel/delivery-state flows and validation.
- [x] Deepen inbox composer, message delivery transitions, and note archive/delete behavior beyond the existing Phase 2/3A workspace foundation.

### Inbox Deepening Summary

- Added local mock delivery progression for outbound inbox messages with sending, sent, delivered, read, and failed states plus retry behavior.
- Wired composer internals for queued attachments, draft clearing, loading feedback, quick-reply insertion, and attachment-only sends.
- Completed internal note lifecycle with validation, edit, archive, restore, and confirmed delete actions.
- Closed the focused inbox button audit so visible inbox/workspace actions now perform mock state changes, open an interaction surface, or show clear feedback.

## Logic Integration QA Pass

- [x] Audit Omnichannel routes for shared mock-data, helper, and local-state integration boundaries.
- [x] Add shared frontend-only Omnichannel integration helpers for queue, SLA, routing, broadcast, channel, tag, and staffing logic.
- [x] Connect dashboard summary cards and drawers to derived conversation, queue, staff, and conversion data where feasible.
- [x] Connect analytics channel and conversion surfaces to derived conversation data where feasible.
- [x] Connect routing simulator to shared rule evaluation logic.
- [x] Connect broadcast planning validation to shared template eligibility logic.
- [x] Connect tag usage and delete validation to actual mock conversation references.
- [x] Connect team reassignment warnings to shared staffing eligibility logic.
- [x] Document page-local or static snapshot flows that still do not share runtime state across routes.
- [x] Run build and source-level verification after the integration audit pass.

### Logic Integration QA Summary

- Added `src/utils/omnichannelIntegration.ts` to centralize reusable frontend-only derivation, validation, and simulation logic without introducing a new store or backend dependency.
- Rewired dashboard, analytics, routing, tags, team, SLA, channels, automation, and broadcasts pages to consume shared Omnichannel helper logic where the current architecture allowed it.
- Confirmed that several interactions still remain page-local because Omnichannel pages seed isolated `useState` from shared mock data rather than a cross-route runtime store.
- Captured those current boundaries in the logic integration audit artifact so the next hardening pass can target true shared state if needed.

## Shared Mock Store Implementation

- [x] Create `src/components/omnichannel/store/OmnichannelMockStore.tsx` Context & Hook.
- [x] Wire route-level provider wrapper in `src/App.tsx`.
- [x] Migrate `/omnichannel/dashboard` to consume global store selectors.
- [x] Migrate `/omnichannel/inbox` to read and dispatch note/message mutations to global store.
- [x] Migrate `/omnichannel/conversations` to use store conversations and run bulk actions.
- [x] Migrate `/omnichannel/channels` to read/write connection settings via store actions.
- [x] Migrate `/omnichannel/routing` to manage rules and simulate routing using store rules.
- [x] Migrate `/omnichannel/automation` to manage automation rules and trigger "run now" history updates.
- [x] Migrate `/omnichannel/templates` to read and update quick replies in store.
- [x] Migrate `/omnichannel/tags` to read labels and enforce usage validation checks on live store conversations.
- [x] Migrate `/omnichannel/sla` to manage policies and simulate SLA breaches.
- [x] Migrate `/omnichannel/team` to bind online status cycles and workload rebalancing.
- [x] Migrate `/omnichannel/analytics` to bind reporting schedules and charts.
- [x] Migrate `/omnichannel/activity` to consume auto-logged store audit events.
- [x] Migrate `/omnichannel/settings` to save/reset draft snapshot options.
- [x] Migrate `/omnichannel/broadcasts` to schedule, duplicate, and validate campaigns.
- [x] Validate build correctness via Vite production compile step.

## Runtime Self-Test Harness

- [x] Create self-test assertion helper library `src/utils/omnichannelSelfTests.ts`.
- [x] Create React component `src/components/omnichannel/OmnichannelDiagnosticsPage.tsx` with summary cards, table list, and activity log console stream.
- [x] Expose sub-navigation route `/omnichannel/diagnostics` inside `src/App.tsx`.
- [x] Link to navbar sub-navigation inside `src/components/omnichannel/omnichannelNavigation.ts`.
- [x] Localize all UI terms in English messages file.
- [x] Localize all UI terms in Arabic messages file.
- [x] Run Vite compiler build to confirm compilation compatibility.

## Phase 6: Arabic/RTL And Verification

- [ ] Verify every Omnichannel route in English.
- [ ] Verify every Omnichannel route in Arabic.
- [ ] Confirm Arabic layout is visually mirrored, not only translated.
- [ ] Confirm inbox side panels swap cleanly in RTL.
- [ ] Confirm tables use logical alignment and isolated horizontal scroll wrappers.
- [ ] Confirm no page-level overflow.
- [ ] Add `.bidi-isolate` / `.ltr-value` for IDs, phones, emails, dates, channel handles, timers, codes, and template variables.
- [ ] Confirm Arabic labels fit buttons, cards, tables, drawers, and modals.
- [ ] Run typecheck/build after implementation approval.

## Exclusions To Preserve

- [ ] Do not add backend/API logic.
- [ ] Do not add real WhatsApp/Facebook/Instagram integrations.
- [ ] Do not add database logic.
- [ ] Do not change auth.
- [ ] Do not touch `vite.config.ts`.
- [ ] Do not change package manager.
- [ ] Do not run install commands.
- [ ] Do not add `eslint-disable`.
- [ ] Do not use `any` or `as any`.
- [ ] Do not commit unless explicitly requested.
