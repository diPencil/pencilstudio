# Implementation Plan - Parity Fix Pass 2 (Should-Fix)

This plan outlines the design and implementation details for **Should-Fix Pass 2** in the Travneeds System.

## User Review Required

> [!IMPORTANT]
> - All calculations will remain 100% frontend-only.
> - Data state (FOC checkboxes, selected scenario) is saved in the wizard session state and preserved upon clicking "Save Draft".
> - The package-manager and lockfiles (`package-lock.json`) will not be modified or deleted.

---

## Proposed Changes

### 1. Types Extension

#### [MODIFY] [quotation.ts](file:///d:/Development/CRM%20Travel/TravneedsSystem/src/types/quotation.ts)
- Add `isComplimentary?: boolean` to `QuotationServiceLine`.
- Add `appliedScenario?: 'Budget' | 'Standard' | 'Premium' | 'Custom'` to `QuotationPricingSummary`.

---

### 2. Calculation Engine Upgrades

#### [MODIFY] [quotationCalculations.ts](file:///d:/Development/CRM%20Travel/TravneedsSystem/src/utils/quotationCalculations.ts)
- Update `calculateServiceLineTotals` to force `totalSelling = 0` if `isComplimentary` is true. This automatically reduces individual service line profit to `-totalCost` and margin to `0%`.
- Update `calculatePricingFromServiceLines` to compute the `baseMarkup` only on the cost of non-complimentary items. The cost of complimentary items is still included in `grandTotalCost` but is excluded from the customer's selling base.

---

### 3. User Interface Components

#### [MODIFY] [CostingStep.tsx](file:///d:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/CostingStep.tsx)
- Add a "FOC / Free" column with a checkbox in the Selected Services table.
- Display a real-time summary block beneath the Selected Services table showing:
  - Total FOC items.
  - Total FOC cost absorbed.
  - Indicated margin impact warning if FOC cost is high.

#### [MODIFY] [PricingStep.tsx](file:///d:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/PricingStep.tsx)
- Add a **Multi-Scenario Pricing Comparison** panel.
- Compute three scenarios dynamically using the active costing data:
  - **Budget**: 5% markup, 0% discount, 0% commission.
  - **Standard**: 15% markup, 0% discount, 0% commission.
  - **Premium**: 25% markup, 0% discount, 0% commission.
- Show comparison fields: Markup Value, Cost, Selling Price, Gross Profit, Margin, Per-Person Selling, and Status Badges.
- Provide a "Select & Apply" button for each scenario.
- Highlight the active scenario card.
- Add an alert warning if FOC count is excessive or if final profit margins fall below 10%.

#### [MODIFY] [QuotationPreviewPage.tsx](file:///d:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/QuotationPreviewPage.tsx)
- Add a `Complimentary / FOC` badge in the price column for FOC service lines.
- Set the displayed selling price of FOC lines to `$0 (FOC)`.

---

## Verification Plan

### Automated Tests & Verification
- Run production build: `pnpm build`
- Run focused ESLint: `pnpm exec eslint <modified files>`

### Manual Verification Steps
1. Navigate to `/sales/cases/CASE-2025-001/quotations/create`.
2. Add multiple service lines.
3. Toggle "isComplimentary" on one line and check that the Total Selling updates while Cost remains.
4. Open the Pricing step and verify the multi-scenario comparison layout.
5. Click "Apply Scenario" and verify that active totals update instantly.
6. Verify live preview and Save Draft behaviors preserve all configurations.
