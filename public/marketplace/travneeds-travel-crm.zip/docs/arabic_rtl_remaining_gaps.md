# Arabic/RTL Parity Gap Audit Report

This report outlines the remaining gaps in localization and RTL visual formatting within the Travneeds System frontend codebase.

---

> [!NOTE]
> **Emergency Pass 2 Correction Note**:
> - The previous correction targeted the main dashboard component (`src/components/dashboard/Dashboard.tsx`), which was a mismatch.
> - The actual visible page that needed fixing is the Business Intelligence/Reports page (`src/components/reports/ReportsPage.tsx`), as proven by owner screenshots.
> - Parity and RTL visual layouts for `ReportsPage.tsx`, `Sidebar.tsx`, and `Header.tsx` have now been corrected and polished.

---

## 1. Executive Summary of Remaining Gaps
While core modules (Supplier Management, Products & Services, and Quotation Builder) have had localization and RTL foundation frameworks applied, the core **Dashboard** and several secondary components still exhibit hardcoded English values or require layout polish.

---

## 2. Dashboard Gaps (`src/components/dashboard/Dashboard.tsx`)
* **KPI Metric Cards**: Hardcoded labels ("Total Revenue", "Total Bookings", "Confirmations", "Conversion", "Operations", "Efficiency") and trends ("Month", "Week", "Active Now", "Target").
* **Quick Actions**: Hardcoded action button texts ("New Reservation", "Add Lead", "Record Payment", "Create Ticket", "Assign Staff", "View Reports").
* **Charts**:
  * English chart titles ("Revenue Growth Trend", "Lead Distribution") and drop-down filters ("Monthly", "Weekly").
  * Hardcoded Legend values ("Revenue", "Leads").
* **Lists / Feeds**:
  * Hardcoded section headers ("Follow-up Reminders", "Recent System Activity", "View All Tasks", "View All").
  * Hardcoded task and reminder items, times, and priority status tags.
  * Hardcoded system log actions and relative timestamps ("2 mins ago", "1 hour ago", etc.).

---

## 3. Global Shell / Header / Sidebar Gaps
* **Header Components** (`src/components/layout/Header.tsx`):
  * Mock notifications user descriptions and metadata are in English.
* **Sidebar Layout** (`src/components/layout/Sidebar.tsx`):
  * Well-structured with translation key mappings, but some mock navigation items (e.g. support, roles, overtime) still require translation coverage under the keys.

---

## 4. Remaining Non-Core Pages Needing Arabic
The following module files are currently hardcoded in English and need to be localized in subsequent phases:

* **Leads [COMPLETED - PASS 1]**:
  * `src/components/leads/LeadsPage.tsx`
  * `src/components/leads/NewLeadPage.tsx`
  * `src/components/leads/AddLeadModal.tsx`
  * `src/components/leads/EditLeadModal.tsx`
  * `src/components/leads/ViewLeadModal.tsx`
  * `src/components/leads/MessageModal.tsx`
  * `src/components/leads/AssignLeadModal.tsx`
  * `src/components/leads/ConvertLeadModal.tsx`
* **Customers [COMPLETED - PASS 2]**:
  * `src/components/customers/CustomersPage.tsx`
  * `src/components/customers/NewCustomerPage.tsx`
  * `src/components/customers/CorporateAccountsPage.tsx`
  * Modals (Add, Edit, View Customer, Booking, Activity, Export, Bulk Email, Corporate details/actions, preferences, VIP settings) fully localized and RTL polished.
* **Sales [COMPLETED - PASS 3]**:
  * `src/components/sales/SalesPage.tsx`
  * `src/components/sales/NewCasePage.tsx`
  * `src/components/sales/CaseDetailsPage.tsx`
  * `src/components/sales/TodayTasksPage.tsx`
  * `src/components/sales/CreateCaseModal.tsx`
  * `src/components/sales/ViewCaseModal.tsx`
  * `src/components/sales/NotesModal.tsx`
  * `src/components/sales/ScheduleModal.tsx`
  * `src/components/sales/TodaysTasksModal.tsx`
  * `src/components/sales/TaskModal.tsx`
  * `src/components/sales/QuotationStatusBadge.tsx`
  * Modals, badges, forms, headers, pipeline cards, and activity feeds fully localized and RTL-polished.
* **Reservations [COMPLETED - PASS 4]**:
  * `src/components/reservations/ReservationsPage.tsx`
  * `src/components/reservations/NewReservationPage.tsx`
  * `src/components/reservations/AddReservationModal.tsx`
  * `src/components/reservations/ViewReservationModal.tsx`
  * `src/components/reservations/UploadDocumentModal.tsx`
  * `src/components/reservations/TasksModal.tsx`
  * `src/components/reservations/NotesModal.tsx`
  * Modals, forms, tables, check lists, summary cards, and activity logs fully localized and RTL-polished. Supplier files were explicitly excluded and left untouched.
* **Finance & Accounting [COMPLETED - PASS 5]**:
  * `src/components/finance/FinancePage.tsx`
  * `src/components/finance/FinancialReportsPage.tsx`
  * `src/components/finance/RecordPaymentPage.tsx`
  * Modals (Export, Financial Reports, Internal Chat, Issue Invoice, Record Payment, Supplier Invoice, View Payment) fully localized, RTL-polished, and strictly typed.
* **Operations**:
  * `src/components/operations/OperationsPage.tsx`
  * `src/components/operations/AddOptionalServicePage.tsx`
  * `src/components/operations/TodaysSchedulePage.tsx`
  * `src/components/operations/CalendarViewPage.tsx`
* **Reports**:
  * `src/components/reports/ReportsPage.tsx`
  * `src/components/reports/CustomReportsPage.tsx`
* **Attendance & HR**:
  * `src/components/attendance/AttendancePage.tsx`
  * `src/components/attendance/LeaveRequestsPage.tsx`
  * `src/components/attendance/OvertimeLogs.tsx`
* **Support & Help Center**:
  * `src/components/support/HelpCenter.tsx`
  * `src/components/support/NewTicketPage.tsx`
  * `src/components/support/SupportPage.tsx`
  * `src/components/support/KnowledgeBase.tsx`
* **User Management**:
  * `src/components/users/UsersPage.tsx`
  * `src/components/users/InviteUserPage.tsx`
  * `src/components/users/RolesPermissions.tsx`
  * `src/components/users/SystemLogs.tsx`
* **Authentication**:
  * `src/components/auth/LoginPage.tsx`
* **Landing / Marketing**:
  * `src/components/landing/LandingPage.tsx`

---

## 5. Recommended Next Fix Order
1. **Dashboard & Metrics (Emergency Pass 1)**: Correct English labels and layout structure to establish visual parity.
2. **Leads & Customers (Core Sales)**: Localize lead pipelines, customer logs, and corporate accounts.
3. **Finance & Operations**: Localize schedule boards, transaction sheets, and calendar overlays.
4. **Attendance, Support & System Admin**: Finalize administrative directories, leave requests, support logs, and auth pages.
