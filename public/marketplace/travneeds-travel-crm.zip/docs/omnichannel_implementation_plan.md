# Omnichannel Module Implementation Plan

Planning status: Ready for owner review

Scope: frontend-only mock Omnichannel Communication module for the first complete Travneeds frontend build.

## Clean Working Tree Gate

Command run first:

```powershell
git status --short
```

Result: clean working tree. No modified files were reported before planning began.

## Existing Wireframe References

Found under `wireframe_reference/omnichannel`:

- `README.md`
- `omnichannel_dashboard_wireframe.html`
- `omnichannel_unified_inbox_wireframe.html`
- `omnichannel_conversations_wireframe.html`
- `omnichannel_channels_management_wireframe.html`

### Wireframe Summary

`README.md`
- Defines the Omnichannel purpose: centralized workspace for WhatsApp, Facebook Messenger, Instagram, website chat, email, SMS, and phone/call logs.
- Lists ten intended pages: dashboard, unified inbox, conversations, channels, templates, automations, SLA queues, team performance, analytics, and settings.

`omnichannel_dashboard_wireframe.html`
- Dashboard with top KPIs for total/open/pending conversations, SLA breaches, average first response, unassigned queues, and conversions.
- Channel performance table for WhatsApp, Facebook Messenger, Instagram DMs/comments, website live chat, email, SMS, and phone logs.
- SLA and queue health cards for Sales, Operations, Support, VIP, Complaints, and Unassigned queues.
- Staff performance table, conversion funnel, attention-required list, recent conversations table, health side panel, quick actions, and relationship note.

`omnichannel_unified_inbox_wireframe.html`
- Unified inbox shell with channel tabs, advanced filters, search, unread/unassigned/SLA-risk filters, and conversation cards.
- Three-column workspace: conversation list, message thread/composer, and customer/lead context panel.
- Thread includes system events, customer/agent messages, internal notes, template-sent markers, quotation-created events, assign/close/escalate actions, templates, attachments, internal-note toggle, and send action.
- Context panel includes customer/lead details, linked lead/quotation/booking/ticket records, travel interest, tags, quick actions, and SLA/queue controls.

`omnichannel_conversations_wireframe.html`
- Conversations management list with summary metrics, channel tabs, table filters, bulk assign/status/tag actions, and audit-style table.
- Table columns include conversation ID, customer/lead, channel, last message preview, status, priority, queue, assigned agent, SLA status, linked lead, linked quotation, linked booking, last activity, and actions.
- Side panels include tags/segments, SLA-risk conversations, status definitions, conversation health, quick actions, and activity events.

`omnichannel_channels_management_wireframe.html`
- Channels management page with Add Channel, Sync Channels, export, sync logs, webhook, and refresh actions.
- Status cards for connected/active channels, sync issues, messages today, failed webhooks, templates enabled, queues linked, and automations linked.
- Channel cards/table for WhatsApp Business API, Facebook Messenger, Instagram DMs/comments, website live chat, email, SMS, and phone/call logs.
- Detail panels for WhatsApp Business API, social channels, email/SMS/phone logs, sync/webhook logs, routing rules, permissions, management rules, empty states, channel health, alerts, quick actions, and activity.

## Missing Wireframe Screens

The README names these screens, but no matching HTML files currently exist:

- `omnichannel_templates_wireframe.html`
- `omnichannel_automations_wireframe.html`
- `omnichannel_sla_queues_wireframe.html`
- `omnichannel_team_performance_wireframe.html`
- `omnichannel_analytics_wireframe.html`
- `omnichannel_settings_wireframe.html`

Implementation should still include the requested product scope for templates, routing/SLA, and analytics using the README plus the dashboard/channel/inbox patterns as reference.

## Current App Structure Findings

Routes are declared in `src/App.tsx` inside one protected layout route.

Current relevant routes:

- Leads: `/leads`, `/leads/new`
- Customers: `/customers`, `/customers/corporate`, `/customers/new`
- Sales cases: `/sales`, `/sales/tasks`, `/sales/new-case`, `/sales/cases`, `/sales/cases/new`, `/sales/cases/:caseId`
- Quotations: `/sales/cases/:caseId/quotations/*`
- Reservations/bookings: `/reservations`, `/reservations/new`, `/reservations/tracker`, `/reservations/suppliers/:supplierId`
- Support tickets: `/help-center/tickets`, plus `/help-center/new`

Navigation is defined in `src/components/layout/Sidebar.tsx` through `navigationGroups` and localized `nav.*` keys.

Localization is centralized in:

- `src/localization/messages/en.ts`
- `src/localization/messages/ar.ts`
- `src/localization/messages/index.ts`
- `src/localization/LocaleProvider.tsx`
- `src/localization/direction.ts`

Existing RTL utilities include `.bidi-isolate`, `.ltr-value`, `.logical-start`, `.logical-end`, `pickDirectionalValue`, and direction-aware layout shell handling.

## Proposed Routes

Add these protected routes in `src/App.tsx`:

- `/omnichannel` -> `OmnichannelDashboardPage`
- `/omnichannel/inbox` -> `OmnichannelInboxPage`
- `/omnichannel/inbox/:conversationId` -> `OmnichannelInboxPage`
- `/omnichannel/conversations` -> `OmnichannelConversationsPage`
- `/omnichannel/channels` -> `OmnichannelChannelsPage`
- `/omnichannel/templates` -> `OmnichannelTemplatesPage`
- `/omnichannel/automation` -> `OmnichannelAutomationPage`
- `/omnichannel/sla` -> `OmnichannelSlaPage`
- `/omnichannel/analytics` -> `OmnichannelAnalyticsPage`
- `/omnichannel/settings` -> `OmnichannelSettingsPage`

Route behavior:

- `/omnichannel/inbox/:conversationId` opens the selected conversation in the same inbox/workspace page.
- Mock link actions navigate to existing module routes where route targets exist.
- Actions that create/link records remain local mock state until backend scope is approved.

## Proposed Files And Components

### Pages

- `src/components/omnichannel/OmnichannelDashboardPage.tsx`
- `src/components/omnichannel/OmnichannelInboxPage.tsx`
- `src/components/omnichannel/OmnichannelConversationsPage.tsx`
- `src/components/omnichannel/OmnichannelChannelsPage.tsx`
- `src/components/omnichannel/OmnichannelTemplatesPage.tsx`
- `src/components/omnichannel/OmnichannelAutomationPage.tsx`
- `src/components/omnichannel/OmnichannelSlaPage.tsx`
- `src/components/omnichannel/OmnichannelAnalyticsPage.tsx`
- `src/components/omnichannel/OmnichannelSettingsPage.tsx`

### Shared Module Components

- `src/components/omnichannel/components/OmnichannelPageTabs.tsx`
- `src/components/omnichannel/components/OmnichannelMetricGrid.tsx`
- `src/components/omnichannel/components/ChannelBadge.tsx`
- `src/components/omnichannel/components/SlaIndicator.tsx`
- `src/components/omnichannel/components/PriorityBadge.tsx`
- `src/components/omnichannel/components/ConversationStatusBadge.tsx`
- `src/components/omnichannel/components/ConversationFilters.tsx`
- `src/components/omnichannel/components/ConversationList.tsx`
- `src/components/omnichannel/components/ConversationListItem.tsx`
- `src/components/omnichannel/components/ConversationThread.tsx`
- `src/components/omnichannel/components/MessageBubble.tsx`
- `src/components/omnichannel/components/MessageComposer.tsx`
- `src/components/omnichannel/components/CustomerContextPanel.tsx`
- `src/components/omnichannel/components/LinkedRecordPanel.tsx`
- `src/components/omnichannel/components/QuickReplyPicker.tsx`
- `src/components/omnichannel/components/TagEditor.tsx`
- `src/components/omnichannel/components/AssignmentControl.tsx`
- `src/components/omnichannel/components/ChannelHealthCard.tsx`
- `src/components/omnichannel/components/ChannelConfigDrawer.tsx`
- `src/components/omnichannel/components/TemplateEditorDrawer.tsx`
- `src/components/omnichannel/components/AutomationRuleCard.tsx`
- `src/components/omnichannel/components/SlaQueueCard.tsx`
- `src/components/omnichannel/components/MockActionModal.tsx`

### Data, Types, And Helpers

- `src/types/omnichannel.ts`
- `src/services/omnichannelMockData.ts`
- `src/utils/omnichannelMetrics.ts`
- `src/utils/omnichannelFilters.ts`
- `src/utils/omnichannelLinks.ts`

## Mock Data And TypeScript Interface Plan

Keep omnichannel mock data separate from existing `src/services/mockData.ts` at first, importing current mock records for relationship options where useful.

Core interfaces in `src/types/omnichannel.ts`:

- `OmnichannelChannelType = 'whatsapp' | 'whatsapp_business' | 'facebook_messenger' | 'instagram_dm' | 'instagram_comment' | 'website_chat' | 'email' | 'sms' | 'phone' | 'future'`
- `OmnichannelConversationStatus = 'open' | 'pending' | 'waiting_agent' | 'waiting_customer' | 'closed'`
- `OmnichannelPriority = 'low' | 'normal' | 'high' | 'urgent'`
- `OmnichannelSlaStatus = 'ok' | 'at_risk' | 'breached' | 'paused' | 'none'`
- `OmnichannelLinkedRecordType = 'lead' | 'customer' | 'reservation' | 'quotation' | 'sales_case' | 'support_ticket'`
- `OmnichannelChannel`
- `OmnichannelChannelOwner`
- `OmnichannelConversation`
- `OmnichannelMessage`
- `OmnichannelParticipant`
- `OmnichannelAttachment`
- `OmnichannelInternalNote`
- `OmnichannelTag`
- `OmnichannelQuickReplyTemplate`
- `OmnichannelTemplateVariable`
- `OmnichannelAutomationRule`
- `OmnichannelRoutingRule`
- `OmnichannelBusinessHours`
- `OmnichannelSlaPolicy`
- `OmnichannelQueue`
- `OmnichannelStaffPerformance`
- `OmnichannelAnalyticsSummary`
- `OmnichannelMockAction`

Mock datasets in `src/services/omnichannelMockData.ts`:

- `mockOmnichannelChannels`
- `mockOmnichannelConversations`
- `mockOmnichannelMessages`
- `mockOmnichannelTags`
- `mockOmnichannelTemplates`
- `mockOmnichannelAutomationRules`
- `mockOmnichannelRoutingRules`
- `mockOmnichannelSlaPolicies`
- `mockOmnichannelQueues`
- `mockOmnichannelStaffPerformance`
- `mockOmnichannelAnalytics`

Mock state actions:

- filter conversations by channel/status/assignment/priority/SLA/tag/search
- select conversation
- send mock reply
- add internal note
- attach mock file metadata
- assign staff
- change status
- add/remove tags
- create/link mock lead, customer, support ticket, sales case, reservation, quotation
- sync/test/configure channel as local mock state
- create/edit/deactivate template
- enable/disable automation and routing rules

No `any` or `as any` should be used. Use explicit unions, discriminated unions, `Record<Union, Value>`, and typed helper return values.

## Sidebar And Navigation Plan

Add a new sidebar group between Sales Department and Reservation Department, or as its own operational group if owner prefers:

- Group title key: `nav.communicationDepartment`
- Parent item:
  - id: `omnichannel`
  - icon: `MessageSquare` or `MessagesSquare` from `lucide-react`
  - label key: `nav.omnichannel`
  - href: `/omnichannel`
- Subitems:
  - `nav.omnichannelDashboard` -> `/omnichannel`
  - `nav.omnichannelInbox` -> `/omnichannel/inbox`
  - `nav.omnichannelConversations` -> `/omnichannel/conversations`
  - `nav.omnichannelChannels` -> `/omnichannel/channels`
  - `nav.omnichannelTemplates` -> `/omnichannel/templates`
  - `nav.omnichannelAutomation` -> `/omnichannel/automation`
  - `nav.omnichannelSla` -> `/omnichannel/sla`
  - `nav.omnichannelAnalytics` -> `/omnichannel/analytics`
  - `nav.omnichannelSettings` -> `/omnichannel/settings`

## Localization Namespace

Add `omnichannel.*` keys to `enMessages`, then mirror in `arMessages`.

Key groups:

- `omnichannel.common.*`
- `omnichannel.dashboard.*`
- `omnichannel.inbox.*`
- `omnichannel.conversations.*`
- `omnichannel.channels.*`
- `omnichannel.templates.*`
- `omnichannel.automation.*`
- `omnichannel.sla.*`
- `omnichannel.analytics.*`
- `omnichannel.settings.*`
- `omnichannel.status.*`
- `omnichannel.priority.*`
- `omnichannel.channel.*`
- `omnichannel.actions.*`
- `omnichannel.empty.*`
- `omnichannel.mockNotice.*`

Add `nav.*` keys for the sidebar entries listed above.

## Arabic And RTL Plan

Arabic must be a true mirror, not only translated text.

Implementation requirements:

- Use `useLocale()` for `direction`, `isRTL`, and translation keys in every omnichannel page.
- Use `pickDirectionalValue` for left/right drawer placement, icon direction, menu alignment, side panels, and inbox column ordering.
- Mirror inbox workspace: in RTL, conversation list and customer context panel should swap sides while the message thread remains central and readable.
- Use `style={{ direction }}` on wide tables, with `.logical-start` and `.logical-end` on cells.
- Wrap IDs, phone numbers, emails, channel handles, dates, timestamps, SLA timers, queue codes, template variables, quotation IDs, booking IDs, and conversation IDs with `.bidi-isolate`; use `.ltr-value` for alphanumeric identifiers and phone/email/code values.
- Ensure all horizontal overflow is confined to table wrappers, not page-level overflow.
- Avoid fixed-width button text that breaks Arabic. Use responsive wrapping or icon buttons with tooltips where appropriate.
- Use direction-aware action order in toolbars and drawers.
- Validate every page visually in both locale modes during implementation without browser automation for this planning pass.

## Integration Plan

Mock links/actions to existing modules:

- Leads:
  - Link to `/leads`
  - Create/link mock lead from conversation context
  - Use existing `mockLeads` fields for option labels: ID, full name, email, phone, source, status, priority, staff
- Customers:
  - Link to `/customers`
  - Create/link mock customer from conversation context
  - Use existing `mockCustomers` fields for ID, name, email, phone, type, contact method
- Sales cases:
  - Link to `/sales/cases/:caseId` when a linked case ID exists
  - Create/link mock sales case from conversation
  - Surface related quotations in case context
- Reservations/bookings:
  - Link to `/reservations`
  - Link mock booking IDs to reservation list context until detail routes exist
  - Use booking IDs from `mockReservations`
- Quotations:
  - Link to `/sales/cases/:caseId/quotations/:quotationId/preview` when `caseId` and `quotationId` are known
  - Create quotation mock action should route to existing quotation builder only when a case context exists
- Support tickets:
  - Link to `/help-center/tickets`
  - Create/link mock support ticket from conversation context
  - Use existing `mockTickets`

All conversion/link actions remain mock UI state and toast/modal confirmations only.

## Implementation Phases

### Phase 1: Foundations

- Add omnichannel types, mock data, metrics/filter/link helpers.
- Add localization keys in `omnichannel.*` and `nav.*`.
- Add routes and sidebar entries.
- Add shared badges, tabs, metrics, filters, and mock action modal.

### Phase 2: Unified Inbox And Workspace

- Build `/omnichannel/inbox` and `/omnichannel/inbox/:conversationId`.
- Implement channel/status/assignment/priority/SLA/tag/search filters.
- Implement conversation list, message thread, composer, internal notes, quick replies, attachments mock, assignment/status/tags, and customer/lead context panel.
- Add conversion/link mock actions to lead/customer/ticket/case/reservation/quotation.

### Phase 3: Dashboard And Conversations Management

- Build dashboard KPIs, channel performance, SLA queue health, staff performance, conversion funnel, alerts, and recent conversations.
- Build conversations table with bulk assign/status/tag mock actions and side health panels.

### Phase 4: Channels Management

- Build channel status cards, channel grid/table, connection/sync/health states, owner/team metadata, routing summary, sync logs, permissions, and config drawers.
- Include WhatsApp, WhatsApp Business/API, Facebook Messenger, Instagram DMs/comments, website live chat, email, SMS, phone/call logs, and future channels.

### Phase 5: Templates, Automation, SLA, Analytics, Settings

- Build templates/quick replies with categories, channel-specific support, approval status, variables, Arabic/English content, and usage counts.
- Build automation/routing/SLA with assignment rules, business hours, escalation rules, SLA timers, auto-tagging, and auto-replies mock.
- Build analytics for conversations by channel, response time, SLA breaches, staff performance, conversion, and channel health.
- Build settings as frontend-only controls for mock preferences.

### Phase 6: RTL Polish And Verification

- Review every omnichannel page in English and Arabic.
- Check mirrored layout, logical alignment, page overflow, table wrappers, IDs/phones/emails/dates/codes isolation, and Arabic button/card/table fit.
- Run typecheck/build after implementation approval.

## Explicit Exclusions

- No backend work.
- No real WhatsApp, Facebook, Instagram, website chat, email, SMS, phone, webhook, or API integrations.
- No database changes.
- No auth changes.
- No `vite.config.ts` changes.
- No package manager changes.
- No install commands.
- No browser automation or screenshots for this planning pass.
- No commits in this planning pass.

## Owner Approval Question

Ready for owner approval to start Omnichannel implementation: yes.
