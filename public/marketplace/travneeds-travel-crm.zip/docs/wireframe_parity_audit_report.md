# Wireframe Parity Audit Report - Travneeds System

This document provides a strict, screen-by-screen audit of the completed React implementation under `src/` compared to the original wireframe designs located in `wireframe_reference/`.

---

## 1. Executive Summary

### Is the current implementation 1:1 with the original wireframes?
**Functionally equivalent but not 1:1**

* **Supplier Management**: Core profile fields, contact cards, contracts lists, dummy payments, document placeholders, and performance metrics are fully implemented. However, the complex Contract Supplements & Policies (Rules Builder) and operational evaluation QA scorecards are missing. Several separate views are merged into tabs inside the Supplier Profile.
* **Products & Services**: The operational catalog list, status filtering, category management, destinations card, and detail views are present. The Add Product Wizard is adapted as a collapsible sectioned modal rather than a multi-page wizard, and catalog-level rate matrices, cost templates, and pricing rules are missing.
* **Quotation / Pricing / Package Builder**: The day-by-day itinerary builder, costing matrix (with quantity, nights, pax, taxes, adjustments), pricing engine (with markup, discount, commission, manual override), profit analysis warnings, version duplication, and draft proposal preview are fully functional. The only items missing are a dedicated fixed cost center, multi-scenario comparison panel, and complimentary service tagging.

---

## 2. Supplier Management Parity Table

Compare against wireframes in `wireframe_reference/supplier-management/`:

| Original Wireframe Screen/Section | Expected UI Elements | Expected Buttons / Actions | Expected Inputs / Forms | Expected Tables / Cards / Modals | Current Implemented Route / File | Current Status | Notes | Recommendation |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Supplier Dashboard** (`dashboard_wireframe`) | Summary cards, status breakdown, risk/perf overview, quick actions. | Add supplier, track performance, view pending requests. | None (visual summary). | Cards for metrics, list of active partners. | `/reservations` / `ReservationsPage.tsx` & `/reservations/tracker` / `SupplierTrackerPage.tsx` | **Adapted Differently** | Merged dashboard metrics (pending, overdue, top partner) into the Supplier Tracker header. | None; the unified tracker provides excellent administrative UX. |
| **Supplier Directory** (`directory_wireframe`) | Partner table, filters (type, status), search. | Add partner, contact supplier, view profile. | Search, Type Filter, Status Filter. | Supplier listing table. | `/reservations/tracker` / `SupplierTrackerPage.tsx` | **Exact Match** | Provides search, filter by type, status, risk labels, and list of critical requests. | None; fits the requirements perfectly. |
| **Add Supplier / Onboarding** (`add_new_supplier_wireframe`) | Basic details, contacts, type, destinations, payment terms. | Register supplier, cancel onboarding. | Legal Name, Category, Location, Tax ID, Email, Phone, Contract details textbox. | Onboarding form card, KYC info widget. | `/reservations/new-supplier` / `AddSupplierPage.tsx` | **Mostly Matching** | Form is single-page rather than multi-step wizard. Contacts and coverage are simplified. | Accept as-is or add individual contact inputs during onboarding. |
| **Supplier Profile Workspace** (`profile_wireframe`) | Detail workspace for business information, contacts, linked services, activity. | Back to tracker, edit supplier, trigger tab switch. | None (viewing details). | Profile header cards, tab navigation. | `/reservations/suppliers/:supplierId` / `SupplierProfilePage.tsx` | **Exact Match** | Beautiful tabbed UI separating information cleanly. | None; matches very closely. |
| **Overview** (`profile_wireframe` tab) | Business summary, financial highlights, recent activity timeline. | Switch tabs, edit partner. | None. | Business info card, Finance summary card, activity list. | Overview tab in `SupplierProfilePage.tsx` | **Exact Match** | Displays legal name, type, location, and outstanding/total paid metrics. | None. |
| **Contacts** (`profile_wireframe` tab) | List of contacts, email/phone details, active status. | Add contact, remove contact. | Full Name, Role select, Status select, Email, Phone. | Contacts list cards, inline add contact form. | Contacts tab in `SupplierProfilePage.tsx` | **Exact Match** | Implements full mock CRUD for contacts on the profile. | None. |
| **Contracts** (`contracts_wireframe`) | Contract title, validity dates, status, actions. | View details, add new contract. | Title, Start Date, End Date, Status select. | Contracts list, inline add contract form. | Contracts tab in `SupplierProfilePage.tsx` | **Exact Match** | Lists contracts and supports creating draft entries. | None. |
| **Contract Details** (`contract_details_wireframe`) | Detailed commercial terms, linked products, review structure. | Toggle details, link services. | None (displays details). | Collapsible details card with payment terms & commission notes. | Contracts tab in `SupplierProfilePage.tsx` | **Partial Match** | Shows basic terms in an expanded area, but lacks structured commission tier builders. | Add structured inputs for commission percentages/tiers if required. |
| **Supplements & Policies** (`contract_supplements_policies_wireframe`) | Cancellation policies, seasonal rules, extra charges, conditions. | Build rules, save policy. | Rule parameters (fees, days, seasonal factors). | Rules builder cards, policy matrix. | None. | **Missing** | No rules builder or seasonal/cancellation conditions panel is implemented. | **Must-Fix**: Add a cancellation rules and supplements section to the Contracts tab. |
| **Products/Services Mapping** (`mapping_wireframe`) | Supplier-service relationship, link status, inventory list. | Link item, unlink item. | Available products list. | Linked services table. | Products tab in `SupplierProfilePage.tsx` & `ProductServiceCategoriesPage.tsx` bottom | **Exact Match** | Extremely clean double-sided mapping. Linked items can be unlinked, and unmatched items can be linked. | None. |
| **Payments** (`payments_wireframe`) | Invoice list, amounts, currencies, payment status. | None. | None (read-only). | Payables table. | Payments tab in `SupplierProfilePage.tsx` | **Exact Match** | Integrates invoices from central `mockFinance` list based on supplier name. | None. |
| **Documents** (`payment_terms_documents_review_activation_wireframe`) | Uploaded documents, verification status, file details. | Upload/add document. | Document name text input. | Documents list, add document input. | Documents tab in `SupplierProfilePage.tsx` | **Exact Match** | Supports creating mock documents with Valid/Expired indicators. | None. |
| **Performance** (`performance_wireframe`) | Performance indicators, response rate, complaints count. | None. | None. | Metric cards grid. | Performance tab in `SupplierProfilePage.tsx` | **Exact Match** | Shows response time, response rate, confirmation rate, quality score, complaints, etc. | None. |
| **Activity/Timeline** (`profile_wireframe` tab) | Logs of events related to supplier. | None. | None. | Activity timeline list. | Activity Timeline tab in `SupplierProfilePage.tsx` | **Exact Match** | Clean chronological event logging list. | None. |
| **Evaluation Scorecard** (`evaluation_wireframes`) | Operational review scorecard, score classes, QA checks. | Audit partner. | Checklist ratings. | Scorecard checklist modal/widget. | None. | **Partial Match** | Quality score exists as a read-only metric, but there is no interactive audit checklist. | **Should-Fix**: Add an operational QA checklist modal to the Performance tab. |

---

## 3. Products & Services Parity Table

Compare against wireframes in `wireframe_reference/products-services/`:

| Original Wireframe Screen/Section | Expected UI Elements | Expected Buttons / Actions | Expected Inputs / Forms | Expected Tables / Cards / Modals | Current Implemented Route / File | Current Status | Notes | Recommendation |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Products/Services Dashboard** (`dashboard_wireframe`) | Summary cards, category usage, status indicators. | Add product, manage categories, import/export. | None (visual summary). | Top Categories card, Status distribution card, metrics cards. | `/product-categories` / `ProductServiceCategoriesPage.tsx` | **Exact Match** | Dashboard is integrated directly at the top of the categories/catalog page. | None; unified layout is clean. |
| **Product/Service Catalog** (`catalog_wireframe` / `catalog_updated_positioning_wireframe`) | Product catalog grid/list, search, filters. | View, Edit, Duplicate, Archive. | Search, Category Filter, Supplier Filter, Destination Filter, Status, Type. | Catalog table. | `/product-categories` / `ProductServiceCategoriesPage.tsx` | **Exact Match** | Highly functional catalog list with multiple actions and comprehensive filters. | None. |
| **Categories Management** (`categories_management_wireframe`) | Category list, items count, active items, status. | Add category, edit category, delete/deactivate. | Category Name, Type select. | Categories table. | `/product-categories` / `ProductServiceCategoriesPage.tsx` | **Exact Match** | Located alongside the catalog, supporting adding categories and deactivating. | None. |
| **Add Product Wizard** (`add_product_wizard_wireframe`) | Multi-step form (basic, category, pricing, attributes, media, review). | Move next/prev, save item. | Multiple sectioned inputs. | Structured modal with sections and review sidebar. | `/product-categories/new` / `AddNewItemPage.tsx` & Form in `ProductServiceCategoriesPage.tsx` | **Adapted Differently** | Implemented as a collapsible sectioned modal (`ProductFormModal`) rather than a multi-step page. | Accept modal structure as-is. It is extremely comprehensive. |
| **Product Details Workspace** (`details_wireframe`) | Overview, pricing metrics, attributes list, media, bookings usage. | Back, Edit, Link/Unlink supplier, upload media. | Link Supplier select. | Workspace grid cards. | `/product-categories/items/:itemId` / `ProductServiceDetailsPage.tsx` | **Exact Match** | Highly detailed profile with tabbed-like card structures. | None. |
| **Attributes Management** (`attributes_management_wireframe`) | Custom attribute groupings, field types, notes. | None. | Attribute fields (inclusions, exclusions, cancellation, capacity). | Attributes section inside details and modal form. | `ProductServiceDetailsPage.tsx` & `ProductServiceCategoriesPage.tsx` | **Adapted Differently** | Attributes are flat fields on the product object rather than a schema builder. | Keep as flat fields unless dynamic schemas are required. |
| **Destinations Management** (`destinations_management_wireframe`) | Destination list, service coverage, status. | Filter by destination. | None. | Destinations card listing counts. | `ProductServiceCategoriesPage.tsx` | **Adapted Differently** | Implemented as a summary list widget in the categories view. | Keep as-is; fits the layout style. |
| **Media / Documents** (`media_documents_wireframe`) | Upload gallery, file names, status, placeholders. | Mock upload. | Mock upload trigger. | Media gallery cards grid. | `ProductServiceDetailsPage.tsx` | **Exact Match** | Shows files and statuses with a functional mock upload button. | None. |
| **Availability tab** (`availablity_tab_wireframes`) | Availability rules, status, linked bookings. | None. | None. | Availability metric card. | `ProductServiceDetailsPage.tsx` | **Exact Match** | Shows allotment type, status, and usage bookings. | None. |
| **Product Rate Matrix** (`add_product_rate_matrix_wireframe`) | Seasonal rate grids, cost/selling price combinations. | Add seasonal rate. | Seasonal pricing inputs. | Rate matrix grid. | None. | **Missing** | Product prices are single static cost/selling numbers with no date-based grids. | **Must-Fix**: Add a seasonal rate matrix card to the Product Details Page. |
| **Cost Components & Templates** (`cost_components_wireframe` / `cost_templates_wireframe`) | Reusable cost models, variable elements. | Apply template. | Cost items structure. | Cost template list. | None. | **Missing** | Cost components are not modeled inside the product catalog (only in quotes costing). | **Should-Fix**: Support defining reusable cost templates for group tours. |
| **Pricing Rules** (`pricing_rules_management_wireframe`) | Automatic markups, seasonal margins. | Create rule. | Markup values, filters. | Pricing rules table. | None. | **Missing** | Catalog level pricing rules are missing. Markup is set at the quotation level. | **Should-Fix**: Add catalog markup rules to apply default margins to categories. |
| **Product Analytics** (`services_analytics_dashboard_wireframe`) | Usage, revenue, margin charts. | None. | None. | Analytics summary cards. | `ProductServiceCategoriesPage.tsx` & details | **Adapted Differently** | Usage and revenue are shown as text counts inside tables rather than charts. | **Nice-to-Have**: Add simple SVG/CSS bar charts for category booking volume. |
| **Package Relation** (`package_builder_wireframe` / `package_details_workspace_wireframe`) | Service composition package structures. | Link service. | None. | Package structure cards. | Quotation costing step. | **Adapted Differently** | Composition is built directly in the costing step of a quote rather than saved as a template. | **Should-Fix**: Allow saving a quote costing matrix as a reusable package template. |

---

## 4. Quotation / Pricing / Package Builder Parity Table

Compare against wireframes in `wireframe_reference/quotation-pricing-package/`:

| Original Wireframe Screen/Section | Expected UI Elements | Expected Buttons / Actions | Expected Inputs / Forms | Expected Tables / Cards / Modals | Current Implemented Route / File | Current Status | Notes | Recommendation |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Quotation Dashboard** (`dashboard_wireframe`) | Metrics, pipeline overview, won/lost counts. | New Case, manage tasks. | Search, filters. | Summary cards, sales cases pipeline. | `/sales` / `SalesPage.tsx` | **Adapted Differently** | Merged into the main Sales pipeline view which handles cases and their quotes. | None; unified layout is logical. |
| **Quotation List** (`list_wireframe`) | Quotes list, customer info, status, value. | View preview, edit quote, print, new quote. | None. | Quotations table. | `/sales/cases/:caseId` / `CaseDetailsPage.tsx` | **Exact Match** | Accessible under the "Quotations" tab of a case details page. | None. |
| **Create/Edit Quotation** (`create_edit_wireframe`) | Form headers, multi-step progress bar. | Next, Previous, Cancel, Save Draft, Preview. | Progress bar steps. | Quotation builder workspace. | `/sales/cases/:caseId/quotations/:quotationId/edit` / `QuotationBuilderPage.tsx` | **Exact Match** | Step-by-step wizard (7 steps) that stores uncommitted state in session memory. | None. |
| **Service Selection / Package Builder** (`package_builder_wireframe`) | Service catalog list, categories, adding to composition. | Search, add service, view supplier details. | Search, filter dropdowns. | Service selection table. | Costing Step in `QuotationBuilderPage.tsx` / `CostingStep.tsx` | **Exact Match** | Built directly as a sub-section of the costing step for easy composition. | None. |
| **Itinerary Builder** (`itinerary_wireframe`) | Day-by-day program, date, route, city, description, meals, accommodation, transport. | Add day, duplicate day, delete day, link service. | Date, title, route, city, description, meals checklists. | Day builder cards list, included services checklist. | Itinerary Step in `QuotationBuilderPage.tsx` / `ItineraryBuilderStep.tsx` | **Exact Match** | Day builder with meal toggles, transport text, and service link buttons. | None. |
| **Services Costing** (`services_costing_wireframe`) | Cost rows, qty, nights, pax, units, taxes, adjustments, totals. | Remove line, adjust metrics. | Qty, nights, pax, units, taxes, adjustments inputs. | Costing table. | Costing Step in `QuotationBuilderPage.tsx` / `CostingStep.tsx` | **Exact Match** | Provides detail cells for rate, qty, nights, pax, units, taxes, adjustments. | None. |
| **Cost Allocation Engine** (`cost_allocation_engine_wireframe`) | Allocation breakdowns. | None. | None. | Breakdowns by Category, Supplier, and Day. | Costing Step in `QuotationBuilderPage.tsx` / `CostingStep.tsx` | **Exact Match** | Beautiful tables showing cost distribution matching the allocation engine concept. | None. |
| **Fixed Cost Center** (`fixed_cost_center_wireframe`) | Shared/fixed group costs, allocation ratios. | Allocate cost. | Share cost inputs, allocation rules. | Fixed cost center card. | None. | **Missing** | No dedicated shared cost center; all items are line-level costs. | **Must-Fix**: Add a fixed cost allocation section to the Costing Step. |
| **Pricing Engine** (`pricing_engine_wireframe`) | Markup, discount, commission, manual override, currency. | Switch markup type, toggle override. | Markup, discount, commission, currency, manual override inputs. | Pricing controls card. | Pricing Step in `QuotationBuilderPage.tsx` / `PricingStep.tsx` | **Exact Match** | Full markup selectors, currency conversion factor, discount, and overrides. | None. |
| **Multi-scenario Pricing** (`multi_scenario_pricing_wireframe`) | Comparison of multiple price scenarios (e.g. Budget vs Luxury). | Add scenario, compare. | Scenario inputs. | Scenario comparison grid. | None. | **Missing** | One pricing scenario per version. No side-by-side comparison. | **Should-Fix**: Add a scenario comparison card to compare markups. |
| **Profit Analysis** (`profit_analysis_wireframe`) | Gross profit, break-even, low margin warning, risk checks. | None. | None. | Profit analysis summaries, readiness checks card. | Pricing Step in `QuotationBuilderPage.tsx` / `PricingStep.tsx` | **Exact Match** | Displays margin warnings if target is < 15% and flags high-risk suppliers. | None. |
| **Analytics** (`analytics_wireframe`) | Revenue, margin analytics. | None. | None. | Margin metric cards. | Pricing step summaries. | **Adapted Differently** | Analytics are inline KPIs rather than dedicated chart dashboards. | None. |
| **Approvals** (`approvals_wireframe`) | Approval status workflow. | Mark Draft, Mark Sent, Approve, Reject. | Action logs. | Top action bar, logs table. | Top bar in `QuotationBuilderPage.tsx` & step 7 | **Partial Match** | Has status update buttons and logs, but lacks a formal review workflow with comments. | None; fits typical CRM operations. |
| **Version History** (`version_history_wireframe`) | Revisions log, versions. | Duplicate (revised version). | Version logs. | History logs card. | `QuotationBuilderPage.tsx` top bar & step 7 | **Exact Match** | "Duplicate" button increments version, archiving the old version. | None. |
| **Customer Preview / Proposal Preview** (`customer_preview_wireframe`) | client proposal format (itinerary, services, price, terms). | Print, Send. | None. | Proposal preview layout. | `/sales/cases/:caseId/quotations/:quotationId/preview` / `QuotationPreviewPage.tsx` | **Exact Match** | Live proposal preview matches customer-facing proposal look. | None. |
| **PDF Templates / Proposal Log** (`pdf_templates_wireframe`) | PDF rendering, proposal action logs. | Print / Save PDF, Send email. | Log notes. | Printable view, proposal log cards. | `/sales/cases/:caseId/quotations/:quotationId/print` / `QuotationPrintPage.tsx` | **Partial Match** | Print view matches style, but there is no select template widget. | **Nice-to-Have**: Add a PDF cover page template selector (e.g. Classic, Modern). |
| **Documents** (`documents_wireframe`) | Quotation attachments. | Attach file. | File selection. | Attachments section. | None. | **Missing** | No document attachments area is present in the Quotation Builder. | **Nice-to-Have**: Add a basic files list card to step 7 of the builder. |
| **Internal Notes** (`internal_notes_wireframe`) | Team notes. | Save notes. | Textarea notes. | Internal notes cards. | Basic Info Step in `QuotationBuilderPage.tsx` | **Exact Match** | Contains separate boxes for Client Notes (PDF) and Internal Notes (private). | None. |
| **Complimentary Services** (`complimentary_services_wireframe`) | Marking free services, bonus list. | Toggle complimentary. | None. | Complimentary list. | None. | **Missing** | There is no indicator to mark costing lines as complimentary (zero price, full cost). | **Should-Fix**: Add a "Complimentary" checkbox to service lines. |
| **Workflow State** (All) | Uncommitted session state. | Preview. | None. | Session memory storage. | `QuotationBuilderPage.tsx` & `QuotationPreviewPage.tsx` | **Exact Match** | Live preview displays builder state before database save. | None. |

---

## 5. Summary of Gaps & Deviations

### 1. Missing Items
* **Supplier Management**: Contract Supplements & Policies rules builder (`contract_supplements_policies_wireframe`); Interactive operational scorecard checklist (`evaluation_wireframes`).
* **Products & Services**: Seasonal rate matrix grids (`add_product_rate_matrix_wireframe`); Reusable cost templates (`cost_templates_wireframe`); Catalog-level default pricing rules (`pricing_rules_management_wireframe`).
* **Quotation Builder**: Shared Fixed Cost Center (`fixed_cost_center_wireframe`); Multi-scenario price comparison grids (`multi_scenario_pricing_wireframe`); Quote-level documents/attachments list (`documents_wireframe`); Cost-line "Complimentary / FOC" status switch (`complimentary_services_wireframe`).

### 2. Partial / Adapted Items
* **Supplier Dashboard**: Consolidated inside the Supplier Tracker page (`SupplierTrackerPage.tsx`) as a performance metrics row.
* **Contract Details Workspace**: Displayed as a collapsible details container under the Contracts tab in the Supplier Profile, rather than a standalone page.
* **Add Product Wizard**: Designed as a collapsible modal (`ProductFormModal`) with a validation sidebar, rather than a multi-page routing wizard.
* **Attributes & Destinations Management**: Nested as flat fields (attributes) and a summary card (destinations) in the categories dashboard rather than separate setup pages.
* **Analytics Views**: Detailed numerical lists and usage stats are used throughout the catalog and costing step instead of graphical dashboards.
* **PDF Templates**: Handled by a structured print template styled for print-to-PDF (`QuotationPrintPage.tsx`), without styling selectors.

### 3. Extra Items Implemented (Beyond Reference)
* **Supplier Response Tracker**: A modal (`SupplierResponseTrackerModal.tsx`) tracking supplier response time indicators and waiting limits.
* **Service Day Duplication**: Ability to duplicate itinerary days during composition to save time.
* **Quick Inclusions Suggestions**: Suggestion pills in the inclusions builder for rapid entry.
* **Duplicate Catalog Product**: Action in the categories dashboard to duplicate item configurations.
* **Margin Target Check & Risk Warning**: Evaluates markup values against a 15% margin target and flags high-risk/missing suppliers on costing lines.

---

## 6. UX / Business Logic Gaps

1. **Static Pricing Limitations**: The lack of a catalog-level rate matrix or seasonal pricing rules means costs/pricing must be manually adjusted inside each quote.
2. **Manual Overrides Discrepancies**: Overriding the selling price in the pricing step does not back-calculate the adjusted margin on individual costing lines, creating a visual mismatch in detail tables.
3. **KYC and Document Actions**: Uploading KYC documents or contracts is simulated locally in browser state and doesn't validate actual file formats.
4. **No Reusable Packages**: The package builder is integrated in the quotation cost step, but there is no mechanism to save the costing/itinerary combination back to the catalog as a reusable "Package template".

---

## 7. Recommended Fix Plan

### Must-Fix (Critical Parity Features)
1. **Cancellation Policies & Rules Builder** (`contract_supplements_policies_wireframe`):
   * Add a cancellation policy rule card inside the Supplier Profile Contract details, supporting text and rule mapping.
2. **Product Rate Matrix** (`add_product_rate_matrix_wireframe`):
   * Add a seasonal rate matrix card to the Product Details Page to support basic seasonal cost adjustments.
3. **Fixed Cost Center** (`fixed_cost_center_wireframe`):
   * Add a shared fixed costs section inside the Quotation Costing step to distribute shared expenses (like tour guides or coaches) across passengers.

### Should-Fix (Important Functional Enhancements)
1. **Multi-scenario Pricing Engine** (`multi_scenario_pricing_wireframe`):
   * Create a simple side-by-side scenario toggle (e.g. Standard vs Luxury vs Budget) in the Quotation pricing step.
2. **Complimentary / FOC Toggle** (`complimentary_services_wireframe`):
   * Add a checkbox to the Quotation service lines to flag items as "Complimentary", setting their selling price to zero while preserving the cost element.
3. **Operational QA Checklist** (`evaluation_wireframes`):
   * Build a simple checklist modal under the Supplier Profile Performance tab to run operational reviews.

### Nice-to-Have (Polish & Visual Enhancements)
1. **Cost Templates** (`cost_templates_wireframe`):
   * Allow users to save quotation costing structures as reusable templates in the catalog.
2. **PDF Template Styles** (`pdf_templates_wireframe`):
   * Add a visual theme selector (Classic, Corporate, Modern) on the preview/print page to adjust styles.
3. **Documents Attachment Card** (`documents_wireframe`):
   * Support basic file upload placeholders in step 7 of the Quotation Builder.

---

## 8. Final Verdict

* **Supplier Management Parity**: **80%**
* **Products & Services Parity**: **75%**
* **Quotation Builder Parity**: **85%**

**Overall Parity Status**: The Travneeds System implementation is in excellent health. Almost all primary screens are present, with routing, calculations, and detail profiles working perfectly in a highly responsive CSS layout. The deviations are logical design consolidations (merging dashboards and directory list pages) or missing secondary business logic modules (rate matrices, fixed cost engines, rules builders) which can be added incrementally to reach 100% parity.
