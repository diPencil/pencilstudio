# Arabic / RTL Full Parity Audit

Date: 2026-06-21
Workspace: `D:\Development\CRM Travel\TravneedsSystem`
Scope: frontend audit only, no implementation

## Executive Summary

The current Travneeds System frontend is not Arabic-ready and is not RTL-ready.

English is the only real operating mode today. The app has:

- no localization framework
- no Arabic translation files
- no runtime locale provider
- no runtime `dir` switching
- no RTL-aware layout system
- multiple hard-coded LTR layout assumptions across shared shell, tables, forms, toasts, steppers, and pricing views

There is enough structural separation in the app to add Arabic/RTL safely, but it should be done as a deliberate platform pass, not as scattered text replacement.

## Current Arabic / RTL Readiness Summary

Estimated readiness: **12%**

Why the estimate is low:

- `index.html` is fixed to `<html lang="en">`
- `src/main.tsx` and `src/App.tsx` have no locale or direction provider
- `src/utils/format.ts` hardcodes `en-US` and `USD`
- shared layout files use physical left/right spacing and positioning
- module pages are full of hard-coded English UI strings
- notifications, toasts, tables, action bars, steppers, and preview layouts assume LTR
- there is no Arabic typography or mixed-direction handling strategy

## Existing Localization Support Found

### Present

- A **mock language preference field** exists in [src/components/layout/SettingsModal.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/layout/SettingsModal.tsx), but it is local-only and not connected to app state.
- General UI composition is componentized enough that a later locale layer can be introduced centrally.
- Shared formatting helpers exist in [src/utils/format.ts](D:/Development/CRM%20Travel/TravneedsSystem/src/utils/format.ts), which gives a good future insertion point for locale-aware formatting.

### Not present

- No `react-i18next`, `i18next`, or custom app-wide translation system
- No translation dictionaries
- No Arabic strings
- No locale context or `useLocale` hook
- No app-level `lang` switching
- No app-level `dir="rtl"` / `dir="ltr"` switching
- No route-based locale support
- No bidi utility wrappers for IDs, email, phone, URLs, or currency fragments

## Missing Localization Infrastructure

The following foundational pieces are missing and are required before module-level Arabic work:

1. **Locale state**
   - current locale
   - current direction
   - locale persistence policy

2. **Runtime document control**
   - update `document.documentElement.lang`
   - update `document.documentElement.dir`

3. **Dictionary system**
   - English source keys
   - Arabic translations
   - namespaced messages by module

4. **Locale-aware formatting layer**
   - currency
   - dates
   - date-time
   - numbers
   - percentages

5. **RTL-aware UI primitives**
   - logical margin/padding helpers
   - start/end alignment conventions
   - mirrored icon behavior
   - toast placement logic
   - drawer/sidebar anchoring logic

6. **Bidi content rules**
   - preserve LTR rendering for codes, IDs, URLs, emails, and phone numbers inside RTL screens

## Shared Components Requiring RTL Changes

These are cross-app blockers because they affect every module.

### App shell / routing / document state

- [index.html](D:/Development/CRM%20Travel/TravneedsSystem/index.html)
- [src/main.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/main.tsx)
- [src/App.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/App.tsx)

Current issues:

- fixed English `lang`
- no locale bootstrapping
- no direction bootstrapping
- no locale-aware routing strategy

### Layout

- [src/components/layout/Layout.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/layout/Layout.tsx)
- [src/components/layout/Header.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/layout/Header.tsx)
- [src/components/layout/Sidebar.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/layout/Sidebar.tsx)
- [src/components/layout/SettingsModal.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/layout/SettingsModal.tsx)

Current issues:

- sidebar is left-anchored
- content offset uses left padding only
- mobile drawer enters from the left only
- search field icon is pinned left
- notifications menu is pinned right
- collapse arrows assume LTR
- submenu indentation uses `ml-*` and `border-l`
- user/profile row spacing assumes LTR

### UI primitives

- [src/index.css](D:/Development/CRM%20Travel/TravneedsSystem/src/index.css)
- [src/components/ui/PageHeader.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/ui/PageHeader.tsx)
- [src/components/ui/Button.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/ui/Button.tsx)
- [src/components/ui/Toast.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/ui/Toast.tsx)
- [src/components/ui/ToastContainer.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/ui/ToastContainer.tsx)

Current issues:

- table default is `text-left`
- page header action spacing assumes LTR
- button loading spinner uses `-ml-1 mr-2`
- toast animation always enters from the right
- toast stack is fixed to top-right
- no global RTL selectors or logical utility layer

### Dashboard / charts

- [src/components/dashboard/Dashboard.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/dashboard/Dashboard.tsx)

Current issues:

- chart labels and titles are English-only
- y-axis placement assumes LTR meaning
- task cards use right-facing directional arrows
- stat formatting is English-only

## Components Requiring Arabic Translations

At minimum, these areas need full translation coverage:

- shared shell: header, sidebar, settings, toasts
- dashboard
- supplier management pages
- products & services pages
- quotation builder, preview, print, status labels, logs
- table headers, placeholders, empty states, button labels, helper text, notices, badge text

This is not a small string pass. The completed workflow has many embedded English literals directly inside JSX and some English text inside mock data.

## Components Requiring Layout Mirroring

The following UI patterns need RTL mirroring rather than simple translation:

- sidebar position and collapse behavior
- header search field and notification placements
- breadcrumbs and back buttons
- page title/action alignment
- stat card icon/value arrangements
- filters and search bars
- table column alignment and action columns
- form label/value alignment
- tab lists and tab overflow behavior
- stepper progression direction
- timeline rails and timeline markers
- toast stack position and animation direction
- sticky quotation footer offset
- mobile drawer entry side

## Components Requiring Icon / Arrow Flipping

Directional icons must become direction-aware, not statically chosen:

- `ArrowLeft` / `ArrowRight`
- `ChevronLeft` / `ChevronRight`
- hover translations like `group-hover:translate-x-1`
- sidebar collapse chevrons
- next / previous step buttons
- back-to-tracker and back-to-list actions
- breadcrumb separators if added later

Icons that are semantic but not directional, such as `Calendar`, `Bell`, `Phone`, `Mail`, do not need flipping.

## Module-by-Module RTL Gap List

## A. Supplier Management

### Supplier Tracker

File:

- [src/components/reservations/SupplierTrackerPage.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/reservations/SupplierTrackerPage.tsx)

RTL gaps:

- search input uses left-pinned icon and left padding
- filter bar order is LTR-first
- table is English-only
- action column is explicitly right-aligned for LTR usage
- supplier rating / risk / performance visuals need mirrored label flow
- any back or row action arrow cues need direction awareness
- mobile/tablet overflow behavior should be rechecked under longer Arabic labels

Arabic content gaps:

- supplier type labels
- status labels
- destinations
- service labels
- risk/performance text
- empty/filter helper text

### Supplier Profile

File:

- [src/components/reservations/SupplierProfilePage.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/reservations/SupplierProfilePage.tsx)

RTL gaps:

- `Back to Tracker` uses LTR back-arrow semantics
- top summary layout is LTR-oriented
- tab list needs RTL reading order and overflow testing
- contacts/contracts/payments/documents tables require start/end alignment audit
- action buttons in tables require mirrored order
- linked products/services sections need RTL badge and warning placement
- activity timeline likely needs rail/marker mirroring

Subsections to mirror and translate:

- Overview
- Contacts
- Contracts
- Products & Services
- Payments
- Documents
- Performance
- Activity Timeline
- any policy or contract rule builder content shown in profile tabs

### Supplier-specific risk items

- mixed content like supplier IDs, emails, phone numbers, contract numbers, bank references, and destination codes must remain readable inside RTL cards and rows

## B. Products & Services

### Product Operations Dashboard / Catalog

File:

- [src/components/categories/ProductServiceCategoriesPage.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/categories/ProductServiceCategoriesPage.tsx)

RTL gaps:

- dashboard metric cards are English-only
- search and filter controls are LTR-biased
- table/list alignment is LTR-biased
- action icons and button order need mirroring
- category chips, status badges, and supplier references need RTL spacing rules
- internal table scroll containers need Arabic width stress testing

### Product Details

File:

- [src/components/categories/ProductServiceDetailsPage.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/categories/ProductServiceDetailsPage.tsx)

RTL gaps:

- back navigation is LTR-oriented
- supplier link and metadata rows assume LTR spacing
- seasonal rate matrix uses left/right aligned numeric columns that need explicit RTL rules
- tabs/sections for attributes, destinations, supplier mapping, documents/media need mirrored headings and action placement

Arabic content gaps:

- category names
- destination labels
- attributes
- availability and status messages
- warning and empty-state text

### Add/Edit Forms and related modals

Files likely impacted:

- [src/components/categories/AddNewItemPage.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/categories/AddNewItemPage.tsx)
- [src/components/categories/AddItemModal.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/categories/AddItemModal.tsx)
- [src/components/categories/EditItemModal.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/categories/EditItemModal.tsx)
- [src/components/categories/ViewItemModal.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/categories/ViewItemModal.tsx)

RTL gaps:

- label/input alignment
- select and date-like input alignment
- helper text and validation alignment
- modal close/action button order
- media/documents side panels if shown

## C. Quotation / Pricing / Package Builder

### Builder shell

File:

- [src/components/sales/QuotationBuilderPage.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/QuotationBuilderPage.tsx)

RTL gaps:

- page header actions are LTR-ordered
- stepper progression is visually LTR
- next/previous actions use fixed arrow directions
- sticky bottom action bar uses `lg:left-64`
- success notice placement near Save Draft should be checked in RTL
- status/version actions need mirrored grouping

### Basic info / program / inclusions

Files:

- [src/components/sales/QuotationBasicInfoStep.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/QuotationBasicInfoStep.tsx)
- [src/components/sales/ProgramOverviewStep.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/ProgramOverviewStep.tsx)
- [src/components/sales/InclusionsExclusionsStep.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/InclusionsExclusionsStep.tsx)

RTL gaps:

- textareas and helper labels are English-only
- chip remove icons use `ml-*`
- scrollable list panels assume LTR padding
- mixed bilingual notes need bidi isolation rules

### Itinerary Builder

File:

- [src/components/sales/ItineraryBuilderStep.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/ItineraryBuilderStep.tsx)

RTL gaps:

- day cards use left border emphasis
- service assignment layout should be mirrored
- day metadata row should reverse reading direction cleanly
- any add/copy/delete control order should be validated under RTL

### Costing / fixed cost center / FOC controls

File:

- [src/components/sales/CostingStep.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/CostingStep.tsx)

RTL gaps:

- service selector search input is LTR-biased
- selector table is left-aligned throughout
- supplier link and risk badge spacing use `ml-*`
- add/remove action columns are LTR-ordered
- selected services costing table needs explicit numeric alignment rules
- fixed cost center table uses mixed `text-left` and `text-right` patterns
- complimentary / FOC controls and badges need readable mirrored placement
- low-margin and supplier-warning banners need bidi-safe mixed content rendering

Arabic content gaps:

- warnings for missing supplier
- high-risk supplier
- inactive/archived service
- low-margin indicators

### Pricing / profit analysis

File:

- [src/components/sales/PricingStep.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/PricingStep.tsx)

RTL gaps:

- pricing control labels are English-only
- numeric columns and totals need explicit locale formatting
- markup/discount/commission controls need label/value alignment rules
- margin/profit warning panels need mirrored layout
- tables should keep numbers easy to compare in RTL

Functional note:

- multi-scenario pricing is not clearly present as a dedicated implemented feature in the current codebase, so Arabic parity for that area would begin after confirming intended UX scope.

### Preview / proposal / print

Files:

- [src/components/sales/QuotationPreviewPage.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/QuotationPreviewPage.tsx)
- [src/components/sales/QuotationPrintPage.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/QuotationPrintPage.tsx)

RTL gaps:

- preview summary, totals, itinerary, notes, and terms are English-only
- proposal action buttons are LTR-ordered
- itinerary/service tables need start/end alignment rules
- totals and profit blocks need Arabic formatting with preserved numeric legibility
- print/PDF-like layout will need a dedicated RTL print audit

### Status / version / logs

Files:

- [src/components/sales/QuotationStatusBadge.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/QuotationStatusBadge.tsx)
- [src/components/sales/CaseDetailsPage.tsx](D:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/CaseDetailsPage.tsx)

RTL gaps:

- status text requires translation
- version actions and log rows need mirrored action order
- preview/edit/print icons and buttons need RTL-aware arrangement

## App Routing / Locale Strategy Audit

Current state:

- no route-based locale support
- no locale prefix such as `/ar/...`
- no locale segment in React Router
- no app-level locale provider

Recommendation:

- for this codebase, **app-level locale state** is the safer first implementation than route-based locale prefixes
- keep the current routes stable
- switch locale and direction at the app shell level
- add route-based locale prefixes only later if marketing/SEO/public URLs ever matter

## Data Formatting Requirements for Arabic

Arabic parity needs more than translated labels.

Required formatting coverage:

### Dates

- centralize in formatter helpers
- decide whether Arabic uses Gregorian only or optionally Hijri later
- support Arabic month names
- ensure date range rendering remains readable in cards, forms, and proposal preview

### Currency

- current code is hardcoded to `USD`
- support locale-aware display for `USD`, `EUR`, `GBP`, `EGP`, and any existing mock currencies
- preserve predictable decimal alignment in tables

### Numbers

- decide whether to use Arabic-Indic numerals or Western digits for operational screens
- whichever choice is made, keep it consistent across tables, summaries, and charts

### Percentages

- margin, markup, commission, discount, risk/performance metrics need locale formatting

### Phone numbers

- should render inside `dir="ltr"` or isolated spans even on RTL pages

### Status labels

- draft/sent/approved/rejected
- active/inactive/archived
- supplier and contract statuses

### Mixed English/Arabic content

Must remain LTR inside RTL containers for:

- IDs such as `SUP-001`
- quotation numbers
- emails
- URLs
- reservation codes
- airport codes
- currency abbreviations when required
- phone numbers

Recommended rule:

- wrap machine-readable identifiers in dedicated bidi-safe components using `dir="ltr"` and `unicode-bidi: isolate`

## Responsive RTL Risks

### 1440px

Primary risks:

- sidebar should move to the right without breaking content offset
- sticky quotation footer currently assumes left sidebar offset
- charts and dashboard cards need balanced mirrored hierarchy

### 1024px

Primary risks:

- tablet drawer/sidebar open direction
- tab overflow and quotation stepper reading order
- action bar wrapping in supplier, products, and quotation pages

### 390px

Primary risks:

- long Arabic button labels may wrap earlier than English
- search/filter bars may crowd icons and badges
- horizontal table overflow must remain inside table containers only
- quotation stepper and pricing tables need careful RTL scrolling behavior
- toast stack and mobile drawer placement must not overlap action bars

## Recommended Implementation Architecture

The safest path is to treat Arabic/RTL as a shared platform feature with module adoption on top.

### Recommended architecture

1. **Locale provider**
   - app-level provider with `locale`, `direction`, `setLocale`
   - updates `<html lang>` and `<html dir>`

2. **Typed dictionary system**
   - English and Arabic dictionaries
   - module namespaces
   - no inline ad hoc translation objects inside page files

3. **Formatter layer**
   - replace direct `Intl.*('en-US')`
   - expose `formatCurrency`, `formatDate`, `formatDateTime`, `formatNumber`, `formatPercent`

4. **RTL-aware primitives**
   - shared helpers for start/end spacing
   - direction-aware icons
   - bidi-safe inline value components
   - direction-aware toast/drawer positioning

5. **Gradual module rollout**
   - shared shell first
   - Supplier Management
   - Products & Services
   - Quotation / Pricing / Proposal Preview

## Recommended File Structure for Translations

Suggested structure:

```text
src/
  localization/
    LocaleProvider.tsx
    localeTypes.ts
    useLocale.ts
    formatters.ts
    bidi.ts
    messages/
      en/
        common.ts
        layout.ts
        dashboard.ts
        suppliers.ts
        products.ts
        quotations.ts
      ar/
        common.ts
        layout.ts
        dashboard.ts
        suppliers.ts
        products.ts
        quotations.ts
```

Optional shared helpers:

```text
src/components/i18n/
  DirectionalIcon.tsx
  BidiText.tsx
  LocalizedCurrency.tsx
  LocalizedDate.tsx
```

## Recommended Execution Plan

### Phase 1: Localization foundation

- add locale provider
- add English/Arabic dictionaries
- wire `lang` and `dir`
- replace hardcoded formatter locale usage

### Phase 2: Shared shell and primitives

- Layout
- Sidebar
- Header
- PageHeader
- Button
- Toast
- common form/table alignment patterns

### Phase 3: Supplier Management RTL parity

- supplier tracker
- supplier profile
- all tabs
- tables, timeline, contacts/contracts/payments/documents/performance

### Phase 4: Products & Services RTL parity

- catalog/dashboard
- details page
- forms/modals
- seasonal rate matrix
- supplier mapping and media/document sections

### Phase 5: Quotation / Pricing / Proposal parity

- builder shell and stepper
- itinerary
- costing
- pricing
- warnings
- save draft/status/version logs
- preview and print surfaces

### Phase 6: Responsive QA and regression pass

- 1440px
- 1024px
- 390px
- mixed English/Arabic content
- print preview

## Risks

Main risks:

- large number of physical Tailwind classes (`left-*`, `right-*`, `ml-*`, `mr-*`, `pl-*`, `pr-*`, `text-left`, `text-right`)
- hard-coded English strings spread directly through JSX
- charts may need localized labels and mirrored axis semantics
- quotation preview/print views will need separate bidi review
- mixed-language operational values can become unreadable without isolate wrappers
- piecemeal RTL changes could easily break the completed English workflow

## Final Verdict

### Is the system ready for Arabic now?

**No.**

The current frontend is not ready for Arabic use or RTL parity in its present state.

### What is needed to reach 100% Arabic / RTL parity?

Required:

- app-wide localization infrastructure
- app-wide direction handling
- locale-aware formatting layer
- shared RTL primitives
- translation coverage across shared shell and target modules
- module-by-module layout mirroring
- directional icon strategy
- bidi-safe handling for IDs, emails, URLs, and numbers
- responsive and print QA in Arabic

### Can Arabic / RTL be implemented safely without breaking the completed English workflow?

**Yes, with the right approach.**

It can be implemented safely if it is done as a structured platform rollout:

- keep current English routes intact
- introduce locale state centrally
- preserve English as the default baseline
- migrate shared primitives before page-level rewrites
- convert pages module by module with regression QA after each phase

It is **not** safe to do as a quick string replacement or scattered `dir="rtl"` patching pass.
