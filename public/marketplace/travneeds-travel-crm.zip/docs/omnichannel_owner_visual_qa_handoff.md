# Omnichannel Owner Visual QA Handoff

## Purpose

This handoff is for owner-led manual visual QA of the committed Omnichannel frontend UI surfaces in a normal browser. Manual browser-controlled QA was not completed in Codex because the in-app browser runtime/tool was unavailable in this session, so this document is the review script for the owner visual pass.

## Current Verified Technical Status

- Relevant commits:
  - `82ba407` - `feat(omnichannel): build complete module UI surfaces`
  - `5fa4fcc` - `chore(git): ignore generated dist backup`
- Build status:
  - `corepack pnpm build` passes
  - Note: Vite reports a chunk-size warning for the main bundle, but the production build completes successfully
- Git status:
  - `git status --short` is clean at handoff time
- Dev server flow:
  - Start with `corepack pnpm dev`
  - Expected local URL example: `http://localhost:5173`
  - If Vite selects a different port automatically, use the URL shown in the terminal

## Owner Review Setup

1. Open a terminal in the repository root.
2. Run `corepack pnpm dev`.
3. Open the Vite local URL in a normal browser.
4. Review the Omnichannel routes in English first.
5. Switch to Arabic using the existing app language switcher.
6. Repeat the same route checks in Arabic RTL.
7. Repeat priority route checks at the listed responsive widths.

## Full Route Checklist

Use this checklist for each route:

- Page opens
- Title/header visible
- Main cards/tables/panels visible
- No placeholder-only page
- No horizontal overflow
- Text readable
- Buttons/filters/modals usable
- Active nav state correct
- English OK
- Arabic RTL OK
- Mobile OK

### `/omnichannel/dashboard`

- [ ] Page opens
- [ ] Title/header visible
- [ ] Main cards/tables/panels visible
- [ ] No placeholder-only page
- [ ] No horizontal overflow
- [ ] Text readable
- [ ] Buttons/filters/modals usable
- [ ] Active nav state correct
- [ ] English OK
- [ ] Arabic RTL OK
- [ ] Mobile OK

### `/omnichannel/conversations`

- [ ] Page opens
- [ ] Title/header visible
- [ ] Main cards/tables/panels visible
- [ ] No placeholder-only page
- [ ] No horizontal overflow
- [ ] Text readable
- [ ] Buttons/filters/modals usable
- [ ] Active nav state correct
- [ ] English OK
- [ ] Arabic RTL OK
- [ ] Mobile OK

### `/omnichannel/channels`

- [ ] Page opens
- [ ] Title/header visible
- [ ] Main cards/tables/panels visible
- [ ] No placeholder-only page
- [ ] No horizontal overflow
- [ ] Text readable
- [ ] Buttons/filters/modals usable
- [ ] Active nav state correct
- [ ] English OK
- [ ] Arabic RTL OK
- [ ] Mobile OK

### `/omnichannel/routing`

- [ ] Page opens
- [ ] Title/header visible
- [ ] Main cards/tables/panels visible
- [ ] No placeholder-only page
- [ ] No horizontal overflow
- [ ] Text readable
- [ ] Buttons/filters/modals usable
- [ ] Active nav state correct
- [ ] English OK
- [ ] Arabic RTL OK
- [ ] Mobile OK

### `/omnichannel/automation`

- [ ] Page opens
- [ ] Title/header visible
- [ ] Main cards/tables/panels visible
- [ ] No placeholder-only page
- [ ] No horizontal overflow
- [ ] Text readable
- [ ] Buttons/filters/modals usable
- [ ] Active nav state correct
- [ ] English OK
- [ ] Arabic RTL OK
- [ ] Mobile OK

### `/omnichannel/templates`

- [ ] Page opens
- [ ] Title/header visible
- [ ] Main cards/tables/panels visible
- [ ] No placeholder-only page
- [ ] No horizontal overflow
- [ ] Text readable
- [ ] Buttons/filters/modals usable
- [ ] Active nav state correct
- [ ] English OK
- [ ] Arabic RTL OK
- [ ] Mobile OK

### `/omnichannel/tags`

- [ ] Page opens
- [ ] Title/header visible
- [ ] Main cards/tables/panels visible
- [ ] No placeholder-only page
- [ ] No horizontal overflow
- [ ] Text readable
- [ ] Buttons/filters/modals usable
- [ ] Active nav state correct
- [ ] English OK
- [ ] Arabic RTL OK
- [ ] Mobile OK

### `/omnichannel/sla`

- [ ] Page opens
- [ ] Title/header visible
- [ ] Main cards/tables/panels visible
- [ ] No placeholder-only page
- [ ] No horizontal overflow
- [ ] Text readable
- [ ] Buttons/filters/modals usable
- [ ] Active nav state correct
- [ ] English OK
- [ ] Arabic RTL OK
- [ ] Mobile OK

### `/omnichannel/team`

- [ ] Page opens
- [ ] Title/header visible
- [ ] Main cards/tables/panels visible
- [ ] No placeholder-only page
- [ ] No horizontal overflow
- [ ] Text readable
- [ ] Buttons/filters/modals usable
- [ ] Active nav state correct
- [ ] English OK
- [ ] Arabic RTL OK
- [ ] Mobile OK

### `/omnichannel/analytics`

- [ ] Page opens
- [ ] Title/header visible
- [ ] Main cards/tables/panels visible
- [ ] No placeholder-only page
- [ ] No horizontal overflow
- [ ] Text readable
- [ ] Buttons/filters/modals usable
- [ ] Active nav state correct
- [ ] English OK
- [ ] Arabic RTL OK
- [ ] Mobile OK

### `/omnichannel/activity`

- [ ] Page opens
- [ ] Title/header visible
- [ ] Main cards/tables/panels visible
- [ ] No placeholder-only page
- [ ] No horizontal overflow
- [ ] Text readable
- [ ] Buttons/filters/modals usable
- [ ] Active nav state correct
- [ ] English OK
- [ ] Arabic RTL OK
- [ ] Mobile OK

### `/omnichannel/settings`

- [ ] Page opens
- [ ] Title/header visible
- [ ] Main cards/tables/panels visible
- [ ] No placeholder-only page
- [ ] No horizontal overflow
- [ ] Text readable
- [ ] Buttons/filters/modals usable
- [ ] Active nav state correct
- [ ] English OK
- [ ] Arabic RTL OK
- [ ] Mobile OK

### `/omnichannel/broadcasts`

- [ ] Page opens
- [ ] Title/header visible
- [ ] Main cards/tables/panels visible
- [ ] No placeholder-only page
- [ ] No horizontal overflow
- [ ] Text readable
- [ ] Buttons/filters/modals usable
- [ ] Active nav state correct
- [ ] English OK
- [ ] Arabic RTL OK
- [ ] Mobile OK

## Alias and Navigation Check

Also verify any existing Omnichannel sidebar links or aliases:

- [ ] Omnichannel navigation group is visible in the sidebar
- [ ] Sidebar links open the expected route
- [ ] Active state follows the current route
- [ ] Dashboard and sub-pages are reachable from navigation without dead links
- [ ] Browser back/forward keeps navigation state sensible

## Interaction Checklist

- [ ] Dashboard links to module pages
- [ ] Inbox conversation selection
- [ ] Convert to Lead
- [ ] Convert to Customer
- [ ] Create Ticket
- [ ] Create Case
- [ ] Link Existing Record
- [ ] Unlink linked record
- [ ] Restore previously removed linked record
- [ ] Channel config modal open/save/test
- [ ] Routing simulation
- [ ] Automation toggle/test preview
- [ ] Template select/duplicate/editor preview
- [ ] Tags create/delete validation
- [ ] SLA simulator
- [ ] Team reassignment mock action
- [ ] Analytics time range switching
- [ ] Activity filters
- [ ] Settings save/reset
- [ ] Broadcast planning mock flow

## Viewport Checklist

Review at these widths:

- [ ] Desktop `1440px`
- [ ] Laptop `1280px`
- [ ] Tablet `768px`
- [ ] Mobile `390px`

For each width, especially confirm:

- [ ] No horizontal scroll
- [ ] Cards stack correctly
- [ ] Tables remain usable or become responsive enough to review
- [ ] Panels/modals fit on screen
- [ ] Navigation remains usable
- [ ] Arabic RTL mobile does not break layout

## Arabic / RTL Checklist

- [ ] Layout direction is correct
- [ ] Sidebar direction and subnav direction are correct
- [ ] Active states still read clearly in RTL
- [ ] No overlaps or collapsed controls
- [ ] Arabic labels are readable and natural
- [ ] Technical terms like `WhatsApp`, `API`, `SMS`, `Instagram` may remain in English where appropriate
- [ ] Numbers, IDs, phones, emails, and timer-like values remain readable
- [ ] No unexpected hardcoded English labels beyond valid technical names

## Screenshot Request List

Please capture or provide screenshots for:

- [ ] English desktop dashboard
- [ ] Arabic desktop dashboard
- [ ] English mobile dashboard
- [ ] Arabic mobile dashboard
- [ ] English inbox workspace
- [ ] Arabic inbox workspace
- [ ] Channels page with config modal open
- [ ] Routing or automation rule builder
- [ ] Analytics page
- [ ] Settings page
- [ ] Any broken page or weird spacing issue

## Issue Report Template

Use this table for each issue found:

| Route | Language | Viewport | Severity | Screenshot | What looks wrong | Expected fix |
| --- | --- | --- | --- | --- | --- | --- |
| `/omnichannel/...` | English / Arabic | 1440 / 1280 / 768 / 390 | Blocker / Major / Minor / Polish | file name or link | brief description | brief expected outcome |

## Severity Guide

- `Blocker`: route fails to render, key workflow unusable, severe overlap/breakage
- `Major`: important UI section broken or clearly unacceptable for review
- `Minor`: visible bug but route still usable
- `Polish`: spacing, alignment, copy, or finesse issue

## Next Step Recommendation

- If the owner finds visual issues, run one Omnichannel Visual Polish Pass.
- If no major issues are found, continue to the next module.
