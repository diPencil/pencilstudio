# Implementation Plan - Parity Fix Pass 1 (Must-Fix Only)

This document outlines the detailed technical implementation plan for executing the parity fixes for the Must-Fix items inside the Travneeds System. All changes are frontend-only, utilizing React state, local session mock state, and `sessionStorage`.

---

## 1. Goal Description

Implement the three critical wireframe parity audit findings designated as "Must-Fix":
1. **Supplier Management**: Contract cancellation policies & supplements rules builder in the supplier profile page.
2. **Products & Services**: Seasonal rate matrix builder and viewer, with active season highlighting and below-cost warnings in both product details and the product categories catalog modal.
3. **Quotation / Pricing**: A dedicated fixed cost center/shared cost allocation workflow in the costing step, which integrates into pricing engine calculations, profit analysis, and the final proposal preview.

---

## 2. User Review Required

> [IMPORTANT]
> - All implementations are strictly frontend-only.
> - There are no database tables or persistence schemas updated; all state is managed via React component state and stored in `sessionStorage` (for quotation builder drafts).
> - We exclude all multi-tenancy, multi-company, subscription, or SaaS admin views to respect the single-tenant Travneeds System architecture.

---

## 3. Open Questions

No outstanding open questions. The requirements and calculations are clearly specified and will be verified using `npm run build` and focused ESLint checks.

---

## 4. Proposed Changes

Below is the file-by-file plan for the modifications grouped by feature area.

### 4.1 Data & Calculations Utility
#### [MODIFY] [quotationCalculations.ts](file:///d:/Development/CRM%20Travel/TravneedsSystem/src/utils/quotationCalculations.ts)
- Add fixed cost calculation logic.
- Modify `buildCostSummaryFromServiceLines` to accept `fixedCosts?: QuotationFixedCost[]` and:
  - Calculate total active fixed costs.
  - Add to `groupTotalCost`.
  - Group active fixed costs by category in `byCategory`.
  - Group active fixed costs by supplier in `bySupplier`.
  - Group active fixed costs under a `"Fixed Costs"` key in `byDay` (since fixed costs are generally flat across the itinerary day-level, keeping them grouped separates them clearly).
  - Calculate `perPersonCost` as `groupTotalCost / paxCount`.
- Modify `calculatePricingFromServiceLines` to take `fixedCosts?: QuotationFixedCost[]` as the 11th parameter and pass it to `buildCostSummaryFromServiceLines`.
- Modify `buildProfitAnalysis` to accept `fixedCosts?: QuotationFixedCost[]` and calculate the gross profit, margins, and markup percentages using the updated pricing summary.

---

### 4.2 Products & Catalog Editor
#### [MODIFY] [ProductServiceCategoriesPage.tsx](file:///d:/Development/CRM%20Travel/TravneedsSystem/src/components/categories/ProductServiceCategoriesPage.tsx)
- Extend `ProductFormState` and `emptyForm` to support `seasonalRates?: ProductSeasonalRate[]`.
- In `ProductFormModal`, add a "Seasonal Rate Matrix" section in the left column.
- Render a table showing existing seasonal rates for the item being edited.
- Display an inline subform to add a new rate (Season Name, Start Date, End Date, Cost Price, Selling Price, Currency, Status, Notes).
- Implement a warning inside the subform and list if selling price is below cost.
- Save and delete rates in local form state, mapping them back during the `onSave` callback.

---

### 4.3 Quotation Costing Step & Fixed Cost Center
#### [MODIFY] [CostingStep.tsx](file:///d:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/CostingStep.tsx)
- Render a new "Fixed Cost Center" card below the "Selected Services" table.
- Display a tabular editor showing all defined fixed costs.
- Support inline or modal subforms to Add/Edit/Delete fixed costs with input validation (Name, Category, Supplier, Amount, Currency, Allocation Method, Quantity, Days, Notes, Status).
- Map changes back to the parent quotation state using the `updateData` handler.

---

### 4.4 Quotation Pricing Step
#### [MODIFY] [PricingStep.tsx](file:///d:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/PricingStep.tsx)
- Ensure `calculatePricingFromServiceLines` and `buildProfitAnalysis` are passed `data.fixedCosts`.
- Display a "Shared Fixed Cost Allocation" row or list inside the pricing overview card to highlight how fixed costs impact the total price.

---

### 4.5 Proposal Preview Page
#### [MODIFY] [QuotationPreviewPage.tsx](file:///d:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/QuotationPreviewPage.tsx)
- Include a "Fixed & Shared Costs" table inside the main proposal overview (below services table) if fixed costs are present.
- Ensure the total cost, profit, and client selling price cards reflect fixed costs correctly.

---

### 4.6 Quote Builder Parent Sync
#### [MODIFY] [QuotationBuilderPage.tsx](file:///d:/Development/CRM%20Travel/TravneedsSystem/src/components/sales/QuotationBuilderPage.tsx)
- Ensure `buildFinalQuoteData` passes `source.fixedCosts` to both `calculatePricingFromServiceLines` and `buildProfitAnalysis`.

---

## 5. Verification Plan

### Automated Tests
Verify typescript and compile errors:
```bash
npm run build
```

Run ESLint specifically on modified files:
```bash
npx eslint src/components/categories/ProductServiceCategoriesPage.tsx src/utils/quotationCalculations.ts src/components/sales/CostingStep.tsx src/components/sales/PricingStep.tsx src/components/sales/QuotationPreviewPage.tsx src/components/sales/QuotationBuilderPage.tsx
```

### Manual Verification
1. **Supplier Policy Rules**: Navigate to `/reservations/suppliers/SUP-001`, open the Contracts tab, add cancellation/supplement rules, edit, toggle status, and verify UI rules list.
2. **Product Rate Matrix**: Navigate to `/product-categories/items/ITEM-001`, check the Matrix. Next, navigate to `/product-categories`, click edit on an item, verify we can add/delete rate rows in the catalog modal, and observe warning if selling price is below cost.
3. **Quotation Fixed Cost Center**: Navigate to `/sales/cases/CASE-2025-001/quotations/create`, proceed to Costing step, add fixed costs, toggle allocation methods, verify pricing step updates (total cost, margins), save draft, click preview, and verify the proposal preview shows fixed costs and totals.
