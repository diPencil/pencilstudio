const fs = require('fs');
const path = require('path');

const enContent = fs.readFileSync('src/localization/messages/en.ts', 'utf-8');
const enKeys = [...enContent.matchAll(/'([^']+)'\s*:/g)].map(m => m[1]);

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else if (file.endsWith('.tsx') || file.endsWith('.ts')) {
      results.push(file);
    }
  });
  return results;
}

const files = walk('src/components/omnichannel');
const usedKeys = new Set();
files.forEach(f => {
  const content = fs.readFileSync(f, 'utf-8');
  // t('omnichannel.foo.bar')
  const matches = content.matchAll(/t\(['"](omnichannel\.[^'"]+)['"]\)/g);
  for (const m of matches) {
    usedKeys.add(m[1]);
  }
});

const missingInDict = [...usedKeys].filter(k => !enKeys.includes(k));

console.log('Missing in EN dictionary:');
console.log(missingInDict);
