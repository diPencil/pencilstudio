const fs = require('fs');
const path = require('path');

function walk(dir) {
    let results = [];
    const list = fs.readdirSync(dir);
    list.forEach(file => {
        file = path.join(dir, file);
        const stat = fs.statSync(file);
        if (stat && stat.isDirectory()) {
            results = results.concat(walk(file));
        } else if (file.endsWith('.tsx')) {
            results.push(file);
        }
    });
    return results;
}

const files = walk('d:/Development/CRM Travel/TravneedsSystem/src/components');
let modifiedCount = 0;

for (const file of files) {
    let content = fs.readFileSync(file, 'utf8');
    let original = content;

    // Check if file has a blue banner
    if (!content.includes('bg-[#2563EB]')) continue;
    
    // We want to wrap text nodes inside <Button> that are inside the banner.
    // Since doing AST parsing is hard, let's use a simpler approach:
    // If we just add a global className to the action container, we can use CSS to style it.
    
    // The action container is usually:
    // className={cn("flex flex-wrap items-center gap-3", isRTL && "flex-row-reverse")}
    // Let's replace it with:
    // className={cn("flex flex-wrap items-center gap-2 sm:gap-3 banner-actions", isRTL && "flex-row-reverse")}
    
    let modified = content.replace(
        /className=\{cn\(\"flex flex-wrap items-center gap-3\"/g, 
        'className={cn("flex items-center gap-2 sm:gap-3 banner-actions"'
    );
    modified = modified.replace(
        /className=\{cn\(\"flex flex-wrap items-center gap-4\"/g, 
        'className={cn("flex items-center gap-2 sm:gap-4 banner-actions"'
    );
    // Also "flex items-center gap-3"
    modified = modified.replace(
        /className=\{cn\(\"flex items-center gap-3\"/g, 
        'className={cn("flex items-center gap-2 sm:gap-3 banner-actions"'
    );
    modified = modified.replace(
        /className=\{cn\(\"flex items-center gap-4\"/g, 
        'className={cn("flex items-center gap-2 sm:gap-4 banner-actions"'
    );

    if (modified !== original) {
        fs.writeFileSync(file, modified);
        modifiedCount++;
    }
}

console.log('Modified', modifiedCount, 'files');
