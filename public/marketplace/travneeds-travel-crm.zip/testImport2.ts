import { OmnichannelMockStoreProvider } from './src/components/omnichannel/store/OmnichannelMockStore';
console.log("OmnichannelMockStoreProvider is:", typeof OmnichannelMockStoreProvider);
