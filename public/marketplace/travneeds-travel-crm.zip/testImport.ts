import { OmnichannelInboxFilters } from './src/components/omnichannel/inbox/OmnichannelInboxFilters';
import { OmnichannelConversationList } from './src/components/omnichannel/inbox/OmnichannelConversationList';
import { OmnichannelConversationWorkspace } from './src/components/omnichannel/inbox/OmnichannelConversationWorkspace';
import { OmnichannelCustomerContextPanel } from './src/components/omnichannel/inbox/OmnichannelCustomerContextPanel';
import { OmnichannelConversionModal } from './src/components/omnichannel/inbox/OmnichannelConversionModal';
import { Card, CardContent } from './src/components/ui/Card';
import { MessageCircleMore } from 'lucide-react';
import { Button } from './src/components/ui/Button';

console.log("OmnichannelInboxFilters:", typeof OmnichannelInboxFilters);
console.log("OmnichannelConversationList:", typeof OmnichannelConversationList);
console.log("OmnichannelConversationWorkspace:", typeof OmnichannelConversationWorkspace);
console.log("OmnichannelCustomerContextPanel:", typeof OmnichannelCustomerContextPanel);
console.log("OmnichannelConversionModal:", typeof OmnichannelConversionModal);
console.log("Card:", typeof Card);
console.log("CardContent:", typeof CardContent);
console.log("MessageCircleMore:", typeof MessageCircleMore);
console.log("Button:", typeof Button);
