# Travneeds System
> **Integrated Management System for Travel & Tourism**

A modern, premium, and feature-rich CRM and ERP system designed specifically for travel agencies and tourism operators. This platform streamlines operations, manages leads, tracks sales, and simplifies financial oversight.

## 🚀 Quick Start

### Installation
```bash
npm install
```

### Development
```bash
npm run dev
```
The application will be available at `http://localhost:5173`.

### Build for Production
```bash
npm run build
```

---

## ✨ Key Features

### 📊 Business Intelligence
- **Dashboard & Analytics**: Real-time KPIs, revenue tracking, and booking trends.
- **Advanced Reports**: Customizable data insights with charts and export options.

### 🎯 Sales & CRM
- **Lead management**: Capture and track leads through an intelligent pipeline.
- **Customer Database**: Complete profiles with booking history and corporate accounts.
- **Sales & Invoicing**: Quote generation, deal tracking, and automated invoicing.

### 🏨 Operations & Reservations
- **Smart Reservations**: Manage hotels, flights, tours, and activities.
- **Product Categories**: Detailed organization of travel services and pricing.
- **Operations Workflow**: Supplier management and transport coordination.

### 🛠️ Support & Management
- **Support Tickets**: Built-in ticketing system with priority routing.
- **User Management**: Advanced role-based access control (RBAC).
- **Attendance**: Employee shift tracking and attendance management.

---

## 🎨 Design & UI

- **Modern SaaS Aesthetic**: Clean, professional, and minimal interface.
- **Collapsible Sidebar**: Dynamic navigation that adapts to your screen.
- **Dark & Light Mode**: Seamless support for both visual themes.
- **Premium Landing Page**: High-conversion landing page with glassmorphism and motion.

---

## 🛠️ Technology Stack

- **Frontend**: [React](https://reactjs.org/) + [Vite](https://vitejs.dev/)
- **Language**: [TypeScript](https://www.typescriptlang.org/)
- **Styling**: [Tailwind CSS](https://tailwindcss.com/)
- **Icons**: [Lucide React](https://lucide.dev/)
- **Charts**: [Recharts](https://recharts.org/)
- **State Management**: React Hooks & Context API

---

## 📝 Demo Credentials
- **Email**: `admin@travneeds.com`
- **Password**: `password123`

---

## 🏢 Credits
© 2026 **Travneeds System**. All rights reserved.

Powered by [**diPencil Studio**](https://dipencil.com)
