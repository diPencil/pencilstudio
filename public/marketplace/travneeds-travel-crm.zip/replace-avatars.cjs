const fs = require('fs');
const path = require('path');

const femaleNames = ['Sarah', 'Layla', 'Sally', 'Fatima', 'Emily', 'Jessica', 'Aida', 'Nour'];

function isFemale(name) {
    const firstPart = name.split('+')[0];
    return femaleNames.includes(firstPart);
}

function walk(dir) {
    let results = [];
    const list = fs.readdirSync(dir);
    list.forEach(file => {
        file = path.join(dir, file);
        const stat = fs.statSync(file);
        if (stat && stat.isDirectory()) {
            results = results.concat(walk(file));
        } else if (file.endsWith('.ts') || file.endsWith('.tsx')) {
            results.push(file);
        }
    });
    return results;
}

const files = walk('d:/Development/CRM Travel/TravneedsSystem/src');
let modifiedCount = 0;

for (const file of files) {
    let content = fs.readFileSync(file, 'utf8');
    let original = content;

    // We will replace all ui-avatars.com URLs
    // Example: 'https://ui-avatars.com/api/?name=Sally+Travels&background=0D8ABC&color=fff'
    const regex = /https:\/\/ui-avatars\.com\/api\/\?name=([a-zA-Z0-9\+%]+)(?:&[a-zA-Z0-9=]+)*/g;
    
    content = content.replace(regex, (match, nameParam) => {
        const decodedName = nameParam.replace(/\+/g, ' ').replace(/%20/g, ' ');
        const firstPart = decodedName.split(' ')[0];
        if (femaleNames.includes(firstPart)) {
            return '/avatar-female.png';
        } else {
            return '/avatar-male.png';
        }
    });

    if (content !== original) {
        fs.writeFileSync(file, content);
        modifiedCount++;
        console.log(`Updated ${file}`);
    }
}

console.log(`Replaced avatars in ${modifiedCount} files.`);
