export type MaintenanceCenterBrand = {
  id: string
  name: string
  image: string
  description: string
}

export const maintenanceCenterBrands: MaintenanceCenterBrand[] = [
  {
    id: "lg",
    name: "LG",
    image: "/maintenancecenter/lg-appliances-brand-logo.jpg",
    description: "متخصصون في صيانة أجهزة LG بجميع أنواعها",
  },
  {
    id: "kiriazi",
    name: "كريازي",
    image: "/maintenancecenter/kiriazi-appliances-egyptian-brand.jpg",
    description: "خدمات متخصصة لأجهزة كريازي المصرية",
  },
  {
    id: "universal",
    name: "يونيفرسال",
    image: "/maintenancecenter/universal-appliances-brand.jpg",
    description: "فنيون معتمدون لصيانة أجهزة يونيفرسال",
  },
  {
    id: "fresh",
    name: "فريش",
    image: "/maintenancecenter/fresh-appliances-egyptian-brand.jpg",
    description: "متخصصون في صيانة أجهزة فريش المصرية",
  },
  {
    id: "gree",
    name: "جري",
    image: "/maintenancecenter/gree-air-conditioning-brand.jpg",
    description: "خدمات متخصصة لأجهزة التكييف والتبريد جري",
  },
  {
    id: "power",
    name: "باور",
    image: "/maintenancecenter/power-appliances-brand.jpg",
    description: "فنيون معتمدون لصيانة أجهزة باور",
  },
  {
    id: "carrier",
    name: "كاريير",
    image: "/maintenancecenter/carrier-air-conditioning-brand.jpg",
    description: "متخصصون في صيانة مكيفات كاريير",
  },
  {
    id: "union-air",
    name: "يونيون إير",
    image: "/maintenancecenter/union-air-conditioning-brand.jpg",
    description: "خدمات متخصصة لأجهزة التكييف يونيون إير",
  },
  {
    id: "york",
    name: "يورك",
    image: "/maintenancecenter/york-air-conditioning-brand.jpg",
    description: "فنيون معتمدون لصيانة مكيفات يورك",
  },
  {
    id: "white-whale",
    name: "وايت ويل",
    image: "/maintenancecenter/maintenance-center-white-whale.jpg",
    description: "خدمات متخصصة لصيانة أجهزة وايت ويل",
  },
  {
    id: "white-westinghouse",
    name: "وايت وستنجهاوس",
    image: "/maintenancecenter/maintenance-center-white-westinghouse.jpg",
    description: "خدمات متخصصة لصيانة أجهزة وايت وستنجهاوس",
  },
  {
    id: "white-point",
    name: "وايت بوينت",
    image: "/maintenancecenter/maintenance-center-white-point.jpg",
    description: "متخصصون في صيانة أجهزة وايت بوينت",
  },
  {
    id: "samsung",
    name: "سامسونج",
    image: "/maintenancecenter/maintenance-center-samsung.jpg",
    description: "خدمات صيانة معتمدة لأجهزة سامسونج",
  },
  {
    id: "ariston",
    name: "اريستون",
    image: "/maintenancecenter/maintenance-center-ariston.jpg",
    description: "فنيون معتمدون لصيانة أجهزة اريستون",
  },
  {
    id: "frigidaire",
    name: "فريجيدير",
    image: "/maintenancecenter/maintenance-center-frigidaire.jpg",
    description: "صيانة احترافية لأجهزة فريجيدير",
  },
  {
    id: "general-electric",
    name: "جنرال اليكتريك",
    image: "/maintenancecenter/maintenance-center-general-electric.jpg",
    description: "خدمات متخصصة لأجهزة جنرال اليكتريك",
  },
  {
    id: "vaguer",
    name: "فاجوار",
    image: "/maintenancecenter/maintenance-center-vaguer.jpg",
    description: "صيانة معتمدة لأجهزة فاجوار",
  },
  {
    id: "westinghouse",
    name: "وستنجهاوس",
    image: "/maintenancecenter/maintenance-center-westinghouse.jpg",
    description: "فنيون متخصصون لصيانة أجهزة وستنجهاوس",
  },
  {
    id: "kelvinator",
    name: "كلفنيتور",
    image: "/maintenancecenter/maintenance-center-kelvinator.jpg",
    description: "خدمات صيانة متخصصة لأجهزة كلفنيتور",
  },
  {
    id: "siemens",
    name: "سيمنز",
    image: "/maintenancecenter/maintenance-center-siemens.jpg",
    description: "صيانة احترافية لأجهزة سيمنز",
  },
  {
    id: "zanussi",
    name: "زانوسي",
    image: "/maintenancecenter/maintenance-center-zanussi.jpg",
    description: "متخصصون في صيانة أجهزة زانوسي",
  },
  {
    id: "ideal",
    name: "ايديال",
    image: "/maintenancecenter/maintenance-center-ideal.jpg",
    description: "خدمات متخصصة لأجهزة ايديال",
  },
  {
    id: "sharp",
    name: "شارب",
    image: "/maintenancecenter/maintenance-center-sharp.jpg",
    description: "صيانة معتمدة لأجهزة شارب",
  },
  {
    id: "toshiba",
    name: "توشيبا",
    image: "/maintenancecenter/maintenance-center-toshiba.jpg",
    description: "فنيون معتمدون لصيانة أجهزة توشيبا",
  },
  {
    id: "hitachi",
    name: "هيتاشي",
    image: "/maintenancecenter/maintenance-center-hitachi.jpg",
    description: "خدمات صيانة متخصصة لأجهزة هيتاشي",
  },
  {
    id: "alaska",
    name: "ألاسكا",
    image: "/maintenancecenter/maintenance-center-alaska.jpg",
    description: "صيانة احترافية لأجهزة ألاسكا",
  },
  {
    id: "hoover",
    name: "هوڤر",
    image: "/maintenancecenter/maintenance-center-hoover.jpg",
    description: "متخصصون في صيانة أجهزة هوڤر",
  },
  {
    id: "daewoo",
    name: "دايو",
    image: "/maintenancecenter/maintenance-center-daewoo.jpg",
    description: "خدمات صيانة معتمدة لأجهزة دايو",
  },
  {
    id: "electrolux",
    name: "اليكترلوكس",
    image: "/maintenancecenter/maintenance-center-electrolux.jpg",
    description: "صيانة احترافية لأجهزة اليكترلوكس",
  },
  {
    id: "electrostar",
    name: "إليكتروستار",
    image: "/maintenancecenter/maintenance-center-electrostar.jpg",
    description: "فنيون متخصصون لصيانة أجهزة إليكتروستار",
  },
  {
    id: "beko",
    name: "بيكو",
    image: "/maintenancecenter/maintenance-center-beko.jpg",
    description: "خدمات متخصصة لأجهزة بيكو",
  },
  {
    id: "whirlpool",
    name: "وايرليبول",
    image: "/maintenancecenter/maintenance-center-whirlpool.jpg",
    description: "صيانة معتمدة لأجهزة وايرليبول",
  },
  {
    id: "bosch",
    name: "بوش",
    image: "/maintenancecenter/maintenance-center-bosch.jpg",
    description: "فنيون معتمدون لصيانة أجهزة بوش",
  },
  {
    id: "indesit",
    name: "انديست",
    image: "/maintenancecenter/maintenance-center-indesit.jpg",
    description: "خدمات صيانة متخصصة لأجهزة انديست",
  },
  {
    id: "candy",
    name: "كاندي",
    image: "/maintenancecenter/maintenance-center-candy.jpg",
    description: "صيانة احترافية لأجهزة كاندي",
  },
  {
    id: "basab",
    name: "باساب",
    image: "/maintenancecenter/maintenance-center-basab.jpg",
    description: "متخصصون في صيانة أجهزة باساب",
  },
  {
    id: "haier",
    name: "هاير",
    image: "/maintenancecenter/maintenance-center-haier.png",
    description: "خدمات صيانة معتمدة لأجهزة هاير",
  },
  {
    id: "geronji",
    name: "چيرونچي",
    image: "/maintenancecenter/maintenance-center-geronji.jpg",
    description: "صيانة احترافية لأجهزة چيرونچي",
  },
  {
    id: "miele",
    name: "مييلا",
    image: "/maintenancecenter/maintenance-center-miele.jpg",
    description: "فنيون متخصصون لصيانة أجهزة مييلا",
  },
]






