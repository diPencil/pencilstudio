export type ServiceInfo = {
  id: string
  title: string
  description: string
  items: string[]
  image: string
  icon: "Wrench" | "Droplet" | "Flame" | "Wind" | "Zap"
}

export const servicesData: ServiceInfo[] = [
  {
    id: "washing-machines",
    title: "صيانة غسالات الملابس",
    description: "صيانة شاملة واحترافية لجميع أنواع الغسالات الأوتوماتيك والفوق أوتوماتيك",
    items: [
      "صيانة شاملة لجميع أنواع الغسالات الأوتوماتيك والفوق أوتوماتيك",
      "تشخيص دقيق للأعطال (الموتور – السخان – لوحة التحكم – حساس المياه)",
      "تنظيف احترافي للأجزاء الداخلية وضبط التوازن",
      "اختبار دورة كاملة أمام العميل بعد الإصلاح",
    ],
    image: "/washing-machine-repair-technician.jpg",
    icon: "Wrench",
  },
  {
    id: "refrigerators",
    title: "صيانة الثلاجات والديب فريزر",
    description: "إصلاح شامل لأعطال التبريد والتجميد مع ضمان مكتوب",
    items: [
      "إصلاح شامل لأعطال التبريد والتجميد",
      "معالجة تسرب الفريون أو تلف الكمبروسر والثرموستات",
      "تنظيف دوائر التبريد وضبط توزيع الهواء",
      "تقليل استهلاك الكهرباء وتحسين الأداء",
    ],
    image: "/refrigerator-repair-service.jpg",
    icon: "Droplet",
  },
  {
    id: "dishwashers",
    title: "صيانة غسالات الأطباق",
    description: "فحص شامل وإصلاح دقيق لجميع أنواع غسالات الأطباق",
    items: [
      "فحص شامل للفلاتر والرشاشات ونظام التسخين",
      "معالجة مشاكل الصرف والدورات غير المكتملة",
      "إعادة ضبط المستشعرات وتحسين الأداء",
      "اختبار عملي أمام العميل",
    ],
    image: "/dishwasher-repair-maintenance.jpg",
    icon: "Flame",
  },
  {
    id: "microwaves",
    title: "صيانة الميكروويف",
    description: "فحص واستبدال القطع بأصلية معتمدة مع ضمان",
    items: [
      "فحص الماجنترون والمحول ولوحة التحكم",
      "استبدال القطع بأصلية معتمدة",
      "اختبار توزيع الحرارة والأمان",
      "ضمان مكتوب على كل إصلاح",
    ],
    image: "/microwave-oven-repair-service.jpg",
    icon: "Wind",
  },
  {
    id: "dryers",
    title: "صيانة المجففات",
    description: "صيانة متخصصة وموثوقة لجميع أنواع المجففات",
    items: [
      "فحص عناصر التسخين والدوران وحساسات الرطوبة",
      "استبدال السيور والمحركات وتنظيف مجرى الهواء",
      "ضبط المستشعرات الإلكترونية",
      "ضمان تجفيف مثالي في كل دورة",
    ],
    image: "/clothes-dryer-repair-technician.jpg",
    icon: "Zap",
  },
]











