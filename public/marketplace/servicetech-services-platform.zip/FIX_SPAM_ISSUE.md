# حل مشكلة وصول الإيميلات إلى Junk/Spam

## المشكلة

الإيميلات المرسلة من الفورم بتوصل في مجلد Junk (Spam) بدل Inbox.

## الأسباب المحتملة

### 1. عدم تطابق From Address مع SMTP User
- **المشكلة:** لو الـ From address مختلف عن الـ SMTP_USER، الإيميل ممكن يتصنف كـ spam
- **الحل:** استخدام نفس الإيميل في From و SMTP_USER

### 2. عدم وجود SPF/DKIM/DMARC Records
- **المشكلة:** لو الـ domain مش عنده SPF/DKIM/DMARC records مضبوطة، الإيميلات ممكن تتصنف كـ spam
- **الحل:** ضبط الـ DNS records في Hostinger

### 3. محتوى الإيميل يبدو Spam-like
- **المشكلة:** استخدام emojis كتير أو محتوى HTML معقد ممكن يسبب spam
- **الحل:** تحسين محتوى الإيميل (تم إصلاحه)

### 4. IP Address غير معتمد
- **المشكلة:** لو الـ IP address اللي بيبعت الإيميل (Vercel) مش معتمد، ممكن يسبب spam
- **الحل:** استخدام SMTP server معتمد (Hostinger)

## الحلول المطبقة في الكود

### 1. استخدام SMTP_USER في From Address
```typescript
from: `"Service Egy" <${smtpUser}>`, // Use SMTP_USER, not SMTP_FROM
```

### 2. إضافة Reply-To Header
```typescript
replyTo: smtpUser, // Reply to the same email
```

### 3. تحسين Email Headers
```typescript
headers: {
  "X-Mailer": "Service Egy Contact Form",
  "MIME-Version": "1.0",
}
```

### 4. إصلاح Encoding
- تم إصلاح encoding النصوص العربية بشكل صحيح

## الحلول المطلوبة في Hostinger

### 1. ضبط SPF Record

اذهب إلى Hostinger → DNS Settings وأضف TXT record:

```
Type: TXT
Name: @
Value: v=spf1 include:_spf.hostinger.com ~all
TTL: 3600
```

### 2. ضبط DKIM Record (اختياري)

لو Hostinger يدعم DKIM، أضف DKIM record:

```
Type: TXT
Name: default._domainkey
Value: [DKIM value from Hostinger]
TTL: 3600
```

### 3. ضبط DMARC Record (اختياري)

أضف DMARC record:

```
Type: TXT
Name: _dmarc
Value: v=DMARC1; p=none; rua=mailto:info@service-egy.com
TTL: 3600
```

## خطوات إصلاح المشكلة

### الخطوة 1: التأكد من Environment Variables في Vercel

تأكد من أن:
- `SMTP_USER` = `info@service-egy.com` (أو إيميلك على Hostinger)
- `SMTP_FROM` = نفس `SMTP_USER` (أو اتركه فارغ)
- `SMTP_TO` = `info@service-egy.com` (الإيميل اللي عايز تستقبل عليه)

### الخطوة 2: ضبط SPF Record في Hostinger

1. اذهب إلى Hostinger → DNS Management
2. أضف TXT record:
   - Name: `@`
   - Value: `v=spf1 include:_spf.hostinger.com ~all`
   - TTL: `3600`
3. احفظ التغييرات
4. انتظر 24-48 ساعة حتى يحدث DNS

### الخطوة 3: اختبار الإيميلات

1. أرسل فورم تجريبي
2. تحقق من مجلد Inbox
3. لو لسه في Junk:
   - اضغط "Not Spam" أو "Mark as Not Junk"
   - اضيف الإيميل إلى Contacts
   - تحقق من SPF record (استخدم [MXToolbox](https://mxtoolbox.com/spf.aspx))

### الخطوة 4: تحسين Reputation (اختياري)

1. أرسل إيميلات قليلة في البداية
2. تأكد من أن المستلمين يضيفون الإيميل إلى Contacts
3. تجنب إرسال إيميلات كثيرة في وقت قصير

## نصائح إضافية

### 1. استخدام نفس Domain
- استخدم نفس domain في From و SMTP_USER
- مثال: `info@service-egy.com` في From و SMTP_USER

### 2. تحسين محتوى الإيميل
- تجنب استخدام emojis كتير في الـ subject
- استخدم plain text version بشكل جيد
- تأكد من أن HTML email صحيح

### 3. اختبار الإيميلات
- استخدم [Mail-Tester](https://www.mail-tester.com/) لاختبار الإيميلات
- استخدم [MXToolbox](https://mxtoolbox.com/) للتحقق من SPF/DKIM/DMARC

## التحقق من الإصلاح

بعد تطبيق الحلول:

1. **تحقق من SPF Record:**
   ```bash
   nslookup -type=TXT service-egy.com
   ```
   أو استخدم [MXToolbox SPF Checker](https://mxtoolbox.com/spf.aspx)

2. **اختبار الإيميل:**
   - أرسل فورم تجريبي
   - تحقق من مجلد Inbox
   - لو لسه في Junk، اضغط "Not Spam"

3. **مراقبة الإيميلات:**
   - راقب الإيميلات الجديدة
   - تأكد من وصولها إلى Inbox

## ملاحظات مهمة

1. **DNS Propagation:** التغييرات في DNS ممكن تستغرق 24-48 ساعة
2. **Email Reputation:** بناء reputation جيد ممكن يستغرق وقت
3. **SPF Record:** مهم جداً لتجنب spam
4. **Testing:** استخدم Mail-Tester لاختبار الإيميلات قبل الإرسال الفعلي

## الدعم

إذا استمرت المشكلة:
1. تحقق من SPF record باستخدام [MXToolbox](https://mxtoolbox.com/spf.aspx)
2. اتصل بدعم Hostinger للتحقق من إعدادات SMTP
3. استخدم [Mail-Tester](https://www.mail-tester.com/) لاختبار الإيميلات









