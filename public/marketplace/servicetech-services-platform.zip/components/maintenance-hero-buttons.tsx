"use client"

import { useState } from "react"
import { Phone, Mail } from "lucide-react"
import MaintenanceFormDialog from "@/components/maintenance-form-dialog"

interface MaintenanceHeroButtonsProps {
  brandName: string
}

export default function MaintenanceHeroButtons({ brandName }: MaintenanceHeroButtonsProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  return (
    <>
      <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 items-stretch sm:items-center">
        <a
          href="tel:01110195560"
          className="inline-flex items-center justify-center gap-2 sm:gap-3 bg-white text-[#2563eb] w-full sm:w-auto sm:flex-1 sm:max-w-sm px-4 sm:px-6 py-3 sm:py-4 rounded-full font-bold hover:shadow-xl hover:bg-blue-50 transition-all hover:scale-105 group"
        >
          <div className="bg-[#2563eb]/10 p-1.5 sm:p-2 rounded-lg group-hover:bg-[#2563eb]/20 transition-colors">
            <Phone className="w-4 h-4 sm:w-5 sm:h-5 text-[#2563eb]" />
          </div>
          <div className="text-center text-lg sm:text-xl md:text-2xl text-[#2563eb] font-bold whitespace-nowrap">
            الخط الساخن 01110195560
          </div>
        </a>
        <button
          onClick={() => setIsDialogOpen(true)}
          className="inline-flex items-center justify-center gap-2 sm:gap-3 border-2 border-white text-white bg-white/10 hover:bg-white/20 w-full sm:w-auto sm:flex-1 sm:max-w-sm px-4 sm:px-6 py-3 sm:py-4 rounded-full font-bold hover:shadow-xl transition-all hover:scale-105 group"
        >
          <div className="bg-white/20 p-1.5 sm:p-2 rounded-lg group-hover:bg-white/30 transition-colors">
            <Mail className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <div className="text-center text-lg sm:text-xl md:text-2xl font-bold whitespace-nowrap">
            املأ نموذج الصيانة
          </div>
        </button>
      </div>

      {/* Maintenance Form Dialog */}
      <MaintenanceFormDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        brandName={brandName}
      />
    </>
  )
}








