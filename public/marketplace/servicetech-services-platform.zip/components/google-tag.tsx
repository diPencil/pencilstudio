"use client"

import Script from "next/script"

export default function GoogleTag() {
  return (
    <>
      {/* Google tag (gtag.js) */}
      <Script
        src="https://www.googletagmanager.com/gtag/js?id=AW-16709869771"
        strategy="afterInteractive"
      />
      <Script
        id="google-tag-init"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'AW-16709869771');
          `,
        }}
      />

      {/* Event snippet for انقر للاتصال conversion page */}
      <Script
        id="google-tag-conversion-function"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: `
            function gtag_report_conversion(url) {
              var callback = function () {
                if (typeof(url) != 'undefined') {
                  window.location = url;
                }
              };
              gtag('event', 'conversion', {
                  'send_to': 'AW-16709869771/IIOrCNCTl8AbEMvB8Z8-',
                  'event_callback': callback
              });
              return false;
            }
          `,
        }}
      />

      {/* Event snippet for عملية شراء conversion page */}
      <Script
        id="google-tag-purchase-conversion"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: `
            if (typeof gtag !== 'undefined') {
              gtag('event', 'conversion', {
                  'send_to': 'AW-16709869771/JBG4CO_I69cZEMvB8Z8-',
                  'transaction_id': ''
              });
            }
          `,
        }}
      />
    </>
  )
}

