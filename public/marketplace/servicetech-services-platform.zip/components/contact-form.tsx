"use client"

import { useState } from "react"
import { Phone, Mail, MapPin, Wrench, MessageSquare, Loader2 } from "lucide-react"
import { useRouter } from "next/navigation"

interface ContactFormProps {
  serviceType?: string
  brandName?: string
}

export default function ContactForm({ serviceType, brandName }: ContactFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const router = useRouter()

  const [formData, setFormData] = useState({
    name: "",
    address: "",
    phone: "",
    whatsapp: "",
    issueType: "",
    deviceType: "",
    details: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Format email content
      const emailSubject = `طلب صيانة جديد من ${formData.name}`
      const emailBody = `
طلب صيانة جديد من موقع Service Egy

البيانات الشخصية:
- الاسم: ${formData.name}
- العنوان: ${formData.address}
- رقم التليفون: ${formData.phone}
- رقم الواتساب: ${formData.whatsapp}

تفاصيل الطلب:
- نوع العطل: ${formData.issueType}
- نوع الجهاز: ${formData.deviceType}
${serviceType ? `- نوع الخدمة: ${serviceType}` : ""}
${brandName ? `- الماركة: ${brandName}` : ""}
${formData.details ? `- تفاصيل إضافية: ${formData.details}` : ""}

التاريخ والوقت: ${new Date().toLocaleString("ar-EG", {
        timeZone: "Africa/Cairo",
      })}
      `.trim()

      // Try API route first (for server-side SMTP)
      const apiEndpoint = process.env.NEXT_PUBLIC_CONTACT_ENDPOINT || "/api/contact"
      console.log("Sending request to API endpoint:", apiEndpoint)

      try {
        const response = await fetch(apiEndpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          mode: apiEndpoint.startsWith('http') ? 'cors' : 'same-origin',
          credentials: apiEndpoint.startsWith('http') ? 'omit' : 'same-origin',
          body: JSON.stringify({
            ...formData,
            serviceType: serviceType || "",
            brandName: brandName || "",
          }),
        })

        console.log("API Response status:", response.status, response.statusText)

        if (!response.ok) {
          // If response is not ok, try to get error message
          let errorMessage = "فشل إرسال الطلب"
          try {
            const errorResult = await response.json()
            errorMessage = errorResult.error || errorMessage
            console.error("API Error:", errorResult)
          } catch (e) {
            console.error("Failed to parse error response:", e)
            errorMessage = `فشل إرسال الطلب (${response.status} ${response.statusText})`
          }
          throw new Error(errorMessage)
        }

        const result = await response.json()
        console.log("API Response:", result)

        if (result.success) {
          // Save form data to localStorage as backup
          try {
            localStorage.setItem('lastContactForm', JSON.stringify({
              ...formData,
              serviceType: serviceType || "",
              brandName: brandName || "",
              timestamp: new Date().toISOString(),
            }))
          } catch (e) {
            // Ignore localStorage errors
          }

          // Redirect to thank you page
          router.push("/thank-you")
          return
        } else {
          throw new Error(result.error || "فشل إرسال الطلب")
        }
      } catch (apiError: any) {
        // Log the error for debugging
        console.error("API Error Details:", apiError)
        console.error("Error message:", apiError.message)
        console.error("Error stack:", apiError.stack)
        
        // Show error to user
        const errorMessage = apiError.message || "فشل الاتصال بخادم API. يرجى المحاولة مرة أخرى أو التواصل معنا مباشرة."
        alert(`خطأ: ${errorMessage}\n\nإذا استمرت المشكلة، يرجى التواصل معنا مباشرة على:\n📧 info@service-egy.com\n📞 01110195560`)
        setIsSubmitting(false)
        return
      }

      // Fallback: Use Web3Forms for static export
      const web3formsKey = process.env.NEXT_PUBLIC_WEB3FORMS_KEY
      if (web3formsKey && web3formsKey !== 'YOUR_ACCESS_KEY_HERE') {
        try {
          const response = await fetch('https://api.web3forms.com/submit', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: JSON.stringify({
              access_key: web3formsKey,
              subject: emailSubject,
              from_name: formData.name,
              email: 'info@service-egy.com',
              message: emailBody,
              name: formData.name,
              address: formData.address,
              phone: formData.phone,
              whatsapp: formData.whatsapp,
              issueType: formData.issueType,
              deviceType: formData.deviceType,
              serviceType: serviceType || '',
              brandName: brandName || '',
              details: formData.details || '',
            }),
          })

          const result = await response.json()

          if (result.success) {
            // Save form data to localStorage as backup
            try {
              localStorage.setItem('lastContactForm', JSON.stringify({
                ...formData,
                serviceType: serviceType || "",
                brandName: brandName || "",
                timestamp: new Date().toISOString(),
              }))
            } catch (e) {
              // Ignore localStorage errors
            }

            // Redirect to thank you page
            router.push("/thank-you")
            return
          }
        } catch (web3Error) {
          console.error("Web3Forms error:", web3Error)
        }
      }

      // If both fail, save and redirect anyway
      try {
        localStorage.setItem('lastContactForm', JSON.stringify({
          ...formData,
          serviceType: serviceType || "",
          brandName: brandName || "",
          timestamp: new Date().toISOString(),
        }))
      } catch (e) {
        // Ignore localStorage errors
      }

      // Redirect to thank you page (user can contact manually)
      router.push("/thank-you")
    } catch (error) {
      console.error("Error submitting form:", error)
      alert("حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى أو التواصل معنا مباشرة على: info@service-egy.com")
      setIsSubmitting(false)
    }
  }

  const issueTypes = [
    "عطل كهربائي",
    "عطل ميكانيكي",
    "مشكلة في التبريد/التسخين",
    "مشكلة في الصرف",
    "صوت غير طبيعي",
    "لا يعمل نهائياً",
    "مشكلة أخرى",
  ]

  const deviceTypes = [
    "غسالة ملابس",
    "ثلاجة",
    "ديب فريزر",
    "غسالة أطباق",
    "ميكروويف",
    "مجفف",
    "مكيف هواء",
    "جهاز آخر",
  ]

  return (
    <section className="py-12 sm:py-16 md:py-20 px-4 sm:px-6 bg-gradient-to-b from-white to-[#F5F7FA]">
      <div className="max-w-7xl mx-auto">
        {/* Title */}
        <div className="text-center mb-8 sm:mb-12">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-[#2563eb] mb-3 sm:mb-4">طلب خدمة صيانة {brandName ? `${brandName}` : ''}</h2>
          <p className="text-base sm:text-lg md:text-xl text-[#707070]">
            املأ النموذج وسنتواصل معك في أقرب وقت ممكن
          </p>
        </div>

        {/* Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 md:gap-10 items-start">
          {/* Right Side - Image & Info */}
          <div className="order-2 md:order-1 space-y-4 sm:space-y-6">
            {/* Main Image */}
            <div className="relative h-56 sm:h-72 md:h-80 lg:h-96 rounded-xl sm:rounded-2xl overflow-hidden shadow-xl">
              <img
                src="/professional-technician-repairing-washing-machine.jpg"
                alt="فني صيانة محترف"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4 sm:p-6">
                <div className="text-white">
                  <h3 className="text-lg sm:text-xl md:text-2xl font-bold mb-1 sm:mb-2">فنيون معتمدون</h3>
                  <p className="text-xs sm:text-sm md:text-base text-white/90">خبرة تزيد عن 15 عاماً في الصيانة</p>
                </div>
              </div>
            </div>

            {/* Info Cards */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-4 sm:p-6 rounded-xl shadow-md text-center">
                <div className="bg-[#2563eb]/10 w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Phone className="w-6 h-6 sm:w-7 sm:h-7 text-[#2563eb]" />
                </div>
                <h4 className="font-bold text-[#2563eb] mb-1 text-sm sm:text-base">استجابة سريعة</h4>
                <p className="text-xs sm:text-sm text-[#707070]">خلال 24 ساعة</p>
              </div>
              <div className="bg-white p-4 sm:p-6 rounded-xl shadow-md text-center">
                <div className="bg-[#2563eb]/10 w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Wrench className="w-6 h-6 sm:w-7 sm:h-7 text-[#2563eb]" />
                </div>
                <h4 className="font-bold text-[#2563eb] mb-1 text-sm sm:text-base">ضمان شامل</h4>
                <p className="text-xs sm:text-sm text-[#707070]">12 شهر</p>
              </div>
            </div>

            {/* Contact Info */}
            <div className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white p-4 sm:p-5 md:p-6 rounded-xl">
              <h4 className="font-bold text-base sm:text-lg md:text-xl mb-3 sm:mb-4">أو تواصل معنا مباشرة</h4>
              <div className="space-y-2 sm:space-y-3">
                <div className="border-b border-white/20 pb-2 sm:pb-3">
                  <p className="text-xs sm:text-sm text-blue-100 mb-1 sm:mb-2">الخط الساخن</p>
                  <a href="tel:01110195560" className="flex items-center gap-2 sm:gap-3 hover:bg-white/10 p-2 rounded-lg transition-colors active:bg-white/20">
                    <Phone className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0" />
                    <span className="font-bold text-lg sm:text-xl">01110195560</span>
                  </a>
                </div>
                
                <div className="border-b border-white/20 pb-2 sm:pb-3">
                  <p className="text-xs sm:text-sm text-blue-100 mb-1 sm:mb-2">أرقام الدعم</p>
                  <div className="space-y-1 sm:space-y-2">
                    <a href="tel:01153625752" className="flex items-center gap-2 sm:gap-3 hover:bg-white/10 p-1.5 sm:p-2 rounded-lg transition-colors active:bg-white/20">
                      <Phone className="w-3.5 h-3.5 sm:w-4 sm:h-4 flex-shrink-0" />
                      <span className="font-semibold text-sm sm:text-base">01153625752</span>
                    </a>
                    <a href="tel:01016503001" className="flex items-center gap-2 sm:gap-3 hover:bg-white/10 p-1.5 sm:p-2 rounded-lg transition-colors active:bg-white/20">
                      <Phone className="w-3.5 h-3.5 sm:w-4 sm:h-4 flex-shrink-0" />
                      <span className="font-semibold text-sm sm:text-base">01016503001</span>
                    </a>
                  </div>
                </div>

                <div>
                  <p className="text-xs sm:text-sm text-blue-100 mb-1 sm:mb-2">البريد الإلكتروني</p>
                  <a href="mailto:info@service-egy.com" className="flex items-center gap-2 sm:gap-3 hover:bg-white/10 p-1.5 sm:p-2 rounded-lg transition-colors active:bg-white/20">
                    <Mail className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0" />
                    <span className="text-xs sm:text-sm break-all">info@service-egy.com</span>
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Left Side - Form */}
          <div className="order-1 md:order-2">
            <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
              {/* Header */}
              <div className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white p-4 sm:p-6">
                <h3 className="text-xl sm:text-2xl font-bold">املأ البيانات</h3>
                <p className="text-sm sm:text-base text-blue-100 mt-1">سنتواصل معك فوراً</p>
              </div>

              {/* Form */}
              <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 sm:space-y-5">
              {/* Name */}
              <div>
                <label htmlFor="name" className="block text-right mb-2 font-bold text-[#2563eb]">
                  <span className="flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    الاسم الكامل *
                  </span>
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  required
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right"
                  placeholder="أدخل اسمك الكامل"
                />
              </div>

              {/* Address */}
              <div>
                <label htmlFor="address" className="block text-right mb-2 font-bold text-[#2563eb]">
                  <span className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    العنوان الكامل *
                  </span>
                </label>
                <input
                  type="text"
                  id="address"
                  name="address"
                  required
                  value={formData.address}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right"
                  placeholder="المحافظة، المدينة، الشارع، رقم العمارة"
                />
              </div>

              {/* Phone */}
              <div>
                <label htmlFor="phone" className="block text-right mb-2 font-bold text-[#2563eb]">
                  <span className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    رقم التليفون *
                  </span>
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  required
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right"
                  placeholder="01XXXXXXXXX"
                  pattern="[0-9]{11}"
                />
              </div>

              {/* WhatsApp */}
              <div>
                <label htmlFor="whatsapp" className="block text-right mb-2 font-bold text-[#2563eb]">
                  <span className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4" />
                    رقم الواتساب *
                  </span>
                </label>
                <input
                  type="tel"
                  id="whatsapp"
                  name="whatsapp"
                  required
                  value={formData.whatsapp}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right"
                  placeholder="01XXXXXXXXX"
                  pattern="[0-9]{11}"
                />
              </div>

              {/* Issue Type */}
              <div>
                <label htmlFor="issueType" className="block text-right mb-2 font-bold text-[#2563eb]">
                  <span className="flex items-center gap-2">
                    <Wrench className="w-4 h-4" />
                    نوع العطل *
                  </span>
                </label>
                <select
                  id="issueType"
                  name="issueType"
                  required
                  value={formData.issueType}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right"
                >
                  <option value="">اختر نوع العطل</option>
                  {issueTypes.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </div>

              {/* Device Type */}
              <div>
                <label htmlFor="deviceType" className="block text-right mb-2 font-bold text-[#2563eb]">
                  <span className="flex items-center gap-2">
                    <Wrench className="w-4 h-4" />
                    نوع الجهاز *
                  </span>
                </label>
                <select
                  id="deviceType"
                  name="deviceType"
                  required
                  value={formData.deviceType}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right"
                >
                  <option value="">اختر نوع الجهاز</option>
                  {deviceTypes.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </div>

              {/* Details */}
              <div>
                <label htmlFor="details" className="block text-right mb-2 font-bold text-[#2563eb]">
                  <span className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4" />
                    تفاصيل إضافية
                  </span>
                </label>
                <textarea
                  id="details"
                  name="details"
                  rows={4}
                  value={formData.details}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right resize-none"
                  placeholder="اكتب تفاصيل إضافية عن المشكلة..."
                />
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white px-6 py-3 sm:py-4 rounded-lg font-bold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-base sm:text-lg"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      جاري الإرسال...
                    </>
                  ) : (
                    <>
                      <Mail className="w-5 h-5" />
                      إرسال الطلب
                    </>
                  )}
                </button>
                <p className="text-xs sm:text-sm text-center text-[#707070] mt-3">
                  سنتواصل معك خلال 24 ساعة كحد أقصى
                </p>
              </div>
            </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

