"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X, Phone, MapPin, Bell, Sparkles, Search, ArrowRight } from "lucide-react"
import { usePathname, useRouter } from "next/navigation"
import { maintenanceCenterBrands } from "@/data/maintenance-center-brands"
import { servicesData } from "@/data/services"

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false)
  const [isNotificationOpen, setIsNotificationOpen] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<Array<{ title: string; href: string; category: string }>>([])
  const [currentNotificationIndex, setCurrentNotificationIndex] = useState(0)
  const pathname = usePathname()
  const router = useRouter()
  const notificationRef = useRef<HTMLDivElement>(null)
  const searchRef = useRef<HTMLDivElement>(null)
  const searchInputRef = useRef<HTMLInputElement>(null)

  const notifications = [
    {
      id: 1,
      title: "جميع خدمات الصيانة في مكان واحد!",
      message: "اكتشف خدماتنا المتنوعة لصيانة جميع الأجهزة المنزلية: غسالات، ثلاجات، مكيفات، وأكثر",
      link: "/services",
      linkText: "تصفح الخدمات →",
      icon: "🔧",
      type: "عرض خاص على خدمات الصيانة",
    },
    {
      id: 2,
      title: "صيانة معتمدة بضمان مكتوب",
      message: "فريقنا المحترف يضمن لك جودة عالية في الصيانة مع ضمان مكتوب على جميع الأعمال",
      link: "/warranty",
      linkText: "اعرف المزيد عن الضمان →",
      icon: "🛡️",
      type: "ضمان مكتوب على جميع الأعمال",
    },
    {
      id: 3,
      title: "خدمة في جميع محافظات مصر",
      message: "نوصل إليك في أي محافظة في مصر! خدماتنا متاحة في القاهرة، الإسكندرية، وجميع المحافظات",
      link: "/contact",
      linkText: "تواصل معنا →",
      icon: "📍",
      type: "تغطية شاملة لجميع المحافظات",
    },
    {
      id: 4,
      title: "صيانة الماركات العالمية والمصرية",
      message: "نخدم جميع الماركات: LG، كريازي، يونيفرسال، فريش، جري، باور، يونيون إير، يورك وغيرها",
      link: "/maintenance-center",
      linkText: "اعرف الماركات →",
      icon: "⭐",
      type: "خبرة مع جميع الماركات",
    },
    {
      id: 5,
      title: "استجابة فورية خلال 24 ساعة",
      message: "فريقنا جاهز للوصول إليك خلال 24 ساعة من طلب الخدمة. صيانة سريعة واحترافية",
      link: "/contact",
      linkText: "اطلب الخدمة الآن →",
      icon: "⚡",
      type: "سرعة في الاستجابة",
    },
    {
      id: 6,
      title: "قطع غيار أصلية متوفرة",
      message: "نستخدم فقط قطع غيار أصلية معتمدة لضمان جودة الصيانة وطول عمر الأجهزة",
      link: "/services",
      linkText: "اعرف المزيد →",
      icon: "🔩",
      type: "قطع غيار أصلية 100%",
    },
  ]

  const currentNotification = notifications[currentNotificationIndex]

  const navItems = [
    { label: "الرئيسية", href: "/" },
    { label: "من نحن", href: "/about" },
    { label: "خدماتنا", href: "/services" },
    { label: "الضمان والدعم", href: "/warranty" },
    { label: "مراكز الصيانة", href: "/maintenance-center" },
    { label: "الأسئلة الشائعة", href: "/faq" },
    { label: "تواصل معنا", href: "/contact" },
  ]

  // Search data
  const baseSearchableItems = [
    { title: "الرئيسية", href: "/", category: "صفحات", keywords: ["الرئيسية", "الصفحة الرئيسية", "home", "main"] },
    { title: "من نحن", href: "/about", category: "صفحات", keywords: ["من نحن", "عن الشركة", "قصتنا", "رؤيتنا", "رسالتنا", "about"] },
    { title: "خدماتنا", href: "/services", category: "صفحات", keywords: ["خدماتنا", "الخدمات", "خدمات الصيانة", "services"] },
    { title: "مراكز الصيانة", href: "/maintenance-center", category: "صفحات", keywords: ["مراكز الصيانة", "مراكز الخدمة", "العلامات التجارية", "brands"] },
    { title: "الضمان والدعم", href: "/warranty", category: "صفحات", keywords: ["الضمان", "الدعم", "الضمان والدعم", "warranty", "support"] },
    { title: "الأسئلة الشائعة", href: "/faq", category: "صفحات", keywords: ["أسئلة", "شائعة", "الأسئلة الشائعة", "faq", "سؤال"] },
    { title: "تواصل معنا", href: "/contact", category: "صفحات", keywords: ["تواصل", "اتصل بنا", "تواصل معنا", "contact", "اتصال"] },
    { title: "سياسة الخصوصية", href: "/privacy-policy", category: "صفحات", keywords: ["سياسة الخصوصية", "الخصوصية", "privacy", "policy"] },
    { title: "الشروط والأحكام", href: "/terms-and-conditions", category: "صفحات", keywords: ["الشروط", "الأحكام", "terms", "conditions"] },
    { title: "نموذج حجز ناجح", href: "/thank-you", category: "صفحات", keywords: ["شكرا", "تاكيد", "thank you"] },
  ]

  const serviceSearchItems = servicesData.map((service) => {
    const slugKeywords = service.id.split("-")
    return {
      title: `خدمة ${service.title}`,
      href: `/services/${service.id}`,
      category: "خدمات",
      keywords: [
        service.title,
        `صيانة ${service.title}`,
        service.id,
        ...slugKeywords,
        "خدمة",
        "صيانة",
        "service",
      ],
    }
  })

  const brandSearchItems = maintenanceCenterBrands.map((brand) => {
    const slugKeywords = brand.id.split("-")
    return {
      title: `مركز صيانة ${brand.name}`,
      href: `/maintenance-center/${brand.id}-repair`,
      category: "مراكز صيانة",
      keywords: [
        brand.name,
        `صيانة ${brand.name}`,
        brand.id,
        ...slugKeywords,
        "مركز",
        "صيانة",
        "brand",
      ],
    }
  })

  const searchableItems = [...baseSearchableItems, ...serviceSearchItems, ...brandSearchItems]

  // Search function
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([])
      return
    }

    const queryLower = searchQuery.toLowerCase().trim()
    const results = searchableItems.filter((item) => {
      const titleMatch = item.title.toLowerCase().includes(queryLower)
      const keywordMatch = item.keywords.some((keyword) =>
        keyword.toLowerCase().includes(queryLower)
      )
      return titleMatch || keywordMatch
    })

    setSearchResults(results)
  }, [searchQuery])

  // Handle search input
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
  }

  // Handle search result click
  const handleResultClick = (href: string) => {
    setIsSearchOpen(false)
    setSearchQuery("")
    setSearchResults([])
    router.push(href)
  }

  // Close search when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchOpen(false)
      }
    }

    if (isSearchOpen) {
      document.addEventListener("mousedown", handleClickOutside)
      // Focus search input when opened
      setTimeout(() => {
        searchInputRef.current?.focus()
      }, 100)
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isSearchOpen])

  // Listen for mobile menu search button click
  useEffect(() => {
    const handleOpenSearch = () => {
      setIsSearchOpen(true)
      // Focus on search input after opening
      setTimeout(() => {
        searchInputRef.current?.focus()
      }, 100)
    }
    window.addEventListener('openSearch', handleOpenSearch)
    return () => window.removeEventListener('openSearch', handleOpenSearch)
  }, [])

  // Handle Enter key in search
  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && searchResults.length > 0) {
      handleResultClick(searchResults[0].href)
    }
  }

  const handleNavClick = () => {
    setIsOpen(false)
  }

  // Close notification when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setIsNotificationOpen(false)
      }
    }

    if (isNotificationOpen) {
      document.addEventListener("mousedown", handleClickOutside)
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isNotificationOpen])

  return (
    <div className="sticky top-0 z-50">
      <div className="bg-[#2563eb] text-white py-2 sm:py-1.5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between md:justify-center flex-wrap gap-2 sm:gap-3 md:gap-6 text-xs sm:text-sm">
            <div className="hidden md:flex items-center gap-2">
              <Phone className="w-4 h-4" />
              <span className="font-semibold">الخط الساخن:</span>
              <a href="tel:01110195560" className="hover:text-blue-100 transition-colors font-bold">
                01110195560
              </a>
            </div>

            <div className="hidden md:flex items-center gap-2">
              <Phone className="w-4 h-4" />
              <span className="font-semibold">الدعم الفني:</span>
              <a href="tel:01153625752" className="hover:text-blue-100 transition-colors font-bold">
                01153625752
              </a>
              <span>|</span>
              <a href="tel:01016503001" className="hover:text-blue-100 transition-colors font-bold">
                01016503001
              </a>
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2 mx-auto md:mx-0 flex-1 md:flex-none justify-center md:justify-start">
              <MapPin className="w-3 h-3 sm:w-4 sm:h-4 flex-shrink-0" />
              <span className="font-semibold text-xs sm:text-xs md:text-sm whitespace-nowrap">نغطي جميع محافظات مصر</span>
            </div>

            {/* Notification Icon */}
            <div className="relative" ref={notificationRef}>
              <button
                onClick={() => {
                  if (!isNotificationOpen) {
                    // Show next notification when opening
                    setCurrentNotificationIndex((prev) => (prev + 1) % notifications.length)
                  }
                  setIsNotificationOpen(!isNotificationOpen)
                }}
                className="relative flex items-center justify-center p-1.5 sm:p-2 hover:bg-white/10 rounded-full transition-colors"
                aria-label="الإشعارات"
              >
                <Bell className="w-4 h-4 sm:w-5 sm:h-5 animate-bell-ring" />
                <span className="absolute top-0 left-0 w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></span>
              </button>

              {/* Notification Dropdown */}
              {isNotificationOpen && (
                <div className="absolute left-0 top-full mt-2 w-72 sm:w-80 bg-white rounded-xl shadow-2xl border border-gray-200 overflow-hidden animate-slide-down z-50">
                  <div className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] p-4 text-white">
                    <div className="flex items-center gap-2 mb-1">
                      <Sparkles className="w-5 h-5 text-yellow-300" />
                      <h3 className="font-bold text-sm sm:text-base">إشعار جديد</h3>
                    </div>
                    <p className="text-xs sm:text-sm text-blue-100">{currentNotification.type}</p>
                  </div>
                  
                  <div className="p-4">
                    <div className="flex items-start gap-3 mb-4">
                      <div className="w-10 h-10 bg-[#2563eb]/10 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-2xl">{currentNotification.icon}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-[#2563eb] text-sm sm:text-base mb-1">
                          {currentNotification.title}
                        </h4>
                        <p className="text-xs sm:text-sm text-gray-600 leading-relaxed mb-3">
                          {currentNotification.message}
                        </p>
                        <Link
                          href={currentNotification.link}
                          prefetch={true}
                          onClick={() => setIsNotificationOpen(false)}
                          className="inline-block bg-[#2563eb] text-white px-4 py-2 rounded-full font-semibold text-xs sm:text-sm hover:bg-[#1d4ed8] transition-colors"
                        >
                          {currentNotification.linkText}
                        </Link>
                      </div>
                    </div>
                    
                    <div className="border-t border-gray-200 pt-3">
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>{currentNotificationIndex + 1} من {notifications.length}</span>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setCurrentNotificationIndex((prev) => (prev + 1) % notifications.length)
                            }}
                            className="text-[#2563eb] hover:underline"
                          >
                            التالي →
                          </button>
                          <span className="text-gray-300">|</span>
                          <button
                            onClick={() => setIsNotificationOpen(false)}
                            className="text-[#2563eb] hover:underline"
                          >
                            إغلاق
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            <Link
              href="/"
              prefetch={true}
              className="flex flex-col items-start gap-0.5"
              onClick={handleNavClick}
            >
              <Image
                src={encodeURI("/سيرفس ايجي لوجو.png")}
                alt="Service Egy Logo"
                width={100}
                height={50}
                className="h-10 sm:h-12 w-auto object-contain"
                priority
              />
              <span className="text-sm sm:text-base font-semibold text-[#2563eb] text-right w-full">
                مركز الخدمة والصيانة الفورية
              </span>
            </Link>

            <div className="hidden md:flex items-center gap-6">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  prefetch={true}
                  className="text-[#2563eb] font-semibold hover:text-[#1d4ed8] transition-colors text-sm"
                  onClick={handleNavClick}
                >
                  {item.label}
                </Link>
              ))}
            </div>

            <div className="flex items-center gap-2">
              {/* Search Box - Visible on all sizes */}
              <button
                onClick={() => setIsSearchOpen(!isSearchOpen)}
                className="flex items-center gap-2 bg-blue-50 hover:bg-blue-100 text-gray-600 px-3 py-2 rounded-lg transition-colors flex-1 max-w-[140px] md:max-w-[180px] text-sm"
                aria-label="البحث"
              >
                <Search className="w-4 h-4 flex-shrink-0 text-[#2563eb]" />
                <span className="text-xs md:text-sm truncate">ابحث عن...</span>
              </button>
              
              {/* Menu Icon - Mobile only */}
              <button onClick={() => setIsOpen(!isOpen)} className="md:hidden text-[#2563eb]" aria-label="تبديل القائمة">
                {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>

          {/* Search Modal */}
          {isSearchOpen && (
            <div className="fixed inset-0 bg-black/50 z-[100] flex items-start justify-center pt-20 px-4">
              <div
                ref={searchRef}
                className="w-full max-w-lg md:max-w-2xl bg-white rounded-xl shadow-2xl border border-gray-200 overflow-hidden animate-slide-down"
              >
                {/* Search Input */}
                <div className="p-4 border-b border-gray-200">
                  <div className="flex items-center gap-3">
                    <Search className="w-5 h-5 text-gray-400 flex-shrink-0" />
                    <input
                      ref={searchInputRef}
                      type="text"
                      value={searchQuery}
                      onChange={handleSearchChange}
                      onKeyDown={handleSearchKeyDown}
                      placeholder="ابحث في الموقع..."
                      className="flex-1 outline-none text-gray-900 placeholder-gray-400 text-base"
                    />
                    {searchQuery && (
                      <button
                        onClick={() => {
                          setSearchQuery("")
                          setSearchResults([])
                          searchInputRef.current?.focus()
                        }}
                        className="text-gray-400 hover:text-gray-600 transition-colors"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Search Results */}
                <div className="max-h-[60vh] overflow-y-auto">
                  {searchQuery && searchResults.length === 0 && (
                    <div className="p-8 text-center text-gray-500">
                      <Search className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p className="text-sm">لم يتم العثور على نتائج</p>
                    </div>
                  )}

                  {!searchQuery && (
                    <div className="p-6 text-center text-gray-500">
                      <p className="text-sm">ابدأ الكتابة للبحث...</p>
                    </div>
                  )}

                  {searchQuery && searchResults.length > 0 && (
                    <div className="p-2">
                      <div className="text-xs text-gray-500 px-3 py-2 font-semibold">
                        نتائج البحث ({searchResults.length})
                      </div>
                      {searchResults.map((result, index) => (
                        <button
                          key={index}
                          onClick={() => handleResultClick(result.href)}
                          className="w-full text-right p-3 hover:bg-blue-50 transition-colors rounded-lg group"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1 min-w-0">
                              <div className="text-sm font-semibold text-gray-900 group-hover:text-[#2563eb] transition-colors mb-1">
                                {result.title}
                              </div>
                              <div className="text-xs text-gray-500">{result.category}</div>
                            </div>
                            <div className="text-[#2563eb] opacity-0 group-hover:opacity-100 transition-opacity">
                              <ArrowRight className="w-4 h-4" />
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {isOpen && (
            <div className="md:hidden mt-4 space-y-3 pb-4 border-t border-[#F5F7FA] pt-4">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  prefetch={true}
                  className="block text-[#2563eb] font-semibold hover:text-[#1d4ed8] transition-colors py-2"
                  onClick={handleNavClick}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          )}
        </div>
      </nav>
    </div>
  )
}
