"use client"

import { useState, useEffect } from "react"
import { MessageCircle, X, Phone, Clock } from "lucide-react"

export default function ChatWidget() {
  const [isChatOpen, setIsChatOpen] = useState(false)

  // Listen for mobile menu chat button click
  useEffect(() => {
    const handleOpenChat = () => {
      setIsChatOpen(true)
    }
    window.addEventListener('openChat', handleOpenChat)
    return () => window.removeEventListener('openChat', handleOpenChat)
  }, [])

  return (
    <>
      {/* Desktop Chat Button */}
      {!isChatOpen && (
        <div className="hidden md:block fixed bottom-6 right-6 z-50">
          <button
            onClick={() => setIsChatOpen(true)}
            className="bg-[#2563eb] text-white rounded-full p-4 shadow-lg hover:bg-[#1d4ed8] hover:scale-110 transition-all duration-300 animate-bounce"
            aria-label="فتح الدردشة"
          >
            <MessageCircle className="w-6 h-6" />
          </button>
        </div>
      )}

      {/* Chat Box */}
      {isChatOpen && (
        <div className="bg-white rounded-2xl shadow-2xl w-[85vw] max-w-64 sm:max-w-80 md:max-w-80 border-2 border-[#2563eb]/20 max-h-[85vh] md:max-h-[500px] flex flex-col animate-slide-in fixed bottom-20 left-1/2 -translate-x-1/2 md:bottom-6 md:right-6 md:left-auto md:translate-x-0 z-[60]">
            {/* Chat Header */}
            <div className="bg-[#2563eb] text-white p-2.5 md:p-4 rounded-t-2xl flex items-center justify-between flex-shrink-0">
              <div className="flex items-center gap-2 md:gap-3 min-w-0">
                <div className="w-7 h-7 md:w-10 md:h-10 bg-white rounded-full flex items-center justify-center flex-shrink-0">
                  <Phone className="w-3.5 h-3.5 md:w-5 md:h-5 text-[#2563eb]" />
                </div>
                <div className="min-w-0">
                  <h3 className="font-bold text-xs md:text-base">الدعم الفني</h3>
                  <p className="text-[10px] md:text-xs text-blue-100">متاحون للمساعدة</p>
                </div>
              </div>
              <button
                onClick={() => setIsChatOpen(false)}
                className="hover:bg-white/20 rounded-full p-1 transition-colors flex-shrink-0"
                aria-label="إغلاق الدردشة"
              >
                <X className="w-4 h-4 md:w-5 md:h-5" />
              </button>
            </div>

            {/* Chat Body */}
            <div className="p-3 md:p-6 space-y-3 md:space-y-4 overflow-y-auto flex-1">
              {/* Welcome Message with Avatar */}
              <div className="flex gap-2 md:gap-3 items-start">
                <div className="w-7 h-7 md:w-10 md:h-10 bg-[#2563eb] rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-sm md:text-lg">👨‍🔧</span>
                </div>
                <div className="bg-[#f1f5f9] rounded-2xl rounded-tr-none p-2.5 md:p-4 flex-1 min-w-0">
                  <p className="text-[#2563eb] font-semibold mb-1.5 md:mb-2 text-xs md:text-base">مرحباً بك في Service Egy!</p>
                  <p className="text-[11px] md:text-sm leading-relaxed text-[#475569]">
                    نحن هنا لخدمتك. إذا كنت بحاجة إلى دعم فني أو لديك أي استفسار، يمكنك التواصل معنا على الأرقام
                    التالية:
                  </p>
                </div>
              </div>

              {/* Contact Numbers */}
              <div className="space-y-2 md:space-y-3">
                <a
                  href="tel:01110195560"
                  className="block bg-[#2563eb] text-white rounded-xl p-2.5 md:p-4 hover:bg-[#1d4ed8] transition-all hover:scale-105 shadow-md"
                >
                  <div className="flex items-center gap-2 md:gap-3">
                    <Phone className="w-3.5 h-3.5 md:w-5 md:h-5 flex-shrink-0" />
                    <div className="min-w-0">
                      <div className="text-[10px] md:text-xs text-blue-100 mb-0.5 md:mb-1">الخط الساخن</div>
                      <div className="font-bold text-sm md:text-base">01110195560</div>
                    </div>
                  </div>
                </a>

                <a
                  href="tel:01153625752"
                  className="block bg-white border-2 border-[#2563eb] text-[#2563eb] rounded-xl p-2.5 md:p-4 hover:bg-[#f8fafc] transition-all hover:scale-105 shadow-sm"
                >
                  <div className="flex items-center gap-2 md:gap-3">
                    <Phone className="w-3.5 h-3.5 md:w-5 md:h-5 flex-shrink-0" />
                    <div className="min-w-0">
                      <div className="text-[10px] md:text-xs text-[#64748b] mb-0.5 md:mb-1">الدعم الفني</div>
                      <div className="font-bold text-xs md:text-base">01153625752</div>
                    </div>
                  </div>
                </a>

                <a
                  href="tel:01016503001"
                  className="block bg-white border-2 border-[#2563eb] text-[#2563eb] rounded-xl p-2.5 md:p-4 hover:bg-[#f8fafc] transition-all hover:scale-105 shadow-sm"
                >
                  <div className="flex items-center gap-2 md:gap-3">
                    <Phone className="w-3.5 h-3.5 md:w-5 md:h-5 flex-shrink-0" />
                    <div className="min-w-0">
                      <div className="text-[10px] md:text-xs text-[#64748b] mb-0.5 md:mb-1">الدعم الفني</div>
                      <div className="font-bold text-xs md:text-base">01016503001</div>
                    </div>
                  </div>
                </a>
              </div>

              {/* Working Hours */}
              <div className="flex gap-2 md:gap-3 items-start">
                <div className="bg-[#f1f5f9] rounded-2xl p-2.5 md:p-4 flex-1 min-w-0">
                  <div className="flex items-center gap-2 text-[#2563eb] mb-1.5 md:mb-2">
                    <Clock className="w-3.5 h-3.5 md:w-4 md:h-4 flex-shrink-0" />
                    <p className="font-semibold text-[10px] md:text-sm">مواعيد العمل</p>
                  </div>
                  <p className="text-[11px] md:text-sm text-[#475569]">من 9 صباحاً إلى 9 مساءً</p>
                </div>
              </div>
            </div>
          </div>
        )}
    </>
  )
}
