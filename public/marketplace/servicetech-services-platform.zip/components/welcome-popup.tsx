"use client"

import { useState, useEffect } from "react"
import { X, Sparkles } from "lucide-react"
import Link from "next/link"

export default function WelcomePopup() {
  const [isOpen, setIsOpen] = useState(false)
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
    // Show popup after a short delay (every time page loads)
    const timer = setTimeout(() => {
      setIsOpen(true)
    }, 1500) // 1.5 seconds delay

    return () => clearTimeout(timer)
  }, [])

  // Don't render until mounted (prevents hydration issues)
  if (!isMounted) return null

  const handleClose = () => {
    setIsOpen(false)
  }

  if (!isOpen) return null

  return (
    <div className="fixed z-[100] bottom-6 left-3 sm:left-6">
      <div className="relative w-72 sm:w-80 rounded-2xl border border-slate-200 bg-white shadow-xl shadow-blue-100/50 overflow-hidden animate-slide-up">
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-[#2563eb]/10 to-transparent" />

        <button
          onClick={handleClose}
          className="absolute top-3 right-3 flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-md transition hover:scale-105 hover:bg-slate-100"
          aria-label="إغلاق الترحيب"
        >
          <X className="h-4 w-4 text-slate-600" />
        </button>

        <div className="flex items-start gap-3 p-5">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 text-blue-600">
            <Sparkles className="h-6 w-6" />
          </span>
          <div className="space-y-2 text-right">
            <div>
              <p className="text-xs font-semibold text-blue-600">أهلاً بك في Service Egy</p>
              <h3 className="text-lg font-bold text-slate-900">كل خدمات الصيانة في مكان واحد</h3>
            </div>
            <p className="text-sm leading-relaxed text-slate-600">
              فنيين معتمدين، ضمان مكتوب، واستجابة سريعة لجميع محافظات مصر.
            </p>
            <ul className="grid grid-cols-2 gap-2 text-xs text-slate-600">
              <li className="rounded-md border border-slate-200 bg-white px-2 py-1 text-center font-semibold">
                🔧 صيانة معتمدة
              </li>
              <li className="rounded-md border border-slate-200 bg-white px-2 py-1 text-center font-semibold">
                🛡️ ضمان مكتوب
              </li>
              <li className="rounded-md border border-slate-200 bg-white px-2 py-1 text-center font-semibold">
                ⚡ استجابة فورية
              </li>
              <li className="rounded-md border border-slate-200 bg-white px-2 py-1 text-center font-semibold">
                📍 كل المحافظات
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col gap-2 border-t border-slate-200 bg-slate-50/70 p-4">
          <Link
            href="/services"
            onClick={handleClose}
            prefetch={true}
            className="flex items-center justify-center rounded-xl bg-gradient-to-r from-[#2563eb] to-[#3b82f6] px-4 py-2 text-sm font-bold text-white transition hover:shadow-lg"
          >
            تصفح خدماتنا
          </Link>
          <button
            onClick={handleClose}
            className="rounded-xl border border-[#2563eb] px-4 py-2 text-sm font-bold text-[#2563eb] transition hover:bg-blue-50"
          >
            تصفح الموقع
          </button>
        </div>
      </div>
    </div>
  )
}

