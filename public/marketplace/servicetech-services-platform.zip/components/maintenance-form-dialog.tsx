"use client"

import { useState } from "react"
import { Phone, Mail, MapPin, Wrench, MessageSquare, Loader2 } from "lucide-react"
import { useRouter } from "next/navigation"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

interface MaintenanceFormDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  brandName?: string
}

export default function MaintenanceFormDialog({
  open,
  onOpenChange,
  brandName,
}: MaintenanceFormDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const router = useRouter()

  const [formData, setFormData] = useState({
    name: "",
    address: "",
    phone: "",
    whatsapp: "",
    issueType: "",
    deviceType: "",
    details: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Format email content
      const emailSubject = `طلب صيانة جديد من ${formData.name}`
      const emailBody = `
طلب صيانة جديد من موقع Service Egy

البيانات الشخصية:
- الاسم: ${formData.name}
- العنوان: ${formData.address}
- رقم التليفون: ${formData.phone}
- رقم الواتساب: ${formData.whatsapp}

تفاصيل الطلب:
- نوع العطل: ${formData.issueType}
- نوع الجهاز: ${formData.deviceType}
${brandName ? `- الماركة: ${brandName}` : ""}
${formData.details ? `- تفاصيل إضافية: ${formData.details}` : ""}

التاريخ والوقت: ${new Date().toLocaleString("ar-EG", {
        timeZone: "Africa/Cairo",
      })}
      `.trim()

      // Try API route first (for server-side SMTP)
      const apiEndpoint = process.env.NEXT_PUBLIC_CONTACT_ENDPOINT || "/api/contact"
      console.log("Sending request to API endpoint:", apiEndpoint)

      try {
        const response = await fetch(apiEndpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          mode: apiEndpoint.startsWith('http') ? 'cors' : 'same-origin',
          credentials: apiEndpoint.startsWith('http') ? 'omit' : 'same-origin',
          body: JSON.stringify({
            ...formData,
            brandName: brandName || "",
          }),
        })

        console.log("API Response status:", response.status, response.statusText)

        if (!response.ok) {
          // If response is not ok, try to get error message
          let errorMessage = "فشل إرسال الطلب"
          try {
            const errorResult = await response.json()
            errorMessage = errorResult.error || errorMessage
            console.error("API Error:", errorResult)
          } catch (e) {
            console.error("Failed to parse error response:", e)
            errorMessage = `فشل إرسال الطلب (${response.status} ${response.statusText})`
          }
          throw new Error(errorMessage)
        }

        const result = await response.json()
        console.log("API Response:", result)

        if (result.success) {
          // Save form data to localStorage as backup
          try {
            localStorage.setItem('lastContactForm', JSON.stringify({
              ...formData,
              brandName: brandName || "",
              timestamp: new Date().toISOString(),
            }))
          } catch (e) {
            // Ignore localStorage errors
          }

          // Close dialog and redirect
          onOpenChange(false)
          router.push("/thank-you")
          return
        } else {
          throw new Error(result.error || "فشل إرسال الطلب")
        }
      } catch (apiError: any) {
        // Log the error for debugging
        console.error("API Error Details:", apiError)
        console.error("Error message:", apiError.message)
        console.error("Error stack:", apiError.stack)
        
        // Show error to user
        const errorMessage = apiError.message || "فشل الاتصال بخادم API. يرجى المحاولة مرة أخرى أو التواصل معنا مباشرة."
        alert(`خطأ: ${errorMessage}\n\nإذا استمرت المشكلة، يرجى التواصل معنا مباشرة على:\n📧 info@service-egy.com\n📞 01110195560`)
        setIsSubmitting(false)
        return
      }

      // Fallback: Use Web3Forms for static export
      const web3formsKey = process.env.NEXT_PUBLIC_WEB3FORMS_KEY
      if (web3formsKey && web3formsKey !== 'YOUR_ACCESS_KEY_HERE') {
        try {
          const response = await fetch('https://api.web3forms.com/submit', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: JSON.stringify({
              access_key: web3formsKey,
              subject: emailSubject,
              from_name: formData.name,
              email: 'info@service-egy.com',
              message: emailBody,
              name: formData.name,
              address: formData.address,
              phone: formData.phone,
              whatsapp: formData.whatsapp,
              issueType: formData.issueType,
              deviceType: formData.deviceType,
              brandName: brandName || '',
              details: formData.details || '',
            }),
          })

          const result = await response.json()

          if (result.success) {
            // Save form data to localStorage as backup
            try {
              localStorage.setItem('lastContactForm', JSON.stringify({
                ...formData,
                brandName: brandName || "",
                timestamp: new Date().toISOString(),
              }))
            } catch (e) {
              // Ignore localStorage errors
            }

            // Close dialog and redirect
            onOpenChange(false)
            router.push("/thank-you")
            return
          }
        } catch (web3Error) {
          console.error("Web3Forms error:", web3Error)
        }
      }

      // If both fail, save and redirect anyway
      try {
        localStorage.setItem('lastContactForm', JSON.stringify({
          ...formData,
          brandName: brandName || "",
          timestamp: new Date().toISOString(),
        }))
      } catch (e) {
        // Ignore localStorage errors
      }

      // Close dialog and redirect to thank you page
      onOpenChange(false)
      router.push("/thank-you")
    } catch (error) {
      console.error("Error submitting form:", error)
      alert("حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى أو التواصل معنا مباشرة على: info@service-egy.com")
      setIsSubmitting(false)
    }
  }

  const issueTypes = [
    "عطل كهربائي",
    "عطل ميكانيكي",
    "مشكلة في التبريد/التسخين",
    "مشكلة في الصرف",
    "صوت غير طبيعي",
    "لا يعمل نهائياً",
    "مشكلة أخرى",
  ]

  const deviceTypes = [
    "غسالة ملابس",
    "ثلاجة",
    "ديب فريزر",
    "غسالة أطباق",
    "ميكروويف",
    "مجفف",
    "مكيف هواء",
    "جهاز آخر",
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-[#2563eb] text-right">
            {brandName ? `طلب خدمة صيانة ${brandName}` : "طلب خدمة صيانة"}
          </DialogTitle>
          <DialogDescription className="text-right text-[#707070]">
            املأ النموذج وسنتواصل معك في أقرب وقت ممكن
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          {/* Name */}
          <div>
            <label htmlFor="dialog-name" className="block text-right mb-2 font-bold text-[#2563eb]">
              <span className="flex items-center gap-2 justify-end">
                <Mail className="w-4 h-4" />
                الاسم الكامل *
              </span>
            </label>
            <input
              type="text"
              id="dialog-name"
              name="name"
              required
              value={formData.name}
              onChange={handleChange}
              className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right"
              placeholder="أدخل اسمك الكامل"
            />
          </div>

          {/* Address */}
          <div>
            <label htmlFor="dialog-address" className="block text-right mb-2 font-bold text-[#2563eb]">
              <span className="flex items-center gap-2 justify-end">
                <MapPin className="w-4 h-4" />
                العنوان الكامل *
              </span>
            </label>
            <input
              type="text"
              id="dialog-address"
              name="address"
              required
              value={formData.address}
              onChange={handleChange}
              className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right"
              placeholder="المحافظة، المدينة، الشارع، رقم العمارة"
            />
          </div>

          {/* Phone */}
          <div>
            <label htmlFor="dialog-phone" className="block text-right mb-2 font-bold text-[#2563eb]">
              <span className="flex items-center gap-2 justify-end">
                <Phone className="w-4 h-4" />
                رقم التليفون *
              </span>
            </label>
            <input
              type="tel"
              id="dialog-phone"
              name="phone"
              required
              value={formData.phone}
              onChange={handleChange}
              className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right"
              placeholder="01XXXXXXXXX"
              pattern="[0-9]{11}"
            />
          </div>

          {/* WhatsApp */}
          <div>
            <label htmlFor="dialog-whatsapp" className="block text-right mb-2 font-bold text-[#2563eb]">
              <span className="flex items-center gap-2 justify-end">
                <MessageSquare className="w-4 h-4" />
                رقم الواتساب *
              </span>
            </label>
            <input
              type="tel"
              id="dialog-whatsapp"
              name="whatsapp"
              required
              value={formData.whatsapp}
              onChange={handleChange}
              className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right"
              placeholder="01XXXXXXXXX"
              pattern="[0-9]{11}"
            />
          </div>

          {/* Issue Type */}
          <div>
            <label htmlFor="dialog-issueType" className="block text-right mb-2 font-bold text-[#2563eb]">
              <span className="flex items-center gap-2 justify-end">
                <Wrench className="w-4 h-4" />
                نوع العطل *
              </span>
            </label>
            <select
              id="dialog-issueType"
              name="issueType"
              required
              value={formData.issueType}
              onChange={handleChange}
              className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right"
            >
              <option value="">اختر نوع العطل</option>
              {issueTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>

          {/* Device Type */}
          <div>
            <label htmlFor="dialog-deviceType" className="block text-right mb-2 font-bold text-[#2563eb]">
              <span className="flex items-center gap-2 justify-end">
                <Wrench className="w-4 h-4" />
                نوع الجهاز *
              </span>
            </label>
            <select
              id="dialog-deviceType"
              name="deviceType"
              required
              value={formData.deviceType}
              onChange={handleChange}
              className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right"
            >
              <option value="">اختر نوع الجهاز</option>
              {deviceTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>

          {/* Details */}
          <div>
            <label htmlFor="dialog-details" className="block text-right mb-2 font-bold text-[#2563eb]">
              <span className="flex items-center gap-2 justify-end">
                <MessageSquare className="w-4 h-4" />
                تفاصيل إضافية
              </span>
            </label>
            <textarea
              id="dialog-details"
              name="details"
              rows={4}
              value={formData.details}
              onChange={handleChange}
              className="w-full px-4 py-3 border-2 border-[#e0e7ff] rounded-lg focus:border-[#2563eb] focus:outline-none text-right resize-none"
              placeholder="اكتب تفاصيل إضافية عن المشكلة..."
            />
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white px-6 py-3 rounded-lg font-bold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-base"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  جاري الإرسال...
                </>
              ) : (
                <>
                  <Mail className="w-5 h-5" />
                  إرسال الطلب
                </>
              )}
            </button>
            <p className="text-xs text-center text-[#707070] mt-3">
              سنتواصل معك خلال 24 ساعة كحد أقصى
            </p>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
