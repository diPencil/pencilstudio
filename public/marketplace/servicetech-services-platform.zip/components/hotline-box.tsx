"use client"

import { Phone, FileText, Search } from "lucide-react"
import { useState } from "react"
import MaintenanceFormDialog from "@/components/maintenance-form-dialog"

export default function HotlineBox() {
  const [isMaintenanceFormOpen, setIsMaintenanceFormOpen] = useState(false)
  
  const handleChatClick = () => {
    // Dispatch custom event to open chat
    window.dispatchEvent(new CustomEvent('openChat'))
  }

  const handleSearchClick = () => {
    // Dispatch custom event to open search from Navigation component
    const event = new CustomEvent('openSearch', { bubbles: true })
    window.dispatchEvent(event)
  }

  const handleMaintenanceFormClick = () => {
    setIsMaintenanceFormOpen(true)
  }

  return (
    <>
      {/* Mobile Bottom Menu - أيقونات فقط */}
      <div className="fixed bottom-0 left-0 right-0 md:hidden z-50 px-4 pb-3">
        <div className="relative bg-[#2563eb] rounded-full shadow-xl max-w-screen-xl mx-auto">
          <div className="flex items-center justify-around px-2 py-2 relative">
            {/* اتصال */}
            <a
              href="tel:01110195560"
              className="flex flex-col items-center justify-center gap-0.5 flex-shrink-0 relative"
              aria-label="الخط الساخن 01110195560"
            >
              <div className="w-12 h-12 flex items-center justify-center rounded-full bg-white/20 border-2 border-white shadow-lg hover:bg-white/30 transition-colors">
                <Phone className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <span className="text-[9px] text-white font-medium">الخط الساخن</span>
            </a>

            {/* وكيل - Chat Button */}
            <button
              onClick={handleChatClick}
              className="flex flex-col items-center justify-center gap-0.5 flex-shrink-0 relative"
              aria-label="دعم فني"
            >
              <div className="w-12 h-12 flex items-center justify-center rounded-full bg-white/20 border-2 border-white shadow-lg hover:bg-white/30 transition-colors">
                {/* Chat bubble icon with three dots (typing indicator) */}
                <svg
                  className="w-5 h-5 text-white"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                  />
                </svg>
              </div>
                    <span className="text-[9px] text-white font-medium">دعم فني</span>
            </button>

            {/* صيانة */}
            <button
              onClick={handleMaintenanceFormClick}
              className="flex flex-col items-center justify-center gap-0.5 flex-shrink-0"
              aria-label="نموذج صيانة"
            >
              <div className="w-12 h-12 flex items-center justify-center rounded-full bg-white/20 border-2 border-white shadow-lg hover:bg-white/30 transition-colors">
                <FileText className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <span className="text-[9px] text-white font-medium">نموذج صيانة</span>
            </button>

            {/* بحث */}
            <button
              onClick={handleSearchClick}
              className="flex flex-col items-center justify-center gap-0.5 flex-shrink-0"
              aria-label="ابحث عن..."
            >
              <div className="w-12 h-12 flex items-center justify-center rounded-full bg-white/20 border-2 border-white shadow-lg hover:bg-white/30 transition-colors">
                <Search className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <span className="text-[9px] text-white font-medium">ابحث عن...</span>
            </button>
          </div>
        </div>
      </div>

      {/* Maintenance Form Dialog */}
      <MaintenanceFormDialog
        open={isMaintenanceFormOpen}
        onOpenChange={setIsMaintenanceFormOpen}
      />

      {/* Desktop Hotline Box (unchanged) */}
      <div className="hidden md:block fixed bottom-6 right-24 z-40">
        <a
          href="tel:01110195560"
          className="bg-[#2563eb] text-white px-8 py-4 rounded-full shadow-lg hover:bg-[#1d4ed8] hover:scale-105 transition-all duration-300 flex items-center gap-4 animate-pulse whitespace-nowrap"
        >
          <Phone className="w-6 h-6 flex-shrink-0" />
          <div className="flex items-center gap-3">
            <span className="text-base font-bold whitespace-nowrap">الخط الساخن</span>
            <span className="text-lg lg:text-2xl font-extrabold">01110195560</span>
          </div>
        </a>
      </div>
    </>
  )
}
