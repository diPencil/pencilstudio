"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { Phone, MapPin, Bell, Sparkles } from "lucide-react"

export default function TopBar() {
  const [isNotificationOpen, setIsNotificationOpen] = useState(false)
  const [currentNotificationIndex, setCurrentNotificationIndex] = useState(0)
  const notificationRef = useRef<HTMLDivElement>(null)

  const notifications = [
    {
      id: 1,
      title: "جميع خدمات الصيانة في مكان واحد!",
      message: "اكتشف خدماتنا المتنوعة لصيانة جميع الأجهزة المنزلية: غسالات، ثلاجات، مكيفات، وأكثر",
      link: "/services",
      linkText: "تصفح الخدمات →",
      icon: "🔧",
      type: "عرض خاص على خدمات الصيانة",
    },
    {
      id: 2,
      title: "صيانة معتمدة بضمان مكتوب",
      message: "فريقنا المحترف يضمن لك جودة عالية في الصيانة مع ضمان مكتوب على جميع الأعمال",
      link: "/warranty",
      linkText: "اعرف المزيد عن الضمان →",
      icon: "🛡️",
      type: "ضمان مكتوب على جميع الأعمال",
    },
    {
      id: 3,
      title: "خدمة في جميع محافظات مصر",
      message: "نوصل إليك في أي محافظة في مصر! خدماتنا متاحة في القاهرة، الإسكندرية، وجميع المحافظات",
      link: "/contact",
      linkText: "تواصل معنا →",
      icon: "📍",
      type: "تغطية شاملة لجميع المحافظات",
    },
    {
      id: 4,
      title: "صيانة الماركات العالمية والمصرية",
      message: "نخدم جميع الماركات: LG، كريازي، يونيفرسال، فريش، جري، باور، يونيون إير، يورك وغيرها",
      link: "/maintenance-center",
      linkText: "اعرف الماركات →",
      icon: "⭐",
      type: "خبرة مع جميع الماركات",
    },
    {
      id: 5,
      title: "استجابة فورية خلال 24 ساعة",
      message: "فريقنا جاهز للوصول إليك خلال 24 ساعة من طلب الخدمة. صيانة سريعة واحترافية",
      link: "/contact",
      linkText: "اطلب الخدمة الآن →",
      icon: "⚡",
      type: "سرعة في الاستجابة",
    },
    {
      id: 6,
      title: "قطع غيار أصلية متوفرة",
      message: "نستخدم فقط قطع غيار أصلية معتمدة لضمان جودة الصيانة وطول عمر الأجهزة",
      link: "/services",
      linkText: "اعرف المزيد →",
      icon: "🔩",
      type: "قطع غيار أصلية 100%",
    },
  ]

  const currentNotification = notifications[currentNotificationIndex]

  // Close notification when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setIsNotificationOpen(false)
      }
    }

    if (isNotificationOpen) {
      document.addEventListener("mousedown", handleClickOutside)
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isNotificationOpen])

  return (
    <div className="bg-[#2563eb] text-white py-2 sm:py-1.5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between md:justify-center flex-wrap gap-2 sm:gap-3 md:gap-6 text-xs sm:text-sm">
          <div className="hidden md:flex items-center gap-2">
            <Phone className="w-4 h-4" />
            <span className="font-semibold">الخط الساخن:</span>
            <a href="tel:01110195560" className="hover:text-blue-100 transition-colors font-bold">
              01110195560
            </a>
          </div>

          <div className="hidden md:flex items-center gap-2">
            <Phone className="w-4 h-4" />
            <span className="font-semibold">الدعم الفني:</span>
            <a href="tel:01153625752" className="hover:text-blue-100 transition-colors font-bold">
              01153625752
            </a>
            <span>|</span>
            <a href="tel:01016503001" className="hover:text-blue-100 transition-colors font-bold">
              01016503001
            </a>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 mx-auto md:mx-0 flex-1 md:flex-none justify-center md:justify-start">
            <MapPin className="w-3 h-3 sm:w-4 sm:h-4 flex-shrink-0" />
            <span className="font-semibold text-xs sm:text-xs md:text-sm whitespace-nowrap">نغطي جميع محافظات مصر</span>
          </div>

          {/* Notification Icon */}
          <div className="relative" ref={notificationRef}>
            <button
              onClick={() => {
                if (!isNotificationOpen) {
                  // Show next notification when opening
                  setCurrentNotificationIndex((prev) => (prev + 1) % notifications.length)
                }
                setIsNotificationOpen(!isNotificationOpen)
              }}
              className="relative flex items-center justify-center p-1.5 sm:p-2 hover:bg-white/10 rounded-full transition-colors"
              aria-label="الإشعارات"
            >
              <Bell className="w-4 h-4 sm:w-5 sm:h-5 animate-bell-ring" />
              <span className="absolute top-0 left-0 w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></span>
            </button>

            {/* Notification Dropdown */}
            {isNotificationOpen && (
              <div className="absolute left-0 top-full mt-2 w-72 sm:w-80 bg-white rounded-xl shadow-2xl border border-gray-200 overflow-hidden animate-slide-down z-50">
                <div className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] p-4 text-white">
                  <div className="flex items-center gap-2 mb-1">
                    <Sparkles className="w-5 h-5 text-yellow-300" />
                    <h3 className="font-bold text-sm sm:text-base">إشعار جديد</h3>
                  </div>
                  <p className="text-xs sm:text-sm text-blue-100">{currentNotification.type}</p>
                </div>
                
                <div className="p-4">
                  <div className="flex items-start gap-3 mb-4">
                    <div className="w-10 h-10 bg-[#2563eb]/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-2xl">{currentNotification.icon}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-[#2563eb] text-sm sm:text-base mb-1">
                        {currentNotification.title}
                      </h4>
                      <p className="text-xs sm:text-sm text-gray-600 leading-relaxed mb-3">
                        {currentNotification.message}
                      </p>
                      <Link
                        href={currentNotification.link}
                        prefetch={true}
                        onClick={() => setIsNotificationOpen(false)}
                        className="inline-block bg-[#2563eb] text-white px-4 py-2 rounded-full font-semibold text-xs sm:text-sm hover:bg-[#1d4ed8] transition-colors"
                      >
                        {currentNotification.linkText}
                      </Link>
                    </div>
                  </div>
                  
                  <div className="border-t border-gray-200 pt-3">
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{currentNotificationIndex + 1} من {notifications.length}</span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            setCurrentNotificationIndex((prev) => (prev + 1) % notifications.length)
                          }}
                          className="text-[#2563eb] hover:underline"
                        >
                          التالي →
                        </button>
                        <span className="text-gray-300">|</span>
                        <button
                          onClick={() => setIsNotificationOpen(false)}
                          className="text-[#2563eb] hover:underline"
                        >
                          إغلاق
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}









