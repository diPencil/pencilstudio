'use client'

import { Facebook, Instagram, Phone, Mail } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

// WhatsApp Icon Component
const WhatsAppIcon = ({ className }: { className?: string }) => (
  <svg
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
  </svg>
)

export default function Footer() {
  const [isComingSoonOpen, setIsComingSoonOpen] = useState(false)
  return (
    <footer className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* About */}
          <div>
            <div className="flex flex-col items-start gap-3 mb-3">
              <Image
                src={encodeURI("/سيرفس ايجي لوجو2.png")}
                alt="Service Egy Logo"
                width={150}
                height={60}
                className="h-auto w-auto max-w-[180px] object-contain"
                priority
              />
              <p className="text-sm font-semibold text-blue-50">
                مركز الخدمة والصيانة الفورية
              </p>
            </div>
            <p className="text-blue-100 text-sm leading-relaxed">
              خدمات صيانة معتمدة لكل بيت مصري بخبرة واسعة وفنيين معتمدين
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">روابط سريعة</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" prefetch={true} className="text-blue-100 hover:text-white transition-colors">
                  الرئيسية
                </Link>
              </li>
              <li>
                <Link href="/about" prefetch={true} className="text-blue-100 hover:text-white transition-colors">
                  من نحن
                </Link>
              </li>
              <li>
                <Link href="/services" prefetch={true} className="text-blue-100 hover:text-white transition-colors">
                  خدماتنا
                </Link>
              </li>
              <li>
                <Link href="/contact" prefetch={true} className="text-blue-100 hover:text-white transition-colors">
                  تواصل معنا
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-bold mb-4">تواصل معنا</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 flex-shrink-0" />
                <a href="tel:01110195560" className="text-blue-100 hover:text-white transition-colors">
                  01110195560
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 flex-shrink-0" />
                <a href="tel:01153625752" className="text-blue-100 hover:text-white transition-colors">
                  01153625752
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 flex-shrink-0" />
                <a href="tel:01016503001" className="text-blue-100 hover:text-white transition-colors">
                  01016503001
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 flex-shrink-0" />
                <a href="mailto:info@service-egy.com" className="text-blue-100 hover:text-white transition-colors break-words">
                  info@service-egy.com
                </a>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h3 className="text-lg font-bold mb-4">تابعنا</h3>
            <div className="flex gap-4">
              <button
                onClick={() => setIsComingSoonOpen(true)}
                aria-label="Facebook"
                className="bg-white/20 p-2 rounded-full hover:bg-white/30 transition-colors cursor-pointer"
              >
                <Facebook className="w-5 h-5" />
              </button>
              <button
                onClick={() => setIsComingSoonOpen(true)}
                aria-label="Instagram"
                className="bg-white/20 p-2 rounded-full hover:bg-white/30 transition-colors cursor-pointer"
              >
                <Instagram className="w-5 h-5" />
              </button>
              <a
                href="https://wa.me/20116503001"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="WhatsApp"
                className="bg-white/20 p-2 rounded-full hover:bg-white/30 transition-colors"
              >
                <WhatsAppIcon className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-white/20 pt-6 mt-8">
          {/* Single bar with copyright on left and links on right */}
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm">
            {/* Copyright - Left (يسار الشاشة) */}
            <div className="text-blue-100 text-center md:text-left order-2 md:order-1">
              <p className="text-xs sm:text-sm">
                © 2025 Service Egy – جميع الحقوق محفوظة | خدمة معتمدة | جودة مضمونة | استجابة فورية
              </p>
            </div>
            
            {/* Links - Right (يمين الشاشة) */}
            <div className="flex flex-wrap justify-center md:justify-end gap-2 md:gap-4 order-1 md:order-2 text-xs sm:text-sm">
              <Link href="/privacy-policy" prefetch={true} className="text-blue-100 hover:text-white transition-colors whitespace-nowrap">
                سياسة الخصوصية
              </Link>
              <span className="text-blue-200 hidden sm:inline">|</span>
              <Link href="/terms-and-conditions" prefetch={true} className="text-blue-100 hover:text-white transition-colors whitespace-nowrap">
                الشروط والأحكام
              </Link>
              <span className="text-blue-200 hidden sm:inline">|</span>
              <Link href="/faq" prefetch={true} className="text-blue-100 hover:text-white transition-colors whitespace-nowrap">
                الأسئلة والأجوبة
              </Link>
            </div>
          </div>
          
          {/* Powered by - centered below */}
          <div className="text-center text-xs text-blue-200 mt-4">
            <p>
              مدعوم بواسطة{" "}
              <a 
                href="https://www.dipencil.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-white hover:text-blue-100 underline transition-colors"
              >
                بينسل ستوديو
              </a>
            </p>
          </div>
        </div>
      </div>

      {/* Coming Soon Dialog */}
      <Dialog open={isComingSoonOpen} onOpenChange={setIsComingSoonOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl">قريباً</DialogTitle>
            <DialogDescription className="text-center text-base pt-2">
              سنكون متاحين على منصات التواصل الاجتماعي قريباً
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </footer>
  )
}
