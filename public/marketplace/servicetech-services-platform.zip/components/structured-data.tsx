import Script from 'next/script'

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://service-egy.com'

interface StructuredDataProps {
  type?: 'Organization' | 'LocalBusiness' | 'Service'
  data?: Record<string, any>
}

export default function StructuredData({ type = 'LocalBusiness', data }: StructuredDataProps) {
  const defaultOrganizationData = {
    '@context': 'https://schema.org',
    '@type': type,
    name: 'Service Egy',
    description: 'مركز صيانة معتمد يقدم خدمات صيانة احترافية لجميع الأجهزة المنزلية في مصر. غسالات، ثلاجات، ميكروويف، مكيفات. فنيون معتمدون، قطع غيار أصلية، ضمان مكتوب.',
    url: baseUrl,
    logo: `${baseUrl}/سيرفس ايجي لوجو.png`,
    telephone: ['+201153625752', '+201016503001'],
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: '01110195560',
      contactType: 'customer service',
      areaServed: 'EG',
      availableLanguage: 'Arabic'
    },
    email: 'info@service-egy.com',
    address: {
      '@type': 'PostalAddress',
      addressCountry: 'EG',
      addressRegion: 'مصر',
      addressLocality: 'مصر',
    },
    areaServed: {
      '@type': 'Country',
      name: 'مصر',
    },
    priceRange: '$$',
    openingHours: ['Mo-Su 09:00-21:00'],
    sameAs: [],
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: '4.8',
      reviewCount: '500'
    }
  }

  const structuredData = data || defaultOrganizationData

  return (
    <Script
      id="structured-data"
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
    />
  )
}





