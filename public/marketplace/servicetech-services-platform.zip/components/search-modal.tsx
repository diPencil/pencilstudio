"use client"

import { useState, useEffect, useRef } from "react"
import { Search, X, ArrowRight } from "lucide-react"
import { useRouter } from "next/navigation"
import { maintenanceCenterBrands } from "@/data/maintenance-center-brands"
import { servicesData } from "@/data/services"

export default function SearchModal() {
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<Array<{ title: string; href: string; category: string }>>([])
  const router = useRouter()
  const searchRef = useRef<HTMLDivElement>(null)
  const searchInputRef = useRef<HTMLInputElement>(null)

  // Search data
  const baseSearchableItems = [
    { title: "الرئيسية", href: "/", category: "صفحات", keywords: ["الرئيسية", "الصفحة الرئيسية", "home", "main"] },
    { title: "من نحن", href: "/about", category: "صفحات", keywords: ["من نحن", "عن الشركة", "قصتنا", "رؤيتنا", "رسالتنا", "about"] },
    { title: "خدماتنا", href: "/services", category: "صفحات", keywords: ["خدماتنا", "الخدمات", "خدمات الصيانة", "services"] },
    { title: "مراكز الصيانة", href: "/maintenance-center", category: "صفحات", keywords: ["مراكز الصيانة", "مراكز الخدمة", "العلامات التجارية", "brands"] },
    { title: "الضمان والدعم", href: "/warranty", category: "صفحات", keywords: ["الضمان", "الدعم", "الضمان والدعم", "warranty", "support"] },
    { title: "الأسئلة الشائعة", href: "/faq", category: "صفحات", keywords: ["أسئلة", "شائعة", "الأسئلة الشائعة", "faq", "سؤال"] },
    { title: "تواصل معنا", href: "/contact", category: "صفحات", keywords: ["تواصل", "اتصل بنا", "اتصال", "contact"] },
  ]

  const serviceSearchItems = servicesData.map((service) => {
    const slugKeywords = service.id.split("-")
    return {
      title: service.title,
      href: `/services/${service.id}`,
      category: "خدمات",
      keywords: [
        service.title,
        service.description,
        service.id,
        ...slugKeywords,
        "خدمة",
        "صيانة",
        "service",
      ],
    }
  })

  const brandSearchItems = maintenanceCenterBrands.map((brand) => {
    const slugKeywords = brand.id.split("-")
    return {
      title: `مركز صيانة ${brand.name}`,
      href: `/maintenance-center/${brand.id}-repair`,
      category: "مراكز صيانة",
      keywords: [
        brand.name,
        `صيانة ${brand.name}`,
        brand.id,
        ...slugKeywords,
        "مركز",
        "صيانة",
        "brand",
      ],
    }
  })

  const searchableItems = [...baseSearchableItems, ...serviceSearchItems, ...brandSearchItems]

  // Search function
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([])
      return
    }

    const queryLower = searchQuery.toLowerCase().trim()
    const results = searchableItems.filter((item) => {
      const titleMatch = item.title.toLowerCase().includes(queryLower)
      const keywordMatch = item.keywords.some((keyword) =>
        keyword.toLowerCase().includes(queryLower)
      )
      return titleMatch || keywordMatch
    })

    setSearchResults(results)
  }, [searchQuery])

  // Handle search input
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
  }

  // Handle search result click
  const handleResultClick = (href: string) => {
    setIsSearchOpen(false)
    setSearchQuery("")
    setSearchResults([])
    router.push(href)
  }

  // Close search when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchOpen(false)
      }
    }

    if (isSearchOpen) {
      document.addEventListener("mousedown", handleClickOutside)
      // Focus search input when opened
      setTimeout(() => {
        searchInputRef.current?.focus()
      }, 100)
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isSearchOpen])

  // Listen for mobile menu search button click
  useEffect(() => {
    const handleOpenSearch = () => {
      setIsSearchOpen(true)
      // Focus on search input after opening
      setTimeout(() => {
        searchInputRef.current?.focus()
      }, 100)
    }
    window.addEventListener('openSearch', handleOpenSearch)
    return () => window.removeEventListener('openSearch', handleOpenSearch)
  }, [])

  // Handle Enter key in search
  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && searchResults.length > 0) {
      handleResultClick(searchResults[0].href)
    }
  }

  if (!isSearchOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 z-[100] flex items-start justify-center pt-20 px-4">
      <div
        ref={searchRef}
        className="w-full max-w-lg md:max-w-2xl bg-white rounded-xl shadow-2xl border border-gray-200 overflow-hidden animate-slide-down"
      >
        {/* Search Input */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <Search className="w-5 h-5 text-gray-400 flex-shrink-0" />
            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={handleSearchChange}
              onKeyDown={handleSearchKeyDown}
              placeholder="ابحث في الموقع..."
              className="flex-1 outline-none text-gray-900 placeholder-gray-400 text-base"
            />
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery("")
                  setSearchResults([])
                  searchInputRef.current?.focus()
                }}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            )}
            <button
              onClick={() => setIsSearchOpen(false)}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search Results */}
        <div className="max-h-[60vh] overflow-y-auto">
          {searchQuery && searchResults.length === 0 && (
            <div className="p-8 text-center text-gray-500">
              <Search className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p className="text-sm">لم يتم العثور على نتائج</p>
            </div>
          )}

          {!searchQuery && (
            <div className="p-6 text-center text-gray-500">
              <p className="text-sm">ابدأ الكتابة للبحث...</p>
            </div>
          )}

          {searchQuery && searchResults.length > 0 && (
            <div className="p-2">
              <div className="text-xs text-gray-500 px-3 py-2 font-semibold">
                نتائج البحث ({searchResults.length})
              </div>
              {searchResults.map((result, index) => (
                <button
                  key={index}
                  onClick={() => handleResultClick(result.href)}
                  className="w-full text-right p-3 hover:bg-blue-50 transition-colors rounded-lg group"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-gray-900 group-hover:text-[#2563eb] transition-colors mb-1">
                        {result.title}
                      </div>
                      <div className="text-xs text-gray-500">{result.category}</div>
                    </div>
                    <div className="text-[#2563eb] opacity-0 group-hover:opacity-100 transition-opacity">
                      <ArrowRight className="w-4 h-4" />
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

