"use client"

import { usePathname } from "next/navigation"
import Navigation from "@/components/navigation"
import Footer from "@/components/footer"

export function ConditionalNavigation() {
  const pathname = usePathname()
  const isMaintenanceCenter = pathname?.startsWith("/maintenance-center") ?? false
  
  if (isMaintenanceCenter) {
    return null
  }
  
  return <Navigation />
}

export function ConditionalFooter() {
  const pathname = usePathname()
  const isMaintenanceCenter = pathname?.startsWith("/maintenance-center") ?? false
  
  if (isMaintenanceCenter) {
    return null
  }
  
  return <Footer />
}
