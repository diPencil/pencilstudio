"use client"

import { useState } from "react"
import { Phone, Mail, Award } from "lucide-react"
import MaintenanceFormDialog from "@/components/maintenance-form-dialog"

interface MaintenanceCTASectionProps {
  brandName: string
}

export default function MaintenanceCTASection({ brandName }: MaintenanceCTASectionProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  return (
    <>
      {/* CTA Section */}
      <section className="py-10 sm:py-12 md:py-16 px-4 sm:px-6 bg-gradient-to-br from-[#2563eb] to-[#3b82f6]">
        <div className="max-w-4xl mx-auto text-center text-white">
          <Award className="w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 mx-auto mb-4 sm:mb-6" />
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 sm:mb-6 leading-tight">
            هل تحتاج إلى صيانة أجهزة {brandName}؟
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-blue-100 mb-6 sm:mb-8 leading-relaxed">
            فريقنا المتخصص جاهز لخدمتك على مدار الساعة
          </p>
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center">
            <a
              href="tel:01110195560"
              className="bg-white text-[#2563eb] px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold hover:shadow-lg transition-all hover:scale-105 flex items-center justify-center gap-2 sm:gap-3 text-sm sm:text-base"
            >
              <Phone className="w-4 h-4 sm:w-5 sm:h-5" />
              اتصل الآن: 01110195560
            </a>
            <button
              onClick={() => setIsDialogOpen(true)}
              className="border-2 border-white text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold hover:bg-white/10 transition-all flex items-center justify-center gap-2 sm:gap-3 text-sm sm:text-base"
            >
              <Mail className="w-4 h-4 sm:w-5 sm:h-5" />
              املأ نموذج الصيانة
            </button>
          </div>
        </div>
      </section>

      {/* Maintenance Form Dialog */}
      <MaintenanceFormDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        brandName={brandName}
      />
    </>
  )
}








