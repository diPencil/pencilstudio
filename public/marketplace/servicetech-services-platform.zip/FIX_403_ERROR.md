# 🔧 إصلاح خطأ 403 Forbidden في صفحات الماركز

## 🔍 المشكلة:
صفحات الماركز (`/maintenance-center/lg-repair`, إلخ) تعطي خطأ **403 Forbidden** على Hostinger.

## ✅ الحل:

### 1. ملف `.htaccess` محسّن

تم إنشاء ملف `.htaccess` محسّن في مجلد `out` يحتوي على:

1. **منع الوصول إلى ملفات `.txt`**:
   - ملفات `.txt` هي RSC Payload files من Next.js
   - يجب منع الوصول إليها لأنها قد تسبب مشاكل أمنية

2. **قواعد Rewrite محسّنة**:
   - معالجة صفحات الماركز: `/maintenance-center/lg-repair` → `/maintenance-center/lg-repair.html`
   - معالجة صفحات الخدمات: `/services/washing-machines` → `/services/washing-machines.html`
   - معالجة الصفحات الأخرى: `/about` → `/about.html`

### 2. محتوى ملف `.htaccess`:

```apache
Options -Indexes
AddDefaultCharset UTF-8

<IfModule mod_rewrite.c>
RewriteEngine On

# Block access to .txt files (RSC payload files)
RewriteRule ^.*\.txt$ - [F,L]

# Allow sitemap and robots files
RewriteRule ^(sitemap\.xml|robots\.txt)$ - [L]

# Handle maintenance-center routes: /maintenance-center/lg-repair -> /maintenance-center/lg-repair.html
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_URI} ^/maintenance-center/(.+)$
RewriteCond %{DOCUMENT_ROOT}/maintenance-center/%1.html -f
RewriteRule ^maintenance-center/(.+)$ maintenance-center/$1.html [L]

# Handle services routes: /services/washing-machines -> /services/washing-machines.html
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_URI} ^/services/(.+)$
RewriteCond %{DOCUMENT_ROOT}/services/%1.html -f
RewriteRule ^services/(.+)$ services/$1.html [L]

# Handle other routes: /about, /contact, etc. -> /about.html, /contact.html
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_FILENAME}.html -f
RewriteRule ^(.+?)/?$ $1.html [L]

# Fallback to index.html
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^$ index.html [L]
</IfModule>

# Set proper MIME types
<IfModule mod_mime.c>
    AddType text/html .html
    AddType text/css .css
    AddType application/javascript .js
    AddType application/json .json
    AddType image/svg+xml .svg
    AddType image/png .png
    AddType image/jpeg .jpg .jpeg
    AddType image/webp .webp
    AddType font/woff .woff
    AddType font/woff2 .woff2
</IfModule>

# Enable compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript application/json
</IfModule>

# Set cache headers
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
    ExpiresByType image/webp "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
    ExpiresByType application/pdf "access plus 1 month"
    ExpiresByType text/html "access plus 0 seconds"
</IfModule>

# Security headers
<IfModule mod_headers.c>
    Header set X-Content-Type-Options "nosniff"
    Header set X-Frame-Options "SAMEORIGIN"
    Header set X-XSS-Protection "1; mode=block"
</IfModule>

# Prevent access to .txt files
<FilesMatch "\.txt$">
    Order allow,deny
    Deny from all
</FilesMatch>
```

## 📝 الخطوات التالية:

### 1. رفع ملف `.htaccess` على Hostinger:

**طريقة 1: استخدام cPanel File Manager:**
1. سجل الدخول إلى cPanel
2. افتح File Manager
3. اذهب إلى مجلد `public_html` أو `www` (حسب إعدادات Hostinger)
4. تأكد من أن "Show Hidden Files" مفعّل
5. ارفع ملف `.htaccess` من مجلد `out` إلى الجذر
6. تأكد من أن صلاحيات الملف هي `644`

**طريقة 2: استخدام FTP:**
1. اتصل بخادم Hostinger عبر FTP
2. اذهب إلى مجلد `public_html` أو `www`
3. ارفع ملف `.htaccess` من مجلد `out` إلى الجذر
4. تأكد من أن صلاحيات الملف هي `644`

### 2. التحقق من الصلاحيات (Permissions):

في cPanel File Manager:
- **ملفات HTML**: `644`
- **مجلدات**: `755`
- **ملف `.htaccess`**: `644`

### 3. التحقق من إعدادات Hostinger:

1. **تأكد من أن `mod_rewrite` مفعّل**:
   - في cPanel → Apache Handlers
   - تأكد من وجود `mod_rewrite`

2. **تأكد من أن Apache يقرأ ملفات `.htaccess`**:
   - في cPanel → File Manager
   - تأكد من أن `.htaccess` موجود في الجذر

### 4. اختبار الصفحات:

بعد رفع الملفات:
1. افتح: `https://service-egy.com/maintenance-center/lg-repair`
2. يجب أن تفتح الصفحة بدون خطأ 403
3. تحقق من باقي صفحات الماركز

## 🔍 حلول إضافية إذا استمرت المشكلة:

### 1. التحقق من سجلات الأخطاء (Error Logs):

في cPanel → Error Logs:
- ابحث عن أي أخطاء متعلقة بـ `.htaccess` أو Apache
- ابحث عن أي أخطاء متعلقة بـ `mod_rewrite`

### 2. اختبار ملف `.htaccess`:

إذا كان هناك خطأ في ملف `.htaccess`, قد يظهر خطأ 500:
- تحقق من سجلات الأخطاء
- تأكد من أن جميع القواعد صحيحة

### 3. حل بديل: استخدام `.htaccess` أبسط:

إذا استمرت المشكلة، جرب هذا الملف `.htaccess` الأبسط:

```apache
Options -Indexes
AddDefaultCharset UTF-8

<IfModule mod_rewrite.c>
RewriteEngine On

# Block access to .txt files
RewriteRule ^.*\.txt$ - [F,L]

# Handle maintenance-center routes
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_URI} ^/maintenance-center/(.+)$
RewriteRule ^maintenance-center/(.+)$ maintenance-center/$1.html [L]

# Handle services routes
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_URI} ^/services/(.+)$
RewriteRule ^services/(.+)$ services/$1.html [L]

# Handle other routes
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_FILENAME}.html -f
RewriteRule ^(.+?)/?$ $1.html [L]
</IfModule>

# Prevent access to .txt files
<FilesMatch "\.txt$">
    Order allow,deny
    Deny from all
</FilesMatch>
```

### 4. التحقق من وجود الملفات:

تأكد من وجود:
- ✅ ملفات `.html` في مجلد `maintenance-center` (38 ملف)
- ✅ ملف `.htaccess` في الجذر
- ✅ ملف `index.html` في الجذر

### 5. الاتصال بدعم Hostinger:

إذا استمرت المشكلة:
1. اتصل بدعم Hostinger
2. اطلب منهم التحقق من إعدادات `mod_rewrite`
3. اطلب منهم التحقق من صلاحيات الملفات
4. اطلب منهم التحقق من سجلات الأخطاء

## ✅ النتيجة المتوقعة:

بعد تطبيق الحل:
- ✅ صفحات الماركز تفتح بشكل صحيح
- ✅ لا يوجد خطأ 403 Forbidden
- ✅ جميع الروابط تعمل بشكل صحيح
- ✅ ملفات `.txt` محظورة من الوصول

## 🎯 الخلاصة:

تم إنشاء ملف `.htaccess` محسّن يحتوي على:
- ✅ منع الوصول إلى ملفات `.txt`
- ✅ قواعد Rewrite محسّنة لصفحات الماركز
- ✅ معالجة صحيحة للروابط
- ✅ إعدادات أمان محسّنة
- ✅ إعدادات Cache محسّنة

**الملف جاهز للرفع على Hostinger!** 🚀

## 📞 ملاحظات مهمة:

1. **تأكد من رفع ملف `.htaccess`**:
   - الملف موجود في `out/.htaccess`
   - يجب رفعه إلى الجذر (`public_html` أو `www`)

2. **تأكد من الصلاحيات**:
   - ملف `.htaccess`: `644`
   - ملفات HTML: `644`
   - مجلدات: `755`

3. **تحقق من إعدادات Hostinger**:
   - تأكد من أن `mod_rewrite` مفعّل
   - تأكد من أن Apache يقرأ ملفات `.htaccess`

4. **اختبار الصفحات**:
   - افتح صفحات الماركز وتحقق من أنها تعمل
   - تحقق من عدم وجود خطأ 403
