# حل سريع لمشكلة عدم وصول الإيميلات

## 🚨 الخطوات السريعة:

### 1. فتح Console في المتصفح (الأهم!)
1. افتح الموقع في المتصفح
2. اضغط `F12` لفتح Developer Tools
3. اذهب إلى تبويب **Console**
4. حاول إرسال نموذج
5. **انسخ الرسائل التي تظهر** (خاصة الأخطاء باللون الأحمر)

### 2. التحقق من Vercel Environment Variables
1. افتح [Vercel Dashboard](https://vercel.com)
2. اذهب إلى مشروع API
3. اذهب إلى **Settings** → **Environment Variables**
4. **تحقق من**:
   - `ALLOWED_ORIGINS` = `*` أو `https://your-domain.com` (domain Hostinger)
   - `SMTP_USER` = `your-email@service-egy.com`
   - `SMTP_PASSWORD` = `your-password`
   - `SMTP_TO` = `info@service-egy.com`

### 3. إعادة بناء Vercel Project
بعد تعديل Environment Variables:
1. Vercel سيعيد البناء تلقائياً
2. انتظر حتى ينتهي البناء (عادة 1-2 دقيقة)
3. تحقق من أن البناء نجح

### 4. إعادة بناء المشروع الرئيسي
```bash
npm run build
```

### 5. رفع مجلد `out` على Hostinger
1. ارفع جميع محتويات مجلد `out` على Hostinger
2. تأكد من أن `index.html` موجود في الجذر

## 🔍 ما الذي تم إصلاحه:

1. ✅ **تحسين Error Handling**: الآن الكود يظهر الأخطاء بشكل واضح في Console
2. ✅ **إضافة Logging**: الكود يسجل كل خطوة في Console
3. ✅ **تحسين Error Messages**: الرسائل الآن أكثر وضوحاً

## 📝 ما يجب فعله:

1. **افتح Console في المتصفح** وراسلني بالرسائل التي تظهر
2. **تحقق من Vercel Environment Variables** خاصة `ALLOWED_ORIGINS`
3. **اختبر API مباشرة** باستخدام curl:
   ```bash
   curl -X POST https://service-egy-api.vercel.app/api/contact \
     -H "Content-Type: application/json" \
     -d '{
       "name": "Test",
       "address": "Test",
       "phone": "01234567890",
       "whatsapp": "01234567890",
       "issueType": "عطل كهربائي",
       "deviceType": "غسالة ملابس"
     }'
   ```

## 🎯 الأخطاء الشائعة:

### CORS Error:
```
Access to fetch at '...' from origin '...' has been blocked by CORS policy
```
**الحل**: أضف domain Hostinger إلى `ALLOWED_ORIGINS` في Vercel

### SMTP Error:
```
EAUTH: Invalid login
```
**الحل**: تحقق من `SMTP_USER` و `SMTP_PASSWORD` في Vercel

### Connection Error:
```
ECONNECTION: Failed to connect
```
**الحل**: تحقق من `SMTP_HOST` و `SMTP_PORT` في Vercel

## 📞 بعد إجراء الخطوات:

1. افتح Console في المتصفح
2. حاول إرسال نموذج
3. **انسخ الرسائل التي تظهر** (خاصة الأخطاء)
4. **راسلني بالرسائل** وسأساعدك في حل المشكلة









