# دليل رفع API Route على Vercel - مختصر

## الخطوات السريعة

### 1. إنشاء مشروع Vercel جديد

#### الطريقة السريعة (باستخدام Script):

```powershell
# في مجلد المشروع الحالي
cd scripts
.\setup-vercel-api.ps1
```

#### الطريقة اليدوية:

1. **إنشاء مجلد جديد:**
```bash
mkdir service-egy-api
cd service-egy-api
```

2. **إنشاء `package.json`:**
```json
{
  "name": "service-egy-api",
  "version": "1.0.0",
  "scripts": {
    "dev": "next dev",
    "build": "next build"
  },
  "dependencies": {
    "next": "15.5.4",
    "nodemailer": "^7.0.10",
    "react": "19.1.0",
    "react-dom": "19.1.0"
  },
  "devDependencies": {
    "@types/node": "^22",
    "@types/react": "^18",
    "@types/react-dom": "^18",
    "typescript": "^5"
  }
}
```

3. **إنشاء `next.config.mjs`:**
```javascript
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
}
export default nextConfig
```

4. **إنشاء `tsconfig.json`:**
```json
{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "jsx": "preserve",
    "paths": {
      "@/*": ["./*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx"],
  "exclude": ["node_modules"]
}
```

5. **نسخ ملف API route:**
```bash
# إنشاء مجلد
mkdir -p app/api/contact

# نسخ الملف من المشروع الرئيسي
cp ../service-egy-website/app/api/contact/route.ts app/api/contact/route.ts
```

### 2. رفع المشروع على GitHub

```bash
git init
git add .
git commit -m "Initial commit: API route"
git remote add origin https://github.com/YOUR_USERNAME/service-egy-api.git
git push -u origin main
```

### 3. رفع المشروع على Vercel

1. **تسجيل الدخول إلى Vercel:**
   - اذهب إلى [vercel.com](https://vercel.com)
   - سجل الدخول بحساب GitHub

2. **إنشاء مشروع جديد:**
   - اضغط "Add New" → "Project"
   - اختر repository `service-egy-api`
   - اضغط "Import"

3. **إعداد Environment Variables:**
   - اذهب إلى "Settings" → "Environment Variables"
   - أضف المتغيرات التالية:

```
SMTP_HOST=smtp.hostinger.com
SMTP_PORT=465
SMTP_USER=your-email@service-egy.com
SMTP_PASSWORD=your-password
SMTP_FROM=your-email@service-egy.com
SMTP_TO=info@service-egy.com
ALLOWED_ORIGINS=https://service-egy.com,https://www.service-egy.com
```

4. **Deploy:**
   - اضغط "Deploy"
   - انتظر حتى ينتهي الـ deployment

5. **الحصول على URL:**
   - بعد الـ deployment، ستحصل على URL مثل: `https://service-egy-api.vercel.app`
   - URL الخاص بالـ API: `https://service-egy-api.vercel.app/api/contact`

### 4. تحديث الموقع الرئيسي

1. **إنشاء ملف `.env.local` في المشروع الرئيسي:**

```bash
NEXT_PUBLIC_CONTACT_ENDPOINT=https://service-egy-api.vercel.app/api/contact
```

2. **أو تحديث `next.config.mjs`:**

```javascript
const nextConfig = {
  output: 'export', // تفعيل static export
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  env: {
    NEXT_PUBLIC_CONTACT_ENDPOINT: 'https://service-egy-api.vercel.app/api/contact',
  },
}
export default nextConfig
```

3. **إعادة بناء المشروع:**

```bash
npm run build
```

4. **رفع مجلد `out` على Hostinger**

### 5. اختبار الـ API

```bash
# اختبار مباشر
curl -X POST https://service-egy-api.vercel.app/api/contact \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test",
    "address": "Test",
    "phone": "01123456789",
    "whatsapp": "01123456789",
    "issueType": "عطل كهربائي",
    "deviceType": "غسالة ملابس"
  }'
```

## ملاحظات مهمة

1. **CORS:** تأكد من إضافة domain الموقع في `ALLOWED_ORIGINS`
2. **Environment Variables:** لا تشارك `SMTP_PASSWORD` أبداً
3. **Custom Domain:** يمكنك ربط domain مخصص للـ API مثل `api.service-egy.com`

## استكشاف الأخطاء

### CORS Error
- تأكد من إضافة domain الموقع في `ALLOWED_ORIGINS`

### SMTP Error
- تحقق من صحة `SMTP_USER` و `SMTP_PASSWORD`
- تأكد من استخدام Port 465 مع SSL

### API لا يعمل
- تحقق من logs في Vercel Dashboard
- تأكد من أن Environment Variables محفوظة

## الخطوات السريعة (TL;DR)

1. ✅ إنشاء مشروع Next.js جديد للـ API فقط
2. ✅ نسخ `app/api/contact/route.ts` إلى المشروع الجديد
3. ✅ رفع المشروع على GitHub
4. ✅ ربط المشروع بـ Vercel
5. ✅ إضافة Environment Variables في Vercel
6. ✅ الحصول على Vercel URL
7. ✅ تحديث `NEXT_PUBLIC_CONTACT_ENDPOINT` في المشروع الرئيسي
8. ✅ إعادة بناء المشروع الرئيسي ورفعه على Hostinger

## الدعم

- [Vercel Documentation](https://vercel.com/docs)
- [Next.js API Routes](https://nextjs.org/docs/app/building-your-application/routing/route-handlers)
- [Nodemailer Documentation](https://nodemailer.com/about/)









