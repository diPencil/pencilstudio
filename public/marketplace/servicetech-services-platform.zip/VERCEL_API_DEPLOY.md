# دليل رفع API Route على Vercel

هذا الدليل يشرح كيفية رفع API Route الخاص بالفورم على Vercel ليعمل مع الموقع على Hostinger.

## المتطلبات

1. حساب على Vercel (مجاني) - [سجل هنا](https://vercel.com/signup)
2. حساب GitHub (أو GitLab/Bitbucket)
3. مشروع الموقع الحالي

## الخطوات

### الخطوة 1: إنشاء مشروع Vercel جديد للـ API فقط

#### أ) إنشاء مجلد جديد للمشروع

```bash
# في مجلد خارج المشروع الحالي
mkdir service-egy-api
cd service-egy-api
```

#### ب) إنشاء ملفات المشروع الأساسية

1. **إنشاء `package.json`:**

```json
{
  "name": "service-egy-api",
  "version": "1.0.0",
  "description": "API Route for Service Egy Contact Form",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  },
  "dependencies": {
    "next": "15.5.4",
    "nodemailer": "^7.0.10",
    "react": "19.1.0",
    "react-dom": "19.1.0"
  },
  "devDependencies": {
    "@types/node": "^22",
    "@types/react": "^18",
    "@types/react-dom": "^18",
    "typescript": "^5"
  }
}
```

2. **إنشاء `next.config.mjs`:**

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
}

export default nextConfig
```

3. **إنشاء `tsconfig.json`:**

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [
      {
        "name": "next"
      }
    ],
    "paths": {
      "@/*": ["./*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
```

4. **إنشاء مجلد `app/api/contact` ونسخ ملف `route.ts`:**

```bash
mkdir -p app/api/contact
# ثم انسخ محتوى app/api/contact/route.ts من المشروع الرئيسي
```

### الخطوة 2: رفع المشروع على GitHub

1. **تهيئة Git:**

```bash
git init
git add .
git commit -m "Initial commit: API route for contact form"
```

2. **إنشاء repository جديد على GitHub**

3. **ربط المشروع بـ GitHub:**

```bash
git remote add origin https://github.com/YOUR_USERNAME/service-egy-api.git
git branch -M main
git push -u origin main
```

### الخطوة 3: رفع المشروع على Vercel

1. **تسجيل الدخول إلى Vercel:**
   - اذهب إلى [vercel.com](https://vercel.com)
   - سجل الدخول بحساب GitHub

2. **إنشاء مشروع جديد:**
   - اضغط على "Add New" → "Project"
   - اختر repository `service-egy-api`
   - اضغط "Import"

3. **إعداد Environment Variables:**
   - في صفحة المشروع، اذهب إلى "Settings" → "Environment Variables"
   - أضف المتغيرات التالية:

```
SMTP_HOST=smtp.hostinger.com
SMTP_PORT=465
SMTP_USER=your-email@service-egy.com
SMTP_PASSWORD=your-password
SMTP_FROM=your-email@service-egy.com
SMTP_TO=info@service-egy.com
ALLOWED_ORIGINS=https://service-egy.com,https://www.service-egy.com
```

4. **Deploy:**
   - اضغط "Deploy"
   - انتظر حتى ينتهي الـ deployment

5. **الحصول على URL:**
   - بعد الـ deployment، ستحصل على URL مثل: `https://service-egy-api.vercel.app`
   - URL الخاص بالـ API route: `https://service-egy-api.vercel.app/api/contact`

### الخطوة 4: تحديث الموقع الرئيسي

1. **إنشاء ملف `.env.local` في المشروع الرئيسي:**

```bash
NEXT_PUBLIC_CONTACT_ENDPOINT=https://service-egy-api.vercel.app/api/contact
```

2. **أو تحديث `next.config.mjs`:**

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export', // تفعيل static export
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  env: {
    NEXT_PUBLIC_CONTACT_ENDPOINT: 'https://service-egy-api.vercel.app/api/contact',
  },
}
```

3. **إعادة بناء المشروع:**

```bash
npm run build
```

4. **رفع مجلد `out` على Hostinger**

### الخطوة 5: اختبار الـ API

1. **اختبار الـ API مباشرة:**

```bash
curl -X POST https://service-egy-api.vercel.app/api/contact \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "address": "Test Address",
    "phone": "01123456789",
    "whatsapp": "01123456789",
    "issueType": "عطل كهربائي",
    "deviceType": "غسالة ملابس"
  }'
```

2. **اختبار الفورم على الموقع:**
   - اذهب إلى الموقع على Hostinger
   - املأ الفورم
   - تحقق من استلام الإيميل

## ملاحظات مهمة

1. **CORS:**
   - تأكد من إضافة domain الموقع في `ALLOWED_ORIGINS`
   - يمكنك استخدام `*` للسماح لجميع المواقع (غير موصى به للإنتاج)

2. **Environment Variables:**
   - لا تشارك `SMTP_PASSWORD` أبداً
   - استخدم Environment Variables في Vercel لحماية المعلومات الحساسة

3. **Custom Domain (اختياري):**
   - يمكنك ربط domain مخصص للـ API مثل `api.service-egy.com`
   - اذهب إلى "Settings" → "Domains" في Vercel
   - أضف domain المخصص

4. **Monitoring:**
   - يمكنك مراقبة الـ API من خلال Vercel Dashboard
   - اذهب إلى "Analytics" لمشاهدة الإحصائيات

## استكشاف الأخطاء

### المشكلة: CORS Error

**الحل:**
- تأكد من إضافة domain الموقع في `ALLOWED_ORIGINS`
- تحقق من أن الـ API route يرسل headers صحيحة

### المشكلة: SMTP Error

**الحل:**
- تحقق من صحة `SMTP_USER` و `SMTP_PASSWORD`
- تأكد من استخدام Port 465 مع SSL
- تحقق من أن Hostinger يسمح بـ SMTP connections

### المشكلة: API لا يعمل

**الحل:**
- تحقق من logs في Vercel Dashboard
- تأكد من أن Environment Variables محفوظة بشكل صحيح
- تحقق من أن الـ API route يعمل محلياً

## الخطوات السريعة (TL;DR)

1. إنشاء مشروع Next.js جديد للـ API فقط
2. نسخ `app/api/contact/route.ts` إلى المشروع الجديد
3. رفع المشروع على GitHub
4. ربط المشروع بـ Vercel
5. إضافة Environment Variables في Vercel
6. الحصول على Vercel URL
7. تحديث `NEXT_PUBLIC_CONTACT_ENDPOINT` في المشروع الرئيسي
8. إعادة بناء المشروع الرئيسي ورفعه على Hostinger

## الدعم

إذا واجهت أي مشاكل، تحقق من:
- [Vercel Documentation](https://vercel.com/docs)
- [Next.js API Routes](https://nextjs.org/docs/app/building-your-application/routing/route-handlers)
- [Nodemailer Documentation](https://nodemailer.com/about/)









