# حل مشكلة عدم وصول الإيميلات - خطوات مفصلة

## 🔍 المشكلة:
الإيميلات لا تصل بعد إرسال النموذج من الموقع على Hostinger.

## ✅ الخطوات للحل:

### 1. فتح Console في المتصفح
1. افتح الموقع في المتصفح (الموقع على Hostinger)
2. اضغط `F12` أو `Ctrl+Shift+I` لفتح Developer Tools
3. اذهب إلى تبويب **Console**
4. حاول إرسال نموذج
5. ابحث عن الرسائل التالية:
   - `Sending request to API endpoint: ...` ← يجب أن يظهر URL Vercel API
   - `API Response status: ...` ← يجب أن يظهر status code
   - أي رسائل خطأ (باللون الأحمر) ← اقرأها وراسلني بها

### 2. التحقق من Vercel API Environment Variables
1. افتح [Vercel Dashboard](https://vercel.com)
2. اذهب إلى مشروع API (`service-egy-api`)
3. اذهب إلى **Settings** → **Environment Variables**
4. تأكد من وجود المتغيرات التالية:
   - `SMTP_HOST` = `smtp.hostinger.com`
   - `SMTP_PORT` = `465`
   - `SMTP_USER` = `your-email@service-egy.com` (الإيميل الخاص بك)
   - `SMTP_PASSWORD` = `your-password` (كلمة المرور)
   - `SMTP_TO` = `info@service-egy.com` (إيميل المستقبل)
   - `ALLOWED_ORIGINS` = `*` (للسماح بجميع domains) أو `https://your-domain.com,https://www.your-domain.com`

### 3. التحقق من CORS Settings
**المشكلة الأكثر شيوعاً**: CORS Error

**الحل**:
1. في Vercel Dashboard، اذهب إلى **Environment Variables**
2. أضف أو عدل `ALLOWED_ORIGINS`:
   ```
   ALLOWED_ORIGINS=https://your-hostinger-domain.com,https://www.your-hostinger-domain.com
   ```
   أو استخدم `*` للسماح بجميع domains (للتطوير فقط)

3. بعد تعديل Environment Variables، Vercel سيعيد البناء تلقائياً
4. انتظر حتى ينتهي البناء (عادة 1-2 دقيقة)

### 4. التحقق من API Endpoint URL
1. افتح `next.config.mjs` في المشروع الرئيسي
2. تأكد من أن `NEXT_PUBLIC_CONTACT_ENDPOINT` يحتوي على URL Vercel الصحيح:
   ```javascript
   NEXT_PUBLIC_CONTACT_ENDPOINT: process.env.NEXT_PUBLIC_CONTACT_ENDPOINT || 'https://service-egy-api.vercel.app/api/contact'
   ```
3. إذا كان URL Vercel مختلف، غيره هنا
4. أعد بناء المشروع:
   ```bash
   npm run build
   ```
5. ارفع مجلد `out` على Hostinger مرة أخرى

### 5. اختبار API مباشرة
افتح Terminal أو Postman واختبر API مباشرة:

```bash
curl -X POST https://service-egy-api.vercel.app/api/contact \
  -H "Content-Type: application/json" \
  -H "Origin: https://your-hostinger-domain.com" \
  -d '{
    "name": "Test User",
    "address": "Test Address",
    "phone": "01234567890",
    "whatsapp": "01234567890",
    "issueType": "عطل كهربائي",
    "deviceType": "غسالة ملابس",
    "details": "Test message"
  }'
```

إذا نجح، يجب أن ترى:
```json
{
  "message": "تم إرسال الطلب بنجاح",
  "success": true,
  "messageId": "..."
}
```

### 6. التحقق من Vercel Logs
1. افتح Vercel Dashboard
2. اذهب إلى مشروع API
3. اذهب إلى **Logs**
4. ابحث عن أي أخطاء أو رسائل
5. إذا رأيت أخطاء SMTP، تأكد من أن `SMTP_USER` و `SMTP_PASSWORD` صحيحين

## 🐛 المشاكل الشائعة والحلول:

### المشكلة 1: CORS Error
**الخطأ**: `Access to fetch at '...' from origin '...' has been blocked by CORS policy`

**الحل**:
1. في Vercel Dashboard، أضف domain Hostinger إلى `ALLOWED_ORIGINS`:
   ```
   ALLOWED_ORIGINS=https://your-hostinger-domain.com,https://www.your-hostinger-domain.com
   ```
2. بعد التعديل، Vercel سيعيد البناء تلقائياً
3. انتظر حتى ينتهي البناء

### المشكلة 2: SMTP Authentication Error
**الخطأ**: `EAUTH` أو `خطأ في بيانات الدخول SMTP`

**الحل**:
1. تأكد من أن `SMTP_USER` و `SMTP_PASSWORD` صحيحين في Vercel
2. تأكد من أن الإيميل موجود في Hostinger
3. تأكد من أن كلمة المرور صحيحة (لا توجد مسافات في البداية أو النهاية)

### المشكلة 3: Connection Error
**الخطأ**: `ECONNECTION` أو `فشل الاتصال بخادم SMTP`

**الحل**:
1. تأكد من أن `SMTP_HOST` = `smtp.hostinger.com`
2. تأكد من أن `SMTP_PORT` = `465`
3. تأكد من أن Hostinger يسمح بالاتصالات من Vercel

### المشكلة 4: API Endpoint Not Found
**الخطأ**: `404 Not Found` أو `API route not available`

**الحل**:
1. تأكد من أن URL Vercel صحيح في `next.config.mjs`
2. تأكد من أن API route موجود في Vercel
3. تأكد من أن Vercel project تم رفعه بشكل صحيح

### المشكلة 5: الإيميلات تذهب إلى Junk
**الحل**:
1. تأكد من أن `from` address في API route يستخدم `SMTP_USER`
2. تأكد من إزالة أي headers قد تسبب spam
3. تأكد من أن محتوى الإيميل لا يحتوي على كلمات spam

## 📝 خطوات إعادة البناء:

### 1. تحديث الكود:
```bash
npm run build
```

### 2. رفع مجلد `out` على Hostinger:
- ارفع جميع محتويات مجلد `out` على Hostinger
- تأكد من أن `index.html` موجود في الجذر

### 3. التحقق من Vercel:
- تأكد من أن environment variables موجودة
- تأكد من أن API route يعمل بشكل صحيح
- تأكد من أن CORS settings صحيحة

## 🔧 نصائح إضافية:

1. **استخدام Console**: افتح Console في المتصفح لرؤية الأخطاء
2. **فحص Network Tab**: افتح Network tab في Developer Tools لرؤية طلبات API
3. **فحص Vercel Logs**: راجع logs في Vercel لرؤية أخطاء الخادم
4. **اختبار API مباشرة**: استخدم curl أو Postman لاختبار API مباشرة

## 📞 ما يجب فعله الآن:

1. **افتح Console في المتصفح** وراسلني بالرسائل التي تظهر
2. **تحقق من Vercel Environment Variables** وتأكد من أن `ALLOWED_ORIGINS` يحتوي على domain Hostinger
3. **اختبر API مباشرة** باستخدام curl أو Postman
4. **راجع Vercel Logs** لرؤية أي أخطاء

## 🎯 الخطوات المهمة:

1. ✅ تحديث الكود لإظهار الأخطاء بشكل أفضل
2. ✅ إعادة بناء المشروع
3. ⏳ رفع مجلد `out` على Hostinger
4. ⏳ التحقق من Vercel Environment Variables
5. ⏳ التحقق من CORS Settings
6. ⏳ اختبار API مباشرة









