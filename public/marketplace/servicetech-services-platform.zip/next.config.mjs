/** @type {import('next').NextConfig} */
const nextConfig = {
  // Enable static export for Hostinger (only in production build)
  // In dev mode, we don't use static export to enable Fast Refresh
  ...(process.env.NODE_ENV === 'production' && { output: 'export' }),
  // Use trailing slash for better compatibility with static hosting
  trailingSlash: false,
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // Add environment variables for build time
  env: {
    // Vercel API URL - تم التحديث إلى URL الصحيح
    NEXT_PUBLIC_CONTACT_ENDPOINT: process.env.NEXT_PUBLIC_CONTACT_ENDPOINT || 'https://service-egy-78em.vercel.app/api/contact',
  },
}

export default nextConfig
