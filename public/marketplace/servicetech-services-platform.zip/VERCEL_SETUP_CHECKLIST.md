# ✅ Checklist لإعداد Vercel API بشكل صحيح

## 📋 الخطوات المهمة:

### 1. ✅ تحديث API URL (تم)
- تم تحديث `next.config.mjs` لاستخدام URL الصحيح: `https://service-egy-78em.vercel.app/api/contact`
- تم إعادة بناء المشروع بنجاح

### 2. ⏳ التحقق من Vercel Environment Variables

في Vercel Dashboard → مشروع `service-egy-78em` → **Settings** → **Environment Variables**:

#### Environment Variables المطلوبة:

1. **`ALLOWED_ORIGINS`** ⚠️ **مهم جداً!**
   - القيمة: `*` (للتطوير) أو `https://your-domain.com,https://www.your-domain.com` (domain Hostinger)
   - بدون هذا، ستحصل على CORS Error!

2. **`SMTP_HOST`**
   - القيمة: `smtp.hostinger.com`

3. **`SMTP_PORT`**
   - القيمة: `465`

4. **`SMTP_USER`**
   - القيمة: `your-email@service-egy.com` (الإيميل الخاص بك في Hostinger)

5. **`SMTP_PASSWORD`**
   - القيمة: `your-password` (كلمة المرور الخاصة بالإيميل)

6. **`SMTP_TO`**
   - القيمة: `info@service-egy.com` (إيميل المستقبل)

### 3. ⏳ إعادة بناء Vercel Project

بعد إضافة/تعديل Environment Variables:
1. Vercel سيعيد البناء تلقائياً
2. انتظر حتى ينتهي البناء (عادة 1-2 دقيقة)
3. تحقق من أن البناء نجح (يظهر "Ready" بجانب Deployment)

### 4. ⏳ رفع مجلد `out` على Hostinger

1. افتح File Manager في Hostinger
2. اذهب إلى `public_html` أو `www`
3. ارفع جميع محتويات مجلد `out` (ليس المجلد نفسه)
4. تأكد من أن `index.html` موجود في الجذر

### 5. ⏳ اختبار API

#### اختبار 1: اختبار API مباشرة
افتح Terminal أو Postman واختبر API:

```bash
curl -X POST https://service-egy-78em.vercel.app/api/contact \
  -H "Content-Type: application/json" \
  -H "Origin: https://your-domain.com" \
  -d '{
    "name": "Test User",
    "address": "Test Address",
    "phone": "01234567890",
    "whatsapp": "01234567890",
    "issueType": "عطل كهربائي",
    "deviceType": "غسالة ملابس",
    "details": "Test message"
  }'
```

إذا نجح، يجب أن ترى:
```json
{
  "message": "تم إرسال الطلب بنجاح",
  "success": true,
  "messageId": "..."
}
```

#### اختبار 2: اختبار من الموقع
1. افتح الموقع في المتصفح
2. اضغط `F12` لفتح Developer Tools
3. اذهب إلى تبويب **Console**
4. حاول إرسال نموذج
5. يجب أن ترى:
   - `Sending request to API endpoint: https://service-egy-78em.vercel.app/api/contact`
   - `API Response status: 200 OK`
   - `API Response: {message: "تم إرسال الطلب بنجاح", success: true}`

## 🐛 حل المشاكل الشائعة:

### المشكلة 1: CORS Error
**الخطأ**: `Access to fetch at '...' from origin '...' has been blocked by CORS policy`

**الحل**:
1. في Vercel Dashboard، اذهب إلى **Settings** → **Environment Variables**
2. أضف أو عدل `ALLOWED_ORIGINS`:
   ```
   ALLOWED_ORIGINS=https://your-domain.com,https://www.your-domain.com
   ```
   أو استخدم `*` للسماح بجميع domains (للتطوير فقط)

3. بعد التعديل، Vercel سيعيد البناء تلقائياً
4. انتظر حتى ينتهي البناء

### المشكلة 2: SMTP Authentication Error
**الخطأ**: `EAUTH: Invalid login` أو `خطأ في بيانات الدخول SMTP`

**الحل**:
1. تأكد من أن `SMTP_USER` و `SMTP_PASSWORD` صحيحين في Vercel
2. تأكد من أن الإيميل موجود في Hostinger
3. تأكد من أن كلمة المرور صحيحة (لا توجد مسافات في البداية أو النهاية)

### المشكلة 3: Connection Error
**الخطأ**: `ECONNECTION: Failed to connect` أو `فشل الاتصال بخادم SMTP`

**الحل**:
1. تأكد من أن `SMTP_HOST` = `smtp.hostinger.com`
2. تأكد من أن `SMTP_PORT` = `465`
3. تأكد من أن Hostinger يسمح بالاتصالات من Vercel

### المشكلة 4: API Endpoint Not Found
**الخطأ**: `404 Not Found` أو `API route not available`

**الحل**:
1. تأكد من أن URL Vercel صحيح: `https://service-egy-78em.vercel.app/api/contact`
2. تأكد من أن API route موجود في Vercel
3. تأكد من أن Vercel project تم رفعه بشكل صحيح

## 📝 ملاحظات مهمة:

1. **Environment Variables**: يجب إضافتها في Vercel Dashboard → Settings → Environment Variables
2. **CORS**: بدون `ALLOWED_ORIGINS` الصحيح، ستحصل على CORS Error
3. **SMTP Settings**: يجب أن تكون صحيحة في Vercel
4. **Rebuild**: بعد تعديل Environment Variables، Vercel سيعيد البناء تلقائياً
5. **Testing**: اختبر API مباشرة قبل الاختبار من الموقع

## 🎯 الخطوات التالية:

1. ✅ تحديث API URL في `next.config.mjs` (تم)
2. ✅ إعادة بناء المشروع (تم)
3. ⏳ إضافة Environment Variables في Vercel
4. ⏳ إعادة بناء Vercel Project
5. ⏳ رفع مجلد `out` على Hostinger
6. ⏳ اختبار API مباشرة
7. ⏳ اختبار من الموقع

## 📞 بعد إجراء الخطوات:

1. افتح Console في المتصفح
2. حاول إرسال نموذج
3. **انسخ الرسائل التي تظهر** (خاصة الأخطاء)
4. **راسلني بالرسائل** إذا كانت هناك مشاكل









