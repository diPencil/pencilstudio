# خطوات رفع المشروع على Hostinger

## ✅ الخطوات المكتملة:

1. **تفعيل Static Export**: تم تفعيل `output: 'export'` في `next.config.mjs`
2. **إضافة API Endpoint**: تم إضافة `NEXT_PUBLIC_CONTACT_ENDPOINT` في `next.config.mjs`
3. **بناء المشروع**: تم بناء المشروع وإنشاء مجلد `out`

## 📋 الخطوات المتبقية:

### 1. التحقق من Vercel API URL
تأكد من أن الـ URL في `next.config.mjs` صحيح. الـ URL الحالي:
```
https://service-egy-api.vercel.app/api/contact
```

إذا كان الـ URL مختلف في Vercel، قم بتعديله في `next.config.mjs`:

```javascript
env: {
  NEXT_PUBLIC_CONTACT_ENDPOINT: process.env.NEXT_PUBLIC_CONTACT_ENDPOINT || 'YOUR_VERCEL_API_URL_HERE',
},
```

أو قم بإنشاء ملف `.env.local` وأضف:
```
NEXT_PUBLIC_CONTACT_ENDPOINT=https://your-vercel-api-url.vercel.app/api/contact
```

### 2. إعادة بناء المشروع
بعد تعديل الـ URL (إن وُجد)، قم بإعادة بناء المشروع:
```bash
npm run build
```

### 3. رفع مجلد `out` على Hostinger
1. افتح File Manager في Hostinger
2. اذهب إلى مجلد `public_html` أو `www`
3. ارفع جميع محتويات مجلد `out` (ليس المجلد نفسه)
4. تأكد من رفع ملف `index.html` في الجذر

### 4. التحقق من العمل
1. افتح الموقع في المتصفح
2. جرب إرسال نموذج اتصال
3. تأكد من أن الإيميلات تصل بشكل صحيح

## 🔍 ملاحظات مهمة:

- **API Routes**: تم نقل API routes إلى Vercel، لذلك لن تعمل في Hostinger
- **Static Export**: المشروع الآن static فقط، لا يمكن استخدام Server Components
- **Environment Variables**: يجب إضافة `NEXT_PUBLIC_*` variables في `next.config.mjs` أو `.env.local` قبل البناء
- **CORS**: تأكد من أن Vercel API يسمح بـ CORS requests من domain Hostinger

## 📝 الملفات المهمة:

- `next.config.mjs`: إعدادات المشروع و environment variables
- `out/`: مجلد الملفات الجاهزة للرفع
- `components/contact-form.tsx`: نموذج الاتصال
- `components/maintenance-form-dialog.tsx`: نموذج الصيانة في pop-up

## 🐛 حل المشاكل:

### الإيميلات لا تصل:
- تأكد من إعدادات SMTP في Vercel
- تأكد من أن `ALLOWED_ORIGINS` في Vercel يتضمن domain Hostinger

### الفورم لا يعمل:
- تأكد من أن Vercel API يعمل بشكل صحيح
- تأكد من أن الـ URL في `next.config.mjs` صحيح
- تحقق من Console في المتصفح للأخطاء

### الصور لا تظهر:
- تأكد من رفع مجلد `public` على Hostinger
- تأكد من أن مسارات الصور صحيحة









