# نشر المشروع على Hostinger مع SMTP

## ⚠️ ملاحظة مهمة

المشروع الآن يستخدم **API Routes** لإرسال الإيميلات عبر SMTP. هذا يعني أنك تحتاج إلى:

### خيار 1: تشغيل كـ Node.js App (مُوصى به)
إذا كان Hostinger يدعم Node.js:
1. ارفع المشروع كاملاً (بما في ذلك `node_modules`)
2. قم بتشغيل `npm install`
3. قم بتشغيل `npm run build`
4. قم بتشغيل `npm start`
5. أضف متغيرات البيئة في لوحة تحكم Hostinger

### خيار 2: استخدام Static Export (بدون SMTP)
إذا كنت تريد static export فقط:
1. أعد إضافة `output: 'export'` في `next.config.mjs`
2. استخدم Web3Forms أو Formspree لإرسال الإيميلات
3. راجع `EMAIL_SETUP.md` للتعليمات

## 🔧 إعداد SMTP على Hostinger

### 1. إعدادات SMTP من Hostinger

عادةً ما تكون إعدادات Hostinger:
- **SMTP Host:** `smtp.hostinger.com`
- **SMTP Port:** `465` (SSL) أو `587` (TLS)
- **Username:** إيميلك الكامل (مثل: `info@service-egy.com`)
- **Password:** `&L&&C9]pB`

### 2. إضافة متغيرات البيئة

#### على لوحة تحكم Hostinger:
1. اذهب إلى إعدادات التطبيق
2. أضف متغيرات البيئة التالية:

```env
SMTP_HOST=smtp.hostinger.com
SMTP_PORT=465
SMTP_USER=info@service-egy.com
SMTP_PASSWORD=your_email_password
SMTP_FROM=info@service-egy.com
SMTP_TO=info@service-egy.com
```

#### أو في ملف `.env.local` (للتطوير المحلي):
أنشئ ملف `.env.local` في جذر المشروع:

```env
SMTP_HOST=smtp.hostinger.com
SMTP_PORT=465
SMTP_USER=info@service-egy.com
SMTP_PASSWORD=your_email_password
SMTP_FROM=info@service-egy.com
SMTP_TO=info@service-egy.com
```

### 3. بناء المشروع

```bash
npm run build
```

### 4. تشغيل المشروع

```bash
npm start
```

أو إذا كان Hostinger يستخدم PM2 أو أي process manager:
```bash
pm2 start npm --name "service-egy" -- start
```

## ✅ اختبار الإعداد

1. افتح الموقع
2. املأ الفورم
3. أرسل الطلب
4. تحقق من إيميل `info@service-egy.com`

## 🔍 استكشاف الأخطاء

### المشكلة: API route لا يعمل
**الحل:**
- تأكد من أن `output: 'export'` غير موجود في `next.config.mjs`
- تأكد من أن المشروع يعمل كـ Node.js app وليس static site

### المشكلة: خطأ في SMTP
**الحل:**
- تحقق من إعدادات SMTP في `.env.local` أو متغيرات البيئة
- تأكد من أن الإيميل وكلمة المرور صحيحة
- جرب Port 587 بدلاً من 465

## 📝 ملاحظات إضافية

- تأكد من أن Hostinger يدعم Node.js
- إذا لم يدعم، استخدم الحل البديل (Web3Forms أو Formspree)
- راجع `SMTP_SETUP.md` للتفاصيل الكاملة



