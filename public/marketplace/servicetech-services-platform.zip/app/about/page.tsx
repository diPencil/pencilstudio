import { CheckCircle2, Award, Users, Clock, Shield, TrendingUp, Wrench, Star, Phone } from "lucide-react"
import Link from "next/link"
import { Metadata } from "next"
import TestimonialsSlider from "@/components/testimonials-slider"

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://service-egy.com'

export const metadata: Metadata = {
  title: "من نحن",
  description: "تعرف على Service Egy - شركة صيانة معتمدة بخبرة تزيد عن 15 عاماً في صيانة الأجهزة المنزلية في مصر. فريق محترف، معايير جودة عالية، وخدمة في جميع المحافظات.",
  keywords: [
    "من نحن",
    "Service Egy",
    "شركة صيانة مصر",
    "تاريخ الشركة",
    "فريق الصيانة",
    "خبرة صيانة مصر"
  ],
  openGraph: {
    title: "من نحن - Service Egy",
    description: "تعرف على Service Egy - شركة صيانة معتمدة بخبرة تزيد عن 15 عاماً في صيانة الأجهزة المنزلية في مصر",
    url: `${baseUrl}/about`,
    images: [`${baseUrl}/professional-technician-repairing-washing-machine-.jpg`],
  },
  alternates: {
    canonical: "/about",
  },
}

export default function About() {
  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#2563eb] via-[#1d4ed8] to-[#1e40af] text-white py-12 sm:py-16 md:py-24 px-4 sm:px-6 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-300 rounded-full blur-3xl"></div>
        </div>
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="max-w-4xl">
            <h1 className="text-2xl sm:text-3xl md:text-5xl lg:text-6xl font-bold mb-4 sm:mb-6 text-balance leading-tight">
              Service Egy – خبرة تمتد لسنوات في خدمة منزلك
            </h1>
            <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-blue-100 leading-relaxed text-pretty">
              نحن لسنا مجرد شركة صيانة، بل شريكك الموثوق في الحفاظ على أجهزتك المنزلية بأعلى معايير الجودة والاحترافية
            </p>
          </div>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-10 sm:py-14 md:py-20 px-4 sm:px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 sm:gap-12 md:gap-16 items-center">
            <div>
              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4 sm:mb-6 leading-tight">قصتنا</h2>
              <div className="space-y-4 sm:space-y-6 text-sm sm:text-base md:text-lg text-gray-700 leading-relaxed">
                <p>
                  بدأت Service Egy رحلتها من إيمان راسخ بأن كل منزل مصري يستحق خدمة صيانة احترافية تليق بأجهزته
                  المنزلية. منذ تأسيسها، رسّخت الشركة مكانتها كواحدة من أبرز الشركات المصرية الرائدة في مجال صيانة وإصلاح
                  الأجهزة المنزلية بجميع أنواعها.
                </p>
                <p>
                  ما يميزنا ليس فقط خبرتنا الواسعة، بل التزامنا الحقيقي بتقديم خدمة تتجاوز توقعات عملائنا. نحن لا نصلح
                  الأعطال فقط، بل نعيد لأجهزتك كفاءتها الأصلية ونطيل عمرها الافتراضي من خلال صيانة دورية واحترافية.
                </p>
                <p>
                  يعمل لدينا فريق هندسي معتمد يتمتع بخبرة واسعة في التعامل مع جميع الماركات العالمية والمحلية، ويخضع
                  لتدريبات دورية على أحدث التقنيات والأساليب في مجال الصيانة. كل فني في فريقنا مؤهل ومدرب على أعلى مستوى
                  لضمان تقديم خدمة متميزة.
                </p>
                <p>
                  نفخر بأننا نخدم آلاف الأسر المصرية في جميع أنحاء الجمهورية، ونسعى دائماً لتوسيع نطاق خدماتنا لنكون
                  قريبين من كل عميل يثق بنا ويختارنا شريكاً في الحفاظ على منزله.
                </p>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-[4/3] rounded-xl sm:rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src="/professional-technician-repairing-washing-machine-.jpg"
                  alt="فريق Service Egy"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-4 sm:-bottom-6 md:-bottom-8 -left-4 sm:-left-6 md:-left-8 bg-[#2563eb] text-white p-4 sm:p-6 md:p-8 rounded-lg sm:rounded-xl shadow-xl">
                <div className="text-3xl sm:text-4xl md:text-5xl font-bold mb-1 sm:mb-2">15+</div>
                <div className="text-sm sm:text-base md:text-lg">سنة خبرة</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-10 sm:py-14 md:py-20 px-4 sm:px-6 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-6 sm:gap-8">
            <div className="bg-white p-6 sm:p-8 md:p-10 rounded-xl sm:rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4 sm:mb-6">
                <TrendingUp className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 text-[#2563eb]" />
              </div>
              <h3 className="text-2xl sm:text-2xl md:text-3xl font-bold text-gray-900 mb-3 sm:mb-4">رؤيتنا</h3>
              <p className="text-sm sm:text-base md:text-lg text-gray-700 leading-relaxed">
                أن نكون الشركة الأولى والأكثر ثقة في مصر التي يعتمد عليها كل منزل في صيانة وإصلاح أجهزته المنزلية، ونسعى
                لتحقيق التميز في كل خدمة نقدمها من خلال الابتكار المستمر والالتزام بأعلى معايير الجودة.
              </p>
            </div>
            <div className="bg-gradient-to-br from-[#2563eb] to-[#1d4ed8] text-white p-6 sm:p-8 md:p-10 rounded-xl sm:rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 bg-white/20 rounded-full flex items-center justify-center mb-4 sm:mb-6">
                <Award className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 text-white" />
              </div>
              <h3 className="text-2xl sm:text-2xl md:text-3xl font-bold mb-3 sm:mb-4">رسالتنا</h3>
              <p className="text-sm sm:text-base md:text-lg text-blue-50 leading-relaxed">
                تقديم خدمة صيانة سريعة وآمنة وموثوقة تعتمد على الخبرة الفنية العالية والالتزام الصارم بالمواعيد وجودة
                التنفيذ، مع ضمان رضا العملاء الكامل من خلال استخدام قطع غيار أصلية ومتابعة دورية بعد الصيانة.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-10 sm:py-14 md:py-20 px-4 sm:px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8 sm:mb-12 md:mb-16">
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-3 sm:mb-4 leading-tight">لماذا تختار Service Egy؟</h2>
            <p className="text-sm sm:text-base md:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
              نقدم لك مجموعة من المزايا التي تجعلنا الخيار الأمثل لصيانة أجهزتك المنزلية
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 md:gap-8">
            {[
              {
                icon: <Users className="w-8 h-8" />,
                title: "فريق محترف ومعتمد",
                description:
                  "فنيون ومهندسون معتمدون يتمتعون بخبرة واسعة في التعامل مع جميع أنواع الأجهزة المنزلية والماركات العالمية",
              },
              {
                icon: <Clock className="w-8 h-8" />,
                title: "سرعة في الاستجابة",
                description: "نصل إليك في أسرع وقت ممكن، مع الالتزام التام بالمواعيد المحددة واحترام وقتك",
              },
              {
                icon: <Shield className="w-8 h-8" />,
                title: "ضمان شامل",
                description: "نقدم ضماناً مكتوباً على جميع خدمات الصيانة وقطع الغيار المستخدمة لراحة بالك",
              },
              {
                icon: <CheckCircle2 className="w-8 h-8" />,
                title: "قطع غيار أصلية",
                description: "نستخدم فقط قطع غيار أصلية 100% معتمدة من الشركات المصنعة لضمان أفضل أداء",
              },
              {
                icon: <Award className="w-8 h-8" />,
                title: "خبرة تمتد لسنوات",
                description: "أكثر من 15 عاماً من الخبرة في مجال صيانة الأجهزة المنزلية بجميع أنواعها",
              },
              {
                icon: <Star className="w-8 h-8" />,
                title: "رضا العملاء",
                description: "آلاف العملاء الراضين عن خدماتنا وتقييمات ممتازة تعكس جودة عملنا",
              },
            ].map((item, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-gray-50 to-blue-50 p-5 sm:p-6 md:p-8 rounded-lg sm:rounded-xl hover:shadow-lg transition-all group"
              >
                <div className="w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 bg-[#2563eb] text-white rounded-full flex items-center justify-center mb-4 sm:mb-6 group-hover:scale-110 transition-transform">
                  <div className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8">{item.icon}</div>
                </div>
                <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-gray-900 mb-2 sm:mb-3">{item.title}</h3>
                <p className="text-sm sm:text-base text-gray-700 leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-10 sm:py-14 md:py-20 px-4 sm:px-6 bg-gradient-to-br from-[#2563eb] to-[#1d4ed8] text-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8 sm:mb-12 md:mb-16">
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-3 sm:mb-4 leading-tight">قيمنا الأساسية</h2>
            <p className="text-sm sm:text-base md:text-lg lg:text-xl text-blue-100 max-w-3xl mx-auto">
              المبادئ التي نؤمن بها ونلتزم بها في كل خدمة نقدمها
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            {[
              { title: "الأمانة", description: "نتعامل بشفافية تامة ونلتزم بالصدق في كل تعاملاتنا مع عملائنا" },
              { title: "الجودة", description: "نسعى دائماً لتقديم أعلى مستويات الجودة في كل خدمة نقدمها" },
              { title: "الاحترافية", description: "نلتزم بأعلى معايير الاحترافية في التعامل والتنفيذ" },
              { title: "الابتكار", description: "نواكب أحدث التقنيات ونطور خدماتنا باستمرار" },
            ].map((value, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 sm:w-18 sm:h-18 md:w-20 md:h-20 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4 backdrop-blur-sm">
                  <span className="text-2xl sm:text-2xl md:text-3xl font-bold">{index + 1}</span>
                </div>
                <h3 className="text-lg sm:text-xl md:text-2xl font-bold mb-2 sm:mb-3">{value.title}</h3>
                <p className="text-sm sm:text-base text-blue-100 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-10 sm:py-14 md:py-20 px-4 sm:px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8 sm:mb-12 md:mb-16">
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-3 sm:mb-4 leading-tight">إنجازاتنا بالأرقام</h2>
            <p className="text-sm sm:text-base md:text-lg lg:text-xl text-gray-600">أرقام تعكس ثقة عملائنا وجودة خدماتنا</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 md:gap-8">
            {[
              { number: "50,000+", label: "عميل راضٍ", icon: <Users className="w-8 h-8" /> },
              { number: "100,000+", label: "جهاز تم صيانته", icon: <Wrench className="w-8 h-8" /> },
              { number: "27", label: "محافظة نخدمها", icon: <Award className="w-8 h-8" /> },
              { number: "98%", label: "نسبة رضا العملاء", icon: <Star className="w-8 h-8" /> },
            ].map((stat, index) => (
              <div
                key={index}
                className="text-center p-4 sm:p-6 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50 rounded-lg sm:rounded-xl hover:shadow-lg transition-shadow"
              >
                <div className="w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 bg-[#2563eb] text-white rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
                  <div className="w-5 h-5 sm:w-6 sm:h-6 md:w-8 md:h-8">{stat.icon}</div>
                </div>
                <div className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#2563eb] mb-1 sm:mb-2">{stat.number}</div>
                <div className="text-xs sm:text-sm md:text-base lg:text-lg text-gray-700 font-semibold">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Commitments */}
      <section className="py-10 sm:py-14 md:py-20 px-4 sm:px-6 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 sm:gap-12 md:gap-16 items-start">
            <div>
              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-6 sm:mb-8 leading-tight">التزاماتنا تجاهك</h2>
              <div className="space-y-4 sm:space-y-6">
                {[
                  {
                    title: "الشفافية الكاملة",
                    description: "نوضح لك كل تفاصيل العطل والتكلفة قبل البدء في أي عمل، بدون أي رسوم خفية",
                  },
                  {
                    title: "الالتزام بالمواعيد",
                    description: "نحترم وقتك ونلتزم بالمواعيد المحددة، ونصل إليك في الوقت المتفق عليه",
                  },
                  {
                    title: "معايير الجودة العالية",
                    description: "نطبق أعلى معايير الجودة في كل زيارة ونتأكد من رضاك التام عن الخدمة",
                  },
                  {
                    title: "قطع غيار أصلية",
                    description: "نستخدم فقط قطع غيار أصلية 100% معتمدة من الشركات المصنعة",
                  },
                  {
                    title: "ضمان مكتوب",
                    description: "نقدم ضماناً مكتوباً على جميع خدمات الصيانة وقطع الغيار المستخدمة",
                  },
                  {
                    title: "متابعة بعد الصيانة",
                    description: "نتابع معك بعد الصيانة للتأكد من أن كل شيء يعمل بكفاءة تامة",
                  },
                ].map((item, index) => (
                  <div
                    key={index}
                    className="flex gap-3 sm:gap-4 bg-white p-4 sm:p-5 md:p-6 rounded-lg sm:rounded-xl shadow-sm hover:shadow-md transition-shadow"
                  >
                    <div className="flex-shrink-0">
                      <CheckCircle2 className="w-5 h-5 sm:w-6 sm:h-6 text-[#2563eb] mt-1" />
                    </div>
                    <div>
                      <h3 className="text-base sm:text-lg md:text-xl font-bold text-gray-900 mb-1 sm:mb-2">{item.title}</h3>
                      <p className="text-sm sm:text-base text-gray-700 leading-relaxed">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-6 sm:space-y-8">
              <div className="bg-white p-5 sm:p-6 md:p-8 rounded-xl sm:rounded-2xl shadow-lg">
                <h3 className="text-xl sm:text-xl md:text-2xl font-bold text-gray-900 mb-3 sm:mb-4">فريق العمل</h3>
                <p className="text-sm sm:text-base text-gray-700 leading-relaxed mb-4 sm:mb-6">
                  يتكون فريقنا من مهندسين وفنيين معتمدين يتمتعون بخبرة واسعة في مجال صيانة الأجهزة المنزلية. كل عضو في
                  الفريق يخضع لتدريبات دورية على أحدث التقنيات والأساليب في مجال الصيانة.
                </p>
                <div className="space-y-3 sm:space-y-4">
                  <div className="flex items-center gap-2 sm:gap-3">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <Award className="w-5 h-5 sm:w-6 sm:h-6 text-[#2563eb]" />
                    </div>
                    <div>
                      <div className="text-sm sm:text-base font-semibold text-gray-900">مهندسون معتمدون</div>
                      <div className="text-xs sm:text-sm text-gray-600">شهادات معتمدة من الشركات المصنعة</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 sm:gap-3">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <Users className="w-5 h-5 sm:w-6 sm:h-6 text-[#2563eb]" />
                    </div>
                    <div>
                      <div className="text-sm sm:text-base font-semibold text-gray-900">فنيون محترفون</div>
                      <div className="text-xs sm:text-sm text-gray-600">خبرة تمتد لأكثر من 10 سنوات</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 sm:gap-3">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-[#2563eb]" />
                    </div>
                    <div>
                      <div className="text-sm sm:text-base font-semibold text-gray-900">تدريب مستمر</div>
                      <div className="text-xs sm:text-sm text-gray-600">دورات تدريبية دورية على أحدث التقنيات</div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-gradient-to-br from-[#2563eb] to-[#1d4ed8] text-white p-5 sm:p-6 md:p-8 rounded-xl sm:rounded-2xl shadow-lg">
                <h3 className="text-xl sm:text-xl md:text-2xl font-bold mb-3 sm:mb-4">خدمة العملاء</h3>
                <p className="text-sm sm:text-base text-blue-100 leading-relaxed mb-4 sm:mb-6">
                  فريق خدمة العملاء لدينا متاح على مدار الساعة للرد على استفساراتك وحجز مواعيد الصيانة
                </p>
                <Link
                  href="/contact"
                  prefetch={true}
                  className="inline-flex items-center gap-2 bg-white text-[#2563eb] px-5 sm:px-6 py-2.5 sm:py-3 rounded-full font-semibold hover:bg-blue-50 transition-colors text-sm sm:text-base"
                >
                  <Phone className="w-4 h-4 sm:w-5 sm:h-5" />
                  تواصل معنا الآن
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <TestimonialsSlider />

      {/* CTA Section */}
      <section className="py-10 sm:py-14 md:py-20 px-4 sm:px-6 bg-gradient-to-br from-[#2563eb] to-[#1d4ed8] text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4 sm:mb-6 leading-tight">هل أنت مستعد لتجربة خدمة صيانة احترافية؟</h2>
          <p className="text-base sm:text-lg md:text-xl text-blue-100 mb-6 sm:mb-8 leading-relaxed">
            انضم إلى آلاف العملاء الراضين عن خدماتنا واحصل على صيانة احترافية لأجهزتك المنزلية
          </p>
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center">
            <Link
              href="/contact"
              prefetch={true}
              className="inline-flex items-center justify-center gap-2 bg-white text-[#2563eb] px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold text-sm sm:text-base md:text-lg hover:bg-blue-50 transition-colors shadow-lg"
            >
              <Phone className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6" />
              احجز موعد الآن
            </Link>
            <Link
              href="/services"
              prefetch={true}
              className="inline-flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-bold text-sm sm:text-base md:text-lg hover:bg-white/20 transition-colors border-2 border-white"
            >
              تعرف على خدماتنا
            </Link>
          </div>
        </div>
      </section>
    </main>
  )
}
