import { CheckCircle, Phone, ArrowRight } from "lucide-react"
import Link from "next/link"
import { Metadata } from "next"

export const metadata: Metadata = {
  title: "شكراً لك",
  description: "شكراً لتسجيلك، سوف يتواصل معك فريق الصيانة الفورية قريباً",
  robots: {
    index: false,
    follow: false,
  },
}

export default function ThankYou() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-[#2563eb] to-[#1d4ed8] flex items-center justify-center px-6 py-16">
      <div className="max-w-2xl w-full bg-white rounded-2xl shadow-2xl p-8 md:p-12 text-center">
        {/* Success Icon */}
        <div className="flex justify-center mb-6">
          <div className="bg-green-100 rounded-full p-4">
            <CheckCircle className="w-16 h-16 text-green-600" />
          </div>
        </div>

        {/* Thank You Message */}
        <h1 className="text-4xl md:text-5xl font-bold text-[#2563eb] mb-4">
          شكراً لك
        </h1>
        <p className="text-xl md:text-2xl text-[#707070] mb-8 leading-relaxed">
          تم تسجيل طلبك بنجاح
        </p>
        <p className="text-lg text-[#707070] mb-12">
          سوف يتواصل معك فريق الصيانة الفورية قريباً
        </p>

        {/* Contact Information */}
        <div className="bg-[#F5F7FA] rounded-xl p-8 mb-8">
          <h2 className="text-2xl font-bold text-[#2563eb] mb-6">معلومات التواصل</h2>
          
          <div className="space-y-4">
            {/* Hotline */}
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <div className="flex items-center justify-center gap-3 mb-3">
                <Phone className="w-6 h-6 text-[#2563eb]" />
                <h3 className="text-lg font-bold text-[#2563eb]">الخط الساخن</h3>
              </div>
              <a
                href="tel:01110195560"
                className="text-3xl font-bold text-[#2563eb] hover:text-[#1d4ed8] transition-colors"
              >
                01110195560
              </a>
            </div>

            {/* Support Numbers */}
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <div className="flex items-center justify-center gap-3 mb-4">
                <Phone className="w-6 h-6 text-[#2563eb]" />
                <h3 className="text-lg font-bold text-[#2563eb]">الدعم الفني</h3>
              </div>
              <div className="space-y-2">
                <a
                  href="tel:01153625752"
                  className="block text-xl font-bold text-[#2563eb] hover:text-[#1d4ed8] transition-colors"
                >
                  01153625752
                </a>
                <a
                  href="tel:01016503001"
                  className="block text-xl font-bold text-[#2563eb] hover:text-[#1d4ed8] transition-colors"
                >
                  01016503001
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/"
            className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white px-8 py-4 rounded-full font-bold hover:shadow-lg transition-all hover:scale-105 flex items-center justify-center gap-2"
          >
            <ArrowRight className="w-5 h-5" />
            العودة للرئيسية
          </Link>
          <a
            href="tel:01110195560"
            className="border-2 border-[#2563eb] text-[#2563eb] px-8 py-4 rounded-full font-bold hover:bg-[#F5F7FA] transition-colors flex items-center justify-center gap-2"
          >
            <Phone className="w-5 h-5" />
            اتصل بنا الآن
          </a>
        </div>

        {/* Additional Info */}
        <p className="text-sm text-[#707070] mt-8">
          فريقنا متاح من 9 صباحاً إلى 9 مساءً يومياً
        </p>
      </div>
    </main>
  )
}



