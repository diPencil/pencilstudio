import type React from "react"
import type { Metadata } from "next"
import { Cairo } from "next/font/google"
import "./globals.css"
import GoogleTag from "@/components/google-tag"
import { ConditionalNavigation, ConditionalFooter } from "@/components/conditional-layout"
import ChatWidget from "@/components/chat-widget"
import HotlineBox from "@/components/hotline-box"
import ScrollToTop from "@/components/scroll-to-top"
import StructuredData from "@/components/structured-data"
import SearchModal from "@/components/search-modal"

const cairo = Cairo({ 
  subsets: ["arabic", "latin"],
  variable: "--font-cairo",
  display: "swap",
})

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://service-egy.com'
const googleVerification = process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION
const bingVerification = process.env.NEXT_PUBLIC_BING_SITE_VERIFICATION
const yahooVerification = process.env.NEXT_PUBLIC_YAHOO_SITE_VERIFICATION

const verification: Metadata["verification"] = {
  ...(googleVerification ? { google: googleVerification } : {}),
  ...(yahooVerification ? { yahoo: yahooVerification } : {}),
  ...(bingVerification
    ? { other: { "msvalidate.01": bingVerification } }
    : {}),
}

export const metadata: Metadata = {
  metadataBase: new URL(baseUrl),
  title: {
    default: "Service Egy - مركز صيانة معتمد لجميع الأجهزة المنزلية في مصر",
    template: "%s | Service Egy - صيانة معتمدة"
  },
  description: "Service Egy - مركز صيانة معتمد يقدم خدمات صيانة احترافية لجميع الأجهزة المنزلية: غسالات، ثلاجات، ميكروويف، مكيفات. فنيون معتمدون، قطع غيار أصلية، ضمان مكتوب. تغطية جميع محافظات مصر.",
  keywords: [
    "صيانة أجهزة منزلية",
    "صيانة غسالات",
    "صيانة ثلاجات",
    "صيانة ميكروويف",
    "صيانة مكيفات",
    "صيانة مصر",
    "فني صيانة معتمد",
    "Service Egy",
    "صيانة LG",
    "صيانة كريازي",
    "صيانة فريش",
    "صيانة يونيفرسال",
    "صيانة في المنزل"
  ],
  authors: [{ name: "Service Egy" }],
  creator: "Service Egy",
  publisher: "Service Egy",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  alternates: {
    canonical: "/",
  },
  openGraph: {
    type: "website",
    locale: "ar_EG",
    url: baseUrl,
    siteName: "Service Egy",
    title: "Service Egy - خدمات صيانة معتمدة لجميع الأجهزة المنزلية",
    description: "مركز صيانة معتمد يقدم خدمات صيانة احترافية لجميع الأجهزة المنزلية في مصر. فنيون معتمدون، قطع غيار أصلية، ضمان مكتوب.",
    images: [
      {
        url: `${baseUrl}/professional-technician-repairing-washing-machine.jpg`,
        width: 1200,
        height: 630,
        alt: "Service Egy - خدمات صيانة معتمدة",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
  title: "Service Egy - خدمات صيانة معتمدة",
    description: "مركز صيانة معتمد لجميع الأجهزة المنزلية في مصر. فنيون معتمدون، قطع غيار أصلية، ضمان مكتوب.",
    images: [`${baseUrl}/professional-technician-repairing-washing-machine.jpg`],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  ...(Object.keys(verification).length > 0 ? { verification } : {}),
  category: "خدمات صيانة",
  icons: {
    icon: '/سيرفس ايجي لوجوfavicon.svg',
    apple: '/سيرفس ايجي لوجوfavicon.svg',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ar" dir="rtl" className={cairo.variable}>
      <body className={`${cairo.className} font-sans`}>
        <GoogleTag />
        <StructuredData />
        <ScrollToTop />
        <ConditionalNavigation />
        {children}
        <ConditionalFooter />
        <HotlineBox />
        <ChatWidget />
        <SearchModal />
      </body>
    </html>
  )
}
