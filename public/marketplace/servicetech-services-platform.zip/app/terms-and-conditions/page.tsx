import { FileText, AlertTriangle, CheckCircle, Shield, Scale, Gavel } from "lucide-react"
import Link from "next/link"
import { Metadata } from "next"

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://service-egy.com'

export const metadata: Metadata = {
  title: "الشروط والأحكام",
  description: "الشروط والأحكام لاستخدام خدمات Service Egy - تعرف على حقوقك ومسؤولياتك عند استخدام خدماتنا.",
  keywords: [
    "الشروط والأحكام",
    "الشروط",
    "الأحكام",
    "Service Egy",
    "شروط الاستخدام"
  ],
  openGraph: {
    title: "الشروط والأحكام - Service Egy",
    description: "تعرف على الشروط والأحكام الخاصة باستخدام خدمات Service Egy",
    url: `${baseUrl}/terms-and-conditions`,
  },
  alternates: {
    canonical: "/terms-and-conditions",
  },
}

export default function TermsAndConditions() {
  return (
    <main className="min-h-screen bg-[#F5F7FA]">
      {/* Hero */}
      <section className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <Gavel className="w-12 h-12" />
            <h1 className="text-5xl font-bold">الشروط والأحكام</h1>
          </div>
          <p className="text-xl text-blue-100">شروط وأحكام استخدام خدمات Service Egy - شفافية ووضوح في كل اتفاقية</p>
          <p className="text-sm text-blue-200 mt-2">آخر تحديث: نوفمبر 2025</p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16 px-6">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Introduction */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h2 className="text-3xl font-bold text-[#2563eb] mb-4">مقدمة</h2>
            <p className="text-[#707070] leading-relaxed mb-4">
              مرحباً بك في <strong>Service Egy</strong>. هذه الشروط والأحكام تحكم استخدامك لموقعنا الإلكتروني 
              وخدماتنا. يرجى قراءة هذه الشروط بعناية قبل استخدام خدماتنا.
            </p>
            <p className="text-[#707070] leading-relaxed">
              باستخدام موقعنا الإلكتروني أو طلب خدماتنا، فإنك توافق على الالتزام بهذه الشروط والأحكام. 
              إذا كنت لا توافق على أي جزء من هذه الشروط، يرجى عدم استخدام خدماتنا.
            </p>
          </div>

          {/* Acceptance */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <div className="flex items-center gap-3 mb-6">
              <CheckCircle className="w-8 h-8 text-[#2563eb]" />
              <h2 className="text-3xl font-bold text-[#2563eb]">قبول الشروط</h2>
            </div>
            
            <div className="space-y-4">
              <p className="text-[#707070] leading-relaxed">
                بالوصول إلى موقعنا الإلكتروني أو استخدام خدماتنا، أنت تقر بأنك:
              </p>
              
              <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                <li>قد قرأت وفهمت هذه الشروط والأحكام</li>
                <li>توافق على الالتزام بجميع الأحكام الواردة هنا</li>
                <li>تتجاوز من العمر 18 عاماً أو لديك موافقة الوالدين/الوصي</li>
                <li>تمتلك السلطة القانونية للدخول في هذه الاتفاقية</li>
                <li>ستوفر معلومات دقيقة وصحيحة عند طلب الخدمات</li>
              </ul>
            </div>
          </div>

          {/* Services Description */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <div className="flex items-center gap-3 mb-6">
              <Shield className="w-8 h-8 text-[#2563eb]" />
              <h2 className="text-3xl font-bold text-[#2563eb]">وصف الخدمات</h2>
            </div>
            
            <div className="space-y-4">
              <p className="text-[#707070] leading-relaxed">
                <strong>Service Egy</strong> تقدم خدمات صيانة احترافية للأجهزة المنزلية في جميع محافظات مصر، بما في ذلك:
              </p>
              
              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>صيانة غسالات الملابس (أوتوماتيك وفوق أوتوماتيك)</li>
                  <li>صيانة الثلاجات والديب فريزر</li>
                  <li>صيانة غسالات الأطباق</li>
                  <li>صيانة الميكروويف</li>
                  <li>صيانة المجففات</li>
                  <li>صيانة مكيفات الهواء (للماركات المدعومة)</li>
                  <li>خدمات صيانة أخرى للأجهزة المنزلية</li>
                </ul>
              </div>

              <p className="text-[#707070] leading-relaxed">
                جميع خدماتنا تتم في منزلك بواسطة فنيين معتمدين ومتخصصين، باستخدام قطع غيار أصلية معتمدة.
              </p>
            </div>
          </div>

          {/* Booking and Appointments */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h2 className="text-3xl font-bold text-[#2563eb] mb-6">الحجز والمواعيد</h2>
            
            <div className="space-y-4">
              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <h3 className="text-lg font-bold text-[#2563eb] mb-3">1. طلب الخدمة</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>يمكنك طلب الخدمة عبر الخط الساخن (01110195560)، الدعم الفني، أو البريد الإلكتروني</li>
                  <li>يجب توفير معلومات دقيقة عن الجهاز والموقع والمشكلة</li>
                  <li>نحتفظ بالحق في رفض أي طلب إذا كان خارج نطاق خدماتنا</li>
                </ul>
              </div>

              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <h3 className="text-lg font-bold text-[#2563eb] mb-3">2. تحديد الموعد</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>نعمل على تحديد موعد مناسب لك خلال 24 ساعة من طلب الخدمة</li>
                  <li>مواعيد العمل: من 9 صباحاً إلى 9 مساءً يومياً</li>
                  <li>يجب إشعارنا قبل 24 ساعة على الأقل لإلغاء أو تغيير الموعد</li>
                  <li>في حالة عدم الحضور دون إشعار، قد يتم تطبيق رسوم</li>
                </ul>
              </div>

              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <h3 className="text-lg font-bold text-[#2563eb] mb-3">3. الاستجابة</h3>
                <p className="text-[#707070] leading-relaxed">
                  نلتزم بالاستجابة لطلبات الصيانة خلال 24 ساعة. قد تختلف أوقات الاستجابة حسب:
                </p>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4 mt-2">
                  <li>المسافة من موقعنا</li>
                  <li>حجم الطلب وتعقيده</li>
                  <li>الظروف الجوية والطوارئ</li>
                  <li>حجم الطلبات في الفترة المحددة</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Pricing and Payment */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h2 className="text-3xl font-bold text-[#2563eb] mb-6">التسعير والدفع</h2>
            
            <div className="space-y-4">
              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <h3 className="text-lg font-bold text-[#2563eb] mb-3">1. الأسعار</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>الأسعار تعتمد على نوع الجهاز وطبيعة العطل</li>
                  <li>سيتم إعلامك بالتكلفة التقديرية قبل بدء العمل</li>
                  <li>جميع الأسعار بالجنيه المصري وتشمل ضريبة القيمة المضافة إن وجدت</li>
                  <li>الأسعار قابلة للتغيير دون إشعار مسبق، لكن لا تنطبق على الطلبات المكتملة</li>
                </ul>
              </div>

              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <h3 className="text-lg font-bold text-[#2563eb] mb-3">2. طرق الدفع</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>الدفع النقدي عند إتمام الخدمة (الطريقة المفضلة)</li>
                  <li>التحويل البنكي (للمشاريع الكبيرة)</li>
                  <li>الدفع الإلكتروني (عند توفر الخدمة)</li>
                </ul>
              </div>

              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <h3 className="text-lg font-bold text-[#2563eb] mb-3">3. الفواتير</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>نقدم فواتير رسمية لجميع الخدمات المدفوعة</li>
                  <li>الفواتير تشمل تفاصيل العمل المنجز وقطع الغيار المستخدمة</li>
                  <li>يجب الاحتفاظ بالفاتورة لإثبات الضمان</li>
                </ul>
              </div>

              <div className="bg-yellow-50 border-r-4 border-yellow-400 p-4 rounded">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-yellow-800">
                    <strong>ملاحظة:</strong> الدفع يجب أن يتم بالكامل قبل تسليم الجهاز. 
                    لن يتم تسليم الجهاز حتى يتم استلام الدفع الكامل.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Warranty */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h2 className="text-3xl font-bold text-[#2563eb] mb-6">الضمان</h2>
            
            <div className="space-y-4">
              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <h3 className="text-lg font-bold text-[#2563eb] mb-3">1. ضمان العمل</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>نقدم ضمان مكتوب على جميع أعمال الصيانة</li>
                  <li>مدة الضمان تختلف حسب نوع العمل والجهاز (عادة 3-12 شهر)</li>
                  <li>الضمان يغطي نفس العطل الذي تم إصلاحه</li>
                  <li>يجب إبلاغنا فوراً في حالة تكرار العطل</li>
                </ul>
              </div>

              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <h3 className="text-lg font-bold text-[#2563eb] mb-3">2. ضمان قطع الغيار</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>جميع قطع الغيار المستخدمة أصلية 100% ومعتمدة</li>
                  <li>قطع الغيار لها ضمان منفصل من المصنع</li>
                  <li>مدة ضمان قطع الغيار تختلف حسب نوع القطعة</li>
                </ul>
              </div>

              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <h3 className="text-lg font-bold text-[#2563eb] mb-3">3. شروط الضمان</h3>
                <p className="text-[#707070] leading-relaxed mb-2">الضمان لا يغطي:</p>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>الأعطال الناتجة عن سوء الاستخدام أو الإهمال</li>
                  <li>الأعطال الناتجة عن محاولات إصلاح غير معتمدة</li>
                  <li>الأعطال الناتجة عن الكوارث الطبيعية أو الحوادث</li>
                  <li>الأعطال في أجزاء أخرى لم يتم إصلاحها</li>
                  <li>الأعطال الناتجة عن عدم اتباع تعليمات الاستخدام</li>
                </ul>
              </div>

              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <h3 className="text-lg font-bold text-[#2563eb] mb-3">4. خدمة الضمان</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>في حالة تكرار العطل خلال فترة الضمان، نقدم خدمة إصلاح مجانية</li>
                  <li>إذا استمرت المشكلة، قد نستبدل القطعة المعيبة</li>
                  <li>يجب تقديم الفاتورة الأصلية عند المطالبة بالضمان</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Customer Responsibilities */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h2 className="text-3xl font-bold text-[#2563eb] mb-6">مسؤوليات العميل</h2>
            
            <div className="space-y-4">
              <p className="text-[#707070] leading-relaxed">
                أنت مسؤول عن:
              </p>
              
              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>توفير معلومات دقيقة وصحيحة عن الجهاز والمشكلة</li>
                  <li>ضمان وصول الفني إلى موقع الجهاز بسهولة</li>
                  <li>توفير بيئة آمنة ومناسبة للعمل</li>
                  <li>إبلاغنا بأي تغييرات في العنوان أو الموعد</li>
                  <li>حماية ممتلكاتك الشخصية أثناء قيام الفني بالعمل</li>
                  <li>الدفع في الوقت المحدد</li>
                  <li>الاحتفاظ بالفاتورة وإثبات الضمان</li>
                  <li>إبلاغنا فوراً في حالة وجود أي مشاكل بعد الصيانة</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Our Responsibilities */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h2 className="text-3xl font-bold text-[#2563eb] mb-6">مسؤولياتنا</h2>
            
            <div className="space-y-4">
              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>تقديم خدمة صيانة احترافية ومتخصصة</li>
                  <li>إرسال فنيين معتمدين ومؤهلين</li>
                  <li>استخدام قطع غيار أصلية 100%</li>
                  <li>الالتزام بالمواعيد المحددة</li>
                  <li>تقديم ضمان مكتوب على جميع الأعمال</li>
                  <li>الحفاظ على نظافة مكان العمل</li>
                  <li>معاملة العملاء باحترافية وأدب</li>
                  <li>التواصل الشفاف حول التكلفة والوقت المتوقع</li>
                  <li>متابعة الخدمة بعد الإصلاح</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Limitation of Liability */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h2 className="text-3xl font-bold text-[#2563eb] mb-6">حدود المسؤولية</h2>
            
            <div className="space-y-4">
              <div className="bg-yellow-50 border-r-4 border-yellow-400 p-4 rounded">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="mb-2">
                      <strong>تنبيه مهم:</strong> في حدود ما يسمح به القانون، لن نكون مسؤولين عن:
                    </p>
                    <ul className="list-disc list-inside space-y-1 mr-4">
                      <li>أي أضرار غير مباشرة أو تبعية ناتجة عن استخدام خدماتنا</li>
                      <li>فقدان البيانات أو المعلومات المخزنة على الأجهزة</li>
                      <li>أي أضرار ناتجة عن تأخير في تقديم الخدمة</li>
                      <li>أي أضرار ناتجة عن استخدام قطع غيار غير أصلية (إذا طلبها العميل)</li>
                    </ul>
                  </div>
                </div>
              </div>

              <p className="text-[#707070] leading-relaxed">
                مسؤوليتنا محدودة بقيمة العمل المنجز. في حالة وجود أي مشكلة، سنعمل على حلها 
                في إطار الضمان المقدم.
              </p>
            </div>
          </div>

          {/* Cancellation and Refund */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h2 className="text-3xl font-bold text-[#2563eb] mb-6">الإلغاء والاسترداد</h2>
            
            <div className="space-y-4">
              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <h3 className="text-lg font-bold text-[#2563eb] mb-3">1. إلغاء من طرفنا</h3>
                <p className="text-[#707070] leading-relaxed">
                  نحتفظ بالحق في رفض أو إلغاء أي طلب في الحالات التالية:
                </p>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4 mt-2">
                  <li>إذا كان الجهاز خارج نطاق خدماتنا</li>
                  <li>إذا كانت هناك مشاكل أمنية أو قانونية</li>
                  <li>إذا كان العميل غير متعاون أو غير محترم</li>
                  <li>في حالة الظروف القاهرة (كوارث طبيعية، إضرابات، إلخ)</li>
                </ul>
              </div>

              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <h3 className="text-lg font-bold text-[#2563eb] mb-3">2. إلغاء من طرف العميل</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>يمكنك إلغاء الطلب قبل 24 ساعة من الموعد بدون رسوم</li>
                  <li>الإلغاء خلال أقل من 24 ساعة قد يترتب عليه رسوم</li>
                  <li>بعد وصول الفني، لا يمكن الإلغاء إلا في حالات استثنائية</li>
                </ul>
              </div>

              <div className="bg-[#F5F7FA] p-6 rounded-lg">
                <h3 className="text-lg font-bold text-[#2563eb] mb-3">3. الاسترداد</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
                  <li>لا يمكن استرداد المبلغ بعد إتمام العمل</li>
                  <li>في حالة عدم إتمام العمل لأسباب خارجة عن إرادتنا، سنعيد المبلغ المدفوع</li>
                  <li>الاسترداد يتم خلال 5-10 أيام عمل</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Intellectual Property */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h2 className="text-3xl font-bold text-[#2563eb] mb-6">الملكية الفكرية</h2>
            
            <div className="space-y-4">
              <p className="text-[#707070] leading-relaxed">
                جميع محتويات موقعنا الإلكتروني، بما في ذلك النصوص والصور والتصاميم والشعارات، 
                محمية بحقوق الطبع والنشر والملكية الفكرية لـ <strong>Service Egy</strong>.
              </p>
              
              <p className="text-[#707070] leading-relaxed">
                لا يجوز لك نسخ أو إعادة إنتاج أو توزيع أو استخدام أي جزء من محتوى الموقع 
                دون الحصول على إذن كتابي منا.
              </p>
            </div>
          </div>

          {/* Disputes */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h2 className="text-3xl font-bold text-[#2563eb] mb-6">حل النزاعات</h2>
            
            <div className="space-y-4">
              <p className="text-[#707070] leading-relaxed mb-4">
                في حالة وجود أي نزاع أو خلاف، نلتزم بالحل الودي أولاً من خلال:
              </p>
              
              <ol className="list-decimal list-inside space-y-2 text-[#707070] mr-4">
                <li>التواصل المباشر مع فريق خدمة العملاء</li>
                <li>تقديم شكوى رسمية عبر البريد الإلكتروني</li>
                <li>اللجوء إلى الوساطة إذا لزم الأمر</li>
              </ol>

              <p className="text-[#707070] leading-relaxed mt-4">
                في حالة عدم التوصل إلى حل، سيتم التحكيم أو الفصل في النزاع وفقاً لقوانين 
                جمهورية مصر العربية، وتكون المحاكم المصرية هي المختصة.
              </p>
            </div>
          </div>

          {/* Changes to Terms */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h2 className="text-3xl font-bold text-[#2563eb] mb-6">تغييرات على الشروط</h2>
            
            <p className="text-[#707070] leading-relaxed mb-4">
              نحتفظ بالحق في تحديث أو تعديل هذه الشروط والأحكام في أي وقت. 
              سنخطرك بأي تغييرات جوهرية من خلال:
            </p>
            
            <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4">
              <li>نشر الإشعار على موقعنا الإلكتروني</li>
              <li>إرسال إشعار عبر البريد الإلكتروني</li>
              <li>تحديث تاريخ "آخر تحديث" في أعلى هذه الصفحة</li>
            </ul>

            <p className="text-[#707070] leading-relaxed mt-4">
              استمرار استخدامك لخدماتنا بعد التغييرات يعني موافقتك على الشروط المحدثة.
            </p>
          </div>

          {/* Contact */}
          <div className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white p-8 rounded-xl">
            <h2 className="text-3xl font-bold mb-6">تواصل معنا</h2>
            
            <p className="text-blue-100 leading-relaxed mb-6">
              إذا كان لديك أي أسئلة حول هذه الشروط والأحكام، يرجى التواصل معنا:
            </p>

            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5" />
                <div>
                  <p className="font-semibold">البريد الإلكتروني:</p>
                  <a href="mailto:info@service-egy.com" className="text-blue-100 hover:text-white underline">
                    info@service-egy.com
                  </a>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5" />
                <div>
                  <p className="font-semibold">الخط الساخن:</p>
                  <a href="tel:01110195560" className="text-blue-100 hover:text-white underline">
                    01110195560
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}



