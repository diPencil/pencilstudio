"use client"

import Link from "next/link"
import { AlertCircle } from "lucide-react"

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  return (
    <html lang="ar" dir="rtl">
      <body className="flex min-h-screen items-center justify-center bg-linear-to-br from-slate-50 to-blue-50 p-6 text-slate-900">
        <div className="w-full max-w-md rounded-2xl bg-white p-8 text-center shadow-2xl shadow-blue-100/60">
          <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-red-100 text-red-600">
            <AlertCircle className="h-8 w-8" />
          </div>
          <h1 className="mb-3 text-2xl font-bold">حدث خطأ غير متوقع</h1>
          <p className="mb-6 text-sm text-slate-600">
            واجهنا مشكلة أثناء تحميل الصفحة. يرجى المحاولة مرة أخرى، وإذا استمرت المشكلة يرجى التواصل معنا.
          </p>
          <div className="flex flex-col gap-3">
            <button
              onClick={() => reset()}
              className="rounded-xl bg-[#2563eb] px-4 py-2 text-sm font-semibold text-white shadow transition hover:bg-[#1d4ed8]"
            >
              إعادة المحاولة
            </button>
            <Link
              href="/"
              className="rounded-xl border border-[#2563eb] px-4 py-2 text-sm font-semibold text-[#2563eb] transition hover:bg-blue-50"
            >
              العودة للرئيسية
            </Link>
          </div>
          <pre className="mt-6 overflow-x-auto rounded-lg bg-slate-100 p-3 text-right text-xs text-slate-600">
            {error?.message ?? "No message"}
          </pre>
        </div>
      </body>
    </html>
  )
}



