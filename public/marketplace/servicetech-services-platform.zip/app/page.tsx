import {
  Phone,
  Mail,
  Zap,
  Users,
  Award,
  Truck,
  ArrowLeft,
  Play,
  Shield,
  CheckCircle,
  Clock,
  Star,
  Target,
  TrendingUp,
  Wrench,
  BookOpen,
  HeartHandshake,
} from "lucide-react"
import Link from "next/link"
import { Metadata } from "next"
import type { ElementType } from "react"

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "https://service-egy.com"

export const metadata: Metadata = {
  title: "الصفحة الرئيسية",
  description:
    "Service Egy - مركز صيانة معتمد يقدم خدمات صيانة احترافية لجميع الأجهزة المنزلية في مصر. غسالات، ثلاجات، ميكروويف، مكيفات. فنيون معتمدون، قطع غيار أصلية، ضمان مكتوب. تغطية جميع محافظات مصر.",
  openGraph: {
    title: "Service Egy - خدمات صيانة معتمدة لجميع الأجهزة المنزلية",
    description: "مركز صيانة معتمد يقدم خدمات صيانة احترافية لجميع الأجهزة المنزلية في مصر",
    url: baseUrl,
    images: [
      {
        url: `${baseUrl}/professional-technician-repairing-washing-machine.jpg`,
        width: 1200,
        height: 630,
        alt: "Service Egy - خدمات صيانة معتمدة لجميع الأجهزة المنزلية",
      },
    ],
  },
  alternates: {
    canonical: "/",
  },
  twitter: {
    card: "summary_large_image",
    title: "Service Egy - خدمات صيانة معتمدة",
    description:
      "مركز صيانة معتمد لجميع الأجهزة المنزلية في مصر. فنيون معتمدون، قطع غيار أصلية، ضمان مكتوب.",
    images: [`${baseUrl}/professional-technician-repairing-washing-machine.jpg`],
  },
}

type Feature = {
  icon: ElementType
  title: string
  description: string
}

type ServiceCard = {
  href: string
  title: string
  description: string
}

type BrandCard = {
  slug: string
  name: string
  description: string
  image: string
}

type ReasonCard = {
  icon: ElementType
  title: string
  paragraphs: string[]
}

type FAQItem = {
  question: string
  answer: string
}

type GuaranteeCard = {
  icon: ElementType
  title: string
  description: string
}

type ContactOption = {
  icon: ElementType
  label: string
  value: string
  href: string
  primary?: boolean
}

type Testimonial = {
  quote: string
  name: string
  location: string
}

const featureCards: Feature[] = [
  { icon: Zap, title: "استجابة فورية", description: "خلال 24 ساعة" },
  { icon: Users, title: "فنيون معتمدون", description: "مدربون ومتخصصون" },
  { icon: Award, title: "ضمان مكتوب", description: "على كل خدمة" },
  { icon: Truck, title: "تغطية كاملة", description: "جميع محافظات مصر" },
]

const mainServices: ServiceCard[] = [
  { href: "/services/washing-machines", title: "صيانة غسالات الملابس", description: "صيانة شاملة لجميع الأنواع" },
  { href: "/services/refrigerators", title: "صيانة الثلاجات والديب فريزر", description: "إصلاح أعطال التبريد والتجميد" },
  { href: "/services/dishwashers", title: "صيانة غسالات الأطباق", description: "فحص شامل وإصلاح دقيق" },
  { href: "/services/microwaves", title: "صيانة الميكروويف", description: "فحص وإصلاح احترافي" },
  { href: "/services/dryers", title: "صيانة المجففات", description: "صيانة متخصصة وموثوقة" },
]

const brandCards: BrandCard[] = [
  {
    slug: "lg",
    name: "LG",
    description: "متخصصون في صيانة أجهزة LG بجميع أنواعها",
    image: "/maintenancecenter/lg-appliances-brand-logo.jpg",
  },
  {
    slug: "kiriazi",
    name: "كريازي",
    description: "خدمات متخصصة لأجهزة كريازي المصرية",
    image: "/maintenancecenter/kiriazi-appliances-egyptian-brand.jpg",
  },
  {
    slug: "universal",
    name: "يونيفرسال",
    description: "فنيون معتمدون لصيانة أجهزة يونيفرسال",
    image: "/maintenancecenter/universal-appliances-brand.jpg",
  },
  {
    slug: "fresh",
    name: "فريش",
    description: "متخصصون في صيانة أجهزة فريش المصرية",
    image: "/maintenancecenter/fresh-appliances-egyptian-brand.jpg",
  },
  {
    slug: "gree",
    name: "جري",
    description: "خدمات متخصصة لأجهزة التكييف والتبريد جري",
    image: "/maintenancecenter/gree-air-conditioning-brand.jpg",
  },
  {
    slug: "carrier",
    name: "كاريير",
    description: "متخصصون في صيانة مكيفات كاريير",
    image: "/maintenancecenter/carrier-air-conditioning-brand.jpg",
  },
]

const premiumReasons: ReasonCard[] = [
  {
    icon: Star,
    title: "خبرة تمتد لأكثر من 15 عاماً",
    paragraphs: [
      "منذ تأسيسنا، قمنا بخدمة آلاف العملاء في جميع أنحاء مصر. خبرتنا الطويلة في مجال صيانة الأجهزة المنزلية جعلتنا نفهم احتياجات عملائنا بعمق ونقدم حلولاً فعالة لكل مشكلة مهما كانت معقدة.",
      "تعاملنا مع أكثر من 50,000 جهاز منزلي من مختلف الماركات والموديلات، مما أكسبنا معرفة شاملة بكل التفاصيل الفنية والأعطال الشائعة وطرق إصلاحها بكفاءة عالية. هذه الخبرة المتراكمة تضمن لك الحصول على خدمة احترافية من أول مرة.",
    ],
  },
  {
    icon: Users,
    title: "فريق من الفنيين المعتمدين",
    paragraphs: [
      "نفخر بامتلاكنا لفريق من أمهر الفنيين المدربين والحاصلين على شهادات معتمدة من كبرى الشركات المصنعة للأجهزة المنزلية. كل فني في فريقنا يخضع لبرامج تدريبية مستمرة لمواكبة أحدث التقنيات والتطورات في عالم الأجهزة المنزلية.",
      "فنيونا ليسوا مجرد عمال صيانة، بل متخصصون يفهمون كل تفصيلة في الأجهزة التي يعملون عليها. يتمتعون بمهارات تشخيص دقيقة تمكنهم من تحديد المشكلة بسرعة وإصلاحها بكفاءة، مع الحرص على شرح المشكلة للعميل بطريقة واضحة ومفهومة.",
    ],
  },
  {
    icon: Target,
    title: "التزامنا بالجودة والدقة",
    paragraphs: [
      "الجودة ليست مجرد شعار نرفعه، بل هي منهج عمل نلتزم به في كل خطوة. نستخدم فقط قطع الغيار الأصلية المعتمدة من الشركات المصنعة، ونرفض استخدام أي قطع تقليد أو غير أصلية مهما كانت الظروف. هذا الالتزام يضمن لك أداءً مثالياً وعمراً أطول لأجهزتك.",
      "نتبع معايير صارمة في كل عملية صيانة، بدءاً من الفحص الأولي الشامل، مروراً بالتشخيص الدقيق، وصولاً إلى الإصلاح والاختبار النهائي. لا نسلم الجهاز للعميل إلا بعد التأكد من عمله بكفاءة 100% وإجراء اختبارات شاملة لضمان عدم تكرار المشكلة.",
    ],
  },
  {
    icon: TrendingUp,
    title: "تقنيات حديثة وأدوات متطورة",
    paragraphs: [
      "نستثمر باستمرار في أحدث أجهزة التشخيص والأدوات المتخصصة التي تمكننا من تقديم خدمة بمستوى عالمي. نمتلك أجهزة فحص إلكترونية متقدمة، أدوات قياس دقيقة، ومعدات متخصصة لكل نوع من الأجهزة المنزلية.",
      "هذه التقنيات الحديثة تساعدنا على تشخيص الأعطال بدقة متناهية في وقت قياسي، مما يوفر عليك الوقت والمال. كما أننا نستخدم برامج متخصصة لتوثيق كل عملية صيانة وحفظ سجل كامل لكل جهاز، مما يساعدنا على تقديم خدمة أفضل في المستقبل.",
    ],
  },
  {
    icon: Wrench,
    title: "منهجية عمل احترافية ومنظمة",
    paragraphs: [
      "نتبع منهجية عمل واضحة ومنظمة في كل عملية صيانة. تبدأ الخدمة باستقبال طلبك وتحديد موعد مناسب لك، ثم يصل الفني في الموعد المحدد بدقة مع كل الأدوات والمعدات اللازمة. يقوم بفحص شامل للجهاز وتشخيص المشكلة، ثم يشرح لك الحالة والحلول المتاحة بشفافية تامة.",
      "بعد موافقتك، يبدأ العمل على الإصلاح باستخدام قطع الغيار الأصلية، ثم يجري اختبارات شاملة للتأكد من حل المشكلة. في النهاية، تحصل على شهادة ضمان مكتوبة ونصائح للحفاظ على جهازك. نتابع معك بعد الصيانة للتأكد من رضاك التام.",
    ],
  },
  {
    icon: HeartHandshake,
    title: "رضا العملاء هو أولويتنا القصوى",
    paragraphs: [
      "نؤمن بأن نجاحنا يقاس برضا عملائنا. لذلك، نضع احتياجاتك وراحتك في مقدمة أولوياتنا. نحرص على التواصل الواضح والشفاف معك في كل مرحلة، ونحترم وقتك ومنزلك. فنيونا مدربون على التعامل بأدب واحترافية، والحفاظ على نظافة مكان العمل.",
      "نستمع لملاحظاتك واقتراحاتك بعناية ونعمل على تحسين خدماتنا باستمرار. لدينا فريق خدمة عملاء متاح للرد على استفساراتك ومتابعة طلباتك. رضاك التام هو هدفنا، ولن نتوقف حتى نحققه. هذا ما جعل آلاف العملاء يثقون بنا ويوصون بخدماتنا لأصدقائهم وعائلاتهم.",
    ],
  },
]

const faqItems: FAQItem[] = [
  {
    question: "هل الصيانة تتم في المنزل؟",
    answer: "نعم، جميع خدماتنا تتم في منزلك. نأتي إليك بأحدث أجهزة التشخيص والأدوات اللازمة.",
  },
  {
    question: "هل تستخدمون قطع غيار أصلية؟",
    answer: "نعم، نستخدم قطع غيار أصلية 100% معتمدة من المصنعين الأصليين فقط.",
  },
  {
    question: "هل هناك ضمان بعد الصيانة؟",
    answer: "نعم، نقدم ضمان مكتوب على كل خدمة وقطعة، مع متابعة دورية لضمان الأداء.",
  },
  {
    question: "ما مدة الاستجابة؟",
    answer: "نستجيب لطلبات الصيانة خلال 24 ساعة من تقديم الطلب.",
  },
]

const guaranteeCards: GuaranteeCard[] = [
  { icon: Shield, title: "شهادة ضمان معتمدة", description: "على الخدمة والقطع المستخدمة" },
  { icon: CheckCircle, title: "متابعة دورية", description: "للتأكد من استمرار الأداء" },
  { icon: Clock, title: "خدمة مجانية", description: "في حالة تكرار العطل" },
  { icon: Phone, title: "دعم فني متاح", description: "من 9 صباحاً إلى 9 مساءً" },
]

const contactOptions: ContactOption[] = [
  { icon: Phone, label: "الخط الساخن", value: "01110195560", href: "tel:01110195560", primary: true },
  { icon: Mail, label: "البريد الإلكتروني", value: "info@service-egy.com", href: "mailto:info@service-egy.com" },
]

const testimonials: Testimonial[] = [
  {
    quote:
      "خدمة ممتازة وسريعة جداً! الفني وصل في الموعد المحدد بالضبط وكان محترف للغاية. أصلح الثلاجة في أقل من ساعة وشرح لي المشكلة بالتفصيل. السعر كان معقول جداً والضمان مكتوب. أنصح بالتعامل معهم بشدة!",
    name: "أحمد محمد السيد",
    location: "القاهرة - مدينة نصر",
  },
  {
    quote:
      "تعاملت مع Service Egy أكثر من 3 مرات وفي كل مرة الخدمة تكون ممتازة. آخر مرة صلحوا الغسالة والمكيف، والاتنين شغالين زي الفل. الأسعار معقولة والضمان حقيقي مش كلام. فريق محترم ومحترف.",
    name: "فاطمة حسن إبراهيم",
    location: "الإسكندرية - سموحة",
  },
  {
    quote:
      "صيانة احترافية بكل المقاييس! الفني كان خبير وشرح لي المشكلة في الديب فريزر بالتفصيل قبل ما يبدأ الشغل. استخدم قطع غيار أصلية وأعطاني ضمان مكتوب. السعر كان أقل من اللي كنت متوقعه. شكراً Service Egy!",
    name: "محمود علي أحمد",
    location: "الجيزة - المهندسين",
  },
]

export default function Home() {
  return (
    <main className="min-h-screen">
      <HeroSection />
      <FeaturesSection />
      <MainServicesSection />
      <BrandsSection />
      <ReasonsSection />
      <CommitmentBanner />
      <FAQSection />
      <GuaranteeSection />
      <ContactSection />
      <TestimonialsSection />
    </main>
  )
}

function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-white py-12 md:py-20 px-6">
      <HeroDecorations />
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-center">
          <div className="animate-fade-in">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance leading-tight">
              <span className="text-[#2563eb]">صيانة موثوقة</span>
              <br />
              <span className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] bg-clip-text text-transparent">
                لكل أجهزتك المنزلية
              </span>
            </h1>
            <p className="text-lg md:text-xl text-[#707070] mb-8 leading-relaxed max-w-lg">
              Service Egy توفر خدمات صيانة احترافية معتمدة لجميع الأجهزة المنزلية بضمان مكتوب وفنيين متخصصين في جميع
              محافظات مصر
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <Link
                href="/contact"
                prefetch
                className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white px-8 py-4 rounded-full font-bold hover:shadow-lg transition-all hover:scale-105 text-center"
              >
                اطلب الخدمة الآن
              </Link>
              <Link
                href="/services"
                prefetch
                className="border-2 border-[#2563eb] text-[#2563eb] px-8 py-4 rounded-full font-bold hover:bg-[#F5F7FA] transition-all flex items-center justify-center gap-2"
              >
                <Play className="w-5 h-5" />
                شاهد خدماتنا
              </Link>
            </div>
            <div className="flex items-center gap-4 text-sm md:text-base">
              <div className="flex -space-x-2">
                {[
                  { src: "/happy-egyptian-male-customer-smiling.jpg", alt: "عميل راضي" },
                  { src: "/satisfied-egyptian-female-customer.jpg", alt: "عميلة راضية" },
                  { src: "/happy-middle-aged-egyptian-man.jpg", alt: "عميل سعيد" },
                  { src: "/smiling-egyptian-woman-customer.jpg", alt: "عميلة سعيدة" },
                ].map((image) => (
                  <img
                    key={image.src}
                    src={image.src}
                    alt={image.alt}
                    className="w-10 h-10 rounded-full border-2 border-white object-cover"
                  />
                ))}
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#2563eb] to-[#3b82f6] flex items-center justify-center text-white font-bold border-2 border-white text-xs">
                  +500
                </div>
              </div>
              <span className="text-[#707070]">
                <strong className="text-[#2563eb]">500+</strong> عميل راضي عن خدماتنا
              </span>
            </div>
          </div>
          <div className="relative h-96 md:h-full min-h-96 animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="absolute w-80 h-80 md:w-96 md:h-96 rounded-full border-4 border-dashed border-[#2563eb] opacity-20" />
              <div className="relative w-72 h-72 md:w-80 md:h-80 rounded-full overflow-hidden shadow-2xl bg-gradient-to-br from-[#2563eb] to-[#3b82f6] flex items-center justify-center">
                <img
                  src="/professional-technician-repairing-washing-machine.jpg"
                  alt="فني صيانة محترف"
                  className="w-full h-full object-cover"
                />
              </div>
              <div
                className="absolute top-8 right-8 w-16 h-16 bg-[#F5F7FA] rounded-lg shadow-lg flex items-center justify-center animate-bounce"
                style={{ animationDelay: "0s" }}
              >
                <Zap className="w-8 h-8 text-[#2563eb]" />
              </div>
              <div
                className="absolute bottom-12 left-8 w-14 h-14 bg-gradient-to-br from-[#2563eb] to-[#3b82f6] rounded-full shadow-lg flex items-center justify-center animate-bounce"
                style={{ animationDelay: "0.2s" }}
              >
                <Award className="w-7 h-7 text-white" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

function HeroDecorations() {
  return (
    <>
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-blue-100 to-blue-50 rounded-full blur-3xl opacity-60 animate-blob" />
      <div className="absolute top-20 right-40 w-72 h-72 bg-gradient-to-br from-blue-200 to-transparent rounded-full blur-2xl opacity-40 animate-blob animation-delay-2000" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-blue-100 to-blue-50 rounded-full blur-3xl opacity-60 animate-blob animation-delay-4000" />
      <div className="absolute bottom-20 left-40 w-80 h-80 bg-gradient-to-tr from-blue-200 to-transparent rounded-full blur-2xl opacity-40 animate-blob animation-delay-6000" />
      <div className="absolute top-1/4 right-1/4 w-4 h-4 bg-[#2563eb] rounded-full opacity-20 animate-float" />
      <div className="absolute top-1/3 right-1/3 w-3 h-3 bg-[#3b82f6] rounded-full opacity-30 animate-float animation-delay-1000" />
      <div className="absolute bottom-1/4 left-1/4 w-5 h-5 bg-[#2563eb] rounded-full opacity-20 animate-float animation-delay-2000" />
      <div className="absolute bottom-1/3 left-1/3 w-3 h-3 bg-[#3b82f6] rounded-full opacity-30 animate-float animation-delay-3000" />
      <div className="absolute top-1/2 right-1/5 w-4 h-4 bg-[#2563eb] rounded-full opacity-25 animate-float animation-delay-4000" />
      <div className="absolute top-2/3 left-1/5 w-3 h-3 bg-[#3b82f6] rounded-full opacity-20 animate-float animation-delay-5000" />
      <div className="absolute top-1/4 left-1/4 w-8 h-8 border-2 border-[#2563eb] opacity-10 animate-spin-slow" />
      <div className="absolute bottom-1/3 right-1/3 w-6 h-6 border-2 border-[#3b82f6] opacity-15 animate-spin-slow animation-delay-3000" />
    </>
  )
}

function FeaturesSection() {
  return (
    <section className="py-16 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold text-[#2563eb] text-center mb-12">لماذا Service Egy؟</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {featureCards.map((feature) => {
            const Icon = feature.icon
            return (
              <div key={feature.title} className="bg-[#F5F7FA] p-6 rounded-xl text-center hover:shadow-lg transition-shadow">
                <div className="bg-[#2563eb] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-[#2563eb] mb-2">{feature.title}</h3>
                <p className="text-[#707070]">{feature.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}

function MainServicesSection() {
  return (
    <section className="py-16 px-6 bg-[#F5F7FA]">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold text-[#2563eb] text-center mb-12">خدماتنا الرئيسية</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {mainServices.map((service) => (
            <div key={service.href} className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-bold text-[#2563eb] mb-2">{service.title}</h3>
              <p className="text-[#707070] mb-4">{service.description}</p>
              <Link
                href={service.href}
                prefetch
                className="inline-block bg-[#2563eb] text-white px-6 py-2 rounded-full font-semibold hover:bg-[#1d4ed8] transition-colors"
              >
                اعرف تفاصيل الخدمة
              </Link>
            </div>
          ))}
          <Link
            href="/services"
            prefetch
            className="bg-[#2563eb] text-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all hover:bg-[#1d4ed8] flex flex-col items-center justify-center text-center"
          >
            <ArrowLeft className="w-12 h-12 mb-4" />
            <h3 className="text-xl font-bold mb-2">اعرف أكثر عن الخدمات</h3>
            <p className="text-blue-100">اكتشف جميع خدماتنا بالتفصيل</p>
          </Link>
        </div>
      </div>
    </section>
  )
}

function BrandsSection() {
  return (
    <section className="py-16 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-[#2563eb] mb-4">مراكز الصيانة والخدمة</h2>
          <p className="text-xl text-[#707070]">شبكة مراكز معتمدة لخدمة أهم العلامات العالمية والمصرية داخل مصر</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {brandCards.map((brand) => (
            <Link key={brand.slug} href={`/maintenance-center/${brand.slug}-repair`} prefetch className="group text-right">
              <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <div className="h-48 bg-gradient-to-br from-[#2563eb] to-[#3b82f6] overflow-hidden">
                  <img
                    src={brand.image}
                    alt={brand.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold text-[#2563eb] mb-2">{brand.name}</h3>
                  <p className="text-[#707070] text-sm leading-relaxed">{brand.description}</p>
                  <div className="mt-4 text-[#2563eb] font-semibold group-hover:translate-x-2 transition-transform">
                    اعرف المزيد ←
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
        <div className="text-center">
          <Link
            href="/maintenance-center"
            prefetch
            className="inline-block bg-[#2563eb] text-white px-8 py-4 rounded-full font-bold hover:bg-[#1d4ed8] transition-colors"
          >
            عرض جميع الماركات
          </Link>
        </div>
      </div>
    </section>
  )
}

function ReasonsSection() {
  return (
    <section className="py-20 px-6 bg-gradient-to-b from-white to-[#F5F7FA]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-[#2563eb] mb-6">
            لماذا Service Egy هي الخيار الأمثل لصيانة أجهزتك؟
          </h2>
          <p className="text-xl text-[#707070] max-w-3xl mx-auto leading-relaxed">
            نحن لسنا مجرد شركة صيانة عادية، بل شريكك الموثوق في الحفاظ على أجهزتك المنزلية بأعلى معايير الجودة والاحترافية
          </p>
        </div>
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {premiumReasons.slice(0, 2).map((reason) => (
            <ReasonCardComponent key={reason.title} reason={reason} />
          ))}
        </div>
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {premiumReasons.slice(2, 4).map((reason) => (
            <ReasonCardComponent key={reason.title} reason={reason} />
          ))}
        </div>
        <div className="grid lg:grid-cols-2 gap-12">
          {premiumReasons.slice(4).map((reason) => (
            <ReasonCardComponent key={reason.title} reason={reason} />
          ))}
        </div>
      </div>
    </section>
  )
}

function ReasonCardComponent({ reason }: { reason: ReasonCard }) {
  const Icon = reason.icon
  return (
    <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
      <div className="flex items-center gap-4 mb-6">
        <div className="bg-gradient-to-br from-[#2563eb] to-[#3b82f6] w-16 h-16 rounded-xl flex items-center justify-center mx-auto">
          <Icon className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-2xl font-bold text-[#2563eb]">{reason.title}</h3>
      </div>
      {reason.paragraphs.map((paragraph, index) => (
        <p key={index} className="text-[#707070] leading-relaxed mb-4 last:mb-0">
          {paragraph}
        </p>
      ))}
    </div>
  )
}

function CommitmentBanner() {
  return (
    <div className="max-w-7xl mx-auto px-6 pb-20">
      <div className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] p-10 rounded-2xl text-white text-center">
        <div className="flex items-center justify-center gap-4 mb-6">
          <BookOpen className="w-12 h-12" />
          <h3 className="text-3xl font-bold">التزامنا تجاهك</h3>
        </div>
        <p className="text-xl leading-relaxed mb-6 max-w-4xl mx-auto">
          عندما تختار Service Egy، فأنت لا تحصل فقط على خدمة صيانة، بل تحصل على شريك موثوق يهتم بأجهزتك كما تهتم بها أنت. نلتزم بتقديم أفضل خدمة ممكنة، بأسعار عادلة وشفافة، مع ضمان مكتوب على كل عمل نقوم به. ثقتك هي أغلى ما نملك، ونعمل كل يوم على أن نكون جديرين بها.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link
            href="/contact"
            prefetch
            className="bg-white text-[#2563eb] px-8 py-4 rounded-full font-bold hover:bg-gray-100 transition-colors"
          >
            اطلب خدمتك الآن
          </Link>
          <Link
            href="/about"
            prefetch
            className="border-2 border-white text-white px-8 py-4 rounded-full font-bold hover:bg-white/10 transition-colors"
          >
            اعرف المزيد عنا
          </Link>
        </div>
      </div>
    </div>
  )
}

function FAQSection() {
  return (
    <section className="py-16 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold text-[#2563eb] text-center mb-12">الأسئلة الشائعة</h2>
        <p className="text-xl text-[#707070] text-center mb-12">إجابات سريعة على أكثر الأسئلة شيوعاً</p>
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {faqItems.map((faq) => (
            <div key={faq.question} className="bg-[#F5F7FA] p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <h3 className="text-lg font-bold text-[#2563eb] mb-3">{faq.question}</h3>
              <p className="text-[#707070] leading-relaxed">{faq.answer}</p>
            </div>
          ))}
        </div>
        <div className="text-center">
          <Link
            href="/faq"
            prefetch
            className="inline-block bg-[#2563eb] text-white px-8 py-4 rounded-full font-bold hover:bg-[#1d4ed8] transition-colors"
          >
            عرض جميع الأسئلة
          </Link>
        </div>
      </div>
    </section>
  )
}

function GuaranteeSection() {
  return (
    <section className="py-16 px-6 bg-[#F5F7FA]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-[#2563eb] mb-4">الضمان والدعم</h2>
          <p className="text-xl text-[#707070]">ثقتك هي رأس مالنا الحقيقي</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {guaranteeCards.map((item) => {
            const Icon = item.icon
            return (
              <div
                key={item.title}
                className="bg-gradient-to-br from-[#2563eb] to-[#3b82f6] text-white p-6 rounded-xl text-center hover:shadow-xl transition-shadow"
              >
                <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-blue-100">{item.description}</p>
              </div>
            )
          })}
        </div>
        <div className="text-center">
          <Link
            href="/warranty"
            prefetch
            className="inline-block bg-[#2563eb] text-white px-8 py-4 rounded-full font-bold hover:bg-[#1d4ed8] transition-colors"
          >
            اعرف المزيد عن الضمان
          </Link>
        </div>
      </div>
    </section>
  )
}

function ContactSection() {
  return (
    <section className="py-16 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold text-[#2563eb] text-center mb-12">تواصل معنا الآن</h2>
        <div className="grid sm:grid-cols-2 gap-6 max-w-3xl mx-auto">
          {contactOptions.map((option) => {
            const Icon = option.icon
            const baseClasses =
              "rounded-xl transition-colors flex items-center gap-4 shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#2563eb]"
            const variantClasses = option.primary
              ? "bg-[#2563eb] text-white hover:bg-[#1d4ed8]"
              : "bg-white text-[#2563eb] hover:bg-[#e8ecf1]"
            return (
              <a key={option.value} href={option.href} className={`${baseClasses} ${variantClasses} p-6`}>
                <Icon className="w-8 h-8" />
                <div>
                  <div className={`text-sm ${option.primary ? "text-blue-100" : "text-[#707070]"}`}>{option.label}</div>
                  <div className={`font-bold ${option.primary ? "text-2xl" : ""}`}>{option.value}</div>
                </div>
              </a>
            )
          })}
        </div>
      </div>
    </section>
  )
}

function TestimonialsSection() {
  return (
    <section className="py-20 px-6 bg-gradient-to-b from-white to-gray-50 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">ماذا يقول عملاؤنا</h2>
          <p className="text-xl text-gray-600">آراء حقيقية من عملاء استفادوا من خدماتنا</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div key={testimonial.name} className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all animate-fade-in">
              <div className="flex gap-1 mb-4">
                {Array.from({ length: 5 }).map((_, index) => (
                  <Star key={index} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-gray-700 leading-relaxed mb-6 italic text-pretty">"{testimonial.quote}"</p>
              <div>
                <div className="font-bold text-gray-900">{testimonial.name}</div>
                <div className="text-sm text-gray-600">{testimonial.location}</div>
              </div>
            </div>
          ))}
        </div>
        <div className="flex justify-center gap-2 mt-8">
          <div className="h-2 rounded-full w-8 bg-[#2563eb]" />
          {Array.from({ length: 28 }).map((_, index) => (
            <div key={index} className="h-2 w-2 rounded-full bg-gray-300" />
          ))}
        </div>
      </div>
    </section>
  )
}

