import { Shield, Lock, Eye, FileText, CircleCheckBig, CircleAlert } from "lucide-react"
import { Metadata } from "next"

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "https://service-egy.com"

export const metadata: Metadata = {
  title: "سياسة الخصوصية - Service Egy",
  description:
    "سياسة الخصوصية الخاصة بـ Service Egy توضح كيفية جمع واستخدام وحماية بياناتك الشخصية أثناء استخدام موقعنا وخدمات الصيانة المعتمدة.",
  keywords: [
    "سياسة الخصوصية",
    "الخصوصية",
    "حماية البيانات",
    "Service Egy",
    "خصوصية العملاء",
  ],
  openGraph: {
    title: "سياسة الخصوصية - Service Egy",
    description: "تعرّف على سياسة الخصوصية الخاصة بـ Service Egy وكيفية حماية بياناتك الشخصية.",
    url: `${baseUrl}/privacy-policy`,
  },
  alternates: {
    canonical: "/privacy-policy",
  },
}

export default function PrivacyPolicy() {
  return (
    <main className="min-h-screen bg-[#F5F7FA]">
      <section className="bg-linear-to-r from-[#2563eb] to-[#3b82f6] text-white py-12 sm:py-16 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto text-right">
          <div className="flex items-center gap-3 sm:gap-4 mb-4">
            <Shield className="w-10 h-10 sm:w-12 sm:h-12" />
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold leading-tight text-right">سياسة الخصوصية</h1>
          </div>
          <p className="text-base sm:text-lg lg:text-xl text-blue-100 leading-relaxed">
            نحمي خصوصيتك وبياناتك الشخصية بشفافية كاملة والتزام بمعايير الأمان.
          </p>
          <p className="text-xs sm:text-sm text-blue-200 mt-2">آخر تحديث: نوفمبر 2025</p>
        </div>
      </section>

      <section className="py-12 sm:py-16 px-4 sm:px-6">
        <div className="max-w-4xl mx-auto space-y-8 text-right">
          <div className="bg-white p-6 sm:p-8 rounded-xl shadow-md">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#2563eb] mb-4">مقدمة</h2>
            <p className="text-[#707070] leading-relaxed mb-4">
              نحن في <strong>Service Egy</strong> ندرك أهمية خصوصيتك ونلتزم بحماية معلوماتك الشخصية. تشرح سياسة الخصوصية هذه كيفية جمع واستخدام وحماية بياناتك عند استخدام موقعنا أو خدماتنا.
            </p>
            <p className="text-[#707070] leading-relaxed">
              باستخدامك لموقعنا أو خدماتنا فإنك توافق على الممارسات الموضحة في هذه السياسة. إذا كنت لا توافق على أي جزء منها، يرجى عدم استخدام الموقع أو الخدمات.
            </p>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-xl shadow-md">
            <div className="flex items-center gap-3 sm:gap-4 mb-6">
              <Eye className="w-7 h-7 sm:w-8 sm:h-8 text-[#2563eb]" />
              <h2 className="text-2xl sm:text-3xl font-bold text-[#2563eb] text-right">المعلومات التي نجمعها</h2>
            </div>

            <div className="space-y-6">
              <div>
                <h3 className="text-lg sm:text-xl font-bold text-[#2563eb] mb-3">1. المعلومات الشخصية</h3>
                <p className="text-[#707070] leading-relaxed mb-3">عندما تطلب خدماتنا، قد نجمع معلومات شخصية عنك تشمل:</p>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4 sm:mr-6">
                  <li>الاسم الكامل</li>
                  <li>أرقام الهواتف للتواصل</li>
                  <li>عنوان البريد الإلكتروني</li>
                  <li>عنوان السكن لتحديد مكان الخدمة</li>
                  <li>معلومات عن الجهاز المراد صيانته (النوع، الماركة، الموديل، وصف العطل)</li>
                  <li>تفاصيل الطلب وأي ملاحظات إضافية</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg sm:text-xl font-bold text-[#2563eb] mb-3">2. بيانات التواصل</h3>
                <p className="text-[#707070] leading-relaxed">
                  نحتفظ بسجلات اتصالاتك معنا عبر الخط الساخن 01110195560، أو أرقام الدعم الفني، أو البريد الإلكتروني
                  <span className="font-semibold"> info@service-egy.com </span>
                  بهدف تحسين الخدمة ومتابعة الطلبات.
                </p>
              </div>

              <div>
                <h3 className="text-lg sm:text-xl font-bold text-[#2563eb] mb-3">3. بيانات الاستخدام</h3>
                <p className="text-[#707070] leading-relaxed mb-3">نجمع معلومات حول كيفية استخدامك لموقعنا، مثل:</p>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4 sm:mr-6">
                  <li>عنوان IP</li>
                  <li>نوع المتصفح ونظام التشغيل</li>
                  <li>الصفحات التي تزورها والوقت الذي تقضيه عليها</li>
                  <li>مصدر الزيارة وكيف وصلت إلى موقعنا</li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg sm:text-xl font-bold text-[#2563eb] mb-3">4. معلومات الدفع</h3>
                <p className="text-[#707070] leading-relaxed">
                  عند استخدام وسائل دفع إلكترونية، قد نجمع البيانات اللازمة لإتمام المعاملة عبر مزودي دفع آمنين. لا نخزن بيانات بطاقات الدفع الكاملة على أنظمتنا.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-xl shadow-md">
            <div className="flex items-center gap-3 sm:gap-4 mb-6">
              <CircleCheckBig className="w-7 h-7 sm:w-8 sm:h-8 text-[#2563eb]" />
              <h2 className="text-2xl sm:text-3xl font-bold text-[#2563eb] text-right">كيف نستخدم معلوماتك</h2>
            </div>

            <div className="space-y-4">
              <p className="text-[#707070] leading-relaxed">نستخدم المعلومات التي نجمعها للأغراض التالية:</p>

              <div className="bg-[#F5F7FA] p-5 sm:p-6 rounded-lg">
                <h3 className="text-base sm:text-lg font-bold text-[#2563eb] mb-3">أ) تقديم الخدمات</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4 sm:mr-6">
                  <li>معالجة طلبات الصيانة وتنسيق المواعيد</li>
                  <li>إرسال الفنيين المعتمدين إلى عنوانك</li>
                  <li>التواصل معك بشأن حالة الطلب وأي استفسارات</li>
                  <li>تقديم الدعم الفني والمتابعة بعد الصيانة</li>
                </ul>
              </div>

              <div className="bg-[#F5F7FA] p-5 sm:p-6 rounded-lg">
                <h3 className="text-base sm:text-lg font-bold text-[#2563eb] mb-3">ب) تحسين الجودة</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4 sm:mr-6">
                  <li>تحليل استخدام الموقع لتحسين الأداء وتجربة المستخدم</li>
                  <li>تطوير خدمات جديدة وتحديث الخدمات الحالية</li>
                  <li>جمع الملاحظات واستطلاعات الرأي لرفع مستوى الخدمة</li>
                </ul>
              </div>

              <div className="bg-[#F5F7FA] p-5 sm:p-6 rounded-lg">
                <h3 className="text-base sm:text-lg font-bold text-[#2563eb] mb-3">ج) التواصل معك</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4 sm:mr-6">
                  <li>إرسال الإشعارات والتذكيرات الخاصة بمواعيد الصيانة</li>
                  <li>الرد على استفساراتك وطلبات الدعم</li>
                  <li>إرسال العروض والتحديثات بموافقتك المسبقة</li>
                  <li>مشاركة التقارير والفواتير المتعلقة بالخدمة</li>
                </ul>
              </div>

              <div className="bg-[#F5F7FA] p-5 sm:p-6 rounded-lg">
                <h3 className="text-base sm:text-lg font-bold text-[#2563eb] mb-3">د) الأمان والامتثال</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4 sm:mr-6">
                  <li>حماية أنظمتنا وخدماتنا من الوصول غير المصرح به</li>
                  <li>منع الاحتيال والأنشطة الضارة</li>
                  <li>الامتثال للقوانين واللوائح المعمول بها في جمهورية مصر العربية</li>
                  <li>الاحتفاظ بالسجلات المطلوبة قانونيًا</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-xl shadow-md">
            <div className="flex items-center gap-3 sm:gap-4 mb-6">
              <Lock className="w-7 h-7 sm:w-8 sm:h-8 text-[#2563eb]" />
              <h2 className="text-2xl sm:text-3xl font-bold text-[#2563eb] text-right">حماية بياناتك</h2>
            </div>

            <div className="space-y-4">
              <p className="text-[#707070] leading-relaxed">
                نطبق إجراءات تقنية وتنظيمية متعددة لحماية بياناتك الشخصية من الوصول غير المصرح به أو التعديل أو التدمير، وتشمل:
              </p>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="bg-[#F5F7FA] p-4 sm:p-5 rounded-lg">
                  <h4 className="font-bold text-[#2563eb] mb-2">التشفير</h4>
                  <p className="text-sm text-[#707070]">استخدام بروتوكولات آمنة (SSL/TLS) لحماية البيانات أثناء النقل.</p>
                </div>
                <div className="bg-[#F5F7FA] p-4 sm:p-5 rounded-lg">
                  <h4 className="font-bold text-[#2563eb] mb-2">الوصول المحدود</h4>
                  <p className="text-sm text-[#707070]">حصر الوصول إلى البيانات على موظفين مخولين ومدرَّبين.</p>
                </div>
                <div className="bg-[#F5F7FA] p-4 sm:p-5 rounded-lg">
                  <h4 className="font-bold text-[#2563eb] mb-2">النسخ الاحتياطي</h4>
                  <p className="text-sm text-[#707070]">إجراء نسخ احتياطية آمنة ومنتظمة للأنظمة والبيانات المهمة.</p>
                </div>
                <div className="bg-[#F5F7FA] p-4 sm:p-5 rounded-lg">
                  <h4 className="font-bold text-[#2563eb] mb-2">تحديثات الأمان</h4>
                  <p className="text-sm text-[#707070]">تحديث مستمر للأنظمة والبرمجيات للحماية من الثغرات.</p>
                </div>
              </div>

              <div className="bg-yellow-50 border-r-4 border-yellow-400 p-4 sm:p-5 rounded">
                <div className="flex items-start gap-3">
                  <CircleAlert className="w-5 h-5 text-yellow-600 shrink-0 mt-0.5" />
                  <p className="text-xs sm:text-sm text-yellow-800">
                    <strong>تنبيه:</strong> رغم التزامنا بأفضل معايير الأمان، لا يمكن ضمان حماية مطلقة لأي نقل بيانات عبر الإنترنت. ننصحك بعدم مشاركة معلومات شديدة الحساسية إلكترونيًا.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-xl shadow-md">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#2563eb] mb-6">مشاركة المعلومات</h2>
            <div className="space-y-4 text-[#707070] leading-relaxed">
              <p>لا نبيع أو نؤجر بياناتك الشخصية لأي طرف ثالث. قد نشارك بعض البيانات في الحالات التالية:</p>

              <div className="bg-[#F5F7FA] p-5 sm:p-6 rounded-lg">
                <h3 className="text-base sm:text-lg font-bold text-[#2563eb] mb-3">1. مزودو الخدمات</h3>
                <p>قد نتعاون مع مزودين موثوقين لمساعدتنا في تشغيل خدماتنا، مثل:</p>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4 sm:mr-6 mt-2">
                  <li>استضافة المواقع والخوادم</li>
                  <li>أنظمة إدارة الطلبات</li>
                  <li>خدمات البريد الإلكتروني والرسائل</li>
                  <li>مزودو خدمات الدفع الإلكتروني</li>
                </ul>
                <p className="mt-2">تلتزم هذه الجهات بالحفاظ على سرية البيانات وعدم استخدامها إلا لتقديم الخدمة نيابة عنا.</p>
              </div>

              <div className="bg-[#F5F7FA] p-5 sm:p-6 rounded-lg">
                <h3 className="text-base sm:text-lg font-bold text-[#2563eb] mb-3">2. الالتزام القانوني</h3>
                <p>قد نفصح عن بعض البيانات إذا طُلب منا ذلك بموجب القانون أو بناءً على أمر من جهة رسمية مختصة، أو لحماية حقوقنا وحقوق عملائنا.</p>
              </div>

              <div className="bg-[#F5F7FA] p-5 sm:p-6 rounded-lg">
                <h3 className="text-base sm:text-lg font-bold text-[#2563eb] mb-3">3. انتقال الأعمال</h3>
                <p>في حال الاندماج أو الاستحواذ أو بيع جزء من أصول الشركة، قد تُنقل البيانات كجزء من الصفقة مع ضمان حماية حقوقك.</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-xl shadow-md">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#2563eb] mb-6">ملفات تعريف الارتباط (Cookies)</h2>
            <div className="space-y-4 text-[#707070] leading-relaxed">
              <p>نستخدم ملفات تعريف الارتباط لتحسين تجربتك على الموقع، مثل تذكّر تفضيلاتك وتحليل أداء الصفحات.</p>
              <div className="bg-[#F5F7FA] p-5 sm:p-6 rounded-lg">
                <h3 className="text-base sm:text-lg font-bold text-[#2563eb] mb-3">أنواع ملفات تعريف الارتباط:</h3>
                <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4 sm:mr-6">
                  <li>
                    <strong>ضرورية:</strong> تُمكّن الموقع من العمل بشكل صحيح.
                  </li>
                  <li>
                    <strong>وظيفية:</strong> تحفظ تفضيلاتك لتحسين التجربة.
                  </li>
                  <li>
                    <strong>تحليلية:</strong> تساعدنا على فهم كيفية استخدام الموقع وتطويره.
                  </li>
                </ul>
              </div>
              <p>يمكنك تعطيل ملفات تعريف الارتباط من إعدادات المتصفح، لكن قد يؤثر ذلك على بعض وظائف الموقع.</p>
            </div>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-xl shadow-md">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#2563eb] mb-6">حقوقك</h2>
            <div className="space-y-4 text-[#707070] leading-relaxed">
              <p>نحترم حقوقك المتعلقة ببياناتك الشخصية، والتي تشمل:</p>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="bg-[#F5F7FA] p-4 sm:p-5 rounded-lg">
                  <h4 className="font-bold text-[#2563eb] mb-2">حق الوصول</h4>
                  <p className="text-sm text-[#707070]">يحق لك طلب معرفة نوع البيانات التي نحتفظ بها عنك.</p>
                </div>
                <div className="bg-[#F5F7FA] p-4 sm:p-5 rounded-lg">
                  <h4 className="font-bold text-[#2563eb] mb-2">حق التصحيح</h4>
                  <p className="text-sm text-[#707070]">يمكنك طلب تصحيح أي بيانات غير دقيقة أو غير مكتملة.</p>
                </div>
                <div className="bg-[#F5F7FA] p-4 sm:p-5 rounded-lg">
                  <h4 className="font-bold text-[#2563eb] mb-2">حق الحذف</h4>
                  <p className="text-sm text-[#707070]">يمكنك طلب حذف بياناتك في الحالات التي يسمح بها القانون.</p>
                </div>
                <div className="bg-[#F5F7FA] p-4 sm:p-5 rounded-lg">
                  <h4 className="font-bold text-[#2563eb] mb-2">حق الاعتراض</h4>
                  <p className="text-sm text-[#707070]">يمكنك الاعتراض على بعض طرق معالجة بياناتك.</p>
                </div>
              </div>
              <p>
                لممارسة أي من هذه الحقوق، يرجى التواصل معنا عبر البريد الإلكتروني
                <a href="mailto:info@service-egy.com" className="text-[#2563eb] hover:underline font-semibold">
                  {" "}
                  info@service-egy.com
                </a>
                .
              </p>
            </div>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-xl shadow-md">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#2563eb] mb-6">الاحتفاظ بالبيانات</h2>
            <div className="space-y-4 text-[#707070] leading-relaxed">
              <p>نحتفظ ببياناتك الشخصية طالما كانت ضرورية لتحقيق الأغراض المذكورة في هذه السياسة أو وفقًا لما يتطلبه القانون.</p>
              <p>بشكل عام، نحتفظ ببيانات العملاء لمدة تصل إلى 5 سنوات من آخر تعامل، ما لم توجد متطلبات قانونية للاحتفاظ بها مدة أطول.</p>
            </div>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-xl shadow-md">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#2563eb] mb-6">خصوصية الأطفال</h2>
            <p className="text-[#707070] leading-relaxed">
              خدماتنا موجهة للبالغين (18 سنة فأكثر). لا نجمع معلومات شخصية عن قصد من الأطفال دون 18 سنة. إذا تبين لنا أننا جمعنا مثل هذه البيانات، سنقوم بحذفها فورًا.
            </p>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-xl shadow-md">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#2563eb] mb-6">التعديلات على السياسة</h2>
            <p className="text-[#707070] leading-relaxed mb-4">
              قد نقوم بتحديث سياسة الخصوصية من وقت لآخر. سنخطرك بأي تغييرات جوهرية عبر:
            </p>
            <ul className="list-disc list-inside space-y-2 text-[#707070] mr-4 sm:mr-6">
              <li>تحديث هذه الصفحة على موقعنا</li>
              <li>تحديث تاريخ "آخر تحديث" أعلى الصفحة</li>
              <li>التواصل معك عبر البريد الإلكتروني عند الحاجة</li>
            </ul>
            <p className="text-[#707070] leading-relaxed mt-4">
              استمرارك في استخدام الموقع أو الخدمات بعد التعديلات يُعد موافقة على السياسة المحدثة.
            </p>
          </div>

          <div className="bg-linear-to-r from-[#2563eb] to-[#3b82f6] text-white p-8 rounded-xl">
            <h2 className="text-3xl font-bold mb-6">تواصل معنا</h2>
            <p className="text-blue-100 leading-relaxed mb-6">
              إذا كان لديك أي أسئلة أو ملاحظات حول سياسة الخصوصية أو طريقة تعاملنا مع بياناتك، يرجى التواصل معنا:
            </p>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5" />
                <div>
                  <p className="font-semibold">البريد الإلكتروني:</p>
                  <a href="mailto:info@service-egy.com" className="text-blue-100 hover:text-white underline">
                    info@service-egy.com
                  </a>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5" />
                <div>
                  <p className="font-semibold">الخط الساخن:</p>
                  <a href="tel:01110195560" className="text-blue-100 hover:text-white underline">
                    01110195560
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
