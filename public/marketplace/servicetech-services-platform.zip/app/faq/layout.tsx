import { Metadata } from "next"

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://service-egy.com'

export const metadata: Metadata = {
  title: "الأسئلة الشائعة",
  description: "إجابات على أكثر الأسئلة شيوعاً حول خدمات صيانة الأجهزة المنزلية في Service Egy. تعرف على كيفية الحجز، الضمان، الأسعار، وأكثر.",
  keywords: [
    "أسئلة شائعة",
    "FAQ صيانة",
    "استفسارات صيانة",
    "خدمة صيانة مصر"
  ],
  openGraph: {
    title: "الأسئلة الشائعة - Service Egy",
    description: "إجابات على أكثر الأسئلة شيوعاً حول خدمات صيانة الأجهزة المنزلية",
    url: `${baseUrl}/faq`,
  },
  alternates: {
    canonical: "/faq",
  },
}

export default function FAQLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}





