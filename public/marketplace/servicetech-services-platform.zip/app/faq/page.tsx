"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"
import Footer from "@/components/footer"

interface FAQItem {
  category: string
  q: string
  a: string
}

export default function FAQ() {
  const [activeTab, setActiveTab] = useState<number | null>(null)

  const faqs: FAQItem[] = [
    {
      category: "الخدمات",
      q: "هل الصيانة تتم في المنزل؟",
      a: "نعم، معظم خدماتنا تتم في منزلك. الفني يزورك مزودًا بأدوات التشخيص والإصلاح اللازمة، ولا يتم نقل الجهاز إلا إذا كانت الحالة تستدعي ذلك وبعد موافقتك.",
    },
    {
      category: "الخدمات",
      q: "ما هي أنواع الأجهزة التي تقدمون لها خدمة الصيانة؟",
      a: "نقدم صيانة شاملة لغسالات الملابس، الثلاجات، الديب فريزر، غسالات الأطباق، الميكروويف، المجففات، والتكييفات، مع تغطية لأشهر الماركات العالمية والمحلية.",
    },
    {
      category: "الخدمات",
      q: "هل تقدمون خدمة الطوارئ؟",
      a: "نعم، متاح استقبال طلبات الأعطال الحرجة عبر الخط الساخن 01110195560 مع محاولة توفير زيارة عاجلة حسب المتاح في منطقتك.",
    },
    {
      category: "قطع الغيار",
      q: "هل تستخدمون قطع غيار أصلية؟",
      a: "نلتزم باستخدام قطع غيار أصلية أو بدائل معتمدة بجودة عالية، مع ضمان مكتوب على القطع والخدمة.",
    },
    {
      category: "قطع الغيار",
      q: "ماذا لو لم تكن قطعة الغيار متوفرة فوراً؟",
      a: "نخبرك بالمدة المتوقعة لتوفير القطعة، ويمكن تحديد موعد لاحق بعد وصولها. لا يتم أي التزام بدون موافقتك.",
    },
    {
      category: "الضمان",
      q: "هل يوجد ضمان بعد الصيانة؟",
      a: "نعم، يوجد ضمان مكتوب على نفس العطل والقطع المستبدلة، وتختلف مدة الضمان حسب نوع الجهاز والعطل (عادة من 3 إلى 12 شهرًا).",
    },
    {
      category: "الضمان",
      q: "ماذا يغطي الضمان؟",
      a: "يغطي تكرار نفس العطل أو مشكلة في القطعة المستبدلة خلال فترة الضمان. لا يغطي سوء الاستخدام أو الأعطال الجديدة غير المرتبطة بالإصلاح السابق.",
    },
    {
      category: "المواعيد",
      q: "هل يمكن تحديد موعد مسبق؟",
      a: "طبعًا، يمكنك حجز الموعد المناسب لك من 9 صباحًا حتى 9 مساءً عبر الخط الساخن أو الواتساب أو الموقع.",
    },
    {
      category: "المواعيد",
      q: "ما مدة الاستجابة لطلب الصيانة؟",
      a: "عادة يتم التواصل خلال نفس اليوم وتحديد زيارة خلال 1–3 أيام حسب ضغط العمل وموقعك، مع أولوية لحالات الطوارئ.",
    },
    {
      category: "الأسعار",
      q: "هل الأسعار موحدة وواضحة؟",
      a: "نعم، الكشف والتكاليف يتم شرحها قبل بدء الإصلاح، ولا نبدأ أي عمل دون موافقتك. لا توجد مصاريف مخفية.",
    },
    {
      category: "الأسعار",
      q: "ما طرق الدفع المتاحة؟",
      a: "الدفع نقدي عند إتمام الخدمة، ويمكن توفير خيارات أخرى حسب الاتفاق (مثل التحويل البنكي للمشروعات أو العقود).",
    },
    {
      category: "المتابعة",
      q: "هل يوجد متابعة بعد الصيانة؟",
      a: "نقوم بالتواصل للتأكد من كفاءة الجهاز بعد الإصلاح، ويمكنك الرجوع لنا في أي وقت خلال فترة الضمان.",
    },
    {
      category: "الفواتير",
      q: "هل تقدمون فواتير رسمية؟",
      a: "نعم، نقدم فاتورة توضح الخدمة والقطع والتكلفة، وتُستخدم كإثبات للضمان.",
    },
    {
      category: "الفنيون",
      q: "هل الفنّيون معتمدون ويمكن الثقة بهم؟",
      a: "فريقنا مدرَّب ومعتمد، ويرتدي زي موحد ويحمل هوية رسمية. يمكنك التأكد من بياناته عبر الاتصال بنا.",
    },
    {
      category: "التغطية",
      q: "هل الخدمة متاحة في جميع المحافظات؟",
      a: "نغطي القاهرة والجيزة ومعظم المحافظات، مع اختلاف وقت الاستجابة حسب بُعد المنطقة.",
    },
    {
      category: "الخدمات",
      q: "هل يمكن طلب صيانة لأكثر من جهاز في نفس الزيارة؟",
      a: "نعم، ويمكن تقديم عروض خاصة عند صيانة عدة أجهزة في نفس الموعد.",
    },
  ]

  const categories = Array.from(new Set(faqs.map((f) => f.category)))

  return (
    <main className="min-h-screen font-sans" dir="rtl">
      {/* Hero */}
      <section className="bg-linear-to-r from-[#2563eb] to-[#3b82f6] text-white py-16 px-6">
        <div className="max-w-7xl mx-auto text-right">
          <h1 className="text-5xl font-bold mb-4">الأسئلة الشائعة</h1>
          <p className="text-xl text-blue-100">
            إجابات واضحة على أكثر الأسئلة تكرارًا بخصوص خدمات Service Egy للصيانة المعتمدة.
          </p>
        </div>
      </section>

      {/* FAQ Content */}
      <section className="py-16 px-6 bg-white">
        <div className="max-w-4xl mx-auto">
          {/* Category Filter */}
          <div className="mb-8 bg-[#F5F7FA] p-6 rounded-xl text-right">
            <h2 className="text-2xl font-bold text-[#2563eb] mb-4">تصفح الأسئلة حسب الفئة</h2>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => {
                    const index = faqs.findIndex((f) => f.category === cat)
                    setActiveTab(index)
                    const element = document.getElementById(`category-${index}`)
                    element?.scrollIntoView({ behavior: "smooth", block: "start" })
                  }}
                  className="bg-white text-[#2563eb] px-4 py-2 rounded-lg hover:bg-[#2563eb] hover:text-white transition-colors text-sm font-semibold"
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Accordion */}
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                id={`category-${index}`}
                className="border-2 border-[#2563eb]/20 rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => setActiveTab(activeTab === index ? null : index)}
                  className="w-full bg-[#F5F7FA] hover:bg-[#e8ecf1] p-6 flex items-center justify-between transition-colors text-right"
                >
                  <ChevronDown
                    className={`w-5 h-5 text-[#2563eb] transition-transform shrink-0 ${activeTab === index ? "rotate-180" : ""}`}
                  />
                  <div className="flex-1 mr-4">
                    <span className="text-xs text-[#2563eb] bg-blue-50 px-2 py-1 rounded-full font-semibold ml-2">
                      {faq.category}
                    </span>
                    <h3 className="text-lg font-bold text-[#2563eb] mt-2">{faq.q}</h3>
                  </div>
                </button>
                {activeTab === index && (
                  <div className="bg-white p-6 border-t-2 border-[#2563eb]/20 text-right">
                    <p className="text-[#707070] leading-relaxed">{faq.a}</p>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Still have questions? */}
          <div className="mt-12 bg-linear-to-r from-[#2563eb] to-[#3b82f6] text-white p-8 rounded-xl text-right">
            <h2 className="text-2xl font-bold mb-4">لسه ما لقيتش إجابتك؟</h2>
            <p className="text-blue-100 mb-6">
              فريق خدمة العملاء جاهز يساعدك ويجاوب على أي استفسار عن الأعطال، الأسعار، أو مواعيد الزيارات.
            </p>
            <div className="flex flex-wrap gap-4 justify-end">
              <a
                href="tel:01110195560"
                className="bg-white text-[#2563eb] px-6 py-3 rounded-full font-bold hover:bg-blue-50 transition-colors"
              >
                اتصل بنا: 01110195560
              </a>
              <a
                href="mailto:info@service-egy.com"
                className="border-2 border-white text-white px-6 py-3 rounded-full font-bold hover:bg-white/10 transition-colors"
              >
                راسلنا عبر البريد الإلكتروني
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
