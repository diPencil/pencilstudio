import { Phone, Mail, Clock, MapPin } from "lucide-react"
import { Metadata } from "next"
import TestimonialsSlider from "@/components/testimonials-slider"
import ContactForm from "@/components/contact-form"

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://service-egy.com'

export const metadata: Metadata = {
  title: "تواصل معنا",
  description: "تواصل مع Service Egy لحجز موعد صيانة أو الاستفسار عن خدماتنا. الخط الساخن: 01110195560. خدمة متاحة في جميع محافظات مصر. من 9 صباحاً إلى 9 مساءً يومياً.",
  keywords: [
    "تواصل معنا",
    "حجز موعد صيانة",
    "الخط الساخن Service Egy",
    "صيانة في مصر",
    "عنوان شركة الصيانة"
  ],
  openGraph: {
    title: "تواصل معنا - Service Egy",
    description: "تواصل مع Service Egy لحجز موعد صيانة أو الاستفسار عن خدماتنا. الخط الساخن: 01110195560",
    url: `${baseUrl}/contact`,
  },
  alternates: {
    canonical: "/contact",
  },
}

export default function Contact() {
  return (
    <main className="min-h-screen">
      {/* Hero */}
      <section className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-5xl font-bold mb-4">تواصل معنا</h1>
          <p className="text-xl text-blue-100">هل جهازك محتاج صيانة؟ تواصل معنا الآن وسنصل إليك في أسرع وقت</p>
        </div>
      </section>

      {/* Contact Info */}
      <section className="py-16 px-6 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            <a
              href="tel:01110195560"
              className="bg-gradient-to-br from-[#2563eb] to-[#3b82f6] text-white p-8 rounded-xl hover:shadow-lg transition-all"
            >
              <div className="flex items-center gap-4 mb-4">
                <Phone className="w-8 h-8" />
                <h3 className="text-2xl font-bold">الخط الساخن</h3>
              </div>
              <p className="text-4xl font-bold text-blue-100">01110195560</p>
            </a>

            <div className="bg-[#F5F7FA] p-8 rounded-xl">
              <div className="flex items-center gap-4 mb-4">
                <Phone className="w-8 h-8 text-[#2563eb]" />
                <h3 className="text-2xl font-bold text-[#2563eb]">الدعم الفني</h3>
              </div>
              <div className="space-y-2">
                <a href="tel:01110195560" className="block text-lg font-bold text-[#2563eb] hover:underline">
                  01110195560
                </a>
                <a href="tel:01153625752" className="block text-lg font-bold text-[#2563eb] hover:underline">
                  01153625752
                </a>
                <a href="tel:01016503001" className="block text-lg font-bold text-[#2563eb] hover:underline">
                  01016503001
                </a>
              </div>
            </div>

            <a
              href="mailto:info@service-egy.com"
              className="bg-[#F5F7FA] p-8 rounded-xl hover:bg-[#e8ecf1] transition-colors"
            >
              <div className="flex items-center gap-4 mb-4">
                <Mail className="w-8 h-8 text-[#2563eb]" />
                <h3 className="text-2xl font-bold text-[#2563eb]">البريد الإلكتروني</h3>
              </div>
              <p className="text-lg font-bold text-[#2563eb] break-all">info@service-egy.com</p>
            </a>

            <div className="bg-[#F5F7FA] p-8 rounded-xl">
              <div className="flex items-center gap-4 mb-4">
                <Clock className="w-8 h-8 text-[#2563eb]" />
                <h3 className="text-2xl font-bold text-[#2563eb]">مواعيد العمل</h3>
              </div>
              <p className="text-lg font-bold text-[#2563eb]">من 9 صباحاً إلى 9 مساءً</p>
              <p className="text-sm text-[#707070] mt-2">يومياً بدون عطل</p>
            </div>
          </div>

          {/* Service Area */}
          <div className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white p-8 rounded-xl">
            <div className="flex items-center gap-4 mb-4">
              <MapPin className="w-8 h-8" />
              <h3 className="text-2xl font-bold">خدمة الصيانة المنزلية</h3>
            </div>
            <p className="text-xl text-blue-100">متوفرة في جميع محافظات مصر</p>
          </div>
        </div>
      </section>

      {/* Governorates Coverage */}
      <section className="py-16 px-6 bg-gradient-to-b from-[#F5F7FA] to-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-[#2563eb] mb-4">نغطي جميع محافظات مصر</h2>
            <p className="text-xl text-[#707070]">خدماتنا متاحة في كل مكان لراحتك وسهولة الوصول إليك</p>
          </div>

          {/* Cairo & Giza */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold text-[#2563eb] mb-6 flex items-center gap-3">
              <div className="w-2 h-8 bg-[#2563eb] rounded-full"></div>
              القاهرة الكبرى
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {[
                "القاهرة",
                "الجيزة",
                "القليوبية",
                "6 أكتوبر",
                "الشروق",
                "العبور",
                "مدينة نصر",
                "المعادي",
                "حلوان",
                "الهرم",
              ].map((gov) => (
                <a
                  key={gov}
                  href="tel:01110195560"
                  className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-all border-2 border-transparent hover:border-[#2563eb] group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-[#2563eb] group-hover:scale-110 transition-transform" />
                    <span className="font-bold text-[#1a1a1a] group-hover:text-[#2563eb] transition-colors">{gov}</span>
                  </div>
                  <div className="mt-2 text-xs text-[#707070] group-hover:text-[#2563eb] transition-colors">
                    اضغط للاتصال: 01110195560
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Delta Region */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold text-[#2563eb] mb-6 flex items-center gap-3">
              <div className="w-2 h-8 bg-[#2563eb] rounded-full"></div>
              محافظات الدلتا
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {[
                "الإسكندرية",
                "الدقهلية",
                "الشرقية",
                "الغربية",
                "كفر الشيخ",
                "المنوفية",
                "البحيرة",
                "دمياط",
                "بورسعيد",
                "الإسماعيلية",
              ].map((gov) => (
                <a
                  key={gov}
                  href="tel:01110195560"
                  className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-all border-2 border-transparent hover:border-[#2563eb] group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-[#2563eb] group-hover:scale-110 transition-transform" />
                    <span className="font-bold text-[#1a1a1a] group-hover:text-[#2563eb] transition-colors">{gov}</span>
                  </div>
                  <div className="mt-2 text-xs text-[#707070] group-hover:text-[#2563eb] transition-colors">
                    اضغط للاتصال: 01110195560
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Canal Cities */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold text-[#2563eb] mb-6 flex items-center gap-3">
              <div className="w-2 h-8 bg-[#2563eb] rounded-full"></div>
              محافظات القناة
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {["السويس", "شمال سيناء", "جنوب سيناء"].map((gov) => (
                <a
                  key={gov}
                  href="tel:01110195560"
                  className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-all border-2 border-transparent hover:border-[#2563eb] group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-[#2563eb] group-hover:scale-110 transition-transform" />
                    <span className="font-bold text-[#1a1a1a] group-hover:text-[#2563eb] transition-colors">{gov}</span>
                  </div>
                  <div className="mt-2 text-xs text-[#707070] group-hover:text-[#2563eb] transition-colors">
                    اضغط للاتصال: 01110195560
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Upper Egypt */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold text-[#2563eb] mb-6 flex items-center gap-3">
              <div className="w-2 h-8 bg-[#2563eb] rounded-full"></div>
              محافظات الصعيد
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {["الفيوم", "بني سويف", "المنيا", "أسيوط", "سوهاج", "قنا", "الأقصر", "أسوان", "الوادي الجديد"].map(
                (gov) => (
                  <a
                    key={gov}
                    href="tel:01110195560"
                    className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-all border-2 border-transparent hover:border-[#2563eb] group cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <MapPin className="w-5 h-5 text-[#2563eb] group-hover:scale-110 transition-transform" />
                      <span className="font-bold text-[#1a1a1a] group-hover:text-[#2563eb] transition-colors">
                        {gov}
                      </span>
                    </div>
                    <div className="mt-2 text-xs text-[#707070] group-hover:text-[#2563eb] transition-colors">
                      اضغط للاتصال: 01110195560
                    </div>
                  </a>
                ),
              )}
            </div>
          </div>

          {/* Red Sea */}
          <div>
            <h3 className="text-2xl font-bold text-[#2563eb] mb-6 flex items-center gap-3">
              <div className="w-2 h-8 bg-[#2563eb] rounded-full"></div>
              محافظات البحر الأحمر
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {["البحر الأحمر", "مطروح"].map((gov) => (
                <a
                  key={gov}
                  href="tel:01110195560"
                  className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-all border-2 border-transparent hover:border-[#2563eb] group cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-[#2563eb] group-hover:scale-110 transition-transform" />
                    <span className="font-bold text-[#1a1a1a] group-hover:text-[#2563eb] transition-colors">{gov}</span>
                  </div>
                  <div className="mt-2 text-xs text-[#707070] group-hover:text-[#2563eb] transition-colors">
                    اضغط للاتصال: 01110195560
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Call to Action */}
          <div className="mt-16 text-center bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white p-12 rounded-2xl">
            <h3 className="text-3xl font-bold mb-4">أينما كنت، نحن في خدمتك</h3>
            <p className="text-xl text-blue-100 mb-8">
              فريقنا المتخصص جاهز للوصول إليك في أي محافظة لتقديم أفضل خدمة صيانة
            </p>
            <a
              href="tel:01110195560"
              className="inline-block bg-white text-[#2563eb] px-8 py-4 rounded-full font-bold text-xl hover:bg-blue-50 transition-colors shadow-lg"
            >
              اتصل بنا الآن: 01110195560
            </a>
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <ContactForm />

      {/* Testimonials Slider */}
      <TestimonialsSlider />
    </main>
  )
}
