import { Wrench, Droplet, Flame, Wind, Zap, Phone, ArrowLeft } from "lucide-react"
import Link from "next/link"
import TestimonialsSlider from "@/components/testimonials-slider"
import { servicesData } from "@/data/services"

export default function Services() {
  const iconMap = {
    Wrench,
    Droplet,
    Flame,
    Wind,
    Zap,
  } as const

  return (
    <main className="min-h-screen">
      {/* Hero */}
      <section className="bg-gradient-to-b from-[#2563eb] to-[#1d4ed8] text-white py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-5xl font-bold mb-4">خدماتنا</h1>
          <p className="text-xl text-blue-100">خدمات صيانة احترافية تغطي كل احتياجات منزلك</p>
        </div>
      </section>

      {/* Services - Updated to show detailed service cards with images and contact info */}
      <section className="py-16 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="space-y-12">
            {servicesData.map((service, index) => {
              const Icon = iconMap[service.icon]
              return (
                <div
                  key={index}
                  className="bg-[#F5F7FA] rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow"
                >
                  <div className="grid md:grid-cols-2 gap-6 p-8">
                    {/* Content */}
                    <div>
                      <div className="flex items-start gap-4 mb-4">
                        <div className="bg-[#2563eb] p-3 rounded-lg flex-shrink-0">
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h2 className="text-2xl font-bold text-[#2563eb]">{service.title}</h2>
                          <p className="text-[#707070] mt-1">{service.description}</p>
                        </div>
                      </div>
                      <ul className="space-y-2 my-6">
                        {service.items.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-3 text-[#707070]">
                            <span className="text-[#2563eb] font-bold mt-1">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                      <div className="mt-6">
                        <Link
                          href={`/services/${service.id}`}
                          className="inline-flex items-center gap-2 bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white px-8 py-3 rounded-full font-bold hover:shadow-lg transition-all hover:scale-105"
                        >
                          <ArrowLeft className="w-5 h-5" />
                          اعرف تفاصيل الخدمة الكاملة
                        </Link>
                      </div>
                      <div className="mt-8 pt-6 border-t border-[#e0e7ff]">
                        <h4 className="font-bold text-[#2563eb] mb-4">تواصل معنا للحصول على هذه الخدمة</h4>
                        <div className="space-y-3">
                          <a
                            href="tel:01110195560"
                            className="flex items-center gap-3 text-[#2563eb] hover:text-[#1d4ed8] font-semibold"
                          >
                            <Phone className="w-5 h-5" />
                            الخط الساخن: 01110195560
                          </a>
                          <a
                            href="tel:01153625752"
                            className="flex items-center gap-3 text-[#2563eb] hover:text-[#1d4ed8] font-semibold"
                          >
                            <Phone className="w-5 h-5" />
                            الدعم الفني: 01153625752
                          </a>
                          <a
                            href="tel:01016503001"
                            className="flex items-center gap-3 text-[#2563eb] hover:text-[#1d4ed8] font-semibold"
                          >
                            <Phone className="w-5 h-5" />
                            الدعم الفني: 01016503001
                          </a>
                        </div>
                      </div>
                    </div>
                    {/* Image */}
                    <div className="flex items-center justify-center">
                      <img
                        src={service.image || "/placeholder.svg"}
                        alt={service.title}
                        className="w-full h-80 object-cover rounded-lg"
                      />
                    </div>
                  </div>
                </div>
              )
            })}
          </div>

          {/* Common Features */}
          <div className="mt-16 bg-[#2563eb] text-white p-8 rounded-xl">
            <h3 className="text-2xl font-bold mb-6">مميزات كل الخدمات</h3>
            <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4">
              {[
                "تشخيص سريع ودقيق",
                "قطع أصلية مع ضمان مكتوب",
                "اختبار عملي أمام العميل",
                "متابعة بعد الصيانة لضمان الكفاءة",
              ].map((feature, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <span className="text-blue-200 text-xl">✓</span>
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Slider */}
      <TestimonialsSlider />
    </main>
  )
}
