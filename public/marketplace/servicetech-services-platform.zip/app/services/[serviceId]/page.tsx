import { Phone, Mail, CheckCircle, Shield, Clock, Wrench, Award, Users, ArrowRight } from "lucide-react"
import Link from "next/link"
import { notFound } from "next/navigation"
import { Metadata } from "next"
import ContactForm from "@/components/contact-form"

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://service-egy.com'

export function generateStaticParams() {
  return [
    { serviceId: "washing-machines" },
    { serviceId: "refrigerators" },
    { serviceId: "dishwashers" },
    { serviceId: "microwaves" },
    { serviceId: "dryers" },
  ]
}

export function generateMetadata({ params }: { params: { serviceId: string } }): Metadata {
  const service = servicesData[params.serviceId as keyof typeof servicesData]
  
  if (!service) {
    return {
      title: "الصفحة غير موجودة",
      description: "الخدمة المطلوبة غير موجودة",
    }
  }

  return {
    title: service.title,
    description: `${service.description}. ${service.hero.subtitle}. صيانة معتمدة، فنيون محترفون، قطع غيار أصلية، ضمان مكتوب. متوفر في جميع محافظات مصر.`,
    keywords: [
      service.title,
      `صيانة ${service.title}`,
      `إصلاح ${service.title}`,
      "صيانة معتمدة",
      "فني صيانة معتمد",
      "صيانة مصر",
    ],
    openGraph: {
      title: `${service.title} - Service Egy`,
      description: service.hero.subtitle,
      url: `${baseUrl}/services/${params.serviceId}`,
      images: [service.image ? `${baseUrl}${service.image}` : `${baseUrl}/placeholder.svg`],
    },
    alternates: {
      canonical: `/services/${params.serviceId}`,
    },
  }
}

const servicesData = {
  "washing-machines": {
    title: "صيانة غسالات الملابس",
    description: "خدمات صيانة شاملة ومتخصصة لجميع أنواع غسالات الملابس",
    image: "/professional-technician-repairing-washing-machine.jpg",
    hero: {
      title: "صيانة غسالات الملابس الاحترافية",
      subtitle: "نوفر خدمات صيانة متكاملة لجميع أنواع وماركات غسالات الملابس بأعلى معايير الجودة",
    },
    sections: [
      {
        title: "خدماتنا الشاملة",
        icon: Wrench,
        content: [
          "فحص شامل للغسالة وتشخيص دقيق للأعطال",
          "إصلاح وصيانة المحرك والموتور",
          "استبدال وإصلاح الحلة الداخلية",
          "صيانة نظام التصريف والمضخة",
          "إصلاح لوحة التحكم الإلكترونية",
          "استبدال السيور والبكرات",
          "صيانة نظام التسخين",
          "إصلاح باب الغسالة والمفصلات",
          "تنظيف الفلاتر والمصافي",
          "معايرة وضبط برامج الغسيل",
        ],
      },
      {
        title: "الأعطال الشائعة التي نعالجها",
        icon: CheckCircle,
        content: [
          "الغسالة لا تعمل أو لا تبدأ دورة الغسيل",
          "عدم تصريف المياه بشكل صحيح",
          "اهتزاز وأصوات غير طبيعية أثناء التشغيل",
          "تسرب المياه من الغسالة",
          "عدم دوران الحلة أو الدوران البطيء",
          "مشاكل في التسخين أو عدم تسخين المياه",
          "رسائل خطأ على الشاشة الرقمية",
          "عدم فتح أو إغلاق الباب بشكل صحيح",
          "رائحة كريهة من الغسالة",
          "استهلاك كهرباء عالي بشكل غير طبيعي",
        ],
      },
      {
        title: "عملية الصيانة المتخصصة",
        icon: Users,
        content: [
          "الفحص الأولي: يقوم فنيونا بفحص شامل للغسالة لتحديد المشكلة بدقة",
          "التشخيص الدقيق: استخدام أحدث الأجهزة لتشخيص الأعطال الإلكترونية والميكانيكية",
          "تقديم التقرير: شرح مفصل للعطل والحلول المقترحة مع تقدير التكلفة",
          "الإصلاح الاحترافي: تنفيذ الإصلاحات باستخدام قطع غيار أصلية ومعتمدة",
          "الاختبار الشامل: تجربة جميع برامج الغسيل للتأكد من عمل الغسالة بكفاءة",
          "التنظيف والصيانة الوقائية: تنظيف شامل وفحص الأجزاء الأخرى",
          "الضمان المكتوب: تقديم ضمان مكتوب على الخدمة وقطع الغيار",
        ],
      },
      {
        title: "الماركات التي نخدمها",
        icon: Award,
        content: [
          "LG - صيانة معتمدة لجميع موديلات غسالات إل جي",
          "Samsung - خبرة واسعة في صيانة غسالات سامسونج",
          "Bosch - متخصصون في الغسالات الألمانية بوش",
          "Ariston - صيانة احترافية لغسالات أريستون",
          "Whirlpool - خدمات متكاملة لغسالات ويرلبول",
          "Zanussi - فنيون معتمدون لصيانة زانوسي",
          "Indesit - خبرة طويلة مع غسالات إنديست",
          "Kiriazi - متخصصون في الماركات المصرية كريازي",
          "Fresh - صيانة شاملة لغسالات فريش",
          "Universal - خدمات معتمدة لغسالات يونيفرسال",
        ],
      },
      {
        title: "لماذا تختار خدماتنا؟",
        icon: Shield,
        content: [
          "فنيون معتمدون ومدربون على أعلى مستوى",
          "استخدام قطع غيار أصلية 100% من المصنع",
          "ضمان مكتوب لمدة 12 شهر على الخدمة والقطع",
          "استجابة سريعة خلال 24 ساعة",
          "أسعار تنافسية وشفافة بدون تكاليف خفية",
          "خدمة عملاء متاحة 7 أيام في الأسبوع",
          "تغطية شاملة لجميع محافظات مصر",
          "تقارير فنية مفصلة بعد كل زيارة",
          "نصائح وإرشادات للحفاظ على الغسالة",
          "متابعة دورية بعد الصيانة",
        ],
      },
    ],
  },
  refrigerators: {
    title: "صيانة الثلاجات والديب فريزر",
    description: "خدمات صيانة متخصصة لجميع أنواع الثلاجات وأجهزة التبريد",
    image: "/refrigerator-repair-technician.jpg",
    hero: {
      title: "صيانة الثلاجات والديب فريزر المتخصصة",
      subtitle: "نقدم حلول صيانة شاملة لجميع مشاكل التبريد والتجميد بخبرة تمتد لسنوات",
    },
    sections: [
      {
        title: "خدمات الصيانة المتكاملة",
        icon: Wrench,
        content: [
          "فحص وإصلاح دائرة التبريد الكاملة",
          "شحن وإعادة شحن غاز الفريون",
          "صيانة وإصلاح الكمبروسر (الضاغط)",
          "إصلاح الثرموستات ومنظم الحرارة",
          "صيانة المروحة والموتور",
          "إصلاح نظام الإضاءة الداخلية",
          "استبدال الجوان والعوازل",
          "صيانة نظام إذابة الثلج",
          "إصلاح الأدراج والرفوف",
          "تنظيف وصيانة المكثف والمبخر",
        ],
      },
      {
        title: "المشاكل الشائعة وحلولها",
        icon: CheckCircle,
        content: [
          "الثلاجة لا تبرد بشكل كافٍ أو لا تبرد نهائياً",
          "تكون الثلج بشكل مفرط داخل الفريزر",
          "تسرب المياه من الثلاجة",
          "أصوات غير طبيعية أثناء التشغيل",
          "الكمبروسر يعمل بشكل متواصل دون توقف",
          "الباب لا يغلق بإحكام",
          "رائحة كريهة داخل الثلاجة",
          "استهلاك كهرباء عالي",
          "عدم عمل الإضاءة الداخلية",
          "مشاكل في شاشة التحكم الرقمية",
        ],
      },
      {
        title: "منهجية العمل الاحترافية",
        icon: Users,
        content: [
          "الفحص الشامل: تقييم كامل لحالة الثلاجة ونظام التبريد",
          "قياس الضغط والحرارة: استخدام أجهزة قياس متطورة لتحديد المشكلة",
          "كشف التسريب: فحص دقيق لاكتشاف أي تسريب في دائرة التبريد",
          "الإصلاح المتخصص: تنفيذ الإصلاحات بأعلى معايير الجودة",
          "اختبار الأداء: التأكد من كفاءة التبريد والتجميد",
          "الصيانة الوقائية: فحص جميع الأجزاء وتنظيفها",
          "الضمان الشامل: ضمان مكتوب على الخدمة والقطع المستبدلة",
        ],
      },
      {
        title: "الماركات المتخصصة",
        icon: Award,
        content: [
          "LG - صيانة معتمدة لثلاجات إل جي بجميع أنواعها",
          "Samsung - خبراء في صيانة ثلاجات سامسونج",
          "Toshiba - متخصصون في ثلاجات توشيبا",
          "Sharp - صيانة احترافية لثلاجات شارب",
          "Kiriazi - خدمات متكاملة للماركة المصرية كريازي",
          "Fresh - صيانة شاملة لثلاجات فريش",
          "White Whale - فنيون معتمدون لصيانة وايت ويل",
          "Zanussi - خبرة واسعة في ثلاجات زانوسي",
          "Beko - متخصصون في صيانة بيكو",
          "Electrolux - صيانة معتمدة لإلكترولوكس",
        ],
      },
      {
        title: "مميزات خدماتنا",
        icon: Shield,
        content: [
          "فنيون متخصصون في أنظمة التبريد والتكييف",
          "معدات وأدوات حديثة للفحص والإصلاح",
          "قطع غيار أصلية معتمدة من الوكلاء",
          "ضمان 12 شهر على جميع الخدمات",
          "خدمة طوارئ متاحة على مدار الساعة",
          "أسعار عادلة ومنافسة",
          "تقارير فنية تفصيلية",
          "نصائح للحفاظ على كفاءة الثلاجة",
          "خدمة الصيانة الدورية المجدولة",
          "تغطية جميع مناطق مصر",
        ],
      },
    ],
  },
  dishwashers: {
    title: "صيانة غسالات الأطباق",
    description: "خدمات صيانة متخصصة لجميع أنواع غسالات الأطباق",
    image: "/dishwasher-repair-service.jpg",
    hero: {
      title: "صيانة غسالات الأطباق الاحترافية",
      subtitle: "حلول متكاملة لجميع مشاكل غسالات الأطباق مع ضمان الجودة والكفاءة",
    },
    sections: [
      {
        title: "خدمات الصيانة الشاملة",
        icon: Wrench,
        content: [
          "فحص وإصلاح نظام الرش والتوزيع",
          "صيانة مضخة المياه والتصريف",
          "إصلاح نظام التسخين والتجفيف",
          "صيانة لوحة التحكم الإلكترونية",
          "استبدال الفلاتر والمصافي",
          "إصلاح نظام قفل الباب",
          "صيانة ذراع الرش العلوي والسفلي",
          "إصلاح صمامات المياه",
          "تنظيف وصيانة السخان",
          "معايرة برامج الغسيل",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: CheckCircle,
        content: [
          "الغسالة لا تملأ بالماء أو تملأ ببطء",
          "عدم تصريف المياه بشكل كامل",
          "الأطباق لا تنظف بشكل جيد",
          "تسرب المياه من الباب أو القاعدة",
          "أصوات غريبة أثناء التشغيل",
          "عدم تسخين المياه",
          "الأطباق لا تجف بشكل كامل",
          "رسائل خطأ على الشاشة",
          "رائحة كريهة من الغسالة",
          "الباب لا يغلق بإحكام",
        ],
      },
      {
        title: "إجراءات الصيانة",
        icon: Users,
        content: [
          "الفحص الأولي الشامل لجميع الأنظمة",
          "اختبار ضغط المياه والتدفق",
          "فحص النظام الكهربائي والإلكتروني",
          "تنظيف عميق للفلاتر والمصافي",
          "اختبار جميع برامج الغسيل",
          "فحص نظام التسخين والتجفيف",
          "معايرة أذرع الرش",
          "الضمان المكتوب على الخدمة",
        ],
      },
      {
        title: "الماركات المدعومة",
        icon: Award,
        content: [
          "Bosch - صيانة معتمدة لغسالات بوش",
          "Siemens - خبراء في صيانة سيمنس",
          "Ariston - متخصصون في أريستون",
          "Indesit - صيانة شاملة لإنديست",
          "Whirlpool - خدمات معتمدة لويرلبول",
          "Beko - فنيون متخصصون في بيكو",
          "Candy - صيانة احترافية لكاندي",
          "Electrolux - خبرة واسعة في إلكترولوكس",
          "Zanussi - متخصصون في زانوسي",
          "Samsung - صيانة معتمدة لسامسونج",
        ],
      },
      {
        title: "ضمانات الجودة",
        icon: Shield,
        content: [
          "فنيون مدربون على أحدث التقنيات",
          "قطع غيار أصلية معتمدة",
          "ضمان 12 شهر شامل",
          "استجابة سريعة خلال 24 ساعة",
          "أسعار شفافة ومنافسة",
          "خدمة عملاء متميزة",
          "تقارير فنية مفصلة",
          "نصائح للاستخدام الأمثل",
          "صيانة دورية مجدولة",
          "تغطية شاملة لكل مصر",
        ],
      },
    ],
  },
  microwaves: {
    title: "صيانة الميكروويف",
    description: "خدمات صيانة متخصصة لجميع أنواع أفران الميكروويف",
    image: "/microwave-oven-repair.jpg",
    hero: {
      title: "صيانة أفران الميكروويف المتخصصة",
      subtitle: "إصلاح احترافي لجميع أعطال الميكروويف مع ضمان السلامة والكفاءة",
    },
    sections: [
      {
        title: "خدمات الصيانة المتكاملة",
        icon: Wrench,
        content: [
          "فحص وإصلاح المغنطرون (Magnetron)",
          "صيانة المحول الكهربائي عالي الجهد",
          "إصلاح لوحة التحكم والشاشة",
          "استبدال الصمام الثنائي عالي الجهد",
          "صيانة موتور الدوران",
          "إصلاح نظام الإضاءة الداخلية",
          "استبدال الباب والمفصلات",
          "صيانة مروحة التبريد",
          "إصلاح نظام القفل الآمن",
          "معايرة مستويات الطاقة",
        ],
      },
      {
        title: "المشاكل الشائعة",
        icon: CheckCircle,
        content: [
          "الميكروويف لا يسخن الطعام",
          "توقف الدوران أثناء التشغيل",
          "أصوات غريبة أو طقطقة",
          "شرارات داخل الفرن",
          "الشاشة لا تعمل أو تعرض أخطاء",
          "الباب لا يغلق بشكل صحيح",
          "رائحة احتراق أثناء التشغيل",
          "الإضاءة الداخلية لا تعمل",
          "التسخين غير متساوٍ",
          "الميكروويف يفصل تلقائياً",
        ],
      },
      {
        title: "بروتوكول الصيانة",
        icon: Users,
        content: [
          "فحص السلامة الكهربائية أولاً",
          "اختبار مستوى الإشعاع والتسريب",
          "فحص المغنطرون والمحول",
          "اختبار لوحة التحكم",
          "فحص نظام القفل الآمن",
          "تنظيف شامل للداخل والخارج",
          "اختبار الأداء بعد الإصلاح",
          "ضمان مكتوب على الخدمة",
        ],
      },
      {
        title: "الماركات المتخصصة",
        icon: Award,
        content: [
          "Samsung - صيانة معتمدة لميكروويف سامسونج",
          "LG - خبراء في صيانة إل جي",
          "Sharp - متخصصون في شارب",
          "Panasonic - صيانة شاملة لباناسونيك",
          "Toshiba - خدمات معتمدة لتوشيبا",
          "Daewoo - فنيون متخصصون في دايو",
          "Kenwood - صيانة احترافية لكينوود",
          "Ariston - خبرة واسعة في أريستون",
          "Fresh - متخصصون في فريش",
          "Tornado - صيانة معتمدة لتورنيدو",
        ],
      },
      {
        title: "معايير الأمان والجودة",
        icon: Shield,
        content: [
          "فنيون معتمدون في الأجهزة الإلكترونية",
          "معدات فحص متطورة للسلامة",
          "قطع غيار أصلية آمنة",
          "ضمان 12 شهر على الخدمة",
          "اختبارات سلامة صارمة",
          "أسعار عادلة وشفافة",
          "خدمة سريعة خلال 24 ساعة",
          "تقارير فنية مفصلة",
          "إرشادات الاستخدام الآمن",
          "تغطية جميع المحافظات",
        ],
      },
    ],
  },
  dryers: {
    title: "صيانة المجففات",
    description: "خدمات صيانة متخصصة لجميع أنواع مجففات الملابس",
    image: "/clothes-dryer-repair.png",
    hero: {
      title: "صيانة مجففات الملابس الاحترافية",
      subtitle: "حلول شاملة لجميع مشاكل التجفيف مع ضمان الكفاءة والأمان",
    },
    sections: [
      {
        title: "خدمات الصيانة الشاملة",
        icon: Wrench,
        content: [
          "فحص وإصلاح نظام التسخين",
          "صيانة المحرك والحزام",
          "إصلاح نظام التهوية والعادم",
          "صيانة الثرموستات وأجهزة الاستشعار",
          "تنظيف وصيانة الفلاتر",
          "إصلاح لوحة التحكم الإلكترونية",
          "استبدال البكرات والمحامل",
          "صيانة نظام الدوران",
          "إصلاح الباب والمفصلات",
          "معايرة برامج التجفيف",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: CheckCircle,
        content: [
          "المجفف لا يسخن أو التسخين ضعيف",
          "الملابس لا تجف بشكل كامل",
          "أصوات غريبة أثناء التشغيل",
          "المجفف لا يدور",
          "توقف المجفف أثناء العمل",
          "رائحة احتراق من المجفف",
          "استهلاك كهرباء عالي",
          "الباب لا يغلق بإحكام",
          "رسائل خطأ على الشاشة",
          "تراكم الوبر بشكل مفرط",
        ],
      },
      {
        title: "منهجية الصيانة",
        icon: Users,
        content: [
          "الفحص الشامل لنظام التسخين",
          "اختبار المحرك والحزام",
          "فحص نظام التهوية والعادم",
          "تنظيف عميق للفلاتر والمجاري",
          "اختبار أجهزة الاستشعار",
          "فحص النظام الكهربائي",
          "اختبار جميع برامج التجفيف",
          "ضمان مكتوب على الخدمة",
        ],
      },
      {
        title: "الماركات المدعومة",
        icon: Award,
        content: [
          "LG - صيانة معتمدة لمجففات إل جي",
          "Samsung - خبراء في صيانة سامسونج",
          "Bosch - متخصصون في بوش",
          "Whirlpool - صيانة شاملة لويرلبول",
          "Electrolux - خدمات معتمدة لإلكترولوكس",
          "Beko - فنيون متخصصون في بيكو",
          "Zanussi - صيانة احترافية لزانوسي",
          "Ariston - خبرة واسعة في أريستون",
          "Indesit - متخصصون في إنديست",
          "Candy - صيانة معتمدة لكاندي",
        ],
      },
      {
        title: "ضمانات الخدمة",
        icon: Shield,
        content: [
          "فنيون مدربون على أعلى مستوى",
          "قطع غيار أصلية معتمدة",
          "ضمان 12 شهر شامل",
          "استجابة سريعة خلال 24 ساعة",
          "أسعار تنافسية وشفافة",
          "خدمة عملاء ممتازة",
          "تقارير فنية تفصيلية",
          "نصائح للصيانة الوقائية",
          "خدمة دورية مجدولة",
          "تغطية كاملة لمصر",
        ],
      },
    ],
  },
}

export default function ServiceDetailPage({ params }: { params: { serviceId: string } }) {
  const service = servicesData[params.serviceId as keyof typeof servicesData]

  if (!service) {
    notFound()
  }

  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#2563eb] to-[#3b82f6] text-white py-20 px-6 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        </div>
        <div className="max-w-7xl mx-auto relative z-10">
          <Link
            href="/services"
            className="inline-flex items-center gap-2 text-blue-100 hover:text-white mb-6 transition-colors"
          >
            <ArrowRight className="w-5 h-5" />
            العودة إلى الخدمات
          </Link>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-balance">{service.hero.title}</h1>
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl leading-relaxed">{service.hero.subtitle}</p>
        </div>
      </section>

      {/* Service Sections */}
      <section className="py-16 px-6">
        <div className="max-w-7xl mx-auto space-y-16">
          {service.sections.map((section, index) => {
            const Icon = section.icon
            const isEven = index % 2 === 0
            return (
              <div
                key={index}
                className={`grid md:grid-cols-2 gap-8 items-center ${isEven ? "" : "md:grid-flow-dense"}`}
              >
                <div className={isEven ? "" : "md:col-start-2"}>
                  <div className="flex items-center gap-4 mb-6">
                    <div className="bg-[#2563eb] p-4 rounded-xl">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h2 className="text-3xl md:text-4xl font-bold text-[#2563eb]">{section.title}</h2>
                  </div>
                  <div className="bg-[#F5F7FA] p-8 rounded-2xl">
                    <ul className="space-y-4">
                      {section.content.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <CheckCircle className="w-6 h-6 text-[#2563eb] flex-shrink-0 mt-1" />
                          <span className="text-[#475569] leading-relaxed">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <div className={isEven ? "" : "md:col-start-1 md:row-start-1"}>
                  <div className="relative h-96 rounded-2xl overflow-hidden shadow-2xl">
                    <img
                      src={service.image || "/placeholder.svg"}
                      alt={section.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#2563eb]/20 to-transparent"></div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </section>

      {/* Contact Form Section */}
      <ContactForm serviceType={service.title} />

      {/* CTA Section */}
      <section className="py-16 px-6 bg-gradient-to-br from-[#2563eb] to-[#3b82f6]">
        <div className="max-w-4xl mx-auto text-center text-white">
          <Clock className="w-16 h-16 mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-6">هل تحتاج إلى خدمة الصيانة؟</h2>
          <p className="text-xl text-blue-100 mb-8 leading-relaxed">
            فريقنا جاهز للرد على استفساراتك وتقديم الخدمة خلال 24 ساعة
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:01110195560"
              className="bg-white text-[#2563eb] px-8 py-4 rounded-full font-bold hover:shadow-lg transition-all hover:scale-105 flex items-center justify-center gap-3"
            >
              <Phone className="w-5 h-5" />
              اتصل الآن: 01110195560
            </a>
            <Link
              href="/contact"
              className="border-2 border-white text-white px-8 py-4 rounded-full font-bold hover:bg-white/10 transition-all flex items-center justify-center gap-3"
            >
              <Mail className="w-5 h-5" />
              أرسل استفسار
            </Link>
          </div>
        </div>
      </section>
    </main>
  )
}
