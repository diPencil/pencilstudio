import { Metadata } from "next"

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://service-egy.com'

export const metadata: Metadata = {
  title: "خدماتنا",
  description: "Service Egy تقدم خدمات صيانة شاملة لجميع الأجهزة المنزلية: صيانة غسالات، ثلاجات، ميكروويف، غسالات أطباق، مجففات. فنيون معتمدون، قطع غيار أصلية، ضمان مكتوب.",
  keywords: [
    "صيانة غسالات",
    "صيانة ثلاجات",
    "صيانة ميكروويف",
    "صيانة غسالات أطباق",
    "صيانة مجففات",
    "خدمات صيانة مصر"
  ],
  openGraph: {
    title: "خدماتنا - Service Egy",
    description: "خدمات صيانة شاملة لجميع الأجهزة المنزلية",
    url: `${baseUrl}/services`,
  },
  alternates: {
    canonical: "/services",
  },
}

export default function ServicesLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}





