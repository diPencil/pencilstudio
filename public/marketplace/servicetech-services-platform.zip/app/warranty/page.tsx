import { Shield, CheckCircle, Clock, Phone } from "lucide-react"
import { Metadata } from "next"
import TestimonialsSlider from "@/components/testimonials-slider"

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://service-egy.com'

export const metadata: Metadata = {
  title: "الضمان وخدمة ما بعد الصيانة",
  description: "تعرف على نظام الضمان الشامل في Service Egy. ضمان مكتوب على جميع الخدمات والقطع الأصلية لمدة 12 شهر. متابعة دورية وخدمة مجانية في حالة تكرار العطل.",
  keywords: [
    "ضمان الصيانة",
    "ضمان Service Egy",
    "ضمان قطع الغيار",
    "متابعة بعد الصيانة",
    "خدمة ما بعد الصيانة"
  ],
  openGraph: {
    title: "الضمان وخدمة ما بعد الصيانة - Service Egy",
    description: "نظام ضمان شامل على جميع خدمات الصيانة والقطع الأصلية لمدة 12 شهر",
    url: `${baseUrl}/warranty`,
  },
  alternates: {
    canonical: "/warranty",
  },
}

export default function Warranty() {
  return (
    <main className="min-h-screen">
      {/* Hero */}
      <section className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-5xl font-bold mb-4">الضمان وخدمة ما بعد الصيانة</h1>
          <p className="text-xl text-blue-100">ثقتك هي رأس مالنا الحقيقي</p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16 px-6 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="space-y-8">
            {/* Main Info */}
            <div className="bg-[#F5F7FA] p-8 rounded-xl">
              <p className="text-[#707070] leading-relaxed mb-4">
                كل عملية صيانة تتم من خلال Service Egy تشمل شهادة ضمان معتمدة على الخدمة والقطع.
              </p>
              <p className="text-[#707070] leading-relaxed">
                نقدّم متابعة بعد الصيانة لضمان استمرار الأداء بنفس الكفاءة، وإذا تكرّر العطل، يتم إرسال فني مختص مجانًا دون
                أي رسوم.
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white border-2 border-[#2563eb] p-6 rounded-xl">
                <div className="flex items-center gap-3 mb-4">
                  <Shield className="w-6 h-6 text-[#2563eb]" />
                  <h3 className="text-xl font-bold text-[#2563eb]">شهادة ضمان معتمدة</h3>
                </div>
                <p className="text-[#707070]">على الخدمة والقطع المستخدمة مع توثيق كامل</p>
              </div>

              <div className="bg-white border-2 border-[#2563eb] p-6 rounded-xl">
                <div className="flex items-center gap-3 mb-4">
                  <CheckCircle className="w-6 h-6 text-[#2563eb]" />
                  <h3 className="text-xl font-bold text-[#2563eb]">متابعة دورية</h3>
                </div>
                <p className="text-[#707070]">للتأكد من استمرار الأداء بنفس الكفاءة</p>
              </div>

              <div className="bg-white border-2 border-[#2563eb] p-6 rounded-xl">
                <div className="flex items-center gap-3 mb-4">
                  <Clock className="w-6 h-6 text-[#2563eb]" />
                  <h3 className="text-xl font-bold text-[#2563eb]">خدمة مجانية</h3>
                </div>
                <p className="text-[#707070]">في حالة تكرار العطل خلال فترة الضمان</p>
              </div>

              <div className="bg-white border-2 border-[#2563eb] p-6 rounded-xl">
                <div className="flex items-center gap-3 mb-4">
                  <Phone className="w-6 h-6 text-[#2563eb]" />
                  <h3 className="text-xl font-bold text-[#2563eb]">دعم فني متاح</h3>
                </div>
                <p className="text-[#707070]">من 9 صباحاً إلى 9 مساءً يومياً</p>
              </div>
            </div>

            {/* System Info */}
            <div className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white p-8 rounded-xl">
              <h3 className="text-2xl font-bold mb-4">نظامنا الإلكتروني</h3>
              <p className="text-blue-100 leading-relaxed">
                نظامنا الإلكتروني يسجّل كل بيانات العملاء لتتبع الحالة بدقة، مما يضمن تقديم خدمة متسقة وموثوقة في كل مرة.
              </p>
            </div>
          </div>
        </div>
      </section>

      <TestimonialsSlider />
    </main>
  )
}
