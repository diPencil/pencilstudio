import { MetadataRoute } from 'next'
import { generateStaticParams as generateBrandParams } from './maintenance-center/[brandSlug]/page'
import { generateStaticParams as generateServiceParams } from './services/[serviceId]/page'

export const dynamic = 'force-static'

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://service-egy.com'

export default function sitemap(): MetadataRoute.Sitemap {
  const brandParams = generateBrandParams()
  const serviceParams = generateServiceParams()
  const brandSlugs = brandParams.map((item) => item.brandSlug)
  const services = serviceParams.map((item) => item.serviceId)
  const staticPages = [
    '',
    '/about',
    '/maintenance-center',
    '/services',
    '/contact',
    '/faq',
    '/warranty',
    '/privacy-policy',
    '/terms-and-conditions',
    '/thank-you',
  ]

  const pages: MetadataRoute.Sitemap = [
    ...staticPages.map((page) => ({
      url: `${baseUrl}${page}`,
      lastModified: new Date(),
      changeFrequency: page === '' ? 'daily' : 'weekly',
      priority: page === '' ? 1 : 0.8,
    })),
    ...brandSlugs.map((slug) => ({
      url: `${baseUrl}/maintenance-center/${slug}`,
      lastModified: new Date(),
      changeFrequency: 'weekly' as const,
      priority: 0.7,
    })),
    ...services.map((service) => ({
      url: `${baseUrl}/services/${service}`,
      lastModified: new Date(),
      changeFrequency: 'weekly' as const,
      priority: 0.7,
    })),
  ]

  return pages
}

