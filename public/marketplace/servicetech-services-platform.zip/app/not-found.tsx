import Link from 'next/link'
import { Home, Search } from 'lucide-react'

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-blue-50 px-6">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Search className="w-8 h-8 text-[#2563eb]" />
        </div>
        <h1 className="text-5xl font-bold text-gray-900 mb-4">404</h1>
        <h2 className="text-2xl font-bold text-gray-800 mb-4">الصفحة غير موجودة</h2>
        <p className="text-gray-600 mb-8">
          عذراً، الصفحة التي تبحث عنها غير موجودة أو تم نقلها.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/"
            className="bg-[#2563eb] text-white px-6 py-3 rounded-full font-semibold hover:bg-[#1d4ed8] transition-colors flex items-center justify-center gap-2"
          >
            <Home className="w-5 h-5" />
            العودة للرئيسية
          </Link>
          <Link
            href="/services"
            className="border-2 border-[#2563eb] text-[#2563eb] px-6 py-3 rounded-full font-semibold hover:bg-[#F5F7FA] transition-colors"
          >
            عرض الخدمات
          </Link>
        </div>
      </div>
    </div>
  )
}




