"use client"

import Link from "next/link"
import TestimonialsSlider from "@/components/testimonials-slider"
import { maintenanceCenterBrands } from "@/data/maintenance-center-brands"

export default function MaintenanceCentersPage() {
  const brands = maintenanceCenterBrands

  return (
    <main className="min-h-screen">
      {/* Hero */}
      <section className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-5xl font-bold mb-4">مراكز الصيانة والخدمة</h1>
          <p className="text-xl text-blue-100">شبكة مراكز معتمدة لخدمة أهم العلامات العالمية والمصرية داخل مصر</p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="bg-[#F5F7FA] p-8 rounded-xl mb-12">
            <p className="text-[#707070] leading-relaxed mb-4">
              يتم تدريب الفنيين وفق تعليمات المصنّع الأصلية لكل علامة لضمان جودة مطابقة للمعايير العالمية.
            </p>
            <p className="text-[#707070] leading-relaxed">
              فريقنا متخصص في التعامل مع جميع الماركات المشهورة والموثوقة في السوق المصري.
            </p>
          </div>

          {/* Brands Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {brands.map((brand) => (
              <Link key={brand.id} href={`/maintenance-center/${brand.id}-repair`} className="group text-right">
                <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                  <div className="h-48 bg-gradient-to-br from-[#2563eb] to-[#3b82f6] overflow-hidden">
                    <img
                      src={brand.image || "/placeholder.svg"}
                      alt={brand.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-2xl font-bold text-[#2563eb] mb-2">{brand.name}</h3>
                    <p className="text-[#707070] text-sm leading-relaxed">{brand.description}</p>
                    <div className="mt-4 text-[#2563eb] font-semibold group-hover:translate-x-2 transition-transform">
                      اعرف المزيد ←
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {/* Additional Info */}
          <div className="bg-gradient-to-r from-[#2563eb] to-[#3b82f6] text-white p-8 rounded-xl">
            <h3 className="text-2xl font-bold mb-4">لماذا نحن الخيار الأفضل؟</h3>
            <ul className="space-y-3">
              {[
                "خبرة واسعة مع جميع الماركات العالمية والمصرية",
                "تدريب دوري على أحدث التقنيات والمعايير",
                "استخدام قطع غيار أصلية معتمدة من المصنعين",
                "ضمان مكتوب على كل خدمة وقطعة غيار",
                "فنيون معتمدون من المصنعين الأصليين",
              ].map((item, idx) => (
                <li key={idx} className="flex items-center gap-3">
                  <span className="text-blue-200 text-xl">✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Testimonials Slider */}
      <TestimonialsSlider />
    </main>
  )
}











