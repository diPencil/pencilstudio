import { Metadata } from "next"
import type React from "react"
import TopBar from "@/components/top-bar"

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://service-egy.com'

export const metadata: Metadata = {
  title: "مراكز الصيانة والخدمة",
  description:
    "Service Egy تقدم شبكة مراكز صيانة وخدمة متخصصة لأشهر العلامات العالمية والمصرية في الأجهزة المنزلية. فنيون خبراء، قطع غيار أصلية، وضمان مكتوب.",
  keywords: [
    "مركز صيانة",
    "مراكز صيانة معتمدة",
    "صيانة أجهزة منزلية",
    "خدمة صيانة فورية",
    "صيانة الماركات العالمية",
    "خدمة صيانة مصر",
  ],
  openGraph: {
    title: "مراكز الصيانة والخدمة - Service Egy",
    description: "شبكة مراكز صيانة متخصصة لخدمة أهم العلامات العالمية والمصرية",
    url: `${baseUrl}/maintenance-center`,
  },
  alternates: {
    canonical: "/maintenance-center",
  },
}

export default function BrandsLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // This layout will wrap children with TopBar only (no Navigation/Footer)
  // The Root Layout will conditionally hide Navigation/Footer based on pathname
  return (
    <>
      <div className="sticky top-0 z-50">
        <TopBar />
      </div>
      {children}
    </>
  )
}





