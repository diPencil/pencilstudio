import { Phone, Mail, CheckCircle, Shield, Award, Wrench, Clock, MapPin, MessageCircle } from "lucide-react"
import { notFound } from "next/navigation"
import { Metadata } from "next"
import Image from "next/image"
import ContactForm from "@/components/contact-form"
import MaintenanceCTASection from "@/components/maintenance-cta-section"
import MaintenanceHeroButtons from "@/components/maintenance-hero-buttons"

const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://service-egy.com'

// Section image assets available in /public for quick reference:
// professional-technician-repairing-washing-machine.jpg
// washing-machine-repair-technician.jpg
// refrigerator-repair-service.jpg
// happy-egyptian-male-customer-smiling.jpg
// happy-middle-aged-egyptian-man.jpg
// placeholder.jpg

const brandIds = [
  "lg",
  "kiriazi",
  "universal",
  "fresh",
  "gree",
  "power",
  "union-air",
  "carrier",
  "york",
  "white-whale",
  "white-point",
  "samsung",
  "ariston",
  "frigidaire",
  "general-electric",
  "vaguer",
  "westinghouse",
  "white-westinghouse",
  "kelvinator",
  "siemens",
  "zanussi",
  "ideal",
  "sharp",
  "toshiba",
  "hitachi",
  "alaska",
  "hoover",
  "daewoo",
  "electrolux",
  "electrostar",
  "beko",
  "whirlpool",
  "bosch",
  "indesit",
  "candy",
  "basab",
  "haier",
  "geronji",
  "miele",
] as const

const brandSlug = (id: string) => `${id}-repair`

export function generateStaticParams() {
  return brandIds.map((id) => ({ brandSlug: brandSlug(id) }))
}

function generateSectionCardTitle(sectionTitle: string, brandName: string) {
  const normalized = sectionTitle.trim()

  if (normalized.includes("تاريخ") || normalized.startsWith("عن")) {
    return `نبذة مختصرة عن ${brandName}`
  }

  if (normalized.includes("خدمات") || normalized.includes("الصيانة")) {
    return `حلول صيانة ${brandName} المتخصصة`
  }

  if (normalized.includes("مميزات") || normalized.includes("مزايا")) {
    return `أبرز مميزات ${brandName}`
  }

  if (normalized.includes("التقنيات") || normalized.includes("التكنولوجيا") || normalized.includes("تقنية")) {
    return `تقنيات ${brandName} المبتكرة`
  }

  if (normalized.includes("الأعطال") || normalized.includes("المشاكل") || normalized.includes("الأعراض")) {
    return `أعطال ${brandName} التي نعالجها`
  }

  if (normalized.includes("خبرتنا") || normalized.includes("لماذا") || normalized.includes("ضمانات")) {
    return `ثقتك في فريق ${brandName}`
  }

  return `نظرة عامة على ${normalized}`
}

function getSectionDefaultImage(sectionTitle: string, fallback?: string) {
  const normalized = sectionTitle.trim()

  if (normalized.includes("عن") || normalized.includes("نبذة")) {
    return "/aboutrepair/عن الشركة.jpg"
  }

  if (normalized.includes("خدمات") || normalized.includes("الصيانة")) {
    return "/aboutrepair/خدمات الصيانة المتخصصة.jpg"
  }

  if (normalized.includes("مميزات") || normalized.includes("مزايا")) {
    return "/aboutrepair/التقنيات المتقدمة.jpg"
  }

  if (normalized.includes("التقنيات") || normalized.includes("التكنولوجيا") || normalized.includes("تقنية")) {
    return "/aboutrepair/التقنيات المتقدمة.jpg"
  }

  if (normalized.includes("الأعطال") || normalized.includes("المشاكل") || normalized.includes("الحلول")) {
    return "/aboutrepair/الأعطال الشائعة وحلولها.jpg"
  }

  if (normalized.includes("لماذا") || normalized.includes("خبرتنا") || normalized.includes("ضمانات") || normalized.includes("ثقتك")) {
    return "/aboutrepair/لماذا نحن لأفضل.jpg"
  }

  return fallback ?? "/placeholder.jpg"
}

function getBrandIdFromSlug(slug: string) {
  if (!slug.endsWith("-repair")) {
    return undefined
  }
  const candidate = slug.slice(0, -"-repair".length)
  return (brandIds as readonly string[]).includes(candidate)
    ? (candidate as keyof typeof brandsData)
    : undefined
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ brandSlug: string }>
}): Promise<Metadata> {
  const { brandSlug } = await params
  const brandId = getBrandIdFromSlug(brandSlug)

  if (!brandId) {
    return {
      title: "الصفحة غير موجودة",
      description: "الماركة المطلوبة غير موجودة",
    }
  }

  const brand = brandsData[brandId]

  return {
    title: `صيانة ${brand.name} - ${brand.tagline}`,
    description: `${brand.hero.subtitle}. ${brand.description}. صيانة متخصصة في كل الماركات، قطع غيار أصلية، ضمان مكتوب. متوفر في جميع محافظات مصر.`,
    keywords: [
      `صيانة ${brand.name}`,
      `فني ${brand.name}`,
      `إصلاح ${brand.name}`,
      `صيانة متخصصة ${brand.name}`,
      brand.name,
    ],
    openGraph: {
      title: `صيانة ${brand.name} - ${brand.tagline} | Service Egy`,
      description: `${brand.hero.subtitle}. ${brand.description}. صيانة متخصصة في كل الماركات، قطع غيار أصلية، ضمان مكتوب.`,
      url: `${baseUrl}/maintenance-center/${brandSlug}`,
      images: [
        brand.heroImage ? `${baseUrl}${brand.heroImage}` : 
        brand.logo ? `${baseUrl}${brand.logo}` : 
        `${baseUrl}/professional-technician-repairing-washing-machine.jpg`
      ],
      type: 'website',
      locale: 'ar_EG',
      siteName: 'Service Egy',
    },
    twitter: {
      card: 'summary_large_image',
      title: `صيانة ${brand.name} - Service Egy`,
      description: brand.hero.subtitle,
      images: [
        brand.heroImage ? `${baseUrl}${brand.heroImage}` : 
        brand.logo ? `${baseUrl}${brand.logo}` : 
        `${baseUrl}/professional-technician-repairing-washing-machine.jpg`
      ],
    },
    alternates: {
      canonical: `/maintenance-center/${brandSlug}`,
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        'max-image-preview': 'large',
        'max-snippet': -1,
      },
    },
  }
}

const brandsData = {
  lg: {
    name: "LG",
    logo: "/maintenancecenter/lg-appliances-brand-logo.jpg",
    heroImage: "/centerlogo/LG.png",
    tagline: "الابتكار من أجل حياة أفضل",
    description: "LG هي واحدة من الشركات الرائدة عالمياً في مجال الأجهزة المنزلية والإلكترونيات الاستهلاكية",
    hero: {
      title: "مركز صيانة LG",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة LG مع ضمان الجودة والكفاءة",
    },
    sections: [
      {
        title: "عن شركة LG",
        icon: Award,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "تأسست شركة LG في كوريا الجنوبية عام 1958 وأصبحت من أكبر الشركات العالمية",
          "تشتهر LG بالابتكار والتكنولوجيا المتقدمة في جميع منتجاتها",
          "تقدم LG مجموعة واسعة من الأجهزة المنزلية بما في ذلك الغسالات والثلاجات والمكيفات",
          "حازت منتجات LG على العديد من الجوائز العالمية للتصميم والابتكار",
          "تلتزم LG بمعايير الجودة العالمية وحماية البيئة",
          "توفر LG تقنيات ذكية مثل ThinQ AI للتحكم في الأجهزة",
          "تتميز أجهزة LG بكفاءة استهلاك الطاقة العالية",
          "شبكة خدمة عملاء LG منتشرة في أكثر من 100 دولة حول العالم",
        ],
      },
      {
        title: "خدمات الصيانة المتخصصة",
        icon: Wrench,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "صيانة غسالات LG الأوتوماتيك بجميع أنواعها (فوق أوتوماتيك، فرونت لود)",
          "إصلاح ثلاجات LG بتقنية الإنفرتر والتبريد الذكي",
          "صيانة مكيفات LG بتقنية التبريد السريع",
          "إصلاح غسالات الأطباق LG بنظام البخار",
          "صيانة مجففات الملابس LG",
          "إصلاح أفران الميكروويف LG",
          "صيانة الشاشات الذكية والتلفزيونات LG",
          "خدمة الصيانة الدورية والوقائية",
          "استبدال قطع الغيار الأصلية المتخصصة من LG",
          "تحديث البرامج والأنظمة الذكية",
        ],
      },
      {
        title: "التقنيات المتقدمة في أجهزة LG",
        icon: CheckCircle,
        image: "/maintenancecenter/lg-appliances-brand-logo.jpg",
        content: [
          "تقنية الإنفرتر (Inverter) لتوفير الطاقة وتقليل الضوضاء",
          "نظام ThinQ AI للتحكم الذكي عبر الهاتف المحمول",
          "تقنية Direct Drive في الغسالات لأداء أفضل وعمر أطول",
          "نظام التبريد الخطي (Linear Cooling) في الثلاجات",
          "تقنية البخار (Steam) للتنظيف العميق والتعقيم",
          "نظام التشخيص الذكي (Smart Diagnosis) لاكتشاف الأعطال",
          "تقنية الضاغط الخطي (Linear Compressor) في الثلاجات",
          "نظام 6 Motion في الغسالات لعناية أفضل بالملابس",
          "تقنية TurboWash للغسيل السريع والفعال",
          "نظام Door Cooling+ للتبريد المتساوي في الثلاجات",
        ],
      },
      {
        title: "الأعطال الشائعة وحلولها",
        icon: Shield,
        content: [
          "مشاكل في نظام الإنفرتر والتحكم الإلكتروني - نوفر قطع غيار أصلية",
          "أعطال في المحرك Direct Drive - فنيون متخصصون في هذه التقنية",
          "مشاكل في نظام ThinQ والاتصال الذكي - خبراء في البرمجيات",
          "أعطال الضاغط الخطي في الثلاجات - صيانة متخصصة",
          "مشاكل في نظام البخار - إصلاح احترافي",
          "أعطال لوحة التحكم الرقمية - استبدال وإصلاح",
          "مشاكل في نظام التجفيف - تنظيف وصيانة",
          "أعطال في نظام القفل الذكي - إصلاح فوري",
          "مشاكل في المستشعرات الذكية - معايرة دقيقة",
          "أعطال في نظام التجفيف - صيانة شاملة",
        ],
        image: "/refrigerator-repair-service.jpg",
      },
      {
        title: "لماذا نحن الأفضل لصيانة LG؟",
        icon: Award,
        image: "/happy-egyptian-male-customer-smiling.jpg",
        content: [
          "فنيون معتمدون ومدربون من قبل LG على أحدث التقنيات",
          "نستخدم قطع غيار أصلية 100% معتمدة من LG",
          "خبرة تزيد عن 15 عاماً في صيانة أجهزة LG",
          "معدات تشخيص متطورة خاصة بأجهزة LG",
          "ضمان مكتوب لمدة 12 شهر على جميع الخدمات والقطع",
          "استجابة سريعة خلال 24 ساعة في جميع أنحاء مصر",
          "أسعار تنافسية وشفافة بدون تكاليف خفية",
          "خدمة عملاء متاحة 7 أيام في الأسبوع",
          "تقارير فنية مفصلة بعد كل زيارة",
          "متابعة دورية بعد الصيانة لضمان الأداء الأمثل",
          "نصائح وإرشادات للحفاظ على أجهزة LG",
          "خدمة الصيانة الدورية المجدولة بأسعار خاصة",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على قطع الغيار الأصلية + 6 أشهر على العمالة",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  kiriazi: {
    name: "كريازي",
    logo: "/maintenancecenter/kiriazi-appliances-egyptian-brand.jpg",
    heroImage: "/centerlogo/كريازي.png",
    tagline: "الماركة المصرية الأولى",
    description: "كريازي هي العلامة التجارية المصرية الرائدة في مجال الأجهزة المنزلية منذ عقود",
    hero: {
      title: "مركز صيانة كريازي",
      subtitle: "خدمات صيانة متخصصة للماركة المصرية الأولى في الأجهزة المنزلية",
    },
    sections: [
      {
        title: "تاريخ كريازي العريق",
        icon: Award,
        image: "/maintenancecenter/kiriazi-appliances-egyptian-brand.jpg",
        content: [
          "تأسست شركة كريازي في مصر عام 1951 وهي من أقدم الشركات المصرية",
          "كريازي هي الماركة الأولى والأكثر انتشاراً في البيوت المصرية",
          "تتميز بالجودة العالية والأسعار المناسبة للسوق المصري",
          "تنتج كريازي مجموعة واسعة من الثلاجات والديب فريزر والغسالات",
          "حازت على ثقة الأجيال المتعاقبة من المصريين",
          "تلتزم بمعايير الجودة المصرية والعالمية",
          "توفر قطع غيار متاحة بسهولة في جميع أنحاء مصر",
          "شبكة خدمة عملاء منتشرة في كل المحافظات",
        ],
      },
      {
        title: "خدمات الصيانة الشاملة",
        icon: Wrench,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "صيانة ثلاجات كريازي بجميع الأحجام والموديلات",
          "إصلاح الديب فريزر الرأسي والأفقي",
          "صيانة غسالات كريازي الأوتوماتيك",
          "إصلاح نظام التبريد والكمبروسر",
          "صيانة الثرموستات ومنظم الحرارة",
          "استبدال الجوان والعوازل",
          "إصلاح نظام الإضاءة الداخلية",
          "صيانة الأدراج والرفوف",
          "شحن وإعادة شحن غاز الفريون",
          "الصيانة الدورية والوقائية",
        ],
      },
      {
        title: "مميزات أجهزة كريازي",
        icon: CheckCircle,
        image: "/maintenancecenter/kiriazi-appliances-egyptian-brand.jpg",
        content: [
          "تصميم عملي يناسب المطابخ المصرية",
          "استهلاك كهرباء اقتصادي",
          "متانة وعمر افتراضي طويل",
          "سهولة الصيانة وتوفر قطع الغيار",
          "أسعار تنافسية ومناسبة",
          "ضمان معتمد من الشركة",
          "تصميمات متنوعة تناسب جميع الأذواق",
          "سعات مختلفة تناسب كل الأسر",
          "تقنيات حديثة في الموديلات الجديدة",
          "خدمة ما بعد البيع الممتازة",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "ضعف التبريد أو عدم التبريد - فحص شامل لدائرة التبريد",
          "تسرب المياه - إصلاح نظام التصريف",
          "أصوات غير طبيعية - صيانة الكمبروسر والمروحة",
          "عدم عمل الإضاءة - استبدال اللمبات والمفاتيح",
          "مشاكل في الثرموستات - معايرة أو استبدال",
          "تلف الجوان - استبدال بقطع أصلية",
          "مشاكل في الموتور - إصلاح أو استبدال",
          "عدم عمل الغسالة - فحص النظام الكهربائي",
          "مشاكل في التصريف - تنظيف وصيانة",
          "استهلاك كهرباء عالي - فحص الكفاءة",
        ],
      },
      {
        title: "خبرتنا في صيانة كريازي",
        icon: Award,
        image: "/happy-middle-aged-egyptian-man.jpg",
        content: [
          "خبرة تزيد عن 20 عاماً في صيانة أجهزة كريازي",
          "فنيون متخصصون في الماركات المصرية",
          "نعرف جميع موديلات كريازي القديمة والحديثة",
          "قطع غيار أصلية متوفرة دائماً",
          "ضمان 12 شهر على جميع الخدمات",
          "استجابة سريعة في نفس اليوم",
          "خدمة منزلية في جميع المحافظات",
          "أسعار عادلة ومناسبة للجميع",
          "تقارير فنية واضحة ومفصلة",
          "نصائح للحفاظ على الأجهزة",
          "صيانة دورية بأسعار مخفضة",
          "خدمة عملاء باللغة العربية",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات والقطع",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  universal: {
    name: "يونيفرسال",
    logo: "/maintenancecenter/universal-appliances-brand.jpg",
    heroImage: "/centerlogo/يونيفرسال.png",
    tagline: "الجودة العالمية بأسعار محلية",
    description: "يونيفرسال من الماركات المصرية المعروفة بجودتها العالية وأسعارها المناسبة",
    hero: {
      title: "مركز صيانة يونيفرسال",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة يونيفرسال المنزلية",
    },
    sections: [
      {
        title: "عن شركة يونيفرسال",
        icon: Award,
        image: "/maintenancecenter/universal-appliances-brand.jpg",
        content: [
          "يونيفرسال من الماركات المصرية الرائدة في السوق المحلي",
          "تقدم مجموعة متنوعة من الأجهزة المنزلية بجودة عالية",
          "معروفة بالمتانة والأداء الموثوق",
          "أسعار تنافسية تناسب السوق المصري",
          "شبكة خدمة واسعة في جميع المحافظات",
          "ضمان معتمد على جميع المنتجات",
          "تصميمات عصرية وعملية",
          "توفر قطع غيار بسهولة",
        ],
      },
      {
        title: "خدمات الصيانة",
        icon: Wrench,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "صيانة غسالات يونيفرسال الأوتوماتيك",
          "إصلاح ثلاجات وديب فريزر يونيفرسال",
          "صيانة المكيفات والتكييفات",
          "إصلاح الأعطال الكهربائية والميكانيكية",
          "استبدال قطع الغيار الأصلية",
          "الصيانة الدورية والوقائية",
          "تنظيف وتعقيم الأجهزة",
          "فحص شامل للأداء",
          "معايرة الأنظمة الإلكترونية",
          "خدمة طوارئ سريعة",
        ],
      },
      {
        title: "مميزات الخدمة",
        icon: CheckCircle,
        image: "/maintenancecenter/universal-appliances-brand.jpg",
        content: [
          "فنيون متخصصون في أجهزة يونيفرسال",
          "قطع غيار أصلية معتمدة",
          "ضمان 12 شهر شامل",
          "أسعار شفافة ومنافسة",
          "استجابة سريعة خلال 24 ساعة",
          "خدمة منزلية مريحة",
          "تقارير فنية مفصلة",
          "نصائح للصيانة الذاتية",
          "خدمة عملاء ممتازة",
          "تغطية جميع المحافظات",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "مشاكل في التبريد والتجميد",
          "أعطال المحرك والموتور",
          "تسرب المياه",
          "أصوات غير طبيعية",
          "مشاكل في لوحة التحكم",
          "عدم التصريف الجيد",
          "مشاكل في الباب والقفل",
          "استهلاك كهرباء عالي",
          "رائحة كريهة",
          "عدم العمل بشكل كامل",
        ],
      },
      {
        title: "ضمانات الجودة",
        icon: Award,
        image: "/happy-egyptian-male-customer-smiling.jpg",
        content: [
          "خبرة طويلة في صيانة يونيفرسال",
          "فنيون معتمدون ومدربون",
          "معدات فحص حديثة",
          "قطع غيار أصلية فقط",
          "ضمان مكتوب على الخدمة",
          "أسعار عادلة وثابتة",
          "خدمة سريعة وموثوقة",
          "تقارير شفافة",
          "متابعة بعد الصيانة",
          "رضا العملاء أولويتنا",
        ],
      },
    ],
    warranty: "ضمان شامل 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  fresh: {
    name: "فريش",
    logo: "/maintenancecenter/fresh-appliances-egyptian-brand.jpg",
    heroImage: "/centerlogo/فريش.png",
    tagline: "الماركة المصرية الموثوقة",
    description: "فريش من الماركات المصرية الرائدة المعروفة بجودتها وأسعارها المناسبة للأسر المصرية",
    hero: {
      title: "مركز صيانة فريش",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة فريش المنزلية بضمان الجودة",
    },
    sections: [
      {
        title: "عن شركة فريش",
        icon: Award,
        image: "/maintenancecenter/fresh-appliances-egyptian-brand.jpg",
        content: [
          "فريش من الماركات المصرية العريقة في مجال الأجهزة المنزلية",
          "تتميز بالجودة العالية والأسعار المناسبة للسوق المصري",
          "تقدم مجموعة واسعة من الثلاجات والغسالات والمكيفات",
          "معروفة بالمتانة والعمر الافتراضي الطويل",
          "شبكة خدمة منتشرة في جميع أنحاء مصر",
          "ضمان معتمد على جميع المنتجات",
          "تصميمات عصرية تناسب المنازل المصرية",
          "قطع غيار متوفرة بسهولة في السوق المحلي",
        ],
      },
      {
        title: "خدمات الصيانة المتخصصة",
        icon: Wrench,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "صيانة ثلاجات فريش بجميع الأحجام والموديلات",
          "إصلاح غسالات فريش الأوتوماتيك والنصف أوتوماتيك",
          "صيانة مكيفات فريش الشباك والسبليت",
          "إصلاح الديب فريزر الرأسي والأفقي",
          "صيانة نظام التبريد والكمبروسر",
          "استبدال الثرموستات ومنظم الحرارة",
          "إصلاح نظام التصريف والمضخات",
          "صيانة لوحة التحكم الإلكترونية",
          "شحن غاز الفريون وإصلاح التسريبات",
          "الصيانة الدورية والوقائية الشاملة",
        ],
      },
      {
        title: "مميزات أجهزة فريش",
        icon: CheckCircle,
        image: "/maintenancecenter/fresh-appliances-egyptian-brand.jpg",
        content: [
          "تصميم عملي يناسب المطابخ المصرية",
          "استهلاك كهرباء اقتصادي ومناسب",
          "متانة عالية وعمر افتراضي طويل",
          "سهولة الصيانة وتوفر قطع الغيار",
          "أسعار تنافسية في متناول الجميع",
          "ضمان معتمد من الشركة المصنعة",
          "تقنيات حديثة في الموديلات الجديدة",
          "سعات متنوعة تناسب جميع الأسر",
          "كفاءة عالية في الأداء",
          "خدمة ما بعد البيع الممتازة",
        ],
      },
      {
        title: "الأعطال الشائعة وحلولها",
        icon: Shield,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "ضعف التبريد - فحص شامل لدائرة التبريد والكمبروسر",
          "تسرب المياه - إصلاح نظام التصريف والجوان",
          "أصوات غير طبيعية - صيانة المحرك والمروحة",
          "عدم عمل الإضاءة - استبدال اللمبات والمفاتيح",
          "مشاكل في الثرموستات - معايرة أو استبدال",
          "تلف الجوان والعوازل - استبدال بقطع أصلية",
          "مشاكل في الموتور - إصلاح أو استبدال احترافي",
          "عدم التصريف الجيد - تنظيف وصيانة المضخة",
          "مشاكل في لوحة التحكم - إصلاح إلكتروني متخصص",
          "استهلاك كهرباء عالي - فحص الكفاءة والأداء",
        ],
      },
      {
        title: "لماذا نحن الأفضل لصيانة فريش؟",
        icon: Award,
        image: "/satisfied-egyptian-female-customer.jpg",
        content: [
          "خبرة تزيد عن 18 عاماً في صيانة أجهزة فريش",
          "فنيون متخصصون في الماركات المصرية",
          "نعرف جميع موديلات فريش القديمة والحديثة",
          "قطع غيار أصلية متوفرة دائماً بأسعار مناسبة",
          "ضمان 12 شهر على جميع الخدمات والقطع",
          "استجابة سريعة في نفس اليوم",
          "خدمة منزلية في جميع المحافظات",
          "أسعار عادلة وشفافة بدون تكاليف خفية",
          "تقارير فنية واضحة ومفصلة",
          "نصائح للحفاظ على الأجهزة وإطالة عمرها",
          "صيانة دورية بأسعار مخفضة للعملاء الدائمين",
          "خدمة عملاء متاحة 7 أيام في الأسبوع",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات والقطع الأصلية",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  gree: {
    name: "جري",
    logo: "/maintenancecenter/gree-air-conditioning-brand.jpg",
    heroImage: "/centerlogo/جري.png",
    tagline: "الرائدة عالمياً في التكييف",
    description: "جري هي الشركة الرائدة عالمياً في صناعة أجهزة التكييف والتبريد بتقنيات متطورة",
    hero: {
      title: "مركز صيانة جري",
      subtitle: "خدمات صيانة متخصصة لأجهزة التكييف والتبريد جري بأعلى معايير الجودة",
    },
    sections: [
      {
        title: "عن شركة جري العالمية",
        icon: Award,
        image: "/maintenancecenter/gree-air-conditioning-brand.jpg",
        content: [
          "جري هي أكبر شركة مصنعة لأجهزة التكييف في العالم",
          "تأسست في الصين عام 1991 وتوسعت عالمياً",
          "تصدر منتجاتها إلى أكثر من 160 دولة حول العالم",
          "حازت على العديد من الجوائز العالمية للابتكار",
          "تستثمر بكثافة في البحث والتطوير",
          "تلتزم بمعايير الجودة والكفاءة العالمية",
          "تقدم تقنيات متطورة في التبريد والتكييف",
          "شبكة خدمة عالمية موثوقة",
        ],
      },
      {
        title: "خدمات الصيانة الشاملة",
        icon: Wrench,
        image: "/maintenancecenter/gree-air-conditioning-brand.jpg",
        content: [
          "صيانة مكيفات جري السبليت بجميع القدرات",
          "إصلاح المكيفات المركزية والكونسيلد",
          "صيانة مكيفات الشباك والمتنقلة",
          "إصلاح نظام التبريد والكمبروسر الإنفرتر",
          "صيانة الوحدة الداخلية والخارجية",
          "تنظيف وتعقيم الفلاتر والمبخر",
          "شحن غاز الفريون R410A و R32",
          "إصلاح لوحة التحكم الإلكترونية",
          "صيانة الريموت كنترول والمستشعرات",
          "الصيانة الدورية قبل الصيف",
        ],
      },
      {
        title: "التقنيات المتقدمة في جري",
        icon: CheckCircle,
        image: "/maintenancecenter/gree-air-conditioning-brand.jpg",
        content: [
          "تقنية الإنفرتر لتوفير الطاقة حتى 60%",
          "نظام التبريد السريع G10 Technology",
          "تقنية التنظيف الذاتي للوحدة الداخلية",
          "نظام التحكم الذكي عبر WiFi والتطبيقات",
          "تقنية الهواء النقي مع فلاتر HEPA",
          "نظام التشغيل الهادئ Silent Mode",
          "تقنية التوزيع المتساوي للهواء 3D Airflow",
          "نظام التشخيص الذكي للأعطال",
          "تقنية التشغيل في درجات حرارة قصوى",
          "نظام الحماية من التيار الكهربائي",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/maintenancecenter/gree-air-conditioning-brand.jpg",
        content: [
          "ضعف التبريد - فحص غاز الفريون والكمبروسر",
          "تسرب المياه من الوحدة الداخلية - تنظيف المصرف",
          "أصوات غير طبيعية - صيانة المروحة والكمبروسر",
          "عدم التشغيل - فحص النظام الكهربائي",
          "مشاكل في الريموت كنترول - برمجة أو استبدال",
          "رائحة كريهة - تنظيف وتعقيم شامل",
          "تجمد الوحدة الداخلية - فحص الفلاتر والغاز",
          "استهلاك كهرباء عالي - فحص الإنفرتر",
          "مشاكل في الوحدة الخارجية - صيانة متخصصة",
          "أعطال لوحة التحكم - إصلاح إلكتروني",
        ],
      },
      {
        title: "خبرتنا في صيانة جري",
        icon: Award,
        image: "/happy-egyptian-male-customer-smiling.jpg",
        content: [
          "فنيون معتمدون من شركة جري العالمية",
          "خبرة 15 عام في صيانة أجهزة التكييف",
          "معدات فحص وشحن متطورة",
          "قطع غيار أصلية 100% من جري",
          "ضمان 12 شهر على جميع الخدمات",
          "خدمة طوارئ متاحة 24/7",
          "أسعار تنافسية وشفافة",
          "تقارير فنية مفصلة بعد كل زيارة",
          "عقود صيانة دورية بأسعار خاصة",
          "تدريب مستمر على أحدث التقنيات",
          "خدمة في جميع محافظات مصر",
          "رضا العملاء نسبة 98%",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على القطع الأصلية + 6 أشهر على العمالة",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  power: {
    name: "باور",
    logo: "/maintenancecenter/power-appliances-brand.jpg",
    heroImage: "/centerlogo/باور.png",
    tagline: "القوة والأداء المتميز",
    description: "باور من الماركات المصرية المعروفة بالقوة والأداء العالي في الأجهزة المنزلية",
    hero: {
      title: "مركز صيانة باور",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة باور المنزلية",
    },
    sections: [
      {
        title: "عن شركة باور",
        icon: Award,
        image: "/maintenancecenter/power-appliances-brand.jpg",
        content: [
          "باور من الماركات المصرية الموثوقة في السوق المحلي",
          "تتميز بالأداء القوي والمتانة العالية",
          "تقدم مجموعة متنوعة من الأجهزة المنزلية",
          "أسعار مناسبة للطبقة المتوسطة",
          "ضمان معتمد على جميع المنتجات",
          "شبكة خدمة منتشرة في المحافظات",
          "تصميمات عملية وبسيطة",
          "قطع غيار متوفرة بسهولة",
        ],
      },
      {
        title: "خدمات الصيانة",
        icon: Wrench,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "صيانة غسالات باور الأوتوماتيك",
          "إصلاح ثلاجات وديب فريزر باور",
          "صيانة المكيفات والتكييفات",
          "إصلاح المحركات والموتورات",
          "استبدال قطع الغيار الأصلية",
          "صيانة نظام التبريد",
          "إصلاح لوحات التحكم",
          "تنظيف وصيانة دورية",
          "فحص شامل للأداء",
          "خدمة طوارئ سريعة",
        ],
      },
      {
        title: "مميزات الخدمة",
        icon: CheckCircle,
        image: "/maintenancecenter/power-appliances-brand.jpg",
        content: [
          "فنيون متخصصون في أجهزة باور",
          "قطع غيار أصلية معتمدة",
          "ضمان 12 شهر شامل",
          "أسعار مناسبة ومنافسة",
          "استجابة سريعة",
          "خدمة منزلية مريحة",
          "تقارير فنية واضحة",
          "نصائح للصيانة",
          "خدمة عملاء ممتازة",
          "تغطية واسعة",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "مشاكل في التبريد",
          "أعطال المحرك",
          "تسرب المياه",
          "أصوات غير طبيعية",
          "مشاكل في التحكم",
          "عدم التصريف",
          "مشاكل في الباب",
          "استهلاك كهرباء عالي",
          "رائحة كريهة",
          "عدم العمل",
        ],
      },
      {
        title: "ضمانات الجودة",
        icon: Award,
        image: "/happy-middle-aged-egyptian-man.jpg",
        content: [
          "خبرة طويلة في صيانة باور",
          "فنيون معتمدون",
          "معدات حديثة",
          "قطع غيار أصلية",
          "ضمان مكتوب",
          "أسعار عادلة",
          "خدمة سريعة",
          "تقارير شفافة",
          "متابعة مستمرة",
          "رضا العملاء",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  "union-air": {
    name: "يونيون إير",
    logo: "/maintenancecenter/union-air-conditioning-brand.jpg",
    heroImage: "/centerlogo/يونيون إير.png",
    tagline: "التكييف المصري الأول",
    description: "يونيون إير هي الشركة المصرية الرائدة في صناعة أجهزة التكييف والتبريد",
    hero: {
      title: "مركز صيانة يونيون إير",
      subtitle: "خدمات صيانة متخصصة للماركة المصرية الأولى في التكييف",
    },
    sections: [
      {
        title: "عن يونيون إير المصرية",
        icon: Award,
        image: "/maintenancecenter/union-air-conditioning-brand.jpg",
        content: [
          "يونيون إير الشركة المصرية الرائدة في التكييف",
          "تأسست في مصر وتخدم السوق المحلي منذ عقود",
          "الماركة الأكثر انتشاراً في المنازل المصرية",
          "تقدم حلول تكييف مناسبة للمناخ المصري",
          "أسعار تنافسية تناسب السوق المحلي",
          "شبكة خدمة واسعة في كل المحافظات",
          "ضمان معتمد على جميع المنتجات",
          "قطع غيار متوفرة بسهولة في مصر",
        ],
      },
      {
        title: "خدمات الصيانة الشاملة",
        icon: Wrench,
        image: "/maintenancecenter/union-air-conditioning-brand.jpg",
        content: [
          "صيانة مكيفات يونيون إير السبليت",
          "إصلاح مكيفات الشباك والمتنقلة",
          "صيانة المكيفات الصحراوية",
          "إصلاح نظام التبريد والكمبروسر",
          "صيانة الوحدة الداخلية والخارجية",
          "تنظيف وتعقيم الفلاتر",
          "شحن غاز الفريون",
          "إصلاح لوحة التحكم",
          "صيانة الريموت كنترول",
          "الصيانة الدورية قبل الصيف",
        ],
      },
      {
        title: "مميزات أجهزة يونيون إير",
        icon: CheckCircle,
        image: "/maintenancecenter/union-air-conditioning-brand.jpg",
        content: [
          "مناسبة للمناخ المصري الحار",
          "استهلاك كهرباء اقتصادي",
          "متانة عالية وعمر طويل",
          "سهولة الصيانة",
          "أسعار مناسبة للجميع",
          "ضمان معتمد",
          "تصميمات عصرية",
          "كفاءة تبريد عالية",
          "تشغيل هادئ",
          "خدمة ما بعد البيع ممتازة",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/maintenancecenter/union-air-conditioning-brand.jpg",
        content: [
          "ضعف التبريد - فحص الغاز والكمبروسر",
          "تسرب المياه - تنظيف المصرف",
          "أصوات غير طبيعية - صيانة المروحة",
          "عدم التشغيل - فحص كهربائي",
          "مشاكل في الريموت - برمجة",
          "رائحة كريهة - تنظيف وتعقيم",
          "تجمد الوحدة - فحص الفلاتر",
          "استهلاك كهرباء عالي - فحص الكفاءة",
          "مشاكل في الوحدة الخارجية - صيانة",
          "أعطال التحكم - إصلاح",
        ],
      },
      {
        title: "خبرتنا في يونيون إير",
        icon: Award,
        image: "/smiling-egyptian-woman-customer.jpg",
        content: [
          "خبرة 20 عام في صيانة يونيون إير",
          "فنيون متخصصون في الماركات المصرية",
          "نعرف جميع الموديلات",
          "قطع غيار أصلية متوفرة",
          "ضمان 12 شهر",
          "استجابة سريعة",
          "خدمة في كل المحافظات",
          "أسعار عادلة",
          "تقارير واضحة",
          "نصائح مفيدة",
          "صيانة دورية",
          "خدمة عملاء ممتازة",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  carrier: {
    name: "كاريير",
    logo: "/maintenancecenter/carrier-air-conditioning-brand.jpg",
    heroImage: "/centerlogo/كاريير.png",
    tagline: "الرائد العالمي في التكييف",
    description: "كاريير من أكبر الشركات العالمية في صناعة أنظمة التكييف والتبريد منذ 1902",
    hero: {
      title: "مركز صيانة كاريير",
      subtitle: "خدمات صيانة متخصصة لأنظمة التكييف كاريير بخبرة عالمية",
    },
    sections: [
      {
        title: "تاريخ كاريير العريق",
        icon: Award,
        image: "/maintenancecenter/carrier-air-conditioning-brand.jpg",
        content: [
          "كاريير تأسست عام 1902 في الولايات المتحدة",
          "أكثر من 120 عام من الخبرة في التكييف",
          "رائدة عالمياً في صناعة التكييف والتبريد",
          "تعمل في أكثر من 180 دولة",
          "متخصصة في الأنظمة التجارية والصناعية والسكنية",
          "معايير جودة أمريكية صارمة",
          "تقنيات متطورة وموثوقة",
          "الخيار المفضل للمشاريع الكبرى",
        ],
      },
      {
        title: "خدمات الصيانة المتخصصة",
        icon: Wrench,
        image: "/maintenancecenter/carrier-air-conditioning-brand.jpg",
        content: [
          "صيانة مكيفات كاريير السبليت",
          "إصلاح الأنظمة المركزية",
          "صيانة مكيفات الكونسيلد",
          "إصلاح نظام التبريد",
          "صيانة الوحدات الداخلية والخارجية",
          "تنظيف وتعقيم شامل",
          "شحن غاز الفريون",
          "إصلاح أنظمة التحكم",
          "صيانة المستشعرات",
          "عقود صيانة دورية",
        ],
      },
      {
        title: "التقنيات المتقدمة",
        icon: CheckCircle,
        image: "/maintenancecenter/carrier-air-conditioning-brand.jpg",
        content: [
          "تقنية الإنفرتر المتطورة",
          "نظام التحكم الذكي",
          "تقنية التبريد الفعال",
          "نظام تنقية الهواء",
          "تقنية التشغيل الهادئ",
          "نظام التوزيع المثالي",
          "تقنية التشخيص الذاتي",
          "نظام الحماية الشامل",
          "تقنية العمل المستمر",
          "نظام إدارة الطاقة",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/maintenancecenter/carrier-air-conditioning-brand.jpg",
        content: [
          "ضعف التبريد - فحص شامل",
          "تسرب الغاز - كشف وإصلاح",
          "أصوات غير طبيعية - صيانة",
          "مشاكل في الكمبروسر - إصلاح",
          "أعطال كهربائية - فحص",
          "مشاكل في التحكم - برمجة",
          "تجمد الوحدة - معالجة",
          "استهلاك عالي - تحسين",
          "رائحة كريهة - تنظيف",
          "مشاكل في الوحدة الخارجية - صيانة",
        ],
      },
      {
        title: "لماذا نحن الأفضل؟",
        icon: Award,
        image: "/happy-egyptian-male-customer-smiling.jpg",
        content: [
          "فنيون معتمدون من كاريير",
          "خبرة 17 عام",
          "معدات فحص أصلية",
          "قطع غيار أصلية",
          "ضمان 12 شهر",
          "خدمة طوارئ",
          "عقود صيانة",
          "تقارير تفصيلية",
          "أسعار تنافسية",
          "تدريب مستمر",
          "خدمة شاملة",
          "رضا العملاء",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على القطع والعمالة",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  york: {
    name: "يورك",
    logo: "/maintenancecenter/york-air-conditioning-brand.jpg",
    heroImage: "/centerlogo/يورك.png",
    tagline: "الخبرة الأمريكية في التكييف",
    description: "يورك من أعرق الشركات الأمريكية في صناعة أنظمة التكييف والتبريد منذ 1874",
    hero: {
      title: "مركز صيانة يورك",
      subtitle: "خدمات صيانة متخصصة لأنظمة التكييف يورك بخبرة عالمية",
    },
    sections: [
      {
        title: "تاريخ يورك العريق",
        icon: Award,
        image: "/maintenancecenter/york-air-conditioning-brand.jpg",
        content: [
          "يورك تأسست عام 1874 في الولايات المتحدة",
          "أكثر من 150 عام من الخبرة في التكييف",
          "من أقدم وأعرق شركات التكييف في العالم",
          "تعمل في أكثر من 100 دولة",
          "متخصصة في الأنظمة التجارية والصناعية",
          "معايير جودة أمريكية صارمة",
          "تقنيات متطورة وموثوقة",
          "الخيار المفضل للمشاريع الكبرى",
        ],
      },
      {
        title: "خدمات الصيانة المتخصصة",
        icon: Wrench,
        image: "/maintenancecenter/york-air-conditioning-brand.jpg",
        content: [
          "صيانة مكيفات يورك السبليت",
          "إصلاح الأنظمة المركزية",
          "صيانة مكيفات الكونسيلد",
          "إصلاح نظام التبريد",
          "صيانة الوحدات الداخلية والخارجية",
          "تنظيف وتعقيم شامل",
          "شحن غاز الفريون",
          "إصلاح أنظمة التحكم",
          "صيانة المستشعرات",
          "عقود صيانة دورية",
        ],
      },
      {
        title: "التقنيات المتقدمة",
        icon: CheckCircle,
        image: "/maintenancecenter/york-air-conditioning-brand.jpg",
        content: [
          "تقنية الإنفرتر المتطورة",
          "نظام التحكم الذكي",
          "تقنية التبريد الفعال",
          "نظام تنقية الهواء",
          "تقنية التشغيل الهادئ",
          "نظام التوزيع المثالي",
          "تقنية التشخيص الذاتي",
          "نظام الحماية الشامل",
          "تقنية العمل المستمر",
          "نظام إدارة الطاقة",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/maintenancecenter/york-air-conditioning-brand.jpg",
        content: [
          "ضعف التبريد - فحص شامل",
          "تسرب الغاز - كشف وإصلاح",
          "أصوات غير طبيعية - صيانة",
          "مشاكل في الكمبروسر - إصلاح",
          "أعطال كهربائية - فحص",
          "مشاكل في التحكم - برمجة",
          "تجمد الوحدة - معالجة",
          "استهلاك عالي - تحسين",
          "رائحة كريهة - تنظيف",
          "مشاكل في الوحدة الخارجية - صيانة",
        ],
      },
      {
        title: "لماذا نحن الأفضل؟",
        icon: Award,
        image: "/happy-egyptian-male-customer-smiling.jpg",
        content: [
          "فنيون معتمدون من يورك",
          "خبرة 18 عام",
          "معدات فحص أصلية",
          "قطع غيار أصلية",
          "ضمان 12 شهر",
          "خدمة طوارئ",
          "عقود صيانة",
          "تقارير تفصيلية",
          "أسعار تنافسية",
          "تدريب مستمر",
          "خدمة شاملة",
          "رضا العملاء",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على القطع والعمالة",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  "white-whale": {
    name: "وايت ويل",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/وايت ويل.png",
    tagline: "الجودة الأوروبية بثقة مصرية",
    description: "وايت ويل من الماركات المعروفة في السوق المصري بجودتها العالية وأسعارها المناسبة",
    hero: {
      title: "مركز صيانة وايت ويل",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة وايت ويل المنزلية بضمان شامل",
    },
    sections: [
      {
        title: "عن شركة وايت ويل",
        icon: Award,
        image: "/placeholder.svg",
        content: [
          "وايت ويل من الماركات المعروفة في السوق المصري",
          "تقدم مجموعة متنوعة من الأجهزة المنزلية",
          "معروفة بالجودة والأداء الموثوق",
          "أسعار مناسبة للسوق المصري",
          "شبكة خدمة منتشرة في المحافظات",
          "ضمان معتمد على جميع المنتجات",
          "تصميمات عصرية وعملية",
          "قطع غيار متوفرة بسهولة",
        ],
      },
      {
        title: "خدمات الصيانة المتخصصة",
        icon: Wrench,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "صيانة غسالات وايت ويل الأوتوماتيك",
          "إصلاح ثلاجات وديب فريزر وايت ويل",
          "صيانة مكيفات وايت ويل",
          "إصلاح غسالات الأطباق",
          "صيانة المجففات والميكروويف",
          "استبدال قطع الغيار الأصلية",
          "الصيانة الدورية والوقائية",
          "فحص شامل للأداء",
          "تنظيف وتعقيم الأجهزة",
          "خدمة طوارئ سريعة",
        ],
      },
      {
        title: "مميزات أجهزة وايت ويل",
        icon: CheckCircle,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "تصميمات عصرية وأنيقة",
          "كفاءة استهلاك الطاقة",
          "متانة وعمر افتراضي طويل",
          "سهولة الاستخدام والصيانة",
          "تقنيات حديثة ومتطورة",
          "أسعار تنافسية ومناسبة",
          "ضمان معتمد من الشركة",
          "قطع غيار متوفرة",
          "أداء موثوق وفعال",
          "خدمة ما بعد البيع الممتازة",
        ],
      },
      {
        title: "الأعطال الشائعة وحلولها",
        icon: Shield,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "مشاكل في التبريد - فحص شامل لدائرة التبريد",
          "أعطال المحرك - إصلاح أو استبدال",
          "تسرب المياه - إصلاح نظام التصريف",
          "أصوات غير طبيعية - صيانة المحرك",
          "مشاكل في لوحة التحكم - إصلاح إلكتروني",
          "عدم التصريف الجيد - تنظيف المضخة",
          "مشاكل في الباب والقفل - إصلاح فوري",
          "استهلاك كهرباء عالي - فحص الكفاءة",
          "رائحة كريهة - تنظيف وتعقيم",
          "عدم العمل بشكل كامل - فحص شامل",
        ],
      },
      {
        title: "لماذا نحن الأفضل لصيانة وايت ويل؟",
        icon: Award,
        image: "/happy-egyptian-male-customer-smiling.jpg",
        content: [
          "خبرة تزيد عن 15 عاماً في صيانة وايت ويل",
          "فنيون متخصصون ومدربون",
          "قطع غيار أصلية معتمدة",
          "ضمان 12 شهر على جميع الخدمات",
          "استجابة سريعة خلال 24 ساعة",
          "أسعار عادلة وشفافة",
          "خدمة منزلية في جميع المحافظات",
          "تقارير فنية مفصلة",
          "نصائح للحفاظ على الأجهزة",
          "خدمة عملاء متاحة 7/7",
          "صيانة دورية بأسعار خاصة",
          "رضا العملاء أولويتنا",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات والقطع",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  "white-point": {
    name: "وايت بوينت",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/وايت بوينت.png",
    tagline: "الماركة المصرية الموثوقة",
    description: "وايت بوينت من الماركات المصرية الرائدة المعروفة بجودتها وأسعارها المناسبة للأسر المصرية",
    hero: {
      title: "مركز صيانة وايت بوينت",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة وايت بوينت مع ضمان الجودة",
    },
    sections: [
      {
        title: "عن شركة وايت بوينت",
        icon: Award,
        image: "/placeholder.svg",
        content: [
          "وايت بوينت من الماركات المصرية المعروفة",
          "تقدم مجموعة واسعة من الأجهزة المنزلية",
          "معروفة بالجودة العالية والأسعار المناسبة",
          "منتشرة في البيوت المصرية",
          "شبكة خدمة واسعة في كل المحافظات",
          "ضمان معتمد على جميع المنتجات",
          "تصميمات عملية ومناسبة",
          "قطع غيار متوفرة بسهولة في السوق المحلي",
        ],
      },
      {
        title: "خدمات الصيانة الشاملة",
        icon: Wrench,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "صيانة غسالات وايت بوينت الأوتوماتيك",
          "إصلاح ثلاجات وايت بوينت بجميع الأحجام",
          "صيانة مكيفات وايت بوينت السبليت والشباك",
          "إصلاح الديب فريزر الرأسي والأفقي",
          "صيانة البوتاجازات والأفران",
          "إصلاح السخانات الكهربائية",
          "صيانة غسالات الأطباق",
          "إصلاح الميكروويف",
          "استبدال قطع الغيار الأصلية",
          "الصيانة الدورية والوقائية",
        ],
      },
      {
        title: "مميزات أجهزة وايت بوينت",
        icon: CheckCircle,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "تصميم عملي يناسب المنازل المصرية",
          "استهلاك كهرباء اقتصادي",
          "متانة وعمر افتراضي طويل",
          "سهولة الصيانة وتوفر قطع الغيار",
          "أسعار مناسبة للجميع",
          "ضمان معتمد من الشركة",
          "تقنيات حديثة في الموديلات الجديدة",
          "سعات متنوعة تناسب جميع الأسر",
          "كفاءة عالية في الأداء",
          "خدمة ما بعد البيع الممتازة",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "ضعف التبريد - فحص دائرة التبريد",
          "تسرب المياه - إصلاح التصريف",
          "أصوات غير طبيعية - صيانة المحرك",
          "عدم التشغيل - فحص كهربائي",
          "مشاكل في الثرموستات - معايرة",
          "تلف الجوان - استبدال",
          "مشاكل في الموتور - إصلاح",
          "عدم التصريف - تنظيف المضخة",
          "مشاكل في التحكم - إصلاح",
          "استهلاك عالي - فحص الكفاءة",
        ],
      },
      {
        title: "خبرتنا في صيانة وايت بوينت",
        icon: Award,
        image: "/happy-middle-aged-egyptian-man.jpg",
        content: [
          "خبرة 18 عام في صيانة وايت بوينت",
          "فنيون متخصصون في الماركات المصرية",
          "نعرف جميع الموديلات القديمة والحديثة",
          "قطع غيار أصلية متوفرة دائماً",
          "ضمان 12 شهر شامل",
          "استجابة سريعة في نفس اليوم",
          "خدمة منزلية في كل المحافظات",
          "أسعار عادلة ومناسبة",
          "تقارير فنية واضحة",
          "نصائح مفيدة للحفاظ على الأجهزة",
          "صيانة دورية بأسعار مخفضة",
          "خدمة عملاء باللغة العربية",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات والقطع",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  samsung: {
    name: "سامسونج",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/سامسونج.png",
    tagline: "الابتكار الكوري العالمي",
    description: "سامسونج من أكبر الشركات العالمية في مجال الإلكترونيات والأجهزة المنزلية بتقنيات متطورة",
    hero: {
      title: "مركز صيانة سامسونج",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة سامسونج بأعلى معايير الجودة",
    },
    sections: [
      {
        title: "عن شركة سامسونج العالمية",
        icon: Award,
        image: "/placeholder.svg",
        content: [
          "سامسونج من أكبر الشركات العالمية في الإلكترونيات",
          "تأسست في كوريا الجنوبية وتوسعت عالمياً",
          "رائدة في التكنولوجيا والابتكار",
          "تقدم مجموعة واسعة من الأجهزة المنزلية الذكية",
          "حازت على العديد من الجوائز العالمية",
          "تلتزم بمعايير الجودة العالمية",
          "تستثمر بكثافة في البحث والتطوير",
          "شبكة خدمة عالمية موثوقة",
        ],
      },
      {
        title: "خدمات الصيانة المتخصصة",
        icon: Wrench,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "صيانة غسالات سامسونج بتقنية EcoBubble",
          "إصلاح ثلاجات سامسونج بنظام التبريد الذكي",
          "صيانة مكيفات سامسونج الإنفرتر",
          "إصلاح غسالات الأطباق بنظام WaterWall",
          "صيانة المجففات والميكروويف",
          "إصلاح الشاشات والتلفزيونات الذكية",
          "صيانة الأجهزة الذكية المتصلة بالإنترنت",
          "تحديث البرامج والأنظمة",
          "استبدال قطع الغيار الأصلية",
          "الصيانة الدورية الشاملة",
        ],
      },
      {
        title: "التقنيات المتقدمة في سامسونج",
        icon: CheckCircle,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "تقنية الإنفرتر الرقمي لتوفير الطاقة",
          "نظام SmartThings للتحكم الذكي",
          "تقنية EcoBubble للغسيل الفعال",
          "نظام التبريد الخطي في الثلاجات",
          "تقنية AddWash لإضافة الملابس أثناء الغسيل",
          "نظام التشخيص الذكي Smart Check",
          "تقنية Wind-Free للتبريد المتساوي",
          "نظام Triple Protector Plus للحماية",
          "تقنية VRT+ لتقليل الاهتزازات",
          "نظام Q-Rator في الثلاجات الذكية",
        ],
      },
      {
        title: "الأعطال الشائعة وحلولها",
        icon: Shield,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "مشاكل في نظام الإنفرتر - قطع غيار أصلية",
          "أعطال في الأنظمة الذكية - خبراء برمجيات",
          "مشاكل في التبريد - فحص شامل",
          "أعطال المحرك الرقمي - صيانة متخصصة",
          "مشاكل في التحكم باللمس - إصلاح",
          "أعطال نظام AddWash - إصلاح",
          "مشاكل في الاتصال بالإنترنت - دعم فني",
          "أعطال المستشعرات - معايرة دقيقة",
          "مشاكل في الشاشة الرقمية - استبدال",
          "أعطال في نظام التجفيف - صيانة",
        ],
      },
      {
        title: "لماذا نحن الأفضل لصيانة سامسونج؟",
        icon: Award,
        image: "/happy-egyptian-male-customer-smiling.jpg",
        content: [
          "فنيون معتمدون من سامسونج",
          "خبرة 15 عام في أجهزة سامسونج",
          "معدات تشخيص متطورة",
          "قطع غيار أصلية 100%",
          "ضمان 12 شهر شامل",
          "استجابة خلال 24 ساعة",
          "أسعار تنافسية وشفافة",
          "خدمة عملاء ممتازة",
          "تقارير فنية مفصلة",
          "دعم فني للأجهزة الذكية",
          "تدريب مستمر على أحدث التقنيات",
          "رضا العملاء 98%",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على القطع الأصلية + 6 أشهر على العمالة",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  ariston: {
    name: "اريستون",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/اريستون.png",
    tagline: "التقنية الإيطالية الراقية",
    description: "اريستون من الماركات الإيطالية العالمية المعروفة بجودتها وتقنياتها المتطورة في الأجهزة المنزلية",
    hero: {
      title: "مركز صيانة اريستون",
      subtitle: "خدمات صيانة متخصصة لأجهزة اريستون الإيطالية بضمان شامل",
    },
    sections: [
      {
        title: "عن شركة اريستون الإيطالية",
        icon: Award,
        image: "/placeholder.svg",
        content: [
          "اريستون من الشركات الإيطالية الرائدة في الأجهزة المنزلية",
          "تأسست في إيطاليا وتعمل في أكثر من 150 دولة",
          "معروفة بالتصميم الأنيق والتقنيات المتطورة",
          "متخصصة في السخانات والغسالات والأفران",
          "تلتزم بأعلى معايير الجودة الأوروبية",
          "حازت على جوائز عديدة للتصميم والابتكار",
          "تقدم حلول موفرة للطاقة",
          "شبكة خدمة عالمية موثوقة",
        ],
      },
      {
        title: "خدمات الصيانة المتخصصة",
        icon: Wrench,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "صيانة غسالات اريستون الأوتوماتيك",
          "إصلاح السخانات الكهربائية والغازية",
          "صيانة غسالات الأطباق",
          "إصلاح الأفران والبوتاجازات",
          "صيانة الثلاجات والفريزرات",
          "إصلاح المجففات",
          "صيانة الشاشات الرقمية",
          "استبدال قطع الغيار الأصلية",
          "الصيانة الدورية الشاملة",
          "خدمة طوارئ متاحة",
        ],
      },
      {
        title: "التقنيات المتقدمة في اريستون",
        icon: CheckCircle,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "تقنية الإنفرتر لتوفير الطاقة",
          "نظام التسخين السريع في السخانات",
          "تقنية Anti-Bacterial للحماية الصحية",
          "نظام Steam Hygiene للتعقيم",
          "تقنية الغسيل الصامت Silent System",
          "نظام Auto Dose للتحكم الأوتوماتيكي",
          "تقنية Push&Wash للغسيل بلمسة واحدة",
          "نظام الحماية من التسرب",
          "تقنية Fast Heating السريعة",
          "نظام التشخيص الذكي",
        ],
      },
      {
        title: "الأعطال الشائعة وحلولها",
        icon: Shield,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "مشاكل في السخانات - إصلاح متخصص",
          "أعطال المحرك - قطع غيار أصلية",
          "تسرب المياه - إصلاح فوري",
          "مشاكل في التحكم الإلكتروني - خبراء",
          "أعطال نظام التسخين - صيانة شاملة",
          "مشاكل في المضخة - استبدال",
          "أعطال الثرموستات - معايرة دقيقة",
          "مشاكل في الباب - إصلاح",
          "أعطال الشاشة - استبدال",
          "مشاكل في الصمامات - صيانة",
        ],
      },
      {
        title: "خبرتنا في صيانة اريستون",
        icon: Award,
        image: "/happy-egyptian-male-customer-smiling.jpg",
        content: [
          "فنيون معتمدون من اريستون",
          "خبرة 15 عام في الماركات الأوروبية",
          "قطع غيار أصلية مستوردة",
          "ضمان 12 شهر شامل",
          "معدات فحص متطورة",
          "استجابة سريعة",
          "أسعار تنافسية",
          "تقارير فنية مفصلة",
          "خدمة في كل المحافظات",
          "دعم فني متخصص",
          "صيانة دورية",
          "رضا العملاء",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على القطع الأصلية + 6 أشهر على العمالة",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  frigidaire: {
    name: "فريجيدير",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/فريجيدير.png",
    tagline: "الماركة الأمريكية العريقة",
    description: "فريجيدير من أعرق الماركات الأمريكية في صناعة أجهزة التبريد والأجهزة المنزلية منذ 1918",
    hero: {
      title: "مركز صيانة فريجيدير",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة فريجيدير الأمريكية",
    },
    sections: [
      {
        title: "تاريخ فريجيدير العريق",
        icon: Award,
        image: "/placeholder.svg",
        content: [
          "فريجيدير تأسست عام 1918 في الولايات المتحدة",
          "رائدة في صناعة الثلاجات والتبريد",
          "أكثر من 100 عام من الخبرة والابتكار",
          "تعمل في أكثر من 100 دولة حول العالم",
          "معروفة بالمتانة والجودة الأمريكية",
          "متخصصة في أجهزة التبريد والتكييف",
          "تلتزم بأعلى معايير الجودة",
          "الخيار المفضل للعائلات الأمريكية",
        ],
      },
      {
        title: "خدمات الصيانة الشاملة",
        icon: Wrench,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "صيانة ثلاجات فريجيدير بجميع الأحجام",
          "إصلاح الديب فريزر الرأسي والأفقي",
          "صيانة مكيفات فريجيدير",
          "إصلاح الغسالات والمجففات",
          "صيانة غسالات الأطباق",
          "إصلاح الأفران والميكروويف",
          "صيانة نظام التبريد",
          "استبدال الكمبروسر والمراوح",
          "شحن غاز الفريون",
          "الصيانة الدورية الشاملة",
        ],
      },
      {
        title: "مميزات أجهزة فريجيدير",
        icon: CheckCircle,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "تقنية التبريد الفائق PureSource",
          "نظام الحفظ الطازج الطويل",
          "تصميم أمريكي كلاسيكي",
          "متانة وعمر افتراضي طويل",
          "كفاءة عالية في استهلاك الطاقة",
          "سعات كبيرة مناسبة للعائلات",
          "تقنية SpaceWise لتنظيم الفراغات",
          "نظام التحكم الدقيق في الحرارة",
          "ضمان معتمد من الشركة",
          "سهولة الصيانة",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "ضعف التبريد - فحص دائرة التبريد",
          "تسرب الفريون - كشف وإصلاح",
          "أعطال الكمبروسر - صيانة أو استبدال",
          "مشاكل في الثرموستات - معايرة",
          "تجمد الثلاجة - ضبط الحرارة",
          "أصوات غير طبيعية - صيانة",
          "مشاكل في صانع الثلج - إصلاح",
          "تسرب المياه - إصلاح التصريف",
          "عدم التشغيل - فحص كهربائي",
          "مشاكل في الباب - ضبط أو استبدال",
        ],
      },
      {
        title: "خبرتنا في فريجيدير",
        icon: Award,
        image: "/happy-middle-aged-egyptian-man.jpg",
        content: [
          "خبرة 20 عام في الماركات الأمريكية",
          "فنيون متخصصون في التبريد",
          "قطع غيار أصلية مستوردة",
          "ضمان 12 شهر على الخدمات",
          "معدات فحص أمريكية",
          "استجابة سريعة",
          "أسعار عادلة",
          "خدمة في كل المحافظات",
          "تقارير فنية مفصلة",
          "نصائح مفيدة",
          "صيانة دورية",
          "رضا العملاء",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات والقطع",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  "general-electric": {
    name: "جنرال اليكتريك",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/جنرال اليكتريك.png",
    tagline: "الابتكار الأمريكي منذ 1892",
    description: "جنرال اليكتريك (GE) من أعرق الشركات الأمريكية العالمية في صناعة الأجهزة الكهربائية والمنزلية",
    hero: {
      title: "مركز صيانة جنرال اليكتريك",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة GE بمعايير الجودة الأمريكية",
    },
    sections: [
      {
        title: "عن جنرال اليكتريك",
        icon: Award,
        image: "/placeholder.svg",
        content: [
          "جنرال اليكتريك تأسست عام 1892 في أمريكا",
          "من أكبر الشركات العالمية في الإلكترونيات",
          "أكثر من 130 عام من الابتكار",
          "رائدة في التكنولوجيا والتصنيع",
          "تعمل في أكثر من 180 دولة",
          "معايير جودة أمريكية صارمة",
          "متخصصة في الأجهزة الثقيلة والمنزلية",
          "الخيار الأول للمؤسسات والشركات",
        ],
      },
      {
        title: "خدمات الصيانة المتخصصة",
        icon: Wrench,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "صيانة ثلاجات GE بجميع الأنواع",
          "إصلاح غسالات ومجففات GE",
          "صيانة غسالات الأطباق",
          "إصلاح الأفران والميكروويف",
          "صيانة مكيفات GE",
          "إصلاح السخانات",
          "صيانة الأنظمة الإلكترونية",
          "استبدال قطع الغيار الأصلية",
          "تحديث البرامج",
          "الصيانة الدورية الشاملة",
        ],
      },
      {
        title: "التقنيات المتقدمة في GE",
        icon: CheckCircle,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "تقنية SmartDispense الذكية",
          "نظام WiFi Connect للتحكم عن بعد",
          "تقنية Precise Fill للملء الدقيق",
          "نظام UltraFresh Vent للتهوية",
          "تقنية TwinChill Evaporators",
          "نظام Autofill للملء الأوتوماتيكي",
          "تقنية Deep Fill للملء العميق",
          "نظام الحماية المتقدم",
          "تقنية التشخيص عن بعد",
          "نظام توفير الطاقة الذكي",
        ],
      },
      {
        title: "الأعطال الشائعة وحلولها",
        icon: Shield,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "مشاكل في الأنظمة الذكية - دعم فني",
          "أعطال المحرك - صيانة متخصصة",
          "مشاكل في التبريد - فحص شامل",
          "أعطال WiFi - إعادة برمجة",
          "مشاكل في نظام SmartDispense - إصلاح",
          "أعطال الكمبروسر - استبدال",
          "مشاكل في التحكم الإلكتروني - خبراء",
          "تسرب المياه - إصلاح",
          "أعطال الشاشة - استبدال",
          "مشاكل في المستشعرات - معايرة",
        ],
      },
      {
        title: "لماذا نحن الأفضل لـ GE؟",
        icon: Award,
        image: "/happy-egyptian-male-customer-smiling.jpg",
        content: [
          "فنيون معتمدون من GE",
          "خبرة 18 عام في الماركات الأمريكية",
          "قطع غيار أصلية مستوردة",
          "معدات تشخيص حديثة",
          "ضمان 12 شهر شامل",
          "دعم فني للأنظمة الذكية",
          "استجابة سريعة",
          "أسعار تنافسية",
          "تقارير تفصيلية",
          "خدمة في كل المحافظات",
          "تدريب مستمر",
          "رضا العملاء 98%",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على القطع والعمالة",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  vaguer: {
    name: "فاجوار",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/فاجوار.png",
    tagline: "الجودة والأداء المتميز",
    description: "فاجوار من الماركات المعروفة في السوق المصري بأدائها الجيد وأسعارها المناسبة",
    hero: {
      title: "مركز صيانة فاجوار",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة فاجوار المنزلية",
    },
    sections: [
      {
        title: "عن شركة فاجوار",
        icon: Award,
        image: "/placeholder.svg",
        content: [
          "فاجوار من الماركات المعروفة في السوق",
          "تقدم مجموعة متنوعة من الأجهزة",
          "معروفة بالأداء الجيد",
          "أسعار مناسبة للأسر المصرية",
          "شبكة خدمة منتشرة",
          "ضمان معتمد",
          "تصميمات عملية",
          "قطع غيار متوفرة",
        ],
      },
      {
        title: "خدمات الصيانة",
        icon: Wrench,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "صيانة غسالات فاجوار",
          "إصلاح الثلاجات والفريزرات",
          "صيانة المكيفات",
          "إصلاح غسالات الأطباق",
          "صيانة المجففات",
          "إصلاح الميكروويف",
          "استبدال قطع الغيار",
          "الصيانة الدورية",
          "فحص شامل",
          "خدمة سريعة",
        ],
      },
      {
        title: "مميزات الخدمة",
        icon: CheckCircle,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "فنيون متخصصون",
          "قطع غيار أصلية",
          "ضمان 12 شهر",
          "أسعار مناسبة",
          "استجابة سريعة",
          "خدمة منزلية",
          "تقارير واضحة",
          "نصائح مفيدة",
          "صيانة دورية",
          "رضا العملاء",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "مشاكل في التبريد",
          "أعطال المحرك",
          "تسرب المياه",
          "أصوات غير طبيعية",
          "مشاكل في التحكم",
          "عدم التصريف",
          "مشاكل في الباب",
          "استهلاك عالي",
          "رائحة كريهة",
          "عدم العمل",
        ],
      },
      {
        title: "ضمانات الجودة",
        icon: Award,
        image: "/happy-middle-aged-egyptian-man.jpg",
        content: [
          "خبرة طويلة",
          "فنيون مدربون",
          "معدات حديثة",
          "قطع أصلية",
          "ضمان مكتوب",
          "أسعار عادلة",
          "خدمة سريعة",
          "تقارير شفافة",
          "متابعة مستمرة",
          "رضا تام",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  westinghouse: {
    name: "وستنجهاوس",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/وستنجهاوس.png",
    tagline: "التقنية الأمريكية العريقة",
    description: "وستنجهاوس من الماركات الأمريكية العريقة المعروفة بتقنياتها المتقدمة والجودة العالية",
    hero: {
      title: "مركز صيانة وستنجهاوس",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة وستنجهاوس الأمريكية",
    },
    sections: [
      {
        title: "عن شركة وستنجهاوس",
        icon: Award,
        image: "/placeholder.svg",
        content: [
          "وستنجهاوس من الماركات الأمريكية العريقة",
          "تأسست في الولايات المتحدة",
          "معروفة بالتقنيات المتطورة",
          "تقدم أجهزة منزلية عالية الجودة",
          "منتشرة عالمياً",
          "معايير جودة أمريكية",
          "تصميمات عصرية",
          "شبكة خدمة موثوقة",
        ],
      },
      {
        title: "خدمات الصيانة",
        icon: Wrench,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "صيانة غسالات وستنجهاوس",
          "إصلاح الثلاجات والفريزرات",
          "صيانة المكيفات",
          "إصلاح غسالات الأطباق",
          "صيانة المجففات",
          "إصلاح الميكروويف",
          "استبدال قطع غيار أصلية",
          "الصيانة الدورية",
          "فحص شامل",
          "خدمة سريعة",
        ],
      },
      {
        title: "مميزات الخدمة",
        icon: CheckCircle,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "فنيون متخصصون",
          "قطع غيار أصلية",
          "ضمان 12 شهر",
          "أسعار منافسة",
          "استجابة سريعة",
          "خدمة منزلية",
          "تقارير واضحة",
          "نصائح مفيدة",
          "صيانة دورية",
          "رضا العملاء",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "مشاكل في التبريد",
          "أعطال المحرك",
          "تسرب المياه",
          "أصوات غير طبيعية",
          "مشاكل في التحكم",
          "عدم التصريف",
          "مشاكل في الباب",
          "استهلاك عالي",
          "رائحة كريهة",
          "عدم العمل",
        ],
      },
      {
        title: "خبرتنا",
        icon: Award,
        image: "/happy-egyptian-male-customer-smiling.jpg",
        content: [
          "خبرة 15 عام",
          "فنيون معتمدون",
          "قطع غيار أصلية",
          "ضمان 12 شهر",
          "استجابة سريعة",
          "أسعار عادلة",
          "خدمة منزلية",
          "تقارير مفصلة",
          "نصائح مفيدة",
          "صيانة دورية",
          "رضا العملاء",
          "خدمة ممتازة",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  "white-westinghouse": {
    name: "وايت وستنجهاوس",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/وايت وستنجهاوس.png",
    tagline: "الجودة الأمريكية الممتازة",
    description: "وايت وستنجهاوس من الماركات الأمريكية المعروفة بجودتها العالية وأدائها الممتاز",
    hero: {
      title: "مركز صيانة وايت وستنجهاوس",
      subtitle: "خدمات صيانة متخصصة لأجهزة وايت وستنجهاوس بضمان شامل",
    },
    sections: [
      {
        title: "عن وايت وستنجهاوس",
        icon: Award,
        image: "/placeholder.svg",
        content: [
          "وايت وستنجهاوس ماركة أمريكية مشهورة",
          "معروفة بالجودة والمتانة",
          "تقدم أجهزة منزلية متنوعة",
          "أسعار مناسبة للسوق",
          "شبكة خدمة واسعة",
          "ضمان معتمد",
          "تصميمات عملية",
          "قطع غيار متوفرة",
        ],
      },
      {
        title: "خدمات الصيانة المتخصصة",
        icon: Wrench,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "صيانة غسالات وايت وستنجهاوس",
          "إصلاح الثلاجات",
          "صيانة المكيفات",
          "إصلاح غسالات الأطباق",
          "صيانة المجففات",
          "إصلاح الميكروويف",
          "استبدال القطع",
          "الصيانة الدورية",
          "فحص شامل",
          "خدمة سريعة",
        ],
      },
      {
        title: "مميزات الخدمة",
        icon: CheckCircle,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "فنيون متخصصون",
          "قطع غيار أصلية",
          "ضمان شامل",
          "أسعار منافسة",
          "استجابة سريعة",
          "خدمة منزلية",
          "تقارير واضحة",
          "نصائح مفيدة",
          "صيانة دورية",
          "رضا العملاء",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "مشاكل التبريد",
          "أعطال المحرك",
          "تسرب المياه",
          "أصوات غير طبيعية",
          "مشاكل التحكم",
          "عدم التصريف",
          "مشاكل الباب",
          "استهلاك عالي",
          "رائحة كريهة",
          "عدم العمل",
        ],
      },
      {
        title: "ضمانات الجودة",
        icon: Award,
        image: "/happy-middle-aged-egyptian-man.jpg",
        content: [
          "خبرة طويلة",
          "فنيون مدربون",
          "معدات حديثة",
          "قطع أصلية",
          "ضمان مكتوب",
          "أسعار عادلة",
          "خدمة سريعة",
          "تقارير شفافة",
          "متابعة مستمرة",
          "رضا تام",
          "خدمة ممتازة",
          "دعم كامل",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  kelvinator: {
    name: "كلفنيتور",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/كلفينيتور.png",
    tagline: "التبريد الأمريكي الأصلي",
    description: "كلفنيتور من أقدم الماركات الأمريكية المتخصصة في أجهزة التبريد والأجهزة المنزلية",
    hero: {
      title: "مركز صيانة كلفنيتور",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة كلفنيتور بخبرة عالية",
    },
    sections: [
      {
        title: "عن كلفنيتور",
        icon: Award,
        image: "/placeholder.svg",
        content: [
          "كلفنيتور من أقدم ماركات التبريد الأمريكية",
          "معروفة بجودة التبريد العالية",
          "متخصصة في الثلاجات والفريزرات",
          "تاريخ عريق في الصناعة",
          "معايير جودة أمريكية",
          "متانة وموثوقية",
          "شبكة خدمة واسعة",
          "قطع غيار متوفرة",
        ],
      },
      {
        title: "خدمات الصيانة",
        icon: Wrench,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "صيانة ثلاجات كلفنيتور",
          "إصلاح الديب فريزر",
          "صيانة نظام التبريد",
          "إصلاح الكمبروسر",
          "شحن غاز الفريون",
          "استبدال الثرموستات",
          "إصلاح الجوان",
          "صيانة المراوح",
          "الصيانة الدورية",
          "فحص شامل",
        ],
      },
      {
        title: "مميزات كلفنيتور",
        icon: CheckCircle,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "تقنية تبريد متقدمة",
          "كفاءة عالية في التبريد",
          "استهلاك طاقة اقتصادي",
          "متانة وعمر طويل",
          "سعات كبيرة",
          "تصميم كلاسيكي",
          "سهولة الصيانة",
          "ضمان معتمد",
          "أداء موثوق",
          "قطع غيار متوفرة",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "ضعف التبريد",
          "تسرب الفريون",
          "أعطال الكمبروسر",
          "مشاكل الثرموستات",
          "تجمد الثلاجة",
          "أصوات غير طبيعية",
          "تسرب المياه",
          "تلف الجوان",
          "عدم التشغيل",
          "استهلاك عالي",
        ],
      },
      {
        title: "خبرتنا",
        icon: Award,
        image: "/happy-egyptian-male-customer-smiling.jpg",
        content: [
          "خبرة 20 عام في التبريد",
          "فنيون متخصصون",
          "قطع غيار أصلية",
          "ضمان 12 شهر",
          "معدات فحص حديثة",
          "استجابة سريعة",
          "أسعار عادلة",
          "خدمة منزلية",
          "تقارير مفصلة",
          "نصائح مفيدة",
          "صيانة دورية",
          "رضا العملاء",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  siemens: {
    name: "سيمنز",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/سيمنز.png",
    tagline: "الهندسة الألمانية الدقيقة",
    description: "سيمنز من أعرق الشركات الألمانية العالمية المعروفة بالهندسة الدقيقة والجودة الفائقة",
    hero: {
      title: "مركز صيانة سيمنز",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة سيمنز الألمانية بأعلى معايير الجودة",
    },
    sections: [
      {
        title: "عن سيمنز الألمانية",
        icon: Award,
        image: "/placeholder.svg",
        content: [
          "سيمنز شركة ألمانية عريقة تأسست عام 1847",
          "من أكبر الشركات العالمية في الهندسة والتكنولوجيا",
          "معروفة بالدقة والجودة الألمانية",
          "تقدم أجهزة منزلية فاخرة",
          "تقنيات متطورة ومبتكرة",
          "معايير جودة أوروبية صارمة",
          "تصميمات أنيقة وعصرية",
          "شبكة خدمة عالمية موثوقة",
        ],
      },
      {
        title: "خدمات الصيانة المتخصصة",
        icon: Wrench,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "صيانة غسالات سيمنز بتقنية iSensoric",
          "إصلاح ثلاجات سيمنز بنظام noFrost",
          "صيانة غسالات الأطباق بتقنية zeolith",
          "إصلاح الأفران والمايكروويف",
          "صيانة المجففات بنظام الحساسات",
          "إصلاح البوتاجازات والشفاطات",
          "صيانة الأنظمة الإلكترونية المتقدمة",
          "تحديث البرامج الذكية",
          "استبدال قطع الغيار الألمانية الأصلية",
          "الصيانة الدورية الشاملة",
        ],
      },
      {
        title: "التقنيات الألمانية المتقدمة",
        icon: CheckCircle,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "تقنية iSensoric للتحكم الذكي",
          "نظام varioPerfect لتوفير الوقت والطاقة",
          "تقنية noFrost لمنع التجمد",
          "نظام Home Connect للتحكم عن بعد",
          "تقنية zeolith للتجفيف الاقتصادي",
          "نظام antiVibration للتشغيل الهادئ",
          "تقنية speedPerfect للأداء السريع",
          "نظام Self-Cleaning للتنظيف الذاتي",
          "تقنية LED الموفرة للطاقة",
          "نظام الحماية الذكي AquaStop",
        ],
      },
      {
        title: "الأعطال الشائعة وحلولها",
        icon: Shield,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "مشاكل في الأنظمة الإلكترونية - خبراء ألمان",
          "أعطال المحرك الذكي - صيانة متخصصة",
          "مشاكل في Home Connect - دعم فني",
          "أعطال نظام noFrost - إصلاح احترافي",
          "مشاكل في الحساسات - معايرة دقيقة",
          "أعطال لوحة التحكم - استبدال أصلي",
          "مشاكل في نظام AquaStop - إصلاح",
          "أعطال المضخة - استبدال",
          "مشاكل في الشاشة الرقمية - إصلاح",
          "أعطال في نظام التجفيف - صيانة",
        ],
      },
      {
        title: "لماذا نحن الأفضل لسيمنز؟",
        icon: Award,
        image: "/happy-egyptian-male-customer-smiling.jpg",
        content: [
          "فنيون معتمدون من سيمنز",
          "خبرة 18 عام في الأجهزة الألمانية",
          "قطع غيار ألمانية أصلية 100%",
          "معدات تشخيص متطورة",
          "ضمان 12 شهر شامل",
          "دعم فني للأنظمة الذكية",
          "استجابة سريعة خلال 24 ساعة",
          "أسعار تنافسية وشفافة",
          "تقارير فنية تفصيلية",
          "خدمة في جميع المحافظات",
          "تدريب مستمر على أحدث التقنيات",
          "رضا العملاء 99%",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على القطع الألمانية + 6 أشهر على العمالة",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  zanussi: {
    name: "زانوسي",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/زانوسي.png",
    tagline: "التصميم الإيطالي الأنيق",
    description: "زانوسي من الماركات الإيطالية الشهيرة المعروفة بتصميماتها الأنيقة وجودتها العالية",
    hero: {
      title: "مركز صيانة زانوسي",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة زانوسي الإيطالية",
    },
    sections: [
      {
        title: "عن زانوسي الإيطالية",
        icon: Award,
        image: "/placeholder.svg",
        content: [
          "زانوسي شركة إيطالية عريقة",
          "معروفة بالتصميم الأنيق",
          "تقدم أجهزة منزلية عالية الجودة",
          "جزء من مجموعة Electrolux العالمية",
          "معايير جودة أوروبية",
          "تقنيات متطورة",
          "منتشرة عالمياً",
          "شبكة خدمة موثوقة",
        ],
      },
      {
        title: "خدمات الصيانة",
        icon: Wrench,
        image: "/washing-machine-repair-technician.jpg",
        content: [
          "صيانة غسالات زانوسي",
          "إصلاح الثلاجات والفريزرات",
          "صيانة غسالات الأطباق",
          "إصلاح الأفران والبوتاجازات",
          "صيانة المجففات",
          "إصلاح الشفاطات",
          "استبدال قطع غيار أصلية",
          "الصيانة الدورية",
          "فحص شامل",
          "خدمة سريعة",
        ],
      },
      {
        title: "مميزات زانوسي",
        icon: CheckCircle,
        image: "/refrigerator-repair-service.jpg",
        content: [
          "تصميم إيطالي أنيق",
          "جودة أوروبية عالية",
          "تقنيات متطورة",
          "كفاءة في استهلاك الطاقة",
          "متانة وموثوقية",
          "سهولة الاستخدام",
          "أسعار مناسبة",
          "ضمان معتمد",
          "أداء ممتاز",
          "قطع غيار متوفرة",
        ],
      },
      {
        title: "الأعطال الشائعة",
        icon: Shield,
        image: "/professional-technician-repairing-washing-machine.jpg",
        content: [
          "مشاكل في التبريد",
          "أعطال المحرك",
          "تسرب المياه",
          "أصوات غير طبيعية",
          "مشاكل في التحكم",
          "عدم التصريف",
          "مشاكل في الباب",
          "استهلاك عالي",
          "رائحة كريهة",
          "عدم العمل",
        ],
      },
      {
        title: "خبرتنا في زانوسي",
        icon: Award,
        image: "/happy-middle-aged-egyptian-man.jpg",
        content: [
          "خبرة 15 عام",
          "فنيون متخصصون",
          "قطع غيار أصلية",
          "ضمان 12 شهر",
          "معدات حديثة",
          "استجابة سريعة",
          "أسعار عادلة",
          "خدمة منزلية",
          "تقارير مفصلة",
          "نصائح مفيدة",
          "صيانة دورية",
          "رضا العملاء",
        ],
      },
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  ideal: {
    name: "ايديال",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/ايديال.png",
    tagline: "الجودة المثالية",
    description: "ايديال من الماركات المعروفة في مصر بجودتها وأسعارها المناسبة",
    hero: {
      title: "مركز صيانة ايديال",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة ايديال المنزلية",
    },
    sections: [
      {title: "عن شركة ايديال", icon: Award, image: "/placeholder.svg", content: ["ايديال من الماركات المعروفة", "تقدم أجهزة منزلية متنوعة", "معروفة بالجودة الجيدة", "أسعار مناسبة للسوق المصري", "شبكة خدمة منتشرة", "ضمان معتمد", "تصميمات عملية", "قطع غيار متوفرة"]},
      {title: "خدمات الصيانة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات ايديال", "إصلاح الثلاجات والفريزرات", "صيانة المكيفات", "إصلاح غسالات الأطباق", "صيانة المجففات", "إصلاح الميكروويف", "استبدال قطع الغيار", "الصيانة الدورية", "فحص شامل", "خدمة سريعة"]},
      {title: "مميزات الخدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["فنيون متخصصون", "قطع غيار أصلية", "ضمان 12 شهر", "أسعار مناسبة", "استجابة سريعة", "خدمة منزلية", "تقارير واضحة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في التبريد", "أعطال المحرك", "تسرب المياه", "أصوات غير طبيعية", "مشاكل في التحكم", "عدم التصريف", "مشاكل في الباب", "استهلاك عالي", "رائحة كريهة", "عدم العمل"]},
      {title: "خبرتنا", icon: Award, image: "/happy-egyptian-male-customer-smiling.jpg", content: ["خبرة 15 عام", "فنيون معتمدون", "قطع غيار أصلية", "ضمان شامل", "استجابة سريعة", "أسعار عادلة", "خدمة منزلية", "تقارير مفصلة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء", "خدمة ممتازة"]},
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  sharp: {
    name: "شارب",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/شارب.png",
    tagline: "التقنية اليابانية العريقة",
    description: "شارب من الشركات اليابانية الرائدة في مجال الإلكترونيات والأجهزة المنزلية",
    hero: {
      title: "مركز صيانة شارب",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة شارب اليابانية",
    },
    sections: [
      {title: "عن شارب اليابانية", icon: Award, image: "/placeholder.svg", content: ["شارب شركة يابانية عريقة تأسست عام 1912", "رائدة في تكنولوجيا الشاشات والإلكترونيات", "معروفة بالجودة اليابانية العالية", "تقدم أجهزة منزلية متطورة", "تقنيات مبتكرة ومتقدمة", "معايير جودة يابانية صارمة", "منتشرة في أكثر من 100 دولة", "شبكة خدمة عالمية موثوقة"]},
      {title: "خدمات الصيانة المتخصصة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات شارب الأوتوماتيك", "إصلاح ثلاجات شارب بتقنية البلازما كلاستر", "صيانة مكيفات شارب الإنفرتر", "إصلاح التلفزيونات والشاشات الذكية", "صيانة الميكروويف والأفران", "إصلاح المراوح والشفاطات", "صيانة الأنظمة الإلكترونية", "تحديث البرامج الذكية", "استبدال قطع الغيار اليابانية", "الصيانة الدورية الشاملة"]},
      {title: "التقنيات اليابانية المتقدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["تقنية Plasmacluster للتنقية والتعقيم", "نظام Inverter لتوفير الطاقة", "تقنية J-Tech الذكية", "نظام الغسيل بالفقاعات", "تقنية التبريد السريع", "نظام التحكم الذكي", "تقنية LED المتطورة", "نظام الحماية الشامل", "تقنية التشغيل الهادئ", "نظام التشخيص الذكي"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في نظام Plasmacluster", "أعطال المحرك الإنفرتر", "مشاكل في الأنظمة الإلكترونية", "أعطال الشاشات الذكية", "مشاكل في التبريد", "أعطال لوحة التحكم", "مشاكل في المستشعرات", "تسرب المياه", "أعطال في نظام التجفيف", "مشاكل في الصوت والصورة"]},
      {title: "خبرتنا في شارب", icon: Award, image: "/happy-egyptian-male-customer-smiling.jpg", content: ["فنيون معتمدون من شارب", "خبرة 17 عام في الأجهزة اليابانية", "قطع غيار يابانية أصلية", "معدات تشخيص متطورة", "ضمان 12 شهر شامل", "دعم فني متخصص", "استجابة سريعة", "أسعار تنافسية", "تقارير فنية مفصلة", "خدمة في كل المحافظات", "تدريب مستمر", "رضا العملاء"]},
    ],
    warranty: "ضمان 12 شهر على القطع اليابانية + 6 أشهر على العمالة",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  toshiba: {
    name: "توشيبا",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/توشيبا.png",
    tagline: "الابتكار الياباني الرائد",
    description: "توشيبا من أعرق الشركات اليابانية في مجال التكنولوجيا والأجهزة المنزلية",
    hero: {
      title: "مركز صيانة توشيبا",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة توشيبا بمعايير الجودة اليابانية",
    },
    sections: [
      {title: "عن توشيبا اليابانية", icon: Award, image: "/placeholder.svg", content: ["توشيبا تأسست في اليابان عام 1875", "من أقدم الشركات اليابانية في الإلكترونيات", "رائدة في تكنولوجيا الحاسوب والإلكترونيات", "معروفة بالجودة والموثوقية اليابانية", "تقنيات متطورة ومبتكرة", "معايير جودة يابانية عالمية", "منتشرة في جميع أنحاء العالم", "شبكة خدمة عالمية موثوقة"]},
      {title: "خدمات الصيانة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات توشيبا الأوتوماتيك", "إصلاح ثلاجات توشيبا", "صيانة مكيفات توشيبا الإنفرتر", "إصلاح التلفزيونات والشاشات", "صيانة الميكروويف", "إصلاح اللاب توب والأجهزة", "صيانة الأنظمة الإلكترونية", "تحديث البرامج", "استبدال قطع غيار يابانية", "الصيانة الدورية"]},
      {title: "التقنيات المتقدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["تقنية الإنفرتر اليابانية", "نظام Great Waves للغسيل", "تقنية Picoion للتعقيم", "نظام التبريد المتقدم", "تقنية Hybrid Inverter", "نظام التحكم الذكي", "تقنية LED المتطورة", "نظام الحماية الشامل", "تقنية التوفير في الطاقة", "نظام التشخيص الذكي"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في نظام الإنفرتر", "أعطال المحرك", "مشاكل في الأنظمة الإلكترونية", "أعطال الشاشة", "مشاكل في التبريد", "أعطال لوحة التحكم", "مشاكل في المستشعرات", "تسرب المياه", "أعطال في التجفيف", "مشاكل في الصوت"]},
      {title: "خبرتنا في توشيبا", icon: Award, image: "/happy-middle-aged-egyptian-man.jpg", content: ["فنيون معتمدون من توشيبا", "خبرة 18 عام", "قطع غيار يابانية", "معدات فحص حديثة", "ضمان 12 شهر", "دعم فني", "استجابة سريعة", "أسعار عادلة", "تقارير مفصلة", "خدمة شاملة", "تدريب مستمر", "رضا العملاء"]},
    ],
    warranty: "ضمان 12 شهر على القطع + 6 أشهر على العمالة",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  hitachi: {
    name: "هيتاشي",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/هيتاشي.webp",
    tagline: "التكنولوجيا اليابانية الفائقة",
    description: "هيتاشي من الشركات اليابانية العملاقة المعروفة بتقنياتها الفائقة في الأجهزة المنزلية",
    hero: {
      title: "مركز صيانة هيتاشي",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة هيتاشي اليابانية",
    },
    sections: [
      {title: "عن هيتاشي اليابانية", icon: Award, image: "/placeholder.svg", content: ["هيتاشي شركة يابانية عملاقة", "تأسست عام 1910 في اليابان", "من أكبر شركات التكنولوجيا العالمية", "معروفة بالتقنيات المتطورة", "تقدم أجهزة عالية الجودة", "معايير يابانية صارمة", "منتشرة عالمياً", "شبكة خدمة موثوقة"]},
      {title: "خدمات الصيانة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات هيتاشي", "إصلاح ثلاجات هيتاشي", "صيانة مكيفات هيتاشي", "إصلاح الأجهزة الإلكترونية", "صيانة المجففات", "إصلاح الميكروويف", "استبدال القطع", "الصيانة الدورية", "فحص شامل", "خدمة سريعة"]},
      {title: "التقنيات المتقدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["تقنية Inverter المتطورة", "نظام Air Purification", "تقنية Frost Recycling", "نظام Beat Wave الذكي", "تقنية التحكم الدقيق", "نظام توفير الطاقة", "تقنية التشغيل الهادئ", "نظام الحماية", "تقنية التبريد السريع", "نظام التشخيص"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في الإنفرتر", "أعطال المحرك", "مشاكل في التبريد", "أعطال إلكترونية", "مشاكل في التحكم", "تسرب المياه", "أعطال في المستشعرات", "مشاكل في الباب", "استهلاك عالي", "عدم العمل"]},
      {title: "خبرتنا", icon: Award, image: "/happy-egyptian-male-customer-smiling.jpg", content: ["فنيون معتمدون", "خبرة 16 عام", "قطع غيار أصلية", "ضمان 12 شهر", "معدات حديثة", "استجابة سريعة", "أسعار عادلة", "خدمة منزلية", "تقارير مفصلة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء"]},
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  alaska: {
    name: "ألاسكا",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/ألاسكا.png",
    tagline: "برودة القطب الشمالي",
    description: "ألاسكا من الماركات المتخصصة في أجهزة التكييف والتبريد بكفاءة عالية",
    hero: {
      title: "مركز صيانة ألاسكا",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة ألاسكا",
    },
    sections: [
      {title: "عن شركة ألاسكا", icon: Award, image: "/placeholder.svg", content: ["ألاسكا متخصصة في التكييف والتبريد", "معروفة بالكفاءة العالية", "تقدم أجهزة بأسعار مناسبة", "منتشرة في السوق المصري", "شبكة خدمة متوفرة", "ضمان معتمد", "تصميمات عملية", "قطع غيار متوفرة"]},
      {title: "خدمات الصيانة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة مكيفات ألاسكا السبليت", "إصلاح مكيفات الشباك", "صيانة الثلاجات", "إصلاح الديب فريزر", "صيانة نظام التبريد", "شحن غاز الفريون", "تنظيف الفلاتر", "الصيانة الدورية", "فحص شامل", "خدمة سريعة"]},
      {title: "مميزات الخدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["فنيون متخصصون", "قطع غيار أصلية", "ضمان 12 شهر", "أسعار مناسبة", "استجابة سريعة", "خدمة منزلية", "تقارير واضحة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["ضعف التبريد", "تسرب الفريون", "أصوات غير طبيعية", "عدم التشغيل", "تسرب المياه", "رائحة كريهة", "استهلاك عالي", "مشاكل في الريموت", "تجمد الوحدة", "مشاكل في المروحة"]},
      {title: "خبرتنا", icon: Award, image: "/happy-egyptian-male-customer-smiling.jpg", content: ["خبرة 14 عام", "فنيون معتمدون", "قطع غيار أصلية", "ضمان شامل", "استجابة سريعة", "أسعار عادلة", "خدمة منزلية", "تقارير مفصلة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء", "خدمة ممتازة"]},
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  hoover: {
    name: "هوڤر",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/هوڤر...png",
    tagline: "الأداء القوي والموثوق",
    description: "هوڤر من الماركات المعروفة عالمياً بأجهزتها القوية والفعالة",
    hero: {
      title: "مركز صيانة هوڤر",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة هوڤر المنزلية",
    },
    sections: [
      {title: "عن شركة هوڤر", icon: Award, image: "/placeholder.svg", content: ["هوڤر ماركة عالمية معروفة", "متخصصة في المكانس والغسالات", "معروفة بالأداء القوي", "منتشرة في أكثر من 50 دولة", "تقدم أجهزة عالية الجودة", "ضمان معتمد", "تصميمات عملية", "قطع غيار متوفرة"]},
      {title: "خدمات الصيانة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات هوڤر", "إصلاح المكانس الكهربائية", "صيانة المجففات", "إصلاح غسالات الأطباق", "صيانة المحركات", "استبدال قطع الغيار", "تنظيف الفلاتر", "الصيانة الدورية", "فحص شامل", "خدمة سريعة"]},
      {title: "مميزات الخدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["فنيون متخصصون", "قطع غيار أصلية", "ضمان 12 شهر", "أسعار مناسبة", "استجابة سريعة", "خدمة منزلية", "تقارير واضحة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في المحرك", "أعطال الشفط", "تسرب المياه", "أصوات غير طبيعية", "مشاكل في التحكم", "عدم التصريف", "مشاكل في الباب", "استهلاك عالي", "رائحة كريهة", "عدم العمل"]},
      {title: "خبرتنا", icon: Award, image: "/happy-middle-aged-egyptian-man.jpg", content: ["خبرة 13 عام", "فنيون معتمدون", "قطع غيار أصلية", "ضمان شامل", "استجابة سريعة", "أسعار عادلة", "خدمة منزلية", "تقارير مفصلة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء", "خدمة ممتازة"]},
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  daewoo: {
    name: "دايو",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/دايو.png",
    tagline: "التكنولوجيا الكورية المتقدمة",
    description: "دايو من الشركات الكورية المعروفة بتقنياتها وأجهزتها المنزلية المتنوعة",
    hero: {
      title: "مركز صيانة دايو",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة دايو الكورية",
    },
    sections: [
      {title: "عن دايو الكورية", icon: Award, image: "/placeholder.svg", content: ["دايو شركة كورية معروفة", "تقدم أجهزة منزلية متنوعة", "معروفة بالتقنيات المتقدمة", "أسعار مناسبة للسوق", "شبكة خدمة منتشرة", "ضمان معتمد", "تصميمات عصرية", "قطع غيار متوفرة"]},
      {title: "خدمات الصيانة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات دايو", "إصلاح الثلاجات", "صيانة المكيفات", "إصلاح الميكروويف", "صيانة المجففات", "إصلاح غسالات الأطباق", "استبدال القطع", "الصيانة الدورية", "فحص شامل", "خدمة سريعة"]},
      {title: "مميزات الخدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["فنيون متخصصون", "قطع غيار أصلية", "ضمان 12 شهر", "أسعار مناسبة", "استجابة سريعة", "خدمة منزلية", "تقارير واضحة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في التبريد", "أعطال المحرك", "تسرب المياه", "أصوات غير طبيعية", "مشاكل في التحكم", "عدم التصريف", "مشاكل في الباب", "استهلاك عالي", "رائحة كريهة", "عدم العمل"]},
      {title: "خبرتنا", icon: Award, image: "/happy-egyptian-male-customer-smiling.jpg", content: ["خبرة 15 عام", "فنيون معتمدون", "قطع غيار أصلية", "ضمان شامل", "استجابة سريعة", "أسعار عادلة", "خدمة منزلية", "تقارير مفصلة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء", "خدمة ممتازة"]},
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  electrolux: {
    name: "اليكترلوكس",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/اليكترلوكس.png",
    tagline: "الجودة السويدية العالمية",
    description: "اليكترلوكس من أكبر الشركات السويدية العالمية في مجال الأجهزة المنزلية",
    hero: {
      title: "مركز صيانة اليكترلوكس",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة اليكترلوكس السويدية",
    },
    sections: [
      {title: "عن اليكترلوكس السويدية", icon: Award, image: "/placeholder.svg", content: ["اليكترلوكس شركة سويدية عالمية", "تأسست عام 1919", "من أكبر شركات الأجهزة المنزلية", "تعمل في أكثر من 150 دولة", "معروفة بالجودة الأوروبية", "تقنيات متطورة ومبتكرة", "معايير بيئية صارمة", "شبكة خدمة عالمية"]},
      {title: "خدمات الصيانة المتخصصة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات اليكترلوكس", "إصلاح الثلاجات والفريزرات", "صيانة غسالات الأطباق", "إصلاح الأفران والمايكروويف", "صيانة المجففات", "إصلاح الشفاطات", "صيانة الأنظمة الإلكترونية", "تحديث البرامج", "استبدال قطع غيار أصلية", "الصيانة الدورية الشاملة"]},
      {title: "التقنيات المتقدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["تقنية UltraMix للغسيل المثالي", "نظام PerfectCare لحماية الأقمشة", "تقنية AirDry للتجفيف", "نظام TwinTech للتبريد", "تقنية SensiCare الذكية", "نظام SteamBoost للبخار", "تقنية ProSteam للعناية", "نظام DualClean", "تقنية توفير الطاقة", "نظام التشخيص الذكي"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في الأنظمة الإلكترونية", "أعطال المحرك", "مشاكل في التبريد", "أعطال المستشعرات", "مشاكل في التحكم", "تسرب المياه", "أعطال المضخة", "مشاكل في الباب", "استهلاك عالي", "مشاكل في التجفيف"]},
      {title: "خبرتنا في اليكترلوكس", icon: Award, image: "/happy-egyptian-male-customer-smiling.jpg", content: ["فنيون معتمدون من اليكترلوكس", "خبرة 17 عام", "قطع غيار سويدية أصلية", "معدات تشخيص متطورة", "ضمان 12 شهر شامل", "دعم فني متخصص", "استجابة سريعة", "أسعار تنافسية", "تقارير فنية مفصلة", "خدمة في جميع المحافظات", "تدريب مستمر", "رضا العملاء 98%"]},
    ],
    warranty: "ضمان 12 شهر على القطع الأوروبية + 6 أشهر على العمالة",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  electrostar: {
    name: "إليكتروستار",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/إليكتروستار.png",
    tagline: "الجودة المصرية المميزة",
    description: "إليكتروستار من الماركات المصرية المعروفة بجودتها وأسعارها المناسبة",
    hero: {
      title: "مركز صيانة إليكتروستار",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة إليكتروستار المصرية",
    },
    sections: [
      {title: "عن إليكتروستار", icon: Award, image: "/placeholder.svg", content: ["إليكتروستار ماركة مصرية معروفة", "تقدم أجهزة منزلية متنوعة", "معروفة بالأسعار المناسبة", "منتشرة في السوق المحلي", "شبكة خدمة واسعة", "ضمان معتمد", "تصميمات عملية", "قطع غيار متوفرة"]},
      {title: "خدمات الصيانة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات إليكتروستار", "إصلاح الثلاجات", "صيانة المكيفات", "إصلاح المجففات", "صيانة الميكروويف", "إصلاح غسالات الأطباق", "استبدال القطع", "الصيانة الدورية", "فحص شامل", "خدمة سريعة"]},
      {title: "مميزات الخدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["فنيون متخصصون", "قطع غيار أصلية", "ضمان 12 شهر", "أسعار مناسبة", "استجابة سريعة", "خدمة منزلية", "تقارير واضحة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في التبريد", "أعطال المحرك", "تسرب المياه", "أصوات غير طبيعية", "مشاكل في التحكم", "عدم التصريف", "مشاكل في الباب", "استهلاك عالي", "رائحة كريهة", "عدم العمل"]},
      {title: "خبرتنا", icon: Award, image: "/happy-middle-aged-egyptian-man.jpg", content: ["خبرة 16 عام", "فنيون معتمدون", "قطع غيار أصلية", "ضمان شامل", "استجابة سريعة", "أسعار عادلة", "خدمة منزلية", "تقارير مفصلة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء", "خدمة ممتازة"]},
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  beko: {
    name: "بيكو",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/بيكو.png",
    tagline: "التقنية التركية الموثوقة",
    description: "بيكو من الشركات التركية الرائدة عالمياً في مجال الأجهزة المنزلية",
    hero: {
      title: "مركز صيانة بيكو",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة بيكو التركية",
    },
    sections: [
      {title: "عن بيكو التركية", icon: Award, image: "/placeholder.svg", content: ["بيكو شركة تركية رائدة", "تعمل في أكثر من 140 دولة", "من أكبر شركات الأجهزة المنزلية", "معروفة بالجودة العالية", "تقنيات متطورة ومبتكرة", "أسعار مناسبة", "شبكة خدمة عالمية", "قطع غيار متوفرة"]},
      {title: "خدمات الصيانة المتخصصة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات بيكو", "إصلاح الثلاجات بتقنية NeoFrost", "صيانة غسالات الأطباق", "إصلاح الأفران", "صيانة المجففات", "إصلاح الشفاطات", "صيانة الأنظمة الإلكترونية", "تحديث البرامج", "استبدال قطع غيار أصلية", "الصيانة الدورية"]},
      {title: "التقنيات المتقدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["تقنية NeoFrost Dual Cooling", "نظام ProSmart Inverter", "تقنية AquaTech للغسيل", "نظام AutoDose الذكي", "تقنية SteamCure", "نظام IonGuard", "تقنية AeroPerfect", "نظام RecycledTub", "تقنية HarvestFresh", "نظام EverFresh+"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في الإنفرتر", "أعطال المحرك", "مشاكل في التبريد", "أعطال إلكترونية", "مشاكل في التحكم", "تسرب المياه", "أعطال المضخة", "مشاكل في الباب", "استهلاك عالي", "مشاكل في المستشعرات"]},
      {title: "خبرتنا في بيكو", icon: Award, image: "/happy-egyptian-male-customer-smiling.jpg", content: ["فنيون معتمدون من بيكو", "خبرة 14 عام", "قطع غيار تركية أصلية", "معدات تشخيص حديثة", "ضمان 12 شهر شامل", "دعم فني متخصص", "استجابة سريعة", "أسعار تنافسية", "تقارير فنية مفصلة", "خدمة في كل المحافظات", "تدريب مستمر", "رضا العملاء"]},
    ],
    warranty: "ضمان 12 شهر على القطع + 6 أشهر على العمالة",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  whirlpool: {
    name: "وايرليبول",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/وايرليبول.png",
    tagline: "الماركة الأمريكية الموثوقة",
    description: "وايرليبول من أكبر الشركات الأمريكية في صناعة الأجهزة المنزلية منذ أكثر من 100 عام",
    hero: {
      title: "مركز صيانة وايرليبول",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة وايرليبول الأمريكية",
    },
    sections: [
      {title: "عن وايرليبول الأمريكية", icon: Award, image: "/placeholder.svg", content: ["وايرليبول شركة أمريكية عملاقة", "تأسست عام 1911 في أمريكا", "من أكبر شركات الأجهزة المنزلية عالمياً", "معروفة بالموثوقية والمتانة", "تقنيات متطورة ومبتكرة", "معايير جودة أمريكية صارمة", "منتشرة في أكثر من 170 دولة", "شبكة خدمة عالمية موثوقة"]},
      {title: "خدمات الصيانة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات وايرليبول", "إصلاح الثلاجات", "صيانة غسالات الأطباق", "إصلاح المجففات", "صيانة الأفران والمايكروويف", "إصلاح الشفاطات", "استبدال قطع غيار أصلية", "الصيانة الدورية", "فحص شامل", "خدمة سريعة"]},
      {title: "مميزات الخدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["فنيون معتمدون", "قطع غيار أمريكية أصلية", "ضمان 12 شهر", "أسعار تنافسية", "استجابة سريعة", "خدمة منزلية", "تقارير مفصلة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في التبريد", "أعطال المحرك", "تسرب المياه", "أصوات غير طبيعية", "مشاكل في التحكم", "عدم التصريف", "مشاكل في الباب", "استهلاك عالي", "رائحة كريهة", "عدم العمل"]},
      {title: "خبرتنا", icon: Award, image: "/happy-egyptian-male-customer-smiling.jpg", content: ["خبرة 19 عام", "فنيون معتمدون", "قطع غيار أصلية", "ضمان شامل", "استجابة سريعة", "أسعار عادلة", "خدمة منزلية", "تقارير مفصلة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء", "خدمة ممتازة"]},
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  bosch: {
    name: "بوش",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/بوش.png",
    tagline: "الهندسة الألمانية الرائدة",
    description: "بوش من أعرق الشركات الألمانية العالمية المعروفة بالهندسة الدقيقة والجودة الفائقة",
    hero: {
      title: "مركز صيانة بوش",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة بوش الألمانية بأعلى معايير الجودة",
    },
    sections: [
      {title: "عن بوش الألمانية", icon: Award, image: "/placeholder.svg", content: ["بوش شركة ألمانية عريقة تأسست عام 1886", "من أكبر الشركات الهندسية في العالم", "معروفة بالدقة والجودة الألمانية الفائقة", "رائدة في تكنولوجيا الأجهزة المنزلية", "تعمل في أكثر من 150 دولة", "معايير جودة ألمانية صارمة", "تقنيات مبتكرة ومتطورة", "شبكة خدمة عالمية موثوقة"]},
      {title: "خدمات الصيانة المتخصصة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات بوش", "إصلاح الثلاجات", "صيانة غسالات الأطباق", "إصلاح الأفران", "صيانة المجففات", "إصلاح الشفاطات", "صيانة الأنظمة الإلكترونية", "تحديث البرامج", "استبدال قطع غيار ألمانية أصلية", "الصيانة الدورية الشاملة"]},
      {title: "التقنيات الألمانية", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["تقنية EcoSilence Drive", "نظام Home Connect الذكي", "تقنية VarioSpeed", "نظام PerfectDry", "تقنية ActiveWater", "نظام VitaFresh", "تقنية Serie 8", "نظام AutoPilot", "تقنية توفير الطاقة", "نظام التشخيص الذكي"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في الأنظمة الإلكترونية", "أعطال المحرك", "مشاكل في التبريد", "أعطال Home Connect", "مشاكل في التحكم", "تسرب المياه", "أعطال المضخة", "مشاكل في الباب", "استهلاك عالي", "مشاكل في المستشعرات"]},
      {title: "خبرتنا في بوش", icon: Award, image: "/happy-egyptian-male-customer-smiling.jpg", content: ["فنيون معتمدون من بوش", "خبرة 18 عام في الأجهزة الألمانية", "قطع غيار ألمانية أصلية 100%", "معدات تشخيص متطورة", "ضمان 12 شهر شامل", "دعم فني للأنظمة الذكية", "استجابة سريعة", "أسعار تنافسية", "تقارير فنية تفصيلية", "خدمة في جميع المحافظات", "تدريب مستمر", "رضا العملاء 99%"]},
    ],
    warranty: "ضمان 12 شهر على القطع الألمانية + 6 أشهر على العمالة",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  indesit: {
    name: "انديست",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/انديست.png",
    tagline: "الجودة الإيطالية المتميزة",
    description: "انديست من الماركات الإيطالية المعروفة بجودتها وأسعارها المناسبة",
    hero: {
      title: "مركز صيانة انديست",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة انديست الإيطالية",
    },
    sections: [
      {title: "عن انديست", icon: Award, image: "/placeholder.svg", content: ["انديست ماركة إيطالية معروفة", "جزء من مجموعة Whirlpool العالمية", "معروفة بالجودة الأوروبية", "أسعار مناسبة للجميع", "منتشرة عالمياً", "ضمان معتمد", "تصميمات عملية", "قطع غيار متوفرة"]},
      {title: "خدمات الصيانة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات انديست", "إصلاح الثلاجات", "صيانة غسالات الأطباق", "إصلاح الأفران", "صيانة المجففات", "إصلاح الشفاطات", "استبدال القطع", "الصيانة الدورية", "فحص شامل", "خدمة سريعة"]},
      {title: "مميزات الخدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["فنيون متخصصون", "قطع غيار أصلية", "ضمان 12 شهر", "أسعار مناسبة", "استجابة سريعة", "خدمة منزلية", "تقارير واضحة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في التبريد", "أعطال المحرك", "تسرب المياه", "أصوات غير طبيعية", "مشاكل في التحكم", "عدم التصريف", "مشاكل في الباب", "استهلاك عالي", "رائحة كريهة", "عدم العمل"]},
      {title: "خبرتنا", icon: Award, image: "/happy-middle-aged-egyptian-man.jpg", content: ["خبرة 14 عام", "فنيون معتمدون", "قطع غيار أصلية", "ضمان شامل", "استجابة سريعة", "أسعار عادلة", "خدمة منزلية", "تقارير مفصلة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء", "خدمة ممتازة"]},
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  candy: {
    name: "كاندي",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/كاندي.png",
    tagline: "الإبداع الإيطالي الحلو",
    description: "كاندي من الماركات الإيطالية المعروفة بتصميماتها المبتكرة وأجهزتها العملية",
    hero: {
      title: "مركز صيانة كاندي",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة كاندي الإيطالية",
    },
    sections: [
      {title: "عن كاندي", icon: Award, image: "/placeholder.svg", content: ["كاندي ماركة إيطالية مشهورة", "معروفة بالتصميمات المبتكرة", "أجهزة عملية وموثوقة", "أسعار مناسبة", "منتشرة عالمياً", "ضمان معتمد", "تصميمات عصرية", "قطع غيار متوفرة"]},
      {title: "خدمات الصيانة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات كاندي", "إصلاح المجففات", "صيانة غسالات الأطباق", "إصلاح الأفران", "صيانة الثلاجات", "إصلاح الشفاطات", "استبدال القطع", "الصيانة الدورية", "فحص شامل", "خدمة سريعة"]},
      {title: "مميزات الخدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["فنيون متخصصون", "قطع غيار أصلية", "ضمان 12 شهر", "أسعار مناسبة", "استجابة سريعة", "خدمة منزلية", "تقارير واضحة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في التبريد", "أعطال المحرك", "تسرب المياه", "أصوات غير طبيعية", "مشاكل في التحكم", "عدم التصريف", "مشاكل في الباب", "استهلاك عالي", "رائحة كريهة", "عدم العمل"]},
      {title: "خبرتنا", icon: Award, image: "/happy-egyptian-male-customer-smiling.jpg", content: ["خبرة 13 عام", "فنيون معتمدون", "قطع غيار أصلية", "ضمان شامل", "استجابة سريعة", "أسعار عادلة", "خدمة منزلية", "تقارير مفصلة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء", "خدمة ممتازة"]},
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  basab: {
    name: "باساب",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/باساب.png",
    tagline: "الجودة المصرية المحلية",
    description: "باساب من الماركات المصرية المعروفة في السوق المحلي بأسعارها المناسبة",
    hero: {
      title: "مركز صيانة باساب",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة باساب المصرية",
    },
    sections: [
      {title: "عن باساب", icon: Award, image: "/placeholder.svg", content: ["باساب ماركة مصرية محلية", "معروفة في السوق المصري", "أسعار اقتصادية مناسبة", "منتشرة في المحافظات", "شبكة خدمة متوفرة", "ضمان معتمد", "تصميمات بسيطة", "قطع غيار متوفرة"]},
      {title: "خدمات الصيانة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات باساب", "إصلاح الثلاجات", "صيانة المكيفات", "إصلاح المجففات", "صيانة الميكروويف", "إصلاح غسالات الأطباق", "استبدال القطع", "الصيانة الدورية", "فحص شامل", "خدمة سريعة"]},
      {title: "مميزات الخدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["فنيون متخصصون", "قطع غيار أصلية", "ضمان 12 شهر", "أسعار مناسبة", "استجابة سريعة", "خدمة منزلية", "تقارير واضحة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في التبريد", "أعطال المحرك", "تسرب المياه", "أصوات غير طبيعية", "مشاكل في التحكم", "عدم التصريف", "مشاكل في الباب", "استهلاك عالي", "رائحة كريهة", "عدم العمل"]},
      {title: "خبرتنا", icon: Award, image: "/happy-middle-aged-egyptian-man.jpg", content: ["خبرة 14 عام", "فنيون معتمدون", "قطع غيار أصلية", "ضمان شامل", "استجابة سريعة", "أسعار عادلة", "خدمة منزلية", "تقارير مفصلة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء", "خدمة ممتازة"]},
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  haier: {
    name: "هاير",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/هاير.png",
    tagline: "التقنية الصينية المتقدمة",
    description: "هاير من أكبر الشركات الصينية في صناعة الأجهزة المنزلية عالمياً",
    hero: {
      title: "مركز صيانة هاير",
      subtitle: "خدمات صيانة احترافية لجميع أجهزة هاير الصينية",
    },
    sections: [
      {title: "عن هاير الصينية", icon: Award, image: "/placeholder.svg", content: ["هاير من أكبر شركات الأجهزة المنزلية", "تأسست في الصين عام 1984", "تعمل في أكثر من 160 دولة", "معروفة بالتقنيات المتقدمة", "رائدة في الابتكار", "معايير جودة عالمية", "أسعار مناسبة", "شبكة خدمة عالمية"]},
      {title: "خدمات الصيانة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات هاير", "إصلاح الثلاجات", "صيانة المكيفات", "إصلاح غسالات الأطباق", "صيانة المجففات", "إصلاح الميكروويف", "استبدال القطع", "الصيانة الدورية", "فحص شامل", "خدمة سريعة"]},
      {title: "مميزات الخدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["فنيون متخصصون", "قطع غيار أصلية", "ضمان 12 شهر", "أسعار مناسبة", "استجابة سريعة", "خدمة منزلية", "تقارير واضحة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في التبريد", "أعطال المحرك", "تسرب المياه", "أصوات غير طبيعية", "مشاكل في التحكم", "عدم التصريف", "مشاكل في الباب", "استهلاك عالي", "رائحة كريهة", "عدم العمل"]},
      {title: "خبرتنا", icon: Award, image: "/happy-egyptian-male-customer-smiling.jpg", content: ["خبرة 15 عام", "فنيون معتمدون", "قطع غيار أصلية", "ضمان شامل", "استجابة سريعة", "أسعار عادلة", "خدمة منزلية", "تقارير مفصلة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء", "خدمة ممتازة"]},
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  geronji: {
    name: "چيرونچي",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/چيرونچي.png",
    tagline: "الجودة المصرية المحلية",
    description: "چيرونچي من الماركات المصرية المعروفة في السوق المحلي",
    hero: {
      title: "مركز صيانة چيرونچي",
      subtitle: "خدمات صيانة متخصصة لجميع أجهزة چيرونچي المصرية",
    },
    sections: [
      {title: "عن چيرونچي", icon: Award, image: "/placeholder.svg", content: ["چيرونچي ماركة مصرية محلية", "معروفة في السوق المصري", "أسعار اقتصادية", "منتشرة في المحافظات", "شبكة خدمة متوفرة", "ضمان معتمد", "تصميمات بسيطة", "قطع غيار متوفرة"]},
      {title: "خدمات الصيانة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات چيرونچي", "إصلاح الثلاجات", "صيانة المكيفات", "إصلاح المجففات", "صيانة الميكروويف", "إصلاح غسالات الأطباق", "استبدال القطع", "الصيانة الدورية", "فحص شامل", "خدمة سريعة"]},
      {title: "مميزات الخدمة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["فنيون متخصصون", "قطع غيار أصلية", "ضمان 12 شهر", "أسعار مناسبة", "استجابة سريعة", "خدمة منزلية", "تقارير واضحة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء"]},
      {title: "الأعطال الشائعة", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في التبريد", "أعطال المحرك", "تسرب المياه", "أصوات غير طبيعية", "مشاكل في التحكم", "عدم التصريف", "مشاكل في الباب", "استهلاك عالي", "رائحة كريهة", "عدم العمل"]},
      {title: "خبرتنا", icon: Award, image: "/happy-middle-aged-egyptian-man.jpg", content: ["خبرة 13 عام", "فنيون معتمدون", "قطع غيار أصلية", "ضمان شامل", "استجابة سريعة", "أسعار عادلة", "خدمة منزلية", "تقارير مفصلة", "نصائح مفيدة", "صيانة دورية", "رضا العملاء", "خدمة ممتازة"]},
    ],
    warranty: "ضمان 12 شهر على جميع الخدمات",
    coverage: "خدمة متاحة في جميع محافظات مصر",
  },
  miele: {
    name: "مييلا",
    logo: "/placeholder.svg",
    heroImage: "/centerlogo/مييلا.png",
    tagline: "الفخامة الألمانية المطلقة",
    description: "مييلا من أرقى الشركات الألمانية في صناعة الأجهزة المنزلية الفاخرة",
    hero: {
      title: "مركز صيانة مييلا",
      subtitle: "خدمات صيانة فاخرة لجميع أجهزة مييلا الألمانية بأعلى معايير الجودة",
    },
    sections: [
      {title: "عن مييلا الألمانية", icon: Award, image: "/placeholder.svg", content: ["مييلا شركة ألمانية فاخرة تأسست عام 1899", "من أرقى ماركات الأجهزة المنزلية عالمياً", "معروفة بالجودة الألمانية الفائقة", "أجهزة فاخرة وموثوقة", "ضمان لـ 20 سنة على المنتجات", "تقنيات متطورة جداً", "معايير جودة صارمة جداً", "الخيار الأول للفنادق الفاخرة"]},
      {title: "خدمات الصيانة الفاخرة", icon: Wrench, image: "/washing-machine-repair-technician.jpg", content: ["صيانة غسالات مييلا الفاخرة", "إصلاح الثلاجات الذكية", "صيانة غسالات الأطباق", "إصلاح الأفران الاحترافية", "صيانة المجففات", "إصلاح الشفاطات", "صيانة الأنظمة الذكية", "تحديث البرامج", "استبدال قطع غيار ألمانية أصلية", "صيانة دورية VIP"]},
      {title: "التقنيات الفاخرة", icon: CheckCircle, image: "/refrigerator-repair-service.jpg", content: ["تقنية TwinDos الأوتوماتيكية", "نظام Perfect Fresh Pro", "تقنية M Touch الذكية", "نظام AutoDos الفاخر", "تقنية PowerWash 2.0", "نظام PerfectClean", "تقنية MultiSteam", "نظام M-Touch", "تقنية QuickPowerWash", "نظام WiFiConn@ct"]},
      {title: "الأعطال", icon: Shield, image: "/professional-technician-repairing-washing-machine.jpg", content: ["مشاكل في الأنظمة الذكية", "أعطال المحرك", "مشاكل في التحكم", "أعطال WiFi", "مشاكل في المستشعرات", "تسرب المياه", "أعطال إلكترونية", "مشاكل في الباب", "مشاكل في الشاشة", "أعطال في التجفيف"]},
      {title: "خبرتنا في مييلا", icon: Award, image: "/happy-egyptian-male-customer-smiling.jpg", content: ["فنيون معتمدون من مييلا", "خبرة 16 عام في الأجهزة الفاخرة", "قطع غيار ألمانية أصلية 100%", "معدات تشخيص خاصة بمييلا", "ضمان 12 شهر Premium", "دعم فني VIP", "استجابة خلال 24 ساعة", "خدمة فاخرة", "تقارير تفصيلية", "خدمة في كل المحافظات", "تدريب متقدم", "رضا العملاء 99%"]},
    ],
    warranty: "ضمان Premium 12 شهر على القطع الألمانية + 6 أشهر على العمالة",
    coverage: "خدمة فاخرة متاحة في جميع محافظات مصر",
  },
}

export default async function BrandDetailPage({ params }: { params: Promise<{ brandSlug: string }> }) {
  const { brandSlug } = await params
  const brandId = getBrandIdFromSlug(brandSlug)

  if (!brandId) {
    notFound()
  }

  const brand = brandsData[brandId]

  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#2563eb] to-[#3b82f6] text-white py-12 sm:py-16 md:py-20 px-4 sm:px-6 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        </div>
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-row items-center gap-3 sm:gap-6 mb-6">
            <div className="w-28 h-20 sm:w-32 sm:h-24 md:w-44 md:h-32 lg:w-52 lg:h-36 bg-white rounded-xl sm:rounded-2xl p-2 sm:p-3 md:p-4 shadow-xl flex-shrink-0 overflow-hidden flex items-center justify-center">
              <img src={encodeURI(brand.heroImage || brand.logo || "/placeholder.svg")} alt={brand.name} className="w-full h-full object-contain rounded-lg" />
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-3xl sm:text-3xl md:text-5xl lg:text-6xl font-bold mb-1 sm:mb-2 leading-tight">{brand.hero.title}</h1>
              <p className="text-sm sm:text-base md:text-xl text-blue-100">{brand.tagline}</p>
            </div>
          </div>
          <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-blue-100 max-w-3xl leading-relaxed mb-4 sm:mb-6">{brand.hero.subtitle}</p>
          <MaintenanceHeroButtons brandName={brand.name} />
        </div>
      </section>

      {/* Brand Description */}
      <section className="py-8 sm:py-10 md:py-12 px-4 sm:px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="bg-[#F5F7FA] p-4 sm:p-6 md:p-8 rounded-xl sm:rounded-2xl">
            <p className="text-sm sm:text-base md:text-lg text-[#475569] leading-relaxed">{brand.description}</p>
          </div>
        </div>
      </section>

      {/* Services Grid Section */}
      <section className="py-8 sm:py-12 md:py-16 px-4 sm:px-6 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
            {[
              {
                title: "صيانة ثلاجات",
                description: "صيانة شاملة لجميع أنواع الثلاجات مع فنيين معتمدين وقطع غيار أصلية. نصلح جميع الأعطال: مشاكل التبريد، تسرب المياه، الأعطال الكهربائية، وأكثر.",
                image: "/repair/صيانة ثلاجات.jpg",
              },
              {
                title: "صيانة ديب فريزر",
                description: "خدمة صيانة متخصصة للديب فريزر بجميع الأحجام. إصلاح مشاكل التجميد، الأعطال الكهربائية، تسرب الغاز، وصيانة دورية شاملة.",
                image: "/repair/صيانة ديب فريزر.jpg",
              },
              {
                title: "صيانة غسالات أوتوماتيك",
                description: "صيانة احترافية لجميع أنواع الغسالات الأوتوماتيكية. إصلاح الأعطال الميكانيكية والكهربائية، استبدال قطع الغيار، وضمان مكتوب على جميع الأعمال.",
                image: "/repair/صيانة غسالات أوتوماتيك.jpg",
              },
              {
                title: "صيانة غسالات فوق أوتوماتيك",
                description: "خدمة صيانة متخصصة للغسالات الفوق أوتوماتيك بجميع الموديلات. إصلاح الأعطال الميكانيكية والكهربائية، تنظيف شامل، وضمان مكتوب على الصيانة.",
                image: "/repair/صيانة غسالات فوق أوتوماتيك.jpg",
              },
              {
                title: "صيانة غسالات أطباق",
                description: "خدمة صيانة متخصصة لغسالات الأطباق بجميع الموديلات. إصلاح الأعطال الهيدروليكية والكهربائية، تنظيف شامل، وضمان على الصيانة.",
                image: "/repair/صيانة غسالات أطباق.jpg",
              },
              {
                title: "صيانة مجففات",
                description: "صيانة شاملة للمجففات بجميع الأنواع. إصلاح مشاكل التسخين، الأعطال الكهربائية، مشاكل الدوران، وضمان مكتوب على الصيانة.",
                image: "/repair/صيانة مجففات.jpg",
              },
              {
                title: "صيانة ميكروويف",
                description: "صيانة سريعة وفعالة لجميع أنواع الميكروويف. إصلاح مشاكل التسخين، الأعطال الكهربائية، استبدال قطع الغيار، وضمان على العمل.",
                image: "/repair/صيانة ميكروويف.jpg",
              },
              {
                title: "صيانة بوتاجازات",
                description: "صيانة احترافية للبوتاجازات بجميع الأنواع. إصلاح الأعطال الكهربائية والغازية، استبدال الشعلات، تنظيف شامل، وضمان مكتوب.",
                image: "/repair/صيانة بوتاجازات.jpg",
              },
              {
                title: "صيانة سخانات",
                description: "خدمة صيانة متخصصة لجميع أنواع السخانات الكهربائية والغازية. إصلاح تسرب المياه، مشاكل التسخين، الأعطال الكهربائية، وضمان على الصيانة.",
                image: "/repair/صيانة سخانات.jpg",
              },
              {
                title: "صيانة تكييفات",
                description: "صيانة شاملة لجميع أنواع أجهزة التكييف. إصلاح مشاكل التبريد، تسرب الغاز، تنظيف شامل، صيانة دورية، وضمان مكتوب على جميع الأعمال.",
                image: "/repair/صيانة تكييفات.jpg",
              },
            ].map((service, index) => {
              const serviceImage = service.image ?? brand.logo ?? "/placeholder.jpg"
              return (
                <div
                  key={index}
                  className="bg-white rounded-xl sm:rounded-2xl shadow-md hover:shadow-lg transition-shadow overflow-hidden"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
                  {/* Text Content */}
                  <div className="p-4 sm:p-5 md:p-6 flex flex-col justify-between">
                    <div>
                      <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-[#2563eb] mb-3 sm:mb-4">
                        {service.title} {brand.name}
                      </h3>
                      <p className="text-sm sm:text-base text-[#475569] leading-relaxed mb-4 sm:mb-6">
                        {service.description}
                      </p>
                    </div>
                    <a
                      href="tel:01110195560"
                      className="inline-flex items-center justify-center gap-2 bg-[#2563eb] text-white px-4 sm:px-5 md:px-6 py-2.5 sm:py-3 rounded-lg hover:bg-[#1d4ed8] transition-all hover:scale-105 group"
                    >
                      <div className="bg-white/20 p-1 rounded-lg group-hover:bg-white/30 transition-colors">
                        <Phone className="w-4 h-4 sm:w-5 sm:h-5" />
                      </div>
                      <span className="font-bold text-sm sm:text-base">الخط الساخن 01110195560</span>
                    </a>
                  </div>
                  {/* Image */}
                  <div className="relative w-full h-48 sm:h-56 md:h-full min-h-[200px]">
                    <Image
                      src={serviceImage}
                      alt={`${service.title} ${brand.name}`}
                      fill
                      className="object-cover"
                      sizes="(max-width: 768px) 100vw, 50vw"
                    />
                  </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Brand Sections */}
      <section className="py-8 sm:py-12 md:py-16 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto space-y-8 sm:space-y-12 md:space-y-16">
          {brand.sections.map((section, index) => {
            const Icon = section.icon
            const isEven = index % 2 === 0
            const sectionImage = getSectionDefaultImage(section.title, section.image ?? brand.logo ?? "/placeholder.jpg")
            const cardTitle = generateSectionCardTitle(section.title, brand.name)
            return (
              <div
                key={index}
                className={`grid md:grid-cols-2 gap-4 sm:gap-6 md:gap-8 items-start ${isEven ? "" : "md:grid-flow-dense"}`}
              >
                <div className={isEven ? "" : "md:col-start-2"}>
                  <div className="flex items-center gap-2 sm:gap-3 md:gap-4 mb-4 sm:mb-6">
                    <div className="bg-[#2563eb] p-2 sm:p-3 md:p-4 rounded-lg sm:rounded-xl flex-shrink-0">
                      <Icon className="w-5 h-5 sm:w-6 sm:h-6 md:w-8 md:h-8 text-white" />
                    </div>
                    <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-[#2563eb] leading-tight">{section.title}</h2>
                  </div>
                  <div className="bg-[#F5F7FA] p-4 sm:p-6 md:p-8 rounded-xl sm:rounded-2xl">
                    <ul className="space-y-3 sm:space-y-4">
                      {section.content.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2 sm:gap-3">
                          <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 text-[#2563eb] flex-shrink-0 mt-1" />
                          <span className="text-sm sm:text-base text-[#475569] leading-relaxed">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <div className={isEven ? "" : "md:col-start-1 md:row-start-1"}>
                  <div className="bg-gradient-to-br from-[#2563eb] to-[#3b82f6] p-4 sm:p-6 md:p-8 rounded-xl sm:rounded-2xl text-white h-full flex flex-col justify-center">
                    {sectionImage && (
                      <div className="mb-4 sm:mb-6 relative w-full h-32 sm:h-40 md:h-48 rounded-lg sm:rounded-xl overflow-hidden shadow-lg">
                        <Image
                          src={sectionImage}
                          alt={`${brand.name} - ${section.title}`}
                          fill
                          className="object-cover"
                          sizes="(max-width: 768px) 100vw, 50vw"
                        />
                      </div>
                    )}
                    <div className="mb-4 sm:mb-6">
                      <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
                        <Icon className="w-5 h-5 sm:w-6 sm:h-6 flex-shrink-0" />
                        <h3 className="text-lg sm:text-xl md:text-2xl font-bold leading-tight">{cardTitle}</h3>
                      </div>
                      <p className="text-sm sm:text-base text-blue-100 leading-relaxed">
                        نقدم خدمات متخصصة وموثوقة لجميع منتجات {brand.name} مع ضمان الجودة والكفاءة
                      </p>
                    </div>
                    <div className="space-y-2 sm:space-y-3">
                      <div className="flex items-center gap-2 sm:gap-3">
                        <Shield className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0" />
                        <span className="text-xs sm:text-sm md:text-base">{brand.warranty}</span>
                      </div>
                      <div className="flex items-center gap-2 sm:gap-3">
                        <MapPin className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0" />
                        <span className="text-xs sm:text-sm md:text-base">{brand.coverage}</span>
                      </div>
                      <div className="flex items-center gap-2 sm:gap-3">
                        <Clock className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0" />
                        <span className="text-xs sm:text-sm md:text-base">استجابة خلال 24 ساعة</span>
                      </div>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 mt-4 sm:mt-6 pt-4 sm:pt-6 border-t border-white/20">
                      <a
                        href="tel:01110195560"
                        className="flex-1 block bg-white text-[#2563eb] px-3 sm:px-4 py-2 sm:py-3 rounded-lg sm:rounded-xl font-bold hover:shadow-xl hover:bg-blue-50 transition-all hover:scale-[1.02] flex items-center justify-center gap-2 group"
                      >
                        <div className="bg-[#2563eb]/10 p-1 sm:p-1.5 rounded-lg group-hover:bg-[#2563eb]/20 transition-colors">
                          <Phone className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#2563eb]" />
                  </div>
                        <div className="text-center text-[#2563eb] font-bold">
                          <span className="text-xs sm:text-sm md:text-base">الخط الساخن </span>
                          <span className="text-sm sm:text-base md:text-xl">01110195560</span>
                        </div>
                      </a>
                      <a
                        href="https://wa.me/201110195560"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 block bg-[#25D366] text-white px-3 sm:px-4 py-2 sm:py-3 rounded-lg sm:rounded-xl font-bold hover:shadow-xl hover:bg-[#20BA5A] transition-all hover:scale-[1.02] flex items-center justify-center gap-2 group"
                      >
                        <div className="bg-white/20 p-1 sm:p-1.5 rounded-lg group-hover:bg-white/30 transition-colors">
                          <MessageCircle className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                        </div>
                        <div className="text-center text-xs sm:text-sm md:text-base">
                          تواصل عبر واتساب
                        </div>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </section>

      {/* Contact Form Section */}
      <ContactForm brandName={brand.name} />

      {/* CTA Section */}
      <MaintenanceCTASection brandName={brand.name} />

      {/* Disclaimer Footer */}
      <section className="bg-white border-t-2 border-gray-400 pt-10 pb-32 sm:pt-10 sm:pb-20 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto">
          <p className="text-xl sm:text-base md:text-base text-gray-900 font-medium text-center leading-relaxed px-4 break-words">
            مركز صيانة مستقل متخصص فى صيانة واصلاح الأجهزة المنزلية ولسنا وكلاء أو تابعين لأى شركة أو علامة تجارية مذكورة
          </p>
        </div>
      </section>
    </main>
  )
}
