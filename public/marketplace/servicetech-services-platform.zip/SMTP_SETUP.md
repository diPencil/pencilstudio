# إعداد SMTP مع Hostinger

## ✅ الإعدادات المطلوبة

### 1. معلومات SMTP من Hostinger
عادةً ما تكون إعدادات SMTP لـ Hostinger:

- **SMTP Host:** `smtp.hostinger.com`
- **SMTP Port:** `465` (SSL) أو `587` (TLS)
- **SMTP Username:** إيميلك الكامل (مثل: `info@service-egy.com`)
- **SMTP Password:** كلمة مرور الإيميل
- **From Email:** `info@service-egy.com` (أو أي إيميل على نفس الدومين)
- **To Email:** `info@service-egy.com` (الإيميل الذي تريد استقبال الطلبات عليه)

### 2. إعداد متغيرات البيئة

أنشئ ملف `.env.local` في جذر المشروع (نفس مجلد `package.json`) وأضف:

```env
# SMTP Settings for Hostinger
SMTP_HOST=smtp.hostinger.com
SMTP_PORT=465
SMTP_USER=info@service-egy.com
SMTP_PASSWORD=your_email_password_here
SMTP_FROM=info@service-egy.com
SMTP_TO=info@service-egy.com
```

**مثال:**
```env
SMTP_HOST=smtp.hostinger.com
SMTP_PORT=465
SMTP_USER=info@service-egy.com
SMTP_PASSWORD=MySecurePassword123!
SMTP_FROM=info@service-egy.com
SMTP_TO=info@service-egy.com
```

### 3. ملاحظات مهمة

#### أ) كلمة مرور الإيميل
- استخدم كلمة مرور الإيميل الحقيقية
- إذا كان لديك "App Password" من Hostinger، استخدمه
- تأكد من أن الإيميل مفعل ويمكنه إرسال الرسائل

#### ب) المنفذ (Port)
- **465**: SSL (مُوصى به)
- **587**: TLS (بديل)
- جرب 465 أولاً، إذا لم يعمل استخدم 587

#### ج) الأمان
- **لا تشارك ملف `.env.local`** - أضفه إلى `.gitignore`
- تأكد من أن `.env.local` موجود في `.gitignore`

### 4. إعادة بناء المشروع

بعد إضافة المتغيرات:

```bash
npm run build
```

أو للتطوير:

```bash
npm run dev
```

### 5. اختبار الفورم

1. افتح الموقع
2. املأ الفورم
3. أرسل الطلب
4. تحقق من إيميل `info@service-egy.com`

## 🔧 استكشاف الأخطاء

### المشكلة: "خطأ في بيانات الدخول SMTP"
**الحل:**
- تأكد من صحة اسم المستخدم وكلمة المرور
- تأكد من أن الإيميل مفعل
- جرب استخدام App Password إذا كان متاحاً

### المشكلة: "فشل الاتصال بخادم SMTP"
**الحل:**
- تأكد من أن `SMTP_HOST` صحيح
- جرب تغيير المنفذ من 465 إلى 587
- تأكد من أن Firewall لا يمنع الاتصال

### المشكلة: الإيميل لا يصل
**الحل:**
- تحقق من مجلد Spam
- تأكد من أن `SMTP_TO` صحيح
- تحقق من Console في Terminal لأي أخطاء
- تأكد من أن الإيميل يمكنه استقبال الرسائل

## 📝 معلومات إضافية عن Hostinger SMTP

عادةً ما تكون إعدادات Hostinger:
- **SMTP Host:** `smtp.hostinger.com`
- **Port 465:** SSL/TLS
- **Port 587:** STARTTLS
- **Authentication:** مطلوب (اسم المستخدم وكلمة المرور)

## 🔒 الأمان

1. **لا ترفع `.env.local` على GitHub**
2. تأكد من وجود `.env.local` في `.gitignore`
3. استخدم كلمات مرور قوية
4. لا تشارك ملف `.env.local` مع أي شخص

## ✅ التحقق من الإعداد

بعد الإعداد، جرب إرسال فورم تجريبي. إذا نجح، ستجد الإيميل في صندوق الوارد (أو Spam) في `info@service-egy.com`.



