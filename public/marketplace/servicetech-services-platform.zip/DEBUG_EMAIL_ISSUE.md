# حل مشكلة عدم وصول الإيميلات

## 🔍 الخطوات لفحص المشكلة:

### 1. فتح Console في المتصفح
1. افتح الموقع في المتصفح
2. اضغط `F12` أو `Ctrl+Shift+I` لفتح Developer Tools
3. اذهب إلى تبويب **Console**
4. حاول إرسال نموذج
5. ابحث عن الرسائل التالية:
   - `Sending request to API endpoint: ...`
   - `API Response status: ...`
   - أي رسائل خطأ (باللون الأحمر)

### 2. التحقق من Vercel API
1. افتح Vercel Dashboard
2. اذهب إلى مشروع API
3. تحقق من **Environment Variables**:
   - `SMTP_HOST` = `smtp.hostinger.com`
   - `SMTP_PORT` = `465`
   - `SMTP_USER` = `your-email@service-egy.com`
   - `SMTP_PASSWORD` = `your-password`
   - `SMTP_TO` = `info@service-egy.com`
   - `ALLOWED_ORIGINS` = `*` أو `https://your-hostinger-domain.com`

### 3. التحقق من CORS
1. تأكد من أن `ALLOWED_ORIGINS` في Vercel يتضمن domain Hostinger
2. مثال: `ALLOWED_ORIGINS=https://service-egy.com,https://www.service-egy.com`
3. أو استخدم `*` للسماح بجميع domains (للتطوير فقط)

### 4. التحقق من API Endpoint
1. افتح `next.config.mjs`
2. تأكد من أن `NEXT_PUBLIC_CONTACT_ENDPOINT` يحتوي على URL Vercel الصحيح
3. مثال: `https://service-egy-api.vercel.app/api/contact`

### 5. اختبار API مباشرة
افتح Terminal أو Postman واختبر API مباشرة:

```bash
curl -X POST https://service-egy-api.vercel.app/api/contact \
  -H "Content-Type: application/json" \
  -H "Origin: https://your-hostinger-domain.com" \
  -d '{
    "name": "Test User",
    "address": "Test Address",
    "phone": "01234567890",
    "whatsapp": "01234567890",
    "issueType": "عطل كهربائي",
    "deviceType": "غسالة ملابس",
    "details": "Test message"
  }'
```

### 6. التحقق من Logs في Vercel
1. افتح Vercel Dashboard
2. اذهب إلى مشروع API
3. اذهب إلى **Logs**
4. ابحث عن أي أخطاء أو رسائل

## 🐛 المشاكل الشائعة والحلول:

### المشكلة 1: CORS Error
**الخطأ**: `Access to fetch at '...' from origin '...' has been blocked by CORS policy`

**الحل**:
1. تأكد من أن `ALLOWED_ORIGINS` في Vercel يتضمن domain Hostinger
2. أضف domain Hostinger إلى `ALLOWED_ORIGINS`:
   ```
   ALLOWED_ORIGINS=https://your-hostinger-domain.com,https://www.your-hostinger-domain.com
   ```

### المشكلة 2: SMTP Authentication Error
**الخطأ**: `EAUTH` أو `خطأ في بيانات الدخول SMTP`

**الحل**:
1. تأكد من أن `SMTP_USER` و `SMTP_PASSWORD` صحيحين في Vercel
2. تأكد من أن الإيميل موجود في Hostinger
3. تأكد من أن كلمة المرور صحيحة

### المشكلة 3: Connection Error
**الخطأ**: `ECONNECTION` أو `فشل الاتصال بخادم SMTP`

**الحل**:
1. تأكد من أن `SMTP_HOST` = `smtp.hostinger.com`
2. تأكد من أن `SMTP_PORT` = `465`
3. تأكد من أن Hostinger يسمح بالاتصالات من Vercel

### المشكلة 4: API Endpoint Not Found
**الخطأ**: `404 Not Found` أو `API route not available`

**الحل**:
1. تأكد من أن URL Vercel صحيح في `next.config.mjs`
2. تأكد من أن API route موجود في Vercel
3. تأكد من أن Vercel project تم رفعه بشكل صحيح

### المشكلة 5: الإيميلات تذهب إلى Junk
**الحل**:
1. تأكد من أن `from` address في API route يستخدم `SMTP_USER`
2. تأكد من إزالة أي headers قد تسبب spam
3. تأكد من أن محتوى الإيميل لا يحتوي على كلمات spam

## 📝 خطوات إعادة البناء:

1. **تحديث الكود**:
   ```bash
   npm run build
   ```

2. **رفع مجلد `out` على Hostinger**:
   - ارفع جميع محتويات مجلد `out` على Hostinger
   - تأكد من أن `index.html` موجود في الجذر

3. **التحقق من Vercel**:
   - تأكد من أن environment variables موجودة
   - تأكد من أن API route يعمل بشكل صحيح

## 🔧 نصائح إضافية:

1. **استخدام Console**: افتح Console في المتصفح لرؤية الأخطاء
2. **فحص Network Tab**: افتح Network tab في Developer Tools لرؤية طلبات API
3. **فحص Vercel Logs**: راجع logs في Vercel لرؤية أخطاء الخادم
4. **اختبار API مباشرة**: استخدم curl أو Postman لاختبار API مباشرة

## 📞 التواصل:

إذا استمرت المشكلة، تأكد من:
1. فتح Console في المتصفح ورؤية الأخطاء
2. فحص Vercel Logs لرؤية أخطاء الخادم
3. التحقق من environment variables في Vercel
4. التحقق من CORS settings في Vercel









